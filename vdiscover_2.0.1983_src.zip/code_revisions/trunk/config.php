<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

# $Rev: 1950 $

if (!defined('APPLICATION_started')) {header('Location: .');exit;}

# Setting the subversion revision

$revision = substr('$Revision: 1950 $',11,-2);
// Development version instead of a version with a number
$repository_config['subversion_revision'] = "0.1983";
// $repository_config['subversion_revision'] = "0.".$revision;

# Configuration -----------------------------

# session configuration
session_save_path  		( $repository_config['path_sessions'] );
session_cache_expire	( 30 /*[min]*/ );
session_cache_limiter 	( 'nocache');

define ('DEFAULT_TIMEZONE','Europe/Berlin');
{ # Set timezone	
	date_default_timezone_set(DEFAULT_TIMEZONE);
}

# End of file --------------------------------

# Add a dot or comment, if you want to update the svn code version number, here:
#........

?>