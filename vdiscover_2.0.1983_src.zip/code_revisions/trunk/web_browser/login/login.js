/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.require("dojo.data.ItemFileReadStore");
dojo.require("dijit.form.Button");
dojo.require("dijit.form.Form");
dojo.require("dijit.form.TextBox");
dojo.require("dijit.form.ValidationTextBox");
dojo.require("dijit.form.CheckBox");
dojo.require("dijit.form.FilteringSelect");
dojo.require("dijit.layout.BorderContainer");
dojo.require("dijit.layout.ContentPane");

dojo.declare('login.widgets.loginDialog',[common.widgets.fixedSizeDialog],{
	
	// these slots have values need to be passed when creating the widget
	// 'name'			: null, // mandantory STRING --- the parent object type name
	// 'OT_UUID'		: null, // mandantory STRING --- the parent object type's UUID
	
	
	// the following slots form internal variables / containers
	'_loginDisabled'	: null,
	
	
	// settings of the parent class common.widgets.fixedSizeDialog
	'innerWidth'	: 480,
	'innerHeight'	: 600,
	'closable'		: false,
	
	
	// widget life cycle
	'constructor' : function () {
	
		// some initialisations
		this.widgets 		= {};
		this._loginDiabled = ('login_disabled' in application.configuration.global);
		
	} // end of method constructor
	,
	'postMixInProperties' : function () {
		this.inherited(arguments);
	
		this.title = application.configuration.global.application_version; 
	
	} // end of method postMixInProperties
	,
	'buildRendering' : function () {
		this.inherited(arguments);
		
		this.widgets.BC = new dijit.layout.BorderContainer({
			'style'		: 'width:100%;height:100%;',
			'gutters'	: false,
		});
		this.widgets.BC.placeAt(this.containerNode);
		
		this.widgets.logoPane = new dijit.layout.ContentPane({
			// 'id'		: 'logoPane',
			'region'	: 'center',
			'href'		: application.configuration.global.RS_appTitle_href,
		});
		this.widgets.BC.addChild(this.widgets.logoPane);
		
		this.connect( this.widgets.logoPane, 'onDownloadEnd', '_resizeBC' );
		
		// -----------------------------------------------------------
		
		this.widgets.bottomPane = new dijit.layout.ContentPane({
			// 'id'		: 'bottomPane',
			'region'	: 'bottom',
			'style'		: '',
			'content'	: ''
				+'<a class="small" href="../../">'
					+T('login.js/GoToRepoOverV_LNK', 'go to the Repository Overview')
				+'</a>',
		});
		this.widgets.BC.addChild(this.widgets.bottomPane);
		
		this.widgets.loginButton = new dijit.form.Button({
			'label' 	: '<img src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/dialog-ok-apply-4.png"/> '
				+T('FUT_Login', 'Login'),
			'type'		: 'button',
			'style'		: 'float:right;margin-right:0.25em;',
		}).placeAt(this.widgets.bottomPane.containerNode);
		
		dojo.style( this.closeButtonNode, 'display', 'none' );
		
		// -----------------------------------------------------------		
		
		this.widgets.loginPane = new dijit.layout.ContentPane({
			// 'id'		: 'loginPane',
			'region'	: 'bottom',
		});
		this.widgets.BC.addChild(this.widgets.loginPane);
		
		
		dojo.create('H1', {
			'innerHTML'	: T('login.js/Welcome_TXT', 'Welcome!')
		}, this.widgets.loginPane.containerNode);
	
		dojo.create('P', {
			'innerHTML'	: T('login.js/loginHint_TXT', 'To log in, please enter your user name and password:')
		}, this.widgets.loginPane.containerNode);
	
		dojo.create('P', {
			'innerHTML'	: '&nbsp;'
		}, this.widgets.loginPane.containerNode);
	
		this.widgets.form = new dijit.form.Form({
			// 'id'		: 'loginForm',
			// 'scope'		: this,
			'action'	: '.',
			'method'	: 'POST',
			// 'onSubmit'	: function () {
				// return this.scope._onSubmit_triggered();			
			// }, // end of method onSubmit
		}).placeAt(this.widgets.loginPane.containerNode);
		this.connect( this.widgets.form, 'onSubmit', '_onSubmit_triggered' );
	
		// this hidden submit button is necessary because the displayed one is located outside this.widgets.form
		this.widgets.submitButton = new dijit.form.Button({
			'type'		: 'submit',
			'style'		: 'float:right;display:none;',
		}).placeAt(this.widgets.form.containerNode);
		
		
		// hidden input tags for the action command
		this.a_widget = new dijit.form.TextBox({
			'type'	: 'hidden',
			'name'	: 'a',
			'value'	: 'login',
			}).placeAt(this.widgets.form.containerNode);
			
		if ('jumpTo' in application.configuration.global) {
			
			var g = application.configuration.global;
			
			// hidden input tag for jumpTo command
			this.widgets.jumpTo_widget = new dijit.form.TextBox({
				'type'	: 'hidden',
				'name'	: 'jumpTo',
				'value'	: g.jumpTo,
			}).placeAt(this.widgets.form.containerNode);
			
			// hidden input tag for O_v_UUID slot
			if ('O_v_UUID' in g) this.widgets.O_v_UUID_widget = new dijit.form.TextBox({
				'type'	: 'hidden',
				'name'	: 'O_v_UUID',
				'value'	: g.O_v_UUID,
			}, this.widgets.form.containerNode);
			
			// hidden input tag for V_UUID slot
			if ('V_UUID' in g) this.widgets.V_UUID_widget = new dijit.form.TextBox({
				'type'	: 'hidden',
				'name'	: 'V_UUID',
				'value'	: g.V_UUID,
			}).placeAt(this.widgets.form.containerNode);
			
			// hidden input tag for OT_UUID slot
			if ('OT_UUID' in g) this.widgets.OT_UUID_widget = new dijit.form.TextBox({
				'type'	: 'hidden',
				'name'	: 'OT_UUID',
				'value'	: g.OT_UUID,
			}).placeAt(this.widgets.form.containerNode);
			
			// hidden input tag for FL_UUID slot
			if ('FL_UUID' in g) this.widgets.FL_UUID_widget = new dijit.form.TextBox({
				'type'	: 'hidden',
				'name'	: 'FL_UUID',
				'value'	: g.FL_UUID,
			}).placeAt(this.widgets.form.containerNode);
			
		} // end if hidden input tags are necessary
		
		if ('login_errorMessage' in application.configuration.global) {
			this._errorMessage_domNode = dojo.create( 'DIV', {
				'style'		: 'padding:.25em;margin:.5em;border-radius:.5em;border:.1ex solid red;background-color:antiquewhite;font-weight:bold;',
				'innerHTML'	: ''
					+'<p>'
						+application.configuration.global.login_errorMessage
					+'</p>'
			}, this.widgets.form.containerNode );
		} // end if
		
		if ('loginMessage' in application.configuration.global) {
			this._errorMessage_domNode = dojo.create( 'DIV', {
				'style'		: 'padding:.25em;margin:.5em;border-radius:.5em;border:.1ex solid yellow;background-color:antiquewhite;font-weight:bold;',
				'innerHTML'	: ''
					+'<p>'
						+application.configuration.global.loginMessage
					+'</p>'
			}, this.widgets.form.containerNode );
		} // end if
		
		this.loginPwd_Table = dojo.create('TABLE', {
			'class'		: 'compact',
			'style'		: 'width:98%',
			'innerHTML'	: ''
				+'<tr>'
					+'<th style="text-align:right;width:50%;vertical-align:baseline;">'
						+T('login.js/UserName_LBL', 'Your user name:' )
					+'</th>'
					+'<td class="_login_domNode" style="vertical-align:baseline;">'
					+'</td>'
				+'</tr>'
		
				+'<tr>'
					+'<th style="text-align:right;width:50%;vertical-align:baseline;">'
						+T('login.js/Password_LBL', 'Your password to log in:' )
					+'</th>'
					+'<td class="_password_domNode" style="vertical-align:baseline;">'
					+'</td>'
				+'</tr>'
				
				+'<tr colspan="2"><td>&nbsp;</td></tr>'

				+'<tr>'
					+'<td style="text-align:right;width:50%;">'
						+T('login.js/selectLocale_TXT','Choose your language:') // locale auf deutsch: Sprachversion
					+'</td>'
					+'<td class="small">'
						+'<div class="_chooseLocaleSelector_domNode"></div>'
					+'</td>'
				+'</tr>'

				+'<tr colspan="2"><td>&nbsp;</td></tr>'
				
				+'<tr class="_storeUserName_TR">'
					+'<th style="text-align:right;width:50%;">'
						+'&nbsp;'
					+'</th>'
					+'<td class="small">'
						+'<span class="_storeUserNameCheckBox_domNode" style="cursor:pointer;"></span>'
						+'&nbsp;'
						+'<span class="_storeUserNameLabel_domNode" style="cursor:pointer;">'
							+T('login.js/storeUserName_TXT','Remember my user name.')
						+'</span>'
					+'</td>'
				+'</tr>'
				+'<tr class="_storePassword_TR">'
					+'<th style="text-align:right;width:50%;">'
						+'&nbsp;'
					+'</th>'
					+'<td class="small">'
						+'<span class="_storePasswordCheckBox_domNode" style="cursor:pointer;"></span>'
						+'&nbsp;'
						+'<span class="_storePasswordLabel_domNode" style="cursor:pointer;">'
							+T('login.js/storePassword_TXT',
								'Remember my password.<br/>Do not set this option when other people '
								+'may use this computer while you are away.')
						+'</span>'
					+'</td>'
				+'</tr>'
		
		}, this.widgets.form.containerNode);

		// localise important DOM nodes
		dojo.forEach([
			'_login_domNode',
			'_storeUserName_TR',
			'_storeUserNameCheckBox_domNode',
			'_storeUserNameLabel_domNode',
			'_password_domNode',
			'_storePassword_TR',
			'_storePasswordCheckBox_domNode',
			'_storePasswordLabel_domNode',
			'_chooseLocaleSelector_domNode',
		], function (s) { this[s] = dojo.query( '.'+s, this.loginPwd_Table ).pop(); }, this);
		
		// place dijit widgets
		this.widgets.login_VTB = new dijit.form.ValidationTextBox({
			'class'				: 'fullWidth',
			'name'				: 'dialogue_login_u',
			'type'				: 'text',
			'value'				: '',
			// 'selectOnClick'		: true, // leave this deactivated because of a bug in Internet Explorer
			'required'			: true,
			'regExp'			: '.{2,}',
			'intermediateChanges': true,
			'invalidMessage'	: T('login.js/userNameInvalidMSG_TXT', 'The user name should have a length of at least 2 chars.'),
			'tooltipPosition'	: "above",
			'trim'				: true, 
			'maxlength'			: 256,
			'disabled'			: this._loginDiabled,
		}).placeAt(this._login_domNode);
		
		this.widgets.password_VTB = new dijit.form.ValidationTextBox({
			'class'				: 'fullWidth',
			'name'				: 'dialogue_login_p',
			'type'				: 'password',
			'value'				: '',
			// 'selectOnClick'		: true, // leave this deactivated because of a bug in Internet Explorer
			'required'			: true,
			'regExp'			: '.{2,}',
			'intermediateChanges': true,
			'invalidMessage'	: T('login.js/passwordInvalidMSG_TXT', 'The password should have a length of at least 2 chars.'),
			'tooltipPosition'	: "below",
			'trim'				: true, 
			'maxlength'			: 256,
			'disabled'			: this._loginDiabled,
		}).placeAt(this._password_domNode);
				
		var currentLocale = ( 		('locale' in application.configuration.global)
								&& (application.configuration.global.locale.length>0)
							) 
								? 
									application.configuration.global.locale 
								: 	'default' 
							;
		if( this._webClientHasLocalStorage() ) {
			var r	= application.configuration.global.repository_name,
				storedLocale = localStorage.getItem( 'RS_locale::'+r );
			if (storedLocale) currentLocale = storedLocale;			
		};
		

		
		this.widgets.localeSelector = new dijit.form.FilteringSelect ({
			'style' : 'width:100%;',
			'store'	: new dojo.data.ItemFileReadStore({
				'data'	: langStoreData, // global variable
			}),
			'searchAttr' : 'localeName_display',
			'name'	: 'locale',
			'value'	: currentLocale,
		}).placeAt( this._chooseLocaleSelector_domNode );
		
		// display check boxes for storing user name and password if possible
		if ( this._webClientHasLocalStorage() ) {
		
			var r = application.configuration.global.repository_name;
		
			this.widgets.storeUserNameCheckBox = new dijit.form.CheckBox({
				'checked'	: (localStorage.getItem('RS_storeUserName::'+r)		== "true"),
			}).placeAt(this._storeUserNameCheckBox_domNode);
			
			this.widgets.storePasswordCheckBox = new dijit.form.CheckBox({
				'checked'	: (localStorage.getItem('RS_storeUserPassword::'+r) == "true"),
			}).placeAt(this._storePasswordCheckBox_domNode);
			
			// set the stored user name as default
			if (localStorage.getItem('RS_storeUserName::'+r) == "true") {
				this.widgets.login_VTB.attr('value', localStorage.getItem('RS_userName::'+r) );
			} // end if
			
			// set the stored password as default
			if (localStorage.getItem('RS_storeUserPassword::'+r) == "true") {
				this.widgets.password_VTB.attr('value', localStorage.getItem('RS_UserPassword::'+r) );
			} // end if 
			
		} else {
			dojo.style( this._storeUserName_TR, 'display', 'none' );
			dojo.style( this._storePassword_TR, 'display', 'none' );
		} // end if 
		
		// insert an empty line
		dojo.create('P',{
			'innerHTML' : '&nbsp;',
		}, this.widgets.form.containerNode);
		
	} // end of method buildRendering
	,
	'startup' : function () {
		this.inherited(arguments);
	
		// trigger the startup of children widgets ...
		this.widgets.BC.startup();
		this.widgets.BC.resize();
	
		// it's time now for the connects ...
		this.connect( this.widgets.loginButton, 'onClick',  '_loginButton_clicked' );
		this.connect( this.widgets.login_VTB,	'onChange', '_checkIfSubmitPermitted' );
		this.connect( this.widgets.password_VTB,'onChange', '_checkIfSubmitPermitted' );
		
		this.connect( this.widgets.localeSelector, 'onChange', '_locale_changed' );
		
		if ( this._webClientHasLocalStorage() ) {
			this.connect( this._storeUserNameLabel_domNode,	'onclick', '_toggle_storeUserNameCheckBox' );
			this.connect( this._storePasswordLabel_domNode,	'onclick', '_toggle_storePasswordCheckBox' );
		} // end if

		// set the focus to the login text box
		this.widgets.login_VTB.focus();
		
		// enable/ disable the Login button
		this._checkIfSubmitPermitted();
	
	} // end of method startup
	,
	'destroy' : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		
		for (var i in this.widgets) {
			if (this.widgets[i].destroyRecursive) this.widgets[i].destroyRecursive(false);
			delete this.widgets[i];
		} // end for .. in
		
		// this.inherited(arguments);
	} // end of method destroy
	,
	
	// internal methods
	/*'_execute' : function (e) {
		this.onExecute();
		this.hide();
	} // end of method _execute
	,*/
	'_loginButton_clicked' : function (e) {
		dojo.stopEvent(e);
		// this.widgets.submitButton.onClick();
		// console.clear();
		// console.log(this.widgets.form.getValues());
		// console.log(dojo.query('INPUT', this.widgets.form.containerNode));
		// dojo.forEach(dojo.query('INPUT', this.widgets.form.containerNode), function(i){
			// console.log(i.name, i.value);
		// },this);
		// return;
		this.widgets.form.submit();
	} // end of method _loginButton_clicked
	,
	'_resizeBC'	: function () {
		this.widgets.BC.resize();
	} // end of method _resizeBC
	,
	'_checkIfSubmitPermitted' : function () {
		var submitPermitted = !this._loginDiabled
								&& this.widgets.login_VTB.isValid()
								&& this.widgets.password_VTB.isValid()
	
		this.widgets.loginButton	.attr('disabled', !submitPermitted);
		this.widgets.submitButton	.attr('disabled', !submitPermitted);
	
		return submitPermitted;
	} // end of method _checkIfSubmitPermitted
	,
	'_toggle_storeUserNameCheckBox' : function (e) {
		dojo.stopEvent(e);
		this.widgets.storeUserNameCheckBox.attr('checked', !this.widgets.storeUserNameCheckBox.attr('checked') );
	} // end of method _toggle_storeUserNameCheckBox
	,
	'_toggle_storePasswordCheckBox' : function (e) {
		dojo.stopEvent(e);
		this.widgets.storePasswordCheckBox.attr('checked', !this.widgets.storePasswordCheckBox.attr('checked') );
	} // end of method _toggle_storeUserNameCheckBox
	,
	'_webClientHasLocalStorage' : function () { // see http://diveintohtml5.info/storage.html
		try {
			return 'localStorage' in window && window['localStorage'] !== null;
		} catch (e) {
			return false;
		} // end try .. catch
	} // end of method _webClientHasLocalStorage
	,
	'_saveOrDelete_userInfoInLocalStorage' : function () {
		
		// user name
		var sU	= this.widgets.storeUserNameCheckBox.attr('checked'),
			sP	= this.widgets.storePasswordCheckBox.attr('checked'),
			r	= application.configuration.global.repository_name;
			
		localStorage.setItem( 'RS_storeUserName::'+r, 		sU);
		localStorage.setItem( 'RS_storeUserPassword::'+r, 	sP);
		
		if (sU ) {
			localStorage.setItem( 'RS_userName::'+r,		this.widgets.login_VTB.attr('value') );
		} else {
			localStorage.removeItem( 'RS_userName::'+r );
		} // end if
		
		// password
		if ( sP ) {
			localStorage.setItem( 'RS_UserPassword::'+r,	this.widgets.password_VTB.attr('value') );
		} else {
			localStorage.removeItem( 'RS_UserPassword::'+r );
		} // end if
	
	} // end of method _saveOrDelete_userInfoInLocalStorage
	,
	'_locale_changed' : function () {
		// force reloading the login dialog and changing the locale
			
		this._saveOrDelete_userInfoInLocalStorage();
		
		if( this._webClientHasLocalStorage() ) {
			var r	= application.configuration.global.repository_name;
			localStorage.setItem( 'RS_locale::'+r,	this.widgets.localeSelector.attr('value') );			
		};
		
		// this.widgets.login_VTB.		attr('value', '');
		// this.widgets.login_VTB.		attr('required',false);
		// this.widgets.password_VTB.	attr('value', '');
		// this.widgets.password_VTB.	attr('required',false);
		
		// set the action to 'changeLocale'
		this.a_widget.set( 'value', 'changeLocale' );
		
		// trigger submit
		this.widgets.form.submit();
		
	} // end of method _locale_changed
	,
	'_onSubmit_triggered' : function () {
	
		// This method is called after a submit has been triggered and before starting the submit.
		// Its return value decides whether the submit is executed (true) or not (false).
	
		// store default settiongs
		if ( this._webClientHasLocalStorage() ) {
			this._saveOrDelete_userInfoInLocalStorage();
		} // end if local storage
		
		// shortcut for changing the locale?
		if (this.a_widget.get('value') == 'changeLocale' ) return true;
	
		// console.log('_onSubmit_triggered');
	
		// normal procedure
		return (this._checkIfSubmitPermitted()) ? true : false;

	} // end of method _onSubmit_triggered
	,
	
	
	
	
	// events
	'onExecute' : function (OT_UUID, newName) {},
	
});	// end of declaration login.widgets.loginDialog
	








dojo.addOnLoad(function(){
	dojo.require("dojo.parser");
	/* ----------------------------------------------------- */
	
	var djConfig = {
		isDebug: false,
		debugAtAllCosts: false
	};

	/* ----------------------------------------------------- */
	
	dojo.parser.parse();
	
	var loginDialog = new login.widgets.loginDialog({});
	
	loginDialog.show();
	
	dojo.addOnLoad(function(){ // this will be executed at last after everything else
		
		loader.hide();
		
	});

});
