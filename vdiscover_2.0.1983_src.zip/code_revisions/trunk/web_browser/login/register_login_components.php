<?php if (!defined('APPLICATION_started')) {header('Location: .');exit;} 
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// this file registers all preloader componentsa
$r->register_mainHTMLFile		('login/application.dojoHTML.php');
$r->register_JavaScriptFile		('common/special_dijit_classes/common.widgets.fixedSizeDialog.js');
$r->register_JavaScriptFile		('login/login.js');
$r->register_cssContent			('
	body, html, #masterBc {
			width:100%; height:100%;
	}
');

?>