<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

if (!defined('APPLICATION_started')) {header('Location: .');exit;}

// Configuration -----------------------------

// AJAX-specific options
define ('AJAX_default_timeout', 0 /* [msec], e.g. 2000 ; the default value is 0 and means "no timeout" */ );

// Application title in HTML
$repository_config['application_version'] 	= '[vDiscover 2.'.$repository_config['subversion_revision'].']';
$repository_config['application_title_HTML']= '&laquo;'.$repository_config['repository_name'].'&raquo;'.' '.$repository_config['application_version'];

// DOJO toolkit version --- packages  are available from http://download.dojotoolkit.org/

// Versioning notation: "major version"."minor version"."bugfix release"



{// set the DOJO toolkit path

	// the following routine takes the first available dojo toolkit path and sets it
	$thirdPartyLibraries = 'third_party_libraries';
	$possibleDojoPaths = array( // put the most important one to the top
		'dojo-release-1.6.2-src',	// works -  there are minor problems with a few bundled language packs of neglible importance
		'dojo-release-1.6.2',		// works
		// 'dojo-release-1.6.1-src',	// ??? stopper bug with Firefox 25
		// 'dojo-release-1.6.1',		// ??? stopper bug with Firefox 25 and there are minor problems with a few bundled language packs of neglible importance
		// 'dojo-release-1.7.1',		// works - but there are still a lot of bugs to be resolved
		// 'dojo-release-1.7.1-src',	// works - but there are still a lot of bugs to be resolved
	);
	// select the first dojo toolkit path as default
	while( list($k,$p) = each( $possibleDojoPaths ) ) {
		if ( @is_dir( __DIR__.DIRECTORY_SEPARATOR.$thirdPartyLibraries.DIRECTORY_SEPARATOR.$p ) ) {
			define ( 'DOJO_TOOLKIT_path', $p );
			break;
		} // end if
	} // end while
	
} // end set dojo toolkit path

// Dojo theme -- see http://o.dojotoolkit.org/book/dojo-book-0-9/part-2-dijit/themes-and-design
$repository_config['DOJO_theme'] = 'soria'; // default soria, alternatives: tundra, nihilo, claro

// End of file --------------------------------
?>