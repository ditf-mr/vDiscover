########################################################################
#                                                                      #
#                          Webpage Icons                               #
#                              by the                                  #
#                        Open Icon Library                             #
#                                                                      #
########################################################################


Description:
	This is a collection of icons created for webpage designers.  It 
includes common icons used by webpages.  It includes icons for social
networking, international flags, and others.  It contains images from 
multiple free/open sources, under various free/open licenses.  This 
means you are free to use for personal or commercial uses, you are free 
to modify and redistribute.  The only requirement is the authors and 
licenses go with files.  See LICENSES_web_icons.txt

Originally created: 20 Jan 2010


