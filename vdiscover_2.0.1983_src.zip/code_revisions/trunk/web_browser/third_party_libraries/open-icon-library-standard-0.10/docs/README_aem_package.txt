#############################################################
#                 AEM Pictorial Database                    #
#############################################################

Description: 
	This package include pictograms from the Association of 
Equipment Manufacturers Pictorial Database, an set of 
industrial standard warning symbols.  They a collection of 
simple pictograms covering many posible injuries cause by 
equipment, to be used as warning symbols.

Package source:	
	Open Icon Library
	http://openiconlibrary.sourceforge.net/

Date:		
	13 Jan 2009

License:	
	Public Domain
	http://en.wikipedia.org/wiki/Public_domain

Original Source:	
	Link: http://www.aem.org/Technical/PictorialDatabase/index.asp
	Aquired: 27 Dec 2009
	Modifications: EPS converted to SVG and PNG by the 
		Open Icon Library

