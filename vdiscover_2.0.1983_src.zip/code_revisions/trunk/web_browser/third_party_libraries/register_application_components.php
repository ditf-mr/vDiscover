<?php if (!defined('APPLICATION_started')) {header('Location: .');exit;} 
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// this file registers all basic dojo componentsa

{// let's start with the DOJO & DIJIT javascript, css and themes
$p='third_party_libraries/'.DOJO_TOOLKIT_path;
$r->register_cssFile($p.'/dijit/themes/'.$repository_config['DOJO_theme'].'/'.$repository_config['DOJO_theme'].'.css');
$r->register_cssFile($p.'/dojox/grid/resources/Grid.css');
$r->register_cssFile($p.'/dojox/grid/enhanced/resources/claro/EnhancedGrid.css');
$r->register_cssFile($p.'/dojox/grid/resources/'.$repository_config['DOJO_theme'].'Grid.css');
$r->register_JavaScriptFile($p.'/dojo/dojo.js');

$r->register_cssContent( '
/* Layout "makeup" to beautify the pretty experience even more ... */

.dijitTabListContainer-top /*.tabStrip-disabled .dijitAlignTop .dijitLayoutContainer*/ {
	margin-left: .5em;
}

.dijitTreeContentExpanded {cursor:pointer;}

.soria .dojoxGridRowOver .dojoxGridCell {
	background-color: rgb(215,255,205);
	color: black;
}

.soria .dijitMenuItem {
    font-family: inherit;
}

/* bugfix */
.soria .dijitPlaceHolder {
    left: 0.5ex;
}

.dojoxGrid {
    font-family: inherit;
}

/* bugfix */
.soria .dijitUpArrowButton .dijitArrowButtonInner {
    background-position: -21px center;
}

.dijitButtonNode .dijitArrowButtonInner {
    margin-right: 1px;
    width: 8px;
}

.dijitVisible {
	width: -moz-available;
}
');

} // end register DOJO & DIJIT

{ // let's register some images for menu bars, etc. as CSS classes
$r->register_cssContent( '
/* image CSS classes */
.RS_icon_enterFullScreen {
	background-image:url(third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/view-fullscreen-5.png);
}

.RS_icon_cancelFullScreen {
	background-image:url(third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/view-nofullscreen-3.png);
}

.RS_icon_RT {
	background-image:url(third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/go-next-7.png);
}

.RS_icon_navigation_node {
	background-image:url(third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/database.png);
}

.RS_icon_OT {
	background-image:url(third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/edit-copy-6.png);
}

.RS_icon_refresh_small {
	background-image:url(third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/arrow-refresh-small.png);
}

.RS_icon_lightning_small {
	background-image:url(third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/lightning.png);
}

.RS_icon_OT_with_children {
	background-image:url(third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/tab-duplicate-3.png);
}

.RS_icon_O {
	background-image:url(third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/apps/accessories-text-editor-3.png);
}

.RS_icon_Edit {
	background-image:url(third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/edit-3.png);
}

.RS_icon_highlight {
	background-image:url(third_party_libraries/misc/billiard-marker-icon/billiard-marker-icon.png);
}

.RS_icon_OkApply {
	background-image:url(third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/dialog-ok-apply-4.png);
}

.RS_icon_Cancel {
	background-image:url(third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/dialog-cancel-4.png);
}

.RS_icon_delete {
	background-image:url(third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/bullet-delete.png);
}

.RS_icon_add {
	background-image:url(third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/bullet-add.png);
}

.RS_icon_returnToMainApplication {
	background-image:url(third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/edit-undo-8.png);
}

.RS_icon_ExitApplication {
	background-image:url(third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/application-exit-2.png);
}

.RS_icon_SendToPrintQueue {
	background-image:url(third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/devices/printer_add.png);
}

.RS_icon_Printer {
	background-image:url(third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/devices/printer-8.png);
}

.RS_icon_SendToPrinter {
	background-image:url(third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/status/printer-printing.png);
}

.RS_icon_Preferences {
	background-image:url(third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/categories/preferences-system-2.png);
}

.RS_icon_User {
	background-image:url(third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/apps/personal-4.png);
}

.RS_icon_Manual {
	background-image:url(third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/categories/applications-office-4.png);
}

.RS_icon_Find {
	background-image:url(third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/system-search-4.png);
}

.RS_icon_EstimateDependencies {
	background-image:url(third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/system-run-5.png);
}

.RS_icon_download {
	background-image:url(third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/emblems/emblem-downloads.png);
}


.RS_icon_go_up {
	background-image:url(third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/go-up-7.png);
}

.RS_icon_go_down {
	background-image:url(third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/go-down-7.png);
}

.RS_icon_go_previous {
	background-image:url(third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/go-previous-7.png);
}

.RS_icon_go_next {
	background-image:url(third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/go-next-7.png);
}

.RS_icon_go_down_green {
	background-image:url(third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/go-down-5.png);
}

.RS_icon_go_up_green {
	background-image:url(third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/go-up-5.png);
}

.RS_icon_mathematics {
	background-image:url(third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/apps/education-mathematics.png);
}

');
} // end register images as CSS

{ // let's register a JavaScript library for generating UUIDs according to RFC4122(v4)
$r->register_JavaScriptFile('third_party_libraries/BROOFA.com_Math.uuid_V1.1.0/Math.uuids.js');

// let's register the dialog for the equation solver
$r->register_dialogHTML('third_party_libraries/Multidimensional_Equation_Solver/solverResults.dialog.dojoHTML.php');


} // end registering JS library for UUIDS
?>