<?php if (!defined('APPLICATION_started')) {header('Location: .');exit;}
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/
?>
 
<div dojoType="dijit.Dialog" id="application.Dialogs.estimationResults" title="Estimation results" 
		onExecute="return true;"
		onCancel="return false;"
		execute="return true;">
	<div class="dijitDialogPaneContentArea small" id="application.Dialogs.estimationResults.contents" style="width:18.46cm;max-height:600px;overflow:auto;">
	</div>
	<div class="dijitDialogPaneActionBar" style="text-align:right;">
		<button dojoType="dijit.form.Button" type="submit" >OK</button>
		<!--<button dojoType="dijit.form.Button" type="button" onClick="dijit.byId('application.Dialogs.estimationResults').onCancel();">Cancel</button>-->
	</div>
</div>