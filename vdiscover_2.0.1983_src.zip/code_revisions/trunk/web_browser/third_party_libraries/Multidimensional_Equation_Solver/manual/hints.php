﻿<?php /*
Retrieval System for Structured Information

The retrieval system for structured information is a ontology-based expert system
with case-based reasoning functionality especially designed for small and medium enterprises.

Copyright (C) 2010  DITF Denkendorf * Körschtalstr. 26 * 73770 Denkendorf * Germany

This program is free software; you can redistribute it and/or modify it under the
terms of the GNU General Public License as published by the Free Software
Foundation; either version 3 of the License, or any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this
program; if not, see <http://www.gnu.org/licenses/>.
*/?>
<h2>Equation solver manual</h2>
<h3>About the equation solver</h3>
<p>
	The equation solver that is being used here is one that bases on the Gauss-Newton algorithm. 
	It carries out non-linear least-square fitting.
</p>
<p>
  Since the algorithm bases on a least square fitter, it can also
  &laquo;solve&raquo; overdefined equation systems with no real solution. <!--For this
  cases the "Remaining error: X" line has been included in the output. -->
</p>
<p>
  It is also possible to use this script for solving underdefined
  quation systems, too. In these cases, any numerically valid solution is
  returned.
 </p>
<h3>Comments</h3>
<p>Single line comments start with a comment sign &laquo;<code>#</code>&raquo; and go until the end of the line.</p>
<p>Multiline comments start with <code>/*</code> and finish with <code>*/</code>.</p>
<p>Example:</p>
<textarea dojoType="dijit.form.Textarea" style="width:100%;" class="code">a:=123 #Comment
#This line is a comment, as well.

A=a*c/2

/* this is a multiline comment
A=sin(alpha)*a*b
*/</textarea> 
 
<h3>Configuration Options</h3>
<h4>Deactivate the close-to-singularity detection</h4>
<p>Inserting the following line deactivates the close-to-singularity detection:</p>
<pre>$tryhard</pre>
<p>In some scenarios the equation solver returns better results with
this option set. But it incrases the solver runtime, as well.</p>

<h4>Tune the Gauss-Newton solver</h4>
<p>Inserting the following line my sometimes help to overcome solution finding problems:</p>
<pre>$scalehack</pre>
<p>Setting this option enables a small hack in the Gauss-Newton
solver that helps finding solutions in equations that are
otherwise problematic with Gauss-Newton solvers (such as
the equation &laquo;<code>pow(x,3)-2*x+2 = 0</code>&raquo;) and speeds up solving of
some equation systems.</p>

<h4>Output independent variables and expressions</h4>
<p>The following line tells the solver to print as well independent variables and expressions:</p>
<pre>$showindep</pre>

<h3>Constants and Variables</h3>

<p>Constant and variable names may be built using the chars &laquo;<code>a-zA-Z0-9_</code>&raquo;.
	Both constant and variable names must start necessarily with an alphabetical char.</p>

<p>Numbers need to be written with a dot &laquo;<code>.</code>&raquo; as decimal separator. Example:</p>
<pre>5.46</pre>
<p>Macros or static constants can be declared using
  the &laquo;<code>:=</code>&raquo; operator, with the name on the left hand side and the term on the right hand side.</p>
<p>Examples:</p>
<textarea dojoType="dijit.form.Textarea" style="width:100%;" class="code">pi:=3.1415926535        # Constant definition
radius:=diameter/2           # Macro
circle_area=pi*radius*radius # Equation</textarea>

<p>If you want to assign a test value to a variable, use the &laquo;<code>:==</code>&raquo; operator, instead.</p>

<h4>Bind attribute values to variables</h4>
<p>Equation systems link variables as quantitatively expressed dependencies.
You may bind the values of numeric attributes to variables by using the following syntax:</p>
<pre>bind variable VAR_NAME to ${ATTRIBUTE_NAME}</pre>
<p><code>VAR_NAME</code> is the name of the variable whereas <code>ATTRIBUTE_NAME</code> is the attribute name. 
Use the menu option &laquo;Insert variable&raquo; to insert these attribute-variable bindings.</p>
Example:
<textarea dojoType="dijit.form.Textarea" style="width:100%;" class="code">bind variable yarn_tex to ${Linear yarn mass}
bind variable yarn_Nm to ${Yarn number}

1000 = yarn_tex * yarn_Nm

yarn_tex:==40
#yarn_Nm:==25</textarea>

<p>
	The &laquo;<code>VAR_NAME :== 123.45</code>&raquo; operator is a test value assignment. 
	When editing the equation system, you may use this assignment for testing the entered equations.
	<code>VAR_NAME</code> needs to be replaced with the corresponding variable name, its values goes to the right hand side of the statment.
</p>


</p>When editing a view of an object for which an equation system is defined, 
you can estimate blank values by clicking in &laquo;Estimate dependent values&raquo;.</p>

  
<h4>Pre-defined constants</h4>
<table class="fullWidth listWithAlternatingRowColour">
	<thead>
		<tr>
			<th>Constant</th>
			<th>Value</th>
			<th>Comments</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td class="code">E</td>
			<td class="code">2.718281828459045</td>
			<td>
				Euler's number
			</td>
		</tr>
		<tr>
			<td class="code">LN2</td>
			<td class="code">0.6931471805599453</td>
			<td>
				Natural logarithm of <code>2</code>
			</td>
		</tr>
		<tr>
			<td class="code">LN10</td>
			<td class="code">2.302585092994046</td>
			<td>
				Natural logarithm of <code>10</code>
			</td>
		</tr>
		<tr>
			<td class="code">E</td>
			<td class="code">2.718281828459045</td>
			<td>
				Euler's number
			</td>
		</tr>
		<tr>
			<td class="code">LOG2E</td>
			<td class="code">2.718281828459045</td>
			<td>
				Base-2 logarithm of <code>E</code>
			</td>
		</tr>
		<tr>
			<td class="code">LOG10E</td>
			<td class="code">0.4342944819032518</td>
			<td>
				Base-10 logarithm of <code>E</code>
			</td>
		</tr>
		<tr>
			<td class="code">PI</td>
			<td class="code">3.141592653589793</td>
			<td>
				&pi;
			</td>
		</tr>
		<tr>
			<td class="code">SQRT1_2</td>
			<td class="code">0.7071067811865476</td>
			<td>Square root of <code>1/2</code></td>
		</tr>
		<tr>
			<td class="code">SQRT2</td>
			<td class="code">1.4142135623730951</td>
			<td>
				Square root of <code>2</code>
			</td>
		</tr>
	</tbody>
</table>
  
<h4>Start values for estimations</h4>
<p>The start value for all variables is <code>1</code>. Another start value can
be defined using special &laquo;<code>?=</code>&raquo; assignations, with the variable name
on the left and a numerical value on the right side.</p>

<h4>Ranges for variable values</h4>
<pre>$range:X:Min:Max</pre>
<p>This command specifies the valid range for the 
fitted variable <code>X</code> so that <code>Min &le; X &le; Max</code>. For open
ranges, just leave the Min or Max field empty.

<h3>Operators</h3>
<p>The following operators are available:</p>
<pre>+ - * /</pre>
<p>Statements may be grouped by braces, e.g.:</p>
<pre>(a+b)*(a-b)</pre>

<h3>Equations</h3>
<p>
Normal equations can entered by using the &laquo;<code>=</code>&raquo; operator. Inequations
  can be written using the &laquo;<code><</code>&raquo; and &laquo;<code>></code>&raquo; operators.
</p>
<p>An equation example:</p>
<pre>sin(x)=0.8</pre>

<h4>The weight command</h4>
<p>The weight command</p>
<pre>$weight:X</pre>
<p>sets the weight for all (in)equations following
this statement to the number <code>X</code>. The default weight is <code>1</code>. A higher weight
for an (in)equation results in a higher impact on the
solution.</p>

<h3>Functions</h3>

<h4>Available functions</h4>
<p>Note that all JavaScript <code>Math.*</code> functions can be used in the
equations, but without the <code>Math.</code> prefix. I.e. &laquo;<code>0.8 = sin(x)</code>&raquo; is
a valid equation.</p>
<p>Here is an overview of all available functions:</p>

<table class="fullWidth listWithAlternatingRowColour">
	<thead>
		<tr>
			<th>Name</th>
			<th>Description</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td class="code">abs(x)</td>
			<td>
				Returns the absolute value of <code>x</code>.
			</td>
		</tr>
		<tr>
			<td class="code">acos(x)</td>
			<td>
				Returns the arccosine value of <code>x</code> in radians.
			</td>
		</tr>
		<tr>
			<td class="code">asin(x)</td>
			<td>
				Returns the arcsine value of <code>x</code> in radians.
			</td>
		</tr>
		<tr>
			<td class="code">atan(x)</td>
			<td>
				Returns the arctangent value of <code>x</code> in radians as a numeric value between -PI/2 and PI/2.
			</td>
		</tr>
		<tr>
			<td class="code">atan2(y,x)</td>
			<td>
				Returns the arctangent value of the quotient of its arguments.
			</td>
		</tr>
		<tr>
			<td class="code">ceil(x)</td>
			<td>
				Returns <code>x</code>, rounded upwards to the nearest integer.
			</td>
		</tr>
		<tr>
			<td class="code">cos(x)</td>
			<td>
				Returns the cosine of <code>x</code>. <code>x</code> needs to be in radians.
			</td>
		</tr>
		<tr>
			<td class="code">exp(x)</td>
			<td>
				Returns the value of <code>E<sup>x</sup></code>.
			</td>
		</tr>
		<tr>
			<td class="code">floor(x)</td>
			<td>
				Returns  <code>x </code>, rounded downwards to the nearest integer.
			</td>
		</tr>
		<tr>
			<td class="code">log(x)</td>
			<td>
					Returns the natural logarithm (base E) of  <code>x</code>.
			</td>
		</tr>
		<tr>
			<td class="code">max(x,y,z,...,n)</td>
			<td>
					Returns the highest value of its arguments.
			</td>
		</tr>
		<tr>
			<td class="code">min(x,y,z,...,n)</td>
			<td>
					Returns the lowest value of its arguments.
			</td>
		</tr>
		<tr>
			<td class="code">pow(x,y)</td>
			<td>
					Returns the value of <code>x</code> to the power of <code>y</code>.
			</td>
		</tr>
		<tr>
			<td class="code">random()</td>
			<td>
				Returns a random number between <code>0</code> and <code>1</code>.
			</td>
		</tr>
		<tr>
			<td class="code">round(x)</td>
			<td>
					Rounds <code>x</code> to the nearest integer.
			</td>
		</tr>
		<tr>
			<td class="code">sin(x)</td>
			<td>
				Returns the sine of <code>x</code> (<code>x</code> is in radians).
			</td>
		</tr>
		<tr>
			<td class="code">sqrt(x)</td>
			<td>
				Returns the square root of <code>x</code>.
			</td>
		</tr>
		<tr>
			<td class="code">tan(x)</td>
			<td>
				Returns the tangent of <code>x</code>.
			</td>
		</tr>
		<!--<tr>
			<td class="code"></td>
			<td>
			</td>
		</tr>-->
	</tbody>
</table>

<h4>Macros</h4>
<p>Macros can be used to write larger equations in a simplified manner.</p>
<p>The <code>:=</code> separates a macro's left hand side from its right hand side. 
	The left hand side needs to be a variable. The right hand side may contain other macros, 
	numbers, variables, functions, but not the variable of the left hand side.
</p>
<p>Examples:</p>
<textarea dojoType="dijit.form.Textarea" style="width:100%;" class="code">pi_2:=PI/2
radians2degrees:=360/2/PI
a:=1/(a+b) // no valid macro</textarea>

<h4>User-defined functions</h4>
<p>The following code example will be translated into a function that can be used in equations:</p>
<textarea dojoType="dijit.form.Textarea" style="width:100%;" class="code">$function:avg(a, b)
return (a+b) / 2;
$endfunction</textarea>

<h3>Code examples</h3>

<h4>Solving non-linear equations</h4>
<textarea dojoType="dijit.form.Textarea" style="width:100%;" class="code">pow(2,x) = pow(y,5)
100*x*y = y+23</textarea>

<h4>Calculating DIN A0 and DIN B0 sheet sizes</h4>
<textarea dojoType="dijit.form.Textarea" style="width:100%;" class="code">A0a * A0b = 1
A0a / A0b = (A0b / 2) / A0a

B0a = 1
B0a / B0b = (B0b / 2) / B0a</textarea>

<h4>Fitting a 3rd order polynom</h4>
<textarea dojoType="dijit.form.Textarea" style="width:100%;" class="code">$function:p3(x, k0, k1, k2, k3)
    return k0 + k1*x + k2*x*x + k3*x*x*x;
$endfunction

p3(10, k0, k1, k2, k3) = 42
p3(30, k0, k1, k2, k3) = 12
p3(15, k0, k1, k2, k3) = 22
p3(5, k0, k1, k2, k3) = 8</textarea>

<h4>DC analysis of a simple voltage divider</h4>
<textarea dojoType="dijit.form.Textarea" style="width:100%;" class="code"># supply networks
vdd := 60
gnd := 0

# ohm's law
u1 = i1 * r1
u2 = i2 * r2
r1 := 470
r2 := 100

# kirchhoff's current and voltage laws
i1 = i2
n1 = gnd + u1
vdd = n1 + u2</textarea>

<h4>Combined serial and parallel resistance synthesis</h4>
<textarea dojoType="dijit.form.Textarea" style="width:100%;" class="code"># Q: What pair of resistors combines to a total resistance of 500
# Ohms in a parallel circuit and 5000 Ohms in a serial circuit?

$function:para(a, b)
  return 1 / (1/a + 1/b);
$endfunction

$function:ser(a, b)
  return a + b;
$endfunction

500 = para(r1, r2)
5000 = ser(r1, r2)

# give r1 a higher initial value to avoid singularity
r1 ?= 2</textarea>

<h4>Calculating the Darcy friction factor using the Colebrook formula</h4>
<textarea dojoType="dijit.form.Textarea" style="width:100%;" class="code">$function:log10(a)
     return log(a) / log(10);
$endfunction

e := 0.001
Re := 1000000
1/sqrt(f) = -2*log10(e/3.71+2.51/(Re*sqrt(f)))

# avoid singularity at f <= 0
$range:f:0.001:</textarea>

<hr/>
<p class="textRight">The equation solver is a third party library from Clifford Wolf. 
	You find the original code <a href="http://svn.clifford.at/tools/trunk/electrotools/eqsolver.html" target="_new">here</a>.</p>