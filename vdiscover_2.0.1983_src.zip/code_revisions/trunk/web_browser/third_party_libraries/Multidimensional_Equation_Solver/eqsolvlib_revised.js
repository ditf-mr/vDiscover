/*
 * eqsolvlib.js - Multidimensional Equation Solver library
 * Copyright (C) 2009  Clifford Wolf <clifford@clifford.at>
 *
 * This program is free software; you can redistribute iterations and/or modify
 * iterations under the terms of the GNU General Public License as published by
 * the Free Software Foundation; eiterationsher version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that iterations will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * See eqsolver.html for usage examples and documentation
 *
 */

// keep in mind: http://sylvester.jcoglan.com/ 



dojo.declare('Matrix',[],{
	dim_x	:	0
	,
	dim_y	:	0
	,
	dat		:	null // array
	,
	constructor : function(d) {
		this.dat = new Array();
		
		// any initial matrix structure passed?
		if (typeof d != 'undefined')
			for (var y=0; y<d.length; y++) for (var x=0; x<d[y].length; x++) 
				this.set(y, x, d[y][x]);
		
	} // end of method constructor
	,
	set : function(pos_y, pos_x, value) {
		// this method sets value on the matrix position pos_y | pos_x

		// Attention: the range of the adderssable positions starts at 0, always.
		//	The dimensions in y and x direction start at 1.
		
		// expand dimensions
		while (pos_y >= this.dim_y) this.dat[this.dim_y++] = new Array();
		if (pos_x >= this.dim_x) 	this.dim_x = pos_x+1;
		
		this.dat[pos_y][pos_x] = value;
	} // end of method set
	,
	get : function(y, x) {
		// this method returns the value at row y and col x
	
		return this.dat[y][x] ? this.dat[y][x] : 0;
	} // end of method get	
	,
	clone : function() {
		
		var ret = new Matrix();
		for (var y=0; y<this.dim_y; y++) for (var x=0; x<this.dim_x; x++)
			ret.set(y, x, this.get(y, x));
		
		return ret;
	}  // end of method clone
	,
	add : function(a) {
	
		// check if a is a matrix, as well
		if(!a || !a.declaredClass || a.declaredClass!="Matrix") throw ""
			+"Matrix.add: The passed parameter is no valid Matrix object.";
	
		// check if matrix dimensions match
		if (this.dim_x != a.dim_x || this.dim_y != a.dim_y) throw ""
			+"Matrix.add: Cannot add matrizes with different sizes:\n"
			+" "+this.dim_x+"x"+this.dim_y+" != "+a.dim_x+"x"+a.dim_y+"";
		
		// create a new Matrix and add the values of this and a
		var ret = new Matrix();
		for (var y=0; y<this.dim_y; y++) for (var x=0; x<this.dim_x; x++)
			ret.set(y, x, this.get(y, x) + a.get(y, x));
			
		return ret;
	}  // end of method add
	,
	smul : function(s) { // scalar multiplication
	
		// check if the passed parameter is a number
		if (typeof s!="number") throw ""
			+"Matrix.smul: the passed parameter is no number.";
	
		// create a new Matrix and carry out a scalar multiplication of this
		var ret = new Matrix();
		for (var y=0; y<this.dim_y; y++) for (var x=0; x<this.dim_x; x++)
			ret.set(y, x, this.get(y, x) * s);

		return ret;
	}  // end of method smul
	,
	mul : function(a) { // matrix multiplication
	
		// check if a is a matrix, as well
		if(!a || !a.declaredClass || a.declaredClass!="Matrix") throw ""
			+"Matrix.mul: The passed parameter is no valid Matrix object.";
	
		// check if matrix dimensions match
		if (this.dim_x != a.dim_y) throw ""
			+"Matrix.mul: Cannot add matrizes with incompatible sizes:\n"
			+" "+this.dim_x+"x"+this.dim_y+" != "+a.dim_x+"x"+a.dim_y+"";
		
		// create a new Matrix and fill it with the multiplied values of this and a
		var ret = new Matrix();
		for (var x=0; x<a.dim_x; x++) for (var y=0; y<this.dim_y; y++) {
			var sum = 0;
			for (var z=0; z<a.dim_y; z++) sum += this.get(y, z) * a.get(z, x);
			ret.set(y, x, sum);
		} // end for
		
		return ret;
	}  // end of method mul
	,
	transpose : function() {
		// this method returns a transposed version of this
		
		// create a new MAtrix and fill it with the transposed values of this
		var ret = new Matrix();
		for (var y=0; y<this.dim_y; y++) for (var x=0; x<this.dim_x; x++) ret.set(x, y, this.get(y, x));
		
		return ret;
	}  // end of method transpose
	,
	gaussJordan : function() {
		// carry out the Gauss-Jordan elimination on this Matrix
	
		var y = 0;
		var ret = this.clone(), warnings=[];
		for (var x = 0; x < ret.dim_x; x++) {
			var pivot_y = y;
			for (var y1 = y+1; y1 < ret.dim_y; y1++) 
				if (Math.abs(ret.get(pivot_y, x)) < Math.abs(ret.get(y1, x))) pivot_y = y1;
				
			if (Math.abs(ret.get(pivot_y, x)) == 0) {
				warnings.push("WARNING: Singularity in Gauss-Jordan elimination in column "+(x+1)+"!");
				
			} else {
				for (var x1 = x; x1 < ret.dim_x; x1++) {
					var temp = ret.get(pivot_y, x1);
					ret.set(pivot_y, x1, ret.get(y, x1));
					ret.set(y, x1, temp);
				}
				var div = ret.get(y, x);
				for (var x1 = x; x1 < ret.dim_x; x1++) 	ret.set(y, x1, ret.get(y, x1) / div);
				for (var y1 = 0; y1 < ret.dim_y; y1++) {
					if (y1 == y) continue;
					for (var x1 = ret.dim_x-1; x1 >= x; x1--)
						ret.set(y1, x1, ret.get(y1, x1) - ret.get(y1, x) * ret.get(y, x1));
				} // end for
				if (++y >= ret.dim_y) break;
			} // end if
			
		} // end for
		
		if(warnings) 	return {'ret':ret, 'warnings':warnings}
			else		return ret;
	}  // end of method gaussJordan
	,
	inv : function() {
		// invert this Matrix
	
		// check if inversion is possible
		if (this.dim_x != this.dim_y) throw ""
			+"Inversion is only possible on a quadratic matrix!\n"
			+"This matrix has the dimensions "+this.dim_x+"x"+this.dim_y+".";
		
		// create a clone of this Matrix and extend it 
		var tmp = this.clone();
		for (var y=0; y<this.dim_y; y++) for (var x=0; x<this.dim_x; x++) 
			tmp.set(y, x+this.dim_x, y == x);
			
		// carry out the inversion via Gauss-Jordan elimination
		var warnings=[];
		tmp = tmp.gaussJordan();
		if(typeof tmp=='object' && tmp.warnings) {
			warnings=tmp.warnings;
			tmp=tmp.ret;
		} // end if
		if(warnings.length) console.warn(warnings);
		
		// copy the relevant parts from the clone matrix to a new one
		var ret = new Matrix();
		for (var y=0; y<this.dim_y; y++) for (var x=0; x<this.dim_x; x++)
			ret.set(y, x, tmp.get(y, x+this.dim_x));
			
		return ret;
	}  // end of method inv
	,
	dump : function() {
		// return this Matrix as a formatted string
	
		var fmtnum = function (x, len) {
			var t;
			var a = Math.abs(x);
			
			if (a < 1000000 && a > 1000) 	t = x.toFixed(0);
			else if (a > 0.0001 || a == 0)  t = x.toFixed(5);
			else 							t = x.toPrecision(4);
			
			while (t.length < len) t =" "+t;
			
			return t;
		} // end of local function definition

		var ret = "";
		// iterate over all rows
		for (var y=0; y<this.dim_y; y++) { 
			
			// decide what to prepend to the row
			if (this.dim_y == 1)		ret += "[";
			else if (y == 0)			ret += "/";
			else if (y == this.dim_y-1)	ret += "\\";
			else						ret += "|";
			
			// iterate over all columns and output the values
			for (var x=0; x<this.dim_x; x++) ret += fmtnum(this.get(y, x), 10);
			
			// decide what to postpend to the row
			if (this.dim_y == 1)		ret += " ]";
			else if (y == 0)			ret += " \\";
			else if (y == this.dim_y-1)	ret += " /";
			else						ret += " |";
			
			// finish the row
			ret +='\n';
			
		} // end for all rows
		
		return ret;
	} // end of method dump
	
}); // end of class declaration Matrix

dojo.declare('EquationSolver',[],{
	constructor : function () {
		this.bindings={
				'attr_var'					:	{},
				'var_attr'					:	{}
			};
		this.ranges 						=	{};
		this.userDefinedFunctions_asParsed	=	{};
		this.userDefinedFunctions			= 	{};
		this.fixedValues					=	{};
		this.macros							=	{};
		this.data							=	{}; // initial values
		this.initialValues					=	{}; // initial values
		this.residualFunctions				=	[];
		this.equations_asParsed				=	[];
		this.equationWeights				=	[];
		this.eqlist							=	[];
		this.variablesInEquations			=	[];
		this.logMessages					=	'';
		this.debugMessages					=	'';
		this.settings = {
				config_scalehack 		:	false,
				config_tryhard			:	false,
				config_showindep		:	false,
				config_weight			:	1,
				config_defaultStartValue: 	1
			};
	} // end of constructor
	,
	logMessages : null
	,
	log : function (l) {this.logMessages+=l+"\n---\n";this.debug(l);}
	,
	debugMessages : null
	,
	debug : function (d) {this.debugMessages+=d+"\n---\n";return d;}
	,
	original_code : ''
	,
	settings: null // object
	,
	parameterise : function (code) {
		this.original_code=code+"\n"; // the additional "\n" prevents later on parsing problems
		this.debug("Parameterising the solver. Code:\n|\t"+code.replace(/[\r\n\v\f]+/g,"\n|\t"));
		
		// reset the loopup tables
		this.macroLookupTable={};
		this.tokenLookupTable={};
		
	} // end of method parameterise
	,
	getCode_withoutBindingsAndTestValues : function () {
		var code = this.original_code;
		code=code.replace(/[\s]*bind variable[^\n]*\n/g,'');
		code=code.replace(/[\s]*([a-zA-Z_][a-zA-Z0-9_]*)[\s]*:==[^\n]*\n/g,'');
		return code;
	} // end of method getCode_withoutBindingsAndTestValues
	,
	parse : function () {
	
		this.debug("Parsing the code.");
	
		if (!this.original_code) throw this.log("EquationSolver.parse: Cannot start parsing because there is no code.");
	
		try {
	
			var code = this.original_code;
		
			var config_weight=this.settings.config_weight;
		
			// eliminate comment areas like /* ...*/ and # ...
			code=code.replace(/\/\*(.|[\r\n])*\*\/|#([^\n]*)/g,'');

			// add an additional new line to the end of the code to prevent parsing problems
			code+='\n';
			
			while (code.match(/([^\n]*)\n/)) {
			
				// get the current line
				var line = RegExp.$1;
								
				// strip the current line from the code
				code = code.replace(/[^\n]*\n/, '');
				
				// strip leading white spaces
				line=line.replace(/^[\s]+/,'');
				
				// are there some variable bindings to be honored?
				var result=line.match(/^[\s]*bind variable[\s]+([a-zA-Z_][a-zA-Z0-9_]*)[\s]+to[\s]+\$\{([^\}]+)\}/);
				if (result) {
					//								varName		attrName
					this.register_varAttrBinding(	result[1],	result[2]);
					continue;
				} // end if variable binding found
				
				// test value assignation?
				var result=line.match(/^[\s]*([a-zA-Z_][a-zA-Z0-9_]*)[\s]*:==[\s]*([-]{0,1}\d*[\.]{0,1}\d*([eE][-]{0,1}\d+){0,1})[\s]*/);
				if (result) {
					//								varName		value
					this.register_fixedValue(		result[1],	parseFloat(result[2]) );
					continue;
				} // end if variable binding found
				
				// eliminate any white spaces and comments from the current line
				line = line.replace(/[ \r\t]|#.*/g, "");
				
				// nothing left ? --> continue with next line
				if (line == "") continue;

				// detect configuration options
				if (line == "$scalehack") 	{ this.settings.config_scalehack = 1; 	continue; }
				if (line == "$tryhard") 	{ this.settings.config_tryhard = 1; 	continue; }
				if (line == "$showindep") 	{ this.settings.config_showindep = 1; 	continue; }

				// detect weight changes
				if (line.match(/^\$weight:([\d\.-Ee]+)$/)) {
					try {
						config_weight = parseFloat(RegExp.$1);
						//with (Math) {config_weight =eval(RegExp.$1);}
					} catch(e) {
						throw ""
							+"Cannot calculate new equation weight "+RegExp.$1+".\n"
							+"Javascript returned :"+e;
					} // end try .. catch
					continue;
				} // end if weight change detected

				// identify ranges for variables
				if (line.match(/^\$range:([a-zA-Z_][a-zA-Z0-9_]*):([\d\.-Ee]*):([\d\.-Ee]*)$/)) {
					//						varName		min						max
					this.register_varRange(	RegExp.$1,	parseFloat(RegExp.$2), 	parseFloat(RegExp.$3));
					continue;
				} // end if range identified

				// identify functions
				if (line.match(/^\$function:([a-zA-Z_][a-zA-Z0-9_]*)\((.*)\)$/)) {
					var fname = RegExp.$1, fargs = RegExp.$2;
					
					// extract the function body ... there has to be a more elegant way than this one ....
					var body = "";
					while (code.match(/[\s]*([^\n]*)\n/)) {
						line = RegExp.$1;
						code = code.replace(/[^\n]*\n/, "");
						if (line.match(/^\$endfunction$/))	break;
						body += line + " ";
					} // end while
									
					this.register_userFunc(fname,fargs,body);
					continue;
				} // end if function identified

				// identify macros
				if (line.match(/^([a-zA-Z][a-zA-Z0-9_]*):=([a-zA-Z0-9_+\-*\/\(\),.]+)$/)) {
					//					varName		expression
					this.register_macro(RegExp.$1, 	RegExp.$2);
					continue;
				} // end if macro identified

				// detect initial values
				if (line.match(/^([a-zA-Z_][a-zA-Z0-9_]*)\?=([\d\.-Ee]+)$/)) {
					//							varName		value
					this.register_initalValue(	RegExp.$1,	parseFloat(RegExp.$2));
					continue;
				} // end if initial value detected

				// if there is anything left, it needs to be an equation ...
				if (line.match(/^([a-zA-Z0-9_+\-*\/(),.]+)(<|>|=)([a-zA-Z0-9_+\-*\/(),.]+)$/)) {
					//							left hand side	right hand side	comparisonOperator	weight
					this.register_equation( 	RegExp.$1, 		RegExp.$3, 		RegExp.$2, 			config_weight );
					continue;
				} // end if equation detected

				// ... or a syntax error
				throw "Syntax Error. Cannot understand this line:\n\""+line+"\"\n";
				 
			} // end while parsing the code
		
			// initialise the user-defined functions, if any
			if (this.userDefinedFunctions_asParsed) this.parseUserDefinedFunctions();
		
		} catch (e) {

			throw this.log('EquationSolver :: parse: Experienced a parser problem:\n\n'+e);
		
		} // end try ... catch
		
		this.debug('Finished parsing, successfully.\n\n');
	} // end of method parse
	,
	bindings : null // object
	,
	register_varAttrBinding : function (varName,attrName) {
		
		this.debug("Registering variable-attribute-binding: \""+varName+"\" <--> \""+attrName+"\"");
		
		// let's test if there is already a binding for the same variable name
		if (this.bindings.attr_var[attrName]) throw this.log(""
			+"EquationSolver:register_varAttrBinding: there is already a registered variable called \""+varName+"\".\n"
			+"The already existing binding: \""+varName+"\" <--> \""+this.bindings.var_attr[varName]+"\"\n"
			+"The new one:				    \""+varName+"\" <--> \""+attrName+"\""
			);
			
		this.bindings.attr_var[attrName]=varName;
		this.bindings.var_attr[varName]=attrName;
	} // end of method register_varAttrBinding
	,
	ranges : null // object
	,
	register_varRange : function (varName,min,max){
	
		this.debug("Registering new variable range restriction \""+varName+"\" is in ["+min+" ... "+max+"]");
		
		// let's test if there is already a variable with the same name
		if (this.ranges[varName]) throw this.log(""
			+"EquationSolver:register_varRange: there is already a var range for \""+varName+"\".\n"
			+"The already existing one: \""+varName+"\" is in ["+this.ranges[varName][0]+" ... "+this.ranges[varName][1]+"]\n"
			+"The new one:				\""+varName+"\" is in ["+min+" ... "+max+"]\n"
			);
			
		this.ranges[varName]=[min,max];
	} // end of method register_varRange
	,
	userDefinedFunctions_asParsed : null // object
	,
	register_userFunc : function (funcName,arguments,body) {
		
		this.debug("Registering new user function \""+funcName+"\".");
		
		// let's test if there is already a macro with the same name
		if (this.userDefinedFunctions_asParsed[funcName]) throw this.log(""
			+"EquationSolver:register_userFunc: there is already a function called \""+funcName+"\".\n"
			);
			
		this.userDefinedFunctions_asParsed[funcName]=[arguments,body];
	} // end of method register_userFunc
	,
	userDefinedFunctions : null // object
	,
	parseUserDefinedFunctions : function () {
		// this method creates an object with all user-defined functions
		
		this.debug("Parsing the user-defined functions.");
		
		if(!Object.keys(this.userDefinedFunctions_asParsed).length) return;
		
		for( var fName in this.userDefinedFunctions_asParsed) {
		
			// locate the body and the arguments
			var fArgs = this.userDefinedFunctions_asParsed[fName][0];
			var fBody = this.userDefinedFunctions_asParsed[fName][1];
		
			// the function arguments need to be valid variable names and ,-separated
			fArgs=fArgs.split(',');
			for (var i in fArgs) {
				var a=fArgs[i].replace(/[\s]+/g,'');
				if (!a.match(/^[a-zA-Z_][a-zA-Z0-9_]*$/)) throw this.log(""
					+"EquationSolver:parseUserDefinedFunctions: Function\""+fName+"("+fArgs+")\":\n"
					+"Syntax error: The function argument \""+a+"\" is no valid variable name."
					);
				
				fArgs[i]=a;
			} // end for each argument
			var fArguments=fArgs.join(',');
		
			// the function body may contain:-
			//	* macros, 
			//	* Math.* functions 
			//	* the listed function argument
			//	* numbers
			
			fBody=dojo.replace(fBody, dojo.hitch(	this,
				function(match, name, offset, templateString) {
					// name is math function?
					if(name in Math) return "Math."+name;
					// name is function argument?
					if(dojo.indexOf(fArgs,name)>-1) return  name;
					// name is macro?
					return this.lookupMacro(name);
			}), /([a-zA-Z_][a-zA-Z0-9_]*|[\d\.-Ee]+)/g);

			var funcAsString="function ("+fArguments+") {\n"+fBody+"\n}\n";
			
			try {
				eval("this.userDefinedFunctions[fName]="+funcAsString+";");
			} catch(e) {
				console.error(e);
				var m = ""
					+"EquationSolver:parseUserDefinedFunctions: Cannot declare the function \""+fName+"\":\n"
					+"Error message: "+e+"\n\n"
					+"Function declaration:\n"+funcAsString+"\n";
				this.log(m);
				throw m;
			} // end try ... catch
			
		} // end for each user-defined function

	} // end of method parseUserDefinedFunctions
	,
	fixedValues : null // object
	,
	register_fixedValue : function (varName, value) {
	
		this.debug("Registering fixed value \""+varName+":=="+value+"\".");
		
		this.fixedValues[varName]=value;
	} // end of method register_fixedValue
	,
	macros : null // object
	,
	register_macro : function(varName,expression) {
	
		this.debug("Registering macro \""+varName+":="+expression+"\".");
		
		// let's test if there is already a macro with the same name
		if (this.macros[varName]) throw this.log(""
			+"EquationSolver:register_macro: there is already a macro called \""+varName+"\".\n"
			+"The already existing one: "+varName+":="+this.macros[varName]+"\n"
			+"The new one:				"+varName+":="+expression
			);
			
		this.macros[varName]=expression;
	
	} // end of method register_macro
	,
	macroLookupTable : null // object
	,
	lookupMacro : function (mName) {
		if (this.macroLookupTable && this.macroLookupTable[mName]) return this.macroLookupTable[mName];
	
		this.debug("Looking for macro \""+mName+"\".");
		
		if (this.macros && (mName in this.macros)) {
			
			var macro = this.macros[mName];
			
			this.debug("Found macro \""+mName+":="+macro+"\". Will replace embedded macros, as necessary.");
			
			// the macro name must not appear in the macro
			if(macro.indexOf(mName)>-1) throw this.log(""
				+"The macro \""+mName+":="+macro+"\" contains its left hand side on its right hand side.\n"
				+"This is not permitted.");
			
			// replace other macros within the macro
			this.macros[mName]="!Recursion!";
			
			var expandedMacro=macro.replace(/[a-zA-Z_][a-zA-Z0-9_]*/g, dojo.hitch(this, "lookupMacro"));
			
			if(expandedMacro.indexOf("!Recursion!")>-1) throw this.log(""
				+"Detected a recursion while expanding the macro \""+mName+":="+macro+"\":\n"
				+"\""+mName+":="+expandedMacro+"\"");

			this.macros[mName]=macro; // maybe it is more efficient to set this to expandedMacro
			
			this.debug("Returning expanded macro \""+mName+":="+expandedMacro+"\".");
			
			return this.macroLookupTable[mName]="("+expandedMacro+")";
		} // end if .. in
		
		this.debug("No expansion found for \""+mName+"\". Returning the token as it is.");		
		
		return this.macroLookupTable[mName]=mName; // no macro
	} // end of method cleanUpMacros
	,
	tokenLookupTable : null // object
	,
	identifyToken : function (token) {
		if (this.tokenLookupTable && this.tokenLookupTable[token]) return this.tokenLookupTable[token];
	
		this.debug ("Identifying token \""+token+"\".");
	
		// is the token a user-defined function?
		if (this.userDefinedFunctions && this.userDefinedFunctions[token]) {
			this.debug("Token \""+token+"\" is a user-defined function.");
			return this.tokenLookupTable[token]="this.userDefinedFunctions."+token;
		} // end if
		
		// is the token a JavaScript Math.* method?
		if (Math[token])	{
			this.debug("Token \""+token+"\" is a JavaScript Math method.");
			return this.tokenLookupTable[token]="Math." + token;
		} // end if
		
		// the token needs to be a variable name
		this.debug("The token \""+token+"\" needs to be a variable name.");
		
		// test if the token is a fixed value
		if (this.fixedValues && this.fixedValues[token]) {
			this.debug("Variable \""+token+"\" has got a fixed value.");
			return this.tokenLookupTable[token]="(/* "+token+":==*/ "+this.fixedValues[token]+")";
		} // end if
		
		// test if the variable is already defined as a start value
		if (token in this.initialValues) {
			this.debug("The variable \""+token+"\" has the initial value "+this.initialValues[token]+" .\n"
				+"Registering the variable with its initial value");
			this.data[token]=this.initialValues[token];
		} else {
			this.debug("There is no initial value for the variable \""+token+"\", yet.\n"
				+"Registering the new variable with the default initial value "+this.settings.config_defaultStartValue+" .");
			this.data[token]=this.settings.config_defaultStartValue;
		} // end if
		
		return this.tokenLookupTable[token]="this.data."+token;
	} // end of method identifyToken
	,
	data : null // object --- current values
	,
	initialValues : null // object --- initial values
	,
	register_initalValue : function(varName,val){
	
		this.debug("Registering the variable \""+varName+"\" with the initial value "+val+" .");
				
		// let's test if there is already a macro with the same name
		if (this.initialValues[varName]) throw this.log(""
			+"EquationSolver:register_initalValue: there is already an intitial value for \""+varName+"\".\n"
			+"The already existing one: "+varName+":="+this.initialValues[varName]+"\n"
			+"The new one:				"+varName+":="+val
			);
			
		this.initialValues[varName]=val;
	} // end of method register_initalValue
	,
	equations_asParsed : null // array
	,
	register_equation : function(leftHandSide, rightHandSide, operator, weight){
	
		this.debug("Registering the equation \""+leftHandSide+operator+rightHandSide+"\" with the weight "+weight+" .");
	
		this.equations_asParsed.push([leftHandSide, rightHandSide, operator, weight]);
	} // end of method register_initalValue
	,
	eqlist : null // array
	,
	equationWeights	: null // array
	,
	variablesInEquations : null // array
	,
	identifyVariablesInEquations : function () {
		
		// task already carried out? --> return
		if(this.variablesInEquations.length) return;
		
		// iterate over all equations and extract the variables in them
		for (var i in this.equations_asParsed) {
			var equation 	= this.equations_asParsed[i][0]+' <=> ' +this.equations_asParsed[i][1];
			
			// expand the macros in the equation
			var eq = equation.replace(/[a-zA-Z_][a-zA-Z0-9_]*/g, dojo.hitch(this, this.lookupMacro));
			
			// identify all variables in the expanded equation
			var token;
			if(!this.variablesInEquations[i]) this.variablesInEquations[i]={};
			var tokens_in_eq = eq.match(/[a-zA-Z_][a-zA-Z0-9_]*/g);
			if (tokens_in_eq) while(token=tokens_in_eq.shift()) {
			
				// token has been added, already?
				if (this.variablesInEquations[i][token]) continue; // ignore it
			
				// token is user-defined function?
				if (Object.keys(this.userDefinedFunctions).length && this.userDefinedFunctions[token]) continue;
				
				// token is Math function?
				if (Math[token]) continue;
				
				// token needs to be a new variable name
				this.variablesInEquations[i][token]=token;
				
			} // end while there are tokens
		} // end for .. in this.equations_asParsed
		
	} // end of method identifyVariablesInEquations
	,
	findDependentVariables : function (varName, parsedEquations) {
		
		// console.log('findDependentVariables',varName,parsedEquations);
		
		if(typeof parsedEquations == "undefined") parsedEquations={};
		
		var dependentVariables = {}, dependentEquations={};
		
		// iterate over all not-parsed equations
		for (var i in this.variablesInEquations) if(!parsedEquations[i]) {
			var equation=this.variablesInEquations[i];
		
			if (equation[varName]) {
				// add all other variables in the equation to the list of found variables
				var newVariables = {};
				for (var variable in equation) {
					if (variable!=varName) {
						newVariables[variable]=equation[variable];
					} // end if
				} // end for .. in
				
				// mark the current equation as parsed
				parsedEquations[i]=i;
				
				// look in all equations that were not parsed yet after dependent variables
					
				// are there still equations that are not parsed, yet?
				if(Object.keys(parsedEquations).length<this.variablesInEquations.length) {
					// iterate over all new variables and have a look if they appear
					for (var nV in newVariables) {
						var r = this.findDependentVariables(nV,parsedEquations);
						
						dojo.mixin(dependentVariables, r.dependentVariables);
						dojo.mixin(dependentEquations, r.dependentEquations);
						
						
					} // end for .. in
					
				} // end if
					
				dependentEquations[i]=i;
				dojo.mixin(dependentVariables, newVariables);
				dependentVariables[varName]=varName;
			} // end if
		
		} // end for .. in
		
		return {
			'dependentVariables': dependentVariables,
			'dependentEquations': dependentEquations
		};
	} // end of method findDependentVariables
	,
	findDependencies : function (attr_UUID) {
	
		var variable = this.bindings.attr_var[attr_UUID];
		
		if(!variable) return {};
	
		var dependentVariables = {};
		var equations = 0;
		
		this.identifyVariablesInEquations();
		var r=this.findDependentVariables(variable);
		var dependentVariables=r.dependentVariables;
		var numEquations=Object.keys(r.dependentEquations).length;
		
		// look up the UUID of all dependent variables and strip variables without UUID
		for(var v in dependentVariables)
			if(this.bindings.var_attr[v]) 	dependentVariables[v]=this.bindings.var_attr[v]
				else						delete dependentVariables[v];
		
		return {
			'dependentVariables' : dependentVariables,
			'numberOfVariables' : Object.keys(dependentVariables).length,
			'numberOfEquations' : numEquations,
			'equations'			: r.dependentEquations
		};
	} // end of method findDependentVariables
	,
	identifyDependencies : function (attr_UUID, currAttributeValues) {
	
		var varName = this.bindings.attr_var[attr_UUID];
		
		if(!varName) return {};
		
		var dependentEquations={}, dependentVariables={};
	
		// identify the variables in the equations
		this.identifyVariablesInEquations();
		
		// get all dependent variables and equations
		var r 					= this.findDependentVariables(varName);
		var dependentVariables 	= r.dependentVariables;
		var equations 			= r.dependentEquations;
		
		for (var i in equations) equations[i] = {
			'vars': 				this.variablesInEquations[i], 
			'solvable': 			null, 
			'dependentVariables': 	null,
			'degreesOfFreedom': 	null
		};
		
		// detect for all variables how many times they appear in the equations
		for (var v in dependentVariables) {
			dependentVariables[v]={
				'numberOfEquations' : 	0, 
				'inEquations':			{}, 
				'problematic':			false,
				'A_UUID':				this.bindings.var_attr[v]
			};
			for (var i in equations) {
				if (equations[i].vars[v]) {
					dependentVariables[v].numberOfEquations++;
					dependentVariables[v].inEquations[i]=i;
				} // end if
			} // end for .. in
		} // end for .. in
		
		// detect for all equations whether they are solvable or not
		// Note: this is carried out incompletely, here ...
		for (var i in equations) {
			var vars=equations[i].vars;
			var num_vars=Object.keys(vars).length;
			var degreesOfFreedom=num_vars;
			for (var v in vars) {
				// look for the value of v
				var A_UUID=this.bindings.var_attr[v];
				var value = null;
				if (		(A_UUID in currAttributeValues) 
						&& 	(typeof currAttributeValues[A_UUID] == 'number')	) 
					degreesOfFreedom--;								
			} // end for .. in
			
			if (degreesOfFreedom==1) {
				equations[i].solvable='solvable';
			} else if (degreesOfFreedom>1) {
				equations[i].solvable='underspecified';
			} else if (degreesOfFreedom<1) {
				equations[i].solvable='overspecified';
			} // end if
			
			equations[i].dependentVariables = num_vars;
			equations[i].degreesOfFreedom 	= degreesOfFreedom;
			
			// mark all variables of unsolvable equations as problematic
			if (equations[i].solvable!='solvable') for (var v in vars) {
				dependentVariables[v].problematic=true;
			} // end for .. in && if
			
		} // end for .. in
		
		// prepare response
		var r={};
		
		if (Object.keys(dependentVariables).length) r.dependentVariables = dependentVariables;
		if (Object.keys(equations).length) 			r.dependentEquations = equations;
		
		return r;
	} // end of method identifyDependencies
	,
	build_residualFunctions : function () {

		this.debug('Converting the equations to residual functions.');

		this.debug('Re-setting the variable vector.');
		
		this.data = {};
		
		this.debug('Re-setting the residual functions.');		
		
		this.eqlist				= [];
		this.equationWeights	= [];
		this.tokenLookupTable	= {};
		
		this.debug('Determining which equations shall be converted.');		
		
		var equations = arguments[0];
		
		if (typeof equations == 'undefined') {
			equations = {};
			for (var i in this.equations_asParsed) {
				equations[i]=i;
			} // end for .. in
		} // end if
		
		this.debug('Will convert '+(Object.keys(equations).length)+' of '+this.equations_asParsed.length+' equations.');
		
		for (var i in /*this.*/equations/*_asParsed*/) {
			var expr1 	= this.equations_asParsed[i][0]; // left hand side
			var expr2 	= this.equations_asParsed[i][1]; // right hand side
			var op 		= this.equations_asParsed[i][2]; // operator, either = or > or <
			var wght 	= this.equations_asParsed[i][3]; // weight
			
			this.debug("Converting the equation \""+expr1+op+expr2+"\" with the weight "+wght+" .\n"
				+"Will expand all macros, then process all tokens.");

			// expand all macros on the left hand side and on the right hand side
			expr1 = expr1.replace(/[a-zA-Z_][a-zA-Z0-9_]*/g, dojo.hitch(this, this.lookupMacro));
			expr2 = expr2.replace(/[a-zA-Z_][a-zA-Z0-9_]*/g, dojo.hitch(this, this.lookupMacro));
			
			// process all tokens and identify variables
			expr1 = expr1.replace(/[a-zA-Z_][a-zA-Z0-9_]*/g, dojo.hitch(this, this.identifyToken));
			expr2 = expr2.replace(/[a-zA-Z_][a-zA-Z0-9_]*/g, dojo.hitch(this, this.identifyToken));

			// build the residual function
			var resFunc;
			
			if 		(op == "=") { resFunc = "function () { return 		  (("+expr1+") - ("+expr2+")   ); }"; }
			else if (op == "<") { resFunc = "function () { return Math.max(("+expr1+") - ("+expr2+"), 0); }"; }
			else if (op == ">") { resFunc = "function () { return Math.min(("+expr1+") - ("+expr2+"), 0); }"; }
			
			this.debug("Residual function:\n\n"+resFunc);
			
			try{
				var eq = '';
				eval('eq='+resFunc);
				// this.eqlist.push(eval(resFunc));
				this.eqlist.push(eq);
				this.equationWeights.push(wght);
			} catch(e) {
				throw this.log(""
					+"EquationSolver:build_residualFunctions: cannot convert the equation\n\n"
					+this.equations_asParsed[i][0]+" "+this.equations_asParsed[i][2]+" "+this.equations_asParsed[i][1]+"\n\n"
					+"to a residual function. The equation seems to contain an error."
					+"The residual function:\n"
					+resFunc+"\n\n"
					+"The JavaScript error message:\n"
					+e
					);
			} // end try ... catch
		} // end for ... in
		
		this.debug('Finished converting the equations to residual functions.');
		
	} // end of method build_residualFunctions
	,
	calculate_residualsVector : function () {
		var r_vec = new Matrix();
		for (var i in this.eqlist) r_vec.set(i, 0, this.equationWeights[i]*dojo.hitch(this, this.eqlist[i])() );
		return r_vec;
	} // end of method calculate_residualsVector
	,
	errVector : null // object
	,
	calculate_error : function () {
		
		var err = 	0, 
			x	=	0;
		for (var i in this.eqlist) {
			this.errVector[i] = x = dojo.hitch(this, this.eqlist[i])();
			err += this.equationWeights[i] * x * x;
		}
		
		return err;
	} // end of function calculate_error
	,
	calculate_jacobiMatrix : function () {	
		var D = new Matrix();
		var x = 0; // matrix direction of variables
		for (var variable in this.data) {
			var y = 0; // matrix direction of equations
			for (var eq_nr in this.eqlist) {
				var last_varValue = this.data[variable];
				
				// 3.4527e-04 = sqrt() of a single prec float machine epsilon (2^-23)
				var delta = Math.abs(last_varValue) < 1e-10 ? 1e-12 : Math.abs(last_varValue * 3.4527e-04);
				this.data[variable] = last_varValue - delta;
				var v1 = dojo.hitch(this, this.eqlist[eq_nr])();
				this.data[variable] = last_varValue + delta;
				var v2 = dojo.hitch(this, this.eqlist[eq_nr])();
				var diff = (v2 - v1) / (2*delta);
				if (!isFinite(diff) || isNaN(diff)) diff = 0;
				this.data[variable] = last_varValue;
				D.set(y, x, diff*this.equationWeights[eq_nr]); // I do not know if it is a good idea to multiply the Jacobi matrix with the weights, here
				
				y++;
			} // end for each equation
			
			x++;
		} // end for each variable
		
		return D;
	}  // end of function calculate_jacobiMatrix	
	,
	remainingError : null // float
	,
	iterations	: null // int
	,
	'outputJacobiMatrix' : function () {
	
		var o='';
		
		o += '<table class="fullWidth compact" style="border:1px solid black !important;">';

			o += '<thead>';
			
				o += '<tr>';
					o += '<th class="textCenter"rowspan="2" style="vertical-align:bottom;">'+Object.keys(this.variablesInEquations).length+' Equations</th>';
					o += '<th class="textCenter" rowspan="2" style="border-left:1px solid black;vertical-align:bottom;">R²</th>';
					
					if (this.fixedValues) 	o += ''
						+'<th colspan="'+Object.keys(this.fixedValues).length	+'" class="textCenter" style="border-left:1px solid black;border-top:1px solid black;">'
							+Object.keys(this.fixedValues).length	+' Constants'
						+'</th>';
					if (this.data)	o += ''
						+'<th colspan="'+Object.keys(this.data).length			+'" class="textCenter" style="border-left:1px solid black;border-top:1px solid black;">'
							+Object.keys(this.data).length			+' Variables'
						+'</th>';
				o += '</tr>';
				
				o += '<tr>';
				
					
					for	(var fV in this.fixedValues) 	o += '<th class="code" style="border-left:1px solid black;border-top:1px solid black;">'+fV+'</th>';
					for	(var iV in this.data) 			o += '<th class="code" style="border-left:1px solid black;border-top:1px solid black;">'+iV+'</th>';
					
				o += '</tr>';		
			
			o += '</thead>';
			
			o += '<tbody>';
			
				for (var eq in this.variablesInEquations) {
			
					var err = this.errVector[eq]*this.errVector[eq],
						bgColor = [200,255,200]; // this should be some green
					
					var minErr = .001,
						maxErr = .01;
					
					if (err >minErr) { // it's time to modify the background color
					
						var maxDiff 	= maxErr-minErr,
							diff 		= Math.min(maxDiff,err)-minErr,
							startColor 	= [255,200,200],
							endColor 	= [255,50,50];
						
						dojo.forEach(startColor,function(vS,i){
							var vE		= endColor[i],
								colDiff	= vE-vS;
						
							bgColor[i]=Math.round(vS+Math.sqrt(diff/maxDiff)/1*colDiff);
						},this);
					
					} // end if
			
					o += '<tr style="background-color:'+(new dojo.Color(bgColor)).toCss()+'">';
					
						o += '<th style="border-top:1px solid black;">';
						
						var eqAsArray = this.equations_asParsed[eq];
						
						o += '<code>'+eqAsArray[0]+' '+eqAsArray[2]+' '+eqAsArray[1]+'</code>';
						
						o += '</th>';
						
						o += '<td class="code" style="border-left:1px solid black;border-top:1px solid black;">'+dojo.number.format(err)+'</td>';
						
						var vars = this.variablesInEquations[eq];
					
						for	(var fV in this.fixedValues)	o += '<td class="textCenter" style="border-left:1px solid black;border-top:1px solid black;">'+(vars[fV]?'&#x25CB;':'&nbsp;')+'</td>';
						for	(var iV in this.data) 			o += '<td class="textCenter" style="border-left:1px solid black;border-top:1px solid black;">'+(vars[iV]?'&#x25CF;':'&nbsp;')+'</td>';
					
					o += '</tr>';
			
				} // end for .. in

			o += '</tbody>';
		
		o += '</table>';
		
		return o;
	} // end of method outputJacobiMatrix
	,
	'solve' : function (equations) {
		// equations : optional parameter that tells whether to restrict equation solving to the selected subset or not
	
		// clear the log
		//this.logMessages	= '';
		//this.debugMessages	= '';
	
		// build the residual functions
		if (this.equations_asParsed.length) this.build_residualFunctions(equations);
				
		this.debug("\n\n Starting with solving the equation system.\n");

		// let's start with equation solving
		var iterations=0;
		this.errVector = {};
				
		// set the solver's start values
		var lastErr = -1;
		var thisErr = this.calculate_error();
		var bestErr = thisErr;
		this.remainingError=-1;
		var bestData = this.data;
		var stallCounter = 0;
		
		this.debug("Starting values:\n"+dojo.toJson(bestData,true));
		
		// let's go solving
		for (iterations=0; iterations < 100 && thisErr != lastErr && thisErr != 0; iterations++) {
			this.debug("**** Gauss-Newton-Solving (iteration "+(iterations+1)+") ****");

			var D = this.calculate_jacobiMatrix();
			this.debug("Jacobi Matrix:\n"+D.dump()+"\n");
			
			// abort if there is nothing to do
			if (iterations == 0 && D.dim_x==0 && D.dim_y==0) {
				this.log('There are no variables to be identified. Aborting.');
				break;
			} // end if

			var r = this.calculate_residualsVector();
			this.debug("Residuals Vector:\n"+r.dump()+"\n");

			if (iterations == 0 && D.dim_y < D.dim_x) this.log("WARNING: the equation system seems to be underdefined.");

			var Dt = D.transpose();
			var aoff = Dt.mul(D).inv().mul(Dt).mul(r);
			this.debug("Offset Vector:\n"+aoff.dump()+"\n");

			var y = 0;
			var old_data = this.data;
			this.data = new Object();
			for (var id in old_data) {
				this.data[id] = old_data[id] - aoff.get(y++, 0);
				if (id in this.ranges) {
					if (this.ranges[id][0] != "" && this.data[id] < +this.ranges[id][0]) {
						this.debug("Applying lower border condition to variable \""+id+"\". Setting its value from "+this.data[id]+" to "+this.ranges[id][0]+".");
						this.data[id] = +this.ranges[id][0];
					} // end if
					if (this.ranges[id][1] != "" && this.data[id] > +this.ranges[id][1]) {
						this.debug("Applying upper border condition to variable \""+id+"\". Setting its value from "+this.data[id]+" to "+this.ranges[id][1]+".");
						this.data[id] = +this.ranges[id][1];
					} // end if
				} // end if variable has a range restriction
			} // end for each variable
			
			this.debug("New values:\n"+dojo.toJson(this.data,true));

			lastErr = thisErr;
			thisErr = this.calculate_error();

			if (this.settings.config_scalehack && lastErr > 0 && thisErr > 0 && thisErr*2 > lastErr) {
			
				this.debug("Insufficient improvement in square error. Trying scaling hack.");
				
				var scaleValues = [ -100, -10, -1, -0.1, 0, 0.1, 0.15, 0.22, 0.33, 0.47, 0.68,
									1.0, 1.5, 2.2, 3.3, 4.7, 6.8, 10, 15, 22, 33, 47, 68, 100 ];
				var bestErr = thisErr;
				var bestScaleIdx = -1;
				this.data = new Object();
				for (i in scaleValues) {
					var y = 0;
					if (this.settings.config_tryhard && scaleValues[i] == 0) continue;
					for (var id in old_data) this.data[id] = old_data[id] - aoff.get(y++, 0)*scaleValues[i];
					thisErr = this.calculate_error();
					if (thisErr < bestErr) {
						bestErr = thisErr;
						bestScaleIdx = i;
						this.debug("Scaling by "+scaleValues[bestScaleIdx]+" leads to the reduced square error "+thisErr+" .");
					} // end if error improvement
				}
				var finalScale = 1;
				if (bestScaleIdx >= 0) {
					finalScale = scaleValues[bestScaleIdx];
					this.debug("Using scaling factor "+scaleValues[bestScaleIdx].toFixed(1)+".\nNew square error: "+thisErr+" .");
				} else {
					this.debug("\nNo improvement from scaling hack.\n");
				}
				
				var y = 0;
				for (var id in old_data) {
					this.data[id] = old_data[id] - aoff.get(y++, 0)*finalScale;
				}
				thisErr = this.calculate_error();
				this.debug("New values after the scaling hack:\n"+dojo.toJson(this.data,true));
			} // end if scaleHack is turned on

			
			if (!this.settings.config_tryhard && lastErr > 0 && thisErr > 0 && thisErr*1.0001 > bestErr) {
				if (++stallCounter < 5) {
					this.debug("Trying hard. Improvement in square error is minimal ("+stallCounter+"/5).");
				} else {
					this.debug("Trying hard. Improvement in square error stays minimal. Aborting.");
					break; // stop iterating
				}
			} else stallCounter = 0;

			if (bestErr > thisErr) {
				bestData = this.data;
				bestErr = thisErr;
			} // end if
		} // end iterating

		// store the results
		this.data 			= bestData;
		this.remainingError	= bestErr;
		this.iterations 	= iterations;
		
		this.log("Finished solving the equation system. Results:\n"
			+"Variables:\n"+dojo.toJson(this.data,true)+"\n"
			+"Remaining error: "+Math.sqrt(this.remainingError)+"\n"
			+"Iterations: "+iterations);
		
		
		// prepare the output
		var ret = {
			data 			: this.data,
			func 			: this.userDefinedFunctions_asParsed,
			remainingError 	: this.remainingError,//Math.sqrt(this.remainingError),
			iterations		: this.iterations,
			numEquations	: Object.keys(this.variablesInEquations).length,
			numVariables	: Object.keys(this.data).length
		
		};
			
		// calculate all macros and append them to the results
		if(this.settings.config_showindep) {
			ret.alldata=ret.data;
			for (var id in this.macros) {
				var m = this.macros[id];
				m = m.replace(/[a-zA-Z_][\w]*/g, dojo.hitch(this, "lookupMacro"));
				m = m.replace(/[a-zA-Z_][\w]*/g, this.identifyToken);
				
				ret.alldata[id] = dojo.hitch(ret, function(expr){return eval(expr);})(m);
			} // end for all macros
			this.log("Variable and macro values:\n"+dojo.toJson(ret.alldata,true));
		} // end if
		
		// if there are attr-variable bindings: assign to the AV_UUIDs the corresponding new values
		if(this.bindings.var_attr) {
			ret.oldAttrValues = this.attrVarList;
			ret.newAttrValues = {};
			
			var varName;
			for (varName in ret.data) {
				var value = ret.data[varName];
				
				// lookup the AV_UUID
				var AV_UUID = this.bindings.var_attr[varName];
				
				if (AV_UUID) ret.newAttrValues[AV_UUID]=value;
			} // end for .. in
			
		} // end if there are attr-var-bindings
		
		var jacobiMatrix = this.outputJacobiMatrix();
		
		ret.jacobiMatrix 	= jacobiMatrix;
		ret.log				= this.logMessages;
		ret.debug			= this.debugMessages;
		
		return ret;
	} // end of method solve
	,
	set_attributeValues : function (attrVarList) {
		// attrVarList needs to be an object with the attribute UUIDs as key and the value as slot
		// empty values need to be "", not 0!

		this.log("Integrating new attribute values into the equation system.");
		
		this.attrVarList=attrVarList;
		
		// iterate over all passed attribute-variable bindings
		// var AV_UUID;
		for (var AV_UUID in attrVarList) {
		
			// locate the variable that belongs to AV_UUID
			var varName=this.bindings.attr_var[AV_UUID];

			this.debug("Integrating the value of the attribute \""+AV_UUID+"\".");
			
			if(varName) {
				
				this.debug("Identified the variable binding \""+varName+"\" for attribute \""+AV_UUID+"\".");				
				
				// delete the start value, if it exists
				if(this.data[varName]) {
					this.debug(varName+": Deleting existing start value.");
					delete this.data[varName];
				} // end if

				// delete the fixed value, if it exists
				if(this.fixedValues[varName]) {
					this.debug(varName+": Deleting existing fixed value.");
					delete this.fixedValues[varName];
				} // end if
				
				// delete the macro, if it exists
				if(this.macros[varName]) {
					this.debug(varName+": Deleting existing macro \""+this.macros[varName]+"\".");
					delete this.macros[varName];
				} // end if
				
				// locate the value
				var keepConstant= attrVarList[AV_UUID].keepConstant,
					value		= attrVarList[AV_UUID].value;
				
				// it it is not empty: set the variable as a fixed value or as an initial value
				if (value!=="") {
				
					if (keepConstant) {
						this.debug(varName+": Setting the passed value "+value+" as a fixed value.");
						this.register_fixedValue(varName, parseFloat(value) );
					} else {
						this.debug(varName+": Setting the passed value "+value+" as an initial value.");
						this.register_initalValue(varName, parseFloat(value) );
					} // end if				
				
				} // end if
			} else {
			
				this.debug("No variable binding for attribute \""+AV_UUID+"\" found.");
				
			} // end if there is a variable in the equation system
			
		} // end for each passed variable	
	
	} // end of method set_attributeValues
});
