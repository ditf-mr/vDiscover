<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # check if application is started correctly
		if ( ! defined('APPLICATION_started') or ! $repository_config ) {
			header('Location: ../../../..');
			exit;
		}
	}

	{ # start http output 
		header('Content-type: application/json');
	}

	try { 
	
		# user permission are validated either in each task or in the backend functions 
		
		{ # identify the task 
			$task = sanitize_string($_POST, 'task', $_GET);
			switch ( $task ) { 
			
				case 'add_RT': # -------------------------------------------------------------------
					{ # create a new relation type
						include('RelationType.json/add_RT.inc.php');
						break;
					}
					
				case 'may_deleteRT': # -------------------------------------------------------------
					{ # checks if the relation type may be deleted.
						include('RelationType.json/may_deleteRT.inc.php');
						break;
					}
					
				case 'delete_RT': # ----------------------------------------------------------------
					{ # delete the relation type. 
						include('RelationType.json/delete_RT.inc.php');
						break;
					}
					
				case 'get_RT_name': # --------------------------------------------------------------
					{ # get (read) the name of a relation type 
						include('RelationType.json/get_RT_name.inc.php');
						break;
					}
					
				case 'set_RT_name': # --------------------------------------------------------------
					{ # set (save) the name of the relation type
						include('RelationType.json/set_RT_name.inc.php');
						break;
					}
					
				case 'get_RT_nameOfInverse': # -----------------------------------------------------
					{ # get (read) the nameOfInverse of a relation type 
						include('RelationType.json/get_RT_nameOfInverse.inc.php');
						break;
					}
					
				case 'set_RT_nameOfInverse': # -----------------------------------------------------
					{ # set (save) the nameOfInverse of the relation type
						include('RelationType.json/set_RT_nameOfInverse.inc.php');
						break;
					}
					
				case 'get_RT_names': # -------------------------------------------------------------
					{ # get (read) the name and the nameOfInverse of a relation type 
						include('RelationType.json/get_RT_names.inc.php');
						break;
					}
					
				case 'set_RT_names': # -------------------------------------------------------------
					{ # set (save) the name and the nameOfInverse of the relation type
						include('RelationType.json/set_RT_names.inc.php');
						break;
					}
					
				case 'get_RT_description': # -------------------------------------------------------
					{ # get (read) the description of a relation type 
						include('RelationType.json/get_RT_description.inc.php');
						break;
					}
					
				case 'get_RT_descriptionPlain': # --------------------------------------------------
					{ # get (read) the plain version of the description of a relation type 
						include('RelationType.json/get_RT_descriptionPlain.inc.php');
						break;
					}
					
				case 'set_RT_description': # -------------------------------------------------------
					{ # set (save) the description of the relation type
						include('RelationType.json/set_RT_description.inc.php');
						break;
					}
					
				case 'get_RT_cardinality': # -------------------------------------------------------
					{ # get (read) the cardinality of a relation type 
						include('RelationType.json/get_RT_cardinality.inc.php');
						break;
					}
					
				case 'set_RT_cardinality': # -------------------------------------------------------
					{ # set (save) the cardinality of a relation type
						include('RelationType.json/set_RT_cardinality.inc.php');
						break;
					}
					
				case 'get_RT_attributes': # --------------------------------------------------------
					{ # return the list of attributes of the relation type
						include('RelationType.json/get_RT_attributes.inc.php');
						break;
					}
					
				case 'set_RT_attributes': # --------------------------------------------------------
					{ # set the attributes of the relation type, that means add new ones, delete
					  # those, that are not longer needed and change some if neccessary.
						include('RelationType.json/set_RT_attributes.inc.php');
						break;
					}
					
				case 'get4_renameRT': # --------------------------------------------------------------
					{ # get (read) the information needed for the dialogue 'renameRT'  
						include('RelationType.json/get4_renameRT.inc.php');
						break;
					}
					
				default:
					throw new Exception('The passed task is not implemented.');
			} # end-of-switch
		}
	} 
	catch (Exception $e) {
		header('HTTP/1.1 500 Internal Server Error');
		echo 
			json_encode(
				array(
					'type'		=> 'Exception',
					'message'	=> $e->getMessage(),
					'code'		=> $e->getCode(),
					'file'		=> $e->getFile(),
					'line'		=> $e->getLine(),
					'trace'		=> $e->getTraceAsString()
				)
			);
	} # end-of-trycatch


?>