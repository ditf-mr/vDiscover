<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # check if application is started correctly
		if ( ! defined('APPLICATION_started') or ! $repository_config ) {
			header('Location: ../../../..');
			exit;
		}
	}
	
	{ # start http output 
		header('Content-type: application/json');
	}
	
	try { 

		# user permission are validated either in each task or in the backend functions 
		
		{ # identify the task 
			$task = sanitize_string($_POST, 'task', $_GET);
			switch ( $task ) { 
			
				case 'add_rootOT': # ---------------------------------------------------------------
					{ # create an new object type on root level
# nur wenn session['user_adminPermission']	, sonst access denied throw new Exception('The passed task is not implemented.');
						include('ObjectType.json/add_rootOT.inc.php');
						break;
					}
					
				case 'get_NavigationTree': # -------------------------------------------------------
					{ # return the list of all object types for the current user (else). If 
					  # parameter 'withChildrenSlot'=1 then with 'children' slot.
						include('ObjectType.json/get_NavigationTree.inc.php');
						break;
					}
					
				case 'add_OT': # -------------------------------------------------------------------
					{ # create a new object type
						include('ObjectType.json/add_OT.inc.php');
						break;
					}
					
				case 'may_deleteOT': # -------------------------------------------------------------
					{ # checks if the object type may be deleted.
						include('ObjectType.json/may_deleteOT.inc.php');
						break;
					}
					
				case 'duplicate_OT': # -------------------------------------------------------------
					{ # duplicates an object type
						include('ObjectType.json/duplicate_OT.inc.php');
						break;
					}
					
				case 'delete_OT': # ----------------------------------------------------------------
					{ # delete the object type. If withSubs=true the whole object type hierarchy
					  # starting in the given object type, will be deleted.
						include('ObjectType.json/delete_OT.inc.php');
						break;
					}
					
				case 'get_OT': # -------------------------------------------------------------------
					{ # get (read) all items of an object type
						include('ObjectType.json/get_OT.inc.php');
						break;
					}
					
				case 'get_OT_name': # --------------------------------------------------------------
					{ # get (read) the name of an object type 
						include('ObjectType.json/get_OT_name.inc.php');
						break;
					}
					
				case 'set_OT_name': # --------------------------------------------------------------
					{ # set (save) the name of the object type
						include('ObjectType.json/set_OT_name.inc.php');
						break;
					}
					
				case 'move_OT': # ------------------------------------------------------------------
					{ # move an object type in the object type tree to another parent object type
						include('ObjectType.json/move_OT.inc.php');
						break;
					}
					
				case 'get_OT_description': # -------------------------------------------------------
					{ # get (read) the description of an object type 
						include('ObjectType.json/get_OT_description.inc.php');
						break;
					}
					
				case 'get_OT_descriptionPlain': # --------------------------------------------------
					{ # get (read) the plain version of the description of an object type 
						include('ObjectType.json/get_OT_descriptionPlain.inc.php');
						break;
					}
					
				case 'set_OT_description': # -------------------------------------------------------
					{ # set (save) the description of an object type
						include('ObjectType.json/set_OT_description.inc.php');
						break;
					}
					
				case 'get_OT_attributes': # --------------------------------------------------------
					{ # return the list of attributes of the object type
						include('ObjectType.json/get_OT_attributes.inc.php');
						break;
					}
					
				case 'set_OT_attributes': # --------------------------------------------------------
					{ # set the attributes of the object type, that means add new ones, delete 
					  # those, that are not longer needed and change some if neccessary.
						include('ObjectType.json/set_OT_attributes.inc.php');
						break;
					}
					
				case 'get_OT_attributeTags': # --------------------------------------------------------
					{ # return the list of attributes of the object type
						include('ObjectType.json/get_OT_attributeTags.inc.php');
						break;
					}
					
				case 'set_OT_attributeTags': # --------------------------------------------------------
					{ # set the attributes of the object type, that means add new ones, delete 
					  # those, that are not longer needed and change some if neccessary.
						include('ObjectType.json/set_OT_attributeTags.inc.php');
						break;
					}
					
				case 'get_OT_dependencyConfiguratorInputs': # --------------------------------------
					{ # returns dependencies for objects of a type
						include('ObjectType.json/get_OT_dependencyConfiguratorInputs.inc.php');
						break;
					}
				
				case 'set_OT_dependencies': # ------------------------------------------------------
					{ # stores dependencies for objects of a type
						include('ObjectType.json/set_OT_dependencies.inc.php');
						break;
					}
				
				case 'get_OT_viewTypes': # ---------------------------------------------------------
					{ # return the list of view types of the object type
						include('ObjectType.json/get_OT_viewTypes.inc.php');
						break;
					}
				
				case 'set_OT_viewTypes': # ---------------------------------------------------------
					{ # set the view types of the object type, that means add new one, delete those,
					  # that are not longer needed and change some if neccssary.
						include('ObjectType.json/set_OT_viewTypes.inc.php');
						break;
					}
					
				case 'get_OT_viewTypesByKind': # ---------------------------------------------------
					{ # return the list of view types of the object type
						include('ObjectType.json/get_OT_viewTypesByKind.inc.php');
						break;
					}
					
				case 'get_OT_viewTypesAllowed4NameTemplate': # -------------------------------------
					{ # return the list of view types that may be used as name template of an
					  # object type
						include('ObjectType.json/get_OT_viewTypesAllowed4NameTemplate.inc.php');
						break;
					}
					
				case 'get_OT_viewTypesAllowed4DescriptionTemplate': # ------------------------------
					{ # return the list of view types that may be used as description template of 
					  # an object type
						include('ObjectType.json/get_OT_viewTypesAllowed4DescriptionTemplate.inc.php');
						break;
					}
					
				case 'usesTemplateViewForObjectName': # --------------------------------------------
					{ # return true, if a template view for names of objects is specified, false, 
					  # if not.
						include('ObjectType.json/usesTemplateViewForObjectName.inc.php');
						break;
					}
					
				case 'get_OT_templateViewType_UUIDs': # --------------------------------------------
					{ # return the view types of those view types, which are used to display name 
					  # and description of the object of the corresponding object type.
						include('ObjectType.json/get_OT_templateViewType_UUIDs.inc.php');
						break;
					}
					
				case 'set_OT_templateViewType_UUIDs': # --------------------------------------------
					{ # set the view types of those view types, which are used to display name and 
					  # description of the object of the corresponding object type.
						include('ObjectType.json/set_OT_templateViewType_UUIDs.inc.php');
						break;
					}
					
				case 'get_OT_menuBarOT': # ---------------------------------------------------------
					{ # get the menu bar on object type level (a list of all menu items) for the 
					  # selected object type.
						include('ObjectType.json/get_OT_menuBarOT.inc.php');
						break;
					}
					
				case 'set_OT_menuBarOT': # ---------------------------------------------------------
					{ # store modifications of the menu bar on object type level and create/ delete 
					  # unnecessary items.
						include('ObjectType.json/set_OT_menuBarOT.inc.php');
						break;
					}
					
				case 'get_OT_menuBarO': # ----------------------------------------------------------
					{ # get the menu bar on object level (a list of all menu items) for the selected 
					  # object type.
						include('ObjectType.json/get_OT_menuBarO.inc.php');
						break;
					}
					
				case 'set_OT_menuBarO': # ----------------------------------------------------------
					{ # store modifications of the menu bar on object type level and create/ delete 
					  # unnecessary items
						include('ObjectType.json/set_OT_menuBarO.inc.php');
						break;
					}
					
				case 'get_OT_menuBars': # ----------------------------------------------------------
					{ # get both the menu bar for objects and the menu bar for types 
					  # object type.
						include('ObjectType.json/get_OT_menuBars.inc.php');
						break;
					}
					
				case 'get_Os': # -------------------------------------------------------------------
					{ # return the list of all objects of the object type in a simple form.
					  # (see also task "get_Os_4_OT_show_all_io" below.
						include('ObjectType.json/get_Os.inc.php');
						break;
					}
					
				case 'add_O': # --------------------------------------------------------------------
					{ # create a new object
						include('ObjectType.json/add_O.inc.php');
						break;
					}
					
				case 'get_OT_objectAccessPermissions': # --------------------------------------------------------------------
					{ # create a new object
						include('ObjectType.json/get_OT_objectAccessPermissions.inc.php');
						break;
					}
					
				case 'get_OT_relationTypes_asStart': # ---------------------------------------------
					{ # return the list of relation types that start at the object type
						include('ObjectType.json/get_OT_relationTypes_asStart.inc.php');
						break;
					}
					
				case 'get_OT_attributes_of_OT_at_RT_end': # ----------------------------------------
					{ # return the list of attributes of the object type at the end of a relation 
					  # type.
						include('ObjectType.json/get_OT_attributes_of_OT_at_RT_end.inc.php');
						break;
					}
					
				case 'get_OT_viewTypes_of_OT_at_RT_end': # -----------------------------------------
					{ # return the list of viewTypes of the object type at the end of a relation 
					  # type.
						include('ObjectType.json/get_OT_viewTypes_of_OT_at_RT_end.inc.php');
						break;
					}
					
				case 'get_Os_by_name': # ----------------------------------------------------------
					{ # search all object that match the pattern and belong to the given object type
					  # or one of its sub object classes.
						include('ObjectType.json/get_Os_by_name.inc.php');
						break;
					}
					
				case 'searchObjectsBy_nameOrDescription': # --------------------------------------
					{ # search all objects that match the pattern and belong to the given object 
					  # type or one of its sub object classes. 
					  # - Search is done in name and description.
					  # - Parameter 'searchDomain' maybe empty (search in all cObjectTypes
					  #   or an OT_UUID. 
						include('ObjectType.json/searchObjectsBy_nameOrDescription.inc.php');
						break;
					}

				case 'retrieveObjectsBy_attributeValues': # ----------------------------------------
					{ # processes a query, that means searchs for objects of either the given 
					  # object type or one of its sub object types matching the given attribute
					  # values.
						include('ObjectType.json/retrieveObjectsBy_attributeValues.inc.php');
						break;
					}					
				
				case 'get_numberOfObjects_4_OT_show_all_io': # -------------------------------------
					{ # return the list of all objects of the object type
						include('ObjectType.json/get_numberOfObjects_4_OT_show_all_io.inc.php');
						break;
					}
				
				case 'get_Os_4_OT_show_all_io': # --------------------------------------------------
					{ # return the list of all objects of the object type
						include('ObjectType.json/get_Os_4_OT_show_all_io.inc.php');
						break;
					}
				
				case 'get_Os_4_OT_show_all_io_REST': # ---------------------------------------------
					{ # return the list of all objects of the object type 
						include('Object.json/get_O_view2_functions.inc.php');
						include('ObjectType.json/get_Os_4_OT_show_all_io_REST.inc.php');
						break;
					}
				
				case 'get_OT_4_setOTTemplates': # --------------------------------------------------
					{ # return all data needed to process the dialogue 'setOTTemplates'.
						include('ObjectType.json/get_OT_4_setOTTemplates.inc.php');
						break;
					}
					
				case 'save_OT_retrievalQuery': # ---------------------------------------------------
					{ # saves 1 retrievalQuery of the object type.
						include('ObjectType.json/save_OT_retrievalQuery.inc.php');
						break;
					}
				
				case 'get_OT_retrievalQueries': # --------------------------------------------------
					{ # returns the list of retrieval queries of the object type
						include('ObjectType.json/get_OT_retrievalQueries.inc.php');
						break;
					}
				
				case 'get_OT_retrievalQuery': # ----------------------------------------------------
					{ # returns a retrieval queries of the object type
						include('ObjectType.json/get_OT_retrievalQuery.inc.php');
						break;	
					}
				
				case 'dialogue_statisticData_get': # -----------------------------------------------
					{ # returns all data, need to fill the dialogue statisticData
						include('ObjectType.json/dialogue_statisticData_get.inc.php');
						break;	
					}
					
				case 'dialogue_statisticData_set': # -----------------------------------------------
					{ # creates a list of objects according to the specification in the parameters.
						include('ObjectType.json/dialogue_statisticData_set.inc.php');
						break;	
					}
				
				case 'deleteObjects': # ------------------------------------------------------------
					{ # deletes (mark as deleted) some or all objects of an object type
						include('ObjectType.json/deleteObjects.inc.php');
						break;	
					}
					
				case 'prepareExportOfObjectSet': # -------------------------------------------------
					{ # generate a file on the server containing some objects of an object type
					  # in the specified format (csv, xlsx, ...) and return a access code for
					  # this file, that is valid for 12 hours 
						include('Object.json/get_O_view2_functions.inc.php');
						include('ObjectType.json/prepareExportOfObjectSet.inc.php');
						break;	
					}
				
				case 'set_findQuery': 
				case 'save_OT_findList': # -------------------------------------------------------------
					{ # create or update an existing find query 
						include('ObjectType.json/save_OT_findList.inc.php');
						break;	
					}
					
				case 'get_findQueries':
				case 'get_OT_findLists': # -----------------------------------------------------------
					{ # get a list of all existing find list for a given OT_UUID 
						include('ObjectType.json/get_OT_findLists.inc.php');
						break;	
					}
					
				case 'get_findQuery':
				case 'get_OT_findList': # -------------------------------------------------------------
					{ # get a specific find list 
						include('ObjectType.json/get_OT_findList.inc.php');
						break;	
					}
					
				case 'delete_findQuery':
				case 'delete_OT_findList': # ----------------------------------------------------------
					{ # delete a specific find list 
						include('ObjectType.json/delete_OT_findList.inc.php');
						break;	
					}
					
				default: # -------------------------------------------------------------------------
					throw new Exception('The passed task is not implemented.');
					
			} # end-of-switch
		}
	} 
	catch ( Exception $e ) {
		header('HTTP/1.1 500 Internal Server Error');
		$GLOBALS['logHandler']->debug($e);
		echo 
			json_encode( 
				array(
					'type'		=> 'Exception',
					'message'	=> $e->getMessage(),
					'code'		=> $e->getCode(),
					'file'		=> $e->getFile(),
					'line'		=> $e->getLine(),
					'trace'		=> $e->getTraceAsString()
				)
			);
	} # end-of-trycatch


# ==================================================================================================
# helpers
# ==================================================================================================


// function __makeMenuBarLinear ( $menuBarHierarchical ) {
	// /** Convert the hierachical menu bar into the linear structure
	 // * @param $menuHierarchical array. The menu bar in the internal hierarchical form.
	 // * @return array. The menu bar in a linear format.
	 // */
	// $menuBarLinear = array();
	// foreach($menuBarHierarchical as $menuItem) {
		// $menuBarItemLinear = array();
		// { # copy all slots of the menuItem except 'children' slot
			// foreach($menuItem as $key => $value)
				// if ($key != 'children')
					// $menuBarItemLinear[$key] = $value;
		// }
		// { # add menuBarItemLinear to $menuBarLinear
			// $menuBarLinear[] = $menuBarItemLinear;
		// }
		// { # if menuItem is popupMenu add children 
			// if (($menuItem['type'] == 'dijit.PopupMenuBarItem') 
			// and (is_array($menuItem['children']))) {
				// foreach($menuItem['children'] as $childMenuItem) {
					// $childMenuItem['parent_UUID'] = $menuItem['UUID'];
					// $menuBarLinear[] = $childMenuItem;
				// }
			// }
		// }
	// }
	// return $menuBarLinear;
// } # end-of-function __makeMenuBarLinear


// function __makeMenuBarHierarchical ( $menuBarLinear ) {
// } # end-of-function __makeMenuBarHierarchical
 
?>