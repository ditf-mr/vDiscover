<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # check if application is started correctly
		if ( ! defined('APPLICATION_started') or ! $repository_config ) {
			header('Location: ../../../..');
			exit;
		}
	}

	{ # start http output 
		header('Content-type: application/json');
	}

	try { 
	
		# user permission are validated either in each task or in the backend functions 
		
		{ # identify the task 
			$task = sanitize_string($_POST, 'task', $_GET);
			switch ( $task ) { 
			
				case 'getUserProfile': # -----------------------------------------------------------
					{ # returns the profile (name, username, language and country code, but not the
					  #  password) of the user currently logged in.
					  include('General.json/getUserProfile.inc.php');
					  break;
					}
					
				case 'setUserProfile': # -----------------------------------------------------------
					{ # saves the given user profile (name, username, password, language and country
					  # code) into the corresponding object.
					  include('General.json/setUserProfile.inc.php');
					  break;
					}
					
				case 'existsUsername': # -----------------------------------------------------------
					{ # checks if the given username already exists (and is not the username of the 
					  # the user currently logged in.
					  include('General.json/existsUsername.inc.php');
					  break;
					}
					
				case 'userPermissions': # ----------------------------------------------------------
					{ # returns a list of all permissions.
					  include('General.json/userPermissions.inc.php');
					  break;
					}
					
				case 'userIsAdmin': # --------------------------------------------------------------
					{ # returns true if the user currently logged in is an admin (administrator) or
					  # not.
					  include('General.json/userIsAdmin.inc.php');
					  break;
					}
					
				case 'userHasReadPermission': # ----------------------------------------------------
					{ # returns true if the user currently logged in has got read permission or
					  # not.
					  include('General.json/userHasReadPermission.inc.php');
					  break;
					}
					
				case 'userHasWritePermission': # ---------------------------------------------------
					{ # returns true if the user currently logged in has got write permission or
					  # not.
					  include('General.json/userHasWriterPermission.inc.php');
					  break;
					}
					
				case 'get_NavigationTree4Admin': # -------------------------------------------------
					{ # return the navigation tree (including the list of all object and relation 
					  # types) for the administrator. If parameter "onlyOT" is set, then the object 
					  # types will used for the generation only.
						include('General.json/get_NavigationTree4Admin.inc.php');
						break;
					}
					
				case 'get_attributeKinds': # -------------------------------------------------------
					{ # return the list of all registered attribute kinds (allowed for 
					  # either cObjectType or cRelationType)
						include('General.json/get_attributeKinds.inc.php');
						break;
					}
					
				case 'get_watchList': # ------------------------------------------------------------
					{ # return the list on user's watch list as navigation tree.
						include('General.json/get_watchList.inc.php');
						break;
					}
					
				case 'objectModelReport':
					{ # generates the object model report, that is a description of object types
					  # including attributes, relation types and their attributes.
						include('General.json/objectModelReport.inc.php');
						break;
					}

				case 'get_roles': # -------------------------------------------------------------------
					{ # return the list of all objects of the object type in a simple form.
					  # (see also task "get_Os_4_OT_show_all_io" below.
						include('General.json/get_roles.inc.php');
						break;
					}
					
                case 'getLanguageStrings':   # -------------------------------------------------------------------
					{ # return the list of all objects of the object type in a simple form.
					  # (see also task  below.
						include('common/lang/getLanguageStrings.json.php');
						break;
					}     
                                        
				default: # -------------------------------------------------------------------------
					throw new Exception('The passed task is not implemented.');
					
			} # end-of-switch
		}
	} 
	catch (Exception $e) {
		header('HTTP/1.1 500 Internal Server Error');
		echo 
			json_encode(
				array(
					'type'		=> 'Exception',
					'message'	=> $e->getMessage(),
					'code'		=> $e->getCode(),
					'file'		=> $e->getFile(),
					'line'		=> $e->getLine(),
					'trace'		=> $e->getTraceAsString()
				)
			);
	} # end-of-trycatch

	
?>