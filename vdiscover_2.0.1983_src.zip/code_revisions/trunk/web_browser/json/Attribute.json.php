<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # check if application is started correctly
		if ( ! defined('APPLICATION_started') or ! $repository_config ) {
			header('Location: ../../../..');
			exit;
		}
	}

	{ # start http output 
		header('Content-type: application/json');
	}

	try { 
	
		# user permission are validated either in each task or in the backend functions 
		
		{ # identify the task 
			$task = sanitize_string($_POST, 'task', $_GET);
			switch ( $task ) { 
			
				case 'get_A': # --------------------------------------------------------------------
					{ # get (read) all items of an attribute
						include('Attribute.json/get_A.inc.php');
						break;
					}
					
				case 'get_relationValueTuple_for_temporaryRelation': # -----------------------------
					{ # create the structure of an imaginary and temporal relation to the specified 
					  # target object
						include('Attribute.json/get_relationValueTuple_for_temporaryRelation.inc.php');
						break;
					}
											
				case 'get_cOTInfoAttribute_configurationParameter': # -----------------------------
					{ # returns the configuration parameter of the cOTInfoAttribute
						include('Attribute.json/get_cOTInfoAttribute_configurationParameter.inc.php');
						break;
					}
											
				default: # -------------------------------------------------------------------------
					throw new Exception('The passed task is not implemented.');
			} # end-of-switch
		}
	} 
	catch (Exception $e) {
		$GLOBALS['logHandler']->log($e);
		header('HTTP/1.1 500 Internal Server Error');
		echo 
			json_encode(
				array(
					'type'		=> 'Exception',
					'message'	=> $e->getMessage(),
					'code'		=> $e->getCode(),
					'file'		=> $e->getFile(),
					'line'		=> $e->getLine(),
					'trace'		=> $e->getTraceAsString()
				)
			);
	} # end-of-trycatch

	
?>