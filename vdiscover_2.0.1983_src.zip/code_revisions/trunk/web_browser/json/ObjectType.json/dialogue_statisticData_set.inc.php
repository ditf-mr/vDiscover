<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/
	/*
		Creates objecty of the given object type according to the specifictions given in the
		parameters.
		Parameters are:
		- OT_UUID: UUID-string, the UUID of the object type
		- postData: array containing the following elements
		-- attrsWithSettingsAsValueTuples: array, list of attributeValues, with each element has got 
			the following format:	
			array(
				A_UUID => array(
					dummy_UUID => array(
						'value_number' => a_number
					)
					...
				)
				...
			)
		-- nameAttribute: array, the attribute that will be used to mark all generate objects
			array(
				'A_UUID' => A_UUID, 
				'valueTuple' => a_single_line_value_with_name_in_value_text
			)
		-- options: array
		--- deleteExistingObjectsBefore: boolean, all objects generated in a previous step will be 
				deleted first. These objects can be identified, by searching all objects that 
				contain a given content see 'nameAttribute' above
		--- randomOrder: boolean
		--- maxNumberOfObjects: integer, the maximum number of objects that will be created, = means
			no limit.
		The task answer the number of objects that have been created.
	*/
	
	{ # save start_time
		$start_time = microtime(true);
	}
	{ # get parameters
		$OT_UUID = sanitize_string($_POST, 'OT_UUID', $_GET);	
		if ( empty($OT_UUID)) {
			$OT_UUID = sanitize_string($_POST, 'UUID', $_GET);
		}
		
		{ # postData
			$postData = json_decode(sanitize_HTMLstring($_POST, 'postData', $_GET), true);
			if (json_last_error() != JSON_ERROR_NONE) {
				throw new incorrectInputDataException('"options" caused json-syntax-error.');
			}
			{ # options
				$options = isset($postData['options'])?$postData['options']: array();
				$deleteExistingObjectsBefore = isset($options['deleteExistingObjectsBefore'])?$options['deleteExistingObjectsBefore']:false;
				$randomOrder = isset($options['randomOrder'])?$options['randomOrder']:false;
				$maxNumberOfObjects = isset($options['maxNumberOfObjects'])?$options['maxNumberOfObjects']:false;
			}
			{ # nameAttribute
				$nameAttribute = isset($postData['nameAttribute'])?$postData['nameAttribute']: array();
				$nameAttribute_A_UUID = isset($nameAttribute['A_UUID'])?$nameAttribute['A_UUID']:'';
				$valueBlock = current(isset($nameAttribute['valueTuple'])?$nameAttribute['valueTuple']:'');
				$nameAttribute_text = isset($valueBlock['value_text'])?$valueBlock['value_text']:'';
			}
			{ # attrsWithSettingsAsValueTuples
				$attrsWithSettingsAsValueTuples = isset($postData['attrsWithSettingsAsValueTuples'])?$postData['attrsWithSettingsAsValueTuples']: array();
			}
		}
	}
	if (is_null($objectType = $backend->getObjectType($OT_UUID))) {
		throw new instanceNotFoundException(objectType, $OT_UUID);
	}
	{ # check access permissions
		if (! $backend->mayWrite_OT($objectType->OT_UUID())) {
			throw new writeViolationException($objectType);
		}
	}
	{ # clear if needed
		$numberOfObjectsDeleted = 0;
		if ($deleteExistingObjectsBefore) {
			$numberOfObjectsDeleted = $objectType->deleteObjects();
		}
	}
	{ # generate all permutations
		$permutations = array();
		foreach($attrsWithSettingsAsValueTuples as $A_UUID => $values) {
			$permutations2 = $permutations;
			$permutations = array();
			foreach($values as $value) {
				$newElement = array($A_UUID => $value);
				if (count($permutations2) == 0) {
					$permutations[] = $newElement;
				}
				else {
					foreach($permutations2 as $permutation2) {
						$newPermutation = array_merge($permutation2, $newElement);
						$permutations[] = $newPermutation;
					}
				}
			}
		}
	}
	{ # shuffle it needed
		if ($randomOrder) {
			shuffle($permutations);
		}
	}
	{ # walk through permutations and generate objects
		$numberOfObjectsCreated = 0;
		$objectsCreated = array();
		foreach($permutations as $permutation) {
			{ # extend process time for script
				set_time_limit(4);		
			}
			$numberOfObjectsCreated++;
			{ # create object
				$object = $objectType->addObject($nameAttribute_text.substr('0000000'.$numberOfObjectsCreated, -8));
				$objectsCreated[] = $object->O_v_UUID();
			}
			{ # add nameAttribute content if exists
				if (! empty($nameAttribute_A_UUID)) {
					$object->setAttributeValuesOfAnAttribute(
						$nameAttribute_A_UUID, 
						array(
							'dummy' => array(
								'positionOfValue'	=> 1,
								'value_text'		=> $nameAttribute_text
							)
						)
					);
				}
			}
			{ # add attributes
				foreach($permutation as $A_UUID => $value) {
					$attribute = $backend->getAttribute($A_UUID);
					$attributeValuesAsArray = array();
					switch($attribute->kind()) {
						case 'cNumberAttribute': {
							$newAttributeValue = cAttributeValue::newAttributeValueFromArray(
								$object->O_v_UUID(), 
								'O', 
								$A_UUID,
								array(
									'positionOfValue'	=> 1,
									'value_number'		=> $value['value_number'],
									'unit'				=> $value['unit']
								)
							);
							break;
						}
						case 'cSingleLineAttribute': {
							$newAttributeValue = cAttributeValue::newAttributeValueFromArray(
								$object->O_v_UUID(), 
								'O', 
								$A_UUID,
								array(
									'positionOfValue'	=> 1,
									'value_text'		=> $value['value_text']
								)
							);
							break;
						}
					}
					$newAttributeValue->save();
					unset($newAttributeValue);
				}
			}
			{ # update
				$object->update();
			}
			if ($numberOfObjectsCreated == $maxNumberOfObjects) {
				break; # stop because maximum reached
			}
		}
	}
	{ # answer
		$output = array(
			'OT_UUID'					=> $objectType->OT_UUID(),
			'numberOfObjectsCreated'	=> $numberOfObjectsCreated,
			'numberOfObjectsDeleted'	=> $numberOfObjectsDeleted,
			'objects'					=> $objectsCreated,
			'processTime'				=> sprintf('%.3f', microtime(true)-$start_time).' s'

		);
		echo json_encode($output);
	}

						
?>