<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		$OT_UUID = sanitize_string($_POST, 'OT_UUID', $_GET);	
		if ( empty($OT_UUID)) {
			$OT_UUID = sanitize_string($_POST, 'UUID', $_GET);
		}
		$name = sanitize_string($_POST, 'name');
	}
	if (is_null($objectType = $backend->getObjectType($OT_UUID))) {
		throw new instanceNotFoundException(objectType, $OT_UUID);
	}
	{ # check access permissions
		if (! $backend->isAdmin()) {
			throw new accessViolationException('You must not add object types.');
		}
	}
	$newObjectType = $objectType->addSubObjectType($name);
	{ # do not add cAllAttributesViewType to a new sub object type
		# $allAttributeViewType = new cAllAttributesViewType();
		# $allAttributeViewType->setName('All Attributes');
		# $newObjectType->addViewType($allAttributeViewType->toArray());
	}
	{ # answer
		$output = array(
			'UUID' => $newObjectType->OT_UUID()
		);
		echo json_encode($output);
	}

						
?>