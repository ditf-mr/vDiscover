<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		$OT_UUID = sanitize_string($_POST, 'OT_UUID', $_GET);	
		if ( empty($OT_UUID)) {
			$OT_UUID = sanitize_string($_POST, 'UUID', $_GET);
		}
		$addMenuItemList = json_decode(sanitize_string($_POST, 'new_items', $_GET), true);
		if (json_last_error() != JSON_ERROR_NONE) {
			throw new incorrectInputDataException('"new_items" caused json-syntax-error.');
		}
		$changeMenuItemList = json_decode(sanitize_string($_POST, 'change_items', $_GET), true);
		if (json_last_error() != JSON_ERROR_NONE) {
			throw new incorrectInputDataException('"change_items" caused json-syntax-error.');
		}
		$deleteMenuItemList = json_decode(sanitize_string($_POST, 'delete_items', $_GET), true);
		if (json_last_error() != JSON_ERROR_NONE) {
			throw new incorrectInputDataException('"delete_items" caused json-syntax-error.');
		}
	}
	if (is_null($objectType = $backend->getObjectType($OT_UUID))) {
		throw new instanceNotFoundException(objectType, $OT_UUID);
	}
	{ # check access permissions
		if (! $backend->isAdmin()) {
			throw new accessViolationException('You are not allowed to edit an object type.');
		}
	}
	$objectType->setMenuBarOT_2($addMenuItemList, $changeMenuItemList, $deleteMenuItemList);
	$objectType->update();
	{ # answer
		$output = array( 
			'identifier'	=> 'UUID',
			'label'			=> 'label',
			'items'			=> $objectType->menuBarOT()
		);
		echo json_encode($output);
	}

	
?>