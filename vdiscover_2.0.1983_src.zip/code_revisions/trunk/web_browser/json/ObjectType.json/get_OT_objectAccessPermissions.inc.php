<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		$OT_UUID = sanitize_string($_POST, 'OT_UUID', $_GET);	
		if ( empty($OT_UUID)) {
			$OT_UUID = sanitize_string($_POST, 'UUID', $_GET);
		}
	}
	if (is_null($objectType = $backend->getObjectType($OT_UUID))) {
		throw new instanceNotFoundException(objectType, $OT_UUID);
	}
	{ # check access permissions
		if (! $backend->mayRead_OT($objectType->OT_UUID())) {
			throw new readViolationException($objectType);
		}
	}
	
	// build object access permisions array
	$oAP = array(
				array('UUID'=>'a997b3ed-7c7c-11e0-a3b1-406186f2abca','name' => 'Administrator','readPermission'=>1,'writePermission'=>1,'deletePermission'=>1,'createPermission'=>1), 	/*admin*/
				array('UUID'=>'27ba94cd-5189-11e1-a62f-406186f2abca','name' => 'Reader','readPermission'=>1,'writePermission'=>-1,'deletePermission'=>-1,'createPermission'=>-1),		/*reader*/
				array('UUID'=>'28b1de64-5189-11e1-a62f-406186f2abca','name' => 'Writer','readPermission'=>1,'writePermission'=>1,'deletePermission'=>-1,'createPermission'=>-1),		/*writer*/
				array('UUID'=>'80e89726-5e2e-11e1-aff7-4cb39dfb146e','name' => 'Creater','readPermission'=>1,'writePermission'=>1,'deletePermission'=>-1,'createPermission'=>1),		/*creater*/
				array('UUID'=>'7229e097-5e2e-11e1-aff7-4cb39dfb146e','name' => 'Deleter','readPermission'=>1,'writePermission'=>-1,'deletePermission'=>1,'createPermission'=>-1)		/*deleter*/
			);
	
	{ # answer
		$output = array(
			'identifier'	=> 'UUID',
			'label'			=> 'UUID',
			'items'			=> $oAP
		);
		echo json_encode($output);
	}

						
?>