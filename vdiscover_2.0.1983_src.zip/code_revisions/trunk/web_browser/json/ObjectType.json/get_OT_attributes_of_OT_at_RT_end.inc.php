<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		$RT_UUID = sanitize_string($_POST, 'RT_UUID', $_GET);	
		if ( empty($RT_UUID)) {
			$RT_UUID = sanitize_string($_POST, 'UUID', $_GET);
		}
		$RT_UUID = str_replace('*', '', $RT_UUID);
		$OT_UUID = sanitize_string($_POST, 'OT_UUID', $_GET);	
	}
	if (is_null($relationType = $backend->getRelationType($RT_UUID))) {
		throw new instanceNotFoundException(relationType, $RT_UUID);
	}
	if (is_null($objectType = $backend->getObjectType($OT_UUID))) {
		throw new instanceNotFoundException(objectType, $OT_UUID);
	}
	{ # check access permissions
		if (! $backend->mayRead_OT($objectType->OT_UUID())) {
			throw new readViolationException($objectType);
		}
	}
	$attributes2 = array();
	if ($relationType->Start_OT_UUID() == $OT_UUID) {
		$endObjectType = $relationType->End_OT();
	}
	else { # use inverse direction
		$endObjectType = $relationType->Start_OT();
	}
	if ($endObjectType and ($attributes = $endObjectType->getAttributes())) {
		foreach($attributes as $attribute) {
			$attribute2 = $attribute->toArray();
			{ # bugfixes for different problems concerning special kind of attributes
				switch ($attribute->kind()) {
					case 'cKeyValuePairAttribute': 
						{ #  key-value-pairs, because this associative array will become
						  # a json object, which leads to an javascript resp. dojo error.
							unset($attribute2['keyValuePairs']);
						}
					case 'cOTInfoAttribute': 
						{ # cOTInfoAttribute, because this associative array will become
						  # a json object, which leads to an javascript resp. dojo error.
							unset($attribute2['configurationParameter']);
						}
				} # end-of-switch
			}
			$attributes2[] = $attribute2;
		}
	}
	{ # answer
		$output = array( 
			'identifier'	=> 'UUID',
			'label'			=> 'UUID',
			'items'			=> $attributes2
		);
		echo json_encode($output);
	}
	

?>