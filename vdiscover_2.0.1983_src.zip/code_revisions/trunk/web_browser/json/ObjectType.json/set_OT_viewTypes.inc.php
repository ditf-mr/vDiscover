<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		$OT_UUID = sanitize_string($_POST, 'OT_UUID', $_GET);	
		if ( empty($OT_UUID)) {
			$OT_UUID = sanitize_string($_POST, 'UUID', $_GET);
		}
		$viewTypesBlock = json_decode(sanitize_HTMLstring($_POST, 'viewTypes', $_GET), true);
		if (json_last_error() != JSON_ERROR_NONE) {
			throw new incorrectInputDataException('"viewTypes" caused json-syntax-error.');
		}
		$viewTypes = $viewTypesBlock['items'];	
	}
	if (is_null($objectType = $backend->getObjectType($OT_UUID))) {
		throw new instanceNotFoundException(objectType, $OT_UUID);
	}
	{ # check access permissions
		if (! $backend->isAdmin()) {
			throw new accessViolationException('You are not allowed to edit an object type.');
		}
	}
	{ # initialize buffers for template identification
		$templateName_VT_UUID = '';
		$templateDescription_VT_UUID = '';
	}
	{ # workaround due to the fact that the frontend in javascript needs (gets and sends) the  
	  # slot 'attributeList' seperatly json encoded. (see also 'get_OT_viewTypes.inc.php')
		foreach($viewTypes as &$viewType) { // & is needed !!!
			if (isset($viewType['attributeList'])) {
				$viewType['attributeList'] = json_decode($viewType['attributeList']);
				if (json_last_error() != JSON_ERROR_NONE) {
					throw new incorrectInputDataException('"attributeList" caused json-syntax-error.');
				}
			}
			if ($viewType['isTemplateName']) {
				if (isset($viewType['VT_UUID'])) {
					$templateName_VT_UUID = $viewType['VT_UUID'];
				}
				else {
					$templateName_VT_UUID = 'new view';
				}
			}
			if ($viewType['isTemplateDescription']) {
				if (isset($viewType['VT_UUID'])) {
					$templateDescription_VT_UUID = $viewType['VT_UUID'];
				}
				else {
					$templateDescription_VT_UUID = 'new view';
				}
			}
		}
	}
	$objectType->setViewTypes($viewTypes);
	{ # set template views
		if ($templateName_VT_UUID != 'new view') {
			$objectType->setTemplateName_VT_UUID($templateName_VT_UUID);
		}
		if ($templateDescription_VT_UUID != 'new view') {
			$objectType->setTemplateDescription_VT_UUID($templateDescription_VT_UUID);
		}
	}
	{ # answer
		$output = array(
			'done' => true
		);
		echo json_encode($output);
	}

						
?>