<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		$OT_UUID = sanitize_string($_POST, 'OT_UUID', $_GET);	
		if ( empty($OT_UUID))
			$OT_UUID = sanitize_string($_POST, 'UUID', $_GET);
	}
	if (is_null($objectType = $backend->getObjectType($OT_UUID))) {
		throw new instanceNotFoundException(objectType, $OT_UUID);
	}
	{ # check access permissions
		if (! $backend->mayRead_OT($objectType->OT_UUID())) {
			throw new readViolationException($objectType);
		}
	}
	$queries = cQuery::getBy_OT_UUID ( $OT_UUID ); 
	$queries2 = array();
	foreach($queries as $query) {
		$query2 = $query->toArray();
		$query2['OT_name'] = $objectType->name();
		{ # add name of person, that carried out the last changes
			if (! is_null($changedByP = $backend->getCurrentObject($query->changedByP_UUID()))) {
				$av_name = $changedByP->getAttributeValues(cSystem::$sysObject_Persons_A_Name_UUID);			
				$query2['changedByP_name'] = current($av_name)->value();
				$query2['changedByP_O_v_UUID'] = $changedByP->O_v_UUID();
			}
			else {
				$query2['changedByP_name'] = '???';
			}
		}
		{ # detect whether object is tagged
		
		}
# ----------------------
# the query should be a complete json encoded store as string
$query2['query2'] = json_encode($query2['query']);
unset($query2['query']);
# ----------------------
		$queries2[] = $query2;
	}
	{ # answer
		$output = array(
			'identifier'	=> 'UUID',
			'label'			=> 'UUID',
			'items'			=> $queries2
		);
		echo json_encode($output);
	}

						
?>