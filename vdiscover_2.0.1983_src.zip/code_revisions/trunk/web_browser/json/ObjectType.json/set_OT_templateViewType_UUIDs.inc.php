<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		$OT_UUID = sanitize_string($_POST, 'OT_UUID', $_GET);	
		if ( empty($OT_UUID)) {
			$OT_UUID = sanitize_string($_POST, 'UUID', $_GET);
		}
		$templateName_VT_UUID = sanitize_string($_POST, 'nameView', $_GET);	
		$templateDescription_VT_UUID = sanitize_string($_POST, 'decriptionView', $_GET);	
	}
	if (is_null($objectType = $backend->getObjectType($OT_UUID))) {
		throw new instanceNotFoundException(objectType, $OT_UUID);
	}
	{ # check access permissions
		if (! $backend->isAdmin()) {
			throw new accessViolationException('You are not allowed to edit an object type.');
		}
	}
	if ($templateName_VT_UUID != $objectType->templateName_VT_UUID()) {
		$objectType->setTemplateName_VT_UUID($templateName_VT_UUID);
	}
	if ($templateDescription_VT_UUID != $objectType->templateDescription_VT_UUID()) {
		$objectType->setTemplateDescription_VT_UUID($templateDescription_VT_UUID);
		$objectType->updateDescriptionsOfObjects();
	}
	{ # answer
		$output = array(
			'nameView' => $objectType->templateName_VT_UUID(),
			'decriptionView' => $objectType->templateDescription_VT_UUID()
		);
		echo json_encode($output);
	}

						
?>