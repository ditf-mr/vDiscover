<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		$OT_UUID = sanitize_string($_POST, 'OT_UUID', $_GET);	
		if ( empty($OT_UUID))
			$OT_UUID = sanitize_string($_POST, 'UUID', $_GET);
		$findListBlock = json_decode(sanitize_string($_POST, 'queryParameters', $_GET), true);
		if (json_last_error() != JSON_ERROR_NONE) {
			throw new incorrectInputDataException('"queryParameters" caused json-syntax-error.');
		}
		$name = $findListBlock['queryName'];
		$isPrivate = ($findListBlock['usage'] == 'justMe');
	}
	if (is_null($objectType = $backend->getObjectType($OT_UUID))) {
		throw new instanceNotFoundException(objectType, $OT_UUID);
	}
	{ # check access permissions
		if (! $backend->mayRead_OT($objectType->OT_UUID())) {
			throw new readViolationException($objectType);
		}
	}
	
	{ # save the find list
		$findListObject = $objectType->saveFindList($name, $isPrivate, $findListBlock);
	}
	{ # get info about the person that carried out the last changes
		$changedByP_O_v_UUID	= '';
		$changedByP_name 		= '';
		
		if (! is_null($changedByP = $backend->getCurrentObject($findListObject->changedByP_UUID()))) {
			$changedByP_O_v_UUID = $changedByP->O_v_UUID();
			$PName_AVTSet = $changedByP->getAttributeValues(cSystem::$sysObject_Persons_A_Name_UUID);			
			$changedByP_name = current($PName_AVTSet)->value();
		} // end if
	}
	{ # answer
		$output = array(
			'done' 				=> true,
			'FL_UUID' 			=> $findListObject->FL_UUID(),
			'storedQueryInfo'	=> array (
				'changedAt' 			=> $findListObject->changedAt(),
				'changedByP_O_v_UUID' 	=> $changedByP_O_v_UUID,
				'changedByP_name' 		=> $changedByP_name,
				)
		);
		echo json_encode($output);
	}
?>