<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		$OT_UUID = sanitize_string($_POST, 'OT_UUID', $_GET);	
		if ( empty($OT_UUID)) {
			$OT_UUID = sanitize_string($_POST, 'UUID', $_GET);
		}
		$viewKind = sanitize_string($_POST, 'viewKind', $_GET);	
	}
$GLOBALS['logHandler']->debug(__FILE__);
$GLOBALS['logHandler']->debug('Code must be modified.');
$viewKind = explode(',', $viewKind);
$GLOBALS['logHandler']->debug($viewKind);
	if (is_null($objectType = $backend->getObjectType($OT_UUID))) {
		throw new instanceNotFoundException(objectType, $OT_UUID);
	}
	{ # check access permissions
		if (! $backend->mayRead_OT($objectType->OT_UUID())) {
			throw new readViolationException($objectType);
		}
	}
	$viewTypes = $objectType->getViewTypes($viewKind);
	$viewTypes2 = array();
	foreach($viewTypes as $viewType) {
		$viewTypes2[] = $viewType->toArray();
	}		
	{ # answer
		$output = array( 
			'identifier'	=> 'UUID',
			'label'			=> 'UUID',
			'items'			=> $viewTypes2
		);
		echo json_encode($output);
	}

	
?>