<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	$paramName_points 			= 'points';
	$paramName_name 			= 'name';
	$paramName_description 		= 'description';
	$paramName_lastChangeAtBy 	= 'lastChangeAtBy';

	{ # get parameters
		$OT_UUID = sanitize_string($_POST, 'OT_UUID', $_GET);	
		if ( empty($OT_UUID)) {
			$OT_UUID = sanitize_string($_POST, 'UUID', $_GET);
		}
		// $colHeaders = json_decode(sanitize_string($_POST, 'colHeaders', $_GET));
		// $searchTerm = sanitize_string($_POST, 'searchTerm', $_GET);
		$queryParameters= json_decode(sanitize_string($_POST, 'queryParameters', $_GET), true);
		$colHeaders 	= $queryParameters['colHeaders'];
		$searchTerm 	= $queryParameters['searchQuery'];
		if (empty($searchTerm)) {
			$searchTerm = '*';
		}
	}
	if (is_null($objectType = $backend->getObjectType($OT_UUID))) {
		throw new instanceNotFoundException(objectType, $OT_UUID);
	}
	{ # check access permissions
		if (! $backend->mayRead_OT($objectType->OT_UUID())) throw new readViolationException($objectType);
	}
	
	{ # analyse colHeaders
		# general colHeaders
		$with_points 			= in_array($paramName_points, 			$colHeaders);
		$with_name 				= in_array($paramName_name, 			$colHeaders);
		$with_description 		= in_array($paramName_description, 		$colHeaders);
		$with_lastChangeAtBy 	= in_array($paramName_lastChangeAtBy, 	$colHeaders);
		
		# attributes as colHeaders
		$A_UUIDs = array();
		$attributes = $objectType->getAttributes();
		$k='';
		reset($colHeaders);
		while (list($k,$colHeader)=each($colHeaders)) {
			if (isset($attributes[$colHeader])) {
				$A_UUIDs[] = $colHeader;
			}
		}
	}
	{ # analyseQueryParameters
		$fromNo = 1;
		$limit = 0; # no limit
		if (isset($queryParameters['firstObject'])) {
			$fromNo = abs(intval($queryParameters['firstObject']))+1;
			if ($fromNo < 1) {
				$fromNo = 1;
			}
		}
		if (isset($queryParameters['returnMaxObjects'])) {
			$limit = abs(intval($queryParameters['returnMaxObjects']));
		}
	}
	{ # count total number of objects, that match the pattern
		$totalCountObjects = (int)$objectType->countObjectsBy_nameOrDescription($searchTerm);
	}
	{ # get the desired objects
		$searchResults = $objectType->retrieveObjectsBy_nameOrDescription($searchTerm, 'name asc', $fromNo, $limit);
	}
	{ # 'searchResults' may contain objects of different object types. The list 'A_UUIDs' contain 
	  # the UUIDs of the attributes, how they are specified in OT specified by 'OT_UUID'. During
	  # the collection of attribute values (see below) the A_UUIDs of the corresponding attributes
	  # of the specific object types are needed. The will be collected in the list 
	  # 'referenceList_A_UUID', that will be build up during the retrieval process.
	  # The structure of the list is [ OT_UUID => listOf_A_UUIDs_ofThisObjectType, ... ]
		$referenceList_A_UUID = array(
			$OT_UUID => $A_UUIDs
		);
	}
	{ # The 'reverseList_A_UUID is used to find the A_UUID orginally asked for (in A_UUIDs) by
	  # the UUID of the attribute of the current object (level).
		$reverseList_A_UUID = array();
		foreach($A_UUIDs as $A_UUID) {
			$reverseList_A_UUID[$A_UUID] = $A_UUID;
		}
	} 
	{ # generate result list with relevant columns
		$objects2 = array();
		$k='';
		reset($searchResults);
		while (list($k,$searchResult)=each($searchResults)) {
			set_time_limit(20);
			$object = $searchResult['object'];
			$object2 = array();
			$object2['O_v_UUID'] = $object->O_v_UUID();
			$object2['O_UUID'] = $object->O_UUID();
			if ($with_points) {
				$object2['points'] = $searchResult['quality'];
			}
			// the name is necessary, always
			//if ($with_name) {
				$object2['name'] = $object->name();
			//}
			if ($with_description) {
				$object2['description'] = $object->description();
				$object2['descriptionPlain'] = $object->descriptionPlain();
			}
			if ($with_lastChangeAtBy) {
				{ # add name of person, that carried out the last changes
					$object2['changedAt'] = $object->changedAt();
					if (! is_null($changedByP = $backend->getCurrentObject($object->changedByP_UUID()))) {
						$av_name = $changedByP->getAttributeValues(cSystem::$sysObject_Persons_A_Name_UUID);			
						$object2['changedByP_name'] = current($av_name)->value();
						$object2['changedByP_O_v_UUID'] = $changedByP->O_v_UUID();
					}
					else {
						$object2['changedByP_name'] = '???';
					}
				}
			}
			{ # collect all A_UUIDs of the attributes of this object if not available
				if (! isset($referenceList_A_UUID[$object->OT_UUID()])) {
					$A_UUIDs2 = array();
					foreach($A_UUIDs as $A_UUID) {
						$attribute = $backend->getAttribute($A_UUID);
						$thisAttribute = cAttribute::getBy_A_origin_UUID($attribute->A_origin()->A_UUID(), $object->OT_UUID());
						$A_UUIDs2[] = $thisAttribute->A_UUID();
						$reverseList_A_UUID[$thisAttribute->A_UUID()] = $A_UUID;
					}
					$referenceList_A_UUID[$object->OT_UUID()] = $A_UUIDs2;
				}
			}
			{ # call __get_O_view2_generateView to generate attribute values in all details for 
			  # all attributes
				$attributesWithValueSets_block = __get_O_view2_generateAttributeList(
					$object->O_v_UUID(), 
					$referenceList_A_UUID[$object->OT_UUID()], 
					$maxNumberOfFunctionCalls
				);
				$attributesWithValueSets = $attributesWithValueSets_block['attributesWithValueSets'];
				foreach($attributesWithValueSets as $A_UUID=>$attributesWithValueSet) {
					$attributeValues = $attributesWithValueSet['values'];
					$attributeValues2 = array();
					foreach($attributeValues as $AV_v_UUID=>$attributeValue) {
						$attributeValues2[] = $attributeValue;
					}
					$object2[$reverseList_A_UUID[$A_UUID]] = json_encode($attributeValues2);
				}
			}
			$objects2[] = $object2;
		} # end-of-while
	} 
	
	{ # answer
		$answer = array(
			'identifier' => 'O_UUID',
			'label' => 'O_UUID',
			'items' => &$objects2,
			//'firstObject' => $fromNo,
			//'countObjects' => count($objects2),
			'totalCountObjects' => $totalCountObjects
		);
		echo json_encode($answer);
	}

?>