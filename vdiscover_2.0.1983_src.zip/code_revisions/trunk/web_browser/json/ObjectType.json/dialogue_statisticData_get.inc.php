<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	/*
		Collects all data needed to fill the dialogue 'statisticData'. 
		This includes:
		- object type: OT_UUID, name, description, numberOfObjects
		- list of attributes: A_UUID, name, ... (
			Up to now only cNumericAttribute and cSingleLineAttribute are supported.
	*/
	
	
	{ # get parameters
		// the OT_UUID of the object type
		$OT_UUID = sanitize_string($_POST, 'move_OT_UUID', $_GET);	
		if ( empty($OT_UUID)) {
			$OT_UUID = sanitize_string($_POST, 'UUID', $_GET);
		}
	}
	if (is_null($objectType = $backend->getObjectType($OT_UUID))) {
		throw new instanceNotFoundException(objectType, $OT_UUID);
	}
	{ # check access permissions
		if (! $backend->mayRead_OT($objectType->OT_UUID())) {
			throw new readViolationException($objectType);
		}
	}
	{ # get list of attributes
		$attributes = $objectType->getAttributes();
		$attributes2 = array();
		foreach($attributes as $attribute) {
			if (($attribute->kind() == 'cNumberAttribute')
				or ($attribute->kind() == 'cSingleLineAttribute')) {
				// $attribute2 = $attribute->toArray();
				$attributes2[$attribute->A_UUID()] = $attribute->toArray();
				// $attribute2 = array(
					// 'A_UUID'		=> $attribute->A_UUID(),
					// 'name'			=> $attribute->name(),
					// 'description'	=> $attribute->description(),
					// 'kind'			=> $attribute->kind(),
					// 'readOnly'		=> $attribute->readOnly(),
					// 'mustBeSet'		=> $attribute->mustBeSet(),
					// 'mustBeUnique'	=> $attribute->mustBeUnique()
				// );
				// switch($attribute->kind()) {
					// case 'cNumberAttribute': {
						// $attribute2['format']		= $attribute->format();
						// $attribute2['unitsAsString']= $attribute->unitsAsString();
						// $attribute2['minValue']		= $attribute->minValue();
						// $attribute2['maxValue']		= $attribute->maxValue();
						// $attribute2['defaultValue']	= $attribute->defaultValue();
						// $attribute2['defaultUnit']	= $attribute->defaultUnit();
						// break;
					// }
					// case 'cSingleLineAttribute': {
						// $attribute2['format']		= $attribute->format();
						// $attribute2['maxLength']	= $attribute->maxLength();
						// $attribute2['defaultValue']	= $attribute->defaultValue();
						// break;
					// }
				// }
				//$attributes2[] = $attribute2;
			}
		}
	}
	{ # answer
		$output = array(
			'OT_UUID'			=> $objectType->OT_UUID(),
			'name'				=> $objectType->name(),
			'description'		=> $objectType->description(),
			'numberOfObjects'	=> $objectType->countObjects(),
			'attributes'		=> $attributes2
		);
		echo json_encode($output);
	}

						
?>