<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		$OT_UUID = sanitize_string($_POST, 'OT_UUID', $_GET);	
		if ( empty($OT_UUID))
			$OT_UUID = sanitize_string($_POST, 'UUID', $_GET);
		$retrievalQueryJson = sanitize_HTMLstring($_POST, 'retrievalValues', $_GET);
	}
	if (is_null($objectType = $backend->getObjectType($OT_UUID))) {
		throw new instanceNotFoundException(objectType, $OT_UUID);
	}
	{ # check access permissions
		if (! $backend->mayRead_OT($objectType->OT_UUID())) {
			throw new readViolationException($objectType);
		}
	}
	{ # collect retrieval parameter
		$retrievalQueryBlock = json_decode($retrievalQueryJson, true);
		if (json_last_error() != JSON_ERROR_NONE) {
			throw new incorrectInputDataException('"retrievalQueryJson" caused json-syntax-error.');
		}
		$retrievalQueryItems = $retrievalQueryBlock['items'];
		$retrievalParameters = array();
		foreach($retrievalQueryItems as $retrievalQueryItem) {
			$retrievalParameters[$retrievalQueryItem['A_UUID']] = $retrievalQueryItem;
		}
	}
	$objects = $objectType->retrieveBy_attributeValues($retrievalParameters);
	$objects2 = array();
	foreach($objects as $resultArray) {
		$object2 = $resultArray['object']->toArray();
		$object2['OT_name'] = $resultArray['object']->OT()->name();
		{ # add can points to the object
			if (array_key_exists ( 'canPoints' , $resultArray )) $object2['canPoints'] = $resultArray['canPoints'];
		}
		{ # add name of person, that carried out the last changes
			if (! is_null($changedByP = $backend->getCurrentObject($resultArray['object']->changedByP_UUID()))) {
				$av_name = $changedByP->getAttributeValues(cSystem::$sysObject_Persons_A_Name_UUID);			
				$object2['changedByP_name'] = current($av_name)->value();
				$object2['changedByP_O_v_UUID'] = $changedByP->O_v_UUID();
			}
			else {
				$object2['changedByP_name'] = 'unknown';
			}
		}
		$objects2[] = $object2;
	}
	{ # answer // this should be a array of Objects like at "get_Os"
		$output = array(
			'identifier'	=> 'UUID',
			'label'			=> 'UUID',
			'items'			=> $objects2
		);
		echo json_encode($output);
	}

	
?>