<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		$pattern = sanitize_string($_POST, 'pattern', $_GET);	
		$OT_UUID = sanitize_string($_POST, 'OT_UUID', $_GET);	
	}
	{ # decide where to search
		if (! empty($OT_UUID)) {
			if (is_null($objectType = $backend->getObjectType($OT_UUID))) {
				throw new instanceNotFoundException(objectType, $OT_UUID);
			}
			$searchResults = $objectType->retrieveObjectsBy_nameOrDescription($pattern, 'name asc');
		}
		else {
			$searchResults = cObject::retrieveBy_nameOrDescription('', $pattern, 'name asc');
		}
	}
	{ # Let's output the search results
		$searchResults2 = array();
		foreach($searchResults as &$searchResult) {
		
			$object = &$searchResult['object'];
			{ # continue only, if the user has access permissions
				if ($backend->mayRead_OT($object->OT_UUID())) {
				
					// for JSON encoding, we need to convert the object to an array
					$searchResult2 = $object->toArray();
					
					// let's add some missing slots
					$searchResult2['OT_name'] = $searchResult['object']->OT()->name();
					$searchResult2['quality'] = &$searchResult['quality'];
					{ # add name of person, who did last changes
						if (! is_null($changedByP = $backend->getCurrentObject($searchResult['object']->changedByP_UUID()))) {
							$av_name = $changedByP->getAttributeValues(cSystem::$sysObject_Persons_A_Name_UUID);			
							$searchResult2['changedByP_name'] = current($av_name)->value();
							$searchResult2['changedByP_O_v_UUID'] = $changedByP->O_v_UUID();
						}
						else {
							$searchResult2['changedByP_name'] = 'n.a.';
						}
					}
					
					// let's attach the current search result to the list
					$searchResults2[] = &$searchResult2;
				}
			}
		}
	}
	{ # answer
		$output = array( 
			'identifier'	=> 'UUID',
			'label'			=> 'UUID',
			'items'			=> &$searchResults2
		);
		echo json_encode($output);
	}

	
?>