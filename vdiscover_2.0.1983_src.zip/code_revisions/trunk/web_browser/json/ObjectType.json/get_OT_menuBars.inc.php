<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameters
		$OT_UUID = sanitize_string($_GET, 'OT_UUID', $_POST);	
		if (is_null($objectType = $backend->getObjectType($OT_UUID))) {
			throw new instanceNotFoundException(objectType, $OT_UUID);
		} // end if
	}
	
	{ # check access permissions
		if (! $backend->mayRead_OT($objectType->OT_UUID())) {
			throw new readViolationException($objectType);
		}
	}
	{ # answer
		echo json_encode(array(
			'O_menuBar'		=> $objectType->menuBarO(),
			'OT_menuBar'	=> $objectType->menuBarOT(),		
		));
	}
?>