<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		$OT_UUID = sanitize_string($_POST, 'OT_UUID', $_GET);	
		if ( empty($OT_UUID))
			$OT_UUID = sanitize_string($_POST, 'UUID', $_GET);
		$queryBlock = json_decode(sanitize_string($_POST, 'retrievalQuery', $_GET), true);
		if (json_last_error() != JSON_ERROR_NONE) {
			throw new incorrectInputDataException('"retrievalQuery" caused json-syntax-error.');
		}
		$query = $queryBlock['items'];	
		$name = sanitize_string($_POST, 'queryName', $_GET);
	}
	if (is_null($objectType = $backend->getObjectType($OT_UUID))) {
		throw new instanceNotFoundException(objectType, $OT_UUID);
	}
	{ # check access permissions
		if (! $backend->mayRead_OT($objectType->OT_UUID())) {
			throw new readViolationException($objectType);
		}
	}
	$objectType->saveQuery($name, $query);
	{ # answer
		$output = array(
			'done' => true
		);
		echo json_encode($output);
	}

						
?>