<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		$OT_UUID = sanitize_string($_POST, 'OT_UUID', $_GET);	
		if ( empty($OT_UUID)) {
			$OT_UUID = sanitize_string($_POST, 'UUID', $_GET);
		}
		$attributesBlock = json_decode(sanitize_string($_POST, 'attributes', $_GET), true);
		if (json_last_error() != JSON_ERROR_NONE) {
			throw new incorrectInputDataException('"attributes" caused json-syntax-error.');
		}
		$attributes = $attributesBlock['items'];	
	}
	if (is_null($objectType = $backend->getObjectType($OT_UUID))) {
		throw new instanceNotFoundException(objectType, $OT_UUID);
	}
	{ # check access permissions
		if (! $backend->isAdmin()) {
			throw new accessViolationException('You are not allowed to edit the attributes of an object type.');
		}
	}
	{ # workaround for transformation of 'tags'
		foreach($attributes as &$attribute) {
			if (isset($attribute['tags'])) {
				$tagsArray = json_decode($attribute['tags'], true);
				$tags = array_values($tagsArray);
				$tagsAsString = implode("\n", $tags);
				$attribute['tags'] = $tagsAsString;
			}
			{ # check if attribute is a relation attribute with a reflexive relation type
			  # then specify direction
			  if ($attribute['kind'] == 'cRelationAttribute') {
				if (isset($attribute['selected_RT_UUID']) and (substr($attribute['selected_RT_UUID'], -1) == '*')) {
					$attribute['selected_RT_UUID'] = str_replace('*', '', $attribute['selected_RT_UUID']);
					$attribute['backIfReflexive'] = true;
				}
			  }
			}
		}
	}
	$objectType->setAttributes($attributes);
	{ # answer
		$output = array(
			'done' => true
		);
		echo json_encode($output);
	}

	
?>