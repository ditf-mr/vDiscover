<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameters
	
		$OT_UUID = sanitize_string($_POST, 'OT_UUID', $_GET);
		if ( empty($OT_UUID)) $OT_UUID = sanitize_string($_POST, 'UUID', $_GET);
		
		$relationConfig = sanitize_string($_POST, 'relationConfig', $_GET);
		
	}
	if (is_null($objectType = $backend->getObjectType($OT_UUID))) {
		throw new instanceNotFoundException(objectType, $OT_UUID);
	}
	{ # check access permissions
		if (! $backend->mayRead_OT($objectType->OT_UUID())) {
			throw new readViolationException($objectType);
		}
	}
	$attributes = $objectType->getAttributes();
	$attributes2 = array();
	$tagNames = array(); # see workaround for tags below
	foreach($attributes as $attribute) {
		$attribute2 = $attribute->toArray();
		{ # bugfix for cKeyValuePairAttribute, because this associative array will become
		  # a json object, which leads to an javascript resp. dojo error.
			if ($attribute->kind() == 'cKeyValuePairAttribute') {
				unset($attribute2['keyValuePairs']);
			}
		}
		{ # bugfix for cOTInfoAttribute, because the slot 'configurationParameter' will lead to an 
		  # error. It must be json_encode once more.
			if ($attribute->kind() == 'cOTInfoAttribute') {
				$attribute2['configurationParameter'] = json_encode($attribute2['configurationParameter']);
			}
		}
		{ # for cRelationAttributes: add name of end object type
			if (
						($attribute->kind() == 'cRelationAttribute') 
					AND ($relationConfig!='withoutEndObjAndAttributeInfo')
				) {
				$endObjectType = $backend->getObjectType($attribute->End_OT_UUID());
				$attribute2['End_OT_name'] = is_null($endObjectType)?'':$endObjectType->name();
				$relationAttributes = $attribute->selected_RT()->getAttributes();
				$relationAttributes2 = array();
				foreach($relationAttributes as $A_UUID => $relationAttribute) {
					$relationAttributes2[$A_UUID] = $relationAttribute->toArray();
				}
				$attribute2['relationAttributes'] = json_encode($relationAttributes2);
			}
		}
		{ # add some information if attribute is inherited
			if ($attribute->isInherited()) {
				{ # is view an inherited one
					$attribute2['isInherited'] = true;
				}
				{ # name/UUID of super object type, where the attribute was defined originally
					$origin_A = $attribute->A_origin();
					$attribute2['attributeDefinedAt'] = $origin_A->ORT()->name();
				}
				{ # list of names/UUIDs of super object types that have the same attribute
					$OTList = array();
					$super_OT = $attribute->ORT()->super_OT();
					while(!is_null($super_OT)) {
						$OTList[] = $super_OT->name();
						$super_OT = $super_OT->super_OT();
					}
					$attribute2['inheritanceChain'] = json_encode(array_reverse($OTList));
				}
				{ # get direct parent attribute
					$parentAttribute = cAttribute::getBy_A_origin_UUID ( $attribute->A_origin_UUID(), $attribute->ORT()->super_OT_UUID());
				}
				{ # kind specific things
					switch ($attribute->kind()) {
						case 'cNumberAttribute':
							$attribute2['parentDefaultValue'] = $parentAttribute->defaultValue();
							$attribute2['parentDefaultUnit'] = $parentAttribute->defaultUnit();
							break;
						case 'cFuzzyAttribute':
							$attribute2['parentDefaultValue'] = $parentAttribute->defaultValue();
							break;
						case 'cKeyValuePairAttribute':
							$attribute2['parentDefaultValue'] = $parentAttribute->defaultValue();
							$attribute2['parentDefaultValueAsString'] = $parentAttribute->defaultValueAsString();
							break;
						case 'cSingleLineAttribute':
							$attribute2['parentDefaultValue'] = $parentAttribute->defaultValue();
							break;
						case 'cValueRangeAttribute':
							$attribute2['parentDefaultValue_rangeMin'] = $parentAttribute->defaultValue_rangeMin();
							$attribute2['parentDefaultValue_rangeMax'] = $parentAttribute->defaultValue_rangeMax();
							$attribute2['parentDefaultUnit'] = $parentAttribute->defaultUnit();
							break;
						case 'cMeasurementResultAttribute':
							$attribute2['parentDefaultValue'] = $parentAttribute->defaultValue();
							$attribute2['parentDefaultUnit'] = $parentAttribute->defaultUnit();
							break;
					}
				}
			}
			else {
				$attribute2['isInherited'] = false;
			}
		}
		{ # workaround for tags
			$tags = $attribute->tags();
			$tags2 = array();
			foreach($tags as $tag) {
				if (!isset($tagNames[$tag])) {
					$tagNames[$tag] = cSystem::generateUUID();
				}
				$tags2[$tagNames[$tag]] = $tag;
			}
			$attribute2['tags'] = json_encode($tags2);
		}
		$attributes2[] = $attribute2;
	} # end-of-foreach
	{ # answer
		$output = array( 
			'identifier'	=> 'UUID',
			'label'			=> 'UUID',
			'items'			=> $attributes2
		);
		echo json_encode($output);
	}

	
?>