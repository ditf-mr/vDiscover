<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		$withChildrenSlot = (sanitize_string($_POST, 'withChildrenSlot', $_GET) == '1');
	}
	$objectTypes = $backend->getObjectTypes();
	{ # convert arrays of objects to arrays of arrays
		$objectTypes2 = array();
		foreach($objectTypes as $OT_UUID=>$objectType) {
			{ # check access permissions
				if ($backend->mayRead_OT($OT_UUID)) {
					$objectTypes2[$OT_UUID] = $objectType->toArray();
				}
			}
		}			
	}
	if ($withChildrenSlot) {
		{ # create 'sub_OT_UUID' element for each cObjectType element in the array by:
		  # adding an empty 'sub_OT_UUID' element to each cObjectType and 
		  # filling it with the 'sub_OT_UUID' elements
			foreach($objectTypes2 as $OT_UUID=>$objectType2)
				$objectTypes2[$OT_UUID]['sub_OT_UUIDs'] = array();
			foreach($objectTypes2 as $OT_UUID=>$objectType2) {
				if (! empty($objectType2['super_OT_UUID'])) {
					$objectTypes2[$objectType2['super_OT_UUID']]['sub_OT_UUIDs'][] = $OT_UUID;
				} # end-if
			}# end-foreach
		}
		{ # transform list of object types to json format
			$topLevelObjectTypes = array();
			$items = array();
			foreach($objectTypes2 as $objectType2) {
				if (empty($objectType2['super_OT_UUID']))
					$topLevelObjectTypes[] = array('_reference' => $objectType2['OT_UUID']);
				$children = array();
				foreach($objectType2['sub_OT_UUIDs'] as $child) 
					$children[] = array('_reference' => $child ) ;
				$item = array(
					'UUID' => $objectType2['OT_UUID'],
					'name' => $objectType2['name'],
					'description' => $objectType2['description'],
					'type' => 'OT',
					'menuBarOT'=>json_encode($objectType2['menuBarOT'])
				);	
				if (count($children)>0) $item['children']=$children;
				$items [] = $item;
			} # end-of-foreach
		}
		{ # add root node
			$items[] =  array( 
				'UUID' => 'Object Types', 
				'name' => T( 'get_NavigationTree.inc.php/types_TXT', 'Types' ), 
				'type' => 'navigation_node',
				'children' => $topLevelObjectTypes 
				);
		}
	}
	else {
		$items = array();
		foreach($objectTypes2 as $objectType2) {
			$items [] = array(
				'UUID' => $objectType2['OT_UUID'],
				'name' => $objectType2['name'],
				'type' => 'navigation_node',
				'menuBarOT'=>json_encode($objectType2['menuBarOT'])
			);
		} # end-of-foreach
	} # end-of-if ($withChildrenSlot)
	{ # answer
		$output = array ( 
			'identifier'	=> 'UUID', 
			'label'			=> 'name', 
			'items'			=> $items 
		);
		echo json_encode($output);
	}
	
	
?>