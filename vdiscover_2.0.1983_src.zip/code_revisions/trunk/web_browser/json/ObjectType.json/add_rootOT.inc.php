<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		$name = sanitize_string($_POST, 'name', $_GET);	
		$menuBarOT = json_decode(sanitize_string($_POST, 'menuBarOT', $_GET), true);	
		if (json_last_error() != JSON_ERROR_NONE) {
			throw new incorrectInputDataException('"menuBarOT" caused json-syntax-error.');
		}
		$menuBarO = json_decode(sanitize_string($_POST, 'menuBarO', $_GET), true);	
		if (json_last_error() != JSON_ERROR_NONE) {
			throw new incorrectInputDataException('"menuBarO" caused json-syntax-error.');
		}
	}
	{ # check access permissions
		if (! $backend->isAdmin()) {
			throw new accessViolationException('You are not allowed to add object types.');
		}
	}
	$newObjectType = cObjectType::addObjectType($name);
	{ # add cAllAttributesViewType to new object type
		$allAttributeViewType = new cAllAttributesViewType();
		$allAttributeViewType->setName('All Attributes');
		$newObjectType->addViewType($allAttributeViewType->toArray());
	}
	{ # set initial menu bars
		$newObjectType->setMenuBarOT_2($menuBarOT);
		$newObjectType->setMenuBarO_2($menuBarO);
	}
	$newObjectType->update();
	{ # answer
		$output = array(
			'UUID' => $newObjectType->OT_UUID()
		);
		echo json_encode($output);
	}

						
?>