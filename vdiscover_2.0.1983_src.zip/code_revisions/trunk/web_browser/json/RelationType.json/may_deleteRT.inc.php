<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		$RT_UUID = sanitize_string($_POST, 'RT_UUID', $_GET);	
		if ( empty($RT_UUID)) {
			$RT_UUID = sanitize_string($_POST, 'UUID', $_GET);
		}
	}
	if (is_null($relationType = $backend->getRelationType($RT_UUID))) {
		throw new instanceNotFoundException(relationType, $RT_UUID);
	}
	{ # answer
		$output = ($backend->isAdmin()
			and !$relationType->isSystemObject());
		echo json_encode($output);
	}

						
?>