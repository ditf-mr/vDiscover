<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		$Start_OT_UUID = sanitize_string($_POST, 'start_OT_UUID');
		$End_OT_UUID = sanitize_string($_POST, 'end_OT_UUID');
		$RT_name = sanitize_string($_POST, 'RT_name');
		$RT_nameOfInverse = sanitize_string($_POST, 'RT_nameOfInverse');
		$createAttributeAtStartOT = (sanitize_string($_POST, 'createAttributeAtStartOT') == '1');
		$createAttributeAtEndOT = (sanitize_string($_POST, 'createAttributeAtEndOT') == '1');
	}
	if (is_null($startObjectType = $backend->getObjectType($Start_OT_UUID))) {
		throw new instanceNotFoundException(objectType, $Start_OT_UUID);
	}
	if (is_null($endObjectType = $backend->getObjectType($End_OT_UUID))) {
		throw new instanceNotFoundException(objectType, $End_OT_UUID);
	}
	{ # check access permissions
		if (! $backend->isAdmin()) {
			throw new accessViolationException('You are not allowed to add relation types.');
		}
	}
	$relationType = cRelationType::addRelationType($RT_name, $RT_nameOfInverse, $startObjectType->OT_UUID(), $endObjectType->OT_UUID() );
	if (! is_null($relationType)) {
		{ # create relation attributes at the start or end object type if desired
			if ($createAttributeAtEndOT or $createAttributeAtStartOT) {
				{ # load start and end object type
					$Start_OT = $backend->getObjectType($Start_OT_UUID);
					$End_OT = $backend->getObjectType($End_OT_UUID);
				}
				if ($createAttributeAtStartOT) {
					if ($End_OT->templateName_VT_UUID()) {
						{ # create cRelationAttribute for the view
							$Start_OT->addAttribute(
								array(
									'kind' => 'cRelationAttribute',
									'name' => 'Relation to: ' . $End_OT->name(),
									'description' => 'Auto-generated corresponding to relation type "' . $relationType->name() . '" with UUID="' . $relationType->RT_UUID() .'"',
									'positionOfAttribute' => 9999,
									'readOnly' => false,
									'selected_RT_UUID' => $relationType->RT_UUID(),
									'showWhat' => 'V',
									'show_UUID' => $End_OT->templateName_VT_UUID()
								)
							);
						}
					}
					else {
						$attributes = $End_OT->getAttributes();
						if (count($attributes)) {
							{ # create cRelationAttribute for the first attribute
								$attribute = current($attributes);
								$Start_OT->addAttribute(
									array(
										'kind' => 'cRelationAttribute',
										'name' => 'Relation to: ' . $End_OT->name(),
										'description' => 'Auto-generated corresponding to relation type "' . $relationType->name() . '" with UUID="' . $relationType->RT_UUID() .'"',
										'positionOfAttribute' => 9999,
										'readOnly' => false,
										'selected_RT_UUID' => $relationType->RT_UUID(),
										'showWhat' => 'A',
										'show_UUID' => $attribute->A_UUID()
									)
								);
							}
						}
						else {
							# do nothing
						}
					}
				}
				if ($createAttributeAtEndOT) {
					if ($Start_OT->templateName_VT_UUID()) {
						{ # create cRelationAttribute for the view
							$End_OT->addAttribute(
								array(
									'kind' => 'cRelationAttribute',
									'name' => 'Relation to: ' . $Start_OT->name(),
									'description' => 'Auto-generated corresponding to relation type "' . $relationType->name() . '" with UUID="' . $relationType->RT_UUID() .'"',
									'positionOfAttribute' => 9999,
									'readOnly' => false,
									'selected_RT_UUID' => $relationType->RT_UUID(),
									'showWhat' => 'V',
									'show_UUID' => $Start_OT->templateName_VT_UUID()
								)
							);
						}
					}
					else {
						$attributes = $Start_OT->getAttributes();
						if (count($attributes)) {
							{ # create cRelationAttribute for the first attribute
								$attribute = current($attributes);
								$End_OT->addAttribute(
									array(
										'kind' => 'cRelationAttribute',
										'name' => 'Relation to: ' . $Start_OT->name(),
										'description' => 'Auto-generated corresponding to relation type "' . $relationType->name() . '" with UUID="' . $relationType->RT_UUID() .'"',
										'positionOfAttribute' => 9999,
										'readOnly' => false,
										'selected_RT_UUID' => $relationType->RT_UUID(),
										'showWhat' => 'A',
										'show_UUID' => $attribute->A_UUID()
									)
								);
							}
						}
						else {
							# do nothing
						}
					}
				}
			}
		}
	}
	{ # answer
		$output = array(
			'done' => true,
			'UUID' => $relationType->RT_UUID()
		);
		echo json_encode($output);
	}

	
?>