<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		$RT_UUID = sanitize_string($_POST, 'RT_UUID', $_GET);	
		if ( empty($RT_UUID)) {
			$RT_UUID = sanitize_string($_POST, 'UUID', $_GET);
		}
	}
	if (is_null($relationType = $backend->getRelationType($RT_UUID))) {
		throw new instanceNotFoundException(relationType, $RT_UUID);
	}
	{ # check access permissions
		if (! $backend->mayRead_RT($relationType->RT_UUID())) {
			throw new readViolationException($relationType);
		}
	}
	{ # answer
		$output = array(
			'description' => $relationType->description()
		);
		echo json_encode($output);
	}

	
?>