<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		$RT_UUID = sanitize_string($_POST, 'RT_UUID', $_GET);	
		if ( empty($RT_UUID)) {
			$RT_UUID = sanitize_string($_POST, 'UUID', $_GET);
		}
	}
	if (is_null($relationType = $backend->getRelationType($RT_UUID))) {
		throw new instanceNotFoundException(relationType, $RT_UUID);
	}
	{ # check access permissions
		if (! $backend->isAdmin()) {
			throw new accessViolationException('You are not allowed to delete relation types.');
		}
	}
	$relationType->delete();
	{ # answer
		$output = array(
			'done' => true
		);
		echo json_encode($output);
	}

	
?>