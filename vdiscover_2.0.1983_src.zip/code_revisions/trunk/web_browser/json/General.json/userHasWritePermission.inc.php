<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameters
	}
	{ # generate output element
		$output = array ( 
			'hasWritePermission'	=> $backend->hasWritePermission()
		);
	}
	{ # encode
		echo json_encode( $output );
	}

?>