<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameters
		$type = sanitize_string($_POST, 'type', $_GET);	
	}
	$attributeKinds = $backend->getAttributeKinds($type);
	{ # output the result
		echo json_encode($attributeKinds);
	}

						
?>