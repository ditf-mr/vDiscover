<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	$nl = "\n";
	{ # get parameters
		$listOfOTs = json_decode(sanitize_string($_POST, 'items', $_GET));
		if (json_last_error() != JSON_ERROR_NONE) {
			throw new incorrectInputDataException('"items" caused json-syntax-error.');
		}
		$withAttributes = (sanitize_string($_POST, 'withAttributes', $_GET) == '1');
		$withRelationTypes = (sanitize_string($_POST, 'withRelationTypes', $_GET) == '1');
		$withAttributesOfRelationTypes = (sanitize_string($_POST, 'withAttributesOfRelationTypes', $_GET) == '1');
		$withConfiguration = (sanitize_string($_POST, 'withConfiguration', $_GET) == '1');
		$withEditingConstrains = (sanitize_string($_POST, 'withEditingConstrains', $_GET) == '1');
		$withCardinalityInformation = (sanitize_string($_POST, 'withCardinalityInformation', $_GET) == '1');
		$outputFormat = strtolower(sanitize_string($_POST, 'outputFormat', $_GET));
	}
	{ # correct parameters if necessary
		if (empty($listOfOTs) or (($listOfOTs != 'all') and (! is_array($listOfOTs)))) {
			$listOfOTs = 'all';
		}
	}
	{ # build list of relevant object types
		$objectTypes = $backend->getAllObjectTypes(); 
		$relevantObjectTypes = array();
		foreach($objectTypes as $objectType) {
			if (($listOfOTs == 'all') or (in_array($objectType->OT_UUID(), $listOfOTs))) {
				$relevantObjectTypes[] = $objectType;
			}
		}
	}
	{ # initialise output
		$output = '';
		switch($outputFormat) {
			case 'xml':
				$output .= ''
					. '<?xml version="1.0" encoding="UTF-8" ?>' . $nl
					. '<objectModelReport>' . $nl
					. '<objectTypes>' . $nl;
				break;
			case 'html':
			default:
				$output .= '<table width="100%">';
		} # end-of-switch
	}
	{ # walk through list of object types and produce output
		foreach($relevantObjectTypes as $objectType) {
			{ # output begin of object type
				switch($outputFormat) {
					case 'xml': {
						$output .= '<objectType name="' . $objectType->OT_UUID(). '">' . $nl;
						break;
					}
					case 'html':
					default: {
						$output .= '<tr>'
							. '<td style="width=10px;"></td>'
							. '<td style="width=10px;"></td>'
							. '<td style="width=10px;"></td>'
							. '<td style="width=10px;"></td>'
							. '<td style="width=10px;"></td>'
							. '</tr>' . $nl;
						$output .= '<tr><td colspan="5"><h1>' . $objectType->name(). '</h1></td></tr>' . $nl;
					}
				} # end-of-switch
			}
			{ # output properties
				$output .= __omr_outputProperty('Name', $objectType->name(), $outputFormat, 'omrProperty', 1, $nl);
				$output .= __omr_outputProperty('UUID', $objectType->OT_UUID(), $outputFormat, 'omrProperty', 1, $nl);
				$output .= __omr_outputProperty('Super OT', ($objectType->super_OT_UUID()!=''?$objectType->super_OT()->name():''), $outputFormat, 'omrProperty', 1, $nl);
				$output .= __omr_outputProperty('Description', $objectType->description(), $outputFormat, 'omrProperty', 1, $nl);
				$output .= __omr_outputProperty(
					'templateName', 
					($objectType->templateName_VT_UUID()!=''?
						$objectType->templateName_VT()->name().' ('.$objectType->templateName_VT_UUID().')':
						''), 
					$outputFormat, 
					'omrProperty', 
					1,
					$nl
				);
				$output .= __omr_outputProperty(
					'templateDescription', 
					($objectType->templateDescription_VT_UUID()!=''?
						$objectType->templateDescription_VT()->name().' ('.$objectType->templateDescription_VT_UUID().')':
						''), 
					$outputFormat, 
					'omrProperty', 
					1,
					$nl
				);
			}
			{ # output attributes
				if ($withAttributes) {
					{ # retrieve list of attributes
						$attributes = $objectType->getAttributes();
					}
					{ # output begin of attributes
						switch($outputFormat) {
							case 'xml': {
								$output .= '<attributes>' . $nl;
								break;
							}
							case 'html':
							default: {
								$output .= '<tr><td></td><td colspan="4" class="omrAttributes" style="border: 1px solid #000;"><h2>Attributes</h2></td></tr>' . $nl;
							}
						} # end-of-switch
					}
					{ # walk through list of attributes and out them
						foreach($attributes as $attribute) {
							{ # output begin of attribute
								switch($outputFormat) {
									case 'xml': {
										$output .= '<attribute name="' . $attribute->name() . '">' . $nl;
										break;
									}
									case 'html':
									default: {
										$output .= '<tr><td colspan="2"></td><td colspan="3" class="omrAttributes" style="border: 1px solid #000;"><h3>' . $attribute->name() . '</h3></td></tr>' . $nl;
									}
								} # end-of-switch
							}
							{ # retrieve properties and output them
								$properties = $attribute->forReports();
								foreach ($properties as $propertyGroup=>$propertiesInGroup) {
									foreach ($propertiesInGroup as $propertyLabel=>$propertyValue) {
										if (($propertyGroup == 'common') 
										or ($withEditingConstrains and ($propertyGroup == 'constrains'))
										or ($withCardinalityInformation and ($propertyGroup == 'cardinality'))
										or ($withConfiguration and ($propertyGroup == 'configuration')))
											$output .= __omr_outputProperty($propertyLabel, $propertyValue, $outputFormat, 'omrProperty', 2, $nl);
									}
								}
							}
							{ # output end of attribute
								switch($outputFormat) {
									case 'xml': {
										$output .= '</attribute>' . $nl;
										break;
									}
									case 'html':
									default: {
									}
								} # end-of-switch
							}
						} # end-of-foreach
					}
					{ # output end of attributes
						switch($outputFormat) {
							case 'xml': {
								$output .= '</attributes>' . $nl;
								break;
							}
							case 'html':
							default:
						}
					}
				} # end-of-if
			}
			{ # output relation types
				if ($withRelationTypes) {
					{ # retrieve (build) list of relation types
						$relationTypesAsStart = $objectType->getRelationTypes_asStart();
						$relationTypesAsEnd = $objectType->getRelationTypes_asEnd();
						$relationTypes = array_merge($relationTypesAsStart, $relationTypesAsEnd);
					}
					{ # output begin of relations types
						switch($outputFormat) {
							case 'xml': {
								$output .= '<relationTypes>' . $nl;
								break;
							}
							case 'html':
							default: {
								$output .= '<tr><td></td><td colspan="4" class="omrRelationTypes" style="border: 1px solid #000;"><h2>Relation Types</h2></td></tr>' . $nl;
							}
						} # end-of-switch
					}
					{ # walk through list of relation types and produce output
						foreach($relationTypes as $relationType) {
							{ # output begin of relation type
								switch($outputFormat) {
									case 'xml': {
										$output .= '<relationType name="' . $relationType->name() . '">' . $nl;
										break;
									}
									case 'html':
									default: {
										$output .= '<tr><td colspan="2"></td><td colspan="3" class="omrRelationTypes" style="border: 1px solid #000;"><h3>' . $relationType->name() . '</h3></td></tr>' . $nl;
									}
								} # end-of-switch
							}
							{ # output properties
								$output .= __omr_outputProperty('Name', $relationType->name(), $outputFormat, 'omrProperty', 2, $nl);
								$output .= __omr_outputProperty('Name of inverse', $relationType->nameOfInverse(), $outputFormat, 'omrProperty', 2, $nl);
								$output .= __omr_outputProperty('UUID', $relationType->RT_UUID(), $outputFormat, 'omrProperty', 2, $nl);
								$output .= __omr_outputProperty('Description', $relationType->description(), $outputFormat, 'omrProperty', 2, $nl);
								$output .= __omr_outputProperty(
									'Starts at OT', 
									($relationType->Start_OT_UUID()!=''?
										$relationType->Start_OT()->name().' ('.$relationType->Start_OT_UUID().')':
										''), 
									$outputFormat, 
									'omrProperty', 
									2,
									$nl
								);
								$output .= __omr_outputProperty(
									'Ends at OT', 
									($relationType->End_OT_UUID()!=''?
										$relationType->End_OT()->name().' ('.$relationType->End_OT_UUID().')':
										''), 
									$outputFormat, 
									'omrProperty', 
									2,
									$nl
								);
								$output .= __omr_outputProperty('Cardinality', $relationType->cardinality(), $outputFormat, 'omrProperty', 2, $nl);
							}
							{ # output attributes
								if ($withAttributesOfRelationTypes) {
									{ # retrieve list of attributes
										$attributes = $relationType->getAttributes();
									}
									{ # output begin of attributes
										switch($outputFormat) {
											case 'xml': {
												$output .= '<attributes>' . $nl;
												break;
											}
											case 'html':
											default: {
												$output .= '<tr><td colspan="2"></td><td colspan="3" class="omrAttributes" style="border: 1px solid #000;"><h4>Attributes</h4></td></tr>' . $nl;
											}
										} # end-of-switch
									}
									{ # walk through list of attributes and out them
										foreach($attributes as $attribute) {
											{ # output begin of attribute
												switch($outputFormat) {
													case 'xml': {
														$output .= '<attribute name="' . $attribute->name() . '">' . $nl;
														break;
													}
													case 'html':
													default: {
														$output .= '<tr><td colspan="3"></td><td colspan="3" class="omrAttributes" style="border: 1px solid #000;"><h5>' . $attribute->name() . '</h5></td></tr>' . $nl;
													}
												} # end-of-switch
											}
											{ # retrieve properties and output them
												$properties = $attribute->forReports();
												foreach ($properties as $propertyGroup=>$propertiesInGroup) {
													foreach ($propertiesInGroup as $propertyLabel=>$propertyValue) {
														if (($propertyGroup == 'common') 
														or ($withEditingConstrains and ($propertyGroup == 'constrains'))
														or ($withCardinalityInformation and ($propertyGroup == 'cardinality'))
														or ($withConfiguration and ($propertyGroup == 'configuration')))
															$output .= __omr_outputProperty($propertyLabel, $propertyValue, $outputFormat, 'omrProperty', 3, $nl);
													}
												}
											}
											{ # output end of attribute
												switch($outputFormat) {
													case 'xml': {
														$output .= '</attribute>' . $nl;
														break;
													}
													case 'html':
													default: {
													}
												} # end-of-switch
											}
										} # end-of-foreach
									}
									{ # output end of attributes
										switch($outputFormat) {
											case 'xml': {
												$output .= '</attributes>' . $nl;
												break;
											}
											case 'html':
											default:
										}
									}
								} # end-of-if
							}
							{ # output end of relation type
								switch($outputFormat) {
									case 'xml': {
										$output .= '</relationType>' . $nl;
										break;
									}
									case 'html':
									default:
								}
							}
						} # end-of-foreach
					}
					{ # output end of relationTypes
						switch($outputFormat) {
							case 'xml': {
								$output .= '</relationTypes>' . $nl;
								break;
							}
							case 'html':
							default:
						}
					}
				} # end-of-if
			}
			{ # output end of object type
				switch($outputFormat) {
					case 'xml':
						$output .= '</objectType>' . $nl;
						break;
					case 'html':
					default:
				} # end-of-switch
			}
		} # end-of-foreach
	}
	{ # complete output
		switch($outputFormat) {
			case 'xml':
				$output .= ''
					. '</objectTypes>' . $nl
					. '</objectModelReport>';
				break;
			case 'html':
			default:
				$output .= '</table>';
		} # end-of-switch
	}
	{ # encode
		echo ( json_encode($output) );
	}

	
	function __omr_outputProperty ($name, $value, $outputFormat, $class, $level, $nl) {
		/** Outputs one property regarding its data type.
		 * @return string
		 */
		switch($outputFormat) {
			case 'xml':
				if (is_bool($value)) {	
					$outputValue = ($value?'yes':'no');
				}
				elseif (is_numeric($value)) {	
					$outputValue = $value;
				}
				elseif (empty($value)) {
					$outputValue = '';
				}
				elseif (is_array($value)) {
					$outputValue = '<values>';
					foreach($value as $singleValue) {
						$outputValue .= '<value>' . $singleValue . '</value>';
					}
					$outputValue .= '<values>';
				}
				else {
					$outputValue = $value;
				}
				return ('<' . $name . '>' . $value . '</' . $name . '>' . $nl);
				break;
			case 'html':
			default: {
				if (is_bool($value)) {	
					$outputValue = ($value?'yes':'no');
				}
				elseif (is_numeric($value)) {	
					$outputValue = $value;
				}
				elseif (empty($value)) {
					$outputValue = '';
				}
				elseif (is_array($value)) {
					$outputValue = '<ul><li>'.implode('</li><li>', $value) .'</li></ul>';
				}
				else {
					$outputValue = htmlentities($value, ENT_NOQUOTES, 'UTF-8');
				}
				return ( ''
					. '<tr class="' . $class. '">'
					. ($level?'<td colspan="' . ($level) . '"></td>':'')
					. '<td colspan="' . (4-$level). '" style="border: 1px solid #000; font-weight:bold">' . $name . '</td><td style="border: 1px solid #000;">' . $outputValue . '</td>'
					. '</tr>' 
					. $nl
				);
			}
		} # end-of-switch
	} # end-of-function __omr_outputProperty
	
	
?>