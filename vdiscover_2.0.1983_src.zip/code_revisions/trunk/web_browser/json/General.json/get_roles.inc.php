<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	if (is_null($objectType = $backend->getObjectType('10000000-1000-1000-1000-00000000000e'))) {
		throw new Exception('Object type with UUID = "'.$OT_UUID.'" not found.');
	}
	$objects = $objectType->getObjects();
	$objects2 = array();
	foreach($objects as $object) {
		$object2 = $object->toArray();
		$objects2[] = $object2;
	}
	{ # answer
		$output = array(
			'identifier'	=> 'O_UUID',
			'label'			=> 'O_UUID',
			'items'			=> $objects2
		);
		echo json_encode($output);
	}

						
?>