<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	$errorCode = ''; # a brief string that tells the client about the problem

	{ # Get parameters
		$name = sanitize_string($_POST, 'name', $_GET);	
		$username = sanitize_string($_POST, 'username', $_GET);	
		$password = sanitize_string($_POST, 'password', $_GET);	
		$oldPassword = sanitize_string($_POST, 'currentPassword', $_GET);	
		$locale	= sanitize_string($_POST, 'locale', $_GET);
		$language = '';
		$country = '';
		if ($locale!='default') {
			$localeArray = explode('-', $locale);
			$language = $localeArray[0];
			$country = $localeArray[1];
		}
	}
	
	{ # Load object for current user
		if (is_null($userObject = $backend->currentUser('object'))) {
			throw new developerError('Could not load object for current user.');
		}
	}
	{ # Check oldPassword if "password" exists
		if (empty($errorCode)) {
			if (!empty($password)) {
				{ # check if password of current user matches given password
					$sql = '
						SELECT
							value_tinytext_1 
						FROM attributevalue
						WHERE (OR_kind = \'O\')
						  AND (versionType = \'c\')
						  AND (OR_v_UUID = '.$dbLayer->quoteSmart($backend->currentUser('v_UUID')).')
						  AND (A_UUID = '.$dbLayer->quoteSmart(cSystem::$sysObject_Persons_A_Password_UUID).')
					';
					$res = $dbLayer->readQuery($sql);
					if ( ! $row = $res->fetchRow() ) {
						$errorCode = 'currentPWDinvalid';
					}
					if (cPasswordAttribute::encrypt($oldPassword) != $row['value_tinytext_1']) {
						$errorCode = 'currentPWDinvalid';
					}
				}
			}
		}
	}
	if (empty($errorCode)) {
		{ # Load attribute "name" to do validation of input
			if (is_null($attribute = $backend->getAttribute(cSystem::$sysObject_Persons_A_Name_UUID))) {
				throw new developerError('Could not load attribute for Person::Name.');
			}
			if (!$attribute->isValidValue('value_text', $name)) {
				throw new incorrectInputDataException('Name is invalid.');
			}
		}
		{ # Load attribute for "username" to do validation of input
			if (is_null($attribute = $backend->getAttribute(cSystem::$sysObject_Persons_A_Username_UUID))) {
				throw new developerError('Could not load attribute for Person::Username.');
			}
			if (empty($username) or (strlen($username) < 3) or !$attribute->isValidValue('value_text', $username)) {
				throw new incorrectInputDataException('Username is invalid.');
			}
			{ # Check if username already exists. If so, then return an error.
				$sql = '
					SELECT
						OR_v_UUID 
					FROM attributevalue
					WHERE (OR_kind = \'O\')
					  AND (OR_v_UUID <> ' . $dbLayer->quoteSmart($backend->currentUser('v_UUID')) . ')
					  AND (versionType = \'c\')
					  AND (A_UUID = ' . $dbLayer->quoteSmart(cSystem::$sysObject_Persons_A_Username_UUID) . ')
					  AND (value_tinytext_1 = ' . $dbLayer->quoteSmart($username) . ')
				';
				$res = $dbLayer->readQuery($sql);
				if ($row = $res->fetchRow()) {
					throw new incorrectInputDataException('Username already exists.');
				}
			}
		}
		{ # Load attribute for "password" to do validation of input
			if (is_null($attribute = $backend->getAttribute(cSystem::$sysObject_Persons_A_Password_UUID))) {
				throw new developerError('Could not load attribute for Person::Password.');
			}
			if (!empty($password) and !$attribute->isValidValue('value_password', $password)) {
				throw new incorrectInputDataException('Password is invalid.');
			}
		}
		{ # Load attribute for "language" to do validation of input
			if (is_null($attribute = $backend->getAttribute(cSystem::$sysObject_Persons_A_Language_UUID))) {
				throw new developerError('Could not load attribute for Person::Password.');
			}
			if (!$attribute->isValidValue('value_text', $language)) {
				throw new incorrectInputDataException('Language is invalid.');
			}
		}
		{ # Load attribute for "country" to do validation of input
			if (is_null($attribute = $backend->getAttribute(cSystem::$sysObject_Persons_A_Country_UUID))) {
				throw new developerError('Could not load attribute for Person::Country.');
			}
			if (!$attribute->isValidValue('value_text', $country)) {
				throw new incorrectInputDataException('Country is invalid.');
			}
		}
		{ # Specify the structure "attributeSetValuesAsArray" containing the new values
			{ # name
				$attributeSetValuesAsArray[cSystem::$sysObject_Persons_A_Name_UUID] = array(
					'name' => array(
						'A_UUID' => cSystem::$sysObject_Persons_A_Name_UUID,
						'UUID' => 'name',
						'positionOfAttribute' => 1,
						'positionOfValue' => 1,
						'value_text' => $name 
					)
				);
				$sessionName = $name;
			}
			{ # username
				$attributeSetValuesAsArray[cSystem::$sysObject_Persons_A_Username_UUID] = array(
					'username' => array(
						'A_UUID' => cSystem::$sysObject_Persons_A_Username_UUID,
						'UUID' => 'username',
						'positionOfAttribute' => 1,
						'positionOfValue' => 1,
						'value_text' => $username 
					)
				);
				$sessionUsername = $username;
			}
			{ # password
				if (!empty($password)) {
					$attributeSetValuesAsArray[cSystem::$sysObject_Persons_A_Password_UUID] = array(
						'password' => array(
							'A_UUID' => cSystem::$sysObject_Persons_A_Password_UUID,
							'UUID' => 'password',
							'positionOfAttribute' => 1,
							'positionOfValue' => 1,
							'new_password' => $password 
						)
					);
				}
			}
			{ # language
				if (!empty($language)) {
					$attributeSetValuesAsArray[cSystem::$sysObject_Persons_A_Language_UUID] = array(
						'language' => array(
							'A_UUID' => cSystem::$sysObject_Persons_A_Language_UUID,
							'UUID' => 'language',
							'positionOfAttribute' => 1,
							'positionOfValue' => 1,
							'value_text' => $language 
						)
					);
					$sessionLanguage = $language;
				}
				else {
					$attributeSetValuesAsArray[cSystem::$sysObject_Persons_A_Language_UUID] = array();
					$sessionLanguage = null;
				}
			}
			{ # country
				if (!empty($country)) {
					$attributeSetValuesAsArray[cSystem::$sysObject_Persons_A_Country_UUID] = array(
						'country' => array(
							'A_UUID' => cSystem::$sysObject_Persons_A_Country_UUID,
							'UUID' => 'country',
							'positionOfAttribute' => 1,
							'positionOfValue' => 1,
							'value_text' => $country 
						)
					);
					$sessionCountry = $country;
				}
				else {
					$attributeSetValuesAsArray[cSystem::$sysObject_Persons_A_Country_UUID] = array();
					$sessionCountry = null;
				}
			}
		}
		{ # Save modifications on the attributes.
			$userObject->setAttributeValuesOfAnAttributeSet(array_keys($attributeSetValuesAsArray), $attributeSetValuesAsArray);
		}
		{ # Reset profile in session
			if (!is_null($name)) {
				$_SESSION['user_name'] = $name;
			}
			if (!is_null($username)) {
				$_SESSION['user_username'] = $username;
			}
			if (!is_null($language)) {
				$_SESSION['user_language'] = $language;
			}
			if (!is_null($country)) {
				$_SESSION['user_country'] = $country;
			}
		}
	}
	{ # Output the result
		if (empty($errorCode)) {
			echo json_encode(array('result' => true));
		} else {
			echo json_encode(array('error' => $errorCode));
		}
	}

						
?>