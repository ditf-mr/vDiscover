<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameters
		# no parameter needed
	}
	{ # output the result
		if ( ( $backend->currentUser('language') == '' ) || ($backend->currentUser('country') == '') )
			$locale = 'default';
		else
			$locale = $backend->currentUser('language').'-'.$backend->currentUser('country');
	
		$answer = array(
			'name'		=> $backend->currentUser('name'),
			'username'	=> $backend->currentUser('username'),
			
			'language'	=> $backend->currentUser('language'),
			'country'	=> $backend->currentUser('country'),
			
			'locale'	=> $locale,
		);
		echo json_encode($answer);
	}

						
?>