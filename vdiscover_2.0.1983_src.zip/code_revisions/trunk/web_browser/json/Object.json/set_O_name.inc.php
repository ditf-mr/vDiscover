<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		if (is_null($object = _getCObjectFromParameter())) {
			throw new instanceNotFoundException(_object_);
		}
		$name = sanitize_string($_POST, 'name');
	}
	{ # check access permissions
		if (! $backend->mayWrite_OT($object->OT_UUID())) {
			throw new writeViolationException($object);
		}
	}
	// $object->archive();
	$object->setName($name);
	$object->update();
	{ # answer
		$output = $object->toArray();
		echo json_encode($output);
	}


?>