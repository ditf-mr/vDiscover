<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		if (is_null($object = _getCObjectFromParameter())) {
			throw new instanceNotFoundException(_object_);
		}
		$VT_UUID = sanitize_string($_POST, 'VT_UUID', $_GET);
		if (is_null($viewType = $backend->getViewType($VT_UUID))) {
			throw new instanceNotFoundException(viewType, $VT_UUID);
		}
	}
	{ # check access permissions
		if (! $backend->mayRead_OT($object->OT_UUID())) {
			throw new readViolationException($object);
		}
	}
	{ # get attribute value sets
		$attributeValueSets = $object->getAttributeValueSets($viewType->getAttributeList());
		$attributeValueSets2 = array();
		foreach($attributeValueSets as $attributeValueSet) {
			$attributeArray = $attributeValueSet['attribute']->toArray();
			$attributeValues = $attributeValueSet['values'];
			$attributeValueAsArray = array();
			foreach($attributeValues as $attributeValue) {
				$attributeValueAsArray[$attributeValue->AV_UUID()] = $attributeValue->toArray();
			}
			$attributeValueSets2[$attributeArray['UUID']] = array(
				'attribute'	=> $attributeArray, 
				'values'	=> $attributeValueAsArray
			);
		}			
	}
	$viewType2 = $viewType->toArray();
	{ # sort the attribute value set according to the attributes in the view
		if (isset($viewType2['attributeList'])) {
			$attributeValueSets3 = array();
			foreach($viewType2['attributeList'] as $A_UUID) {
				$attributeValueSets3[$A_UUID] = $attributeValueSets2[$A_UUID];
			}
			$attributeValueSets2 = $attributeValueSets3;
		}
	}
	{ # save access history
		cAccessHistory::add($object, $viewType);
	}
	{ # answer
		$output = array( 
			'viewType'				=> $viewType2,
			'attributeValueSets'	=> $attributeValueSets2 
		);
		echo json_encode($output);
	}
	

?>