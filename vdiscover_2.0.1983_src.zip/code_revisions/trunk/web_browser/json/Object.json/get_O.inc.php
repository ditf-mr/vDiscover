<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		if (is_null($object = _getCObjectFromParameter())) {
			throw new instanceNotFoundException(_object_);
		}
	}
	{ # check access permissions
		if (! $backend->mayRead_OT($object->OT_UUID())) {
			throw new readViolationException($object);
		}
	}
	{ # answer
		$output = $object->toArray();
		$attributes = $object->getAttributes();
		foreach($attributes as $attribute) {
			$output['attributes'][] = $attribute->toArray();
		}			
		$viewTypes = $object->getViewTypes();
		foreach($viewTypes as $viewType) {
			$output['viewTypes'][] = $viewType->toArray();
		}		
		echo json_encode($output);
	}


?>