<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # some preparation works
		{ # include CBR classes
			// echo realpath('.');  
			include_once('./../common_plugins/DITF_CBR/cCBR.php');
		}
	global $backend;
	}

	{ # get parameters
		$OT_UUID 	= sanitize_string($_POST, 'OT_UUID', 	$_GET);
		$O_v_UUID 	= sanitize_string($_POST, 'O_v_UUID', 	$_GET);
		$VT_UUID 	= sanitize_string($_POST, 'VT_UUID', 	$_GET);
		$CBRQuery 	= json_decode(sanitize_string($_POST, 'CBRQuery', $_GET));
	}
	$CBRQuery->CBRConfig->affectedOT = $OT_UUID;	
	$CBRQuery->CBRConfig->influenceMatrix[0]->type = 1;

	{ # clone original Object into working object
		$object = $backend->getObject($O_v_UUID);
		$workingObject = $object->duplicate($object->name().'_duplicate');
	}
	
	{ # store predefined values
		foreach ( $CBRQuery->valsForSimilarityAssessment as $A_UUID => $attrValue){
			cAttributeValue::deleteAttributeValuesBy_A_UUID_OR_v_UUID($A_UUID, $workingObject->O_v_UUID());

			$attrValueArray = (array)$attrValue;
			$attrValueArray['positionOfValue']= 0;
			$attributeValuesAsArray = array();
			$newAttributeValue = cAttributeValue::newAttributeValueFromArray(
				$workingObject->O_v_UUID(), 
				'O', 
				$A_UUID,
				$attrValueArray
			);
			$newAttributeValue->save();
			unset($newAttributeValue);
		}
	}
	
	{ # CBR
		$cbrResult = new cCBR( $workingObject->O_v_UUID() , json_encode($CBRQuery->CBRConfig) );
	}

	$output = array();
	{ # prepare answer
		foreach ($cbrResult->CBRconfig()->influenceMatrix() as $key => $influenceSet){
			foreach($influenceSet->getAffectedAttrList() as $A_UUID){
				$AV = current($cbrResult->suggestion()->getAttributeValues($A_UUID));
				$output[$A_UUID] = array ( $AV->UUID() => $AV->toArray() ) ;
			}
		}
	}
	
	$workingObject->delete();
	
	{ # answer
		echo json_encode($output);
	}

?>