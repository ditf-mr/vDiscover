<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # max number of recursive function calls
		$maxNumberOfFunctionCalls = 5;
	}


	function __get_O_view2_generateView ( $O_v_UUID, $VT_UUID, $iterationSteps ) {
		/** Function can be called recursively. Function stops (breaks) after a specific number
		 * of interations.
		 * @param $O_v_UUID \ref UUID-string. The UUID (O_v_UUID) of the cObject.
		 * @param $VT_UUID \ref UUID-string. The UUID (VT_UUID) of the cViewType.
		 * @param $iterationSteps integer. The number of iterations that are still allowed. In
		 *                                 each recursive call of this function, this parameter is
		 *                                 decreased. The function breaks and returns null when
		 *                                 this parameter becomes zero or less.
		 * @return null. On failure. The number of function calls exceeded.
		 * @return array.
		 */
		global $backend;
		{ # exit if maximum number of iterations reached
			if ($iterationSteps <= 0)
				return null;
		}
		if (is_null($object = $backend->getObject($O_v_UUID))) {
			throw new developerException('Object with UUID = "'.$O_v_UUID.'" not found.');
		}
		{ # get relevant view type. This may be inherited, so it depends on the cObjectType.
			{ # get origin of the view type first
				if (is_null($thisViewType = $backend->getViewType($VT_UUID))) {
					throw new modelErrorException('Invalid or missing view type in relation type definition.');
				}
				$origin_VT_UUID = $thisViewType->VT_origin()->VT_UUID();
			}
			if (is_null($viewType = cViewType::getBy_VT_origin_UUID ( $origin_VT_UUID, $object->OT()->OT_UUID() ))) {
				throw new Exception('Inherited View Type of UUID = "'.$origin_VT_UUID.'" not found.');
			}
			{ # load list of needed A_UUIDs
				$attributeList = $viewType->getAttributeList();
			}
		}
		{ # call __get_O_view2_generateAttributeList
			$output = __get_O_view2_generateAttributeList($object->O_v_UUID(), $attributeList, $iterationSteps);
		}
		{ # add information about object
			$output['object'] = $object->toArray();
		}
		{ # add information about view
			$viewType2 = $viewType->toArray();
			{ # sort the attribute value set according to the attributes in the view
				if (isset($viewType2['attributeList'])) {
					$attributeValueSets3 = array();
					foreach($viewType2['attributeList'] as $A_UUID) {
						if (isset($attributeValueSets2[$A_UUID])) {
							$attributeValueSets3[$A_UUID] = $attributeValueSets2[$A_UUID];
						}
					}
					$attributeValueSets2 = $attributeValueSets3;
				}
			}
			{ # add the equation list
				$viewType2['eqSystem'] = $object->OT()->equationSystem();
			}
			$output ['viewType'] = $viewType2;
		}
		return($output);
	} # end-of-function __get_O_view2_generateView


	function __get_O_view2_generateAttributeList ( $O_v_UUID, $A_UUIDs=null, $iterationSteps ) {
		/** Function can be called recursively. Function stops (breaks) after a specific number
		 * of interations.
		 * @param $O_v_UUID \ref UUID-string. The UUID (O_v_UUID) of the cObject.
		 * @param $A_UUIDs array of \ref UUID-string. The list of A_UUIDs of the attributes.
		 *		If empty all attributes will be taken.
		 * @param $iterationSteps integer. The number of iterations that are still allowed. In
		 *		each recursive call of this function, this parameter is decreased. The function 
		 * 		breaks and returns null when this parameter becomes zero or less.
		 * @return null. On failure. The number of function calls exceeded.
		 * @return array.
		 */
		global $backend;
		{ # exit if maximum number of iterations reached
			if ($iterationSteps <= 0)
				return null;
		}
		if (is_null($object = $backend->getObject($O_v_UUID))) {
			throw new developerException('Object with UUID = "'.$O_v_UUID.'" not found.');
		}
		{ # check A_UUIDs
			if (is_array($A_UUIDs)) {
				$attributeList = $A_UUIDs;
			}
			else {
				$attributes = $object->OT()->getAttributes();
				$attributeList = array();
				foreach($attributes as $attribute) {
					$attributeList[] = $attribute->A_UUID();
				}
			}
		}
		{ # check if attribute list is empty
			if (empty($attributeList)) {
				$attributeValueSets2 = array();
			}
			else {
				{ # get attribute value sets
					$attributeValueSets = $object->getAttributeValueSets($attributeList);
				}
				{ # filter and process the attributes
					$attributeValueSets2 = array();
					foreach($attributeValueSets as $attributeValueSet) {
						$attribute = $attributeValueSet['attribute'];
						$attributeValues = $attributeValueSet['values'];
						{ # if the attribute is not in the list of attributes needed, skip it.
							if (! in_array($attribute->A_UUID(), $attributeList)) {
								continue;
							}
						}
						{ # check if the attribute needs a type specific handling, e.g. as cRelationAttribute.
						  # if so, then follow the relation to the end object and retrieve either the
						  # values of an attribute or a view.
							switch ($attribute->kind()) {
								case 'cRelationAttribute':
									{ # the cAttributeValues contains UUIDs of cRelation. end object must be
									  # fetch and the values of the view or attribute list taken.
										$attributeArray = $attribute->toArray();
										{ # get name of end cObjectType
											$endObjectType = $backend->getObjectType($attributeArray['End_OT_UUID']);
											$attributeArray['End_OT_name'] = is_null($endObjectType)?'':$endObjectType->name();
										}
										{ # get (configuration information of ) attributes
											$relationType = $backend->getRelationType($attribute->selected_RT_UUID());
											$relationAttributes = $relationType->getAttributes();
											$relationAttributes2 = array();
											foreach($relationAttributes as $r_A_UUID => $relationAttribute) {
												$relationAttributes2[$r_A_UUID] = $relationAttribute->toArray();
											}
											$attributeArray['relationAttributes'] = $relationAttributes2;
										}
										$attributeValueAsArray = array();
										switch ($attribute->showWhat()) {
											case 'V':
												{ # walk through all (virtual) attribute values and collect end object information
													foreach($attributeValues as $attributeValue) {
														$attributeValueAsArray[$attributeValue->AV_UUID()] = $attributeValue->toArray();
														$relation = $backend->getRelation($attributeValue->value_UUID());
														{ # collect attribute values of relation
															$relationAttributeValueSets = $relation->getAttributeValueSets();
															$relationAttributeValueSets2 = array();
															foreach($relationAttributeValueSets as $relationAttributeValueSet) {
																$relationAttribute = $relationAttributeValueSet['attribute'];
																$relationAttributeArray = $relationAttribute->toArray();
																$relationAttributeValues = $relationAttributeValueSet['values'];
																$relationAttributeValueAsArray = array();
																foreach($relationAttributeValues as $relationAttributeValue) {
																	$relationAttributeValueAsArray[$relationAttributeValue->AV_UUID()] = $relationAttributeValue->toArray();
																}
																$relationAttributeValueSets2[$relationAttributeArray['UUID']] = array(
																	'attribute'	=> $relationAttributeArray,
																	'values'	=> (object)$relationAttributeValueAsArray,
																);
															}
														}
														$attributeValueAsArray[$attributeValue->AV_UUID()]['relationAttributeValueSets'] = $relationAttributeValueSets2;
														{ # retrieve end object of relation
															$endObject = __getEndObject($attribute, $attributeValue, $relation, $object);
														}
														{ # go into recursion
															$next_O_v_UUID = $endObject->O_v_UUID();
															$next_VT_UUID = $attribute->show_UUID();
															$output_atEndObject = __get_O_view2_generateView ( $next_O_v_UUID, $next_VT_UUID, $iterationSteps-1 );
														}
														$attributeValueAsArray[$attributeValue->AV_UUID()]['atEndObject'] = $output_atEndObject;
													}
												}
												break;
											case 'A':
												{ # walk through all (virtual) attribute values and collect end object information
													foreach($attributeValues as $attributeValue) {
														$attributeValueAsArray[$attributeValue->AV_UUID()] = $attributeValue->toArray();
														$relation = $backend->getRelation($attributeValue->value_UUID());
														{ # collect attribute values of relation
															$relationAttributeValueSets = $relation->getAttributeValueSets();
															$relationAttributeValueSets2 = array();
															foreach($relationAttributeValueSets as $relationAttributeValueSet) {
																$relationAttribute = $relationAttributeValueSet['attribute'];
																$relationAttributeArray = $relationAttribute->toArray();
																$relationAttributeValues = $relationAttributeValueSet['values'];
																$relationAttributeValueAsArray = array();
																foreach($relationAttributeValues as $relationAttributeValue) {
																	$relationAttributeValueAsArray[$relationAttributeValue->AV_UUID()] = $relationAttributeValue->toArray();
																}
																$relationAttributeValueSets2[$relationAttributeArray['UUID']] = array(
																	'attribute'	=> $relationAttributeArray,
																	'values'	=> (object)$relationAttributeValueAsArray,
																);
															}
														}
														$attributeValueAsArray[$attributeValue->AV_UUID()]['relationAttributeValueSets'] = $relationAttributeValueSets2;
														{ # retrieve end object of relation
															$endObject = __getEndObject($attribute, $attributeValue, $relation, $object);
														}
														{ # go into recursion
															$next_O_v_UUID = $endObject->O_v_UUID();
															$next_A_UUID = $attribute->show_UUID();
															$output_atEndObject = __get_O_view2_getAttribute ( $next_O_v_UUID, $next_A_UUID, $iterationSteps-1 );
														}
														$attributeValueAsArray[$attributeValue->AV_UUID()]['atEndObject'] = $output_atEndObject;
													}
												}
												break;
											case 'N':
											default:
												{ # walk through all (virtual) attribute values and collect end object information
													foreach($attributeValues as $attributeValue) {
														$attributeValueAsArray[$attributeValue->AV_UUID()] = $attributeValue->toArray();
														$relation = $backend->getRelation($attributeValue->value_UUID());
														{ # collect attribute values of relation
															$relationAttributeValueSets = $relation->getAttributeValueSets();
															$relationAttributeValueSets2 = array();
															foreach($relationAttributeValueSets as $relationAttributeValueSet) {
																$relationAttribute = $relationAttributeValueSet['attribute'];
																$relationAttributeArray = $relationAttribute->toArray();
																$relationAttributeValues = $relationAttributeValueSet['values'];
																$relationAttributeValueAsArray = array();
																foreach($relationAttributeValues as $relationAttributeValue) {
																	$relationAttributeValueAsArray[$relationAttributeValue->AV_UUID()] = $relationAttributeValue->toArray();
																}
																$relationAttributeValueSets2[$relationAttributeArray['UUID']] = array(
																	'attribute'	=> $relationAttributeArray,
																	'values'	=> (object)$relationAttributeValueAsArray,
																);
															}
														}
														$attributeValueAsArray[$attributeValue->AV_UUID()]['relationAttributeValueSets'] = $relationAttributeValueSets2;
														{ # retrieve end object of relation
															$endObject = __getEndObject($attribute, $attributeValue, $relation, $object);
														}
														{ # use name of endObject, no recursion needed
															$output_atEndObject = array(
																'object'	=> $endObject->toArray()
															);
														}
														$attributeValueAsArray[$attributeValue->AV_UUID()]['atEndObject'] = $output_atEndObject;
													}
												}
												break;
										} # end-of-switch ($attribute->showWhat())
									}
									break;
								# add additional attribute type specific handling here ***
								default:
									{ # handle any "standard" attribute type
										$attributeArray = $attribute->toArray();
										// $attributeValues = $attributeValueSet['values'];
										$attributeValueAsArray = array();
										foreach($attributeValues as $attributeValue) {
											$attributeValueAsArray[$attributeValue->AV_UUID()] = $attributeValue->toArray();
										}
									}
							} # end-of-switch ($attribute->kind())
							$attributeValueSets2[$attributeArray['UUID']] = array(
								'attribute'	=> $attributeArray,
								'values'	=> (object)$attributeValueAsArray,
							);
						}
					} # end-of-foreach
				}
			}
		}
		{ # answer
			$output = array(
				'attributesWithValueSets'	=> $attributeValueSets2
			);
		}
		return ( $output );
	} # end-of-function __get_O_view2_generateAttributeList


	function __get_O_view2_getAttribute ( $O_v_UUID, $A_UUID, $iterationSteps ) {
		/** Function can be called recursively. Function stops (breaks) after a specific number
		 * of interations.
		 * @param $O_v_UUID \ref UUID-string. The UUID (O_v_UUID) of the cObject.
		 * @param $A_UUID \ref UUID-string. The UUID (A_UUID) of the cAttribute. This might be the
		 *                                  A_origin_UUID of the attribute.
		 * @param $iterationSteps integer. The number of iterations that are still allowed. In
		 *                                 each recursive call of this function, this parameter is
		 *                                 decreased. The function breaks and returns null when
		 *                                 this parameter becomes zero or less.
		 * @return null. On failure. The number of function calls exceeded.
		 * @return array.
		 */
		global $backend;
		{ # exit if maximum number of iteations reached
			if ($iterationSteps <= 0)
				return null;
		}
		if (is_null($object = $backend->getObject($O_v_UUID))) {
			throw new Exception('Object with UUID = "'.$O_v_UUID.'" not found.');
		}
		{ # get relevant attribute. This may be inherited, so it depends on the cObjectType.
			{ # get origin of the attribute first
				if (is_null($thisAttribute = $backend->getAttribute($A_UUID))) {
					throw new modelErrorException('Invalid or missing attribute in relation type definition.');
				}
				$origin_A_UUID = $thisAttribute->A_origin()->A_UUID();
			}
			if (is_null($attribute = cAttribute::getBy_A_origin_UUID($origin_A_UUID, $object->OT_UUID()))) {
				throw new Exception('Inherited Attribute of UUID = "'.$origin_A_UUID.'" not found.');
			}
		}
		{ # check if the attribute needs a type specific handling, e.g. as cRelationAttribute.
		  # if so, then follow the relation to the end object and retrieve either the
		  # values of an attribute or a view.
			switch ($attribute->kind()) {
				case 'cRelationAttribute':
					{ # the cAttributeValues contain UUIDs of cRelation. end object must be
					  # fetch and the values of the view or attribute list taken.
						$attributeArray = $attribute->toArray();
						{ # get name of end cObjectType
							$endObjectType = $backend->getObjectType($attributeArray['End_OT_UUID']);
							$attributeArray['End_OT_name'] = is_null($endObjectType)?'':$endObjectType->name();
						}
						{ # get (configuration information of ) attributes
							$relationType = $backend->getRelationType($attribute->selected_RT_UUID());
							$relationAttributes = $relationType->getAttributes();
							$relationAttributes2 = array();
							foreach($relationAttributes as $r_A_UUID => $relationAttribute) {
								$relationAttributes2[$r_A_UUID] = $relationAttribute->toArray();
							}
							$attributeArray['relationAttributes'] = $relationAttributes2;
						}
						$attributeValues = $object->getAttributeValues($attribute->A_UUID());
						$attributeValueAsArray = array();
						switch ($attribute->showWhat()) {
							case 'V':
								{ # walk through all (virtual) attribute values and collect end object information
									foreach($attributeValues as $attributeValue) {
										$attributeValueAsArray[$attributeValue->AV_UUID()] = $attributeValue->toArray();
										$relation = $backend->getRelation($attributeValue->value_UUID());
										{ # collect attribute values of relation
											$relationAttributeValueSets = $relation->getAttributeValueSets();
											$relationAttributeValueSets2 = array();
											foreach($relationAttributeValueSets as $relationAttributeValueSet) {
												$relationAttribute = $relationAttributeValueSet['attribute'];
												$relationAttributeArray = $relationAttribute->toArray();
												$relationAttributeValues = $relationAttributeValueSet['values'];
												$relationAttributeValueAsArray = array();
												foreach($relationAttributeValues as $relationAttributeValue) {
													$relationAttributeValueAsArray[$relationAttributeValue->AV_UUID()] = $relationAttributeValue->toArray();
												}
												$relationAttributeValueSets2[$relationAttributeArray['UUID']] = array(
													'attribute'	=> $relationAttributeArray,
													'values'	=> (object)$relationAttributeValueAsArray,
												);
											}
										}
										$attributeValueAsArray[$attributeValue->AV_UUID()]['relationAttributeValueSets'] = $relationAttributeValueSets2;
										{ # retrieve end object of relation
											$endObject = __getEndObject($attribute, $attributeValue, $relation, $object);
										}
										{ # go into recursion
											$next_O_v_UUID = $endObject->O_v_UUID();
											$next_VT_UUID = $attribute->show_UUID();
											$output_atEndObject = __get_O_view2_generateView ( $next_O_v_UUID, $next_VT_UUID, $iterationSteps-1 );
										}
										$attributeValueAsArray[$attributeValue->AV_UUID()]['atEndObject'] = $output_atEndObject;
									}
								}
								break;
							case 'A':
								{ # walk through all (virtual) attribute values and collect end object information
									foreach($attributeValues as $attributeValue) {
										$attributeValueAsArray[$attributeValue->AV_UUID()] = $attributeValue->toArray();
										$relation = $backend->getRelation($attributeValue->value_UUID());
										{ # collect attribute values of relation
											$relationAttributeValueSets = $relation->getAttributeValueSets();
											$relationAttributeValueSets2 = array();
											foreach($relationAttributeValueSets as $relationAttributeValueSet) {
												$relationAttribute = $relationAttributeValueSet['attribute'];
												$relationAttributeArray = $relationAttribute->toArray();
												$relationAttributeValues = $relationAttributeValueSet['values'];
												$relationAttributeValueAsArray = array();
												foreach($relationAttributeValues as $relationAttributeValue) {
													$relationAttributeValueAsArray[$relationAttributeValue->AV_UUID()] = $relationAttributeValue->toArray();
												}
												$relationAttributeValueSets2[$relationAttributeArray['UUID']] = array(
													'attribute'	=> $relationAttributeArray,
													'values'	=> (object)$relationAttributeValueAsArray,
												);
											}
										}
										$attributeValueAsArray[$attributeValue->AV_UUID()]['relationAttributeValueSets'] = $relationAttributeValueSets2;
										{ # retrieve end object of relation
											$endObject = __getEndObject($attribute, $attributeValue, $relation, $object);
										}
										{ # go into recursion
											$next_O_v_UUID = $endObject->O_v_UUID();
											$next_A_UUID = $attribute->show_UUID();
											$output_atEndObject = __get_O_view2_getAttribute ( $next_O_v_UUID, $next_A_UUID, $iterationSteps-1 );
										}
										$attributeValueAsArray[$attributeValue->AV_UUID()]['atEndObject'] = $output_atEndObject;
									}
								}
								break;
								case 'N':
								default:
									{ # walk through all (virtual) attribute values and collect end object information
										foreach($attributeValues as $attributeValue) {
											$attributeValueAsArray[$attributeValue->AV_UUID()] = $attributeValue->toArray();
											$relation = $backend->getRelation($attributeValue->value_UUID());
											{ # collect attribute values of relation
												$relationAttributeValueSets = $relation->getAttributeValueSets();
												$relationAttributeValueSets2 = array();
												foreach($relationAttributeValueSets as $relationAttributeValueSet) {
													$relationAttribute = $relationAttributeValueSet['attribute'];
													$relationAttributeArray = $relationAttribute->toArray();
													$relationAttributeValues = $relationAttributeValueSet['values'];
													$relationAttributeValueAsArray = array();
													foreach($relationAttributeValues as $relationAttributeValue) {
														$relationAttributeValueAsArray[$relationAttributeValue->AV_UUID()] = $relationAttributeValue->toArray();
													}
													$relationAttributeValueSets2[$relationAttributeArray['UUID']] = array(
														'attribute'	=> $relationAttributeArray,
														'values'	=> (object)$relationAttributeValueAsArray,
													);
												}
											}
											$attributeValueAsArray[$attributeValue->AV_UUID()]['relationAttributeValueSets'] = $relationAttributeValueSets2;
											{ # retrieve end object of relation
												$endObject = __getEndObject($attribute, $attributeValue, $relation, $object);
											}
											{ # use name of endObject, no recursion needed
												$output_atEndObject = array(
													'object'	=> $endObject->toArray()
												);
											}
											$attributeValueAsArray[$attributeValue->AV_UUID()]['atEndObject'] = $output_atEndObject;
										}
									}
									break;
						} # end-of-switch ($attribute->showWhat())
					}
					break;
				# add additional attribute type specific handling here ***
				default:
					{ # handle any "standard" attribute type
						$attributeArray = $attribute->toArray();
						$attributeValues = $object->getAttributeValues($attribute->A_UUID());
						$attributeValueAsArray = array();
						foreach($attributeValues as $attributeValue) {
							$attributeValueAsArray[$attributeValue->AV_UUID()] = $attributeValue->toArray();
						}
					}
			} # end-of-switch ($attribute->kind())
			$attributeValueSets2[$attributeArray['UUID']] = array(
				'attribute'	=> $attributeArray,
				'values'	=> (object)$attributeValueAsArray,
			);
		}
		{ # answer
			$output = array(
				'object'	=> $object->toArray(),
				'attributesWithValueSets'	=> $attributeValueSets2 // $attributeValueAsArray
			);
			return ( $output );
		}
	}

	
	function  __getEndObject ( $attribute, $attributeValue, $relation, $object ) {
		/** Function is helper function for the above two ones. It retrieves the end object
		 * of the given relation according to the specifications in the given attribute and 
		 * attributeValue and from the viewpoint of the given object.
		 * @param $attribute cRelationAttribute.
		 * @param $attributeValue cRelationAttributeValue.
		 * @param $relation cRelation.
		 * @param $object cObject.
		 * @return cObject. The end object.
		 */
// if ($attribute->reflexive()) {
// { # check if the object is start or end of the relation
// if ($relation->Start_O_UUID() == $object->O_UUID()) {
// $endObject = $relation->End_O();
// }
// else {
// $endObject = $relation->Start_O();
// }
// }
// }
// else
		if (! $attributeValue->inverse()) {
			$endObject = $relation->End_O();
		}
		else { # inverse relation
			$endObject = $relation->Start_O();
		}
		return ( $endObject );
	} # end-of-function __getEndObject
?>