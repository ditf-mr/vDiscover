<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		$O_UUID = sanitize_string($_POST, 'O_UUID', $_GET);
		if (empty($O_UUID)) {
			$O_UUID = sanitize_string($_POST, 'UUID', $_GET); 
		}
	}
	$O_v_UUID = $backend->O_modified($O_UUID);
	{ # answer
		$output = array(
			'UUID'		=> $O_v_UUID,
			'O_v_UUID'	=> $O_v_UUID
		);
		echo json_encode( $output );
	}


?>