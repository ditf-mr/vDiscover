<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		if (is_null($object = _getCObjectFromParameter())) {
			throw new instanceNotFoundException(_object_);
		}
		$A_UUID = sanitize_string($_POST, 'A_UUID', $_GET); 
		if (is_null($attribute = $backend->getAttribute($A_UUID))) {
			throw new instanceNotFoundException(attribute, $A_UUID);
		}
		$RT_UUID = sanitize_string($_POST, 'RT_UUID', $_GET); 
		if (is_null($relationType = $backend->getRelationType($RT_UUID))) {
			throw new instanceNotFoundException(relationType, $RT_UUID);
		}
		$R_v_UUID = sanitize_string($_POST, 'R_v_UUID', $_GET); 
		if (is_null($relation = $backend->getRelation($R_v_UUID))) {
			throw new instanceNotFoundException(relation, $R_v_UUID);
		}
	}
	{ # check access permissions
		if (! $backend->mayRead_OT($object->OT_UUID())) {
			throw new readViolationException($object);
		}
	}
	{ # get end object of relation
		$End_O = $relation->End_O();
	}
	{ # check access permissions
		if (! $backend->mayRead_OT($End_O->OT_UUID())) {
			throw new readViolationException($End_O);
		}
	}
	{ # get attribute values of end object
		$attributeValues = $End_O->getAttributeValues($attribute->A_UUID());
		$attributeValues2 = array();
		foreach($attributeValues as $attributeValue) {
			$attributeValues2[] = $attributeValue->toArray();
		}
	}
	{ # answer
		$output =  array ( 	
			'attribute'			=> $attribute->toArray(),
			'attributeValues' 	=> $attributeValues2
		);
		echo json_encode($output);
	}
	
	
?>