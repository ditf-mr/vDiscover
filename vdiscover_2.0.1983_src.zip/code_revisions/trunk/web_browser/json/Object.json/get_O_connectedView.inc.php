<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		if (is_null($object = _getCObjectFromParameter())) {
			throw new instanceNotFoundException(_object_);
		}
		$RT_UUID = sanitize_string($_POST, 'RT_UUID', $_GET); 
		if (is_null($relationType = $backend->getRelationType($RT_UUID))) {
			throw new instanceNotFoundException(relationType, $RT_UUID);
		}
		$R_v_UUID = sanitize_string($_POST, 'R_v_UUID', $_GET); 
		if (is_null($relation = $backend->getRelation($R_v_UUID))) {
			throw new instanceNotFoundException(relation, $R_v_UUID);
		}
		$connected_VT_UUID = sanitize_string($_POST, 'VT_UUID', $_GET); 
		if (is_null($viewType = $backend->getViewType($connected_VT_UUID))) {
			throw new instanceNotFoundException(viewType, $connected_VT_UUID);
		}
	}
	{ # check access permissions
		if (! $backend->mayRead_OT($object->OT_UUID())) {
			throw new readViolationException($object);
		}
	}
	{ # get end object of relation
		$End_O = $relation->End_O();
	}
	{ # check access permissions
		if (! $backend->mayRead_OT($End_O->OT_UUID())) {
			throw new readViolationException($End_O);
		}
	}
	{ # get attribute value sets of end object
		$attributeValueSets = $End_O->getAttributeValueSets($viewType->getAttributeList());
		$attributeValueSets2 = array();
		foreach($attributeValueSets as $attributeValueSet) {
			$attributeArray = $attributeValueSet['attribute']->toArray();
			$attributeValues = $attributeValueSet['values'];
			$attributeValueAsArray = array();
			foreach($attributeValues as $attributeValue) {
				$attributeValueAsArray[$attributeValue->AV_UUID()] = $attributeValue->toArray();
			}
			$attributeValueSets2[$attributeArray['UUID']] = array(
				'attribute'	=> $attributeArray, 
				'values'	=> $attributeValueAsArray
			);
		}			
	}	
	$viewType2 = $viewType->toArray();
	{ # sort the attribute value set according to the attributes in the view (if view)
		if (isset($viewType2['attributeList'])) {
			$attributeValueSets3 = array();
			foreach($viewType2['attributeList'] as $A_UUID) {
				$attributeValueSets3[$A_UUID] = $attributeValueSets2[$A_UUID];
			}
			$attributeValueSets2 = $attributeValueSets3;
		}
	}
	{ # answer
		$output = array(
			'End_O_v_UUID'			=> $End_O->toArray(),
			'viewType'				=> $viewType2,
			'attributeValueSets'	=> $attributeValueSets2 
		);
		echo json_encode($output);
	}
	
	
?>