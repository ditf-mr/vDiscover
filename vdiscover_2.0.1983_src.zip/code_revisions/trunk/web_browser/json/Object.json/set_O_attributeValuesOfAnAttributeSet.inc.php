<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		if (is_null($object = _getCObjectFromParameter())) {
			throw new instanceNotFoundException(_object_);
		}
		$activate = sanitize_boolean($_POST, 'activate', $_GET);
		# A_UUIDs should look like this:
		# [A_UUID_1, A_UUID_2, ..., A_UUID_n]
		$A_UUIDs = json_decode(sanitize_string($_POST, 'A_UUIDs', $_GET), true);
		$attributeValues = json_decode(sanitize_string($_POST, 'attributeValues', $_GET), true);
		if (json_last_error() != JSON_ERROR_NONE) {
			throw new incorrectInputDataException('"attributeValues" caused json-syntax-error.');
		}
	}
	{ # check access permissions
		if (! $backend->mayWrite_OT($object->OT_UUID())) {
			throw new writeViolationException($object);
		}
	}
	{ # check if activation is necessary
		if ($activate) {
			$object->activate();
		}
	}
	{ # save current object name to check, if it will be modified by changing 
	  # some attribute values.
		$O_oldName = $object->name(); 
	}
	$done = $object->setAttributeValuesOfAnAttributeSet($A_UUIDs, $attributeValues );
	{ # check if the name has been changed
		$nameIsModified = ($O_oldName != $object->name());
	}
	{ # answer
		$output = array(
			'O_UUID'			=> $object->O_UUID(),
			'O_v_UUID'			=> $object->O_v_UUID(),
			'O_nameIsModified'	=> $nameIsModified, 
			'name'				=> $object->name()
			 );
		echo json_encode($output);
	}


?>