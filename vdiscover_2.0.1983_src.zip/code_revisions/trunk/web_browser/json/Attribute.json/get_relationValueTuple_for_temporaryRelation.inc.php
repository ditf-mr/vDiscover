<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # load relevant functions
		include(realpath(__DIR__).DIRECTORY_SEPARATOR.'../Object.json/get_O_view2_functions.inc.php');
	}
	{ # get parameter (see cRelationAttribute.js)
		$Start_O_v_UUID	= sanitize_string($_POST, 'O_v_UUID', $_GET); 
		$End_O_UUID	= sanitize_string($_POST, 'endObj_O_UUID',$_GET); 
		$A_UUID = sanitize_string($_POST, 'A_UUID', $_GET); 
		$specialCommand = sanitize_string($_POST, 'specialCommand', $_GET); 
		// $ORT_kind = sanitize_string($_POST, 'ORT_kind', $_GET); 
	}
	{ # check parameter
		if (is_null($startObject = $backend->getObject($Start_O_v_UUID))) {
			throw new instanceNotFoundException(object, $Start_O_v_UUID);
		}
		if (is_null($attribute = $backend->getAttribute($A_UUID))) {
			throw new instanceNotFoundException(attribute, $A_UUID);
		}
	}
	{ # check access permissions
		if (! $backend->mayWrite_OT($startObject->OT_UUID())) {
			throw new writeViolationException($startObject);
		}
	}
	{ # check if attribute is a reflexive attribute in reverse direction
		$reverseDirection = ($attribute->reflexive() and $attribute->backIfReflexive());
	}
	{ # process specialCommand
		switch($specialCommand) {
			case '': {
				if (is_null($endObject = $backend->getCurrentObject($End_O_UUID))) {
					throw new instanceNotFoundException(object, $End_O_UUID);
				}
				break;
			}
			case 'duplicate': {
				if (is_null($endObject = $backend->getCurrentObject($End_O_UUID))) {
					throw new instanceNotFoundException(object, $End_O_UUID);
				}
				$endObject = $endObject->duplicate('', cObject::vtTemporary);
				break;
			}
			case 'new': {
				$OT_UUID_ofNewObject = sanitize_string($_POST, 'new_typeUUID', $_GET); 
				if (is_null($endObjectType = $backend->getObjectType($OT_UUID_ofNewObject))) {
					throw new instanceNotFoundException(objectType, $OT_UUID_ofNewObject);
				}
				$endObject = $endObjectType->addObject('', cObject::vtTemporary);
				break;
			}
			default: {
				throw new incorrectInputDataException('Invalid special command "'.$specialCommand.'".');
			}
		}
	}
	{ # check access permissions
		if (! $backend->mayWrite_OT($endObject->OT_UUID())) {
			throw new writeViolationException($endObject);
		}
	}
	{ # retrieve relation type
		$relationType = $attribute->selected_RT();
	}
	{ # check access permissions
		if (! $backend->mayRead_RT($relationType->RT_UUID())) {
			throw new readViolationException($relationType);
		}
	}
	{ # generate UUIDs for virtual relation
		$dummy_R_UUID = 'd_'.cSystem::generateUUID();
		$dummy_R_v_UUID = 'd_'.cSystem::generateUUID();
	}
	{ # create relationAttributeValueSets of virtual existing relation
		{ # get attributes of relation type
			$relationAttributes = $relationType->getAttributes();
		}
		{ # walk through attributes and load corresponding attribute values
			$relationAttributeValueSets = array();
			foreach($relationAttributes as $relationAttribute) {
				$relationAttributeValueSets[$relationAttribute->A_UUID()] = array (
					'attribute' => $attribute->toArray(),
					'values' => (object)array()
				);
			}
		}
	}
	{ # collect all attributes of this object.
		$startObjectAttributes = $startObject->getAttributes();
	}
	{ # init $output
		$output = array();
	}
	{ # walk through all attributes, which is a cRelationAttribute and refer to 
	  # the determined relation type.
		foreach($startObjectAttributes as $startObjectAttribute) {
			if (($startObjectAttribute->kind() == 'cRelationAttribute') 
			and ($startObjectAttribute->selected_RT_UUID() == $relationType->RT_UUID())) {
				if ((!$reverseDirection and (!$startObjectAttribute->reflexive() or !$startObjectAttribute->backIfReflexive()))
				or ($reverseDirection and $startObjectAttribute->reflexive() and $startObjectAttribute->backIfReflexive())){
					{ # generate output of the startObjectAttribute with virtual relation.
						{ # generate output at end object of virtual relation
							switch ($startObjectAttribute->showWhat()) {
								case 'V':
									$atEndObject = __get_O_view2_generateView ( $endObject->O_v_UUID(), $startObjectAttribute->show_UUID(), $maxNumberOfFunctionCalls);
									break;
								case 'A':
									$atEndObject = __get_O_view2_getAttribute ( $endObject->O_v_UUID(), $startObjectAttribute->show_UUID(), $maxNumberOfFunctionCalls);
									break;
								case 'N':
								default:
									$atEndObject = array(
										'object'	=> $endObject->toArray()
									);
							}
						}
						$dummy_AV_UUID = 'd_'.cSystem::generateUUID();
						$dummy_AV_v_UUID = 'd_'.cSystem::generateUUID();
						$output[$startObjectAttribute->A_UUID()] = array(
							$dummy_AV_UUID => array(
								'UUID' => $dummy_AV_v_UUID,
								'changedAt' => cSystem::time(),
								'changedBy' => $backend->currentUser('UUID'),
								'AV_UUID' => $dummy_AV_UUID,
								'AV_v_UUID' => $dummy_AV_v_UUID,
								'A_UUID' => $startObjectAttribute->A_UUID(),
								'OR_v_UUID' => $startObject->O_v_UUID(),
								'OR_kind' => 'O',
								'kind' => $startObjectAttribute->classNameOfValue(),
								'positionOfAttribute' => $startObjectAttribute->positionOfAttribute(),
								'positionOfValue' => ($startObjectAttribute->getLargestPositionOfValue() + 1),
								'value' => $dummy_R_v_UUID,
								'value_UUID' => $dummy_R_v_UUID,
								'relationAttributeValueSets' => $relationAttributeValueSets,
								'atEndObject' => $atEndObject
							)
						);
					}
				}
			}
		}
	}
	echo json_encode($output);

						
?>