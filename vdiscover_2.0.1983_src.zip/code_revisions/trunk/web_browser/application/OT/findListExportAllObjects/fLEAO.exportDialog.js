/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare('application.widgets.OT_findListExportAllObjects.exportDialog',[common.widgets.fixedSizeDialog],{
	'innerWidth'	: 400
	,
	'innerHeight'	: 480
	,
	'constructor' : function() {
		// Your constructor method will be called before the parameters are mixed into the widget, and can be used to initialize arrays, etc.
		this.inherited(arguments);
		
		// some initialisations
		this.widgets 		= {};
		
	} // end of method constructor
	,
	'postMixInProperties' : function () {
		this.inherited(arguments);
	
		// set the dialog title
		this.title= ''
			+ T('fLEAOexportDialog.js/ExportTit_TIT','Export « $[0]» ',[this.OT_name]);
	
	} // end of method postMixInProperties
	,
	'postCreate' : function () {
		// This is typically the workhorse of a custom widget. The widget has 
		// been rendered (but note that sub-widgets in the containerNode have not!). 
		// The widget though may not be attached to the DOM yet so you shouldn't 
		// do any sizing calculations in this method.
		this.inherited(arguments);
			
			// build the main structure of the dialog
		this.widgets.optionsContainer = new dijit.layout.BorderContainer({
			'style' 	: 'width:100%;height:100%;',
			'gutters'	: false
		}).placeAt(this.containerNode);
		
		// create the action bar at the bottom of the dialog
		this.widgets.actionBar = new dijit.layout.ContentPane({
			'region'	: 'bottom',
			'class'		: 'dijitDialogPaneActionBar textRight',
			'style'		: 'padding-top:1em;'
		});
		this.widgets.optionsContainer.addChild(this.widgets.actionBar);

		this.widgets.OkButton = new dijit.form.Button({
			'label' 	: '<img src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/dialog-ok-apply-4.png"/> '
				+T('BTN_OK','OK'),
			'type'		: 'button'
		}).placeAt(this.widgets.actionBar.containerNode);

		// this.connect(this.widgets.OkButton,'onClick','execute');
		this._connects.push(dojo.connect( this.widgets.OkButton,	'onClick', this, 'prepareFile'));
		
		this.widgets.CancelButton = new dijit.form.Button({
			'label' 	: '<img width="12" src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/dialog-cancel-4.png"/> '
				+T('BTN_Cancel','Cancel'),
			'type'		: 'button',
			'style'		: 'margin-right:0;'
		}).placeAt(this.widgets.actionBar.containerNode);
		
		this.widgets.closeButton = new dijit.form.Button({
			'label' 	: '<img width="12" src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/document-close-2.png"/> '
				+T('BTN_Close','Close'),
			'type'		: 'button',
			'style'		: 'margin-right:0;display:none;'
		}).placeAt(this.widgets.actionBar.containerNode);
		
		this._connects.push(dojo.connect( this.widgets.CancelButton,	'onClick', this.parentWidget, 'export_closeDialog'));
		this._connects.push(dojo.connect( this.widgets.closeButtonNode,	'onClick', this.parentWidget, 'export_closeDialog'));
		this._connects.push(dojo.connect( this.widgets.closeButton,	'onClick', this.parentWidget, 'export_closeDialog'));

		// create the main pane of the dialog
		
		this.widgets.mainPane = new dijit.layout.ContentPane({
			'region'	: 'center',
			'style'		: 'padding-right:.5ex;',
		});
		this.widgets.optionsContainer.addChild(this.widgets.mainPane);
		
		this.contentDomNode = dojo.create('DIV', {
			'innerHTML'	: ''
				+'<h3>' + T('fLEAOexportDialog.js/WhatToExport_TXT','What do you want to export?') + '</h3>'
				+'<p>' + T('fLEAOexportDialog.js/YouAreAboutTo_HTM','You are about to export « $[0]» .',[this.OT_name]) + '</p>'
				+((this.selectedObjects)?'<p><span class="onlySelectedObjects"/></span>&nbsp; <span class="clickOn_onlySelectedObjects">' + T('fLEAOexportDialog.js/IWantToExport_HTM','I want to export the <code>$[0]</code> selected ones.',[this.selectedObjects]) +'</span></p>':'' )
				+'<p><label><span class="allObjects"/></span>&nbsp; <span class="clickOn_allObjects">' + T('fLEAOexportDialog.js/ExportAll_HTM','I want to export all (in total <code>$[0]</code>).',[this.allObjects]) + '</span></p>'
				+'<p>&nbsp;</p>'
				+'<p>' + T('fLEAOexportDialog.js/TheExportFileWill_TXT','The export file will contain all currently listed objects with the displayed attribute or column properties.') + '</p>'
				+'<p>&nbsp;</p>'
				+'<h3>' + T('fLEAOexportDialog.js/WhichFileFormat_TXT','Which file format is your favourite one?') + '</h3>'
				+'<ul>'
					+'<li>'
						+'<h4>'
							+ T('fLEAOexportDialog.js/FlatDataStruct_TXT','Flat data structures')
						+'</h4>'
						+'<p><span class="includeHeading_cB"></span>&nbsp; <span class="clickOn_includeHeading_cB">' + T('fLEAOexportDialog.js/InclAttrColHeadings_TXT','Include the attribute/ col names as col headings') +'</span></p>'
						+'<p>' + T('fLEAOexportDialog.js/ChooseFileFormat_TXT','Choose the file format:') + '</p>'
						+'<table class="fullWidth">'
							+'<tr>'
								+'<td width="2%">'
									+'<span class="rB_CSV"></span>'
								+'</td>'
								+'<td>'
									+'<span class="clickOn_rB_CSV">' + T('fLEAOexportDialog.js/FormatCSV_HTM','Character-separated values (<code>*.csv</code>)') + '</span>'
								+'</td>'
							+'</tr>'
							+'<tr>'
								+'<td>'
									+'&nbsp;'
								+'</td>'
								+'<td>'
									+'<table>'
										+'<tr>'
											+'<td class="textRight">'
												+ T('fLEAOexportDialog.js/FieldSepChar_TXT','Field separator char:')
											+'</td>'
											+'<td>'
												+'<span class="fieldSeparatorChar_vTB"></span>'
											+'</td>'
										+'</tr>'
										+'<tr>'
											+'<td class="textRight">'
												+ T('fLEAOexportDialog.js/DecSepChar_TXT','Decimal separator char:')
											+'</td>'
											+'<td>'
												+'<span class="decimalSeparatorChar_vTB"></span>'
											+'</td>'
										+'</tr>'
									+'</table>'
								+'</td>'
							+'</tr>'
							+'<tr>'
								+'<td>'
									+'<span class="rB_XLSX"></span>'
								+'</td>'
								+'<td>'
									+' <span class="clickOn_rB_XLSX">' + T('fLEAOexportDialog.js/Excel2007_HTM','Excel 2007+ (<code>*.xlsx</code>)') +'</span>'
									+ T('fLEAOexportDialog.js/NotImplYet_TXT',' (not implemented, yet)')
								+'</td>'
							+'</tr>'
						+'</table>'
						+'<p>&nbsp; </p>'
					+'</li>'
				+'</ul>'
		}, this.widgets.mainPane.containerNode);
		
		this.radioButtonNameExportRange = Math.uuid();

		if (this.selectedObjects) this.widgets.exportOnlySelected_RB = new dijit.form.RadioButton({
			'name'		: this.radioButtonNameExportRange,
			'checked'	: true,
			'style'		: 'margin-left:1em;',
		}, dojo.query('.onlySelectedObjects', this.contentDomNode ).pop() );
		
		this.widgets.exportAll_RB = new dijit.form[(this.selectedObjects?'RadioButton':'CheckBox')]({
			'name'		: this.radioButtonNameExportRange,
			'checked'	: ((!this.selectedObjects)?true:false),
			'style'		: 'margin-left:1em;',
			'disabled'	: ((!this.selectedObjects)?true:false)
		}, dojo.query('.allObjects', this.contentDomNode ).pop() );
		
		this.radioButtonNameFileType = Math.uuid();

		this.widgets.exportToCSV = new dijit.form.RadioButton({
			'name'		: this.radioButtonNameFileType,
			'checked'	: true,
			'style'		: 'margin-left:1em;',
		}, dojo.query('.rB_CSV', this.contentDomNode ).pop() );
		
		this.widgets.exportToXLSX = new dijit.form.RadioButton({
			'name'		: this.radioButtonNameFileType,
			'checked'	: false,
			'style'		: 'margin-left:1em;',
			'disabled'	: true,
		}, dojo.query('.rB_XLSX', this.contentDomNode ).pop() );
		
		if (this.selectedObjects) {
			this.connect( dojo.query('.clickOn_onlySelectedObjects', this.contentDomNode ).pop(), 'onclick', 'clickOn_onlySelectedObjects');
			this.connect( dojo.query('.clickOn_allObjects', this.contentDomNode ).pop(), 'onclick', 'clickOn_allObjects');
		} // end if
		
		this.widgets.includeHeading = new dijit.form.CheckBox({
			// 'style'		: '',
			'checked'	: true,
		},  dojo.query('.includeHeading_cB', this.contentDomNode ).pop() );
		
		this.connect( dojo.query('.clickOn_rB_CSV', this.contentDomNode ).pop(), 'onclick', 'clickOn_rB_CSV');
		//this.connect( dojo.query('.clickOn_rB_XLSX', this.contentDomNode ).pop(), 'onclick', 'clickOn_rB_XLSX');
		this.connect( dojo.query('.clickOn_includeHeading_cB', this.contentDomNode ).pop(), 'onclick', 'clickOn_includeHeading_cB');
		
		this.widgets.fieldSeparatorChar_vTB = new dijit.form.ValidationTextBox({
			'style'					: 'width:1.5em;margin-left:1ex;',
			'class'					: 'code',
			'maxLength'				: 1,
			'intermediateChanges'	: true,
			'invalidMessage' 		: 'invalidMessage',
			'promptMessage' 		: T('fLEAOexportDialog.js/CSVSepCharTip_TTP','Please enter here the char that will separate the values in the CSV file.<br/>Examples for popular value separator chars: <code>,;|</code>&nbsp;.'),
			'selectOnClick'			: true,
			'regExp'				: '.{1}',
			'value'					: ';',
			'required'				: true,
		},  dojo.query('.fieldSeparatorChar_vTB', this.contentDomNode ).pop() );
		
		var bundle = dojo.i18n.getLocalization("dojo.cldr", "number", dojo.i18n.normalizeLocale());		
		
		this.widgets.decimalSeparatorChar_vTB = new dijit.form.ValidationTextBox({
			'style'					: 'width:1.5em;margin-left:1ex;',
			'class'					: 'code',
			'maxLength'				: 1,
			'intermediateChanges'	: true,
			'invalidMessage' 		: 'invalidMessage',
			'promptMessage' 		: T('fLEAOexportDialog.js/CSVSepDecTip_TTP','Please enter here the char that will separate the decimal part in numbers in the CSV file.'),
			'selectOnClick'			: true,
			'regExp'				: '.{1}',
			'value'					: bundle.decimal,
			'required'				: true,
		},  dojo.query('.decimalSeparatorChar_vTB', this.contentDomNode ).pop() );
		
	} // end of method postCreate
	,
	'clickOn_onlySelectedObjects' : function (e) {
		this.widgets.exportOnlySelected_RB.attr('checked', !this.widgets.exportOnlySelected_RB.attr('checked'));
		dojo.stopEvent(e);
	} // end of method clickOn_onlySelectedObjects
	,
	'clickOn_allObjects' : function (e) {
		this.widgets.exportAll_RB.attr('checked', !this.widgets.exportAll_RB.attr('checked'));
		dojo.stopEvent(e);
	} // end of method clickOn_onlySelectedObjects
	,
	'clickOn_rB_CSV' : function (e) {
		var CSV_isChecked = this.widgets.exportToCSV.attr('checked');
		this.widgets.exportToCSV.attr('checked',	!CSV_isChecked);
		this.widgets.exportToXLSX.attr('checked',	CSV_isChecked);
		dojo.stopEvent(e);
	} // end of method clickOn_onlySelectedObjects
	,
	'clickOn_rB_XLSX' : function (e) {
		var CSV_isChecked = this.widgets.exportToCSV.attr('checked');
		this.widgets.exportToCSV.attr('checked',	!CSV_isChecked);
		this.widgets.exportToXLSX.attr('checked',	CSV_isChecked);
		dojo.stopEvent(e);
	} // end of method clickOn_onlySelectedObjects
	,
	'clickOn_includeHeading_cB' : function (e) {
		var includeHeading_isChecked = this.widgets.includeHeading.attr('checked');
		this.widgets.includeHeading.attr('checked',	!includeHeading_isChecked);
		dojo.stopEvent(e);
	} // end of method clickOn_includeHeading_cB
	,
	'destroy' : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		
		for (var i in this.widgets) {
			if (this.widgets[i].destroyRecursive) this.widgets[i].destroyRecursive(false);
			delete this.widgets[i];
		} // end for .. in
		
		//this.inherited(arguments);
	} // end of method destroy
	,
	'prepareFile' : function () {
	
		// some preliminary checks
		if	(	this.widgets.exportToCSV.attr('checked')
			&&	(
						!this.widgets.fieldSeparatorChar_vTB	.isValid() 
					||	!this.widgets.decimalSeparatorChar_vTB	.isValid()
				)
			) return;
	
		// prepare the query and send it to the server
		
		var parameters = this.parentWidget.parentWidget.widgets.preferencesTab.get('parameters'),
			content = {
				'v'			: 'JSON_ObjectType',
				"task"		: 'prepareExportOfObjectSet', 
				"UUID"		: this.OT_UUID,
				
				'searchTerm' : parameters.searchQuery,
				'colHeaders' : dojo.toJson(parameters.colHeaders),
				
				'exportWhat': 'allObjects',
				'export_fileMIMEType' 	:	(		(this.widgets.exportToXLSX.attr('checked'))
												?	'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
												:	'application/csv'
											),
				'CSV_separatorChar'		: (this.widgets.fieldSeparatorChar_vTB.attr('value')?this.widgets.fieldSeparatorChar_vTB.attr('value'):''),
				'CSV_decimalChar'		: (this.widgets.decimalSeparatorChar_vTB.attr('value')?this.widgets.decimalSeparatorChar_vTB.attr('value'):''),
				'includeColHeadings'	: (this.widgets.includeHeading.attr('value')?'true':'false'),
			};
		
		// export selected objects, only?
		if(!this.widgets.exportAll_RB.attr('checked')) {
			var selectedItems = this.parentWidget.widgets.grid.getSelected(),
				selected_O_v_UUIDs = [];
			
			dojo.forEach(selectedItems,function(i){
				selected_O_v_UUIDs.push(i.O_v_UUID);
			},this);
			
			content.exportWhat = 'selectedObjectsOnly';
			content['export_O_v_UUIDs'] = dojo.toJson(selected_O_v_UUIDs);
		
		} // end if
		
		this.exportResults = null;
		
		dojo.style( this.widgets.CancelButton.domNode,	'display', 'none');
		dojo.style( this.widgets.OkButton.domNode, 		'display', 'none');
		dojo.style( this.widgets.closeButton.domNode,	'display', 'inline-block');
		
		this.widgets.optionsContainer.removeChild(this.widgets.mainPane);
		
		loader.show('now');
		
		dojo.xhrPost({
			'url'		: '?',
			'content'	: content,
			'error'		: application.AJAX_errorMessage, // function
			'handleAs'	: 'json',
			'scope'		: this,
			'load'		: function(response,request){ /* onSuccess */
				
				request.args.scope.exportResults = response;
				
			}, // end of onSuccess method
			//preventCache:true,
			//failOk	: true,
			'sync'		: true,
			'timeout'	: 	application.configuration.global.AJAX_default_timeout
		});
		
		loader.hide();
		
		if (this.exportResults.done) {
		
			this.widgets.exportSuccessful = new dijit.layout.ContentPane({
				'region'	: 'center',
				'content'	: ''
					+'<h3>' + T('fLEAOexportDialog.js/ExportFileReady_TXT','The export file is ready for download, now') + '</h3>'
					+'<p>&nbsp;</p>'
					+'<table class="fullWidth compact ">'
						+'<tr>'
							+'<th>'
								+ T('fLEAOexportDialog.js/NumOfExpObj_TXT','Number of exported Objects')
							+'</th>'
							+'<td>'
								+this.exportResults.numberOfObjectsExported
							+'</td>'
						+'</tr>'
						+'<tr>'
							+'<th>'
								+ T('FUT_FileSize','File Size')
							+'</th>'
							+'<td>'
								+'<code>'+dojo.number.format(this.exportResults.fileSize / 1024, {'pattern':'###,###,##0.000'})+'</code>'
								+'&nbsp; kBytes'
							+'</td>'
						+'</tr>'
					+'</table>'
					+'<p>&nbsp;</p>'
//					+'<p><a href="../temp/'+this.exportResults.fileAccessCode+'" target="export">Download the export file '+this.exportResults.fileAccessCode+'</a>.</p>'
					+'<p class="textLeft">' + T('fLEAOexportDialog.js/ClickOnLinkToDL_TXT','Click on the following link to download the export file') + '<br/><a href="index.php?v=downloadExportFile&fileAccessCode='+this.exportResults.fileAccessCode+'">'+this.exportResults.fileAccessCode+'</a>.</p>'
					// +'<pre class="small">'+dojo.toJson(this.exportResults,true)+'</pre>'					
			});	
			this.widgets.optionsContainer.addChild(this.widgets.exportSuccessful);
		
		} else {
		
			this.widgets.exportfailed = new dijit.layout.ContentPane({
				'region'	: 'center',
				'content'	: ''
					+'<h3>' + T('fLEAOexportDialog.js/ExportFailed_TXT','The export failed') + '</h3>'
					+'<p>&nbsp;</p>'
					+'<p>' + T('fLEAOexportDialog.js/TheServerRet_TXT','The server returned:') + '</p>'
					+'<pre class="small">'+dojo.toJson(this.exportResults,true)+'</pre>'
			});	
			this.widgets.optionsContainer.addChild(this.widgets.exportfailed);
		
		} // end if
		
	} // end of method prepareFile
});