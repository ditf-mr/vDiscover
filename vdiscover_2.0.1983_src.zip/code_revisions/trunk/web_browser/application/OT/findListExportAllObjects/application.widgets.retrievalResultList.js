/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare( 'application.widgets.retrievalResultList', [dijit.layout.BorderContainer], {
	
	// these variables need to be passed in instantiation
	'colInfos'			: null // needs to be of type []
	,
	'initialRows'		: null // needs to be of type []
	,
	'searchResultTab'	: null // application.widgets.OT_findListExportAllObjects.searchResultTab
	,
	'initallyFoundItems': null // needs to be of type integer, default: 0
	,
	
	
	// these variables may be passed on instantiation
	'showSelectBoxColumn' : true
	,
	
	
	// dijit.layout.BorderContainer tweaks
	'gutters': false
	,
	'class' : 'dijitTabPaneWrapper'
	,
	'title' : ''
	,
	
	
	// internal variables
	'rows'				: null // will be set to []
	,
	'_widgets' 			: null // will be set to {}
	,
	'_colHeaderWidgets' : null // will be set to []
	,
	'_rowWidgets' 		: null // will be set to []
	,
	'_numSelectedRows'	: null // integer
	,
	'_foundItems'		: null // integer
	,
	
	// WIDGET LIFE CYCLE METHODS --------------------------------------------------------------------------
	'constructor': function () {
	
		// initialisations
		this.initialRows 		= [];	
		this.rows		 		= [];	
		this.initallyFoundItems	= 0;
	
		this._widgets 			= {};	
		this._colHeaderWidgets 	= [];	
		this._rowWidgets 		= [];	
		this._numSelectedRows 	= 0;
		this._foundItems		= 0;
	
	} // end of method constructor
	,
	'postCreate' : function () {
		this.inherited(arguments);
	
		// generate the grid
		this._setupGrid();
		
		// set up the col headers
		this._setUpColHeaders();
		
		// fill in the rows
		this._setUpRows();
		
	} // end of method postCreate
	,
	'resize' : function () {
		this.inherited(arguments);
	
		// set the widths of the col headers to the ones of the first row
		this._setWidthOfColHeaders();
	
	} // end of method resize
	,
	'destroy' : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		
		for (var i in this._widgets) {
			if (this._widgets[i].destroyRecursive) this._widgets[i].destroyRecursive(false);
			delete this._widgets[i];
		} // end for .. in
		delete this._widgets;
		
		// colHeaderWidgets
		dojo.forEach(this._colHeaderWidgets, function(w,i) {
			if (w.destroyRecursive) w.destroyRecursive(false);
			delete this._colHeaderWidgets[i];
		}, this); // end dojo.forEach
		delete this._colHeaderWidgets;
		
		// rowWidgets
		dojo.forEach(this._rowWidgets, function(w,i) {
			if (w.destroyRecursive) w.destroyRecursive(false);
			delete this._rowWidgets[i];
		}, this); // end dojo.forEach
		delete this._rowWidgets;
		
		this.inherited(arguments);
	} // end of method destroy
	,
	
	
	// Grid setup methods
	'_setupGrid' : function () { // this method generates the grid
		
		// create the content pane for the col headings
		this._widgets.colHeaderPane = new dijit.layout.ContentPane({
			'region'	: 'top',
			'content'	: ''
				+'<table class="compact grid noBorders" style="background-color:7#E9E9E9;">'
					+'<thead>'
						+'<tr class="colHeaders">'
							// +'<th>This is the header of the retrieval result list</th>'
							// +'<th>This is the header of the retrieval result list</th>'
						+'</tr>'
					+'</thead>'
				+'</table>',
		});
		this.addChild(this._widgets.colHeaderPane);
		
		// identify the DOM node for the col headers
		this._colHeaders_domNode = dojo.query('table > thead > tr.colHeaders', this._widgets.colHeaderPane.containerNode).pop();
		
		// create the content pane for the rows
		this._widgets.rowsPane = new dijit.layout.ContentPane({
			'region'	: 'center',
			'style'		: 'overflow-y:scroll;',
			'content'	: ''
				+'<table class="compact grid fullWidth noBorders">'
					+'<tbody class="rows">'
						// +'<tr>'
							// +'<td>The rows of the retrieval result list go here</td>'
							// +'<td>The rows of the retrieval result list go here</td>'
						// +'</tr>'
					+'</tbody>'
				+'</table>'
				+'<div class="loadingNextSectionPane RS_viewPane_reloading style="display:hidden;">'
					+'<p class="communicatingWithServer textCenter">' + T('fLEAOsearchResultTab.js/CommWServer_TXT','Communicating with the server …') 			+ '</p>'
				+'</div>'
				+'<div class="loadNextSectionPane dijitSplitterH" style="display:block;">'
					+'<p class="textCenter" style="padding-top:4.5em;padding-bottom:4.5em;">' + T('fLEAOsearchResultTab.js/loadMoreItems_TXT','Move the mouse here to load more items …')+ '</p>'
				+'</div>'
				,
		});
		this.addChild(this._widgets.rowsPane);
		
		// identify the DOM node for the rows and the loading pane
		this._rows_domNode 					= dojo.query('table > tbody.rows', 			this._widgets.rowsPane.containerNode).pop();
		this._loadingNextSectionPane_domNode= dojo.query( 'div.loadingNextSectionPane', this._widgets.rowsPane.containerNode).pop();
		this._loadNextSectionPane_domNode 	= dojo.query( 'div.loadNextSectionPane', 	this._widgets.rowsPane.containerNode).pop();
	
		this.connect(this._loadNextSectionPane_domNode, 'onmouseover', '_loadNextSectionPane_mouseOver' );
	
	} // end of method
	,
	'_setWidthOfColHeaders' : function () {
	
		/*
		// set the width of the header table to the one of the row table
		var headerTable = dojo.query('table', this._widgets.colHeaderPane.containerNode	).pop(),
			rowsTable 	= dojo.query('table', this._widgets.rowsPane.containerNode		).pop();
		
		dojo.contentBox( headerTable, {'w': dojo.contentBox(rowsTable).w});
		*/
		
		// get the nodes in the first table row
		if(!this._rows_domNode.firstChild) return;
		var domNodesInFirstRow = this._rows_domNode.firstChild.children;
		
		// get the col header nodes
		var colHeaderNodes = this._colHeaders_domNode.children;
	
		// iterate over all DOM nodes in the first row and set their properties at the corresponding col header node
		var styles = {
			'paddingLeft'		: 'padding-left',
			'paddingRight'		: 'padding-right',
			'borderLeftWidth'	: 'border-left-width',
			'borderRightWidth'	: 'border-right-width',
			'marginLeft'		: 'margin-left',
			'marginRight'		: 'margin-right',
			'width'				: 'width',
		};
		dojo.forEach( domNodesInFirstRow, function (rowNode, i) {
			var headerNode	= colHeaderNodes[i];
			
			// console.log('##############################################################')
			for (var s in styles) {
				// var readableCSS=styles[s];
				// console.log('####');
				// console.log( s, ' ', dojo.style(rowNode, s), ' ', dojo.style(headerNode, s) );
				dojo.style(headerNode, s, ''+dojo.style(rowNode, s)+'px');
				// console.log( s, ' ', dojo.style(rowNode, s), ' ', dojo.style(headerNode, s) );
			}; // end for .. in
			
		}, this); // end dojo.forEach
		
		// set the width of the last colHeaderNode to the difference between the width of both tables
		/*
		var headerPane		= this._widgets.colHeaderPane.domNode,
			headerTable 	= headerPane.firstChild,
			remainingWidth 	= dojo.contentBox(headerPane).w 
								- 	dojo.contentBox(headerTable).w,
			lastHeader		= colHeaderNodes[colHeaderNodes.length-1],
			lastHeaderWidth	= dojo.contentBox(lastHeader).w,
			newWidth 		= lastHeaderWidth + remainingWidth;
			
		dojo.contentBox( lastHeader, {'w': newWidth});
		*/
	} // end of method _setWidthOfColHeaders
	,
	'_setUpColHeaders' : function () {
		
		// generate a select/ deselect col header cell
		if (this.showSelectBoxColumn) this._colHeaderWidgets.push(
			new application.widgets.retrievalResultList_headerCell({
				'colInfo'	: {
						'name'	: T('FUT_Sel?','Sel?'),
					},
			}).placeAt(this._colHeaders_domNode)
		);
		
		// iterate over all col headers and generate for each one a header cell
		dojo.forEach(this.colInfos, function (colInfo) {
			this._colHeaderWidgets.push(
				new application.widgets.retrievalResultList_headerCell({
					'colInfo'	: colInfo,
				}).placeAt(this._colHeaders_domNode)
			);
		}, this);
				
	} // end of method _setUpColHeaders
	,
	'_setUpRows' : function () {
		this.addRows(this.initialRows, this.initallyFoundItems);
	} // end of method _setUpRows
	,
	
	
	// Internal methods ---------------------------------------------------------
	'_rowSelectedStatusChanged' : function (rowIndex, isSelected) {
		
		// toggle the counter of selected rows
		this._numSelectedRows += (isSelected?1:-1);
				
		this.numSelectedRowsChanged(this._numSelectedRows);
	} // end of method _rowSelectedStatusChanged
	,
	'_loadNextSectionPane_mouseOver': function () {
	
		dojo.style( this._loadNextSectionPane_domNode, 		'display', 'none');
		dojo.style( this._loadingNextSectionPane_domNode, 	'display', 'block');
	
		this.loadNextSection_requested();
	
	} // end of method _loadNextSectionPane_mouseOver
	,
	
	
	// Externally available methods ----------------------------------------------------------
	'selectAll' : function () {
		dojo.forEach(this._rowWidgets, function( rW, i ){
			rW.attr('isSelected', true);
		}, this);	
	} // end of method selectAll
	,
	'selectTagged' : function () {
		dojo.forEach(this._rowWidgets, function( rW, i ){
			if (application.O.readList.isTagged(rW.rowData.O_v_UUID)) rW.attr('isSelected', true);
		}, this);	
	} // end of method selectTagged
	,
	'selectNone' : function () {
		dojo.forEach(this._rowWidgets, function( rW, i ){
			rW.attr('isSelected', false);
		}, this);	
	} // end of method selectNone
	,
	'invertSelection' : function () {
		dojo.forEach(this._rowWidgets, function( rW, i ){
			var isSelected = rW.attr('isSelected');
			rW.attr('isSelected', !isSelected);
		}, this);	
	} // end of method invertSelection
	,
	'getSelected' : function () {
		var r = [];
		dojo.forEach(this._rowWidgets, function( rW, i ){
			if (rW.attr('isSelected')) r.push({
				'rowIndex'	: rW.rowIndex,
				'O_v_UUID'	: rW.rowData.O_v_UUID,
				'name'		: rW.rowData.name,
			});
		}, this);
		return r;
	} // end of method getSelectedBy_O_v_UUID
	,
	'updateRow' : function (rowIndex) {
		this._rowWidgets[rowIndex].update();
		this.resize();
	} // end of method updateRow
	,
	'addRows' : function (rowsArray, foundItems) { // use this method to add rows to the grid
	
		this._foundItems = foundItems;
	
		var firstInsertedDomNode = null;
	
		dojo.forEach(rowsArray, function (row, i) {
			this.rows.push(row);
			var rW = new application.widgets.retrievalResultList_row({
					'showSelectBox' 	: this.showSelectBoxColumn,
					'colInfos'			: this.colInfos,
					'rowData'			: row,
					'rowIndex'			: i,
					'searchResultTab'	: this.searchResultTab,
				});
			rW.placeAt(this._rows_domNode);
			this._rowWidgets.push( rW );
			this.connect(rW, 'onIsSelectedChanged', '_rowSelectedStatusChanged' );
			if (!firstInsertedDomNode) firstInsertedDomNode = rW.domNode;
			}, this);
	
	
		// hide the loading pane
		dojo.style( this._loadingNextSectionPane_domNode, 	'display', 'none');
	
		// is there something worth showing?
	
		if (this.rows.length) { // there are rows
		
			// remove the "nothing found" pane, if it exists
			if (this._widgets._nothingFoundPane) {
				this.removeChild(this._widgets._nothingFoundPane);
			} // end if 
		
			// add the header and rows pane
			this.addChild(this._widgets.colHeaderPane);
			this.addChild(this._widgets.rowsPane);			
		
			// show the pane for loading the next section only, if there seems to be something to show
			dojo.style( this._loadNextSectionPane_domNode, 'display', (( this.rows.length < this._foundItems ) ? 'block' : 'none' ));
			
			// scroll to the first inserted dom node
			if (firstInsertedDomNode) dojo.window.scrollIntoView(firstInsertedDomNode);
		
			// correct the col header width
			this._setWidthOfColHeaders();
			
		} else { // nothing to show - this needs to be mentioned
		
			this.removeChild(this._widgets.colHeaderPane);
			this.removeChild(this._widgets.rowsPane);
			
			this._widgets._nothingFoundPane = new dijit.layout.ContentPane({
			'region'	: 'center',
			'style'		: '',
			'content'	: ''
				+'<div style="width:40em;margin-left:auto;margin-right:auto;padding-top:4.5em;">'
					+'<img src="third_party_libraries/open-icon-library-standard-0.10/icons/png/64x64/emotes/face-sad-4.png" align="left" title="'
							+T( 'fLEAOsearchResultTab.js/addRows_nothingFoundQuote_TXT', 
								'My momma always said, “Life was like a box of chocolates. You never know what you’re gonna get.” — Forrest Gump')
						+'"/>'
					+'<div style="margin-left:64px;padding-left:.25em;">'
						+'<h3>'
							+T( 'fLEAOsearchResultTab.js/addRows_nothingFoundTitle_TXT', 
								'Apologies &mdash; what you are looking for could not be found')
						+'</h3>'
						+T('fLEAOsearchResultTab.js/addRows_nothingFoundExpl_TXT',
							'<p>Some possible reasons:</p><ul><li>There are no items, yet. Consider creating some.</li><li>There are no items that meet your search query.</li><li>You do not have read permissions.</li></ul>')
					+'<div>'
				+'<div>'
				,
			});
			this.addChild(this._widgets._nothingFoundPane);
		
		} // end if
		
	} // end of method addResults
	,
	'getNumberOfLoadedItems' : function () {
		return this.rows.length;
	} // end of method getNumberOfLoadedItems
	,
	
	// event methods to connect to .... ------------------------------------------
	'numSelectedRowsChanged' 	: function (selectedRows) {},
	'loadNextSection_requested'	: function () {},
});

dojo.declare( 'application.widgets.retrievalResultList_headerCell', [dijit._Widget, dijit._Templated], {

	// these variables need to be passed in instantiation
	'colInfo' : null // needs to be of type {}
	,
	
	
	
	// WIDGET LIFE CYCLE --------------------------------------------------------------------------
	'constructor' : function () {
		this.colInfo = {
				'name'	: '?',
				'style'	: 'background-color:red;',
			};
	} // end of method constructor
	,
	'postMixInProperties' : function () {
		this.inherited(arguments);

		this.templateString = ''
			+'<th style="overflow-x:hidden;'
					+(this.colInfo.style || '')
				+'" class="dijitReset dijitInline dijitButtonNode">'
					+this.colInfo.name
			+'</th>';
		
	} // end of method postMixInProperties
	,
});

dojo.declare( 'application.widgets.retrievalResultList_rowCell', [dijit._Widget, dijit._Templated], {

	// these variables need to be passed in instantiation
	'colInfo' : null // needs to be of type {}
	,
	'rowData' : null // needs to be of type {}
	,
	'rowIndex' : null // needs to be an integer
	,
	'searchResultTab' : null // application.widgets.OT_findListExportAllObjects.searchResultTab
	,
	
	
	
	// internal variables
	'_widgets' : null // {}
	,
	'_noValue'	: '&mdash;'
	,
	'style' : null // will be set to ''
	,
	
	
	
	// WIDGET LIFE CYCLE --------------------------------------------------------------------------
	'constructor' : function () {
	
		// initialisations
		this._widgets={};
		this.style = '';
	
	} // end of method constructor
	,
	'templateString' : ''
		+'<td dojoAttachPoint="containerNode" style="${style};overflow-x:hidden;">'
		+'</td>'
	,
	// 'postMixInProperties' : function () {
		// this.inherited(arguments);
		
	// } // end of method postMixInProperties
	// ,
	'postCreate' : function () {
		this.inherited(arguments);
		
		// create the content
		var value = this.rowData[ this.colInfo['field'] ];
		if (this.colInfo['formatter'] && (typeof this.colInfo['formatter'] == 'function')) {
			var formattedContent = this.colInfo.formatter(value, this.rowIndex, this);
			if ((typeof formattedContent=='object') && ('waiRole' in formattedContent)) {
				this._widgets.cellObj = formattedContent;
				formattedContent.placeAt(this.containerNode);
			} else {
				if(!formattedContent) formattedContent = this._noValue;
				dojo.attr( this.containerNode, 'innerHTML', formattedContent );
			} // end if 
		} else {
			if(!value) value = this._noValue;
			dojo.attr( this.containerNode, 'innerHTML', value );
		} // end if
	} // end of method postCreate
	,
	'destroy' : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		
		for (var i in this._widgets) {
			if (this._widgets[i].destroyRecursive) this._widgets[i].destroyRecursive(false);
			delete this._widgets[i];
		} // end for .. in
		delete this._widgets;
				
		this.inherited(arguments);
	} // end of method destroy
	,
});

dojo.declare( 'application.widgets.retrievalResultList_row', [dijit._Widget, dijit._Templated], {

	// these variables need to be passed in instantiation
	'isSelected' : false
	,
	'colInfos' : null // needs to be of type []
	,
	'rowData' : null // needs to be of type {}
	,
	'rowIndex' : null // integer
	,
	'searchResultTab' : null // application.widgets.OT_findListExportAllObjects.searchResultTab
	,
	'showSelectBox' : null // boolean
	,
	
	
	// internal variables
	'_cellWidgets' : null // will be initialised to []
	,
	'isSelectedClass' : 'RS_isSelected_row'
	,
	
	// some settings
	'widgetsInTemplate'	: true
	,


	
	// WIDGET LIFE CYCLE --------------------------------------------------------------------------
	'constructor' : function () {
	
		// initialisations
		this._cellWidgets=[];
	
		this.showSelectBox = true;
	
	} // end of method constructor
	,
	'postMixInProperties' : function () {
		this.inherited(arguments);
	
		this.templateString = ''
			+'<tr dojoAttachPoint="containerNode" dojoAttachEvent="onmouseenter:_onHover,onmouseleave:_onUnHover">'
				+(	this.showSelectBox
						?	'<td style="width:2.5em;text-align:center;	">'
								+'<div dojoType="dijit.form.CheckBox" dojoAttachPoint="_isSelected_CheckBoxWidget" dojoAttachEvent="onChange:_isSelected_CheckBox_changed" checked="${isSelected}"></div>'
							+'</td>'
						:	''
					)
			+'</tr>';
	
	} // end of method postMixInProperties
	,
	'postCreate' : function () {
		this.inherited(arguments);
		
		this._generateCellWidgets();
				
	} // end of method postCreate
	,
	'destroy' : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		
		this._removeCellWidgets();
		
		this.inherited(arguments);
	} // end of method destroy
	,
	
	
	
	
	
	
	// internal methods ---------------------------------------------------------------------------
	'_generateCellWidgets' : function () {
	
		this._cellWidgets = [];
		// iterate over all headers and create the cells
		dojo.forEach(this.colInfos, function( colInfo ) {
			this._cellWidgets.push( 
				new application.widgets.retrievalResultList_rowCell({
					'colInfo' 			: colInfo,
					'rowData' 			: this.rowData,
					'rowIndex'			: this.rowIndex,
					'searchResultTab'	: this.searchResultTab,
				}).placeAt(this.containerNode)
			);
		}, this); // end dojo.forEach
		
	} // end of method _generateCellWidgets
	,
	'_removeCellWidgets' : function () {
	
		// delete _cellWidgets
		dojo.forEach(this._cellWidgets, function(w,i) {
			if (w.destroyRecursive) w.destroyRecursive(false);
			delete this._cellWidgets[i];
		}, this); // end dojo.forEach
		delete this._cellWidgets;
	
	} // end of method _removeCellWidgets
	,
	'_isSelected_CheckBox_changed' : function () {
		this.isSelected = this._isSelected_CheckBoxWidget.attr('checked');
		this.onIsSelectedChanged(this.rowIndex, this.isSelected);
	} // end of method _isSelected_CheckBox_changed
	,
	'_setIsSelectedAttr' : function (v) {
		return this.isSelected = this._isSelected_CheckBoxWidget.attr('checked', (v!=false));
	} // end of method _setIsSelectedAttr
	,
	'_onHover' : function() {
		dojo.addClass(this.domNode, this._hoverclasses);
	} // end of method _onHover
	,
	'_onUnHover' : function() {
		dojo.removeClass(this.domNode, this._hoverclasses);
	} // end of method _onUnHover
	,
	'_hoverclasses' : 'dijitReset dijitMenuItemSelected dijitMenuItemFocused dijitFocused'
	,
	
	
	// external methods ----------------------------------------------------------------------------
	'update' : function () {
		
		// remove all cell widgets
		this._removeCellWidgets();
		
		// generate them, again
		this._generateCellWidgets();		
		
	} // end of method update
	,
	
	
	// event functions for dojo.connect ... --------------------------------------------------------
	'onIsSelectedChanged' : function (rowIndex, isSelected) {
		dojo.toggleClass(this.containerNode, this.isSelectedClass, isSelected);
	} // end of method onIsSelectedChanged
	,
	
});