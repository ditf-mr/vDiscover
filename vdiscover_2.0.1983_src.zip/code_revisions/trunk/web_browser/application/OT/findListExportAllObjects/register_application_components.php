<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

{
	$p ='application/OT/findListExportAllObjects/';
	$r->register_JavaScriptFile($p.'OT_findListExportAllObjects.js');
	$r->register_JavaScriptFile($p.'fLEAO.searchResultTab.js');
	$r->register_JavaScriptFile($p.'fLEAO.preferenceTab.js');
	$r->register_JavaScriptFile($p.'fLEAO.exportDialog.js');
	$r->register_JavaScriptFile($p.'fLEAO.confirmDeleteDialog.js');
	$r->register_JavaScriptFile($p.'fLEAO.analyseDependenciesDialog.js');
	$r->register_JavaScriptFile($p.'fLEAO.loadTab.js');
	
	$r->register_JavaScriptFile($p.'application.widgets.retrievalResultList.js');

	{$r->register_cssContent( '
		img.RS_sortableCheckListUpDownBox {
			float:right;
			display: block;
			padding-right: .25em;
			width: .5em;
			height: .5em;
			padding:0;
			cursor: pointer;
		}
		
	');}
	
} 
//cApplicationRegistry::registerModuleComponents(PLUGIN_REGISTRY_parseAllSubDirs, __DIR__ );
?>