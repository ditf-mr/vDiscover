/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare('application.widgets.OT_findListExportAllObjects.loadTab',[dijit.layout.BorderContainer/*dijit._Widget, dijit._Templated*/],{
	// 'widgetsInTemplate' : true
	// ,
	
	// parent widget class properties
	'title'		: ''
		+'<img src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/table-lightning.png" style="vertical-align:top;margin-right:.5ex;"/>'
		+T( 'fLEAOloadTab.js/savedQueries_TXT', 'Stored queries' ),
	'gutters'	: false,
	
	// local properties
	'loaderClass'	: 'RS_viewPane_reloading', // this css class is defined in application/register_application_components.php
	'minTimeBetweenUpdates'	: 5000, // msec
	
	// internal properties
	'_lastUpdate' 	: null, // Date
	
	// widget life cycle
	'constructor'			: function () {
	
		// some initialisations ...
		this.widgets 		= {};
			
	} // end of method constructor
	,
	/*'postMixInProperties'	: function () {
		this.inherited(arguments);
		
	} // end of method postMixInProperties
	,*/
	/*
	'templateString' : ''
		+'<div>'
			+'<div dojoType="dijit.layout.BorderContainer" gutters="true" dojoAttachPoint="_BCWidget" style="width:100%;height:100%;">'
				+'<div dojoType="dijit.layout.ContentPane" position="top" dojoAttachPoint="_headerWidget"'
						//+'style="padding:.5ex;overflow:auto;height:100%;"'
					+'>'
				+'</div>'
				+'<div dojoType="dijit.layout.ContentPane" position="center" dojoAttachPoint="_centerWidget" style="background-color:orange;">'
			+'</div>'
		+'</div>'
	,
	*/
	'postCreate'			: function () {
		this.inherited(arguments);
		
		// set up the title pane
		this.widgets.titlePane = new dijit.layout.ContentPane({
			'region'	: 'top',
			'style'		: 'padding:.5ex;',
			'content'	: ''
					+'<h2 class="widgetTitle">' 
						+'<span class="titleText">'
							+T( 'fLEAOloadTab.js/savedQueries_TXT', 'Stored queries' )
						+'</span>'
					+'</h2>'
					+'<p>'
						+T('fLEAOloadTab.js/expl_TXT','Choose the query that you want to execute and click on it.')
					+'</p>'
					+'<p>&nbsp;</p>'
					,
		});
		this.addChild(this.widgets.titlePane);
		
		this.titleNode = dojo.query( 'H2.widgetTitle', this.widgets.titlePane.containerNode).pop();
		this.titleText_domNode = dojo.query( 'span.titleText', this.widgets.titlePane.containerNode).pop();
		this._reload_domNode = dojo.create( 'SPAN', {'class' :'RS_clickableIcon RS_icon_refresh_small', 'style' : 'margin-left:.5ex;' }, this.titleNode, 'last');
		this.connect( this._reload_domNode, 'onclick', '_loadAvailableFindQueries' );
				
		// set up a hint pane
		this.widgets.hintPane = new dijit.layout.ContentPane({
			'region'	: 'bottom',
			'style'		: 'padding:.5ex;',
			'content'	: ''
					+'<h3>' 
							+T( 'hints_FUT', 'Hints')
					+'</h3>'
					+'<ul>'
						+'<li>'
							+T( 'fLEAOloadTab.js/hintdragLinkSQuery_TXT',
								'Feel free to <strong>drag and drop</strong> the links to the stored queries into the file system, to other applications or to your browser\'s bookmark bar.'
								)
						+'</li>'
						+'<li>'
							+T( 'fLEAOloadTab.js/hintStoreQuery_TXT',
								'<strong>Storing queries</strong>: you may store or update a stored query on the preference tab.'
								)
						+'</li>'
						+'<li>'
							+T( 'fLEAOloadTab.js/hintPublishQuery_TXT',
								'<strong>Making queries publicly available</strong>: you find a radio button for this on the preference tab. You need to store the query, afterwards.'
								)
						+'</li>'
						+'<li>'
							+T( 'fLEAOloadTab.js/hintDeleteQuery_TXT',
								'<strong>Deleting queries</strong>: load a query and go to the preference tab. There, you may delete the query.'
								)
						+'</li>'
					+'</ul>'
					+'<p>&nbsp;</p>'
					,
		});
		this.addChild(this.widgets.hintPane);
		
		// set up the loading pane
		this.widgets.loadingPane = dijit.layout.ContentPane({
			'region'	: 'center',
			'class'		: this.loaderClass,
			'content'	: '<p class="textCenter">' + T('fLEAOsearchResultTab.js/CommWServer_TXT','Communicating with the server …') + '</p>',
		});
		
		// get and place the find queries
		this._loadAvailableFindQueries();
		
	} // end of method postCreate
	,
	'startup' : function() {
		// If you need to be sure parsing and creation of any child widgets has 
		// completed, use startup. This is often used for layout widgets like 
		// BorderContainer. If the widget does JS sizing, then startup() should 
		// call resize(), which does the sizing.
		this.inherited(arguments);
		
		this.connect (this, 'onShow', '_loadAvailableFindQueries' );
		
	} // end of method startup
	,
	'destroy' : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		
		for (var i in this.widgets) {
			if (this.widgets[i].destroyRecursive) try{
				this.widgets[i].destroyRecursive();
			} catch(e) {
				console.error('Problem in '+this.declaredClass+'::destroy():\nWhen trying to delete subwidget "'+i+'", the following error was thrown:');
				console.error(e);
				console.log('this', this);
				console.log('this.widgets[i]', this.widgets[i]);
				dijit.registry.remove(this.widgets[i].id);
			} // end if .. try
			delete this.widgets[i];
		} // end for .. in
		
		this.inherited(arguments);
	} // end of method destroy
	,
	
	// methods that are connected to events ...
	'_loadAvailableFindQueries' : function (e) {
	
		if (e) dojo.stopEvent(e);
	
		// detect if update is really necessary
		var now = new Date();
		if (		this._lastUpdate 
				&& (now - this._lastUpdate < this.minTimeBetweenUpdates) ) {
			return; // do nothing
		} // end if
		this._lastUpdate  = now;
	
		// remove an already existing find query pane
		if (this.widgets.findQueryPane) {
			this.removeChild(this.widgets.findQueryPane);
			this.widgets.findQueryPane.destroyRecursive(false);
			this.widgets.findQueryPane = null;
		} // end if
		
		this.addChild(this.widgets.loadingPane);
	
		// prepare the query
		var p 	= this.parentWidget.widgets.preferencesTab.get('parameters'),
			URL = '?'
					+dojo.objectToQuery({
						'v'					: 'JSON_ObjectType',
						'task'				: 'get_OT_findLists',
						'OT_UUID'			: p.OT_UUID,
					});
		
		// execute the query
		dojo.xhrPost({
			'url'		: URL,
			'error'		: application.AJAX_errorMessage, // function
			'handleAs'	: 'json',
			'scope'		: this,
			'load'		: function(response,request){ /* onSuccess */				
				request.args.scope._placeFoundFindQueries( response );
			}, // end of onSuccess method
			//preventCache:true,
			//failOk	: true,
			'sync'		: false, // this is important to assure a quick startup
		});		
	
	} // end of method _loadAvailableFindQueries
	,
	'_placeFoundFindQueries' : function (r) {
		
		// 2 cases: there are find queries or none
		// the following clause deals with the second case
		if (!r.length) {
			this.widgets.findQueryPane = new dijit.layout.ContentPane({
				'region'	: 'center',
				'style'		: 'padding:.5ex;',
				'content'	: ''
					+'<img src="third_party_libraries/open-icon-library-standard-0.10/icons/png/32x32/emotes/face-uncertain.png" align="left" title="'
							+T( 'fLEAOloadTab.js/nothingFoundQuote_TXT', 
								'“Neither with those nor with the others, with all I agree and dissent; in all part of truth and part of error must be seen.” — Miguel Serveto y Conesa, alias «Revés» (1509-1553)')
						+'"/>'
					+'<p>' 
						+T(	'fLEAOloadTab.js/savedQueries_TXT',
							'Stored Queries' 
						)
					+'</p>'
					,
			});
			this.removeChild(	this.widgets.loadingPane	);
			this.addChild(		this.widgets.findQueryPane	);
			
			return;
		} // end if
		
		// first case: there are find queries
		
		this.widgets.findQueryPane = new application.widgets.retrievalResultList({
			'region'				: 'center',
			'style'					: 'border-left:0;border-right:0;',
			'colInfos'				: this._buildHeaderStructure(),
			'initialRows'			: r,
			'searchResultTab	'	: this,
			'showSelectBoxColumn'	: false,
		});
				
		this.removeChild(	this.widgets.loadingPane	);
		this.addChild(		this.widgets.findQueryPane	);
		
	} // end of method _placeFoundFindQueries
	,
	'_buildHeaderStructure' : function () {
		var h = [];
		
		// query name as a link
		h.push({
			'field'		: 'name',
			'name'		: T('FUT_Name','Name'),
			'style'		: 'text-align:left;',
			'scope'		: this,
			'formatter'	: function(name,rowIndex,cellObj){						
				var FL_UUID = cellObj.rowData.FL_UUID,
					OT_UUID = this.scope.parentWidget.OT_UUID,
					URL		= '?'+dojo.objectToQuery({
								'jumpTo':'OTfindList',
								'OT_UUID':OT_UUID,
								'FL_UUID':FL_UUID,
							});
				
				return new application.widgets.actionLink({
					'linkName'	: ''
									+'<img src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/table-lightning.png" '
										+'style="vertical-align:middle;margin-right:.5ex;" '
									+'/>'
									+name,
					'URL'		: URL,
					'title'		: T('fLEAOloadTab.js/clickHereToLoadQuery_TXT',
									'Click here to load this query.\nFeel free drag this link to another application, into the file system or to your bookmark bar.'
									),
									
					'FL_UUID'	: FL_UUID,
					'OT_UUID'	: OT_UUID,
					// 'scope'		: this.scope,
					'onClick'	: function(){
						application.OT.show( this.OT_UUID, 'OT_menubar_itemKinds.general.all', {'loadFindQuery': this.FL_UUID} );
						//this.scope.parentWidget.loadFindQuery(this.FL_UUID);
					}, // end of method onClick
					'_destroyOnRemove' :true, // see http://dojotoolkit.org/reference-guide/dojox/grid/DataGrid.html
				});
			} // end of formatter function
		});
	
		// query availability
		h.push({
			'field'		: 'usage',
			'name'		: '<div style="text-align:center;">'
								+T(	'fLEAOloadTab.js/availability_TXT',
									'Available to …'
									)
							+'</div>',
			'style'		: 'width:7.5em;',
			'formatter' : function(usage,rowIndex,cellObj){
				// var O_v_UUID= cellObj.rowData.O_v_UUID;
											
				return (		usage
							?	 T('fLEAOloadTab.js/public_TXT','everyone')
							:	 T('fLEAOloadTab.js/private_TXT','just myself')
						);
			} // end of formatter function
		});
	
		// last change at & by
		h.push({
			'field'		: 'lastChanges_at',
			// 'style'		: 'min-width:5em;',
			'name'		: '<div style="text-align:right">'
							+T('FUT_LastChange','Last change')
						+'</div>',
			'formatter'	: function(value,rowIndex,cellObj){
				var d	= new Date( value.replace(/-/g,'/').replace(/T/,' ').replace(/\+/,' +') ), // see http://stackoverflow.com/questions/4450837/javascript-string-to-date-php-iso-string-format
					now	= new Date(), 
					r	= '';
				
				// pretty-format the date
				if (dojo.date.difference(d,now,'hour')<1)			r=dojo.date.difference(d,now,'minute')+' min ago';
					else if (dojo.date.difference(d,now,'day')<1) 	r=dojo.date.locale.format(d,{selector:'time'});
					else 								 			r=dojo.date.locale.format(d);
				
				return '<div style="text-align:right;">'+r+'</div>'
			} // end of formatter function
		});
		h.push({
			'field'		: 'lastChanges_by',
			// 'style'		: 'min-width:5em;',
			'name'		: T('FUT_ChangedBy','Changed by'),
			'formatter'	: function(name,rowIndex,cellObj){
				var lastChanges_byO_v_UUID=cellObj.rowData.lastChanges_byO_v_UUID;
					
				return new application.widgets.internalLink({
					"O_v_UUID" 			: lastChanges_byO_v_UUID,
					"linkName" 			: name,
					'_destroyOnRemove' : true // see http://dojotoolkit.org/reference-guide/dojox/grid/DataGrid.html
				});
			} // end of formatter function
		});
	
	
		return h;
	} // end of method _buildHeaderStructure
	,
	
	
	// Events ---------------------------------------------------------------------
});

// widget declaration for an action link
dojo.declare("application.widgets.actionLink", [dijit._Widget, dijit._Templated],{
		'widgetsInTemplate'	: true,

		// these slots need to be passed on instantiation:
		'linkName'	: '', // not necessary for declarative instantion
		
		// these slots are optional
		'title' 	: '',
		'class'		: 'internalLink',
		'URL'	: 'javascript:void(e);return false;',
		
		
		
		'templateString' : '',
		
		'postMixInProperties' : function () {
			this.inherited(arguments);
			
			var esc = function (t) {
				// this local function escapes quotes in the passed string t
				return t.replace(/["']/g, function(r) { return '\\'+r;});
			};
			
			this.templateString = ''
				+'<a '
					+'href="'+this.URL+'" '
					+'dojoAttachPoint="containerNode" '
					+'dojoAttachEvent="onclick:_myOnClick" '
					+'title="'+esc(this.title)+'" '
				+'>'
					+this.linkName
				+'</a>';
				
		} // end of method postMixInProperties
		,
		
		// internal methods
		'_myOnClick':function(e){
			dojo.stopEvent(e);
			this.onClick();
		},
		
		// events
		'onClick' : function () {},
});
