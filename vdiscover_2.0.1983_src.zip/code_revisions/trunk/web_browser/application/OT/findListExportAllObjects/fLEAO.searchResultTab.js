/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare('application.widgets.OT_findListExportAllObjects.searchResultTab',[/*dijit._Widget, dijit._Templated*/dijit.layout.BorderContainer],{
	// 'templateString'	: '<div style="" dojoAttachPoint="containerNode"></div>',
	
	// these slots need to be set on initialisation
	'OT_UUID' : null
	,
	'parentWidget' : null
	,
	
	
	// Some settings
	'defaultTitle'	: T('FUT_FoundObjects','Found objects')
	,	
	'loaderClass'	: 'RS_viewPane_reloading' // this css class is defined in application/register_application_components.php
	,
	'style'			: 'width:100%;height:100%;'
	,
	'minTimeBetweenUpdates'	: 5000, // msec

	// internal properties
	'_lastUpdate' 	: null, // Date
	
	'selectedRows'	: null // integer
	,
	
	
	// widget life cycle
	'constructor'	: function () {
	
		// some initialisations
		this.selectedRows = 0;
	
	} // end of method constructor
	,
	'postMixInProperties' : function (){
		this.inherited(arguments);
		
		this.widgets = {};
		
		// localise the attribute list
		this.attrList	= this.parentWidget.attrList;
		this.attrStore	= this.parentWidget.attrStore;
		
		this.title = this.defaultTitle;
		
	} // end of methodpostMixInProperties
	,
	'destroy' : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		
		for (var i in this.widgets) {
			if (this.widgets[i].destroyRecursive) try{
				this.widgets[i].destroyRecursive();
			} catch(e) {
				console.error('Problem in instance of type application.widgets.OT_findListExportAllObjects.searchResultTab:\nWhen trying to delete subwidget "'+i+'", the following error was thrown:');
				console.error(e);
				console.log('this', this);
				console.log('this.widgets[i]', this.widgets[i]);
				dijit.registry.remove(this.widgets[i].id);
			} // end if .. try
			delete this.widgets[i];
		} // end for .. in
		
		this.inherited(arguments);
	} // end of method destroy
	,
	'postCreate' : function () {
		this.inherited(arguments);
	
		// create the menu bar
		this.widgets.menuBar = new dijit.MenuBar({
			'region'	: 'top',
			'title'		: '',
		});
		this.addChild(this.widgets.menuBar);
		var mb = this.widgets.menuBar;

		
		// Create a drop-down menu for options that refer to a selection
		
		this.widgets.selectDDMenu = new dijit.Menu({});

		this.widgets.selectAllMI = new dijit.MenuItem({
            'label': T('fLEAOsearchResultTab.js/SelectAll_MNU','Select all')
        });
		this.widgets.selectDDMenu.addChild(this.widgets.selectAllMI);
		this.connect(this.widgets.selectAllMI, 'onClick', 'selectAll');

		this.widgets.selectNoneMI = new dijit.MenuItem({
            'label': T('fLEAOsearchResultTab.js/DeselectAll_MNU','Deselect all')
        });
		this.widgets.selectDDMenu.addChild(this.widgets.selectNoneMI);
		this.connect(this.widgets.selectNoneMI, 'onClick', 'deselectAll');
		
		this.widgets.invertSelectionMI = new dijit.MenuItem({
            'label': T('fLEAOsearchResultTab.js/InvertSel_MNU','Invert selection')
        });
		this.widgets.selectDDMenu.addChild(this.widgets.invertSelectionMI);
		this.connect(this.widgets.invertSelectionMI, 'onClick', 'invertSelection');
		
		this.widgets.selectTaggedMI = new dijit.MenuItem({
            'label': T('fLEAOsearchResultTab.js/SelTaggedItm_MNU','Select tagged items')
        });
		this.widgets.selectDDMenu.addChild(this.widgets.selectTaggedMI);
		this.connect(this.widgets.selectTaggedMI, 'onClick', 'selectTagged');
		
		// Create a drop-down menu for actions for (selected) items
		this.widgets.selectedObjectsDDMenu = new dijit.Menu({});
		
		this.widgets.openSelectedMI = new dijit.MenuItem({
            'label': T('fLEAOsearchResultTab.js/OpenSelItm_MNU','Open selected items'),
			// 'disabled': true,
        });
		this.widgets.selectedObjectsDDMenu.addChild(this.widgets.openSelectedMI);
		this.connect(this.widgets.openSelectedMI, 'onClick', 'openSelected');

		// ----------------------------------------------------------------------
		this.widgets.separator1MI = new dijit.MenuSeparator({});
		this.widgets.selectedObjectsDDMenu.addChild(this.widgets.separator1MI);
		// ----------------------------------------------------------------------
		
		this.widgets.tagSelectedMI = new dijit.MenuItem({
            'label': T('fLEAOsearchResultTab.js/TagSelItm_MNU','Tag selected items'),
			// 'disabled': true,
        });
		this.widgets.selectedObjectsDDMenu.addChild(this.widgets.tagSelectedMI);
		this.connect(this.widgets.tagSelectedMI, 'onClick', 'tagSelected');

		this.widgets.unTagSelectedMI = new dijit.MenuItem({
            'label': T('fLEAOsearchResultTab.js/UntagSelItm_MNU','Untag selected items'),
			// 'disabled': true,
        });
		this.widgets.selectedObjectsDDMenu.addChild(this.widgets.unTagSelectedMI);
		this.connect(this.widgets.unTagSelectedMI, 'onClick', 'untagSelected');

		// ----------------------------------------------------------------------
		this.widgets.separator1MI = new dijit.MenuSeparator({});
		this.widgets.selectedObjectsDDMenu.addChild(this.widgets.separator1MI);
		// ----------------------------------------------------------------------
		
		this.widgets.exportMI = new dijit.MenuItem({
            'label': T('fLEAOsearchResultTab.js/Export_MNU','Export …'),
			// 'disabled': true,
        });
		this.widgets.selectedObjectsDDMenu.addChild(this.widgets.exportMI);
		this.connect(this.widgets.exportMI, 'onClick', 'export_showDialog');
		
		this.widgets.analyseDependenciesMI = new dijit.MenuItem({
            'label': T('fLEAOsearchResultTab.js/AnalDepend_MNU','Analyse dependencies …'),
			// 'disabled': true,
        });
		this.widgets.selectedObjectsDDMenu.addChild(this.widgets.analyseDependenciesMI);
		this.connect(this.widgets.analyseDependenciesMI, 'onClick', 'analyseDependencies_showDialog');
		
		this.widgets.deleteMI = new dijit.MenuItem({
            'label': T('fLEAOsearchResultTab.js/Delete_MNU','Delete …'),
			// 'disabled': true,
        });
		this.widgets.selectedObjectsDDMenu.addChild(this.widgets.deleteMI);
		this.connect(this.widgets.deleteMI, 'onClick', 'deleteSelection_showDialog');
		
		
		// add the drop-down menus to the menu bar
		this.widgets.selectDDMenuBarItem = new dijit.PopupMenuBarItem({
            'label': T('fLEAOsearchResultTab.js/NoSelItm_MNU','No selected items&nbsp;…'),
            'popup': this.widgets.selectDDMenu,
        });
		mb.addChild(this.widgets.selectDDMenuBarItem);
		
		this.widgets.selectedObjectsDDMenuBarItem = new dijit.PopupMenuBarItem({
            'label': T('fLEAOsearchResultTab.js/CarryOutAct_MNU','Carry out action&nbsp;…'),
            'popup': this.widgets.selectedObjectsDDMenu,
			// 'style'		: 'float: right;',
        });
		mb.addChild(this.widgets.selectedObjectsDDMenuBarItem);
		
		
		// set up the loading pane
		this.widgets.loadingPane = dijit.layout.ContentPane({
			'region'	: 'center',
			'class'		: this.loaderClass,
			'content'	: '<p class="textCenter">' + T('fLEAOsearchResultTab.js/CommWServer_TXT','Communicating with the server …') + '</p>',
		});
		
	} // end of method postCreate
	,
	'startup'	: function () {
		this.inherited(arguments);

		this.connect( this, 'onShow', 'executeQuery' );
	} // end of method startup
	,
	'_loadNextSection' : function () {
			
		// prepare the query
		var queryParameters =this.parentWidget.widgets.preferencesTab.get('parameters');
		queryParameters.firstObject= this.widgets.grid.getNumberOfLoadedItems();
				
		var queryTargetURL	= '?'
			+dojo.objectToQuery({
				'v'					: 'JSON_ObjectType',
				'task'				: 'get_Os_4_OT_show_all_io_REST',
				'UUID'				: this.OT_UUID,
				'queryParameters' 	: dojo.toJson(queryParameters),
			});
		
		// query and get the search results
		dojo.xhrPost({
			'url'		: queryTargetURL,
			'error'		: application.AJAX_errorMessage, // function
			'handleAs'	: 'json',
			'scope'		: this,
			'load'		: function(response,request){ /* onSuccess */				
				request.args.scope.finishQuery( response.items, response.totalCountObjects );
			}, // end of onSuccess method
			//preventCache:true,
			//failOk	: true,
			'sync'		: false,
			'timeout'	: 2*application.configuration.global.AJAX_default_timeout
		});		
	
	} // end of method _loadNextSection
	,
	'executeQuery' : function () {

		// detect if update is really necessary
		var now = new Date();
		if (		this._lastUpdate 
				&& (now - this._lastUpdate < this.minTimeBetweenUpdates) ) {
			return; // do nothing
		} // end if
		this._lastUpdate  = now;	
	
		// destroy the grid if it already exists
		if(this.widgets.grid) {
			// remove the grid 
			this.removeChild(this.widgets.grid);
			
			// delete the grid
			this.widgets.grid.destroyRecursive(false);
			delete this.widgets.grid;
		} // end if there is tear-down work to do
		
		this.addChild(this.widgets.loadingPane);
		this.numSelectedRowsChanged(0);
		
		
		// build the grid
		this.widgets.grid = new application.widgets.retrievalResultList({
			'region' 		: 'center',
			'colInfos'		: this.buildHeaderStructure(),
			// 'initialRows'	: [],
			'searchResultTab': this,
		});
		this.connect(this.widgets.grid, 'numSelectedRowsChanged', 		'numSelectedRowsChanged');
		this.connect(this.widgets.grid, 'loadNextSection_requested', 	'_loadNextSection'		);
		this.numSelectedRowsChanged(0);
		
		
		// execute the query and load the first section of results
		this._loadNextSection(); // the grid MUST exist for this
		
	} // end of method executeQuery
	,
	'finishQuery' : function (newItems, foundItems) {
	
		this._updateNumberOfFoundObjects(foundItems);

		// show the grid
		this.removeChild(this.widgets.loadingPane);
		this.addChild(this.widgets.grid);
		
		// add the new rows to the grid
		this.widgets.grid.addRows(newItems, foundItems);
		
	} // end of method finishQuery
	,
	'buildHeaderStructure' : function () {
		var parameters = this.parentWidget.widgets.preferencesTab.get('parameters'),
			colHeaders = parameters.colHeaders,
			searchTerm = parameters.searchTerm,
			h = [];
			
		// compile the colHeaders for the requested columns
		dojo.forEach(colHeaders, function(colHeader, i){
		
			var orderHTML = '';
			if (parameters.orderBy == colHeader) {
				orderHTML = '<img src="third_party_libraries/open-icon-library-standard-0.10/'
								+'icons/png/16x16/actions/view-sort-'
									+(parameters.orderAsc?'asc':'desc')+'ending-2.png" '
								+'style="vertical-align:text-bottom;" />'
								+'&nbsp;';
			} // end if 
		
			switch (colHeader) {
				case 'points': {
					if (searchTerm) h.push({
						'field'		: 'points',
						'name'		: '<div style="text-align:center;">' + orderHTML + T('FUT_Points','Points') + '</div>',
						'style'		: 'width:5em;',
						'formatter'	: function(value,rowIndex,cellObj){
							return '<div class="textCenter"><code>'+value+'</code></div>';
						},
					});
					} break;
				case 'tagged': {
					h.push({
						'field'		: 'tagged',
						'name'		: '<div style="text-align:center;">' + orderHTML + T('FUT_Tagged','Tagged') + '?</div>',
						'style'		: 'width:5em;',
						'formatter' : function(isTagged,rowIndex,cellObj){
							var O_v_UUID= cellObj.rowData.O_v_UUID;
														
							return (		application.O.readList.isTagged(O_v_UUID)
										?	'<div style="text-align:center;"><img src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/others/tag-orange.png" style="vertical-align:text-bottom;" /></div>'
										:	''
									);
						} // end of formatter function
					});
					
				} break;
				case 'name': {
					h.push({
						'field'		: 'name',
						'name'		: orderHTML + T('FUT_Name','Name'),
						'style'		: 'text-align:left;',
						'formatter'	: function(name,rowIndex,cellObj){						
							var O_v_UUID= cellObj.rowData.O_v_UUID,
								isTagged= application.O.readList.isTagged(O_v_UUID);
								
							return new application.widgets.internalLink({
								"O_v_UUID" : O_v_UUID,
								"linkName" : (isTagged?'<b>'+name+'</b>':name),
								'_destroyOnRemove' :true // see http://dojotoolkit.org/reference-guide/dojox/grid/DataGrid.html
							});
						} // end of formatter function
					});
				} break;
				case 'description': {
					h.push({
						'field'		: 'description',
						'name'		: orderHTML + T('FUT_Description','Description'),
						'style'		: 'min-width:8em;max-width:36em;',
						'formatter' :function(value, rowIndex, cellObj){
							return '<div class="small">'+value+'</div>';
						}
					});
				} break;
				case 'lastChangeAtBy': {
					h.push({
						'field'		: 'changedAt',
						'name'		: '<div style="text-align:right">' + orderHTML + T('FUT_LastChange','Last change') + '</div>',
						'formatter'	: function(value,rowIndex,cellObj){
							var d	= new Date( value.replace(/-/g,'/').replace(/T/,' ').replace(/\+/,' +') ), // see http://stackoverflow.com/questions/4450837/javascript-string-to-date-php-iso-string-format
								now	= new Date(), 
								r	= '';
							
							// pretty-format the date
							if (dojo.date.difference(d,now,'hour')<1)			r=dojo.date.difference(d,now,'minute')+' min ago';
								else if (dojo.date.difference(d,now,'day')<1) 	r=dojo.date.locale.format(d,{selector:'time'});
								else 								 			r=dojo.date.locale.format(d);
							
							return '<div style="text-align:right;">'+r+'</div>'
						} // end of formatter function
					});
					h.push({
						'field'		: 'changedByP_name',
						'name'		: orderHTML + T('FUT_ChangedBy','Changed by'),
						'formatter'	: function(name,rowIndex,cellObj){
							var changedByP_O_v_UUID=cellObj.rowData.changedByP_O_v_UUID;
								
							return new application.widgets.internalLink({
								"O_v_UUID" 			: changedByP_O_v_UUID,
								"linkName" 			: name,
								'_destroyOnRemove' : true // see http://dojotoolkit.org/reference-guide/dojox/grid/DataGrid.html
							});
						} // end of formatter function
					});
				} break;
				default: // colHeader needs to be an attribute
					var A_UUID = colHeader,
						attrName = '?';
				
					// get the attribute name
					this.attrStore.fetchItemByIdentity({
						'identity'	: A_UUID,
						'scope'		: this,
						'onItem'	: function (i) {
							attrName = this.attrStore.getValue(i, 'name');
						} // end of method onItem
					});
				
					h.push({
						'field'	: colHeader,
						'name'	: orderHTML + attrName,
						'formatter':function(valueTuples,rowIndex,cellObj){
							var A_UUID	= cellObj.colInfo.field,
								config	= cellObj.searchResultTab.attrList[A_UUID];
						
							// decode the relation attribute configuration slot, if necessary
							if (		(config.kind=='cRelationAttribute')
									&&	('relationAttributes' in config) 
									&&	(typeof config.relationAttributes=='string')
									
								)	config.relationAttributes = dojo.fromJson(config.relationAttributes);
						
							return new application.widgets[config.kind]({
								'_destroyOnRemove'	: true, // see http://dojotoolkit.org/reference-guide/dojox/grid/DataGrid.html
								'A_UUID'			: config.A_UUID,
								// 'O_UUID'	: '',
								'edit'				: false,
								'config'			: config,
								'valueTuples' 		: dojo.fromJson(valueTuples),
							});
						}
					});
					
			} // end switch

		}, this); // end dojo.forEach
	
		return h;
	} // end of method buildHeaderStructure
	,
	'selectAll' : function () {
		this.widgets.grid.selectAll();
	} // end of method selectAll
	,
	'deselectAll' : function () {
		this.widgets.grid.selectNone();
	} // end of method deselectAll
	,
	'invertSelection' : function () {
		this.widgets.grid.invertSelection();
	} // end of method invertSelection
	,
	'openSelected' : function () {
	
		// get the selected the O_v_UUIDs of the selected objects and open them
		var selectedItems = this.widgets.grid.getSelected();
		
		dojo.forEach(selectedItems,function(selInfo){
			application.O.show(selInfo.O_v_UUID);
		},this);

	} // end of method openSelected
	,
	'tagSelected' : function () {
	
		// get the selected objects, get their O_v_UUIDs and delete them
		var selectedItems = this.widgets.grid.getSelected();
		
		dojo.forEach(selectedItems,function(i){
			if(i) {
				application.O.readList.add(i.O_v_UUID, i.name, this.OT_UUID);
				application.O.readList.tag(i.O_v_UUID);
				
				// update the row
				this.widgets.grid.updateRow(i.rowIndex);         

			} // end if 
		},this);

	} // end of method tagSelected
	,
	'untagSelected'	: function () {
	
		// get the selected objects, get their O_v_UUIDs and delete them
		var selectedItems = this.widgets.grid.getSelected();
		
		dojo.forEach(selectedItems,function(i){
			application.O.readList.removeTag(i.O_v_UUID);

			// update the row
			this.widgets.grid.updateRow(i.rowIndex);         
				
		},this);

	} // end of method untagSelected
	
	,
	'selectTagged' : function () {
		this.widgets.grid.selectTagged();
	} // end of method selectTagged
	,
	
	
	
	
	'deleteSelection_showDialog' : function () {
		if (this.deleteDialogWidget) this.deleteSelection_closeDialog(); // destroy a potentially existing dialog widget
		
		var selectedObjects = this.selectedRows,
			allObjects		= this.numObjects;
					
		if (selectedObjects==allObjects) selectedObjects=0;
				
		this.deleteDialogWidget = new application.widgets.OT_findListExportAllObjects.confirmDeleteDialog({
			'OT_UUID'			: this.OT_UUID,
			'OT_name'			: this.parentWidget.OTName,
			'parentWidget'		: this,
			'selectedObjects' 	: selectedObjects,
			'allObjects' 		: allObjects,
		});
		
		this.deleteDialogWidget.startup();
		this.deleteDialogWidget.show();
		
	} // end of method deleteSelection
	,
	'closeObjectTabIfNecessary' : function (O_v_UUID) {
		// this method tests if there is a tab for an object with the given O_v_UUID and closes it, if necessary
	
		var Ow = dijit.byId('O_'+O_v_UUID);
		if (Ow) {
			var tCw = dijit.byId('OT_tC_'+this.OT_UUID);
			tCw.closeChild(Ow);
		} // end if
	} // end of method closeObjectTabIfNecessary
	,
	'closeAllObjectTabs' : function () {
		// this method closes all tabs of the type that are object tabs
		
		var OTw = dijit.byId('OT_tC_'+this.OT_UUID),
			tWs = OTw.getChildren();
		
		dojo.forEach(tWs, function (w) {
			if (w.id.slice(0,2)=='O_') OTw.closeChild(w);
		},this);
		
	} // end of method closeAllObjectTabs
	,
	'deleteSelection_execute'	: function () {
		
		// show the loader
		loader.show();
		
		// tell the server to delete the selected objects
		var content = {
				'v'		: 'JSON_ObjectType',
				"task"	: 'deleteObjects', 
				"UUID"	: this.OT_UUID,
				
			};
		
		if (!this.deleteDialogWidget.widgets.deleteAll_RB.attr('checked')) {
			
			// delete only selected objects
			if (this.deleteDialogWidget.selectedObjects && !this.deleteDialogWidget.widgets.deleteOnlySelected_RB.attr('checked')) {
				// just close the dialog
				this.deleteSelection_closeDialog();
				
				// hide the loader
				loader.hide();
				
			} // end if
			
			// get the selected O_v_UUIDs
			var selectedItems = this.widgets.grid.getSelected(),
				selected_O_v_UUIDs = [];
			
			dojo.forEach(selectedItems,function(i){
				selected_O_v_UUIDs.push( i.O_v_UUID );
				
				// it is necessary to close the object, first, if it is opened
				this.closeObjectTabIfNecessary( i.O_v_UUID );
			},this);
			
			content.deleteWhat = 'selectedObjectsOnly';
			content.delete_O_v_UUIDs = dojo.toJson(selected_O_v_UUIDs);
		} else {
			// delete all objects
			
			content.deleteWhat = 'allObjects';
			
			// close all object tabs that are currently opened
			this.closeAllObjectTabs();
			
		} // end if
		
		// execute the query
		dojo.xhrPost({
			'url'		: '?',
			'content'	: content,
			'error'		: application.AJAX_errorMessage, // function
			'handleAs'	: 'json',
			'scope'		: this,
			'load'		: function(response,request){ /* onSuccess */
				
				// console.log('Response', response);
				// console.log('request', request);
				
			}, // end of onSuccess method
			//preventCache:true,
			//failOk	: true,
			'sync'		: true,
			'timeout'	: application.configuration.global.AJAX_default_timeout
		});
		
		// remove the deleted objects from the internal "isTagged" store
		application.O.readList.initialise();
		
		// reload the list of all objects
		this.executeQuery();
		
		// close the dialog
		this.deleteSelection_closeDialog();
		
		// hide the loader
		loader.hide();
		
	} // end of method deleteSelection_execute
	,
	'deleteSelection_closeDialog'	: function () {
		this.deleteDialogWidget.hide();
		this.deleteDialogWidget.destroyRecursive(false);
		this.deleteDialogWidget.destroy();
		this.deleteDialogWidget=null;
	} // end of method deleteSelection_execute
	,
	'analyseDependencies_showDialog' : function () {
		if (this.analyseDependenciesDialogWidget) this.analyseDependencies_closeDialog(); // destroy a potentially existing dialog widget
		
		this.analyseDependenciesDialogWidget = new application.widgets.OT_findListExportAllObjects.analyseDependenciesDialog({
			'OT_UUID'		: this.OT_UUID,
			'OT_name'		: this.parentWidget.OTName,
			'parentWidget'	: this,
		});
		
		this.analyseDependenciesDialogWidget.startup();
		this.analyseDependenciesDialogWidget.show();
		
	} // end of method analyseDependencies_showDialog
	,
	'analyseDependencies_closeDialog'	: function () {
		this.analyseDependenciesDialogWidget.hide();
		this.analyseDependenciesDialogWidget.destroyRecursive(false);
		this.analyseDependenciesDialogWidget.destroy();
		this.analyseDependenciesDialogWidget=null;
	} // end of method analyseDependencies_closeDialog
	,
	'export_showDialog' : function () {
		if (this.exportDialogWidget) this.export_closeDialog(); // destroy a potentially existing dialog widget
		
		var selectedObjects = this.selectedRows,
			allObjects		= this.numObjects;
					
		if (selectedObjects==allObjects) selectedObjects=0;
		
		this.exportDialogWidget = new application.widgets.OT_findListExportAllObjects.exportDialog({
			'OT_UUID'			: this.OT_UUID,
			'OT_name'			: this.parentWidget.OTName,
			'parentWidget'		: this,
			'selectedObjects' 	: selectedObjects,
			'allObjects' 		: allObjects,
		});
		
		this.exportDialogWidget.startup();
		this.exportDialogWidget.show();
		
	} // end of method export_showDialog
	,
	'export_closeDialog'	: function () {
		this.exportDialogWidget.hide();
		this.exportDialogWidget.destroyRecursive(false);
		this.exportDialogWidget.destroy();
		this.exportDialogWidget=null;
	} // end of method export_closeDialog
	,
	'_updateNumberOfFoundObjects' : function (n) {
		this.numObjects = n;
		this.set( 'title', ''
			+'<img src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/insert-table-2.png" style="vertical-align:top;margin-right:.5ex;"/>'
			+T(	'fLEAOsearchResultTab.js/FoundXItm_TIT',
				'Found $[0] items',[
					dojo.number.format(n)
				])
			);
		dojo.attr( this.containerNode, 'title', '');
	} // end of method _updateNumberOfFoundObjects
	,
	'numSelectedRowsChanged' : function (selectedRows) {
		this.selectedRows = selectedRows;
		this.widgets.selectDDMenuBarItem.attr('label', 
			(	this.selectedRows	
					?	T('fLEAOsearchResultTab.js/XSelItm_TXT', 
								'<code>$[0]</code> selected items&nbsp;…', 
								[dojo.number.format(this.selectedRows)])
					:	T('fLEAOsearchResultTab.js/NoSelItm_TXT', 'No selected items&nbsp;…')
			));
	} // end of method numSelectedRowsChanged
	,
});
