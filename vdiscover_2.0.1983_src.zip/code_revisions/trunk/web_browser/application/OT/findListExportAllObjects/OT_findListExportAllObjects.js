/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare('application.widgets.OT_findListExportAllObjects',[dijit.layout.BorderContainer],{

	// these parameters need to be passed
	'OT_UUID'	: null
	,
	
	
	
	// these parameters may be passed
	'optionalExecParameters' : null // here: {}
	,
	
	
	
	// internal variables
	'attrList'	: null	// {} with A_UUID as key and the attribute configuration as value
	,
	'attrStore'	: null 	// dojo.data.itemFileWriteStore with the attribute configuration
	,
	
	// settings for dijit.layout.BorderContainer
	'title' : 'Find & List' // will be replaced automatically
	,
	'gutters'	: false
	,
	'closable'	: true
	,
	// methods
	'postMixInProperties' : function () {
		this.inherited(arguments);
		
		//some initialisations
		this.widgets	= {};
		this.domNodes 	= {};
		
		if(!this.OT_UUID) throw this.declaredClass + ' :: '+postMixInProperties+': Cannot set up the widget because there was no OT_UUID passed.';
		
		// get the object type's name
		this.OTName='unknown';
		application.OT.navigationStore.fetch({
			'query': {'UUID':this.OT_UUID},
			'scope': this,
			'onItem': function(item){
				this.OTName=application.OT.navigationStore.getValue(item,'name');
			} // end of method onItem
		});
		
		this.title = ''
			+'<img src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/table-lightning.png" style="vertical-align:top;margin-right:.5ex;"/>'			
			+T('OT_findListExpAllObj.js/FindAndListObj_TAB','Find & list «$[0]»',[this.OTName]);
		
		// load the attribute list
		// load the attribute list from the server and create a store for them
		dojo.xhrPost({
			'url'		: '?'
			,
			'content'	: {
				'v'		: 'JSON_ObjectType',
				"task"	: 'get_OT_attributes', 
				"UUID"	: this.OT_UUID 
			}
			,
			'error'		: 	application.AJAX_errorMessage, // function
			'handleAs'	: 'json',
			'scope'		: this,
			'load'		: function(response,request){ /* onSuccess */
				
				var permittedForDependencyAnalysis = [
					'cNumberAttribute',
					'cMeasurementResultAttribute',
					'cFuzzyAttribute',
				];
				
				request.args.scope.attrList = {};
				dojo.forEach(response.items, function(i,index, itemArray){
					request.args.scope.attrList[dojo.clone(i.A_UUID)]=dojo.clone(i);
					itemArray[index]['permittedForDependencyAnalysis']=(dojo.indexOf(permittedForDependencyAnalysis, i.kind) > -1) ? true : false;
				},this);
				
				request.args.scope.attrStore = new dojo.data.ItemFileWriteStore({
						'data'			: response, 
						'clearOnClose' 	: true,
						// 'hierarchical'	: true
					});
				
			}, // end of onSuccess method
			//preventCache:true,
			//failOk	: true,
			'sync'		: true,
			'timeout'	: 	application.configuration.global.AJAX_default_timeout
		});

		// console.log(this.declaredClass+':: postMixInProperties', this.attrStore);
		
	} // end of method postMixInProperties
	,
	'postCreate' : function () {
		this.inherited(arguments);
		
		// create the main tab structure #####################################
		
		// Title pane with
		//	* heading
		//	* reload icon
		//	* find box + button
		//	* tab controller (aligned right)
		this.widgets.headerPane = new dijit.layout.ContentPane({
			'region'	: 'top',
			//'content'	: '<span style="">67 elements</span> | reload ',
			// 'style'		: 'margin-top:.5ex;'
		});
		this.addChild(this.widgets.headerPane);
		
		this.domNodes.headerContent = dojo.create('DIV',{
			'style'	: 'padding-left:.5ex;padding-right:.5ex;height:2.25em;position:relative;width:100%;'
		},this.widgets.headerPane.containerNode);
		
		this.domNodes.headerLeft = dojo.create('DIV',{
			'style'		: 'left:.5em;bottom:0;margin-bottom:.5ex;',
			// 'style'		: 'position:absolute;left:.5em;bottom:0;margin-bottom:.5ex;',
		},this.domNodes.headerContent);
		
		this.widgets.findForm = new dijit.form.Form({
			'encType'	: "multipart/form-data",
			'action'	: "",
			'method'	: "",
			'parentWidget' : this,
			'onSubmit' 	: function(e) {
				dojo.stopEvent(e); // this is necessary to avoid that the whole client application get's reloaded
				// console.log('onSubmit');
				// console.log(this.parentWidget.widgets.findBox.isValid());
				if (this.parentWidget.widgets.findBox.isValid()) {
					this.parentWidget.executeQuery(); 
				} // end if
				return false;
			} // end of method onSubmit
		}).placeAt(this.domNodes.headerLeft);
		
		this.widgets.findBox = new dijit.form.ValidationTextBox({
			'placeHolder'			: T('FUT_Find …','Find …'),
			// 'style'					: '',
			// 'intermediateChanges'	: true,
			'invalidMessage' 		: 'invalidMessage',
			'promptMessage' 		: T('OT_findListExpAllObj.js/PromptMsg_HTM','Type here what you want to find.<br/>You may use <code>*</code> as a wildcard char.<br/>E.g. <code>*123*</code> finds <code>64<i>123</i></code> and <code><i>123</i>45</code>.'),
			'regExp'				: '.*',
			'selectOnClick' 		: true,
			'maxLength'				: 255,
			'intermediateChanges'	: true,
		}).placeAt(/*this.domNodes.headerLeft*/this.widgets.findForm.containerNode);
		this.connect(this.widgets.findBox, 'onChange', '_findQuery_hasChanged');
		
		this.widgets.findSubmitButton = new dijit.form.Button({
			'type' 		: 'submit',
			// 'class'		: 'RS_clickableIcon RS_icon_refresh_small',
			'label'		: '<span class="RS_clickableIcon RS_icon_lightning_small"></span>',
			'title'		:  T('OT_findListExpAllObj.js/execFindQuery_TXT', 'Execute find query!'),
		}).placeAt(this.widgets.findForm.containerNode);
		this.connect(this.widgets.findSubmitButton, 'onClick', 'executeQuery');
		
		/*
		this.domNodes.reloadButton = dojo.create('SPAN',{
			'class'		: 'RS_clickableIcon RS_icon_refresh_small',
			'style'		: 'cursor:hand;margin-bottom:.5ex;margin-left:.33em;',
			'title'		: 'Find / Reload',
		}, this.domNodes.headerLeft);
		*/
		
		// this.domNodes.numElements = dojo.create('SPAN',{
			// 'innerHTML'	: '98.765 Elements found',
			// 'style'		: 'padding-left:.5em;',
		// }, this.domNodes.headerLeft);
		
		// body with tab container and tabs
		//	* Search results
		//	* Preferences
		//	* Export
		this.widgets.formContainer	 = new dijit.layout.StackContainer({
			'region'	: 'center',
			// 'style'		: 'margin-top:.5ex;',
		});
		this.addChild(this.widgets.formContainer);
		
		this.widgets.preferencesTab = new application.widgets.OT_findListExportAllObjects.preferenceTab({
			'OT_UUID'		: this.OT_UUID,
			'parentWidget'	: this,
			'queryName'		: this.title,
		}).placeAt(	this.widgets.formContainer );
		
		this.connect(this.widgets.preferencesTab, 'queryName_onChange', '_queryName_hasChanged');
		
		// execute optional commands -- this needs to be carried out before the query result widget is created
		if (typeof this.optionalExecParameters == 'object') {
			this.set('optionalExecParameters', this.optionalExecParameters);
		} // end if
		
		this.widgets.queryResultsTab = new application.widgets.OT_findListExportAllObjects.searchResultTab({
			'OT_UUID'		: this.OT_UUID,
			'parentWidget'	: this,
		});
		this.widgets.formContainer.addChild(this.widgets.queryResultsTab);
		
		this.widgets.loadStoredQueriesTab = new application.widgets.OT_findListExportAllObjects.loadTab ({
			'OT_UUID'		: this.OT_UUID,
			'parentWidget'	: this,
		}).placeAt( this.widgets.formContainer );
		
		
		this.widgets.tabController = new dijit.layout.StackController({
			'containerId': 	this.widgets.formContainer.id,
			'style'		: 'position:absolute;right:1.5em;bottom:0;',
			'buttonWidget':"dijit.layout._TabButton",
		}).placeAt(/*this.widgets.headerPane.containerNode*/this.domNodes.headerContent);
		
		dojo.create('DIV',{
			'class'	: 'dijitTabSpacer dijitTabContainerTop-spacer dijitAlignTop',
			'style'	: 'width:100%;position:static;height:.33ex;',
		},this.widgets.headerPane.containerNode);
		
	} // end of method postCreate
	,
	'startup' : function () {
		this.inherited(arguments);
		
		// the tabs of this widgets need some very special CSS
		for (var paneId in this.widgets.tabController.pane2button) {
			var button = this.widgets.tabController.pane2button[paneId];
			dojo.style(button.domNode, 'display', 'inline-block');
		} // end for .. in
		
		
		// focus the query results tab
		this.widgets.formContainer.selectChild(this.widgets.queryResultsTab);
		
		// this.widgets.preferencesTab.startup();
		// this.widgets.loadStoredQueriesTab.startup();
		// this.widgets.queryResultsTab.startup();
	
		// execute optional commands
		// if (typeof this.optionalExecParameters == 'object') {
			// this.set('optionalExecParameters', this.optionalExecParameters);
		// } // end if
	
	} // end of method startup
	,
	'destroy' : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		
		for (var i in this.widgets) {
			if (this.widgets[i].destroyRecursive) this.widgets[i].destroyRecursive(false);
			delete this.widgets[i];
		} // end for .. in
		
		//this.inherited(arguments);
	} // end of method destroy
	,
	'getSearchTerm' : function () {
		if (!this.widgets.findBox.isValid()) return '';
		return this.widgets.findBox.get('value');
	} // end of method getSearchTerm
	,
	'executeQuery' : function (e) {
		if(e) dojo.stopEvent(e);
	
		// detect whether to reload the query results or to simply switch to the corresponding pane
		if (this.widgets.formContainer.selectedChildWidget.id==this.widgets.queryResultsTab.id) {
			this.widgets.queryResultsTab.executeQuery();
		} else {
			// show the query result widget -- this executes the query, automatically
			this.widgets.formContainer.selectChild(this.widgets.queryResultsTab);
		} // end if
		
	} // end of method executeQuery
	,
	'loadFindQuery' : function (FL_UUID) {
		loader.show();
	
		// prepare the query
		var p = this.get('parameters'),
			URL = '?'
					+dojo.objectToQuery({
						'v'					: 'JSON_ObjectType',
						'task'				: 'get_OT_findList',
						'OT_UUID'			: this.OT_UUID,
						'FL_UUID'			: FL_UUID,
					});
		
		// execute the query
		dojo.xhrPost({
			'url'		: URL,
			'error'		: application.AJAX_errorMessage, // function
			'handleAs'	: 'json',
			'scope'		: this,
			'load'		: function(response,request){ /* onSuccess */	
				request.args.scope._parameteriseWithLoadedFindQuery( response );
			}, // end of onSuccess method
			//preventCache:true,
			//failOk	: true,
			'sync'		: true,
		});		
	
	} // end of method loadFindQuery
	,
	'_parameteriseWithLoadedFindQuery' : function (r) {
	
		// build the query parameter object
		var p = r.queryParameters;
		
		p.queryUUID 			= r.FL_UUID;
		p.changedAt 			= r.changedAt;
		p.changedByP_name 		= r.changedByP_name;
		p.changedByP_O_v_UUID	= r.changedByP_O_v_UUID;
		
		// set the query parameters
		this.widgets.preferencesTab.set('parameters', p);
		loader.hide();
		
		// execute the query
		this.executeQuery();
		// this.widgets.formContainer.selectChild(this.widgets.queryResultsTab);
		// this.widgets.queryResultsTab.executeQuery();
	
	} // end of method _parameteriseWithLoadedFindQuery
	,
	'_setOptionalExecParametersAttr' : function (p) {
	
		// check if this method is being called after creation
		if (!this._created) return;
	
		// check if the passed parameter p is an object
		if (typeof p != 'object') return;
	
		// parse the passed object
		switch (true) {
			case ('loadFindQuery' in p) : {
					var FL_UUID = p.loadFindQuery;
					this.loadFindQuery(FL_UUID);
				} // end case loadFindQuery
			
			default: // do nothing
		} // end switch
	
	} // end of method _setOptionalExecParametersAttr
	,
	'_getOptionalExecParametersAttr' : function () {
		return {};
	} // end of method _getOptionalExecParametersAttr
	,
	
	
	
	
	// chained reactions on events
	'_queryName_hasChanged' : function (qN) {
		this.set( 'title', ''
			+'<img src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/table-lightning.png" style="vertical-align:top;margin-right:.5ex;"/>'
			+qN );
		dojo.attr( this.containerNode, 'title', '');
	} // end of method _queryName_hasChanged
	,
	'_findQuery_hasChanged' : function (sQ) {
		
		if( !this.widgets.findBox.isValid() ) return;
		
		this.widgets.preferencesTab.set( 'searchQuery', 
			this.widgets.findBox.get('value') );
		
	} // end of method _findQuery_hasChanged
	,

	
});

// register the corresponding menu bar option
dojo.addOnLoad(function(){
	application.OT_menubar_itemKinds.register({
		'name'				: T('OT_findListExpAllObj.js/ListAllObj_MNU','List all Objects'),
		'UUID'				: "OT_menubar_itemKinds.general.all",
		'addWhenCreating' 	: true,
		'openByDefault' 	: true,
		'JS_command'		: function (OT_UUID, tabContainerID, optionalExecParameters) {
			var t_C 					= dijit.byId(tabContainerID),
				findListAllWidget_UUID	= 'OT_all_'+OT_UUID,
				findListAllWidget 				= dijit.byId(findListAllWidget_UUID);
			
			// this is a workaround because findListAllWidget does not get deleted, correctly, for some reasons
			if(findListAllWidget && findListAllWidget._beingDestroyed) {
				dijit.registry.remove(findListAllWidget_UUID);
				findListAllWidget = null;
			} // end if
			
			// create findListAllWidget, if necessary
			if(!findListAllWidget) {
				findListAllWidget= new application.widgets.OT_findListExportAllObjects({
					'id'					: findListAllWidget_UUID,
					'OT_UUID'				: OT_UUID,
					'optionalExecParameters': optionalExecParameters
				});
				t_C.addChild(findListAllWidget);
			} else {
				// pass the optional exec parameters for parsing
				findListAllWidget.set('optionalExecParameters', optionalExecParameters);
				
			} // end if
		
			// focus the widget
			t_C.selectChild(findListAllWidget,true/*means: animated*/);
		
			
		
		
		} // end-of-method showAllInfObjs
		,
		'description'		:	""
			// +"<p>This menu item for object types is purely experimental! It is not fit for daily use.</p>"
			+ T('OT_findListExpAllObj.js/ThisCommandOpensDescr_HTM','<p>This command opens the tab with a list of all objects of the type.</p><p>This list is useful to quickly navigate over all objects.</p>')
			
	});
}); // end dojo.addOnLoad
