/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare('application.widgets.OT_findListExportAllObjects.preferenceTab',[dijit.layout.BorderContainer /*dijit._Widget, dijit._Templated*/],{
	// 'widgetsInTemplate' : true
	// ,
	'title'	: '<img src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/categories/preferences-system-2.png" style="vertical-align:text-top;"/>'
		+'&nbsp;'
		+T('FUT_Preferences','Preferences')
		,
	'gutters'	: false,
	
	
	'queryName'				: null // string
	,	
	'queryUUID'				: null // UUID string
	,
	'maxNumObjects_default'	: 50 // integer
	,
	'storedQueryInfo'		: null // {}
	
	,
	'generalPropertyDefs' : {
			'points'		: {'label': T('FUT_Points',		'Points'), 			'type': 'generalProperty'},
			'tagged'		: {'label': T('FUT_Tagged',		'Tagged') + '?',	'type': 'generalProperty'},
			'name' 			: {'label': T('FUT_ObjectName',	'Object Name'), 	'type': 'generalProperty'},
			'description' 	: {'label': T('FUT_Description','Description'), 	'type': 'generalProperty'},
			'lastChangeAtBy': {'label': T('FUT_LastChange',	'Last change'),		'type': 'generalProperty'},
		} // end of generalPropertyDefs definition
	,
	'defaultColSet'			: [
			'points', 
			'tagged', 
			'name', 
			// 'description', 
			// 'lastChangeAtBy'
		] // end of defaultColSet definition
	,
	'defaultSortBy'			: 'points', // one element of this.defaultColSet
	'defaultSortDir_ASC'	: true,
	'defaultSearchQuery'	: '',
	'defaultQueryUUID'		: '- no query UUID, yet -',
	'defaultQUsage'			: 'justMe',
	
	'constructor'			: function () {
	
		// some initialisations ...
		this.widgets 		= {};
		
		this.selectedColSet = [];
		
		this.queryName		= '';
		this.searchQuery	= this.defaultSearchQuery;
		this.orderAsc		= this.defaultSortDir_ASC;
		this.orderBy		= this.defaultSortBy;
		this.returnMaxObjects= this.maxNumObjects_default;
		this.queryUUID		= this.defaultQueryUUID; // Math.uuid();
		
		this.storedQueryInfo= null;
	
	} // end of method constructor
	,
	'postMixInProperties'	: function () {
		this.inherited(arguments);
		
		this.attrStore = this.parentWidget.attrStore;
		
	} // end of method postMixInProperties
	,
	'postCreate'			: function () {
		this.inherited(arguments);

		this.widgets.heading = new dijit.layout.ContentPane({
			'region'	: 'top',
			'content'	: ''
				+'<h2>' 
					+'<img src="third_party_libraries/open-icon-library-standard-0.10/icons/png/32x32/categories/preferences-system-2.png" style="vertical-align:text-bottom;"/>'
					+'&nbsp;'
					+T('FUT_Preferences', 'Preferences')
					+'<img class="_reset_domNode" src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/edit-undo-7.png" style="margin-left:.5ex;cursor:pointer;vertical-align:text-bottom;" title="'
						+T('fLEAOpreferenceTab.js/resetToDefaults_TXT','Apply the default settings.')
					+'" />'
				+'</h2>'
				,
			'style'		: 'padding:.5ex;',
		}).placeAt(this);
		this.connect( dojo.query( 'img._reset_domNode', this.widgets.heading.containerNode ).pop(),
						'onclick',
						'_applyDefaultSettings'
						);
		
		this.widgets.storePane = new dijit.layout.ContentPane({
			'style'		: 'padding:.5ex;',
			'region'	: 'bottom',
			'content'	: ''
				+'<div class="RS_1column">'
					+'<hr/>'
				+'</div>'
				
				+'<div class="RS_2columns">'
					+'<h3>'
						+T('fLEAOpreferenceTab.js/retainQuery_TXT','Store this query') 
					+'</h3>'
					
					+'<table class="compact fullWidth">'
						+'<tr>'
							+'<td>'
								+'<p style="display:inline-block;">'
										+T( 'fLEAOpreferenceTab.js/queryName_TXT',
											'Please enter the query name, here:'
											)
									+'<span class="_queryNameWidget_domNode"></span>'
								+'</p>'
								
								+'<p>' 
									+T( 'fLEAOpreferenceTab.js/queryAvailability_TXT',
										'Who shall use this query?'
										)
								+'</p>'
								+'<p>'
									+'<span class="_queryAvailabilityJustMe_domNode" style="cursor:pointer;">' 
										+T( 'fLEAOpreferenceTab.js/queryAvailabilityJustMe_TXT',
											'Just me.'
											)
									+'</span>'
									+'<span class="_queryAvailabilityEverybody_domNode" style="cursor:pointer;">' 
										+T( 'fLEAOpreferenceTab.js/queryAvailabilityEverybody_TXT',
											'Everybody.'
											)
									+'</span>'
								+'</p>'
							+'</td>'
							+'<td>'
								+'<div class="_storeChangesButton_domNode" style=""></div>'
							+'</td>'
						+'</tr>'
					+'</table>'
					
				+'</div>'
				
				+'<div  class="_deleteQuery_domNode RS_2columns"  style="">'
				
					+'<h3>'
						+T('fLEAOpreferenceTab.js/deleteQuery_TXT','Delete this query on the server') 
					+'</h3>'
					
					+'<table class="compact fullWidth">'
						+'<tr>'
							+'<td style="vertical-align:top;">'
								+'<p>' 
									+T( 'fLEAOpreferenceTab.js/deleteQueryExpl_TXT',
										'This query is stored on the server.'
										)
								+'</p>'
								+'<p>'
									+T(	'fLEAOpreferenceTab.js/storedQueryProperties_TXT',
										'The last change was carried out by $[0] at $[1].',
										[	'<span class="_lastChangeBy_domNode"></span>',
											'<span class="_lastChangeOn_domNode code"></span>',
										])
							+'</td>'
							+'<td>'
								+'<div class="_deleteQueryButton_domNode"></div>'
							+'</td>'
						+'</tr>'
					+'</table>'
					
				+'</div>'					
				,
		}).placeAt(this);
		
		// connect the DOM nodes
		dojo.forEach([
			// '_lastChange_domNode',
			'_lastChangeOn_domNode',
			'_lastChangeBy_domNode',
			'_queryNameWidget_domNode',
			'_queryAvailabilityJustMe_domNode',
			'_queryAvailabilityEverybody_domNode',
			'_storeChangesButton_domNode',
			'_deleteQuery_domNode',
			'_deleteQueryButton_domNode',
		], function (s) {
			this[s] = dojo.query( '.'+s, this.widgets.storePane.containerNode ).pop();
		}, this);
		
		// create the input box for the query name
		this.widgets.queryName = new dijit.form.ValidationTextBox({
			'value'					: this.queryName,
			'regexp'				: '.{2,}',
			'class'					: 'fullWidth',
			'selectOnClick'			: true,
			'required'				: true,
			'intermediateChanges'	: true,
		}).placeAt( this._queryNameWidget_domNode );
		
		// set up the radio buttons for the query availability
		var qUsageNameTag = this.queryUUID + '__nameTag';
		this.widgets.QUsageJustMe = new dijit.form.RadioButton({
			'checked'				: true,
			'name'					: qUsageNameTag,
			'style'					: 'margin-right:.5ex;',
		}).placeAt(this._queryAvailabilityJustMe_domNode, 'first' );
		this.connect( this._queryAvailabilityJustMe_domNode, 'onclick', '_justMeClicked' );
		
		this.widgets.QUsageAll = new dijit.form.RadioButton({
			'checked'				: false,
			'name'					: qUsageNameTag,
			'style'					: 'margin-right:.5ex;',
		}).placeAt(this._queryAvailabilityEverybody_domNode, 'first' );
		this.connect( this._queryAvailabilityEverybody_domNode, 'onclick', '_everybodyClicked' );
		
		// set up the buttons for storing changes
		this.widgets.storeChangesButton = new dijit.form.Button({
			'label'					: '<img src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/table-save.png" style="vertical-align:text-top;">&nbsp;'
										+T(	'fLEAOpreferenceTab.js/store_BTN',
											'Store'
											),
			'disabled'				: false,
			'style'					: 'float:right;',
		}).placeAt( this._storeChangesButton_domNode );
		this.connect( this.widgets.storeChangesButton, 'onClick', '_storeFindQuery' );
		
		this.widgets.deleteQueryButton = new dijit.form.Button({
			'label'					: '<img src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/table-delete-2.png" style="vertical-align:text-top;">&nbsp;'
										+T(	'BTN_Delete',
											'Delete'
											),
			'disabled'				: false,
			'style'					: 'float:right;',
		}).placeAt( this._deleteQueryButton_domNode );
		this.connect( this.widgets.deleteQueryButton, 'onClick', '_deleteFindQuery' );
		
		// initialise the stored query info table
		this.set('storedQueryInfo', {});
		
		// #####################################################################################################
		
		this.widgets.mainPane = new dijit.layout.ContentPane({
			'style'		: 'padding:.5ex;',
			'region'	: 'center',
			'content'	: ''
				+'<div class="RS_2columns">'
					+'<h3>'
						+T('FUT_ColumnHeaders','Column headers') 
					+'</h3>'
					+'<p>' 
						+T('fLEAOpreferenceTab.js/PleaseSelectColHdr_TXT', 'Please select the column headers and order them as you like:')
					+'</p>'
					+'<div class="_headerSelectorWidget_domNode"></div>'
					+'<p>&nbsp;</p>'

					+'<h3>'
						+T('FUT_OrderBy','Order by') 
					+'</h3>'
					
					+'<div class="_sortByWidget_domNode"></div>'
					
					+'<p class="_sortByAscending_domNode" style="cursor:pointer;">' 
						+T( 'fLEAOpreferenceTab.js/sortByAscending_TXT',
							'$[0]&nbsp;Ascending <code>0…1…9…A…Z</code>.',
							['<img src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/view-sort-ascending-2.png" style="vertical-align:text-top;"/>']
							)
					+'</p>'
					+'<p class="_sortByDescending_domNode" style="cursor:pointer;">' 
						+T( 'fLEAOpreferenceTab.js/sortByDescending_TXT',
							'$[0]&nbsp;Descending <code>Z…A…9…1…0</code>.',
							['<img src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/view-sort-descending-2.png" style="vertical-align:text-top;"/>']
							)
					+'</p>'
					+'<p>&nbsp;</p>'
					
				+'</div>'
				
				+'<div class="RS_2columns">'
					+'<h3>'
						+ T('fLEAOpreferenceTab.js/HandlingLQueries_TXT', 'Handling queries with big responses') 
					+'</h3>'
					+'<p>'
						+ T('fLEAOpreferenceTab.js/MaxNumObj_TXT','Maximum number of objects to be retrieved at once:')
						+'<div class="_maxNumObjects_domNode" ></div>'
						+' ' 
						+ T('FUT_items','items') 
						+ '.'
					+'</p>'
					
					+'<p>&nbsp;</p>'
				+'</div>'
				
				+'<div class="RS_2columns">'
					+'<h3>'
						+ T('fLEAOpreferenceTab.js/FindQuery_TXT', 'Find query') 
					+'</h3>'

					+'<div class="_searchQueryWidget_domNode"></div>'
					
					+'<p>' 
						+ T('fLEAOpreferenceTab.js/searchQuerxExpl_TXT',
							'The find query is the content of the « Find»  input box. You may use the wildcard char <code>*</code> in find queries.<br/> E.g. <code>*bird</code> will find<br/><code><i>black</i>bird</code>,  <code>bird</code>, <code><i>lady</i>bird</code>, …'
							)
					+'</p>'
					
					+'<p>&nbsp;</p>'
				+'</div>'
				,
		}).placeAt(this);
		
		// connect the DOM nodes
		dojo.forEach([
			'_headerSelectorWidget_domNode',
			'_sortByWidget_domNode',
			'_sortByAscending_domNode',
			'_sortByDescending_domNode',
			'_maxNumObjectsWidget',
			'_searchQueryWidget_domNode',
			'_maxNumObjects_domNode',
		], function (s) {
			this[s] = dojo.query( '.'+s, this.widgets.mainPane.containerNode ).pop();
		}, this);
		
		// set up the list of selected columns
		if(!this.selectedColSet.length) this.selectedColSet = dojo.clone( this.defaultColSet );
		
		// build the item list 
		this.itemList = {};
		
		// add this.generalPropertyDefs to the item list
		for (var UUID in this.generalPropertyDefs) {
			this.itemList[UUID] = this.generalPropertyDefs[UUID].label;
		} // end for ... in
		
		// add the attribute columns to the item list
		this.attrStore.fetch({
			'scope'		: this,
			// 'query'	: {'queryPart':true,	'searchType':'can'},
			'sort'		: [{'attribute': 'position', 'descending': false}],
			'onItem'	: function(item){
				// check whether the attribute is listed, already
				var UUID = this.attrStore.getValue(item, 'UUID');
				if (dojo.indexOf(this.selectedColSet, UUID)<0) {
					var	name = this.attrStore.getValue(item, 'name');
						this.itemList[UUID] = name;
				} // end if 
			} // end onItem
		}); // end fetch
		
		// create the sortable check list widget
		this.widgets.headerSelector = new common.widgets.sortableCheckList({
			'style'					: 'max-height:15em;overflow-y:auto;display:block;',
			'itemList'				: this.itemList,
			'checkedItems'			: this.selectedColSet,
			'checkedItemsLabel'		: '<h4>' + T('fLEAOpreferenceTab.js/SelColHdr_TXT','Selected col headers') + '</h4>',
			'uncheckedItemsLabel'	: '<h4>' + T('fLEAOpreferenceTab.js/AvailColHdr_TXT','Available col headers') + '</h4>',
		}).placeAt( this._headerSelectorWidget_domNode );
		this.connect( this.widgets.headerSelector, 'onChange', '_headerListChanged' );
		
		//set up the widget for the search query
		this.widgets.searchQueryBox = new dijit.form.ValidationTextBox({
			'value'					: this.searchQuery,
			// 'regexp'				: '.{2,}',
			'class'					: 'fullWidth code',
			'selectOnClick'			: true,
			'intermediateChanges'	: true,
			// 'required'				: true,
		}).placeAt( this._searchQueryWidget_domNode );
		
		// set up the order by select box
		this.widgets.orderBySelect = new dijit.form.Select({
			'style'					: 'width:100%;',
			'options'				: [],
		}).placeAt( this._sortByWidget_domNode );
		this._headerListChanged( this.widgets.headerSelector.getCheckedItems(), this.defaultSortBy );
		
		// set up the radio buttons for the ordering direction
		var orderingDirNameTag = this.queryUUID + '__orderDir';
		this.widgets.orderAsc = new dijit.form.RadioButton({
			'checked'				: this.orderAsc,
			'name'					: orderingDirNameTag,
			'style'					: 'margin-right:.5ex;',
		}).placeAt(this._sortByAscending_domNode, 'first' );
		this.connect( this._sortByAscending_domNode, 'onclick', '_orderAscClicked' );
		
		this.widgets.orderDesc = new dijit.form.RadioButton({
			'checked'				: !this.orderAsc,
			'name'					: orderingDirNameTag,
			'style'					: 'margin-right:.5ex;',
		}).placeAt(this._sortByDescending_domNode, 'first' );
		this.connect( this._sortByDescending_domNode, 'onclick', '_orderDescClicked' );
		
		// maximum number of objects to be retrieved at once
		this.widgets.maxNumObjects = new dijit.form.NumberSpinner({
			'constraints'	: {'max':1000, 'min':10},
			'largeDelta'	: 100,
			'smallDelta'	: 25,
			'required'		: true,
			'style'			: 'width:5em;',
			'value'			: this.returnMaxObjects,
		}).placeAt(this._maxNumObjects_domNode);
		
		// apply default settings
		this._applyDefaultSettings();
		
	} // end of method postCreate
	,
	'destroy' : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		
		for (var i in this.widgets) {
			if (this.widgets[i].destroyRecursive) try{
				this.widgets[i].destroyRecursive();
			} catch(e) {
				console.error('Problem in '+this.declaredClass+'::destroy():\nWhen trying to delete subwidget "'+i+'", the following error was thrown:');
				console.error(e);
				console.log('this', this);
				console.log('this.widgets[i]', this.widgets[i]);
				dijit.registry.remove(this.widgets[i].id);
			} // end if .. try
			delete this.widgets[i];
		} // end for .. in
		
		this.inherited(arguments);
	} // end of method destroy
	,
	'startup' : function() {
		// If you need to be sure parsing and creation of any child widgets has 
		// completed, use startup. This is often used for layout widgets like 
		// BorderContainer. If the widget does JS sizing, then startup() should 
		// call resize(), which does the sizing.
		this.inherited(arguments);
		
		// this should take car of displaying all up/down arrows, properly
		this.widgets.headerSelector.startup();
		
		this.connect( this.widgets.queryName, 		'onChange', '_queryNameChanged' );
		this.connect( this.widgets.searchQueryBox, 	'onChange', '_searchQueryBoxChanged' );
		
	} // end of method startup
	,
	
	// methods that are connected to events ...
	
	'_headerListChanged' : function (hL, overrideSortBy_UUID) {
		// hL is of type []
	
		var selectW			= this.widgets.orderBySelect,
		
			selectedItemUUID= overrideSortBy_UUID || selectW.get('value'),
			oldItems		= selectW.getOptions(); // []
				
		// remove all old items
		dojo.forEach(oldItems, function(i) {
			selectW.removeOption(i.value);
		}, this); // end dojo.forEach
		
		// create an item for "nothing selected"
		selectW.addOption({
			'value'		: '',
			'label'		: T('fLEAOpreferenceTab.js/nothingSelected_TXT',
							'&mdash;'
							),
			'selected'	: true,
		});
		
		// create new items
		dojo.forEach(hL, function (UUID) {
		
			// get the item's name
			var name = '';
			if (UUID in this.generalPropertyDefs) {
				name = this.generalPropertyDefs[UUID].label;
			} else {
				this.attrStore.fetch({
					'scope'		: this,
					'query'		: {'UUID': UUID},
					'onItem'	: function(item){
						name = this/*.scope*/.attrStore.getValue(item, 'name');
					} // end onItem
				}); // end fetch
			} // end if
		
			// add the new item
			selectW.addOption({
				'value'		: UUID,
				'label'		: name,
				// 'selected'	: ( (UUID==selectedItemUUID) ? true : false ),
			});
			
		}, this); // end dojo.forEach
		
		// set the last selection, if applicable
		if ( dojo.indexOf(hL, selectedItemUUID)>=0 ) {
			selectW.set('value', selectedItemUUID);
		} // end if
	
	} // end of method _headerListChanged
	,
	'_searchQueryBoxChanged' : function () {
		var sQ = '';
		if( this.widgets.searchQueryBox.isValid() ) {
			sQ = this.widgets.searchQueryBox.get('value');
		} // end if
		
		this.searchQuery = sQ;
		
		var findBoxSQ = this.parentWidget.widgets.findBox.get('value');
		
		if( this.searchQuery != findBoxSQ ) {
			this.parentWidget.widgets.findBox.set( 'value', this.searchQuery);
		} // end if 
		
	} // end of method _searchQueryBoxChanged
	,
	
	'_justMeClicked' : function (e) {
		dojo.stopEvent(e);
		this.widgets.QUsageJustMe.set('checked', true);
	} // end of method _justMeClicked
	,
	'_everybodyClicked' : function (e) {
		dojo.stopEvent(e);
		this.widgets.QUsageAll.set('checked', true);
	} // end of method _everybodyClicked
	,
	
	'_orderAscClicked' : function (e) {
		dojo.stopEvent(e);
		this.widgets.orderAsc.set('checked', true);	
	} // end of method _orderAscClicked
	,
	'_orderDescClicked' : function (e) {
		dojo.stopEvent(e);
		this.widgets.orderDesc.set('checked', true);	
	} // end of method _orderDescClicked
	,
	'_queryNameChanged' : function (qN) {
		if ( this.widgets.queryName.isValid() ) {
			this.queryName = this.widgets.queryName.get('value');
			this.queryName_onChange(this.queryName);
		} // end if	
	} // end of method _queryNameChanged
	,
	
	
	'_setParametersAttr' : function (p) {
		/** This method sets all query parameters at once.
		*
		*/
	
		// Query name and usage
		this.widgets.queryName.set( 'value', p.queryName );
		this.widgets.QUsageJustMe.set('checked', ( ( p.usage == 'justMe' ) ? true : false ) );
		
		// Selected columns/ attributes
		this.widgets.headerSelector.uncheckAll();
		dojo.forEach( p.colHeaders, function (UUID) {
			this.widgets.headerSelector.check(UUID);
		}, this);
		
		this.widgets.orderBySelect.set('value', p.orderBy);
		this.widgets.orderAsc.set('checked', p.orderAsc);
		
		// Limit for fetching objects
		this.widgets.maxNumObjects.set('value', p.returnMaxObjects);
		
		// Find query
		this.set('searchQuery', p.searchQuery);
	
		// Optional slots (for stored queries)
		
		var i = {},
			sQSlots = [
				'changedAt',
				'changedByP_O_v_UUID',
				'changedByP_name',
			];
		
		dojo.forEach(sQSlots, function(slot){
			if (slot in  p) i[slot] = p[slot];
		}, this);
		this.set('storedQueryInfo', i);
		
		// Query UUID
		if ('queryUUID' in p) this.set('queryUUID', p.queryUUID);
		
		return this.get('parameters');
	} // end of method _setParametersAttr
	,
	'_getParametersAttr' : function () {
		/** This method returns all query parameters.
		*
		*/
	
		var p = {
			'OT_UUID'			: this.parentWidget.OT_UUID,
			'queryName'			: this.widgets.queryName		.get( 'value' ),
			'queryUUID'			: this.queryUUID,
			'usage'				: ( this.widgets.QUsageJustMe	.get('checked') ? 'justMe' : 'everybody' ),
			'colHeaders'		: this.widgets.headerSelector	.getCheckedItems(),
			'returnMaxObjects'	: this.widgets.maxNumObjects	.get('value'),
			'searchQuery'		: this.widgets.searchQueryBox	.get('value'),
			'orderBy'			: this.widgets.orderBySelect	.get('value'),
			'orderAsc'			: this.widgets.orderAsc			.get('checked'),
		};
		
		return p;
	} // end of method _getParametersAttr
	,
	
	'_setSearchQueryAttr' : function (sQ) {
		this.searchQuery = sQ;
		this.widgets.searchQueryBox.set('value', sQ);
		return sQ;
	} // end of method _setSearchQueryAttr
	,
	'_getSearchQueryAttr' : function () {
		return this.widgets.searchQueryBox.get('value');
	} // end of method _getSearchQueryAttr
	,
	
	'_setQueryUUIDAttr' : function (Q_UUID) {
		return this.queryUUID = Q_UUID;
	} // end of method _setSearchQueryAttr
	,
	'_getQueryUUIDAttr' : function () {
		return this.queryUUID;
	} // end of method _getSearchQueryAttr
	,
	
	'_setStoredQueryInfoAttr' : function (i) {
		this.storedQueryInfo = {};
	
		dojo.attr(this._lastChangeOn_domNode, 'innerHTML', '&mdash;' );
		dojo.attr(this._lastChangeBy_domNode, 'innerHTML', '&mdash;' );
	
		// set last changes
		if ('changedAt' in i) {
			this.storedQueryInfo.changedAt = i.changedAt;
		
			// output the formatted date
			var timeStamp 	= this.storedQueryInfo.changedAt,
				d 			= new Date( timeStamp.replace(' ', 'T') );
		
			dojo.attr(this._lastChangeOn_domNode, 'innerHTML', dojo.date.locale.format(d) );
		} // end if

		// set info about last changer
		if(		('changedByP_O_v_UUID' in i) 
			&&	('changedByP_name' in i)
											) {
			this.storedQueryInfo.changedByP_O_v_UUID 	= i.changedByP_O_v_UUID;
			this.storedQueryInfo.changedByP_name 		= i.changedByP_name;
			
			// try to delete an already existing widget with info about the last changer
			if (this.lastChangerWidget) {
				this.lastChangerWidget.destroy();
				this.lastChangerWidget = null;
			} // end if
			
			this.lastChangerWidget = new application.widgets.internalLink({
				'O_v_UUID' 			: this.storedQueryInfo.changedByP_O_v_UUID,
				'linkName' 			: this.storedQueryInfo.changedByP_name,
			}).placeAt( dojo.create( 'DIV', {}, this._lastChangeBy_domNode, 'only' ));
			
		} // end if
		
		// show or hide the table with information about last changes and the delete query region
		var show = (Object.keys(this.storedQueryInfo).length);
		
		dojo.style( this._deleteQuery_domNode, 'display',
			( show ? 'block' : 'none' ) );
		
		return this.storedQueryInfo;
		} // end of method _setSearchQueryAttr
	,
	'_getStoredQueryInfoAttr' : function () {
		return this.storedQueryInfo;
	} // end of method _getSearchQueryAttr
	,
	
	
	
	
	
	
	'_storeFindQuery' : function (e) {
		dojo.stopEvent(e);
		loader.show();
	
		// prepare the query
		var p = this.get('parameters'),
			URL = '?'
					+dojo.objectToQuery({
						'v'					: 'JSON_ObjectType',
						'task'				: 'save_OT_findList',
						'OT_UUID'			: p.OT_UUID,
						'queryParameters' 	: dojo.toJson(p),
			});
		
		// execute the query
		dojo.xhrPost({
			'url'		: URL,
			'error'		: application.AJAX_errorMessage, // function
			'handleAs'	: 'json',
			'scope'		: this,
			'load'		: function(response,request){ /* onSuccess */
				request.args.scope.set( 'storedQueryInfo',	response.storedQueryInfo	);
				// the query uuid is usually defined by the server
				request.args.scope.set( 'queryUUID', 		response.FL_UUID			);
			}, // end of onSuccess method
			//preventCache:true,
			//failOk	: true,
			'sync'		: true,
		});		
	
		loader.hide();
	} // end of method _storeFindQuery
	,
	'_deleteFindQuery' : function (e) {
		dojo.stopEvent(e);
		loader.show();
	
		// prepare the query
		var p = this.get('parameters'),
			URL = '?'
					+dojo.objectToQuery({
						'v'					: 'JSON_ObjectType',
						'task'				: 'delete_OT_findList',
						'OT_UUID'			: p.OT_UUID,
						'FL_UUID'			: p.queryUUID,
						// 'queryParameters' 	: dojo.toJson(p),
			});
		
		// execute the query
		dojo.xhrPost({
			'url'		: URL,
			'error'		: application.AJAX_errorMessage, // function
			'handleAs'	: 'json',
			'scope'		: this,
			'load'		: function(response,request){ /* onSuccess */				
				// request.args.scope.finishQuery( response.items, response.totalCountObjects );
			}, // end of onSuccess method
			//preventCache:true,
			//failOk	: true,
			'sync'		: true,
		});		
	
		this._applyDefaultSettings();
	
		loader.hide();
	} // end of method _storeFindQuery
	,
	'_applyDefaultSettings' : function (e) {
		if (e) dojo.stopEvent(e);

		// reset the column headers
		this.widgets.headerSelector.uncheckAll();
		dojo.forEach( this.defaultColSet, function (UUID) {
			this.widgets.headerSelector.check(UUID);
		}, this);
		
		// set order by to default
		this.widgets.orderBySelect.set('value', this.defaultSortBy);
		
		// set the order direction to ascending
		this.widgets.orderAsc.set('checked', this.defaultSortDir_ASC);

		// set the max number of objects to be returned at once to the default value
		this.widgets.maxNumObjects.set('value', this.maxNumObjects_default);
		
		// set the find query to the default value
		this.widgets.searchQueryBox.set( 'value', this.defaultSearchQuery);
		
		// set the query uuid to the default value
		this.set( 'queryUUID', this.defaultQueryUUID);
		
		// set the query name to the default value
		this.widgets.queryName.set(	'value',
			T(	'OT_findListExpAllObj.js/FindAndListObj_TAB',
				'Find & list «$[0]»', [
					this.parentWidget.OTName
				])
			);
		
		// set the query usage to the default value
		this.widgets.QUsageJustMe.set('checked', ( ( this.defaultQUsage == 'justMe' ) ? true : false ) );
	
		// stored query info
				this.set('storedQueryInfo', {});
	
	} // end of method _applyDefaultSettings
	,
	
	
	
	// Events ---------------------------------------------------------------------
	'queryName_onChange' : function (qN) {},
});
