/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare('application.widgets.OT_findListExportAllObjects.confirmDeleteDialog',[common.widgets.fixedSizeDialog],{
	'innerWidth'	: 400
	,
	'innerHeight'	: 250
	,
	'constructor' : function() {
		// Your constructor method will be called before the parameters are mixed into the widget, and can be used to initialize arrays, etc.
		this.inherited(arguments);
		
		// some initialisations
		this.widgets 		= {};
		
	} // end of method constructor
	,
	'postMixInProperties' : function () {
		this.inherited(arguments);
	
		// set the dialog title
		this.title= ''
			+ T('fLEAO.confirmDeleteDialog.js/DelTitle_HTM','Do you want to delete « $[0]» ?',[this.OT_name]);
	
	} // end of method postMixInProperties
	,
	'postCreate' : function () {
		// This is typically the workhorse of a custom widget. The widget has 
		// been rendered (but note that sub-widgets in the containerNode have not!). 
		// The widget though may not be attached to the DOM yet so you shouldn't 
		// do any sizing calculations in this method.
		this.inherited(arguments);
			
			// build the main structure of the dialog
		this.widgets.borderContainer = new dijit.layout.BorderContainer({
			'style' 	: 'width:100%;height:100%;',
			'gutters'	: false
		}).placeAt(this.containerNode);
		
		// create the action bar at the bottom of the dialog
		this.widgets.actionBar = new dijit.layout.ContentPane({
			'region'	: 'bottom',
			'class'		: 'dijitDialogPaneActionBar textRight',
			'style'		: 'padding-top:1em;'
		});
		this.widgets.borderContainer.addChild(this.widgets.actionBar);

		this.widgets.OkButton = new dijit.form.Button({
			'label' 	: '<img src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/dialog-ok-apply-4.png"/> '
				+ T('BTN_OK','OK'),
			'type'		: 'button'
		}).placeAt(this.widgets.actionBar.containerNode);

		// this.connect(this.widgets.OkButton,'onClick','execute');
		this._connects.push(dojo.connect( this.widgets.OkButton,	'onClick', this.parentWidget, 'deleteSelection_execute'));
		
		this.widgets.CancelButton = new dijit.form.Button({
			'label' 	: '<img width="12" src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/dialog-cancel-4.png"/> '
				+ T('BTN_Cancel','Cancel'),
			'type'		: 'button',
			'style'		: 'margin-right:0;'
		}).placeAt(this.widgets.actionBar.containerNode);
		
		this._connects.push(dojo.connect( this.widgets.CancelButton,	'onClick', this.parentWidget, 'deleteSelection_closeDialog'));
		this._connects.push(dojo.connect( this.widgets.closeButtonNode,	'onClick', this.parentWidget, 'deleteSelection_closeDialog'));

		// create the main pane of the dialog
		
		this.widgets.mainPane = new dijit.layout.ContentPane({
			'region'	: 'center',		
		});
		this.widgets.borderContainer.addChild(this.widgets.mainPane);
		
		this.radioButtonName = Math.uuid();
		
		this.contentDomNode = dojo.create('DIV', {
			'innerHTML'	: ''
				+'<table class="compact fullWidth">'
					+'<tr>'
						+'<td width="25%" class="textCenter">'
							+'<img width="64" src="third_party_libraries/open-icon-library-standard-0.10/icons/png/64x64/status/dialog-warning-2.png"/> '
						+'</td>'
						+'<td style="vertical-align:top;">'
							+'<p>' 
								+ T('fLEAO.confirmDeleteDialog.js/YouAreAboutToDel_HTM',
									'You are about to delete « $[0]» .',
									[this.OT_name]
									)
							+ '</p>'
							+(	(this.selectedObjects)
									?	'<p>&nbsp;<span class="onlySelectedObjects"/></span>&nbsp; '
											+'<span class="onlySelectedObjects_clickHere">' 
											+ T('fLEAO.confirmDeleteDialog.js/IWantToDel_HTM','I want to delete the <code>$[0]</code> selected ones.',[this.selectedObjects]) 
											+ '</span></p>'
									:	'' )
							+'<p>&nbsp;<span class="allObjects"/></span>&nbsp; '
								+'<span class="allObjects_clickHere">' 
									+ T('fLEAO.confirmDeleteDialog.js/WantToDelAll_HTM','I want to delete all (in total <code>$[0]</code>).',[this.allObjects]) 
								+'</span></p>'
							+'<p>&nbsp;</p>'
							+ T('fLEAO.confirmDeleteDialog.js/IsThisAWiseStep', '<p>Is this a wise step?</p><p>&nbsp;</p><p>If you think so, click on « OK» .</p>')
						+'</td>'
					+'</tr>'
				+'</table>'
		}, this.widgets.mainPane.containerNode);
		
		if (this.selectedObjects) {
			this.widgets.deleteOnlySelected_RB = new dijit.form.RadioButton({
				'name'		: this.radioButtonName,
				'checked'	: true,
			}, dojo.query('.onlySelectedObjects', this.contentDomNode ).pop());
		} // end if 
		
		this.widgets.deleteAll_RB = new dijit.form[(this.selectedObjects?'RadioButton':'CheckBox')]({
			'name'		: this.radioButtonName,
			'checked'	: false,
		}, dojo.query('.allObjects', this.contentDomNode ).pop());
		this.connect( dojo.query('.allObjects_clickHere', this.contentDomNode ).pop(), 'onclick', 'clickOn_allObjects');
		
		if (this.selectedObjects) {
			this.connect( dojo.query('.onlySelectedObjects_clickHere', this.contentDomNode ).pop(), 'onclick', 'clickOn_onlySelectedObjects');
		} else {
			this.widgets.OkButton.set('disabled', true);
			this.connect( this.widgets.deleteAll_RB, 'onChange', '_allObjectsCBToggled');
		}// end if
		
		
	} // end of method postCreate
	,
	'clickOn_onlySelectedObjects' : function (e) {
		this.widgets.deleteOnlySelected_RB.attr('checked', !this.widgets.deleteOnlySelected_RB.attr('checked'));
		dojo.stopEvent(e);
	} // end of method clickOn_onlySelectedObjects
	,
	'clickOn_allObjects' : function (e) {
		this.widgets.deleteAll_RB.attr('checked', !this.widgets.deleteAll_RB.attr('checked'));
		
		dojo.stopEvent(e);
	} // end of method clickOn_onlySelectedObjects
	,
	'_allObjectsCBToggled' : function (e) {
	
		// enable/ disable the ok button
		this.widgets.OkButton.set('disabled', !this.widgets.deleteAll_RB.attr('checked'));
	
	} // end of method _allObjectsCBToggled
	,
	'destroy' : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		
		for (var i in this.widgets) {
			if (this.widgets[i].destroyRecursive) this.widgets[i].destroyRecursive(false);
			delete this.widgets[i];
		} // end for .. in
		
		//this.inherited(arguments);
	} // end of method destroy
	,
});
