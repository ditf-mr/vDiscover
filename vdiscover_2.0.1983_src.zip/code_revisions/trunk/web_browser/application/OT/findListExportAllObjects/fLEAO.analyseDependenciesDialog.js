/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare('application.widgets.OT_findListExportAllObjects.analyseDependenciesDialog',[common.widgets.fixedSizeDialog],{
	'innerWidth'	: 750
	,
	'innerHeight'	: 2000
	,
	'constructor' : function() {
		// Your constructor method will be called before the parameters are mixed into the widget, and can be used to initialize arrays, etc.
		this.inherited(arguments);
		
		// some initialisations
		this.widgets 		= {};
		
	} // end of method constructor
	,
	'postMixInProperties' : function () {
		this.inherited(arguments);
	
		// set the dialog title
		this.title= ''
			+ T('fLEAOanalyse...js/AnalyseDependInOT_TIT','Analyse dependencies in « $[0]» ',[this.OT_name]);
	
	} // end of method postMixInProperties
	,
	'postCreate' : function () {
		// This is typically the workhorse of a custom widget. The widget has 
		// been rendered (but note that sub-widgets in the containerNode have not!). 
		// The widget though may not be attached to the DOM yet so you shouldn't 
		// do any sizing calculations in this method.
		this.inherited(arguments);
			
			// build the main structure of the dialog
		this.widgets.borderContainer = new dijit.layout.BorderContainer({
			'style' 	: 'width:100%;height:100%;',
			'gutters'	: false
		}).placeAt(this.containerNode);
		
		// create the action bar at the bottom of the dialog
		this.widgets.actionBar = new dijit.layout.ContentPane({
			'region'	: 'bottom',
			'class'		: 'dijitDialogPaneActionBar textRight',
			'style'		: 'padding-top:1em;'
		});
		this.widgets.borderContainer.addChild(this.widgets.actionBar);

		this.widgets.CloseButton = new dijit.form.Button({
			'label' 	: '<img width="12" src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/document-close-2.png"/> '
				+T('BTN_Close', 'Close'),
			'type'		: 'button',
			'style'		: 'margin-right:0;'
		}).placeAt(this.widgets.actionBar.containerNode);
		
		this._connects.push(dojo.connect( this.widgets.CloseButton,		'onClick', this.parentWidget, 'analyseDependencies_closeDialog'));
		this._connects.push(dojo.connect( this.widgets.closeButtonNode,	'onClick', this.parentWidget, 'analyseDependencies_closeDialog'));

		// create the main pane of the dialog
		
		this.widgets.mainPane = new dijit.layout.ContentPane({
			'region'	: 'center',	
			'content'	: '<p>' + T('fLEAOanalyse...js/ChooseTheAttribForHorAndVertAxis_TXT','Please choose the attributes for the horizonal and vertial axis and click on « Analyse» .') + '</p>'
		});
		this.widgets.borderContainer.addChild(this.widgets.mainPane);
		
		// create the top pane
		
		this.widgets.topPane = new dijit.layout.ContentPane({
			'region'	: 'top',	
			'content'	: ''
				+'<table class="fullWidth">'
					+'<tbody>'
						+'<tr>'
							+'<th width="33%;">'
								+ T('FUT_SearchQuery','Search query')
							+'</th>'
							+'<td class="placeSearchQueryHere">'
								+''
							+'</td>'
						+'</tr>'
						+'<tr>'
							+'<th>'
								+ T('fLEAOanalyse...js/ChAttrVertAxis_HTM','Choose the attribute for the <i>vertical</i> axis')
							+'</th>'
							+'<td>'
								+'<div class="placeVerticalAxisSelectorHere"></div>'
							+'</td>'
						+'</tr>'
						+'<tr>'
							+'<th>'
								+ T('fLEAOanalyse...js/ChAttrHorAxis_HTM','Choose the attribute for the <i>horizontal</i> axis')
							+'</th>'
							+'<td>'
								+'<div class="placeHorizontalAxisSelectorHere"></div>'
							+'</td>'
						+'</tr>'
						+'<tr>'
							+'<th>'
								+'&nbsp;'
							+'</th>'
							+'<td style="text-align:right;" >'
								+'<div class="placeAnalyseButtonHere"></div>'
							+'</td>'
						+'</tr>'
					+'</tbody>'
				+'</table>'
		});
		this.widgets.borderContainer.addChild(this.widgets.topPane);
		
		this.verticalAxisSelector_domNode	= dojo.query('.placeVerticalAxisSelectorHere', 		this.widgets.topPane.containerNode).shift();
		this.horizontalAxisSelector_domNode	= dojo.query('.placeHorizontalAxisSelectorHere', 	this.widgets.topPane.containerNode).shift();
		this.analyseButton_domNode		= dojo.query('.placeAnalyseButtonHere', 			this.widgets.topPane.containerNode).shift();
		
		this.widgets.verticalAxisSelector = new dijit.form.FilteringSelect({
			'class'				: 'fullWidth',
			// 'style'				: 'width:10em;',
			'store'				: this.parentWidget.attrStore,
			'query'				: {'permittedForDependencyAnalysis' : true},
			// 'autoComplete' 		: true,
			'fetchProperties' 	: {'sort': [{'attribute':"position", 'descending': false}]},
			// 'highlightMatch' 	: "all",
			'ignoreCase'		: true,
			// 'queryExpr'			: '*{0}*',
			'required' 			: true,
		}, this.verticalAxisSelector_domNode );
		
		this.widgets.horizontalAxisSelector = new dijit.form.FilteringSelect({
			'class'				: 'fullWidth',
			// 'style'				: 'width:10em;',
			'store'				: this.parentWidget.attrStore,
			'query'				: {'permittedForDependencyAnalysis' : true},
			// 'autoComplete' 		: true,
			'fetchProperties' 	: {'sort': [{'attribute':"position", 'descending': false}]},
			// 'highlightMatch' 	: "all",
			'ignoreCase'		: true,
			// 'queryExpr'			: '*{0}*',
			'required' 			: true,
		}, this.horizontalAxisSelector_domNode );
		
		this.widgets.analyseButton = new dijit.form.Button({
			'label'				: T('BTN_Analyse','Analyse')
		}, this.analyseButton_domNode);
		
		this.connect(this.widgets.analyseButton, 		'onClick', 'analyse');
		this.connect(this.widgets.verticalAxisSelector, 	'onChange', 'activateOrDeactivateAnalyseButton');
		this.connect(this.widgets.horizontalAxisSelector, 	'onChange', 'activateOrDeactivateAnalyseButton');
		
		// set up the search term widget
		this.searchTermNode = dojo.query('.placeSearchQueryHere', this.widgets.topPane.containerNode).shift();
		
		this.widgets.searchTermBox = new dijit.form.ValidationTextBox({
			'placeHolder'			: T('FUT_Find...','Find...'),
			// 'style'					: '',
			// 'intermediateChanges'	: true,
			'invalidMessage' 		: 'invalidMessage',
			'promptMessage' 		: T('fLEOanalyse...js/PromptMsg_HTM','Type here what you want to find. <br/>You may use <code>*</code> as a wildcard char.<br/>E.g. <code>*123*</code> finds <code>64<i>123</i></code> and <code><i>123</i>45</code>.'),
			'regExp'				: '.*',
			'selectOnClick' 		: true,
			'maxLength'				: 255,
			'value'					: this.parentWidget.parentWidget.getSearchTerm(),
			'class'					: 'fullWidth',
		}).placeAt(this.searchTermNode);

	} // end of method postCreate
	,
	'destroy' : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		
		for (var i in this.widgets) {
			if (this.widgets[i].destroyRecursive) this.widgets[i].destroyRecursive(false);
			delete this.widgets[i];
		} // end for .. in
		
		//this.inherited(arguments);
	} // end of method destroy
	,
	'activateOrDeactivateAnalyseButton' : function () {
	
		var enable = (		this.widgets.verticalAxisSelector	.isValid()
						&&	this.widgets.horizontalAxisSelector	.isValid()
					 ) ? true : false;
						
		this.widgets.analyseButton.attr('disabled', !enable);
	
	} // end of method activateOrDeactivateAnalyseButton
	,
	'startup' : function () {
		this.inherited(arguments);
	
		this.activateOrDeactivateAnalyseButton();
	
	} // end of method startup
	,
	'analyse' : function (e) {
		dojo.stopEvent(e);
	
		// show a loading message
		this.widgets.mainPane.attr('content', ''
			+'<p>' + T('fLEOanalyse...js/LoadingData...','Loading data … please wait …') + '</p>'
			+'<p>&nbsp;</p>'
			+'<img style="display:block;margin-left:auto;margin-right:auto;" src="./third_party_libraries/dojo-release-1.6.1/dojox/widget/Standby/images/loading.gif"/>'
		);
	
		var x_A_UUID	= this.widgets.horizontalAxisSelector.attr('value'),
			y_A_UUID	= this.widgets.verticalAxisSelector.attr('value'),
			x_axisLabel	= this.widgets.horizontalAxisSelector.attr('displayedValue'),
			y_axisLabel	= this.widgets.verticalAxisSelector.attr('displayedValue'),
			x_unit		= '',
			y_unit		= '',
			x_format	= '',
			y_format	= '',
			x_attrName	= '',
			y_attrName	= '';
		
		// build the label for the x axis
		this.parentWidget.attrStore.fetch({
			'query': {'UUID': x_A_UUID},
			'scope': this,
			'onItem': function(item){
				x_attrName 	= x_axisLabel	= this.parentWidget.attrStore.getValue(item,'name');
				x_format 	= this.parentWidget.attrStore.getValue(item,'format');
				var units 	= this.parentWidget.attrStore.getValue(item,'units');
				if (units) {
					x_unit = units;
					x_axisLabel +=' ['+x_unit+']';
				} // end if
			} // end of method onItem
		});
		
		// build the label for the y axis
		this.parentWidget.attrStore.fetch({
			'query': {'UUID': y_A_UUID},
			'scope': this,
			'onItem': function(item){
				y_attrName 	= y_axisLabel	= this.parentWidget.attrStore.getValue(item,'name');
				y_format 	= this.parentWidget.attrStore.getValue(item,'format');
				var units 	= this.parentWidget.attrStore.getValue(item,'units');
				if (units) {
					y_unit = units;
					y_axisLabel +=' ['+y_unit+']';
				} // end if
			} // end of method onItem
		});
		
		// request the chosen attributes from the server
		var query = {
				'v'					: 'JSON_ObjectType',
				"task"			 	: 'get_Os_4_OT_show_all_io_REST', 
				"UUID"		 		: this.OT_UUID,
				'queryParameters' 	: dojo.toJson({
					'searchQuery' 		: this.widgets.searchTermBox.attr('value'),
					'colHeaders' 		: [
							'name', 
							x_A_UUID, 
							y_A_UUID,
						],
					}),
			};
	
		this.response = null;
	
		dojo.xhrPost({
			'url'		: '?',
			'content'	: query,
			'error'		: application.AJAX_errorMessage, // function
			'handleAs'	: 'json',
			'scope'		: this,
			'load'		: function(response,request){ /* onSuccess */
				request.args.scope.response  = response.items;
			}, // end of onSuccess method
			//preventCache:true,
			//failOk	: true,
			'sync'		: true,
			'timeout'	: 	application.configuration.global.AJAX_default_timeout
		});

		// this.response contains now a list of all objects
		// this.widgets.mainPane.attr('content', dojo.create('PRE', {'innerHTML':dojo.toJson(this.response,true)}));
		
		// create the chart
		
		// https://dojotoolkit.org/documentation/tutorials/1.6/charting/
		// http://dojotoolkit.org/reference-guide/1.7/dojox/charting.html
		
		// http://archive.dojotoolkit.org/nightly/dojotoolkit/dojox/charting/tests/theme_preview.html
		dojo.require("dojox.charting.Chart2D");
		// dojo.require("dojox.charting.axis2d.Default");
		// dojo.require("dojox.charting.plot2d.Default");
		dojo.require("dojox.charting.themes.ThreeD");
		dojo.require("dojox.charting.action2d.Tooltip");
		dojo.require("dojox.charting.action2d.Magnify");		
		// prepare the chart series
		var	series 		= [], x_min = null, x_max = null, y_min = null, y_max = null, total_dataSets =0;;
		dojo.forEach(this.response, function (o,index){
			total_dataSets++;
			if (	(x_A_UUID in o) 
				&& 	(y_A_UUID in o)
				
				) {
					o[x_A_UUID] = dojo.fromJson(o[x_A_UUID]);
					o[y_A_UUID] = dojo.fromJson(o[y_A_UUID]);
				
					if (	(o[x_A_UUID][0])
						&&	('value_number' in o[x_A_UUID][0])
						&&	(o[y_A_UUID][0])
						&&	('value_number' in o[y_A_UUID][0])
						) {
				
						var x = o[x_A_UUID][0].value_number,
							y = o[y_A_UUID][0].value_number;
						
						// identify the boundaries
						if ( (x_min===null) || x < x_min) x_min = x;
						if ( (x_max===null) || x > x_max) x_max = x;
						if ( (y_min===null) || y < y_min) y_min = y;
						if ( (y_max===null) || y > y_max) y_max = y;
						
						// add the data points
						series.push({
							'x'			: x,
							'y'			: y,
							'tooltip'	: o['name'],
						});
					} // end if
			} // end if	
		},this);
		
		if (series.length < 2) {
			//TG: Original
			//this.widgets.mainPane.attr('content', '<p>Sorry &mdash; at least <code>2</code> samples are needed, '
			//    +(series.length==0?'none':'<code>'+series.length+'</code>')
			//    +' is available. Aborting.</p>'
			//    );
			//TG: T() Calls
			
			this.widgets.mainPane.attr('content', ''
				+ '<p>'
				+ T('fLEAOanalyse...js/SorryAtLast2Msg_p1_HTM','Sorry &mdash; at least <code>2</code> samples are needed, ')  
				+ ((series.length==0)? T('FUT_none','none') : '<code>'+series.length+'</code>' )
				+ T('fLEAOanalyse...js/SorryAtLast2Msg_p2_TXT',' is available. Aborting.')
				+ '</p>'
			     );
			
			return;
		} //
		
		// console.log('series', series);
		// console.log('x_min', x_min);
		// console.log('x_max', x_max);
		// console.log('y_min', y_min);
		// console.log('y_max', y_max);
		
		var x_span = x_max - x_min,
			y_span = y_max - y_min;
			
		var minChartToSpanWidth = 110/100,
			
			x_chartMin = x_min - x_span * (minChartToSpanWidth-1),
			x_chartMax = x_max + x_span * (minChartToSpanWidth-1);		
			
			y_chartMin = y_min - y_span * (minChartToSpanWidth-1),
			y_chartMax = y_max + y_span * (minChartToSpanWidth-1);		
			
		// calculate the correlation coefficient
		var n=series.length;
	
		var sum_x = 0,
			sum_y = 0;
		
		// build the sums of x and y
		dojo.forEach(series, function (e) {
			sum_x += e.x;
			sum_y += e.y;
		}, this);
	
		// calculate the means
		var mean_x = sum_x/n,
			mean_y = sum_y/n;
			
		// build the deviation sums of x and y
		var dev2Sum_x 		= 0,
			dev2Sum_y 		= 0,
			devX_x_devY_sum = 0;
	
		dojo.forEach(series, function (e) {
			var dev_x = e.x - mean_x,
				dev_y = e.y - mean_y;
				
			dev2Sum_x 		+= dev_x*dev_x;
			dev2Sum_y 		+= dev_y*dev_y;
			devX_x_devY_sum	+= dev_x*dev_y;
		}, this);
	
		// calculate the correlation coefficient
		var corrCoeff  = devX_x_devY_sum / Math.sqrt(dev2Sum_x*dev2Sum_y),
			R2			= devX_x_devY_sum * devX_x_devY_sum / dev2Sum_x / dev2Sum_y;
		
		// linear regression: calculate a and b in y=a*x+b
		var b = devX_x_devY_sum / dev2Sum_x,
			a = mean_y - b * mean_x;

		var regressionSeries = [];
		dojo.forEach(series, function (e) {
			regressionSeries.push({
				'x'			: e.x,
				'y'			: b*e.x + a,
				'tooltip'	: T('fLEAOanalyse...js/LinearRegrOf_TXT','Linear regression of ') + e.tooltip,
			});
		}, this);
					
		// create the chart node
		var date = dojo.date.locale.format(new Date()),
			output = new common.widgets.printableContent({
				'header' : '<h1>' + T('fLEAOanalyse...js/DependAnalReport_TXT','Dependency Analysis Report') + '</h1>',
				'footer' : '<p class="textCenter small">'+date+'</p>',
			});
		this.widgets.mainPane.attr('content', output);
			
		var outputNode		= dojo.create('DIV', {
				// 'class'	: 'output_DIN_A4',
				'innerHTML'	: ''
					+'<p class="textRight">'+date+'</p>'
					+'<h2>' + T('fLEAOanalyse...js/DependAnalReport_TXT','Dependency Analysis Report') + '</h2>'
					+'<p>' + T('fLEAOanalyse...js/SearchQuery_TXT','Search query:') +' <code>'+this.widgets.searchTermBox.attr('value')+'</code></p>'
					+'<p>' + T('fLEAOanalyse...js/NumberOfSamples_TXT','Number of samples: <code>$[0]</code> (of <code>$[1]</code> retrieved objects).', [n, total_dataSets]) +'</p>'
					+'<table class="fullWidth listWithRows">'
						+'<thead>'
							+'<tr>'
								+'<th class="textCenter">'
									+ T('FUT_Axis','Axis')
								+'</th>'
								+'<th>'
									+ T('FUT_Attribute','Attribute')
								+'</th>'
								+'<th class="textRight">'
									+ T('FUT_min','min')
								+'</th>'
								+'<th class="textRight">'
									+ T('FUT_mean','mean')
								+'</th>'
								+'<t class="textRight"h>'
									+ T('FUT_max','max')
								+'</th>'
								+'<th>'
									+ T('FUT_Unit','Unit')
								+'</th>'
							+'</tr>'
						+'</thead>'
						+'<tbody>'
							+'<tr>'
								+'<th class="textCenter">'
									+'x'
								+'</th>'
								+'<td>'
									+x_attrName
								+'</td>'
								+'<td class="textRight">'
									+'<code>'+dojo.number.format(x_min, {'pattern': x_format})+'</code>'
								+'</td>'
								+'<td class="textRight">'
									+'<code>'+dojo.number.format(mean_x, {'pattern': x_format})+'</code>'
								+'</td>'
								+'<td class="textRight">'
									+'<code>'+dojo.number.format(x_max, {'pattern': y_format})+'</code>'
								+'</td>'
								+'<td>'
									+x_unit
								+'</td>'
							+'</tr>'
							+'<tr>'
								+'<th class="textCenter">'
									+'y'
								+'</th>'
								+'<td>'
									+y_attrName
								+'</td>'
								+'<td class="textRight">'
									+'<code>'+dojo.number.format(y_min, {'pattern': x_format})+'</code>'
								+'</td>'
								+'<td class="textRight">'
									+'<code>'+dojo.number.format(mean_y, {'pattern': x_format})+'</code>'
								+'</td>'
								+'<td class="textRight">'
									+'<code>'+dojo.number.format(y_max, {'pattern': y_format})+'</code>'
								+'</td>'
								+'<td>'
									+y_unit
								+'</td>'
							+'</tr>'
						+'</tbody>'
					+'</table>'
			}/*, this.widgets.mainPane.containerNode, 'only'*/);
		
		// this.widgets.mainPane.attr('content', outputNode);
		output.add(outputNode);
		
		var chartWidth 		= Math.round(outputNode.clientWidth*.75),
			chartHeight 	= chartWidth;
		
		var chartNodeOuter	= dojo.create('DIV', {
									'style' : 'text-align: center;',
							}, outputNode);
			chartNode 		= dojo.create('DIV', {
									'style'	: 'width:'+chartWidth+'px;height:'+chartHeight+'px;display:block;margin-left:auto;margin-right:auto;'
								}, chartNodeOuter);
		
		var chart = new dojox.charting.Chart2D(chartNode);
		// Set the theme
		chart.setTheme(dojox.charting.themes.ThreeD);
		 
		chart.addPlot("default",	{'type': "Scatter"});
		if (Math.abs(corrCoeff)>.3) chart.addPlot("Regression",	{'type': "Lines"});
		chart.addAxis("x", 			{
			//'includeZero'	: true,
			'min'			: x_chartMin,
			'max'			: x_chartMax,
			'fixLower'		: "major",
			'fixUpper'		: "major",
			
			'font'			: '11pt bold',
			
			'title'			: x_axisLabel,
			'titleOrientation': 'away',	// || 'axis'
			
			'majorLabels'	: true,
			'minorTicks'	: true,
			'minorLabels'	: false,
			'microTicks'	: false,
		});
		chart.addAxis("y", { 'vertical': true, 
			//'includeZero'	: true,
			'min'			: y_chartMin,
			'max'			: y_chartMax,
			'fixLower'		: "major", 
			'fixUpper'		: "major", 
			
			'font'			: '11pt bold',
			
			'title'			: y_axisLabel,
			'titleOrientation': 'axis',	// || 'away'
			
			'majorLabels'	: true,
			'minorTicks'	: true,
			'minorLabels'	: false,
			'microTicks'	: false,
		});
		chart.addPlot("grid", 		{'type': "Grid",
			'hAxis': "x",
			'vAxis': "y",
			'hMajorLines': true,
			'hMinorLines': false,
			'vMajorLines': true,
			'vMinorLines': false
		});
		chart.addSeries( "data", series, {
			'plot'			: 'default',
			// 'stroke'		: {
				// 'color'	:	"blue",
				// 'width'	:	0,
			// }, 
			'marker'		: /*"m0, -3 l0, 6 m-3, -3 l6, 0" */ "m0,-3 l3,3 -3,3 -3,-3 z"
		});
		
		if (Math.abs(corrCoeff)>.3) chart.addSeries( "regressionData", regressionSeries, {
			'plot'			: 'Regression',
			// 'stroke'		: {
				// 'color'	:	'red',
				// 'width'	:	3,
			// }, 
			'marker'		: /*"m0, -3 l0, 6 m-3, -3 l6, 0" */ "m0,-3 l3,3 -3,3 -3,-3 z"
		});
		
		// Create the tooltip
		var tip = new dojox.charting.action2d.Tooltip(chart,"default");

		// Create the magnifier
		var mag = new dojox.charting.action2d.Magnify(chart,"default");
	
		// Render the chart!		
		chart.render();		
	
		dojo.create('DIV', {
			'innerHTML'	: ''
				+'<p>' + T('fLEAOanalyse...js/PearsonPMCorr_TXT','Pearson product-moment correlation coefficient:') + '<br/>'
				+'<code>r = '+dojo.number.format(corrCoeff,{
						'fractional'	: true,
						'places'		: 3,
					})+'</code></p>'
				+( (Math.abs(corrCoeff)>.3) 
					? ''
						+'<p>' + T('fLEAOanalyse...js/EstimatedRegrLines_HTM','Estimated regression line <code>y = b*x+a</code> with') + '<br/>'
							+'<code>b = '+dojo.number.format(b,{
								'fractional'	: true,
								'places'		: 3,
							})+'</code><br/>'
							+'<code>a = '+dojo.number.format(a,{
								'fractional'	: true,
								'places'		: 3,
							})+'</code>'
						+'</p>'
						+'<p><code>R² = '+dojo.number.format(R2,{
								'fractional'	: true,
								'places'		: 3,
							})+'</code></p>'
					: ''
				)
		}, outputNode);		
	
	} // end of method analyse
	,
});
