dojo.addOnLoad(function(){
	with (application.OT_menubar_itemKinds) { // here comes now the definition of the standard OT_menubar_itemKinds
		register (
			{	
				//TG: QUESTION: T() Funktion?
				name			: T('createObject.js/NewObj_MNU','New Object'),
				UUID			: "OT_menubar_itemKinds.general.newObject",
				addWhenCreating	: true,
				JS_command		: function ( OT_UUID, tabContainer, createTempObject, onSuccess ) {
					if ( typeof onSuccess != "undefined") {
						this.customOnSuccess = onSuccess;
					} else {
						this.customOnSuccess = false;
					}
					if ( typeof createTempObject != "undefined") {
						this.createTempObject = true;
					} else {
						this.createTempObject = false;
					}
					/*application.OT.new_O*/
					application.OT_menubar_itemKinds.itemKinds_asSlots['OT_menubar_itemKinds.general.newObject'].start(OT_UUID, tabContainer);
					
				}
				,
				description:"<p>" + T('createObject.js/CreateNewObjDialog_TXT','This command calls the start dialog for creating a new object.') + "</p>",
			
				// the following methods are specific ones ---------------------------------------------
				start : function ( OT_UUID, tabContainer ) {
					// check if object type has defined a template_name for objects
					var buttonScope = this;
					application.OT_AJAX_query( {
							task: 'usesTemplateViewForObjectName',
							UUID: OT_UUID
						},
						function(r,a){
							if (! r) {
								// show edit dialogue
								dojo.byId('application.OT.Dialogues.createObject.OT_UUID').value = OT_UUID;
								dojo.byId('application.OT.Dialogues.createObject.newName').value = '';
								dijit.byId('application.OT.Dialogues.createObject').show();
							} else {
								// no need to show edit dialogue
								application.OT_AJAX_query({
										"task"	: "add_O",
										"UUID"	: OT_UUID,
										"name"	: "",
										"temporary" : buttonScope.createTempObject,
										"scope"	: buttonScope
									},
									application.OT_menubar_itemKinds.itemKinds_asSlots['OT_menubar_itemKinds.general.newObject'].onSuccess,
									true /*means sync*/
								);
							}
						},
						true /*means sync*/
					); // end-of OT_AJAX_query
				} // end-of-method start
				,
				execute : function () {
					dijit.byId('application.OT.Dialogues.createObject').hide();
					var OT_UUID = dojo.byId('application.OT.Dialogues.createObject.OT_UUID').value;
					var newName = dojo.byId('application.OT.Dialogues.createObject.newName').value;
					application.OT_AJAX_query({	
							"task"	: "add_O",
							"UUID"	: OT_UUID,
							"name"	: newName,
							"temporary" : this.createTempObject,
							"scope"	: this
						},
						application.OT_menubar_itemKinds.itemKinds_asSlots['OT_menubar_itemKinds.general.newObject'].onSuccess,
						true /*means sync*/
					);
				} // end-of-method execute
				,
				onSuccess : function (r, a) {
					dijit.byId('application.OT.Dialogues.createObject').hide();
					// display new Object
					if ( this.content.scope.customOnSuccess ) {
						eval(this.content.scope.customOnSuccess);
					} else {
						application.O.show(r.UUID);						
					}
				} // end-of-method onSuccess
			}
		); // end-of-register
	} // end-of-with
}); // end dojo.addOnLoad