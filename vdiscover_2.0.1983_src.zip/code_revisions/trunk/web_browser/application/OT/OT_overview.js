/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare('application.widgets.OT_overview',[dijit.layout.BorderContainer],{	
	'title' 	: 	'All', // will be overwritten in postMixInProperties
	'closable'	:	true,
	'gutters'	:	true,
	'defaultDescription':	T('OT_overview.js/DefaultDescr_HTM','<h2>This type has no description, yet.</h2><p>You can edit this description in the admin menu.</p>'),
	'name'		:	null, // string -- will be set in postMixInProperties
	'description'	:	null, // string -- will be set in postMixInProperties
	'hasChildren'	:	null, // boolean -- will be set in postMixInProperties
	/*constructor : function() {
		// Your constructor method will be called before the parameters are mixed into the widget, and can be used to initialize arrays, etc.
		this.inherited(arguments);
	} // end of method constructor
	,*/
	'postMixInProperties' : function() {
		// If you provide a postMixInProperties method for your widget, 
		// it will be invoked before rendering occurs, and before 
		// any dom nodes are created. If you need to add or change the 
		// instance's properties before the widget is rendered 
		// - this is the place to do it.
		this.inherited(arguments);
		
		// get the object type's name and description
		this.name			= 'unknown';
		this.hasChildren	= false;
		
	} // end of method postMixInProperties
	,
	/*buildRendering : function() {
		// dijit._Templated provides an implementation of buildRendering 
		// that most times will do what you need. The template is fetched/read, 
		// nodes created and events hooked up during buildRendering. The end 
		// result is assigned to this.domNode. If you don't mixin dijit._Templated 
		// (and most OOTB dijits do) and want to handle rendering yourself 
		// (e.g. to really streamline a simple widget, or even use a different 
		// templating system) this is where you'd do it.
		this.inherited(arguments);
	} // end of method buildRendering
	,*/
	postCreate : function() {
		// This is typically the workhorse of a custom widget. The widget has 
		// been rendered (but note that sub-widgets in the containerNode have not!). 
		// The widget though may not be attached to the DOM yet so you shouldn't 
		// do any sizing calculations in this method.
		this.inherited(arguments);
		
		application.OT.navigationStore.fetch({
			// take care - fetching something from a store is asynchronous !
			'query'	: {'UUID':this.OT_UUID},
			'scope'	: this,
			'onItem': function(item){
				if(!application.OT.navigationStore.isItemLoaded(item)) application.OT.navigationStore.loadItem(item);
				this.name			= application.OT.navigationStore.getValue(item,'name');
				this.description	= application.OT.navigationStore.getValue(item,'description');
				this.hasChildren 	= (	(		application.OT.navigationStore.hasAttribute(item,'children') 
											&& 	application.OT.navigationStore.getValue(item,'children')
										) ? true : false);										
			} // end of method onItem
			,
			'onComplete': function() {
				if(!this.description) this.description=this.defaultDescription;
				this.attr('title', this.name+' &mdash; ' + T('FUT_Overview','Overview') );
				
				// add a content pane for the overview text
				this.overviewPane = new dijit.layout.ContentPane({
					'content'	: ''
						+'<div class="output_DIN_A4" '
							// the following line aligns the titles of the navigation tree pane and this pane, vertically
							+(this.hasChildren?'style="padding-top:0;margin-top:0;" ':'')
						+'>'
							+this.description
						+'</div>'
					,
					'region'	: 'center'
				});
				this.addChild(this.overviewPane);
				
				// add a dijit tree for displaying and selecting child nodes
				if(this.hasChildren) this.addSubTypeTree();
			} // end of method onComplete
		});
		
	} // end of method postCreate
	,
	'addSubTypeTree' : function () {
	
		// add a content pane for the sub type tree
		this.subTypeBorderContainer = new dijit.layout.BorderContainer({
			'region'		: 'left',
			'style'			: 'width:60ex;',
			'splitter'		: true,
			'gutters'		: false,
			'class'			: 'dijitContentPane dijitBorderContainer-child dijitBorderContainer-dijitContentPane dijitBorderContainerPane'
			// 'content'		: ''
								// +'<h2>Sub types</h2>'
		});
		this.addChild(this.subTypeBorderContainer);
		
		this.subTypeTitleContainer = new dijit.layout.ContentPane({
			'region'	: 'top',
			'content'	: '<h2>' + T('OT_overview.js/SubTypes_TIT','Sub types') + '</h2><p>&nbsp;</p>'
		});
		this.subTypeBorderContainer.addChild(this.subTypeTitleContainer);
		
		this.subTypeTreeContainer = new dijit.layout.ContentPane({
			'region'	: 'center'
		});
		this.subTypeBorderContainer.addChild(this.subTypeTreeContainer);
	
		this.subTypeModel = new dijit.tree.ForestStoreModel({
			'store'			: application.OT.navigationStore,
			'query'			: {'UUID': this.OT_UUID},
			'childrenAttrs' : ['children']
		});
		
		this.tree_DOMNode = dojo.create('DIV',{},this.subTypeTreeContainer.containerNode);
		
		this.subTypeTree = new dijit.Tree ({
			'model'			: this.subTypeModel,
			'openOnClick'	: false,
			'showRoot'		: false,
			'persist'		: true,
			'scope'			: this,
			'onClick': function(item, node) {
				with (application.OT.navigationStore) {
						application.OT.currentObjectType = item;
						if(item && (getValue(item, 'type')=='OT')) {
							application.OT.show(getValue(item, 'UUID')/*,getValue(item, 'name'),dojo.fromJson(getValue(item, 'menuBarOT'))*/);
						}// end if
				} // end with
			},
			'getIconClass' : function(item, isOpened) {
					// get item type
					var type='', has_children=false;
					try{ 
						type=(application.OT.navigationStore.hasAttribute(item,'type')?application.OT.navigationStore.getValue(item,'type'):'');
					} catch(e){}
					if(type=='OT') try{ 
						has_children=(application.OT.navigationStore.hasAttribute(item,'children') && application.OT.navigationStore.getValue(item,'children'));
					} catch(e){}
					var iconClass='';
					switch(type){
						case 'navigation_node':
							iconClass='RS_icon_navigation_node';
							break;
						// case 'RT':
							// iconClass='RS_icon_RT';
							// break;
						case 'OT':
							iconClass=(has_children?'RS_icon_OT_with_children':'RS_icon_OT');//((isOpened)?'dijitFolderOpened':'dijitFolderClosed');
							break;
						default:
							iconClass='';
					} // end switch
					
					return iconClass;
				},
			'getTooltip' : function(item){return((application.OT.navigationStore.getValue(item,'type')=='OT')? T('OT_overview.js/ShowTypeTab_TTP','click to show the type tab.') :'' );}
			}, 
			this.tree_DOMNode
		);
		
	} // end of method addSubTypeTree
	/*,
	startup : function() {
		// If you need to be sure parsing and creation of any child widgets has 
		// completed, use startup. This is often used for layout widgets like 
		// BorderContainer. If the widget does JS sizing, then startup() should 
		// call resize(), which does the sizing.
		this.inherited(arguments);
				
	} // end of method startup
	*/
	/*,
    resize : function() {
		// All widgets that do JS sizing should have a method called resize(), that lays 
		// out the widget. Resize() should be called from startup() and will also be 
		// called by parent widgets like dijit.layout.ContentPane.
	}
	*/
	/*,
	destroy : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you.
		
		this.inherited(arguments);
	} // end of method destroy
	*/
}); // end of declaration of application.widgets.OT_allObjectsList

// register the corresponding menu bar option
dojo.addOnLoad(function(){
	application.OT_menubar_itemKinds.register({name: T('FUT_Overview','Overview'),
		'UUID'			:	"OT_menubar_itemKinds.general.overview",
		'addWhenCreating': 	true,
		'openByDefault'	: 	true,
		'description'	:	""
					+"<p>" + T('OT_overview.js/OverviewDescrP1_TXT','This command opens the tab with the overview information for all information objects of the type.') + "</p>"
					+"<p>" + T('OT_overview.js/OverviewDescrP2_TXT','The overview tab can be edited by the administrator and might contain instructions and other type-specific useful information.') + "</p>"
		,
		'JS_command'	:	function (UUID, tabContainer) {
			
			var t_C = dijit.byId(tabContainer),
				t_id = 'OT_overview_revamped_'+UUID,
				t_Widget = dijit.byId(t_id);
				
			if(!t_Widget) {
				t_Widget= new application.widgets.OT_overview({
					'id'		: 	t_id,
					'OT_UUID'	:	UUID
				});
				t_C.addChild(t_Widget);
			} // end if
			
			t_C.selectChild(t_Widget,true/*means: animated*/);
		
		} // end-of-method showAllInfObjs
	});
}); // end dojo.addOnLoad