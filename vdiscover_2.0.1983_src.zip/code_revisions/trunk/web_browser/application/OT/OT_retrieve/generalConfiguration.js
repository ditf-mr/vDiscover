/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// dojo.require('application.widgets.genericAttribute');

dojo.declare(
	'application.widgets.retrieveAttributes.generalConfiguration',
	[application.widgets.retrieveAttributes.genericAttribute],
	{
		'initialiseProperties': function () {
			if (!this.searchType) {
				this.searchType = 'must';
			}			
			if (!this.canPoints) {
				this.canPoints = 1;
			}
		}, // end-of-function initializeProperties
	
		'values_changed': function(e) {
			if (this.radioButton_searchType_can.get('checked')) {
				this.searchType = 'can';
				this.canPoints_nTB.set('disabled', false);
				// this.propertyHasChanged('canPoints', this.canPoints_nTB.get('value'));
			}
			if (this.radioButton_searchType_must.get('checked')) {
				this.searchType = 'must';
				this.canPoints_nTB.set('disabled', true);
			}
			// this.propertyHasChanged('searchType', this.searchType);
			application.OT.retrieve.changeRetrievalAttribute(
				this.UUID,
				{
					'searchType':	this.searchType,
					'canPoints':	this.canPoints_nTB.get('value')
				}
			);
		}, // end-of-method values_changed
		
		'b_delete_criterium': function(e) {
			this.deleteCriterium();
		}, // end-of-method b_delete_criterium	
		
		'postMixInProperties': function() {
			// If you provide a postMixInProperties method for your widget, 
			// it will be invoked before rendering occurs, and before 
			// any dom nodes are created. If you need to add or change the 
			// instance's properties before the widget is rendered 
			// - this is the place to do it.
			this.inherited(arguments);
			this.locateProperties([
				'searchType','name', 'canPoints'
			]);
			this.initialiseProperties();
			this.title = T('generalConf.js/GeneralRetrOpt_TIT','General retrieval options');
			// expand the template string
			//TG: QUESTION: Tooltips dont work. It displays "General retrieval options" at all.
			this.addTemplateSection(''
				+'<tr>'
					+'<td class="textLeft">'
							+'<input type="radio" dojoType="dijit.form.RadioButton" '
								+' name="application.widgets.retrieveAttributes.generalConfiguration.searchType" '
								+' dojoAttachEvent="onChange:values_changed" '
								+' value="must"'
								+' title="'+ T('generalConf.js/ClickToConfMust_TTP','Click here to configure this option as must criterum. All must criteria have to be met by the objects.') + '"'
								+' dojoAttachPoint="radioButton_searchType_must"'
							+'/>' 
							+' ' 
							+ T('generalConf.js/Must_RAD','Must')
							+'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'
							+'<input type="radio" dojoType="dijit.form.RadioButton" '
								+' name="application.widgets.retrieveAttributes.generalConfiguration.searchType" '
								+' dojoAttachEvent="onChange:values_changed" '
								+' value="can"'
								+' title="' + T('generalConf.js/ClickToConfCan_TTP','Click here to configure this option as can criterum. The can criteria improve the quality of the retrieval results.') + '"'
								+' dojoAttachPoint="radioButton_searchType_can"'
							+'/>' 
							+' ' 
							+ T('generalConf.js/CanWith_RAD','Can with')
							+' ' 
							+'<input type="text"  dojoType="dijit.form.NumberSpinner"'
								+' style="width: 3em;"'
								+' value="${canPoints}"' 
								+' dojoAttachEvent="onChange:values_changed"'
								+' dojoAttachPoint="canPoints_nTB"'
								+' required="true"'
								+' disabled="disabled"'
								+' intermediateChanges=true'
							+'/>' 
							+' ' 
							+ T('generalConf.js/points_RAD','point(s)')
					+'</td>'
					+'<td class="textRight">'
						+'<button dojoType="dijit.form.Button" '
							+'dojoAttachEvent="onClick:b_delete_criterium" '
							+'dojoAttachPoint="button_delete_criterium">' + T('BTN_DeleteCriterium','Delete criterium') + '</button>'
					+'</td>'
				+'</tr>'
			);
			// generate the template string
			this.generateTemplateString();
		}, // end-of-function postMixInProperties
		
		'postCreate': function() {
			// This is typically the workhorse of a custom widget. The widget has 
			// been rendered (but note that sub-widgets in the containerNode have not!). 
			// The widget though may not be attached to the DOM yet so you shouldn't 
			// do any sizing calculations in this method.
			this.inherited(arguments);
			switch (this.searchType) {
				case 'can': {
					this.radioButton_searchType_can.attr('checked', true);
					this.canPoints_nTB.set('disabled', false);
					break;
				}
				case "must": {
					this.radioButton_searchType_must.attr('checked', true);
					this.canPoints_nTB.set('disabled', true);
					break;
				}
			} // end-of-switch
		}, // end-of-function postCreate
	
});