/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare(
	'application.widgets.RetrievalQueryWidget', 
	[dijit.layout.BorderContainer], 
	{
		// special attributes
		_OT_tabContainer_id 			: 'not yet set',
		_OT_tab_id 						: 'not yet set',
		_OT_retrieve_tab_id 			: 'not yet set',
		_OT_retrieve_tabContainer_id 	: 'not yet set',

		optionList : {},
		optionContainerWidget : null,

		attributeListGrid : null, // dojox.grid.DataGrid for searchable attributes
		attributeStore: null,  // itemFileWriteStore
		resultStore: null,  // itemFileWriteStore
		markedObjectsStore: null,  // itemFileWriteStore
		
		closable: true,
		widgetsInTemplate: true,
		
		
		'constructor' : function() {
			this.inherited(arguments);
			// some initialisations
			this.widgets 		= {};
		}, // end-of-method constructor
		
		
		'postMixInProperties': function () {
			// If you provide a postMixInProperties method for your widget, 
			// it will be invoked before rendering occurs, and before any dom 
			// nodes are created. If you need to add or change the instance's 
			// properties before the widget is rendered - this is the place to do it.
			this.inherited(arguments);
			// test if everything necessary is available
			if(! this.OT_UUID ) throw ('Cannot initialise application.widgets.ObjectWidget without OT_UUID. Aborting.');
			// set some attributes
			this._OT_tab_id				= application.OT.OT_tab_prepend+this.OT_UUID;
			this._OT_tabContainer_id	= application.OT.OT_tabContainer_prepend+this.OT_UUID;
			this._OT_retrieve_tab_id	= application.OT.retrieve.rQ_tab_prepend+this.OT_UUID;
			this._OT_retrieve_tabContainer_id = application.OT.retrieve.rQ_tC_prepend+this.OT_UUID;
			this.id = this._OT_retrieve_tab_id;
			this.title = T('OT_retrieve.js/RetrQuery_TAB','Retrieval Query');
			{ // get list of available attributes 
				this.attributeStore = new dojo.data.ItemFileWriteStore({
					url: "?v=JSON_ObjectType&task=get_OT_attributes&OT_UUID="+this.OT_UUID,
					clearOnClose: true
				});			
			}
			{ // build empty ItemFileWriteStore for marked results
				this.markedObjectsStore = new dojo.data.ItemFileWriteStore({
					'data' : {
						'identifier': 'UUID',
						'label': 'UUID', 
						'items': []
					},
					'clearOnClose': true,
					'urlPreventCache': true
				});			
			}
		}, // end-of-function postMixInProperties
		
		
		'postCreate': function () {
			// This is typically the workhorse of a custom widget. The widget has been rendered 
			// (but note that sub-widgets in the containerNode have not!). 
			// The widget though may not be attached to the DOM yet so you shouldn't do any sizing calculations in this method.
			this.inherited(arguments);
			// create the top pane for the name and menu bar, create the views container
			this._createOptionWidget();
			// create the bottom pane for the view tabs
			this._createOptions();
		}, // end-of-method postCreate
		
		
		'_createOptionWidget': function () {
			// add the tab container for the options
			this.widgets.optionContainerWidget = new dijit.layout.TabContainer({
				region: 'center',
				id: this._OT_retrieve_tabContainer_id,
				tabPosition: "top"
			});
			this.addChild(this.widgets.optionContainerWidget);
		}, // end-of-method _createObjectWidget
		
		
		'_createOptions': function() {
			var rqWidget = this;
			{// tab Query
				this.widgets.queryTab_widget = new dijit.layout.BorderContainer({
					id: this._OT_retrieve_tab_id + '_Query',
					title: T('FUT_Query','Query'),
					widgetsInTemplate : true,
					OT_UUID: this.OT_UUID,
					style: 'padding: 0px',
					onShow: function(){
							application.OT.retrieve.queryConfigDialog(this,rqWidget);
						}
				});
				this.widgets.optionContainerWidget.addChild(this.widgets.queryTab_widget);
			}
			{ // tab Results
				this.widgets.queryResults_widget = new dijit.layout.ContentPane({
					id: this._OT_retrieve_tab_id + '_Results',
					title: T('FUT_Results','Results'),
					widgetsInTemplate : true,
					OT_UUID: this.OT_UUID,
					style: 'padding: 0px',
					onShow: function(){
							application.OT.retrieve.showQueryResults(this,rqWidget);
						}
				});
				this.widgets.optionContainerWidget.addChild(this.widgets.queryResults_widget);	
			}
			{ // tab Compare
				this.widgets.compareResults_widget = new dijit.layout.ContentPane({
					id: this._OT_retrieve_tab_id + '_Compare',
					title: T('TAB_CompRes','Compare results'),
					style: 'padding: 0px',
					widgetsInTemplate : true,
					OT_UUID: this.OT_UUID,
					onShow: function(){
							application.OT.retrieve.showComparison(this,rqWidget);
						}
				});
				this.widgets.optionContainerWidget.addChild(this.widgets.compareResults_widget);
			}
			{ // tab Actions
				this.widgets.actionsTab_widget = new dijit.layout.ContentPane({
					id: this._OT_retrieve_tab_id + '_Actions',
					title: T('FUT_Actions','Actions'),
					style: 'padding: 0px',
					widgetsInTemplate : true,

				});
				this.widgets.optionContainerWidget.addChild(this.widgets.actionsTab_widget);
			}
		}, // end-of-method _createOptions
		
		
		'destroy': function () {
			// Implement destroy if you have special tear-down work to do 
			// (the superclasses will take care of most of it for you).
			for (var i in this.widgets) {
				this.widgets[i].destroyRecursive();
				delete this.widgets[i];
			} // end for .. in
			
			this.inherited(arguments);
		}, // end-of-method destroy
		
		
		'_end_': null
		
	}
); // end-of-declaration


dojo.require("dojox.grid.cells._base");


application.OT.retrieve = {
	
	'rQ_tab_prepend': 'OT_rq_',
	'rQ_tC_prepend': 'OT_rq_tC_',
	
	'current_OT_UUID': null,
	
	'registeredWidgets': new dijit.WidgetSet(), /* collects the created widgets for deleting after use*/

	'grid_headerStructure': [
		{
			field: 'name',
			name: T('FUT_Name','Name'),
			width: '6em',
		},
		{
			field: 'parsedQuery',
			name: T('FUT_Query','Query'),
			width: 'auto',
		},
		{
			field: 'searchTypeDisplay',
			name: T('FUT_Type','Type'),
			width: '4em',
		}
	], // end-of grid_headerStructure
		
		
	'show': function(OT_UUID,tabContainer) {
		application.OT.retrieve.current_OT_UUID = OT_UUID;
		if (!OT_UUID || !dojo.isString(OT_UUID)) {
			application.showErrorMessage(
				"<p>Called application.OT.retrieve.show() without passing an ObjectType UUID.</p>"+
				"<p>Received Object Type UUID: « <code>"+dojo.toJson(OT_UUID)+"</code>» </p>"+
				"<p>Aborting.</p>"
			);
			return;
		} // end-of-if
		var rqW = dijit.byId(this.rQ_tab_prepend+OT_UUID);
		if (!rqW) {
			rqW = new application.widgets.RetrievalQueryWidget({'OT_UUID':OT_UUID});
			rqW.OT_UUID = OT_UUID;
			dijit.byId(tabContainer).addChild(rqW);
		} 
		// focus this tab
		dijit.byId(tabContainer).selectChild(rqW);
	}, // end-of-method show
	
	
	'queryConfigDialog': function(queryContentWidget, rqWidget) { 
		// build dialog for query
		dojo.require("dojox.grid.cells._base");
		{ // container attribute list 
			if (!queryContentWidget.attributeListContainer) {
				queryContentWidget.attributeListContainer = new dijit.layout.BorderContainer ({
					region: 'left',
					gutters: true,
					style: 'width: 20em;',
					// id: queryContentWidget.id+'_BCleft'
				})
				queryContentWidget.addChild(queryContentWidget.attributeListContainer);			
				queryContentWidget.attributeListGrid = new dojox.grid.DataGrid ({
					store : rqWidget.attributeStore,
					query : { UUID: '*' },
					clientSort : true,
					style :"width: 100%; height: 100%;",
					structure: this.grid_headerStructure,
					onRowDblClick: function (evt) {
						var items = this.selection.getSelected();
						var grid = this;
						dojo.forEach(items, function(i){
							application.OT.retrieve.editAttributeForQuery(grid, i);
						});
					}
				});	
				var attributeListContentPane = new dijit.layout.ContentPane ({			
					region: 'center',
					content: queryContentWidget.attributeListGrid,
				})
				queryContentWidget.attributeListContainer.addChild(attributeListContentPane);
			} else {
				queryContentWidget.attributeListGrid.selection.clear();
				application.OT.retrieve.editAttributeForQuery();
			}
		}
		{ // container query edit area
			if (!queryContentWidget.queryWorkspace) {
				queryContentWidget.queryWorkspace = new dijit.layout.BorderContainer ({
					region: 'center',
					gutters: true,
					// id: queryContentWidget.id+'_queryEditArea_outer'
				})
				queryContentWidget.addChild( queryContentWidget.queryWorkspace );
				queryContentWidget.queryEditArea = new dijit.layout.ContentPane ({
					region: 'center',
					// id: queryContentWidget.id+'_queryEditArea'
				})
				queryContentWidget.queryWorkspace.addChild(queryContentWidget.queryEditArea);
				this.resetQueryEditArea(rqWidget);
			}
		}
		{ // container buttons
			if (!queryContentWidget.buttonRow){
				queryContentWidget.buttonRow = new dijit.layout.ContentPane ({
					'style':  'padding-top:0.5em;',
					'region': 'bottom',
					'class':  'dijitDialogPaneActionBar textRight'
				})
				{ // button load query
					queryContentWidget.addChild( queryContentWidget.buttonRow );
					var loadButton = new dijit.form.Button ({
						type: 'button',
						onClick: function (){ 
							application.OT.retrieve.loadQuery.showDialogue(rqWidget);
						},
						label: T('BTN_LoadQuery','Load Query')
					});
					queryContentWidget.buttonRow.domNode.appendChild(loadButton.domNode);
				}
				{ // button save query
					var saveButton = new dijit.form.Button ({
						type: 'button',
						onClick: function (){ 
							application.OT.retrieve.saveQuery.showDialogue(rqWidget);
						},
						label: T('BTN_SaveQuery','Save Query')
					});
					queryContentWidget.buttonRow.domNode.appendChild(saveButton.domNode);
				}
				{ // button retrieve 
					var retrieveButton = new dijit.form.Button({
						type: 'button',
						onClick: function (){ 
							application.OT.retrieve.showResultTab(rqWidget);
						},
						label: T('BTN_Retrieve','Retrieve')
					});
					queryContentWidget.buttonRow.domNode.appendChild(retrieveButton.domNode);
				}
			}
		}
	}, // end-of-function queryConfigDialog
	
	'resetQueryEditArea': function (rqWidget) {
		// empty the queryEditArea
		rqWidget.widgets.queryTab_widget.queryEditArea.destroyDescendants();
		
		// reset selection of grid
		rqWidget.widgets.queryTab_widget.attributeListGrid.selection.clear();
		
		// show hint
		var s = new application.widgets.retrieveAttributes.chooseAttribute ({
			rqWidget : rqWidget
		});
		s.placeAt(rqWidget.widgets.queryTab_widget.queryEditArea.id);
		application.OT.retrieve.registeredWidgets.add(s); // register widget in windgetSet
	
	},
	
	'editAttributeForQuery': function(grid, item) {
		if (grid && item) {
			var OT_UUID = grid.domNode.parentElement.parentElement.parentElement.id.substring(6, grid.domNode.parentElement.parentElement.parentElement.id.length-6);
			var rqWidget = dijit.byId(this.rQ_tab_prepend+OT_UUID);
			// var rqWidget = dijit.byId(this.rQ_tab_prepend+this.current_OT_UUID);
			rqWidget.widgets.queryTab_widget.queryEditArea.destroyDescendants();
			// get attribute kind
			var kind = grid.store.getValue(item, 'kind');
			{ // output widget
				if (application.widgets.retrieveAttributes[kind]) {
					{ // output the attribute configuration title
						dojo.create(
							'h2', 
							{innerHTML: T('OT_retrieve.js/EditRetrCritFor_TIT','Edit retrieval criterium for « $[0]» ',[item.name]) }, 
							rqWidget.widgets.queryTab_widget.queryEditArea.id
						);
					}
					{ // output general retrieval options must, can, ...
						var gRO = new application.widgets.retrieveAttributes.generalConfiguration({
							attrInfo : item,
							rqWidget : rqWidget
						});
						gRO.placeAt(rqWidget.widgets.queryTab_widget.queryEditArea.id);
						application.OT.retrieve.registeredWidgets.add(gRO); // register widget in widgetSet
					}
					{ // output attribute specific retrieval configuration
						var s = new application.widgets.retrieveAttributes[kind] ({
							attrInfo : item,
							rqWidget : rqWidget
						});
						s.placeAt(rqWidget.widgets.queryTab_widget.queryEditArea.id);
						application.OT.retrieve.registeredWidgets.add(s); // register widget in windgetSet
					}
				} else {
					var s = new application.widgets.retrieveAttributes.noSearch ({
						attrInfo : item,
						rqWidget : rqWidget
					});
					s.placeAt(rqWidget.widgets.queryTab_widget.queryEditArea.id);
					application.OT.retrieve.registeredWidgets.add(s); // register widget in windgetSet
				}
			} // end output widget
		}
	}, // end-of-function editAttributeForQuery
	
	
	'getRetrievalAttributeValue': function(A_UUID, label) {
		/**
		 * Returns the value of a retrieval attribute, which is saved in the attribute store of the 
		 * retrieval widget of this object type.
		 * @param A_UUID string. The UUID of the attribute.
		 * @param label string. The name of the slot, which contains the value.
		 * @return null. On failure. If the either the attribute or the slot in the attribute is found.
		 * @return mixed. 
		 */
		var rqWidget = dijit.byId(this.rQ_tab_prepend+this.current_OT_UUID);
		var returnValue = null;
		rqWidget.attributeStore.fetchItemByIdentity({
			'identity' : A_UUID,
			'onItem' : function(item) {
				if (item != null) {
					if (rqWidget.attributeStore.hasAttribute(item, label)) {
						returnValue = rqWidget.attributeStore.getValue(item, label);
					}
				}
			}
		});
		return(returnValue);
	}, // end-of-method getAttributeWidget
	
	
	'changeRetrievalAttribute': function(A_UUID, propertyValues) {
		/**
		 * Creates all properties, that belong to a specific attribute. All attribute type specfic properties
		 * are given in the object propertyValues.
		 * @param A_UUID string. The UUID of the attribute.
		 * @param propertyValues object. The values of all attribute type specfic properties of the attribute.
		 *	If null, nothing happens.
		 * @return void
		 */
		var rqWidget = dijit.byId(this.rQ_tab_prepend+this.current_OT_UUID);
		rqWidget.attributeStore.fetchItemByIdentity({
			'identity' : A_UUID,
			'onItem' : function(item) {
				if (item == null) {
					// do nothing
				}
				else {
					var attributeKind = application.attributeKinds.attributeKindList[rqWidget.attributeStore.getValue(item,'kind')];
					var ok = rqWidget.attributeStore.getValue(item, 'ok');
					var newOk = propertyValues['ok'];
					{ // Set all properties (copy property values from object 'propertyValues' to attributeStore)
						for (var key in propertyValues) {
							rqWidget.attributeStore.setValue(item, key, propertyValues[key]);
						}
					}
					{ // Check input, if ok then display the condition, else make out invisible
						if (newOk || ((newOk == undefined) && ok)) {
							// Save (set) properties, that are not attribute specific.
							rqWidget.attributeStore.setValue(item, 'queryPart', true);
							if (rqWidget.attributeStore.getValue(item,'searchType') == 'must') {
								rqWidget.attributeStore.setValue(item, 'searchTypeDisplay', 'must');
							}
							else {
								rqWidget.attributeStore.setValue(item, 'searchTypeDisplay', 'can ('+rqWidget.attributeStore.getValue(item, 'canPoints')+')');
							}
						}
						else {
							application.OT.retrieve.deleteRetrievalAttribute(A_UUID);
						}
					}
				}
			} 
		}); // end-of-fetchItemByIdentity
	}, // end-of-method changeRetrievalAttribute
	
	
	'deleteRetrievalAttribute': function(A_UUID) {
		/**
		 * Deletes all properties, that belong to the attribute identified by the A_UUID.
		 * @param A_UUID string. The UUID of the attribute.
		 * @return void
		 */
		var rqWidget = dijit.byId(this.rQ_tab_prepend+this.current_OT_UUID);
		rqWidget.attributeStore.fetchItemByIdentity({
			'identity' : A_UUID,
			'onItem' : function(item) {
				if (item == null) {
					// Do nothing
				}
				else {
					var attributeKind = application.attributeKinds.attributeKindList[rqWidget.attributeStore.getValue(item, 'kind')];
					{ // Unset attribute type specific properties
						if (attributeKind.defaultRetrievalValues) {
							var defaultRetrievalValues = attributeKind.getDefaultRetrievalValues(item);
							dojo.forEach(defaultRetrievalValues, function (propertyName){
								rqWidget.attributeStore.unsetAttribute(item, propertyName);
							});
						};
					}
					{ // Unset properties, that are not attribute specific
						rqWidget.attributeStore.unsetAttribute(item, 'queryPart');			// relevant
						rqWidget.attributeStore.unsetAttribute(item, 'parsedQuery');		// visible					
						rqWidget.attributeStore.unsetAttribute(item, 'searchTypeDisplay');	// visible
					}
				}
			}
		}); // end-of-fetchItemByIdentity
	}, // end-of-method deleteRetrievalAttribute
	
	
	'showResultTab': function(rqWidget) {
		// save the information in the store
		rqWidget.attributeStore.save();					
		var optionTabContainer = dijit.byId(rqWidget._OT_retrieve_tabContainer_id);
		optionTabContainer.selectChild(rqWidget._OT_retrieve_tab_id+'_Results');
	}, // end-of-functionshowResultTab
	
	
	'showQueryResults': function(resultsContentWidget,rqWidget) { // build dialog for query
		// retrieve objects for attribute values
		application.OT_AJAX_query(
			{
				"task"				: "retrieveObjectsBy_attributeValues",
				"UUID"				: rqWidget.OT_UUID,
				"retrievalValues"	: rqWidget.attributeStore._getNewFileContentString()
			},
			function(r, a) {
				rqWidget.resultStore = new dojo.data.ItemFileWriteStore({
					'data' : r,
					'clearOnClose' : true,
					'urlPreventCache' : true
				});
				var resultTable = new application.widgets.OT_retrieve.showResults({
						results: r,
						OT_UUID: rqWidget.OT_UUID
					})
				resultsContentWidget.attr('content',resultTable);
			}, // end-of-onSuccess function
			true /*sync*/
		); 	
	}, // end-of-method queryConfigDialog
	
	
	'markResultForFurtherAction': function(isSelected, OT_UUID, itemIdentity) {
		var rqWidget = dijit.byId(this.rQ_tab_prepend+OT_UUID);
			
		rqWidget.resultStore.fetchItemByIdentity({
			identity : itemIdentity,
			onItem : function (item) {
					
					if ( isSelected ) {
						rqWidget.resultStore.setValue(/* item */ item, /* string */ 'isSelected', /* almost anything */ true);
					
						var attributes = rqWidget.resultStore.getAttributes(item);
						if ( attributes && attributes.length > 0 ){
							var j;
							var newItem = {};
							for ( j = 0; j < attributes.length; j++  ){
								var values = rqWidget.resultStore.getValues(item, attributes[j]);

								if ( values ){
									if ( values.length > 1 ){
										// Create a copy.
										newItem[attributes[j]] = values.slice(0, values.length);
									} else {
										newItem[attributes[j]] = values[0];
									}
								}
							}
							rqWidget.markedObjectsStore.newItem(newItem);
						}					
						
					} else {
						rqWidget.resultStore.unsetAttribute(/* item */ item, /* string */ 'isSelected');
						
						rqWidget.markedObjectsStore.fetchItemByIdentity({
							identity : itemIdentity,
							onItem: function (item) {
									rqWidget.markedObjectsStore.deleteItem(item);
							}									
						});	
					}
					
					rqWidget.resultStore.save();
					rqWidget.markedObjectsStore.save();
			} // end of function onItem
		}); // end get the item	

	}, // end of method markResultForFurtherAction
		
	
	'showComparison': function(comparisonContentWidget,rqWidget) { // build dialog for query
			
		var comparisonTable = new application.widgets.OT_retrieve.compareResults(
			{
				OT_UUID: rqWidget.OT_UUID,
				showOnlySelected: true
			}
		);
		
		comparisonContentWidget.attr('content',comparisonTable);
				
	}, // end-of-method queryConfigDialog
	
	
	'_end_': null
	
} // end-of application.OT.retrieve


application.OT.retrieve.saveQuery = {
	
	'currentRQueryWidgetId' : '',
	
	
	'showDialogue': function (rqWidget){
		
		// save the widgetId
		this.currentRQueryWidgetId = rqWidget.id;
				
		// save the information in the store
		rqWidget.attributeStore.save();					
		
		var d = dijit.byId('application.OT.Dialogues.save_retrievalQuery');
		
		var parsedQuery_must ='';
		rqWidget.attributeStore.fetch({
			query: {queryPart:true, searchType:'must'},
			onItem: function(item){
				if (parsedQuery_must != '') {
					parsedQuery_must += "<p> " + T('FUT_AND','AND') + " </p>";
				}
				parsedQuery_must += "<p>"+rqWidget.attributeStore.getValue(/* item */ item, /* string */ 'parsedQuery' )+"</p>";
			}
		});
		
		// empty the variable insertion menu
		var mustCriteria = dijit.byId('application.OT.Dialogues.save_retrievalQuery.parsedQuery_must'); 
		mustCriteria.attr('content', parsedQuery_must);

		var parsedQuery_can ='';
		rqWidget.attributeStore.fetch({
			query: {queryPart:true,searchType:'can'},
			onItem: function(item){
				if (parsedQuery_can !='') {
					parsedQuery_can += "<p> " + T('FUT_OR','OR') + " </p>";
				}
				parsedQuery_can += "\n"+rqWidget.attributeStore.getValue(/* item */ item, /* string */ 'parsedQuery' );
			}
		});
		
		// empty the variable insertion menu
		var canCriteria = dijit.byId('application.OT.Dialogues.save_retrievalQuery.parsedQuery_can'); 
		canCriteria.attr('content', parsedQuery_can);
		
		// empty the textbox for name
		var queryName = dijit.byId('application.OT.Dialogues.save_retrievalQuery.queryName'); 
		queryName.attr('value', '');

		// show the dialog
		d.show();	
		
	}, // end-of-method showDialogue
	
	
	'validateName': function(inputWidget){
		var submitButton = dijit.byId('application.OT.Dialogues.save_retrievalQuery.okButton');
		if (inputWidget.isValid()) { 
			submitButton.attr('disabled',false);
		} else {
			submitButton.attr('disabled',true);
		};
	}, // end-of-method validateName
	
	
	'execute': function () {
		// extract the necessary information
		var queryName = dijit.byId('application.OT.Dialogues.save_retrievalQuery.queryName');
		
		var rqWidget = dijit.byId( this.currentRQueryWidgetId);

		// save the modified equation system to the server
		application.OT_AJAX_query(
			{
				"task": "save_OT_retrievalQuery",
				"OT_UUID": rqWidget.OT_UUID,
				"retrievalQuery": rqWidget.attributeStore._getNewFileContentString(),
				"queryName": queryName.get('value')
			}, 
			function (r,a) { // onSuccess
				dijit.byId('application.OT.Dialogues.save_retrievalQuery').hide();
			},
			true
		); // end of AJAX query
		
	}, // end-of-method execute

	
	'_end_': null

} // end-of application.OT.retrieve.saveQuery


application.OT.retrieve.loadQuery = {
	
	'currentRQueryWidgetId' : '',
	
	
	'showDialogue': function (rqWidget){
		
		// save the widgetId
		this.currentRQueryWidgetId = rqWidget.id;
				
		// save the information in the store
		rqWidget.attributeStore.save();					
		
		var d = dijit.byId('application.OT.Dialogues.load_retrievalQuery');
		
		// load all queries for that OT from server
		application.OT_AJAX_query(
			{
				"task": "get_OT_retrievalQueries",
				"OT_UUID": rqWidget.OT_UUID,
			}, 
			function (r,a) { // onSuccess
				rqWidget.savedQueries = new dojo.data.ItemFileReadStore({
					data: r,
					clearOnClose: true
				});	
			},
			true
		); // end of AJAX query

		var select = new dijit.form.FilteringSelect(
			{
				ignoreCase: true,
				query: {OT_UUID:rqWidget.OT_UUID},
				required: false,
				store: rqWidget.savedQueries,
				style: "width: 90%;",
				id: 'application.OT.Dialogues.load_retrievalQuery.select',
				dojoAttachPoint: 'application.OT.Dialogues.load_retrievalQuery.select',
				onChange: function() {
					var submitButton = dijit.byId('application.OT.Dialogues.load_retrievalQuery.okButton');
					if(this.value) { 
						application.OT.retrieve.loadQuery.selectQuery(this.item, rqWidget);
						// enable execute button
						submitButton.attr('disabled',false);
					} else {
						//disable execute button
						submitButton.attr('disabled',true);
						// clear the textbox for name
						var dialogContent = dijit.byId('application.OT.Dialogues.load_retrievalQuery.content'); 
						dialogContent.attr('content', '');
					}
				}
			}
		);
		
		// empty the textbox for name
		var queryList = dijit.byId('application.OT.Dialogues.load_retrievalQuery.selectPane'); 
		queryList.attr('content', select)
	
		// show the dialog
		d.show();	
		
	}, // end-of-method showDialogue
	
	
	'selectQuery': function (item, rqWidget){
		// parse the query to fill the specification pane on the right
		
		data = {
			"identifier": "UUID",
			"label": "UUID",
			"items": dojo.fromJson( rqWidget.savedQueries.getValue(item, 'query2' ) )
		}
		
		var selectedQuery = new dojo.data.ItemFileReadStore({
			data: data,
			clearOnClose: true
		});	

		var parsedQuery_must ='';
		selectedQuery.fetch({
			query: {queryPart:true,searchType:'must'},
			onItem: function(item){
				if (parsedQuery_must !='') {
					parsedQuery_must += "<p> " + T('FUT_AND','AND') + " </p>";
				}
				parsedQuery_must += "<p>"+selectedQuery.getValue(/* item */ item, /* string */ 'parsedQuery' )+"</p>";
			}
		});
		
		var parsedQuery_can ='';
		selectedQuery.fetch({
			query: {queryPart:true,searchType:'can'},
			onItem: function(item){
				if (parsedQuery_can !='') {
					parsedQuery_can += "<p> " + T('FUT_OR','OR') + " </p>";
				}
				parsedQuery_can += "\n"+selectedQuery.getValue(/* item */ item, /* string */ 'parsedQuery' );
			}
		});

		changedBy = new application.widgets.internalLink({
							"O_v_UUID" : rqWidget.savedQueries.getValue(/* item */ item, /* string */ 'changedByP_O_v_UUID' ),
							"linkName" : rqWidget.savedQueries.getValue(/* item */ item, /* string */ 'changedByP_name' )
						});
						
		nameBlock = '<div dojoType="application.widgets.internalLink" O_v_UUID="' + rqWidget.savedQueries.getValue(/* item */ item, /* string */ 'changedByP_O_v_UUID' ) + '">'
						+ rqWidget.savedQueries.getValue(/* item */ item, /* string */ 'changedByP_name' )
						+ '</div>';	
		
		formatOptions = {
						datePattern : 'dd.MM.yyyy',
						timePattern : 'HH:mm'
					};
		
		parsedQuery = '<h3>' + T('OT_retrieve.js/TheSelQuery_TXT','The selectet query &quot;$[0]&quot; has the following specification:',[ (rqWidget.savedQueries.getValue(/* item */ item, /* string */ 'name' )) ]) + '</h3>'
				+ '<h4>' + T('FUT_MustCriteria','Must Criteria') + '</h4>'
				+ '<div>'+((parsedQuery_must)? parsedQuery_must: '<i>' + T('FUT_none','none') + '</i>' ) + '</div>'
				+ '<h4>' + T('FUT_CanCriteria','Can Criteria') + '</h4>'
				+ '<div>'+((parsedQuery_can)? parsedQuery_can: '<i>' + T('FUT_none','none') + '</i>' ) + '</div>'
				+ '<h4>' + T('FUT_LastChange','Last change') + '</h4>'
				+ '<div>'+dojo.date.locale.format(dojo.date.stamp.fromISOString(rqWidget.savedQueries.getValue(/* item */ item, /* string */ 'changedAt' ).replace(' ','T')), formatOptions)
				+ " (" + nameBlock + ') </div>';
		
		// display the selected and parsed query
		var dialogContent = dijit.byId('application.OT.Dialogues.load_retrievalQuery.content'); 
		dialogContent.attr('content', parsedQuery); 
	
	}, // end-of-method selectQuery
	
	
	'closeDialog': function () {
	
		// delete all used widgets
		dijit.byId('application.OT.Dialogues.load_retrievalQuery.selectPane').destroyDescendants();
		dijit.byId('application.OT.Dialogues.load_retrievalQuery.content').destroyDescendants();
	
		// hide the dialog
		dijit.byId('application.OT.Dialogues.load_retrievalQuery').hide();

	}, // end-of-method closeDialog
	
	
	'execute': function () {
		//extract the necessary information
		var querySelect = dijit.byId('application.OT.Dialogues.load_retrievalQuery.select');
		
		var rqWidget = dijit.byId( this.currentRQueryWidgetId);
		
		var data = {
			"identifier": "UUID",
			"label": "UUID",
			"items": dojo.fromJson( rqWidget.savedQueries.getValue(/* item */ querySelect.item, /* string */ 'query2' ) )
		}
		
		// get list of available attributes 
		rqWidget.attributeStore.close();
		rqWidget.attributeStore = new dojo.data.ItemFileWriteStore({
			data: data,
			clearOnClose: true
		});	
		
		// update the grid and clear the edit area
		rqWidget.widgets.queryTab_widget.attributeListGrid.setStore(rqWidget.attributeStore);
		rqWidget.widgets.queryTab_widget.attributeListGrid.selection.clear();
		application.OT.retrieve.editAttributeForQuery();
		
		this.closeDialog();
	}, // end-of-method execute

	
	'_end_': true
	
} // end-of application.OT.retrieve.loadQuery


// register the menu bar item kind for object types
application.OT_menubar_itemKinds.register({name: T('FUT_NewQuery', 'New Query'),
	UUID: 		"OT_menubar_itemKinds.general.newQuery",
	addWhenCreating : true,
	JS_command:	application.OT.retrieve.show,
	description:"<p>" + T('OT_retrieve.js/ThisCommandOpens_TXT','This command opens a tab for a new retrieval query.') + "</p>"
});
