/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare('application.widgets.OT_retrieve.compareResults',[dijit.layout.BorderContainer],{
	// see file:///Y:/Gespiegelte%20Webseiten/Dojo%20Toolkit%20Documentation/DOJOTOOL/REFERENC/DIJIT/_WIDGET.HTM#dijit-widget
	// see as well file:///Y:/Gespiegelte%20Webseiten/Dojo%20Toolkit%20Documentation/DOJOTOOL/REFERENC/QUICKSTA/WRITINGW.HTM#quickstart-writingwidgets
	'title' 	: 	'',
	'closable'	:	false,
	'gutters'	:	true,
	'parentWidget': {}, // This contains the parent widget
	'editableObject' : {}, //you can store the editable object here
	
	constructor : function() {
		// Your constructor method will be called before the parameters are mixed into the widget, and can be used to initialize arrays, etc.
		this.inherited(arguments);
		
		// some initialisations
		this.widgets 		= {};
	} // end of method constructor
	,
	postMixInProperties : function() {
		// If you provide a postMixInProperties method for your widget, 
		// it will be invoked before rendering occurs, and before 
		// any dom nodes are created. If you need to add or change the 
		// instance's properties before the widget is rendered 
		// - this is the place to do it.
		this.inherited(arguments);

		this.parentWidget = dijit.byId(application.OT.retrieve.rQ_tab_prepend+this.OT_UUID);
		
		// get the object type's name
		this.name='unknown';
		application.OT.navigationStore.fetch({
			query: {'UUID':this.OT_UUID},
			scope: this,
			onItem: function(item){
				this.name=application.OT.navigationStore.getValue(item,'name');
			} // end of method onItem
		});
		
	} // end of method postMixInProperties
	,
	// 'style' : 'background-color:yellow;'
	// ,
	/*buildRendering : function() {
		// dijit._Templated provides an implementation of buildRendering 
		// that most times will do what you need. The template is fetched/read, 
		// nodes created and events hooked up during buildRendering. The end 
		// result is assigned to this.domNode. If you don't mixin dijit._Templated 
		// (and most OOTB dijits do) and want to handle rendering yourself 
		// (e.g. to really streamline a simple widget, or even use a different 
		// templating system) this is where you'd do it.
		this.inherited(arguments);
	} // end of method buildRendering
	,*/
	postCreate : function() {
		// This is typically the workhorse of a custom widget. The widget has 
		// been rendered (but note that sub-widgets in the containerNode have not!). 
		// The widget though may not be attached to the DOM yet so you shouldn't 
		// do any sizing calculations in this method.
		this.inherited(arguments);
		
		// Create the menu bar
		this.widgets.menuBar_widget = new dijit.MenuBar({
			'region': 'top'
		});
		this.addChild(this.widgets.menuBar_widget);
		
		this.widgets.numberOfObjects_MBWidget = new dijit.MenuBarItem({
			label: '* this label will be overwritten *',
			compareObjs_Pane : this,
		});
		this.widgets.menuBar_widget.addChild(this.widgets.numberOfObjects_MBWidget);

		var tabContainerOfObjectType 	= application.OT.OT_tabContainer_prepend+ this.OT_UUID;
		
		this.widgets.addEditableObject_widget = new dijit.MenuBarItem({
			label: T('OT_compare_results.js/AddObj_MNU','add new object'),
			compareObjs_Pane : this,
			style: 'float:right;',
			onClick: function(e){application.OT_menubar_itemKinds.itemKinds_asSlots['OT_menubar_itemKinds.general.newObject'].JS_command(this.compareObjs_Pane.OT_UUID,tabContainerOfObjectType,true,'dijit.byId(\''+this.compareObjs_Pane.id+'\').addNewObject(r);');},
			title: T('OT_compare_results.js/AddObj_MNU','add new object')
		});	
		// this.widgets.menuBar_widget.addChild(this.widgets.addEditableObject_widget);
		
		this.widgets.saveEditableObject = new dijit.MenuBarItem({
			label: T('OT_compare_results.js/SaveChanges_MNU','save changes'),
			compareObjs_Pane : this,
			style: 'float:right;',
			onClick: this.saveEditObject,
			title: T('OT_compare_results.js/SaveChanges_MNU','save changes')
		});	
		// this.widgets.menuBar_widget.addChild(this.widgets.saveEditableObject);

		this.widgets.discardEditableObject = new dijit.MenuBarItem({
			label:  T('OT_compare_results.js/DiscardChanges_MNU','discard changes'),
			compareObjs_Pane : this,
			style: 'float:right;',
			onClick: this.deleteEditableObject,
			title:  T('OT_compare_results.js/DiscardChanges_MNU','discard changes')
		});	
		// this.widgets.menuBar_widget.addChild(this.widgets.discardEditableObject);
		
		this.buildMenuBar('compare');
		
	} // end of method postCreate
	,
	buildMenuBar: function (option){
		
		switch (option) {
			case 'edit':
					this.widgets.menuBar_widget.removeChild(this.widgets.addEditableObject_widget);
					this.widgets.menuBar_widget.addChild(this.widgets.saveEditableObject);
					this.widgets.menuBar_widget.addChild(this.widgets.discardEditableObject);
					break;
			default: 
				this.widgets.menuBar_widget.addChild(this.widgets.addEditableObject_widget);
				this.widgets.menuBar_widget.removeChild(this.widgets.saveEditableObject);
				this.widgets.menuBar_widget.removeChild(this.widgets.discardEditableObject);		
		}; // end of switch
		
	}
	,
	numObjects : 0 // integer
	,
	markedObjects: {} // ItemFileWriteStore which contains the objects for the grid
	,
	buildStoreForGrid: function () {
		var rqWidget = this.parentWidget;

		var data = {	"identifier": "UUID",
						"label": "UUID",
						"items": []
					};
		
		this.markedObjects = new dojo.data.ItemFileWriteStore({
								data: data,
								clearOnClose: true
							}); // store for displaying
		
		var tableData = {}; // object to store to transposed object store
	
		// iterarte over the selectd objects	
		this.parentWidget.markedObjectsStore.fetch({
			onItem:function(objectItem) {
				var O_v_UUID=rqWidget.markedObjectsStore.getValue(objectItem,'O_v_UUID');
				
				if ( O_v_UUID != this.editableObject.O_v_UUID) {

					// get attribute definition and attributValueSets from DB
					application.O_AJAX_query(
						{
							"task"	: "get_O_attributeValueSets", 
							"UUID"	: O_v_UUID 
						}, 
						function(r,a){ // onSuccess method
							// 						
							for (attr_UUID in r.attributesWithValueSets) {
								
								if ( !tableData[attr_UUID] ) {
									tableData[attr_UUID] = {};
								} 
								tableData[attr_UUID][r.object.O_v_UUID]		= r.object.O_v_UUID;
								tableData[attr_UUID]['UUID'] 			= attr_UUID;
								tableData[attr_UUID]['kind'] 			= r.attributesWithValueSets[attr_UUID].attribute.kind;
								tableData[attr_UUID]['name'] 			= r.attributesWithValueSets[attr_UUID].attribute.name;
								tableData[attr_UUID][r.object.O_v_UUID+'values']	= r.attributesWithValueSets[attr_UUID].values;
								tableData[attr_UUID][r.object.O_v_UUID+'config']	= r.attributesWithValueSets[attr_UUID].attribute;
								
							}
						} // end of onSuccess method
						,
						true // sync
					); // end AJAX query	

				}; // end of is editable object
				
			} // end of function onItem
			,
			scope: this
		});
		
		// add editable object
		if (typeof this.editableObject.O_v_UUID != "undefined"){	
			
			for (attr_UUID in this.editableObject.attributes) {
				
				if ( !tableData[attr_UUID] ) {
					tableData[attr_UUID] = {};
				} 
				tableData[attr_UUID][this.editableObject.O_v_UUID]			= this.editableObject.O_v_UUID;
				tableData[attr_UUID]['UUID'] 			= attr_UUID;
				tableData[attr_UUID]['kind'] 			= this.editableObject.attributes[attr_UUID].attribute.kind;
				tableData[attr_UUID]['name'] 			= this.editableObject.attributes[attr_UUID].attribute.name;
				tableData[attr_UUID][this.editableObject.O_v_UUID+'values']	= this.editableObject.attributes[attr_UUID].values;
				tableData[attr_UUID][this.editableObject.O_v_UUID+'config']	= this.editableObject.attributes[attr_UUID].attribute;
				
			}
		}

		// add items to the store for displaying in the grid
		for (i in tableData) {
			this.markedObjects.newItem(tableData[i]);
		}

	}
	,
	addNewObject: function (newObject) {
		// mark new object as edit
		this.markForEdit(newObject.O_v_UUID);
 	}
	,
	markForEdit: function (O_v_UUID) {
		
		var editableObject = {};
		// get attribute definition and attributValueSets from DB
		application.O_AJAX_query(
			{
				"task"	: "get_O_attributeValueSets", 
				"UUID"	: O_v_UUID 
			}, 
			function(r,a){ // onSuccess method					
				editableObject = r.object;
				editableObject['attributes'] = r.attributesWithValueSets;
			} // end of onSuccess method
			,
			true // sync
		); // end AJAX query	
		
		this.editableObject = editableObject;
		
		this.buildStoreForGrid();
		this.rebuildGrid();

		this.buildMenuBar('edit');
	
	}
	,
	saveEditObject: function (){
	
		// !!!! different scope du to event handling
		
		this.compareObjs_Pane.buildMenuBar('compare');
				
		// save this.compareObjs_Pane.editableObject to DB
		var activateObject = false;
		if (this.compareObjs_Pane.editableObject.versionType == "t") {
		// activate object
			activateObject = true;
		}
		
		var A_UUIDs = [];
		var attributesValues = {};
		for ( var A_UUID in this.compareObjs_Pane.editableObject.attributes ){
			
			if ( Object.keys(this.compareObjs_Pane.editableObject.attributes[A_UUID].values).length  > 0 ){
				A_UUIDs.push(A_UUID);
			}
			
			for ( var i in this.compareObjs_Pane.editableObject.attributes[A_UUID].values ){
				if(!attributesValues[A_UUID]) attributesValues[A_UUID] = {};
				attributesValues[A_UUID][i] = this.compareObjs_Pane.editableObject.attributes[A_UUID].values[i];
			};
		};
		
		application.O_AJAX_query(
			{
				"task"	: "set_O_attributeValuesOfAnAttributeSet", 
				"O_v_UUID"	: this.compareObjs_Pane.editableObject.O_v_UUID,
				"A_UUIDs"	: dojo.toJson(A_UUIDs),
				"attributeValues": dojo.toJson(attributesValues),
				"activate" : activateObject,
				"scope"		: this.compareObjs_Pane,
			}, 
			function(r,a){ // onSuccess method					
				
				a.args.content.scope.editableObject = {};
				
				// this.compareObjs_Pane.parentWidget.markedObjectsStore.newItem();
				// this.compareObjs_Pane.parentWidget.markedObjectsStore.save();
			
				//  refresh the store's contents
				a.args.content.scope.buildStoreForGrid();
			
				//  refresh the grid
				a.args.content.scope.rebuildGrid();

			} // end of onSuccess method
			,
			true // sync
		); // end AJAX query					
		
	}
	,
	deleteEditableObject: function (){

		// !!!! different scope du to event handling

		this.compareObjs_Pane.buildMenuBar('compare');

		this.compareObjs_Pane.editableObject = {};
				
		//  refresh the store's contents
		this.compareObjs_Pane.buildStoreForGrid();
	
		//  refresh the grid
		this.compareObjs_Pane.rebuildGrid();

	}
	,
	rebuildGrid : function () {
		var rqWidget = this.parentWidget;

		if(this.widgets.grid_widget) {
			// remove the grid 
			this.removeChild(this.widgets.grid_widget);
			
			// delete the grid
			this.widgets.grid_widget.destroyRecursive(false);
			delete this.widgets.grid_widget;
		} // end if there is tear-down work

		var layout = [{	field: 'name',
						name: '<b>'+ T('FUT_Attributes','Attributes') + '</b>',
						width: '7.5em',
						formatter: function(name,rowIndex,cellObj){						
							return '<b>'+name+'</b> ';
						} // end of formatter function
					}];	// end of grid_headerStructure
			
		// iterate over all items, count them and detect whether they are tagged
		this.numObjects=0;
		// display the number of items
		this.widgets.numberOfObjects_MBWidget.attr('label',''
		
				+ T('OT_compare_results.js/XObjectsFound_HTM','<strong>$[0]</strong> $[1] found',[(dojo.number.format(this.numObjects,{pattern:'###,###,##0'})) , (this.name)])
				/*
				 +'<strong>'
					+dojo.number.format(this.numObjects,{pattern:'###,###,##0'})
				+'</strong>'
				+' '+this.name+' found'
				*/
			);
			
		// iterarte over the selected objects	
		this.parentWidget.markedObjectsStore.fetch({
			onItem:function(objectItem) {
				var O_v_UUID=rqWidget.markedObjectsStore.getValue(objectItem,'O_v_UUID');

				if ( O_v_UUID != this.editableObject.O_v_UUID) {
				
					// build header with the names of the selected Objects and define output format
					layout.push({
							field: O_v_UUID,
							name: '<b>'+rqWidget.markedObjectsStore.getValue(objectItem,'name')+'</b> '+(((typeof this.editableObject.O_v_UUID == "undefined"))?'<img src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/edit-3.png" alt="edit" onclick="dijit.byId(\''+this.id+'\').markForEdit(\''+O_v_UUID+'\')">':''),
							width: 'auto',
							formatter: function(O_v_UUID,rowIndex,cellObj){						
								var grid=cellObj.grid, 
									store=grid.store, 
									item=grid.getItem(rowIndex),
									A_UUID=store.getValue(item,'UUID'),
									attrType=store.getValue(item,'kind'),
									valueTuplesArray=store.getValues(item,O_v_UUID+'values'),
									config=store.getValue(item,O_v_UUID+'config');							
								var valueTuples = {};
								for (i in valueTuplesArray) {
									valueTuples = valueTuplesArray[i];
								};
								if ( A_UUID && O_v_UUID && ( Object.keys(valueTuples).length > 0) && config) {
									var widget =  new application.widgets[attrType]({
										'_destroyOnRemove' :true, // see http://dojotoolkit.org/reference-guide/dojox/grid/DataGrid.html
										'A_UUID': 		A_UUID,
										'O_UUID': 		O_v_UUID,
										'isEmbedded':	true,
										'edit':			false,
										'valueTuples':	valueTuples,
										'config':		config
									});
									
									if ((typeof this.editableObject.O_v_UUID == "undefined") || (config.readOnly == true)) return widget;
									
									var outer = new application.widgets.OT_retrieve.copyValueWidget({
													'valueWidget': widget,
													'outerWidget': this,
													'O_v_UUID': O_v_UUID,
													'A_UUID': A_UUID
											});
									
									return outer;
								} else {
									return '-';
								}
							} // end of formatter function
						});	
				}; // end of is editable object	
			} // end of function onItem
			,
			onBegin:function(size) {
				this.numObjects=size;
				this.widgets.numberOfObjects_MBWidget.attr('label',''
						
						+ T('OT_compare_results.js/XObjectsFound_HTM','<strong>$[0]</strong> $[1] found#',[(dojo.number.format(this.numObjects,{pattern:'###,###,##0'})) , (this.name)])
						/*    
						+'<strong>'
							+dojo.number.format(this.numObjects,{pattern:'###,###,##0'})
						+'</strong>'
						+' '+this.name+' found'
						*/
					);
			} // end of function
			,
			scope: this
		});

		if (typeof this.editableObject.O_v_UUID != "undefined"){
			var edit_O_v_UUID = this.editableObject.O_v_UUID;

			// build header with the names of the selected Objects and define output format
			layout.push({
					field: edit_O_v_UUID,
					name: '<b>'+this.editableObject.name+'</b> ',
					width: 'auto',
					formatter: function(O_v_UUID,rowIndex,cellObj){						
						var grid=cellObj.grid, 
							store=grid.store, 
							item=grid.getItem(rowIndex),
							A_UUID=store.getValue(item,'UUID'),
							attrType=store.getValue(item,'kind'),
							valueTuplesArray=store.getValues(item,O_v_UUID+'values'),
							config=store.getValue(item,O_v_UUID+'config');
						var valueTuples = {};
						for (i in valueTuplesArray) {
							valueTuples = valueTuplesArray[i];
						};
						if ( A_UUID && O_v_UUID && ( Object.keys(valueTuples).length > 0) && config) {
							var widget =  new application.widgets[attrType]({
								'_destroyOnRemove' :true, // see http://dojotoolkit.org/reference-guide/dojox/grid/DataGrid.html
								'A_UUID': 		A_UUID,
								'O_UUID': 		O_v_UUID,
								'isEmbedded':		true,
								'edit':			false,
								'valueTuples':		valueTuples,
								'config':		config
							});
							
							return widget;
						} else {
							return '-';
						}
					} // end of formatter function
				});	
		}
		
		// dojo.require("dojox.grid.EnhancedGrid");
		
		// build the grid
		this.widgets.grid_widget = new dojox.grid.DataGrid({
			'clientSort' 	: false,
			'region' 		: "center",
			'noDataMessage' : T('OT_compare_results.js/NoDataMsg_TXT','Sorry, there are no objects available.'),
			'columnReordering' : true,
			'structure'		: layout,
			'query'			: { 'UUID': '*'},
			'store'			: this.markedObjects,
			'formatterScope': this,
			'title'			: ((typeof this.editableObject.O_v_UUID == "undefined")? T('OT_compare_results.js/ReorderColumns_TXT','You may reorder the columns.') : T('OT_compare_results.js/DblClickOnACell_TXT','DoubleClick on a cell copies the value to the editable object') )
			//'title'			: ((typeof this.editableObject.O_v_UUID == "undefined")?'You may reorder the columns.':'\'DoubleClick\' on a cell copies the value to the editable object')
			
		});
		
		// add the grid
		this.addChild(this.widgets.grid_widget);
				
	} // end of method rebuildGrid
	,
	copyValuesTo : function (O_v_UUID,A_UUID){
		var selectedAttribute = {};
		
		this.markedObjects.fetchItemByIdentity({
			'identity'	: A_UUID,
			'scope'		: this,
			'onItem'	: function (i) {
				selectedAttribute = i;
			} // end of function onItem
		});
		
		var editableObjectO_v_UUID = this.editableObject.O_v_UUID;
		
		var attributeValuesArray = this.markedObjects.getValues(selectedAttribute,O_v_UUID+'values');
		
		var attributeValues = {};
		
		for (i in attributeValuesArray) {
			for (j in attributeValuesArray[i]) {
				var AV = attributeValuesArray[i][j];
				
				delete AV.AV_UUID;
				delete AV.AV_v_UUID;
				AV.UUID = Math.uuid();
				AV.OR_v_UUID = editableObjectO_v_UUID;
				
				if ( AV.kind == "cRelationAttributeValue"){
					AV['End_O_UUID'] = AV.atEndObject.object.O_UUID;
				}
				
				
				attributeValues[AV.UUID]=(AV);
			}
		};

		this.editableObject.attributes[A_UUID].values = attributeValues;
				
		this.buildStoreForGrid();
		this.rebuildGrid();

	}
	,
	startup : function() {
		// If you need to be sure parsing and creation of any child widgets has 
		// completed, use startup. This is often used for layout widgets like 
		// BorderContainer. If the widget does JS sizing, then startup() should 
		// call resize(), which does the sizing.
		this.inherited(arguments);
		
		// dynamically refresh the store's contents
		this.buildStoreForGrid();
	
		// dynamically refresh the store's contents
		this.rebuildGrid();

		
	} // end of method startup
/*	,
	onBlur : function (){ // set Event for 
		if (typeof this.editableObject.O_v_UUID != "undefined") {
			// show a warning message
			var d = dijit.byId('application.Dialogs.O.close_objectNotPossible');
			dojo.attr('application.Dialogs.O.close_objectNotPossible.O_name','innerHTML','« '+this.attr('title')+'» ');
			d.attr('title', 'WARNING - Cannot close « '+this.attr('title')+'» ');
			d.show();
			
			// do NOT close the tab
			return false;
		}
	}*/
    /*resize : function() {
		// All widgets that do JS sizing should have a method called resize(), that lays 
		// out the widget. Resize() should be called from startup() and will also be 
		// called by parent widgets like dijit.layout.ContentPane.
	}
	,*/
/*	,
	destroy : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		
		for (var i in this.widgets) {
			if (this.widgets[i].destroyRecursive) this.widgets[i].destroyRecursive(false);
			delete this.widgets[i];
		} // end for .. in
		
		//this.inherited(arguments);
	} // end of method destroy	
*/
}); // end of declaration of application.widgets.OT_allObjectsList




dojo.declare('application.widgets.OT_retrieve.copyValueWidget',[dijit._Widget,dijit._Templated],{
	// see file:///Y:/Gespiegelte%20Webseiten/Dojo%20Toolkit%20Documentation/DOJOTOOL/REFERENC/DIJIT/_WIDGET.HTM#dijit-widget
	// see as well file:///Y:/Gespiegelte%20Webseiten/Dojo%20Toolkit%20Documentation/DOJOTOOL/REFERENC/QUICKSTA/WRITINGW.HTM#quickstart-writingwidgets
	'closable'	:	false,
	'gutters'	:	true,
	/*constructor : function() {
		// Your constructor method will be called before the parameters are mixed into the widget, and can be used to initialize arrays, etc.
		this.inherited(arguments);
	} // end of method constructor
	,*/
	postMixInProperties : function() {
		// If you provide a postMixInProperties method for your widget, 
		// it will be invoked before rendering occurs, and before 
		// any dom nodes are created. If you need to add or change the 
		// instance's properties before the widget is rendered 
		// - this is the place to do it.
		this.inherited(arguments);
		
		this.templateString = ""
			+"<div dojoAttachEvent='ondblclick:_iconClicked' >"
				+"<div style='float:right;'><img src='third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/go-next-7.png' dojoAttachEvent='onclick:_iconClicked' alt='copyValues'></div>"
				+"<div dojoAttachPoint='innerAttributeValue_widget'></div>"
			+"</div>"
			;
		
	} // end of method postMixInProperties
	,
	'_iconClicked' : function (e) {
		this.outerWidget.copyValuesTo(this.O_v_UUID, this.A_UUID );
	} // end of method _iconClicked
	,
	// 'style' : 'background-color:yellow;'
	// ,
	/*buildRendering : function() {
		// dijit._Templated provides an implementation of buildRendering 
		// that most times will do what you need. The template is fetched/read, 
		// nodes created and events hooked up during buildRendering. The end 
		// result is assigned to this.domNode. If you don't mixin dijit._Templated 
		// (and most OOTB dijits do) and want to handle rendering yourself 
		// (e.g. to really streamline a simple widget, or even use a different 
		// templating system) this is where you'd do it.
		this.inherited(arguments);
	} // end of method buildRendering
	,*/
	postCreate : function() {
		// This is typically the workhorse of a custom widget. The widget has 
		// been rendered (but note that sub-widgets in the containerNode have not!). 
		// The widget though may not be attached to the DOM yet so you shouldn't 
		// do any sizing calculations in this method.
		this.inherited(arguments);
		
		this.valueWidget.placeAt(this.innerAttributeValue_widget);

		
	} // end of method postCreate
	,
	startup : function() {
		// If you need to be sure parsing and creation of any child widgets has 
		// completed, use startup. This is often used for layout widgets like 
		// BorderContainer. If the widget does JS sizing, then startup() should 
		// call resize(), which does the sizing.
		this.inherited(arguments);

		
	} // end of method startup

}); // end of declaration of application.widgets.OT_allObjectsList

