/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare('application.widgets.OT_retrieve.showResults',[dijit.layout.BorderContainer],{
	// see file:///Y:/Gespiegelte%20Webseiten/Dojo%20Toolkit%20Documentation/DOJOTOOL/REFERENC/DIJIT/_WIDGET.HTM#dijit-widget
	// see as well file:///Y:/Gespiegelte%20Webseiten/Dojo%20Toolkit%20Documentation/DOJOTOOL/REFERENC/QUICKSTA/WRITINGW.HTM#quickstart-writingwidgets
	//'title' 	: 	'All',
	'title' 	: 	'',
	'closable'	:	false,
	'gutters'	:	true,
	/*constructor : function() {
		// Your constructor method will be called before the parameters are mixed into the widget, and can be used to initialize arrays, etc.
		this.inherited(arguments);
	} // end of method constructor
	,*/
	postMixInProperties : function() {
		// If you provide a postMixInProperties method for your widget, 
		// it will be invoked before rendering occurs, and before 
		// any dom nodes are created. If you need to add or change the 
		// instance's properties before the widget is rendered 
		// - this is the place to do it.
		this.inherited(arguments);

		// get the object type's name
		this.name='unknown';
		application.OT.navigationStore.fetch({
			query: {'UUID':this.OT_UUID},
			scope: this,
			onItem: function(item){
				this.name=application.OT.navigationStore.getValue(item,'name');
			} // end of method onItem
		});
		
	} // end of method postMixInProperties
	,
	// 'style' : 'background-color:yellow;'
	// ,
	/*buildRendering : function() {
		// dijit._Templated provides an implementation of buildRendering 
		// that most times will do what you need. The template is fetched/read, 
		// nodes created and events hooked up during buildRendering. The end 
		// result is assigned to this.domNode. If you don't mixin dijit._Templated 
		// (and most OOTB dijits do) and want to handle rendering yourself 
		// (e.g. to really streamline a simple widget, or even use a different 
		// templating system) this is where you'd do it.
		this.inherited(arguments);
	} // end of method buildRendering
	,*/
	postCreate : function() {
		// This is typically the workhorse of a custom widget. The widget has 
		// been rendered (but note that sub-widgets in the containerNode have not!). 
		// The widget though may not be attached to the DOM yet so you shouldn't 
		// do any sizing calculations in this method.
		this.inherited(arguments);
		
		// Create the menu bar
		this.menuBar_widget = new dijit.MenuBar({
			'region': 'top'
		});
		this.addChild(this.menuBar_widget);
		
		this.numberOfObjects_MBWidget = new dijit.MenuBarItem({
			label: '* this label will be overwritten *',
			allObjs_Pane : this,
		});
		this.menuBar_widget.addChild(this.numberOfObjects_MBWidget);
					
		// this.reloadMBI_widget = new dijit.MenuBarItem({
			// label: '',
			// 'class': 'RS_icon_refresh_small RS_MenuBarItem_withIcon',
			// allObjs_Pane : this,
			// /*style: 'float:right;',*/
			// onClick: function(e){this.allObjs_Pane.rebuildGrid();dojo.stopEvent(e);},
			// title: 'Refresh'
		// });
		// this.menuBar_widget.addChild(this.reloadMBI_widget);
		
	} // end of method postCreate
	,
	get_grid_headerStructure: function(){
		var rqWidget = dijit.byId(application.OT.retrieve.rQ_tab_prepend+this.OT_UUID);
		
		var grid_headerStructure = [					
							{
								field: 'isSelected',
								name:	'<div style="text-align:center;">' + T('FUT_Mark','Mark') + '</div>',
								width:	'3em',
								formatter : function(isSelected,rowIndex,cellObj){
									var grid=cellObj.grid, 
										store=grid.store, 
										item=grid.getItem(rowIndex),
										itemIdentity=store.getIdentity(item);
									return '<div style="text-align:center;"><input type="checkbox" onchange="application.OT.retrieve.markResultForFurtherAction(this.checked,\''+this.OT_UUID+'\',\''+itemIdentity+'\');" '+(isSelected?'checked':'')+'/></div>';
								} // end of formatter function
							},
							{
								field: 'isTagged',
								name:	'<div style="text-align:center;">' + T('FUT_Tagged','Tagged') + '</div>',
								width:	'3em',
								formatter : function(isTagged,rowIndex,cellObj){
									var grid=cellObj.grid, 
										store=grid.store, 
										item=grid.getItem(rowIndex),
										O_v_UUID=store.getValue(item,'O_v_UUID');
									
									return (isTagged?'<div style="text-align:center;"><img src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/others/tag-orange.png" /></div>':'');
								} // end of formatter function
							}];
		{ // add column for can point if there are can criteria
			var canCriteria = false;	
			rqWidget.resultStore.fetch({ 
				query:{canPoints:'*'},
				onBegin: function(count){
						if (count > 0 ) canCriteria = true;
					}
			});
				
			if (canCriteria)	
				grid_headerStructure.push(
								{
									field: 'canPoints',
									name: '<b>' + T('FUT_Points','Points') + '</b>',
									width: '4em',
									formatter: function(name,rowIndex,cellObj){						
										var grid=cellObj.grid, 
											store=grid.store, 
											item=grid.getItem(rowIndex),
											canPoints=store.getValue(item,'canPoints'),
											O_v_UUID=store.getValue(item,'O_v_UUID');
										if (canPoints) { 
											return canPoints;
										}else {
											return '-';
										}
									} // end of formatter function
								});
		}

		grid_headerStructure.push(
					{
						field: 'name',
						name: '<b>' + T('FUT_Name','Name') + '</b>',
						width: '10em',
						formatter: function(name,rowIndex,cellObj){						
							var grid=cellObj.grid, 
								store=grid.store, 
								item=grid.getItem(rowIndex),
								isTagged=store.getValue(item,'isTagged'),
								O_v_UUID=store.getValue(item,'O_v_UUID');
							return new application.widgets.internalLink({
								"O_v_UUID" : O_v_UUID,
								"linkName" : (isTagged?'<b>'+name+'</b>':name)
							});
						} // end of formatter function
					},
					{
						field: 'OT_name',
						name: T('FUT_Type','Type'),
						width: '7.5em'
					},
					{
						field: 'description',
						name: T('FUT_Description','Description'),
						width: 'auto'
					},
					{
						field: 'changedAt',
						name: '<div style="text-align:right">' + T('FUT_LastChange','Last change') + '</div>',
						width: 'auto',
						formatter: function(value,rowIndex,cellObj){
							var d=new Date(value.replace(' ','T')), now=new Date(), r='';
							// pretty-format the date
							if (dojo.date.difference(d,now,'hour')<1)			r=dojo.date.difference(d,now,'minute')+' min ago';
								else if (dojo.date.difference(d,now,'day')<1) 	r=dojo.date.locale.format(d,{selector:'time'});
								else 								 			r=dojo.date.locale.format(d);
							return '<div style="text-align:right;">'+r+'</div>'
						} // end of formatter function
					},
					{
						field: 'changedByP_name',
						// name: '<span class="small">Changed by</span>',
						name: T('FUT_ChangedBy','Changed by'),
						width: 'auto',
						formatter: function(name,rowIndex,cellObj){
							var grid=cellObj.grid, 
								store=grid.store, 
								item=grid.getItem(rowIndex),
								changedByP_O_v_UUID=store.getValue(item,'changedByP_O_v_UUID');
							return new application.widgets.internalLink({
								"O_v_UUID" : changedByP_O_v_UUID,
								"linkName" : name
							});
						} // end of formatter function
					}
				);	
		return grid_headerStructure	// end of grid_headerStructure
	}
	,
	numObjects : 0 // integer
	,
	rebuildGrid : function () {
		var rqWidget = dijit.byId(application.OT.retrieve.rQ_tab_prepend+this.OT_UUID);

		if(this.grid_widget) {
			// remove the grid 
			this.removeChild(this.grid_widget);
			
			// delete the grid
			this.grid_widget.destroyRecursive(false);
			delete this.grid_widget;
		} // end if there is tear-down work
		
		// iterate over all items, count them and detect whether they are tagged
		this.numObjects=0;
		// display the number of items
		this.numberOfObjects_MBWidget.attr('label',''
				+ T('OT_list_results.js/XObjFound','<strong>$[0]</strong> $[1] found',[(dojo.number.format(this.numObjects,{pattern:'###,###,##0'})),(this.name)])
				/* eg. 2 Persons found
				+'<strong>'
					+dojo.number.format(this.numObjects,{pattern:'###,###,##0'})
				+'</strong>'
				+' '+this.name+' found'
				*/
			);
		rqWidget.resultStore.fetch({
			onItem:function(item) {
				var O_v_UUID=rqWidget.resultStore.getValue(item,'O_v_UUID');
				var isTagged = application.O.readList.isTagged(O_v_UUID);
				rqWidget.resultStore.setValue(item, 'isTagged', isTagged);
				
				rqWidget.markedObjectsStore.fetchItemByIdentity({
					identity : O_v_UUID,
					onItem: function (markedItem) {
							if ( markedItem ) {
								rqWidget.resultStore.setValue(item, 'isSelected', true);
							}
					}									
				});	
				
				this.numObjects++;
			} // end of function onItem
			,
			onBegin:function(size) {
				this.numObjects=size;
				this.numberOfObjects_MBWidget.attr('label',''
						+ '<strong>' 
						+ dojo.number.format(this.numObjects,{pattern:'###,###,##0'})
						+ ' ' + this.name
						+ '</strong>'
						// eg. 2 Persons
						
					);
			} // end of function
			,
			scope: this
		});
	
		// build the grid
		this.grid_widget = new dojox.grid.DataGrid({
			'clientSort' 	: true,
			//'style' 		: "width: 100%; height: 100%;",
			'region' 		: "center",
			'noDataMessage' : T('OT_list_results.js/NoObjAvailable','Sorry, there are no objects available.'),
			'columnReordering' : true,
			'structure'		: this.get_grid_headerStructure(),
			'query'			: { 'UUID': '*' },  
			'store'			: rqWidget.resultStore,
			'formatterScope': this,
			'title'			: T('OT_list_results.js/ClickOnObjLink_HTM','Click on an object\'s link to open it. You may sort the columns asc- or descendingly.') 
		});
		
		// add the grid
		this.addChild(this.grid_widget);
				
	} // end of method rebuildGrid
	,
	startup : function() {
		// If you need to be sure parsing and creation of any child widgets has 
		// completed, use startup. This is often used for layout widgets like 
		// BorderContainer. If the widget does JS sizing, then startup() should 
		// call resize(), which does the sizing.
		this.inherited(arguments);
		
		// dojo.connect(this,'onShow',this,function(){

			// dynamically refresh the store's contents
			this.rebuildGrid();

		// });
		
	} // end of method startup
	,
    /*resize : function() {
		// All widgets that do JS sizing should have a method called resize(), that lays 
		// out the widget. Resize() should be called from startup() and will also be 
		// called by parent widgets like dijit.layout.ContentPane.
	}
	,*/
	/*destroy : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you.
		this.inherited(arguments);
	} // end of method destroy
	*/
}); // end of declaration of application.widgets.OT_allObjectsList

