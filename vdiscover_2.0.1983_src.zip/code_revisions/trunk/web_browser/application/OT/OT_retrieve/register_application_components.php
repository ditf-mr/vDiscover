<?php if (!defined('APPLICATION_started')) {header('Location: .');exit;} 
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// this file registers the components
$r->register_JavaScriptFile('application/OT/OT_retrieve/OT_retrieve.js');
$r->register_JavaScriptFile('application/OT/OT_retrieve/OT_list_results.js');
$r->register_JavaScriptFile('application/OT/OT_retrieve/OT_compare_results.js');
$r->register_JavaScriptFile('application/OT/OT_retrieve/generalConfiguration.js');
$r->register_dialogHTML('application/OT/OT_retrieve/save_retrievalQuery.dialog.dojoHTML.php');
$r->register_dialogHTML('application/OT/OT_retrieve/load_retrievalQuery.dialog.dojoHTML.php');

?>