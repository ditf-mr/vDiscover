<?php if (!defined('APPLICATION_started')) {header('Location: .');exit;}
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/
?>
 
<div dojoType="dijit.Dialog" id="application.OT.Dialogues.save_retrievalQuery" 
	title="<?php echo T('FUT_ManageRQs', 'Manage Retrieval Queries'); ?>" execute="application.OT.retrieve.saveQuery.execute();return false;"
	style="">
	
	<div dojoType="dijit.layout.BorderContainer" gutters="false"
	liveSplitters="true" style="width:600px;height:600px;">	
		<div dojoType="dijit.layout.ContentPane" region="top">
				<h2><?php echo T('save_retrQuery.php/SaveRQs_TIT', 'Save Retrieval Queries'); ?></h2>
		</div>
		<div dojoType="dijit.layout.ContentPane" splitter="true" region="center">
				
			<div dojoType="dijit.layout.BorderContainer" title="Retrieval Query" style="maxHeightWidth" gutters="false" id="application.OT.Dialogues.save_retrievalQuery.step1">
				<div dojoType="dijit.layout.ContentPane" region="top">
					<h3><?php echo T('save_retrQuery.php/Step1_TXT', 'Step 1: Current Retrieval Query'); ?></h3>
					<p><?php echo T('save_retrQuery.php/BuildQuery_TXT', 'You have build the following query:'); ?></p>
					<h4><?php echo T('FUT_MustCriteria/', 'Must Criteria'); ?></h4>
					<div dojoType="dijit.layout.ContentPane" id="application.OT.Dialogues.save_retrievalQuery.parsedQuery_must"></div>
					<h4><?php echo T('FUT_CanCriteria/', 'Can Criteria'); ?></h4>
					<div dojoType="dijit.layout.ContentPane" id="application.OT.Dialogues.save_retrievalQuery.parsedQuery_can"></div>
				</div>
				
				<div dojoType="dijit.layout.ContentPane" title="Naming" region="bottom">
					<h3><?php echo T('save_retrQuery.php/Step2_TXT', 'Step 2: Naming'); ?></h3>
					<p><?php echo T('save_retrQuery.php/EnterTheName_LBL', 'Please enter the name of the retrieval query.'); ?></p>
						<input type="text" id="application.OT.Dialogues.save_retrievalQuery.queryName" value="" dojoType="dijit.form.ValidationTextBox"
							regExp=".{2,}" required="true" intermediateChanges="true" class="textCenter" invalidMessage="<?php echo T('save_retrQuery.php/InvMsg_TXT', 'Please enter a name.'); ?>" style="width:10em;" selectOnClick="true" 
							onChange="application.OT.retrieve.saveQuery.validateName(this);">
				</div>			
			
			</div>
				
		</div>
		<div dojoType="dijit.layout.ContentPane" region="bottom" style="text-align:right;">

			<button dojoType="dijit.form.Button" type="submit" disabled="true" id="application.OT.Dialogues.save_retrievalQuery.okButton">
				<?php echo T('save_retrQuery.php/SaveRQ_BTN', 'Save Retrieval Query'); ?>
			</button>
			<button dojoType="dijit.form.Button" type="button" onClick="dijit.byId('application.OT.Dialogues.save_retrievalQuery').hide();">
				<?php echo T('BTN_Cancel', 'Cancel'); ?>
			</button>
		</div>
	</div>
</div>	
	
