<?php if (!defined('APPLICATION_started')) {header('Location: .');exit;}
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/
?>
 
<div dojoType="dijit.Dialog" id="application.OT.Dialogues.load_retrievalQuery" 
	title="<?php echo T('FUT_ManageRQs', 'Manage Retrieval Queries'); ?>" execute="application.OT.retrieve.loadQuery.execute();return false;"
	style="">
	
	<div dojoType="dijit.layout.BorderContainer" gutters="false"
	liveSplitters="true" style="width:600px;height:600px;">	
		<div dojoType="dijit.layout.ContentPane" region="top">
				<h2><?php echo T('load_retrQuery.php/LoadRQs_TXT', 'Load Retrieval Queries'); ?></h2>
		</div>
		<div dojoType="dijit.layout.BorderContainer" splitter="true" style="width:30%;" gutters="false" region="left">
			<div dojoType="dijit.layout.ContentPane" id="application.OT.Dialogues.load_retrievalQuery.selectPane" region="top">
			</div>
			<div dojoType="dijit.layout.ContentPane" region="center" style="padding-right:10px;">
				<p><?php echo T('load_retrQuery.php/SelOneOfListed_TXT', 'Please select one of the listed queries'); ?></p>
			</div>
		</div>
		<div dojoType="dijit.layout.BorderContainer" gutters="false" region="center">
			<div dojoType="dijit.layout.ContentPane" id="application.OT.Dialogues.load_retrievalQuery.content" style="padding:10px;" region="center">
					
			</div>
		</div>
		<div dojoType="dijit.layout.ContentPane" region="bottom" style="text-align:right;">

			<button dojoType="dijit.form.Button" type="submit" disabled="true" id="application.OT.Dialogues.load_retrievalQuery.okButton">
				<?php echo T('load_retrQuery.php/LoadRetQuery_BTN', 'Load Retrieval Query'); ?>
			</button>
			<button dojoType="dijit.form.Button" type="button" onClick="application.OT.retrieve.loadQuery.closeDialog();">
				<?php echo T('BTN_Cancel', 'Cancel'); ?>
			</button>
		</div>
	</div>
</div>	
	
