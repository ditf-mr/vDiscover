/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

application.OT = {
	
	// constants
	'OT_tab_prepend' 			: 'OT_tab_',
	'OT_tabContainer_prepend'	: 'OT_tC_',
	
	// internal and external variables
	'navigationStore' 			: null // dojo.data.ItemFileWriteStore
	,
	'navigationModel' 			: null // dijit.tree.ForestStoreModel
	,
	'navigationTree' 			: null // dijit.Tree
	,
	'currentObjectType'			: null // item of navigationStore
	,
	'tabWidgets'				: {} // {OT_UUID : instance of application.widgets.OT widget, ...}
	,
	
	// all methods that have do do with information object types in general go here
	'initialise_navigationTree' : function () {
	
		// initalise store
		try {
			this.navigationStore = new dojo.data.ItemFileReadStore({
					url: '?v=JSON_ObjectType&task=get_NavigationTree&withChildrenSlot=1',
					urlPreventCache : true,
					clearOnClose : true,
					// failOk : true
				});
		} catch(e) {
			application.showErrorMessage('<pre>'+dojo.toJson(e, true)+'</pre>');
		} // end-of try ... catch / store initialisation
	
		// initialise navigation model
		this.navigationModel = new dijit.tree.ForestStoreModel({
				store: application.OT.navigationStore,
				query: {'type': 'navigation_node'},
				childrenAttrs : ['children']
			});

		// initialise tree
		if (application.OT.navigationTree)application.OT.navigationTree.destroyRecursive();
		dijit.byId('application.navigationPane').destroyDescendants(false);
		dojo.empty('application.navigationPane');
		dijit.byId('application.navigationPane').attr('content', '<div id="application.navigationPane.navTreeContainerDIV"></div>');
		try {
		
			this.navigationTree = new dijit.Tree ({
					model:application.OT.navigationModel,
					openOnClick: false,
					showRoot: false,
					persist: true,
					/*onDblClick*/onClick:function(item, node) {
						with (application.OT.navigationStore) {
								application.OT.currentObjectType = item;
								if(item && (getValue(item, 'type')=='OT')) {
									application.OT.show(getValue(item, 'UUID')/*,getValue(item, 'name'),dojo.fromJson(getValue(item, 'menuBarOT'))*/);
								}// end if
						} // end with
					},
					getIconClass : function(item, isOpened) {
							// get item type
							var type='', has_children=false;
							try{ 
								type=(application.OT.navigationStore.hasAttribute(item,'type')?application.OT.navigationStore.getValue(item,'type'):'');
							} catch(e){}
							if(type=='OT') try{ 
								has_children=(application.OT.navigationStore.hasAttribute(item,'children') && application.OT.navigationStore.getValue(item,'children'));
							} catch(e){}
							var iconClass='';
							switch(type){
								case 'navigation_node':
									iconClass='RS_icon_navigation_node';
									break;
								/*case 'RT':
									iconClass='RS_icon_RT';
									break;*/
								case 'OT':
									iconClass=(has_children?'RS_icon_OT_with_children':'RS_icon_OT');//((isOpened)?'dijitFolderOpened':'dijitFolderClosed');
									break;
								default:
									iconClass='';
							} // end switch
							
							return iconClass;
						},
					getTooltip : function(item){return((application.OT.navigationStore.getValue(item,'type')=='OT')? T('OT.js/ClickToShowTypeTab_TTP','click to show the type tab.') : '' );}
				}, 
				'application.navigationPane.navTreeContainerDIV'
			);
						
		} catch(e) {
			console.log('Navigation tree error', e);
		} // end-of try...catch

	} // end of method initialise_navigationTree
	,
	'get_OTInfo' : function (OT_UUID) {
		var r = {};
		
		// get the information about the object type from the navigation store
		this.navigationStore.fetch({
			'query'		: {'UUID' : OT_UUID},
			'scope'		: this,
			'onItem'	: function (item) {
				var store = this.navigationStore;
				if(item && (store.getValue(item, 'type')=='OT')) {
					r.OT_name 	= store.getValue(item, 'name');
					r.OT_menuBar= store.getValue(item, 'menuBarOT');
				}// end if
			}, // end if method inItem
		});
	
		return r;
	} // end of method fetch_OTInfo
	,
	'show' : function(OT_UUID, execMenuItem_UUID, execParameters) {
		/** This method displays an information object type.
		*
		* Mandatory parameter: OT_UUID (string).
		* Optional parameters: execMenuItem_UUID (string), execParameters (no type restrictions)
		*/
		
		var OT_tabWidget = dijit.byId(this.OT_tab_prepend+OT_UUID);
		
		// if the tab widget cannot be located: create it
		if(!OT_tabWidget) {
			OT_tabWidget = new application.widgets.OT({
				'OT_UUID'	: OT_UUID,
			}).placeAt(OT_tab_container);
		
			this.tabWidgets[OT_UUID] = OT_tabWidget;
			
		} // end if
				
		// bring the tab to the front
		try { 
			dijit.byId(OT_tab_container).selectChild(OT_tabWidget);
		} catch(e) {
			console.error(e);
			throw 'application.OT :: show() :\n'
				+'Cannot show the object type tab for the OT_UUID "'+OT_UUID+'"\n'
				+'in the tab container for object types with the id:"'+OT_tab_container+'".'
				;
		} // end try ... catch
	
		// if passed: exec the command that is assigned to the passed execMenuItem_UUID with the execParameters
		if (		(typeof execMenuItem_UUID == 'string') 
				&&	execMenuItem_UUID.length
			) {
				OT_tabWidget.execMenuItem( execMenuItem_UUID, execParameters );
			} // end if
	
	} // end of method show
	,
	'findInfObjs' : function (searchTerm, OT_UUID) {
		
		var currentItem = application.OT.currentObjectType;
		
		if ( !OT_UUID && ( !currentItem || application.OT.navigationStore.getValue(currentItem, 'type') != 'OT')){
			tabContainer = 'OT_tab_container';
			searchDomain = 'all';
			OT_UUID = 'none';
		} else {
			if (!OT_UUID) OT_UUID = application.OT.navigationStore.getValue(currentItem, 'UUID');
			tabContainer = application.OT.OT_tabContainer_prepend + OT_UUID;
			searchDomain = 'this';
		
			// bring object type tab to front or create if not exists
			application.OT.navigationStore.fetchItemByIdentity({identity: OT_UUID, onItem:function(item){
					with (application.OT.navigationStore) {
							application.OT.currentObjectType = item;
							if(item && (getValue(item, 'type')=='OT')) {
								application.OT.show(getValue(item, 'UUID')/*,getValue(item, 'name'),dojo.fromJson(getValue(item, 'menuBarOT'))*/);
							}// end if
					} // end with
				}}) // end fetchItemByIdentity
		}; // end decide what to show
		
		var widgetID = 'searchResults_'+OT_UUID+'_'+searchTerm.replace(/\W+/g,'_');

		if (!dijit.byId(widgetID)) {
			// build search result widget
			var srW = new application.widgets.SearchResultWidget({
					id				: widgetID,
					title			: T('OT.js/SearchFor_HTM','Search for «$[0]» ',[searchTerm]),
					OT_UUID			: OT_UUID,
					pattern			: searchTerm,
					searchDomain	: searchDomain,
					parentTabContainer_id : tabContainer,
				});
			dijit.byId(tabContainer).addChild(srW);
			
			// focus this tab
			dijit.byId(tabContainer).selectChild(srW);
		} 
		
		return false;
	} // end-of-method findInfObjs
	,
	
	'buildRetrievalQuery': function (UUID){
		tabContainer = application.OT.OT_tabContainer_prepend + UUID

			application.OT.retrieve.show(UUID,tabContainer);
	
	}
	,
	
} // end of section application.OT

// register all available menu bar options and the corresponding code
dojo.addOnLoad(function(){
	with (application.OT_menubar_itemKinds) { // here comes now the definition of the standard OT_menubar_itemKinds
		/* TEMPLATE FOR NEW OT_menubar_itemKinds 
		
		register({name: "",
			UUID: 		"",
			JS_command:	function (UUID, tabContainer) {
				application.general_functionality.show_tab( 
					'OT_descr'+UUID, 
					'Overview', 
					dijit.byId(tabContainer), 
					encodeURI('?v=OT_Overview&UUID='+UUID), 
					true // means to refresh on clicking on the tab title
				);
			} // end-of-method showOverview,
			description:""
		});
		
		*/
		
		register({name: T('FUT_LastChanges','Last Changes'),
			'UUID'	    : "OT_menubar_itemKinds.general.lastChanges",
			'JS_command': function (UUID, tabContainer) {
				application.general_functionality.show_tab( 
					'OT_last_changes'+UUID, 
					T('FUT_LastChanges','Last Changes'), 
					dijit.byId(tabContainer), 
					encodeURI('?v=OT_last_changes&UUID='+UUID) 
				);
			} // end-of-method showLastChanges
			,
			'description': ""
			    + "<p>" + T('OT.js/LastChDescrP1_TXT','This command opens the tab with a list of the last changes that were carried out on information objects of the type.') + "</p>"
			    + "<p>" + T('OT.js/LastChDescrP2_TXT','The last changes tab is useful to see the last modifications that were carried out.') + "</p>"
		});
		
	} // end with	
	
}); // end dojo.addOnLoad