<?php 
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

if (!defined('APPLICATION_started')) {header('Location: .');exit;}

// extract the variables
// some cleanup functions are still necessary
$UUID=RS_add_JS_slashes(str_replace('"', '', RS_strip_slashes($_GET['UUID'])));
?>
<ul>
	<li>Last changes since ...</li>
	<li>Added/ changed /deleted information</li>
	<li>table with action type (added, changed, deleted) + object + time point + user</li>
	<li>Work Flow Status</li>
	<li>table with status since + due date</li>
</ul>
<p>
	Lorem ipsum dolor sit amet, consectetuer
	adipiscing elit. Nam facilisis enim. Pellentesque
	in elit et lacus euismod dignissim. Aliquam
	dolor pede, convallis eget, dictum a, blandit
	ac, urna. Pellentesque sed nunc ut justo
	volutpat egestas. Class aptent taciti sociosqu
	ad litora torquent per conubia nostra, per
	inceptos hymenaeos. In erat. Suspendisse
	potenti. Fusce faucibus nibh sed nisi. Phasellus
	faucibus, dui a cursus dapibus, mauris nulla
	euismod velit, a lobortis turpis arcu vel dui.
	Pellentesque fermentum ultrices pede. Donec
	auctor lectus eu arcu. Curabitur non orci eget
	est porta gravida. Aliquam pretium orci id nisi.
	Duis faucibus, mi non adipiscing venenatis, erat
	urna aliquet elit, eu fringilla lacus tellus quis
	erat. Nam tempus ornare lorem. Nullam feugiat.
</p>
