/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare( 'application.widgets.OT', [dijit.layout.BorderContainer], {
	
	// these parameters need to be passed on instantiation
	'OT_UUID'	: null,
	
	
	// constants
	'menuBarItem_prepend'		: 'menuBarItem_',
	'popupMenuBarItem_prepend'	: 'popupMenuBarItem_',
	
	// internal slots
	'_widgets'					: null, // {}
	'_OTName'					: null, // ""
	'_OTMenuBar'				: null, // ""
	'_dDReference_domNode'		: null, // DOM node
	'_dDReferenceWidget'		: null, // widget
	'OT_tabID_prepend' 			: null, // ''
	'OT_tabContainerID_prepend'	: null,	// ''
	
	
	// widget life cycle --------------------------------------------------------------------------
	'constructor' : function () {
		this._widgets = {};
		
		// localise constants
		this.OT_tabID_prepend 			= application.OT.OT_tab_prepend;
		this.OT_tabContainerID_prepend	= application.OT.OT_tabContainer_prepend;
		
	} // end of method constructor
	,
	'postMixInProperties' : function () {
		this.inherited(arguments);
	
		// some checks
		if ( !this.OT_UUID.length ) throw ''
			+this.declaredClass
			+'::postMixInProperties(): '
			+'no OT_UUID passed on instantiation. Aborting.'
			;
	
		// localise necessary information about the object type
		var i = application.OT.get_OTInfo(this.OT_UUID);
		this._OTName	= i.OT_name;
		this._OTMenuBar = i.OT_menuBar;

		// more checks
		if (!this._OTName || !this._OTMenuBar) throw ''
			+this.declaredClass
			+'::postMixInProperties(): '
			+'no object type name or no menu bar information found for the passed OT_UUID. Aborting.'
			;
		
		// set the id of this widget
		this.id = this.OT_tabID_prepend+this.OT_UUID;
		
		// unpack the menu bar
		if(typeof this._OTMenuBar=='string') this._OTMenuBar=dojo.fromJson(this._OTMenuBar);
		
		// sort OT_menuBar (array) by its position slots
		this._OTMenuBar = this._OTMenuBar.sort(function(i,j){return i.position - j.position;});
		
	} // end of method postMixInProperties
	,
	'postCreate' : function () {
		this.inherited(arguments);
	
		// set the title
		this.set( 'title', ''
			+'<img src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/edit-copy-6.png" style="vertical-align:text-top;margin-right:.5ex;">'
			+this._OTName);
		dojo.attr( this.containerNode, 'title', ''); // no title attribute for the widget's DOM node
	
		// set up the menu bar
		this._widgets.menuBar = new dijit.MenuBar({
			'region'	: 'top',
			'style' 	: "margin-bottom:1ex;border-top:0;border-right:0;border-left:0;",
		}).placeAt(this);
	
		// set up the drag&drop reference for the object type
		this._dDReference_domNode = dojo.create( 'SPAN', {
			'class'	: "dijitMenuItem dijitMenuItemLabel strong",
		}, this._widgets.menuBar.containerNode);
		this._dDReferenceWidget = new application.widgets.internalLink_objectType ({
			'OT_UUID'	: this.OT_UUID,
			'linkName'	: this._OTName,
		}).placeAt(this._dDReference_domNode);
	
		// create the tab container for the views on the objects
		this._widgets.tabContainer = new dijit.layout.TabContainer({
			'region'	:'center',
			'id'		: this.OT_tabContainerID_prepend+this.OT_UUID,
			'style'		: 'margin-left:.5em;margin-right:.5em;',
		}).placeAt(this);
	
		// set up the menu items and add them to the menu bar
		dojo.forEach(this._OTMenuBar, function(menuItem){
			
			switch (menuItem.type) {
				case 'dijit.MenuBarItem': { // -------------------------------------------
					this._createMenuItem( 'MenuBarItem', menuItem, this._widgets.menuBar );
				} break;
					
				case 'dijit.PopupMenuBarItem': { // -------------------------------------
				
						var pMBIWidget = new dijit.PopupMenuBarItem({
								'label'	: menuItem.label,
								'popup'	: new dijit.Menu({}),
							}).placeAt(this._widgets.menuBar);
				
						// iterate over all corresponding menu items and add them as sub menu entries
						dojo.forEach(this._OTMenuBar, function(mi){
							if (typeof mi == 'undefined') return; // internet explorer bugfix
							
							// if the sub menu item belongs to the current PopupMenuItem --> create a menu item
							if (mi.parent_UUID && (mi.parent_UUID==menuItem.UUID)) {							
								this._createMenuItem( 'MenuItem', mi, pMBIWidget.popup);
							} // end if
						}, this); // end dojo.forEach
						
						// register the popup menu item widget locally
						this._widgets[this.popupMenuBarItem_prepend+menuItem.mB_itemKind_UUID] = pMBIWidget;
						
					} break;
					
				default: // do nothing, e.g. dijit.menuItem -----------------------------
			} // end switch
			
		}, this); // end dojo.forEach menu item
		
	} // end of method postCreate
	,
	'destroy' : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		
		for (var i in this._widgets) {
			if (this._widgets[i].destroyRecursive) this._widgets[i].destroyRecursive(false);
			delete this._widgets[i];
		} // end for .. in
		
		this.inherited(arguments);
	} // end of method destroy
	,
	
	
	// external methods ---------------------------------------------------------------------------
	'execMenuItem' : function ( execMenuItem_UUID, optionalExecParameters ) {
console.log(execMenuItem_UUID);
		var mW = this._widgets[this.menuBarItem_prepend+execMenuItem_UUID];
		
		// test if the menu item exists and is instantiated
		if(!mW) throw ''
			+this.declaredClass
			+' :: execMenuItem ( '+execMenuItem_UUID+', '+dojo.toJson(optionalExecParameters)+' ) :\n'
			+'OT_UUID of the widget: '+this.OT_UUID+'\n'
			+'This type widget has no menu item with the passed UUID. Aborting.'
			;
	
		// execute the command thast is assigned to the menu item widget mW
		application.OT_menubar_itemKinds.executeCommand(
			mW.MI_UUID, 
			this.OT_UUID, 
			mW.OT_TC_id,
			optionalExecParameters
			);
	
	} // end of method execMenuItem
	,
	
	
	// internal methods ---------------------------------------------------------------------------
	'_createMenuItem' : function (type /* either'MenuBarItem' or 'MenuItem' */, menuItem/*object*/, parentWidget) {
	
		var mIWidget = new dijit[type]/*.MenuBarItem*/({
			'label'		: menuItem.label,
			
			// necessary parameters for the onClick event
			'MI_UUID'	: menuItem.mB_itemKind_UUID,
			'OT_UUID'	: this.OT_UUID,
			'OT_TC_id'	: this._widgets.tabContainer.id,
			
			// the onClick event
			'onClick'	: function (e) {
				if (e) dojo.stopEvent(e);
				
				// Attention: context is here: dijit.MenuBarItem!
				application.OT_menubar_itemKinds.executeCommand(
					this.MI_UUID, 
					this.OT_UUID, 
					this.OT_TC_id
					);
				
			}, // end of method onClick
		}).placeAt(parentWidget/*this._widgets.menuBar*/);

		// register the menu item widget locally
		this._widgets[this.menuBarItem_prepend+menuItem.mB_itemKind_UUID] = mIWidget;
		
		// execute the assigned command by default?
		if (menuItem.openByDefault) mIWidget.onClick();
		
	} // end of method _createMenuItem
	,
	
	// methods that are chained to events ---------------------------------------------------------
	
	// settings of dijit.layout.BorderContainer ---------------------------------------------------
	'gutters'	: false,	
	'closable'	: true,
});
