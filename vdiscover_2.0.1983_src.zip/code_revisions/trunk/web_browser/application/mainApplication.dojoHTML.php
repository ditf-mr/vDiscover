<?php if (!defined('APPLICATION_started')) {header('Location: .');exit;}
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

//global $repository_config;
global $r, $backend;

?>
 
<div id="application_sendingToPrintQueuePane" style="display:none;">
	<p>&nbsp;</p>
	<p>&nbsp;</p>
	<p>&nbsp;</p>
	<img style="vertical-align:middle;" src="third_party_libraries/open-icon-library-standard-0.10/icons/png/128x128/devices/gnome-dev-printer-new.png" />
	<p>&nbsp;</p>
	<p>&nbsp;</p>
	<p style="text-align:center;">
	<?php echo T('mainApp.dojoHTML.php/AddContTiPrntQu_TXT', 'Adding content to print queue &hellip;'); ?>
	</p>
</div>

<div dojoType="dijit.layout.BorderContainer" id="masterBc">

	<!-- begin left region -->
	<div dojoType="dijit.layout.BorderContainer" region="left" id="leftSide" splitter="true" design="sidebar" gutters="true" liveSplitters="false" persist="true" minSize="150" maxSize="350">
		<div dojoType="dijit.layout.BorderContainer" region="top" style="height:<?php echo $r->get_configOption('appTitle_height', '150px') ?>;">
			<!-- container for application title -->
			<!-- <div dojoType="dijit.layout.ContentPane" id="app_titlePane" region="center" href="?v=application_title"></div> -->
			<div dojoType="dijit.layout.ContentPane" id="app_titlePane"  region="center"></div>

			<!-- container for the global menu with logout, settings, etc. -->			
			<div dojoType="dijit.MenuBar" id="navMenu" region="bottom">
				<div dojoType="dijit.MenuBarItem" style="float:right;" class="RS_MenuBarItem_withIcon RS_icon_ExitApplication"
				 onclick="application.generalOptions.logout();" title="<?php echo T('mainApp.dojoHTML.php/LogOut_TTP', 'Log out'); ?>">
					<span><!--Log out--></span>
				</div>
				
				<div id="navMenu.switchToFullScreen" dojoType="dijit.MenuBarItem" style="float:right;" class="RS_MenuBarItem_withIcon RS_icon_enterFullScreen"
				 onclick="application.generalOptions.requestFullScreen();" title="<?php echo T('mainApp.dojoHTML.php/SwToFullScreen_TTP', 'Switch to full screen mode'); ?>">
					<span><!--Switch to Full Screen --></span>
				</div>
				
				<div id="navMenu.cancelFullScreen" dojoType="dijit.MenuBarItem" style="float:right;display:none;" class="RS_MenuBarItem_withIcon RS_icon_cancelFullScreen"
				 onclick="application.generalOptions.cancelFullScreen();" title="<?php echo T('mainApp.dojoHTML.php/CancelFullScrMode_TTP', 'Cancel full screen mode'); ?>">
					<span><!--Cancel Fullscreen --></span>
				</div>
				
				<div id="navMenu.changeUserSettings" dojoType="dijit.MenuBarItem" style="float:right;" class="RS_MenuBarItem_withIcon RS_icon_User"
				 onclick="application.userSettings.showDialog();" title="<?php echo T('mainApp.dojoHTML.php/UserSettings_TTP', 'User Settings'); ?>">
					<span><!--User settings --></span>
				</div>
				
				<!--<div dojoType="dijit.PopupMenuBarItem" disabled="true" class="RS_icon_Preferences RS_MenuBarItem_withIcon" style="float:right;" title="<?php echo T('mainApp.dojoHTML.php/Settings_TTP', 'Settings'); ?>">
						<span></span>
						<div dojoType="dijit.Menu" id="manualsMenu">
							<div dojoType="dijit.MenuItem" onClick="alert('Change password')" disabled="true">
								<?php echo T('mainApp.dojoHTML.php/ChPasswd_TXT', 'Change password'); ?> 								
							</div>
							<div dojoType="dijit.MenuItem" onClick="applications.generalOptions.aboutMe();" disabled="true">
								<?php echo T('mainApp.dojoHTML.php/Facts_TXT', 'Facts about me'); ?>								
							</div>
							<div dojoType="dijit.MenuItem" onClick="alert('Application Programmer\'s Interface');" disabled="true">
								<?php echo T('mainApp.dojoHTML.php/AppDesignStyle_TXT', 'Application design style'); ?>								
							</div>
						</div>
				</div>-->			
				<div dojoType="dijit.MenuBarItem" disabled="false" class="RS_icon_Manual RS_MenuBarItem_withIcon"
					onclick="application.generalOptions.userManual();" title="<?php echo T('mainApp.dojoHTML.php/Manual_TTP', 'Manual');?>">
					<span><!--User -->
						<?php echo T('mainApp.dojoHTML.php/Manual_TTP', 'Manual'); ?>
					</span>
				</div>
				<div dojoType="dijit.MenuBarItem" disabled="false" 
					class="RS_icon_Printer RS_MenuBarItem_withIcon" title="<?php echo T('mainApp.dojoHTML.php/PQ_ShowDocsForPrinting_TTP', 'Print Queue - Show the documents that are pending for printing');?>"
					onclick="application.printPreviewPane.show();">
					<span><!--Print Queue--></span>
				</div>
			</div>

		</div>	
		
		<!-- Accordion container with navigation starting points -->
		<div dojoType="dijit.layout.AccordionContainer" region="center">
		
			<!-- Information object type tree for normal users -->
			<div dojoType="dijit.layout.AccordionPane" 
				onShow="application.OT.initialise_navigationTree();" 
				title="<?php echo T('mainApp.dojoHTML.php/IWantToNavTo_TAB', 'I want to navigate to ...'); ?>" selected="true" refreshOnShow="true"
				style="padding:0;">
				<div dojoType="dijit.layout.BorderContainer" gutters="false">
					<div dojoType="dijit.layout.ContentPane" region="top">
						<div dojoType="dijit.form.Form" encType="multipart/form-data" 
							id="application.navigationPane.searchForm" 
							onSubmit='application.OT.findInfObjs(this.get("value").searchTerm);return false;'>
							<div dojoType="dijit.Tooltip" connectId="application.navigationPane.searchForm" position="above">
								<p>
									<?php echo T('mainApp.dojoHTML.php/UseWildCardsTo_TXT', 'Use the wildcards <code>*</code> and <code>?</code> to improve your search results:'); ?>								
								</p>
								<ul>
									<li>
										<?php echo T('mainApp.dojoHTML.php/SearchTip_HTM', 
												'<code>*</code> finds any char sequence, 
												e.g.<br/>&laquo;<code>black*</code>&raquo; finds <code>black<i>bear</i></code>,
												<code>black<i>bird</i></code> and just <code>black</code>.'); 
										?>										
									</li>
									<li>
										<?php echo T('mainApp.dojoHTML.php/SearchTip2_HTM', 
												'<code>?</code> finds any char, 
												e.g.<br/>&laquo;<code>bl?ck</code>&raquo; finds <code>bl<i>o</i>ck</code> and 
												<code>bl<i>a</i>ck</code>.'); 
										?>										
									</li>
								</ul>
							</div>
							<div dojoType="dijit.form.Button" style="float:right;" type="submit">
								<span class="dijitMenuItem RS_icon_Find RS_MenuBarItem_withIcon">
									<?php echo T('BTN_Find!', 'Find!'); ?>
								</span>
							</div>
							<div dojoType="dijit.form.TextBox" selectOnClick="true" trim="true" 
								id="application.navigationPane.searchTextBox"
								placeHolder="<?php echo T('mainApp.dojoHTML.php/SearchTerm_TXT', 'search term'); ?>"
								value="" 
								style="display: inline-block;margin-left: 0.5ex;margin-top: 1ex;width: 25ex;" 
								name="searchTerm"></div>
						</div>
					</div>
					<div id="application.navigationPane" dojoType="dijit.layout.ContentPane" region="center">
					
					</div>
				</div><!-- end BorderContainer -->
			</div><!-- end AccordionPane -->

			<!-- The user's tasks ... -->
			<!--<div dojoType="dijit.layout.AccordionPane" title="My tasks ..."></div>-->
			
			<!-- The user's list of read information objects -->
			<div dojoType="dijit.layout.AccordionPane" id="application.historyPane" title="<?php echo T('mainApp.dojoHTML.php/IHaveSeen_TAB', 'I have seen ...'); ?>">
			</div>
			
<?php
if ($backend->isAdmin()){
?>
			<!-- The administration pane -->
			<div 
				dojoType="dijit.layout.AccordionPane" title="<?php echo T('mainApp.dojoHTML.php/Admin_TAB', 'Administration ...'); ?>" class="application_adminPane" 
				onShow="application.admin.initialise_adminPane();" style="padding:0;">
					<div dojoType="dijit.layout.BorderContainer" gutters="false" style="margin:0;padding:0;">
						<div dojoType="dijit.layout.ContentPane" region="top">
							<div dojoType="dijit.MenuBar" style="border-top:0;border-left:0;border-right:0;background-color:transparent;">

							</div>
							<img id="application.admin.image" src="./third_party_libraries/open-icon-library-standard-0.10/icons/png/64x64/emotes/face-devilish-2.png" align="right" style="padding:.25ex;"/>
							<div dojoType="dijit.Tooltip" connectId="application.admin.image">
								<div style="max-width: 30em;">
									<blockquote>
										<p>A computer lets you make more mistakes faster than any invention in human history &mdash; with the possible exceptions of handguns and tequila.</p>
										<p class="textRight">Mitch Ratcliffe</p>
									</blockquote>
								</div>
							</div>
							<h2>
								<?php echo T('mainApp.dojoHTML.php/KlAndInfMdl_TXT', 'Information Schema'); ?>							
							</h2>
							<p>&nbsp;</p>
						</div>
						<div dojoType="dijit.layout.ContentPane" region="center" id="application.adminPane">
							<div id="OT_admin_tree"></div>
						</div>
					</div>
			</div>

<?php
} // end of if is admin
?>
			
		</div>
	</div><!-- end left region / repository list -->

	<!-- Object Type Tab Container -->
	<div dojoType="dijit.layout.TabContainer" region="center" id="OT_tab_container" jsId="OT_tab_container">
		<div dojoType="dijit.layout.ContentPane" 
			title="<?php echo $r->get_configOption('welcomePage_title', T('mainApp.dojoHTML.php/Welcome_TIT','Welcome')); ?>" 
			closable="true" id="welcome" 
			href="<?php echo $r->get_configOption('welcomePage_URL', '?v=welcome_tab'); ?>" 
		></div>
        </div> <!-- end OT_tab_container -->

	<!-- This is the first right-click menu of RS II -->
	<div id="mainRightClickMenu" dojoType="dijit.Menu" targetNodeIds="masterBc" style="display: none;">
		<div dojoType="dijit.MenuItem" iconClass="RS_icon_Printer RS_menuItem_withIcon" onClick="application.printPreviewPane.show();"><?php echo T('mainApp.dojoHTML.php/PrintQueue_TTP', 'Print Queue'); ?></div>
		<div dojoType="dijit.MenuItem" iconClass="RS_menuItem_withIcon" onClick="application.generalOptions.aboutMe();"><?php echo T('mainApp.dojoHTML.php/Facts_TXT', 'Facts about me'); ?></div>
		
		<div id="mainRightClickMenu.requestFullScreen" dojoType="dijit.MenuItem" iconClass="RS_menuItem_withIcon RS_icon_enterFullScreen" onClick="application.generalOptions.requestFullScreen();"><?php echo T('mainApp.dojoHTML.php/SwToFullScreen_TTP', 'Switch to full screen mode'); ?></div>
		<div id="mainRightClickMenu.cancelFullScreen" dojoType="dijit.MenuItem" iconClass="RS_icon_cancelFullScreen RS_menuItem_withIcon" onClick="application.generalOptions.cancelFullScreen();"><?php echo T('mainApp.dojoHTML.php/CancelFullScrMode_TTP', 'Cancel full screen mode'); ?></div>
		
		<div dojoType="dijit.MenuItem" iconClass="RS_icon_ExitApplication RS_menuItem_withIcon" onClick="application.generalOptions.logout();"><?php echo T('mainApp.dojoHTML.php/LogOut_TTP', 'Log out'); ?></div>
	</div>
		
</div> <!-- end main application -->

<!-- the print preview pane-->
<div id="application_printPreviewPane" style="display:none;" dojoType="dijit.layout.BorderContainer" gutters="false">
	<div dojoType="dijit.MenuBar" region="top" id="application_printPreviewPane_menuBar">
		<div dojoType="dijit.MenuBarItem" style="float:right;" class="RS_icon_returnToMainApplication RS_MenuBarItem_withIcon"
			onclick="application.printPreviewPane.hide();">
			<span class="strong"><?php echo T('mainApp.dojoHTML.php/BackToMainApp_TXT', 'Back to the main application'); ?></span>
		</div>
		<div dojoType="dijit.MenuBarItem" style="" class="RS_icon_SendToPrinter RS_MenuBarItem_withIcon" 
			onclick="window.print();">
			<span><?php echo T('mainApp.dojoHTML.php/SendDocToPrinter_TXT', 'Send Documents to Printer'); ?></span>
		</div>
		<div dojoType="dijit.MenuBarItem" style="" class="RS_icon_Cancel RS_MenuBarItem_withIcon"
			onclick="application.printPreviewPane.emptyPrintQueue();">
			<span><?php echo T('mainApp.dojoHTML.php/EmptyPQueue_TXT', 'Empty Print Queue'); ?></span>
		</div>
	</div>
	<div dojoType="dijit.layout.ContentPane" region="center" id="application_printPreviewPane_documentPane">
	</div>
	
	<div dojoType="dijit.Menu" id="pPPaneRightClickMenu" targetNodeIds="application_printPreviewPane" style="display: none;">
		<div dojoType="dijit.MenuItem" iconClass="RS_menuItem_withIcon RS_icon_returnToMainApplication" onClick="application.printPreviewPane.hide();"><?php echo T('mainApp.dojoHTML.php/BackToMainApp_TXT', 'Back to the main application'); ?></div>
		<div dojoType="dijit.MenuItem" iconClass="RS_menuItem_withIcon RS_icon_SendToPrinter" onClick="window.print();"><?php echo T('mainApp.dojoHTML.php/SendDocToPrinter_TXT', 'Send Documents to Printer'); ?></div>
		<div dojoType="dijit.MenuItem" iconClass="RS_menuItem_withIcon RS_icon_Cancel" onClick="application.printPreviewPane.emptyPrintQueue();"><?php echo T('mainApp.dojoHTML.php/EmptyPQueue_TXT', 'Empty Print Queue'); ?></div>
		
		<div id="pPPaneRightClickMenu.requestFullScreen" dojoType="dijit.MenuItem" iconClass="RS_menuItem_withIcon RS_icon_enterFullScreen" onClick="application.generalOptions.requestFullScreen();"><?php echo T('mainApp.dojoHTML.php/SwToFullScreen_TTP', 'Switch to full screen mode'); ?></div>
		<div id="pPPaneRightClickMenu.cancelFullScreen" dojoType="dijit.MenuItem" iconClass="RS_icon_cancelFullScreen RS_menuItem_withIcon" onClick="application.generalOptions.cancelFullScreen();"><?php echo T('mainApp.dojoHTML.php/CancelFullScrMode_TTP', 'Cancel full screen mode'); ?></div>
		
		<div dojoType="dijit.MenuItem" iconClass="RS_icon_ExitApplication RS_menuItem_withIcon" onClick="application.generalOptions.logout();"><?php echo T('mainApp.dojoHTML.php/LogOut_TTP', 'Log out'); ?></div>
		
	</div>

</div>
