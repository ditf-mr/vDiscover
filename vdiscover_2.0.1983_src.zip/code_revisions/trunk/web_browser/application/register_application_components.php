<?php if (!defined('APPLICATION_started')) {header('Location: .');exit;} 
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// this file registers all application components

{// register application-specific CSS

// the following CSS needs to be included here, directly, to assure that the application displays, properly.
{$r->register_cssContent( '
	body , html, #masterBc, .fullWidthHeight {
		width:100%; height:100%;
	}
	
@media screen {	
	#leftSide {
		width:275px;
	}
		
	.dijitContentPaneLoading {
		width:100%; height:100%;
		margin:0; padding:2em;;
		text-align:center;
		vertical-align:middle;
		background:#fff	
			url(third_party_libraries/'.DOJO_TOOLKIT_path.'/dojox/widget/Standby/images/loading.gif)
			no-repeat center center;
		position:absolute;
		z-index:999;
	}
	
	.RS_viewPane_reloading {

		height: 10em;
		text-align:center;
		padding-top: 1.5em;
		color:slategray;
		background:#fff	
			url(./third_party_libraries/'.DOJO_TOOLKIT_path.'/dojox/widget/Standby/images/loading.gif)
			no-repeat center center;
	}
	
	.RS_attribute_highlight {
		background-color: paleturquoise !important;
		/*padding: .125em .25em !important;
		border-radius: .33em;*/
	}

	.RS_highlight_menuBarMarker {
		border-radius: 1em 1em 1em 1em;
		display: inline-block;
		height: 0.75em;
		vertical-align: middle;
		width: 1.25em;	
		border-top-left-radius: 2em;
		border-bottom-right-radius: 2em;
		margin-right:.5em;
	}
	
	.RS_varGroup {
		border-radius: 0.5em;
		display: inline-block;
		padding: 0.125em !important;
		vertical-align: middle;	
	}
	
	.RS_iconButton {
		background-position: center 2px;
		background-repeat: no-repeat;
		cursor: pointer;
		display: inline-block;
		height: 16px;
		vertical-align: top;
		width: 16px;
	}
}

');}

//this file needs a clean-up, because it contains a lot of styles with very different uses
$r->register_cssFile('application/application_formatting.css');

$r->register_cssFile('application/application_printPreview_Formatting.css');
} // end register application-specific CSS

{// register the application components
$r->register_JavaScriptFile('application/dojo_loader.js');
$r->register_mainHTMLFile('application/mainApplication.dojoHTML.php');
$r->register_JavaScriptFile('application/application.js');
$r->register_JavaScriptFile('application/general_functionality.js');
$r->register_JavaScriptFile('application/application.widgets.printableDocument.js');
$r->register_JavaScriptFile('application/application.widgets.internalLink.js');

// these registrations are necessary because dojo.require does not work satisfingly
$r->register_JavaScriptFile('common/special_dijit_classes/common.widgets.fixedSizeDialog.js');
$r->register_JavaScriptFile('common/special_dijit_classes/common.widgets.HTMLEditor.js');

// Register the application components
cApplicationRegistry::registerModuleComponents(array(
		// components in these modules will be included in the given order
		'attributes',
		'views',
		'corporate_identity_panes',
		'dialogs_for_normal_users',
		'find',
		'O',
		'OT',
		'user_manual',
		'admin',
	), __DIR__ );
} // end register the application components

{// DIJIT EDITOR needs lots of CSS 
$p='third_party_libraries/'.DOJO_TOOLKIT_path.'/dojox/editor/plugins/resources/css/';
$r->register_cssFile($p.'Preview.css');
$r->register_cssFile($p.'PageBreak.css');
$r->register_cssFile($p.'ShowBlockNodes.css');
$r->register_cssFile($p.'InsertEntity.css');
$r->register_cssFile($p.'Breadcrumb.css');
$r->register_cssFile($p.'Smiley.css');
$r->register_cssFile($p.'CollapsibleToolbar.css');
$r->register_cssFile($p.'Blockquote.css');
$r->register_cssFile($p.'PasteFromWord.css');
$r->register_cssFile($p.'FindReplace.css');
$r->register_cssFile('third_party_libraries/'.DOJO_TOOLKIT_path.'/dojox/editor/plugins/resources/editorPlugins.css');
// set the configuration options -- these are accessible later in application.configuration.global
$r->set_configOption('editor_normalStylesheet', 'media/master_stylesheet.css');
$r->set_configOption('editor_editingAreaStylesheet', 'application/application_editor_formatting.css');
} // end registration of DIJIT EDITOR CSS

{// plugins for DIJIT EDITOR 
$r->register_JavaScriptFile('application/variableListPlugin.js');
}// end registration of plugins for DIJIT EDITOR


$r->register_JavaScriptFile		('application/setTitle.js', PLUGIN_REGISTRY_loadFinally);

?>