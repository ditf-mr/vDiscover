<?php 
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

//if (!defined('APPLICATION_started')) {header('Location: .');exit;}

?>
<div style="font-weight: bold; text-align:center;line-height:250%;">
	<nobr>vDiscover 2.<?php echo $repository_config['subversion_revision']; ?></nobr>
	<nobr>&laquo;<?php echo $repository_config['repository_name']; ?>&raquo;</nobr>
</div>
