<?php 
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

if (!defined('APPLICATION_started')) {header('Location: .');exit;}

?>
<div class="output_DIN_A4">
<h1>Welcome to <?php echo $repository_config['application_title_HTML']; ?>!</h1>

<h2>Attention developers!</h2>
<p>Please read:<p>
<ol>
	<li><a href="http://dojotoolkit.org/reference-guide/releasenotes/1.5.html">DOJO Toolkit 1.5 release notes</a></li>
	<li><a href="http://dojotoolkit.org/reference-guide/releasenotes/1.6.html#releasenotes-1-6">DOJO Toolkit 1.6 release notes</a></li>	
</ol>

<h2>Overview + Basic hints</h2>
<table class="floatLeft grid noBorders" style="max-width: 8cm;">
	<thead>
		<tr>
			<th>1. Spalte</th>
			<th>Aliquam pretium orci id nisi.</th>
			<th>3. Spalte</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td>1. Spalte</td>
			<td>2. Spalte</td>
			<td>Aliquam pretium orci id nisi.</td>
		</tr>
		<tr>
			<td>1. Spalte</td>
			<td>2. Spalte</td>
			<td>Aliquam pretium orci id nisi.</td>
		</tr>
		<tr>
			<td>Aliquam pretium orci id nisi.</td>
			<td>2. Spalte</td>
			<td>3. Spalte</td>
		</tr>
	</tbody>
	<caption>A table with class="floatLeft grid noBorders"</caption>
</table>
<p>
	Lorem ipsum dolor sit amet, consectetuer
	adipiscing elit. H<sub>2</sub>O CH<sub>4</sub> C<sub>6</sub>H<sub>12</sub>O<sub>6</sub> Nam facilisis enim. Pellentesque
	in elit et lacus euismod dignissim. ax<sup>2</sup>+bx+c-y=0 Aliquam
	dolor pede, convallis eget, dictum a, blandit
	ac, urna. Pellentesque sed nunc ut justo
	volutpat egestas. Class aptent taciti sociosqu
	ad litora torquent per conubia nostra, per
	inceptos hymenaeos. In erat. Suspendisse
	potenti. Fusce faucibus nibh sed nisi. Phasellus
	faucibus, dui a cursus dapibus, mauris nulla
	euismod velit, a <q>lobortis</q> turpis arcu vel dui.
	Pellentesque fermentum ultrices pede. Donec
	auctor lectus eu arcu. Curabitur non orci eget
	est porta gravida. Aliquam pretium orci id nisi.
	Duis faucibus, mi non adipiscing venenatis, erat
	urna aliquet elit, eu fringilla lacus tellus quis
	erat. Nam tempus ornare lorem. Nullam feugiat.
</p>
<blockquote>The quick brown fox jumps over the lazy dog. 
	The quick brown fox jumps over the lazy dog. 
	The quick brown fox jumps over the lazy dog. 
	The quick brown fox jumps over the lazy dog. 
	The quick brown fox jumps over the lazy dog. 
	The quick brown fox jumps over the lazy dog. 
	The quick brown fox jumps over the lazy dog.</blockquote>
<p>
	Lorem ipsum dolor sit amet, consectetuer
	adipiscing elit. Nam facilisis enim. Pellentesque
	in elit et lacus euismod dignissim. Aliquam
	dolor pede, convallis eget, dictum a, blandit
	ac, urna. Pellentesque sed nunc ut justo
	volutpat egestas. Class aptent taciti sociosqu
	ad litora torquent per conubia nostra, per
	inceptos hymenaeos. In erat. Suspendisse
	potenti. Fusce faucibus nibh sed nisi. Phasellus
	faucibus, dui a cursus dapibus, mauris nulla
	euismod velit, a lobortis turpis arcu vel dui.
	Pellentesque fermentum ultrices pede. Donec
	auctor lectus eu arcu. Curabitur non orci eget
	est porta gravida. Aliquam pretium orci id nisi.
	Duis faucibus, mi non adipiscing venenatis, erat
	urna aliquet elit, eu fringilla lacus tellus quis
	erat. Nam tempus ornare lorem. Nullam feugiat.
</p>
<table class="floatLeft listWithAlternatingRowColour" style="max-width: 8cm;">
	<thead>
		<tr>
			<th>1. Spalte</th>
			<th>Aliquam pretium orci id nisi.</th>
			<th>3. Spalte</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td>1. Spalte</td>
			<td>2. Spalte</td>
			<td>Aliquam pretium orci id nisi.</td>
		</tr>
		<tr>
			<td>1. Spalte</td>
			<td>2. Spalte</td>
			<td>Aliquam pretium orci id nisi.</td>
		</tr>
		<tr>
			<td>Aliquam pretium orci id nisi.</td>
			<td>2. Spalte</td>
			<td>3. Spalte</td>
		</tr>
	</tbody>
	<caption>A table with class="floatLeft listWithAlternatingRowColour"</caption>
</table>
<p>
	Lorem ipsum dolor sit amet, consectetuer
	adipiscing elit. Nam facilisis enim. Pellentesque
	in elit et lacus euismod dignissim. Aliquam
	dolor pede, convallis eget, dictum a, blandit
	ac, urna. Pellentesque sed nunc ut justo
	volutpat egestas. Class aptent taciti sociosqu
	ad litora torquent per conubia nostra, per
	inceptos hymenaeos. In erat. Suspendisse
	potenti. Fusce faucibus nibh sed nisi.
</p>
<p>
	Lorem ipsum dolor sit amet, consectetuer
	adipiscing elit. Nam facilisis enim. Pellentesque
	in elit et lacus euismod dignissim. Aliquam
	dolor pede, convallis eget, dictum a, blandit
	ac, urna. Pellentesque sed nunc ut justo
	volutpat egestas. <strong>STRONG Class aptent taciti sociosqu
	ad litora torquent per conubia </strong> nostra, per
	inceptos hymenaeos. In erat. Suspendisse
	potenti. <ins>Fusce faucibus nibh sed nisi. Phasellus
	faucibus, dui</ins> <del>a cursus dapibus, mauris nulla
	euismod velit, a lobortis</del> turpis arcu vel dui.
	Pellentesque fermentum ultrices pede. Donec
	auctor lectus eu arcu. Curabitur non orci eget
	est porta gravida. <code>AB3240</code> Aliquam pretium orci id nisi.
	Duis faucibus, mi non adipiscing venenatis, erat
	urna aliquet elit, eu fringilla lacus tellus quis
	erat. Nam tempus ornare lorem. Nullam feugiat.
</p>
<p>
	Lorem ipsum dolor sit amet, consectetuer
	adipiscing elit. Nam facilisis enim. Pellentesque
	in elit et lacus euismod dignissim. Aliquam
	dolor pede, convallis eget, dictum a, blandit
	ac, urna. Pellentesque sed nunc ut justo
	volutpat egestas. Class aptent taciti sociosqu
	ad litora torquent per conubia nostra, per
	inceptos hymenaeos. In erat. Suspendisse
	potenti. Fusce faucibus nibh sed nisi.
</p>
<ul>
	<li>first list item</li>
	<li>second list item and SUBLIST
		<ul>
			<li>first list item</li>
			<li>second list item</li>
			<li>third list item</li>
		</ul>	
		<ol>
			<li>first list item</li>
			<li>second list item
				<dl>
					<dd>first ddst item</dd>
					<dd>second ddst item</dd>
					<dd>third ddst item</dd>
				</dl>	
			</li>
			<li>third list item</li>
		</ol>	
	</li>
	<li>third list item</li>
</ul>
<ol>
	<li>first list item</li>
	<li>second list item
		<dl>
			<dd>first ddst item</dd>
			<dd>second ddst item</dd>
			<dd>third ddst item</dd>
		</dl>	
	</li>
	<li>third list item</li>
</ol>	
<dl>
	<dd>first ddst item</dd>
	<dd>second ddst item</dd>
	<dd>third ddst item</dd>
</dl>	
<p>
	Lorem ipsum dolor sit amet, consectetuer
	adipiscing elit. Nam facilisis enim. Pellentesque
	in elit et lacus euismod dignissim. Aliquam
	dolor pede, convallis eget, dictum a, blandit
	ac, urna. Pellentesque sed nunc ut justo
	volutpat egestas. <strong>STRONG Class aptent taciti sociosqu
	ad litora torquent per conubia </strong> nostra, per
	inceptos hymenaeos. In erat.
</p>
<pre>
//detect what to do
switch(sanitize_string($_POST, 'task')) { // decide what to do
	case 'delete OT':
		throw new Exception('Task not implemented, yet. Passed parameters: '.json_encode($_POST));
		#$backend->getType($UUID)->delete();
		break;
	case 'change OT name':
		$newName=sanitize_string($_POST, 'newName');
</pre>
<h3>Heading 3</h3>
<h4>Heading 4</h4>
<p>
	Lorem ipsum dolor sit amet, consectetuer
	adipiscing elit. Nam facilisis enim. Pellentesque
	in elit et lacus euismod dignissim. Aliquam
	dolor pede, convallis eget, dictum a, blandit
	ac, urna. Pellentesque sed nunc ut justo
	volutpat egestas. Class aptent taciti sociosqu
	ad litora torquent per conubia nostra, per
	inceptos hymenaeos. <a href="http://www.dojo-toolkit.org/">In erat.</a> Suspendisse
	potenti. Fusce faucibus nibh sed nisi. Phasellus
	faucibus, dui a cursus dapibus, mauris nulla
	euismod velit, a lobortis turpis arcu vel dui.
	Pellentesque fermentum ultrices pede. Donec
	auctor lectus eu arcu. Curabitur non orci eget
	est porta gravida. Aliquam pretium orci id nisi.
	Duis faucibus, mi non adipiscing venenatis, erat
	urna aliquet elit, eu fringilla lacus tellus quis
	erat. Nam tempus ornare lorem. Nullam feugiat.
</p>
<table>
	<caption>The table caption.</caption>
	<thead>
		<tr>
			<th>1. Spalte</th>
			<th>2. Spalte</th>
			<th>3. Spalte</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td>1. Spalte</td>
			<td>2. Spalte</td>
			<td>3. Spalte</td>
		</tr>
		<tr>
			<td>1. Spalte</td>
			<td>2. Spalte</td>
			<td>3. Spalte</td>
		</tr>
		<tr>
			<td>1. Spalte</td>
			<td>2. Spalte</td>
			<td>3. Spalte</td>
		</tr>
	</tbody>
</table>
<table  class="floatRight">
	<caption>The 2<sup>nd</sup> table.</caption>
	<thead>
		<tr>
			<th>1. Spalte</th>
			<th>2. Spalte</th>
			<th>3. Spalte</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<th>1. Spalte</th>
			<td>2. Spalte</td>
			<td>3. Spalte</td>
		</tr>
		<tr>
			<th>1. Spalte</th>
			<td>2. Spalte</td>
			<td>3. Spalte</td>
		</tr>
		<tr>
			<th>1. Spalte</th>
			<td>2. Spalte</td>
			<td>3. Spalte</td>
		</tr>
	</tbody>
</table>
<p>
	Lorem ipsum dolor sit amet, consectetuer
	adipiscing elit. H<sub>2</sub>O CH<sub>4</sub> C<sub>6</sub>H<sub>12</sub>O<sub>6</sub> Nam facilisis enim. Pellentesque
	in elit et lacus euismod dignissim. ax<sup>2</sup>+bx+c-y=0 Aliquam
	dolor pede, convallis eget, dictum a, blandit
	ac, urna. Pellentesque sed nunc ut justo
	volutpat egestas. Class aptent taciti sociosqu
	ad litora torquent per conubia nostra, per
	inceptos hymenaeos. In erat. Suspendisse
	potenti. Fusce faucibus nibh sed nisi. Phasellus
	faucibus, dui a cursus dapibus, mauris nulla
	euismod velit, a <q>lobortis</q> turpis arcu vel dui.
	Pellentesque fermentum ultrices pede. Donec
	auctor lectus eu arcu. Curabitur non orci eget
	est porta gravida. Aliquam pretium orci id nisi.
	Duis faucibus, mi non adipiscing venenatis, erat
	urna aliquet elit, eu fringilla lacus tellus quis
	erat. Nam tempus ornare lorem. Nullam feugiat.
</p>
<blockquote>The quick brown fox jumps over the lazy dog.</blockquote>
<p>
	Lorem ipsum dolor sit amet, consectetuer
	adipiscing elit. Nam facilisis enim. Pellentesque
	in elit et lacus euismod dignissim. Aliquam
	dolor pede, convallis eget, dictum a, blandit
	ac, urna. Pellentesque sed nunc ut justo
	volutpat egestas. Class aptent taciti sociosqu
	ad litora torquent per conubia nostra, per
	inceptos hymenaeos. In erat. Suspendisse
	potenti. Fusce faucibus nibh sed nisi. Phasellus
	faucibus, dui a cursus dapibus, mauris nulla
	euismod velit, a lobortis turpis arcu vel dui.
	Pellentesque fermentum ultrices pede. Donec
	auctor lectus eu arcu. Curabitur non orci eget
	est porta gravida. Aliquam pretium orci id nisi.
	Duis faucibus, mi non adipiscing venenatis, erat
	urna aliquet elit, eu fringilla lacus tellus quis
	erat. Nam tempus ornare lorem. Nullam feugiat.
</p>
<blockquote>The quick brown fox jumps over the lazy dog. 
	The quick brown fox jumps over the lazy dog. 
	The quick brown fox jumps over the lazy dog. 
	The quick brown fox jumps over the lazy dog. 
	The quick brown fox jumps over the lazy dog. 
	The quick brown fox jumps over the lazy dog. 
	The quick brown fox jumps over the lazy dog.</blockquote>
<p>
	Lorem ipsum dolor sit amet, consectetuer
	adipiscing elit. Nam facilisis enim. Pellentesque
	in elit et lacus euismod dignissim. Aliquam
	dolor pede, convallis eget, dictum a, blandit
	ac, urna. Pellentesque sed nunc ut justo
	volutpat egestas. Class aptent taciti sociosqu
	ad litora torquent per conubia nostra, per
	inceptos hymenaeos. In erat. Suspendisse
	potenti. Fusce faucibus nibh sed nisi. Phasellus
	faucibus, dui a cursus dapibus, mauris nulla
	euismod velit, a lobortis turpis arcu vel dui.
	Pellentesque fermentum ultrices pede. Donec
	auctor lectus eu arcu. Curabitur non orci eget
	est porta gravida. Aliquam pretium orci id nisi.
	Duis faucibus, mi non adipiscing venenatis, erat
	urna aliquet elit, eu fringilla lacus tellus quis
	erat. Nam tempus ornare lorem. Nullam feugiat.
</p>
<hr />
<p> This paragraph has an additional indentation.
	Lorem ipsum dolor sit amet, consectetuer
	adipiscing elit. Nam facilisis enim. Pellentesque
	in elit et lacus euismod dignissim. Aliquam
	dolor pede, convallis eget, dictum a, blandit
	ac, urna. Pellentesque sed nunc ut justo
	volutpat egestas. Class aptent taciti sociosqu
	ad litora torquent per conubia nostra, per
	inceptos hymenaeos. In erat. Suspendisse
	potenti. Fusce faucibus nibh sed nisi. Phasellus
	faucibus, dui a cursus dapibus, mauris nulla
	euismod velit, a lobortis turpis arcu vel dui.
	Pellentesque fermentum ultrices pede. Donec
	auctor lectus eu arcu. Curabitur non orci eget
	est porta gravida. Aliquam pretium orci id nisi.
	Duis faucibus, mi non adipiscing venenatis, erat
	urna aliquet elit, eu fringilla lacus tellus quis
	erat. Nam tempus ornare lorem. Nullam feugiat.
</p>
<p>...</p>
</div>