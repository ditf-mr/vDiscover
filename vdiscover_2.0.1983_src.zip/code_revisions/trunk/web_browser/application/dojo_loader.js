var djConfig = {
	// isDebug: true,
	// debugAtAllCosts: true,
        // parseOnLoad: true,
        // By default, dojo determines the locale of the application by pulling the locale from the browser navigator object.
        // locale: 'en-gb'
};

/* ----------------------------------------------------- */

// the following modules are application-specific
/*
dojo.registerModulePath(	"common.widgets.fixedSizeDialog", 
								"../../../common/special_dijit_classes/application.widgets.fixedSizeDialog" );
dojo.registerModulePath(	"common.widgets.HTMLEditor", 
								"../../../common/special_dijit_classes/common.widgets.HTMLEditor" );
								
// dojo.registerModulePath(	"application.widgets.manageViews_viewEditor_template", 
								// "../../../application/views/application.widgets.manageViews_viewEditor_template" );

dojo.registerModulePath(	"application.attributeKinds", 
								"../../../application/attributes/application.attributeKinds" );
dojo.registerModulePath(	"application.widgets.attributes.relationValueTupleView", 
								"../../../application/attributes/cRelationAttribute/relationValueTupleView" );
dojo.registerModulePath(	"application.widgets.genericAttribute", 
								"../../../application/attributes/generalAttributeClasses" );
*/
(function(){ // register the module paths for the attributes
	var attrKinds =[
		'cSingleLineAttribute',
		'cDateTimeAttribute',
		'cFileAttribute',
		'cFuzzyAttribute',
		'cKeyValuePairAttribute',
		'cMaintenanceInfoAttribute',
		'cNumberAttribute',
		'cOTInfoAttribute',
		'cPasswordAttribute',
		'cRelationAttribute',
		'cCounterAttribute',
		'cMeasurementResultAttribute',
		'cMultiLineAttribute',
		'cValueRangeAttribute',
	];
	dojo.forEach(attrKinds,function(k){
		dojo.registerModulePath(	"application.widgets."+k, "../../../application/attributes/"+k+"/"+k );
	}); // end dojo forEach
})();
								
/* ----------------------------------------------------- */

// the following dojo components are necessary, in general

dojo.require('dijit.Declaration');
dojo.require('dijit.Dialog');
dojo.require('dijit.form.Form');
dojo.require('dijit.form.Button');
dojo.require('dijit.form.CheckBox');
dojo.require('dijit.form.ComboButton');
dojo.require('dijit.form.DateTextBox');
dojo.require('dijit.form.FilteringSelect');
dojo.require('dijit.form.MultiSelect');
dojo.require('dijit.form.NumberTextBox');
dojo.require('dijit.form.NumberSpinner');
dojo.require('dijit.form.RadioButton');
dojo.require('dijit.form.Select');
dojo.require('dijit.form.TextBox');
dojo.require('dijit.form.Textarea');
dojo.require('dijit.form.TimeTextBox');
dojo.require('dijit.form.ValidationTextBox');
dojo.require('dijit.layout.AccordionContainer');
dojo.require('dijit.layout.AccordionPane');
dojo.require('dijit.layout.BorderContainer');
dojo.require('dijit.layout.ContentPane');
dojo.require('dijit.layout.LayoutContainer');
dojo.require('dijit.layout.TabContainer');
dojo.require('dijit.Menu');
dojo.require('dijit.MenuBar');
dojo.require('dijit.MenuBarItem');
dojo.require('dijit.MenuItem');
dojo.require('dijit.PopupMenuBarItem');
dojo.require('dijit.PopupMenuItem');
dojo.require('dijit.TitlePane');
dojo.require('dijit.Tree');
dojo.require('dojo.data.ItemFileWriteStore');
dojo.require('dojo.parser');
dojo.require('dojox.grid.DataGrid');

// new in DOJO 1.7.1
// dojo.require('dijit._Templated');
// dojo.require('dijit.WidgetSet');

/* ----------------------------------------------------- */

dojo.addOnLoad(function(){
	// instantiate all page widgets
	dojo.parser.parse();
});
