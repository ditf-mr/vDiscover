<?php if (!defined('APPLICATION_started')) {header('Location: .');exit;}
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/
?>
 
<div dojoType="common.widgets.fixedSizeDialog" innerWidth="800" innerHeight="800"  id="application.Dialog.error" title="An error has occurred" execute="this.hide();" >
	<div dojoType="dijit.layout.BorderContainer"  style="height:100%;width:100%;" gutters="false">
		<div dojoType="dijit.layout.ContentPane" region="left" style="width:150px;">
			<img style="vertical-align:middle;padding-right:1.5em;" src="./third_party_libraries/open-icon-library-standard-0.10/icons/png/128x128/status/dialog-error.png"/>		
		</div>
		<div dojoType="dijit.layout.ContentPane" region="center" class="" id="application.Dialog.error.message">
			Here goes the error message
		</div>
	
		<div dojoType="dijit.layout.ContentPane" region="bottom" style="margin-top:1ex;" >
			<button dojoType="dijit.form.Button" type="submit" style="float:right;">
				<?php echo T('BTN_Close', 'Close'); ?>
			</button>
		</div>
	</div>
</div>	

