<?php if (!defined('APPLICATION_started')) {header('Location: .');exit;}
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/
?>
 

<div dojoType="dijit.Dialog" id="application.Dialogue.logout" title="<?php echo T('logout.dial.php/Logout_TIT', 'Logout'); ?>">
	<div dojoType="dijit.form.Form" id="rm_dialogue_logout_form" encType="multipart/form-data" action="" method="post"  jsId="rm_dialogue_logout_form">
	  <input type="hidden" id="a" name="a" value="logout" />
	  <table style="min-width:400px; max-width: 800px;">
		<tbody>
			<tr>
				<td><img src="./third_party_libraries/open-icon-library-standard-0.10/icons/png/128x128/actions/system-exit.png"/></td>
			  <td  style="vertical-align:middle"><?php echo T('logout.dial.php/ReallyLO_TXT', 'Do you really want to log out?'); ?></td>
			</tr>
			<tr>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			</tr>
			<tr>
			  <td valign="top" colspan="2" style="text-align:right">
				<button dojoType="dijit.form.Button" type="submit"><?php echo T('BTN_OK', 'OK'); ?></button>
				<button dojoType="dijit.form.Button" type="button" onClick="dijit.byId('application.Dialogue.logout').hide(); return false;">
					<?php echo T('BTN_Cancel', 'Cancel'); ?>
				</button>
			</td>
			</tr>
		</tbody>
	  </table>
	</div>
</div>	

