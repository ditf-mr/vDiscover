<?php if (!defined('APPLICATION_started')) {header('Location: .');exit;} 
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// this file registers all components for normal users

$r->register_dialogHTML('application/dialogs_for_normal_users/logout.dialog.dojoHTML.php');
$r->register_dialogHTML('application/dialogs_for_normal_users/error.dialog.dojoHTML.php');
$r->register_dialogHTML('application/dialogs_for_normal_users/message.dialog.dojoHTML.php');

$r->register_JavaScriptFile('application/dialogs_for_normal_users/application.widgets.userSettings.js');

?>