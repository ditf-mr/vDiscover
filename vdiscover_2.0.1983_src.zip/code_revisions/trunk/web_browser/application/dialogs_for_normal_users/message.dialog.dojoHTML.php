<?php if (!defined('APPLICATION_started')) {header('Location: .');exit;}
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/
?>
 
<div dojoType="common.widgets.fixedSizeDialog" innerWidth="800" innerHeight="800"  id="application.Dialog.message" title="An important message (this will be overwritten on run time)" execute="this.hide();" >
	<div dojoType="dijit.layout.BorderContainer"  style="height:100%;width:100%;" gutters="false">
		<div dojoType="dijit.layout.ContentPane" region="center" class="" id="application.Dialog.message.message" style="padding-right:.25em;">
			Here goes the message (this will be overwritten at run time)
		</div>
	
		<div dojoType="dijit.layout.ContentPane" region="bottom" style="margin-top:1ex;" >
			<button dojoType="dijit.form.Button" type="submit" style="float:right;">
				<?php echo T('BTN_Close', 'Close'); ?>
			</button>
		</div>
	</div>
</div>	

