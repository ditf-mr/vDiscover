/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare('application.widgets.userSettings',[common.widgets.fixedSizeDialog],{
	
	// these slots have values need to be passed when creating the widget
	'userProfile'	: null, // mandantory {} --- the information about the user	
	
	// the following slots form internal variables / containers
	'_userNameExists'	: null,
	'_serverError'		: null,
	
	
	// settings of the parent class common.widgets.fixedSizeDialog
	'innerWidth'	: 480
	,
	'innerHeight'	: 400
	,
	
	
	
	// widget life cycle
	'constructor' : function () {
	
		// some initialisations
		this.userProfile 	= {};
	
		this.widgets 		= {};
		this._userNameExists = null;
		this._serverError 	= null;
		
	} // end of method constructor
	,
	'postMixInProperties' : function () {
		this.inherited(arguments);
	
		this.title = T('userSettings.js/ChangeMyUserSettings_TIT', 'Change my User Settings');
	
	} // end of method postMixInProperties
	,
	'buildRendering' : function () {
		this.inherited(arguments);

		
		this.widgets.form = new dijit.form.Form({
			'onSubmit'	: function () {
				return false;
			}, // end of method onSubmit
		}).placeAt(this.containerNode);
	
		this.structureAsTable = dojo.create ( 'TABLE', {
			'class'		: 'fullWidth compact',
			'innerHTML'	: ''
			
				+'<tr>'
					+'<th style="text-align:right;" width="33%">'
						+ T('userSettings.js/UserName_LBL', 'User name:')
					+'</th>'
					+'<td class="_userName_domNode">'
						+'sdfsdfsdfdafsdd'
					+'</td>'
				+'</tr>'
		
				+'<tr class="_userNameExists_domNode" style="display:none;">'
					+'<td colspan="2">'
						+'<p style="padding:.25em;margin:.5em;margin-left:0;margin-right:0;border-radius:.5em;border:.1ex solid red;background-color:antiquewhite;font-weight:bold;">'
							+ T('userSettings.js/NewUserNameErrMsg_TXT', 'The new user name does already exist. Please choose another one.')
						+'</p>'
					+'</td>'
				+'</tr>'
		
				+'<tr>'
					+'<th style="text-align:right;">'
						+T('userSettings.js/PreAndSurname_LBL', 'Prename and surname:')
					+'</th>'
					+'<td class="_name_domNode">'
						+'sdfsdfsdfdafsdd' // This is only a dummy-text, which was replaced later.
					+'</td>'
				+'</tr>'
		
				+'<tr>'
					+'<th rowspan="2" style="text-align:right;">'
						+T('userSettings.js/Locale_LBL', 'Locale:')
					+'</th>'
					+'<td class="_locale_domNode">'
						+'<p>Locale</p>' //This is only a dummy-text, which was replaced later. No T()
					+'</td>'					
				+'</tr>'
				
				+'<tr>'
					+'<td>'
						+'<p>'
							+ T('userSettings.js/LocaleHint_TXT', 'Please attend that the changing of the locale takes effect not before re-login.')
						+'</p>'
					+'</td>'
				+'</tr>'
				
				
				+'<tr>'
					+'<td colspan="2">'
						+'<hr />'
					+'</td>'
				+'</tr>'
		
				+'<tr>'
					+'<td colspan="2">'
						+'<p>'
							+T('userSettings.js/ChPasswdHint_TXT', 'If you want to change your password, please enter the current one and the new one. In case that you do not want to change your password, leave all fields empty.')
						+'</p>'
					+'</td>'
				+'</tr>'
		
				+'<tr class="_allPWDsNeedToBeEntered_domNode" style="display:none;">'
					+'<td colspan="2">'
						+'<p style="padding:.25em;margin:.5em;margin-left:0;margin-right:0;border-radius:.5em;border:.1ex solid red;background-color:antiquewhite;font-weight:bold;">'
							+'You need to enter your current password, the new one and its confirmation.'
						+'</p>'
					+'</td>'
				+'</tr>'
		
				+'<tr>'
					+'<th style="text-align:right;">'
						+ T('userSettings.js/CurrPwd_LBL', 'Current password:')
					+'</th>'
					+'<td class="_currentPWD_domNode">'
						+'sdfsdfsdfdafsdd'
					+'</td>'
				+'</tr>'
		
				+'<tr class="_newPWDsAreNotIdentical_domNode" style="display:none;">'
					+'<td colspan="2">'
						+'<p style="padding:.25em;margin:.5em;margin-left:0;margin-right:0;border-radius:.5em;border:.1ex solid red;background-color:antiquewhite;font-weight:bold;">'
							+T('userSettings.js/PwdMismatchMsg_TXT', 'The new password and its confirmation are not identical.')
						+'</p>'
					+'</td>'
				+'</tr>'
		
				+'<tr>'
					+'<th style="text-align:right;">'
						+ T('userSettings.js/NewPwd_LBL', 'New password:')
					+'</th>'
					+'<td class="_newPWD1_domNode">'
						+'sdfsdfsdfdafsdd'
					+'</td>'
				+'</tr>'
		
				+'<tr>'
					+'<th style="text-align:right;">'
						+ T('userSettings.js/ConfNewPwd_LBL', 'Confirm the new password:')
					+'</th>'
					+'<td class="_newPWD2_domNode">'
						+'sdfsdfsdfdafsdd'
					+'</td>'
				+'</tr>'
		
				+'<tr>'
					+'<td colspan="2">'
						+'&nbsp;'
					+'</td>'
				+'</tr>'
		
				+'<tr class="_serverError_domNode" style="display:none;">'
					+'<td colspan="2">'
						+'<p class="_serverErrorMessage_domNode" style="padding:.25em;margin:.5em;margin-left:0;margin-right:0;border-radius:.5em;border:.1ex solid red;background-color:antiquewhite;font-weight:bold;">'
							+'The error message from the server goes, here.'
						+'</p>'
					+'</td>'
				+'</tr>'
		
		}, this.widgets.form.containerNode);
		
		// localise all necessary DOM nodes
		dojo.forEach([
			'_userName_domNode',
			'_name_domNode',
			'_locale_domNode',
			'_currentPWD_domNode',
			'_newPWD1_domNode',
			'_newPWD2_domNode',
			'_allPWDsNeedToBeEntered_domNode',
			'_newPWDsAreNotIdentical_domNode',
			'_userNameExists_domNode',
			'_serverError_domNode',
			'_serverErrorMessage_domNode',
		], function (slot){
			this[slot] = dojo.query('.'+slot, this.structureAsTable).pop();
		}, this);
		
		// set up the input boxes
		this.widgets.userName_IB = new dijit.form.ValidationTextBox ({
			'regExp'			: ".{2,}",
			'selectOnClick'		: true,
			'value'				: this.userProfile.username,
			'required'			: true,
			'invalidMessage'	: T(	'userSettings.js/UserNameInvalidMSG_TXT',
										"The user name should have at least 2 chars."),
			'class'				: "fullWidth",
			'tooltipPosition'	: "right",
			'trim'				: true, 
			'intermediateChanges':true,
			'maxlength'			: 256,
		}).placeAt(this._userName_domNode, 'only');
		
		this.widgets.name_IB = new dijit.form.ValidationTextBox ({
			'regExp'			: ".{3,}",
			'selectOnClick'		: true,
			'value'				: this.userProfile.name,
			'required'			: true,
			'invalidMessage'	: T(	'userSettings.js/NameInvalidMSG_TXT',
										"The prename and surname should have at least 3 chars."),
			'class'				: "fullWidth",
			'tooltipPosition'	: "right",
			'trim'				: true, 
			'intermediateChanges':true,
			'maxlength'			: 256,
		}).placeAt(this._name_domNode, 'only');
		
		this.widgets.localeSelector = new dijit.form.FilteringSelect ({
			'style'		: 'width:100%;',
			'store'		: new dojo.data.ItemFileReadStore({
				'data'	: langStoreData, // global variable
			}),
			'searchAttr': 'localeName_display',
			'name'		: 'locale',
			'value'		: this.userProfile.locale,
			'intermediateChanges':true,	
		}).placeAt( this._locale_domNode, 'only' );
					
		this.widgets.currentPWD_IB = new dijit.form.ValidationTextBox ({
			'regExp'			: ".{5,}",
			'type'				: 'password',
			'selectOnClick'		: true,
			'value'				: '',
			'required'			: true,
			'invalidMessage'	: T(	'userSettings.js/CurrentPasswordInvalidMSG_TXT',
										"The Current Password should have at least 5 chars."),
			'class'				: "fullWidth",
			'tooltipPosition'	: "right",
			'trim'				: true, 
			'intermediateChanges':true,
			'maxlength'			: 256,
		}).placeAt(this._currentPWD_domNode, 'only');
		
		this.widgets.newPWD_IB = new dijit.form.ValidationTextBox ({
			'regExp'			: ".{5,}",
			'type'				: 'password',
			'selectOnClick'		: true,
			'value'				: '',
			'required'			: true,
			'invalidMessage'	: T(	'userSettings.js/CurrentPasswordInvalidMSG_TXT',
										"The New Password should have at least 5 chars."),
			'class'				: "fullWidth",
			'tooltipPosition'	: "right",
			'trim'				: true, 
			'intermediateChanges':true,
			'maxlength'			: 256,
		}).placeAt(this._newPWD1_domNode, 'only');
		
		this.widgets.confirmNewPWD_IB = new dijit.form.ValidationTextBox ({
			'regExp'			: ".{2,}",
			'type'				: 'password',
			'selectOnClick'		: true,
			'value'				: '',
			'required'			: true,
			'invalidMessage'	: T(	'userSettings.js/NewPasswordInvalidMSG_TXT',
										"The Password confirmation should have at least 5 chars."),
			'class'				: "fullWidth",
			'tooltipPosition'	: "below",
			'trim'				: true, 
			'intermediateChanges':true,
			'maxlength'			: 256,
		}).placeAt(this._newPWD2_domNode, 'only');
			
		dojo.create('P',{
			'innerHTML' : '&nbsp;',
		}, this.widgets.form.containerNode);
	
		var bRow = dojo.create('DIV',{
			'innerHTML' : '',
			'style' : 'position:absolute;bottom:0;right:0;padding:.25em;',
		}, this.widgets.form.containerNode);
	
		this.widgets.OkButton = new dijit.form.Button({
			'label' 	: '<img src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/dialog-ok-apply-4.png"/> '
				+T('BTN_OK','OK'),
			'type'		: 'submit',
			'disabled'	: 'true',
		}).placeAt(bRow);
		
		this.widgets.CancelButton = new dijit.form.Button({
			'label' 	: '<img width="12" src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/dialog-cancel-4.png"/> '
				+T('BTN_Cancel','Cancel'),
		}).placeAt(bRow);
		
	} // end of method buildRendering
	,
	'startup' : function () {
		this.inherited(arguments);
	
		// it's time now for the connects ...
		this.connect( this.widgets.userName_IB, 	'onChange', '_contentChanged'	);
		this.connect( this.widgets.name_IB, 	'onChange', '_contentChanged'	);
		this.connect( this.widgets.localeSelector, 	'onChange', '_contentChanged'	);
		
		this.connect( this.widgets.currentPWD_IB, 	'onChange', '_contentChanged'	);
		this.connect( this.widgets.newPWD_IB, 	'onChange', '_contentChanged'	);
		this.connect( this.widgets.confirmNewPWD_IB, 	'onChange', '_contentChanged'	);

		this.connect( this.widgets.OkButton,	'onClick',	'_execute'			);
		this.connect( this.widgets.CancelButton,'onClick',  'hide'				);
		
		// set the focus to the user name input box
		this.widgets.userName_IB.focus();
		
		// enable/ disable the Ok button
		this._contentChanged();
	
	} // end of method startup
	,
	'destroy' : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		
		for (var i in this.widgets) {
			if (this.widgets[i].destroyRecursive) this.widgets[i].destroyRecursive(false);
			delete this.widgets[i];
		} // end for .. in
		
		// this.inherited(arguments);
	} // end of method destroy
	,
	
	// internal methods
	'_execute' : function (e) {
		
		dojo.style(this._serverError_domNode, 'display', 'none');
		
		if (!this._validateInputs(true /* check passwords */ ) ) return;
	
		var name			= this.widgets.name_IB			.attr('value'),
			username		= this.widgets.userName_IB		.attr('value'),
			password		= this.widgets.confirmNewPWD_IB	.attr('value'),
			currentPassword	= this.widgets.currentPWD_IB	.attr('value'),
			locale			= this.widgets.localeSelector	.attr('value');
	
		application.General_AJAX_query({	
				"task"				: 'setUserProfile',				
				'name'				: name,
				'username'			: username,
				'password'			: password,
				'currentPassword'	: currentPassword,
				'locale'			: locale,
			},
			function(r,a){
				if ('error' in r) {
					a.args.scope._serverError = r.error;					
					console.log('_serverError',  r.error);
				} // end if
				else
					a.args.scope._serverError = false;
			} // end of onLoad
			,
			true /* sync */
			,
			this /* scope */
		);
	
		if (this._serverError) {
		
			var errorMessage = '';
			switch (this._serverError) {
				case 'currentPWDinvalid':
					errorMessage = ''
						+ T('userSettings.js/CurrPwdInvMsg_TXT', 'The current password is wrong. Please correct it and try, again.');
					break;
				default:
					errorMessage = this._serverError;
			} // end switch
		
			// output the error message
			dojo.attr( this._serverErrorMessage_domNode, 'innerHTML', errorMessage);
			dojo.style(this._serverError_domNode, 'display', 'table-row');
			return;
		} // end if server error

		this.hide();
	} // end of method _execute
	,
	'_contentChanged' : function () {
		return this._validateInputs(false /* do not check passwords */ );
	} // end of method _contentChanged
	,
	'_validateInputs' : function (extendedChecks) {
		// This method detects all changes to the entered data and verifies, if a submit to the server is permitted.
		// The submit button will be enabled/ disabled, accordingly.
		
		// What needs to be given for permitting a submit:
		// * one or more of the input fields user name, surname and last name, locale got changed and are valid
		// * the current password, the new one and its confirmation are entered and valid
		
		// check the general input fields
		var generalInputBoxesAreValid 	= true
				&& this.widgets.userName_IB		.isValid()
				&& this.widgets.name_IB			.isValid()
				&& this.widgets.localeSelector	.isValid()
				;
		
		var generalInput_changed 		= false
				|| ( this.widgets.userName_IB	.attr('value') != this.userProfile.username	)
				|| ( this.widgets.name_IB		.attr('value') != this.userProfile.name		)
				|| ( this.widgets.localeSelector.attr('value') != this.userProfile.locale	)
				;
		
		var passwordEntered				= false
				||	( this.widgets.currentPWD_IB	.attr('value') 	!= '' )
				||	( this.widgets.newPWD_IB		.attr('value') 	!= '' )
				||	( this.widgets.confirmNewPWD_IB	.attr('value') 	!= '' )
				;
		
		var everythingOK 				= true
				&& generalInputBoxesAreValid
				&& generalInput_changed
				;
		
		// check the username if it was changed and is valid
		var userName_changedAndValid = true
				&& this.widgets.userName_IB		.isValid()
				&& ( this.widgets.userName_IB	.attr('value') != this.userProfile.username	)
				;
				
		if (extendedChecks && userName_changedAndValid) {
			application.General_AJAX_query({	
					"task"		: 'existsUsername',
					'username'	: this.widgets.userName_IB	.attr('value'),
				},
				function(r,a){
					a.args.scope._userNameExists = r.userNameExists;					
					console.log('_userNameExists',  r.userNameExists);
				} // end of onLoad
				,
				true /* sync */
				,
				this /* scope */
			);
			
			if (this._userNameExists) {
				everythingOK = false;
				dojo.style(this._userNameExists_domNode, 'display', 'table-row');
			} else {
				dojo.style(this._userNameExists_domNode, 'display', 'none');
			} // end if
			
		} // end if
				
		// check the passwords
		if (passwordEntered) {
		
			var allPasswordsAreValid = true
				&& this.widgets.currentPWD_IB	.isValid()
				&& this.widgets.newPWD_IB		.isValid()
				&& this.widgets.confirmNewPWD_IB.isValid()
				;
			
			// if passwords are not valid: error message
			if(extendedChecks && !allPasswordsAreValid) {
				dojo.style(this._allPWDsNeedToBeEntered_domNode, 'display', 'table-row');
			} else {
				dojo.style(this._allPWDsNeedToBeEntered_domNode, 'display', 'none');
			} // end if
			
			var newPWD_isIdentical	= ( this.widgets.newPWD_IB.attr('value') == this.widgets.confirmNewPWD_IB.attr('value') );
			
			// if passwords are not identical: error message
			if(extendedChecks && !newPWD_isIdentical) {
				dojo.style(this._newPWDsAreNotIdentical_domNode, 'display', 'table-row');
			} else {
				dojo.style(this._newPWDsAreNotIdentical_domNode, 'display', 'none');
			} // end if
			
			// test if everything is ok
			
			// if there are changes in the password section, the user name section needs to be valid, only
			everythingOK	= generalInputBoxesAreValid
								&&	allPasswordsAreValid;
			if (extendedChecks) {
				everythingOK	= everythingOK
					&&	( extendedChecks && newPWD_isIdentical );
			} // end if extendedChecks
			
		} // end if
		
		this.widgets.OkButton.attr('disabled', !everythingOK);
		
		return everythingOK;
	} // end of method _validateInputs
	,
	
});	
	
// static code
application.userSettings = {
	'dialogWidget' 	: null
	,
	'dialogConnects' : null
	,
	
	'_userProfile'	: null
	,
	
	'showDialog' : function() {
	
		if (this.dialogWidget) this.deleteDialog(); // destroy a potentially existing dialog widget
		
		// get the necessary information
				
		application.General_AJAX_query({	
				"task"		: 'getUserProfile',
			},
			function(r,a){
				a.args.scope._userProfile = r;
				console.log('userProfile', r);
			} // end of onLoad
			,
			true /* sync */
			,
			this /* scope */
		);
		
		this.dialogWidget = new application.widgets.userSettings({
			'userProfile'	: this._userProfile,
		});
		
		// carry out the necessary connects
		this.dialogConnects = [
			dojo.connect( this.dialogWidget, 'onExecute', this, '_onExecute' 	),
		];
		
		this.dialogWidget.startup();
		this.dialogWidget.show();
		
		loader.hide();
		
	} // end-of-method showDialog
	,
	'closeDialog' : function() {	
		this.dialogWidget.hide();
		this.deleteDialog();
		
	} // end of method closeDialog
	,
	'_onExecute' : function( ) {

		return; 
	} // end-of-method execute
	,
	'deleteDialog' : function () {
	
		dojo.forEach( this.dialogConnects, function (c) {
			dojo.disconnect(c);
		}, this);
		
		this.dialogWidget.destroyRecursive(false);
		this.dialogWidget.destroy();
		this.dialogWidget=null;
		
		this._userProfile = null;
			
	} // end of method deleteDialog
	,
	
}; // end static code