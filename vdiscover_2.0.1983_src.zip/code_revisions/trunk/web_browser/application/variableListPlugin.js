dojo.provide("dojox.editor.plugins.variableList");
dojo.experimental("dojox.editor.plugins.variableList");

// dojo.require("dojo.i18n");
dojo.require("dijit._editor._Plugin");
dojo.require("dijit.form.ToggleButton");
dojo.require("dijit.form.Select");
dojo.require("dijit.form.DropDownButton");


// Localisation not needed
// dojo.requireLocalization("dojox.editor.plugins", "variableList");

dojo.declare("dojox.editor.plugins.variableList", dijit._editor._Plugin, {
	// summary:
	//		This plugin allows the user to select from emoticons or "smileys"
	//		to insert at the current cursor position.
	//
	// description:
	//		The commands provided by this plugin are:
	//		* smiley - inserts the selected emoticon

	// iconClassPrefix: [const] String
	//		The CSS class name for the button node is formed from `iconClassPrefix` and `command`
	iconClassPrefix: "dijitAdditionalEditorIcon",

	// a marker for emoticon wrap like [:-)] for regexp convienent
	// when a message which contains an emoticon stored in a database or view source, this marker include also
	// but when user enter an emoticon by key board, user don't need to enter this marker.
	// also emoticon definition character set can not contains this marker
	emoticonMarker: '${}',

	_initButton: function(){
		// summary:
		//
		var variableList = [];
		application.admin.manageViews.variableList.fetch(
			{ 
				sort: [{ attribute: "name", descending: true}],
				onItem: function (item){
							variableList.push({
								label: application.admin.manageViews.variableList.getValue(item,'name'),
								value: application.admin.manageViews.variableList.getValue(item,'name')
								});
						}
			}
		);
		
		if (variableList.length>0) variableList.unshift({
		    //TG: QUESTION: T() ?
				label: 'List of Attributes',
				value: ''
			});

		this.button = new dijit.form.Select({
			options: variableList,
			maxHeight: 250,
			//TG: QUESTION: T() ?
			emptyLabel: 'no Attributes defined'
		});	
		this.connect(this.button, "onChange", function(variable){
			this.button.closeDropDown();
			this.editor.focus();
			// reset select
			this.button.reset();
			//
			if (variable) {
				variable = this.emoticonMarker.charAt(0)+this.emoticonMarker.charAt(1) + variable + this.emoticonMarker.charAt(2);		
				this.editor.execCommand("inserthtml", variable);
			} // end if variable is not set
		});
		
		// this.button = new dijit.form.DropDownButton({
			// label: 'List of Variables',
			// dropDown: this.dropDown
		// });
	},

	setEditor: function(editor){
		// summary:
		//		Over-ride for the setting of the editor.
		// editor: Object
		//		The editor to configure for this plugin to use.	
		this.editor = editor;
		this._initButton();
		// this.editor.contentPreFilters.push(dojo.hitch(this, this._preFilterEntities));
		// this.editor.contentPostFilters.push(dojo.hitch(this, this._postFilterEntities));
	},

// probably not neccessary code
	
	_preFilterEntities: function(/*String content passed in*/ value){
		// summary:
		//		A function to filter out emoticons into their UTF-8 character form
		//		displayed in the editor.  It gets registered with the preFilters
		//		of the editor.
		// tags:
		//		private.
		//
		//
		return value.replace(/\[([^\]]*)\]/g, dojo.hitch(this, this._decode));
	},

	_postFilterEntities: function(/*String content passed in*/ value){
		// summary:
		//		A function to filter out emoticons into encoded form so they
		//		are properly displayed in the editor.  It gets registered with the
		//		postFilters of the editor.
		// tags:
		//		private.
		return value.replace(/<img [^>]*>/gi, dojo.hitch(this, this._encode));
	},

	_decode: function(str, ascii){
		// summary:
		//		Pre-filter for editor to convert strings like [:-)] into an <img> of the corresponding smiley
		var emoticon = dojox.editor.plugins.Emoticon.fromAscii(ascii);
		return emoticon ? emoticon.imgHtml(this.emoticonImageClass) : ascii;
	},

	_encode: function(str){
		// summary:
		//		Post-filter for editor to convert <img> nodes of smileys into strings like [:-)]
		
		// Each <img> node has an alt tag with it's ascii representation, so just use that.
		// TODO: wouldn't this be easier as a postDomFilter ?
		if(str.search(this.emoticonImageRegexp) > -1){
			return this.emoticonMarker.charAt(0) + str.replace(/(<img [^>]*)alt="([^"]*)"([^>]*>)/, "$2") + this.emoticonMarker.charAt(1);
		}
		else{
			return str;
		}
	}
	
// end of probably not neccessary code
	
});

// Register this plugin.
dojo.subscribe(dijit._scopeName + ".Editor.getPlugin",null,function(o){
	if(o.plugin){ return; }
	if(o.args.name === "variableList"){
		o.plugin = new dojox.editor.plugins.variableList();
	}
});
