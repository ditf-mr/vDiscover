/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// the general widget for any kind of view instance
dojo.declare("application.widgets.genericView",[dijit.layout.ContentPane],{
	
	// necessary settings for all views for dijit.layout.ContentPane
	'region'	: 'center',
	'label'		: '',
	'title'		: '',

	// constants
	'pageSizeCssClass' 			: 'output_DIN_A4',
	'loaderClass'				: 'RS_viewPane_reloading', // this css class is defined in application/register_application_components.php
	'hasEstimationFunctionality': true, // this option may be set to false in sub classes
	
	// variables
	'displayEmbedded'		: false,
	'edit' 					: false,
	'refreshFromServer' 	: true,
	'attributeWidgetList' 	: null,	// will be set to {}
	'O_name' 				: null,
	
	'attributesWithValueSets': null, // if this slot was not specified on initialisation, it will be set to {}
	
	'constructor' : function () {

		// initialisations
		this.attributeWidgetList = {};
		if (typeof this.attributesWithValueSets!='object') this.attributesWithValueSets={};
		this.changed_VTs={};
		
	} // end of method constructor
	,
	'postMixInProperties' : function() {
		this.inherited(arguments);
				
		// set some dependent values
		this.id = Math.uuid();

		if(!this.rA_parentWidget && !this.viewPane) 
		throw ('Cannot initialise application.widgets.genericView without \'rA_parentWidget\' or \'viewPane\' . Aborting.');
	   
		// if the view is included in a relationAttribute widget: organise some dependent values
		if (this.rA_parentWidget) {
					
			if(!this.rA_valueTuple) throw('Cannot find the value tuple with the AV_UUID '+this.AV_UUID_of_valueTuple+'!');
			
			// locate this.viewConfig
			this.viewConfig=this.rA_valueTuple.atEndObject.viewType;
				
		} else {
			this.viewName 	= this.viewPane.titleAsText;
			this.viewConfig = this.viewPane.viewConfig;
			this.VT_UUID 	= this.viewConfig.UUID;
			this.readOnly 	= this.viewConfig.readOnly;
			this.O_UUID 	= this.objectWidget.O_UUID;
			this.O_name 	= this.objectWidget.objName;
		} // end if
				
	   this.title=this.viewName;
	   
		if (this.viewConfig.eqSolverIsActive && (typeof this.viewConfig.eqSolverConfig != 'object')) {
			if (!this.viewConfig.eqSolverJSONConfig.length) this.viewConfig.eqSolverJSONConfig='{}';
			try {
				this.viewConfig.eqSolverConfig = dojo.fromJson(this.viewConfig.eqSolverJSONConfig);
			} catch (e) {
				console.error('Problems while unserialising JSON string \''+this.viewConfig.eqSolverJSONConfig+'\'');
				throw e;
			} // end try ... catch
		} // end if 
		
	} // end of method postMixInProperties
	,
	'addToAttributeWidgetList' : function (A_UUID, A_widget) {
		this.attributeWidgetList[A_UUID]=A_widget;
	} // end of method addToAttributeWidgetList
	,
	/*buildRendering : function() {
		// dijit._Templated provides an implementation of buildRendering 
		// that most times will do what you need. The template is fetched/read, 
		// nodes created and events hooked up during buildRendering. The end 
		// result is assigned to this.domNode. If you don't mixin dijit._Templated 
		// (and most OOTB dijits do) and want to handle rendering yourself 
		// (e.g. to really streamline a simple widget, or even use a different 
		// templating system) this is where you'd do it.
		this.inherited(arguments);
	} // end of method buildRendering
	,*/
	'postCreate' : function() {
		// This is typically the workhorse of a custom widget. The widget has 
		// been rendered (but note that sub-widgets in the containerNode have not!). 
		// The widget though may not be attached to the DOM yet so you shouldn't 
		// do any sizing calculations in this method.
		
		this.inherited(arguments);
		
		// this is an internet explorer bugfix for dense tables
		if (this.displayEmbedded) {
			dojo.style(this.containerNode, 'overflow', 'inherit');
		} // end if
		
	} // end of method postCreate
	,
	/*startup : function() {
		// If you need to be sure parsing and creation of any child widgets has 
		// completed, use startup. This is often used for layout widgets like 
		// BorderContainer. If the widget does JS sizing, then startup() should 
		// call resize(), which does the sizing.
		this.inherited(arguments);
		
		for (var A_UUID in this.attributeWidgetList) this.attributeWidgetList[A_UUID].startup();
		
	} // end of method startup
	,*/
	/*resize : function () {
		console.log('view resize',arguments);
		// get any widgets that are embedded in the current one and tell them to resize
		//dijt.
	}
	,*/
	/*destroy : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you.
		this.inherited(arguments);
	} // end of method destroy
	,*/
	
	'refreshContents' : function(action) {
		
		// determine what to do
		switch(action) {
			case 'switchToReadMode':
				this.edit=false;
				break;
			case 'actualise':
				// this is not permitted if in edit mode 
				if(this.edit) return;
				break;
			case 'activateEditMode':
				this.edit=true;
				break;
			default:
				return; // do nothing
		} // end switch action
	
		// show a refresh message instead of the content
		var loadingMessageDIV = dojo.create('DIV',{
			'class'		: (this.displayEmbedded?'':this.pageSizeCssClass)+' '+this.loaderClass,
			'innerHTML'	: T('views_genTmplWid.js/CommWServer_HTM','Communicating with the server …'),
		});
		this.attr('content', loadingMessageDIV);
		
		// get the newest attribute value set information
		if (this.refreshFromServer) 
			application.O_AJAX_query(
				{ 
				task	: 'get_O_view2', 
				UUID	: this.O_UUID, 
				VT_UUID	: this.VT_UUID,
				'widgetId':this.id // !important! this is passed as a.args.content.widgetId to the onSuccess method
				}, 
			function(r,a){ // onSuccess method
				// identify the widget
				var O_UUID = this.content.UUID; // this == a.args
				var myWidgetId = a.args.content.widgetId;
				var widget = dijit.byId(myWidgetId);
				if (!widget) 
						throw(
					'Problem! Cannot locate the view widget "'+r.viewType.UUID+'"\n'
					+'for the object "'+O_UUID+'"\n'
							+'(the view tab id is "'+myWidgetId+'").'
						);
				// set the attribute config and value sets
				widget.attributesWithValueSets = r.attributesWithValueSets;
			}, // end of onSuccess method
			true /* synchronously */
		); // end AJAX query
		
		// empty the widget's contents
		
		// iterate over all registered attributes and destroy them
		for (var A_UUID in this.attributeWidgetList) {
			var A_widget = this.attributeWidgetList[A_UUID];
			
			if (A_widget.destroyRecursive) 	A_widget.destroyRecursive();
			else if (A_widget.destroy) 		A_widget.destroy();
			
			delete this.attributeWidgetList[A_UUID];
		} // end for .. in
		
		// iterate over all remaining widgets
		var childWidgets = dijit.findWidgets(this.domNode);
		dojo.forEach(childWidgets,function(cWidget){
			if (cWidget.destroyRecursive) 	cWidget.destroyRecursive();
			else if (cWidget.destroy) 		cWidget.destroy();
		},this);
		
		this.destroyDescendants(false/*destroy DOM, as well*/);
		dojo.empty(this.domNode);
		
		// build the widget's contents
		if(this.displayEmbedded) {
			this.attr('content', this.buildContent());
		} else {
			var pageSizeDiv = dojo.create('DIV',{'class':this.pageSizeCssClass});
			dojo.place(this.buildContent(), pageSizeDiv);
			this.attr('content', pageSizeDiv);
			
			// refresh the tag list
			if(this.viewPane) this.viewPane.refreshTagList(this.attributesWithValueSets);
			
		} // end if display as embedded
		
	} // end of method refreshContents
	,
	'getCurrentAttributeValues' : function () { 
		// This method iterates over all child widgets and returns their current value as an object.
		
		var values = {};
		for(var i in this.attributeWidgetList) {
			var cWidget = this.attributeWidgetList[i];
			if(cWidget.currentValueAccessible ) {
				values[cWidget.A_UUID]=cWidget.getCurrentValue();
			} // end if
		} // end for ... in
	
		return values;
	} // end of method getCurrentAttributeValues
	,
	'setChangedAttributeValues' : function (changedValues) {

		for(var i in changedValues) {
			var cWidget = this.attributeWidgetList[i];
			if(cWidget && cWidget.setCurrentValue && (cWidget.config.cardinality==1)) {
				cWidget.setCurrentValue(changedValues[i]);
			} // end if
		} // end for ... in
		
	} // end of method setChangedAttributeValues
	,
	/*
	setEstimatedAttributeValues : function (changedValues) {

		var i;
		for(i in changedValues) {
			var cWidget = this.attributeWidgetList[i];
			if(cWidget && cWidget.setCurrentValue && (cWidget.config.cardinality==1)) {
				cWidget.setEstimatedValue(changedValues[i]);
			} // end if
		} // end for ... in
	} // end of method setChangedAttributeValues
	,*/
	'buildAttributeReplacementTable':function(embedded){
		// this method builds a subobject that provides dojo widget code for attributes
				
		var attributeReplacementTable={};
		for(var i in this.attributesWithValueSets) {
			var a=this.attributesWithValueSets[i];
			if(!application.attributeKinds.attributeKindList[a.attribute.kind]) throw 'There is no registration for the attribute kind "'+a.attribute.kind+'"';
			var dojoType=application.attributeKinds.attributeKindList[a.attribute.kind].widgetClass;
			attributeReplacementTable[a.attribute.A_UUID]=
				'<div'
					+' dojoType="'+dojoType
					+'" A_UUID="'+a.attribute.A_UUID
					+'" O_UUID="'+this.O_UUID
					+'" VT_UUID="'+this.VT_UUID
					+'" V_widgetId="'+this.id
					+'" readOnly="'+this.readOnly
					+'" isEmbedded="'+((this.displayEmbedded||embedded)?'true':'false')
					+'" edit="'+(this.edit && !this.readOnly?'true':'false')
				+'"></div>';
		};
		return attributeReplacementTable;
	} // end of method buildAttributeReplacementTable
	,
	'buildContent': function() {
		// create the DOM for some generic content
		return dojo.create('div',{innerHTML:'<p>You need to overwrite '+this.declaredClass+'::buildContent() in the widget for "'+this.attr('title')+'"!</p>'
				+'<h1>this.viewConfig</h1>'+'<pre class="small">'+dojo.toJson(this.viewConfig,true)+'</pre>'
				+'<h1>this.attributesWithValueSets</h1>'+'<pre class="small">'+dojo.toJson(this.attributesWithValueSets,true)+'</pre>'
			});
	} // end of method buildContent
	,
	
	'changed_VTs' : null // gets {} after initialisation
	,
	'attrValueTuple_hasChanged' : function (A_UUID, VT_UUID, tupleObj) {
		//if (tupleObj.status!='create') tupleObj.status = 'modified';

		if(!this.changed_VTs[A_UUID]) this.changed_VTs[A_UUID]={};
		this.changed_VTs[A_UUID][VT_UUID]=tupleObj;
		
		// if the view is an embedded one: tell the parent widget that there are changes
		if(this.rA_parentWidget) {
			// tell the parent widget that one of the end object's / view's value tuples has changed
			this.rA_parentWidget.change_VTatEndObject (this.rA_valueTuple.AV_UUID, A_UUID, VT_UUID, tupleObj);
		} // end if
		
		// notify the other attributes that there are changes
		for (var i in this.attributeWidgetList) {		
			var w=this.attributeWidgetList[i];
			if (		application.attributeKinds.kindPermitsAnalyticalExpressions(w.config.kind) 
					&& 	w.config.enableAnalyticalExpressions // analytical expressions turned on
					&&	w.attrVTIsInputForAnalyticalExpression(A_UUID) // test if the changed value tuple is input for the analytical expression
				) w.executeAnalyticalExpression();
		} // end for .. in
		
	} // end of method attrValueTuple_hasChanged
	,
	'isValid' : function () {
		// iterate over all attribute widgets and test if their current values are valid
		var allValuesAreValid = true;
		for (var i in this.attributeWidgetList) {		
			var w=this.attributeWidgetList[i];
				if(w.outputMode=='edit') {

					var wIsValid =  w.isValid();
					
					// mark the attribute as invalid, if necessary
					if (!this.rA_parentWidget) {
						if (wIsValid) 	w.remove_notValidMark();
							else 		w.markAs_notValid();
					}; // end if
					
					allValuesAreValid = allValuesAreValid && wIsValid;
				} // end if in edit mode
		} // end for .. in 
		return allValuesAreValid;
	} // end of method isValid
	,
	'getChanges' : function () {
		// This method returns a list with the current value tuples of all attributes in this view.
		// Expect this list to be empty if the output mode is !='edit'
		
		// return an empty object if not in edit mode
		if (!this.edit) {
			return {};
		} // end if
	
		// iterate over all editable attributes and get the updated value tuple sets
		var changes = {};
		
		for (var i in this.attributeWidgetList) {		
			var w=this.attributeWidgetList[i];
			if(w.outputMode=='edit') {
				var cTS = w.getChangedTupleSet();
				if(Object.keys(cTS).length>0) changes[w.A_UUID]=cTS;
			} // end if in edit mode
		} // end for .. in 
		
		return changes;
	} // end of method getChanges
	,
	'saveChanges' : function () {
	
		// This method sends a list of attribute value tuples to the server.
		// The corresponding attributes need to appear in this view and need to be editable.

		var saveSuccessful=false, i;
	
		if (!this.isValid()) {
			application.showErrorMessage(
				T('views_genTmplWid.js/InputsInvalid_cannotSave_HTM',
					'<p>There is one or more attribute with invalid or incomplete values.</p><p>You need to correct these values before your input can be stored on the server.</p>')
				);
			return saveSuccessful;
		} // end if 
	
		try {
			// save all changes to the server
			application.O_AJAX_query({
					'task'				: 'set_O_attributeValuesOfAViewType',
					'O_v_UUID'			: this.O_UUID,
					'VT_UUID'			: this.VT_UUID,
					'attributeValues'	: dojo.toJson(this.getChanges())
				}, 
				function(q_result, q) {
				// name has changed?
				// Bug: the name should be rendered here, directly, not on the server
					if (q_result.O_nameIsModified)
						application.O.updateName(q.args.content.O_v_UUID, q_result.name);
						saveSuccessful=true; // means: switch to read mode
				}, 
				true /* synchronously */
			);
		} catch (e) {
			console.error(e);
			alert('Houston - there is a problem:\n\n'+e);
		} // end try .. catch
	
		return saveSuccessful;
	} // end of method saveChanges
	,
	/*currentAttr_widget : null
	,
	setCurrentAttr_widget : function (w) {
		this.currentAttr_widget=w;
		
		// detect if there are dependencies
		if(!this.eqSolver) return;
		
		var dependencies = this.eqSolver.identifyDependencies(
				this.currentAttr_widget.A_UUID,
				this.getCurrentAttributeValues()
			);
		
		if(!Object.keys(dependencies).length && this.menuItems.estimateDependenciesPM) {
			// deactivate the dependencies estimation menu item
			this.menuItems.estimateDependenciesPM.attr('disabled',true);
			return;
		} // end if
		
		// enable the estimate dependencies menu item
		if (this.menuItems.estimateDependenciesPM) this.menuItems.estimateDependenciesPM.attr('disabled',false);
		
		var dependentVars = dependencies.dependentVariables;
		
		// iterate over all dependent variables and mark them
		for (var v in dependentVars) {
			var A_UUID=dependentVars[v].A_UUID;
			if(		(A_UUID)									// variable is bound to attribute
				&& 	(A_UUID!=this.currentAttr_widget.A_UUID) 	// the variable is not the one that corresponds to the current attribute
				&& 	(A_UUID in this.attributeWidgetList)		// the variable's attribute is in the view
															){
				this.attributeWidgetList[A_UUID].markAsDependent();
			} // end if
		} // end for .. in
		
		
	} // end of method setCurrentAttr_widget
	,*/
	'markAllAttributes_normal' : function() {

		// display all attributes in normal style
		for (var attrUUID in this.attributeWidgetList)
			//if(this.attributeWidgetList[attrUUID].displayNormal)
				this.attributeWidgetList[attrUUID].markAsNormal();
	
	} // end of method displayAllAttributes_normal
	,/*
	highlightDependentAttributes : function (calledBy_attrWidget) {
	
		// display all attributes in normal style
		this.displayAllAttributes_normal();
		
		// highlight the dependent attributes
		var dependencies		= this.eqSolver.findDependencies(calledBy_attrWidget.A_UUID);
		var dependentAttrUUIDs	= dependencies.dependentVariables;
		var equations 			= dependencies.numberOfEquations;
		var numberOfVariables 	= dependencies.numberOfVariables;
		
		// get the number of dependent attributes with valid values
		var num_values=0;
		for(var variable in dependentAttrUUIDs) {
			var attrUUID=dependentAttrUUIDs[variable];
			if (this.attributeWidgetList[attrUUID].getCurrentValue()!=="") num_values++;;
		} // end for .. in
		
		var degreesOfFreedom = numberOfVariables - num_values;
		
		console.log('equations', equations);
		console.log('numberOfVariables', numberOfVariables);
		console.log('num_values', num_values);
		console.log('degreesOfFreedom', degreesOfFreedom);
		
		var determination = '';
		if 		(degreesOfFreedom<equations) 	determination='overdetermined'
		else if (degreesOfFreedom==equations) 	determination='determined'
		else									determination='underdetermined';

		for(var variable in dependentAttrUUIDs) {
			var attrUUID=dependentAttrUUIDs[variable];
			this.attributeWidgetList[attrUUID].highlight(determination, calledBy_attrWidget.id);
		} // end for .. in
		
	} // end of method hilightDependentAttributes
	,*/
	/*
	removeAllEstimatedValues : function () {
		
		// iterate over all attributes and remove estimated values
		for (var A_UUID in this.attributeWidgetList) if (this.attributeWidgetList[A_UUID].setEstimatedValue) this.attributeWidgetList[A_UUID].setEstimatedValue(null);
		
	} // end ofm method removeAllEstimatedValues
	,*/
	/*estimateDependencies : function () {
	
		var showDebugOutput = (arguments[0]?true:false);
	
		// console.log(this.declaredClass+':estimateDependencies');
		// console.log(this);
	
		if(!this.currentAttr_widget) return;
		
		// console.log(this.currentAttr_widget);
		var A_UUID=this.currentAttr_widget.A_UUID;
	
		// console.log(this.declaredClass+' :: estimateDependencies');
		var dependencies		= this.eqSolver.findDependencies(A_UUID);
		var attrValues 			= this.getCurrentAttributeValues();
		var results;
		try {
			this.eqSolver.set_attributeValues(attrValues);
			results = this.eqSolver.solve(dependencies.equations);
			// console.log('EqSolver results', results);
		} catch(e) {
			console.log("Equation solver error!");
			console.log( this.eqSolver.debugMessages);
			throw e;
		} // end try ... catch
		
		// remove all estimated values
		this.removeAllEstimatedValues();
		
		// set the changed attribute values
		if (results.newAttrValues) {
			this.setEstimatedAttributeValues(results.newAttrValues);
			
			this.menuItems.acceptEstimatedValues.attr('disabled',false);
		} // end if there are results
		
		if(showDebugOutput) application.estimationResults.show( ''
			+'\n<h2>Log</h2>\n\n<pre>'+results.log+'</pre>\n'
			//+'<hr/>'
			+'\n\n<h2>Debug log</h2>\n\n<pre>'+results.debug+'</pre>'
		);
		
	} // end of method estimateDependencies
	,
	acceptEstimatedValues : function() {
		
		// iterate over all attributes and accept the estimated values, if any
		for (var A_UUID in this.attributeWidgetList) 
			if (this.attributeWidgetList[A_UUID].acceptEstimatedValue) 
				this.attributeWidgetList[A_UUID].acceptEstimatedValue();
		
	} // end of method acceptEstimatedValues
	,
	*/
	'highlightTaggedAttributes' : function ( T_UUID ) {
		
		// iterate over all attributes ...
		for (var A_UUID in this.attributeWidgetList)
			// ... and highlight them if they are tagged with T_UUID
			this.attributeWidgetList[A_UUID].highlightIfTagged( T_UUID );
	
	} // end of method highlightTaggedAttributes
	,
	'attrFormsPartOfEQSystem' : function (A_UUID){
		// returns true, if the attribute with A_UUID forms part of an equation system
		return ((		(this.viewConfig.eqSolverIsActive)
					&&	('eqSolverConfig' in this.viewConfig)
					&&	('attrVarTable' in this.viewConfig.eqSolverConfig)
					&&	(A_UUID in this.viewConfig.eqSolverConfig.attrVarTable)
				) ? true : false );
	} // end of method attrFormsPartOfEQSystem
	,
	'setAttrsInVarGroupConstant' : function (varGroupName) {
	
		var varGroup = this.viewConfig.eqSolverConfig.varGroups[varGroupName];
		
		if(!typeof varGroup =='object') varGroup = {};
	
		// iterate over all attributes ...
		for (var A_UUID in this.attributeWidgetList) {
		
			// detect if the attribute forms part of the variable group
			var isInVarGroup = ((A_UUID && (A_UUID in varGroup))?true:false);
		
			// ... and set them constant of they are in the variable group varGroupName
			this.attributeWidgetList[A_UUID].setConstant( isInVarGroup );
		
		} // end for .. in
		
	} // end of method setAttrsInVarGroupConstant
	,	
	'executeSolver' : function (showDebugOutput) {
		
		var solverOutput 	= '';
		
		// clear the console
		console.clear();
		console.log('this.viewConfig.eqSolverConfig');
		console.log(this.viewConfig.eqSolverConfig);
		
		// read all current values, set all estimated values to ""
		var attrValues 			= {}, // A_UUID => {'keepConstant': true|false,'value':123.45}
			bindings			= '' // EQ Solver string
				+'# Variable bindings (generated automatically) ######\n'
			
		for (var A_UUID in this.viewConfig.eqSolverConfig.attrVarTable) {
		
			var varName 		= this.viewConfig.eqSolverConfig.attrVarTable[A_UUID];
		
			if(!varName) continue;
			
			var	w 				= this.attributeWidgetList[A_UUID],
				value 			= w.getCurrentValue(),
				keepConstant 	= w.isConstant(),
				A_name			= w.config.name;
			
			if((typeof value != 'undefined') && value.toString().length && !isNaN(value)) {
				attrValues[A_UUID] = {
					'keepConstant'	: keepConstant,
					'value'			: value
				};
			} // end if
			
			// add a variable binding
			bindings +='bind variable '+varName+' to ${'+A_UUID+'} # '+A_name+'\n';
			
		} // end for ... in attrWidgets
		
		
		// execute the solver
				
		var eqSolver		= new EquationSolver(),
			eqSystem		= this.viewConfig.eqSolverConfig.eqSystem,
			results			= {};
		
		console.log('Executing the equation solver');
		try {
			eqSolver.parameterise(''
				+bindings
				+'\n'
				+'# --------------------------------------------'
				+'\n'
				+'# Equation System (this forms part of the view configuration)\n'
				+eqSystem);
			eqSolver.parse();
			eqSolver.set_attributeValues(attrValues);
			eqSolver.identifyVariablesInEquations();
			results = eqSolver.solve();
			console.log('EqSolver results', results);
		} catch(e) {
			console.log("Equation solver error!");
			console.log(eqSolver.debugMessages);
			throw e;
		} // end try ... catch
		
		// set the changed attribute values
		if (results.newAttrValues) {
			
			for (var A_UUID in results.newAttrValues) {
				this.attributeWidgetList[A_UUID].setEstimatedValue(results.newAttrValues[A_UUID]);
			} // end for .. in
			
		} // end if there are results
		
		var solvabilityMessage = '',
			DoF = results.numVariables-results.numEquations;
		
		if (DoF==0) solvabilityMessage = T('views_genTmplWid.js/SolvMsgDoF_EQ0_TXT', 'The degree of freedom is <code>0</code>. There as as many variables as equations. If there is no error, everything was specified, correctly.');
		if (DoF<0) 	solvabilityMessage = T('views_genTmplWid.js/SolvMsgDoF_LT0_HTM', 'The degrees of freedom are <code>$[0]</code>. This means that there are less variables than equations. Have a look at the constants that appear in the equations with the biggest error. One or more of them should be variables.', [DoF]);
		if (DoF>0) 	solvabilityMessage = T('views_genTmplWid.js/SolvMsgDoF_GT0_HTM', 'The degrees of freedom are <code>$[0]</code>. The euqation system is underspecified. You need to set more constants, e.g. in the equations with the biggest error.', [DoF]);
		
		solverOutput +=''
				+'<h2>' + T('views_genTmplWid.js/SolvRes_TXT', 'The solver\'s results') + '</h2>\n'
				+'<h3>' + T('views_genTmplWid.js/RemError_TXT', 'Remaining Error') + '</h3>\n'
				+'<pre>R² = '+dojo.number.format(results.remainingError)+'</pre>\n'
				+'<h3>Jacobi Matrix</h3>'
				+'<p>'+solvabilityMessage+'</p>'
				+results.jacobiMatrix
				+'<h3>' + T('FUT_Iterations', 'Iterations') + '</h3>\n'
				+'<pre>'+dojo.number.format(results.iterations)+'</pre>\n'
				+'<h3>Log</h3>\n\n<pre>'+results.log+'</pre>\n'
				// +'<pre>'+dojo.toJson(results,true)+'</pre>\n'
			;
		
		// show the debug messages
		if(showDebugOutput) {
			solverOutput +=''
					+'<h2>' + T('views_genTmplWid.js/SlvrDbgLog_TXT', 'The solver\'s debug log') + '</h2>'
					+'<pre>'+results.debug+'</pre>'
				;
			
		} // end if showDebugOutput
		
		if(showDebugOutput || (results.remainingError >1e-6)) application.showMessage( T('views_genTmplWid.js/ResOfEstBySlvr_TXT', 'Results of the estimations by the equation solver'), solverOutput);
		
	} // end of method executeSolver
	,
});

