/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// the widget for calculations
dojo.declare('application.widgets.manageViews_viewEditor_CBRProperties', [application.widgets.manageViews_viewEditor_template],{
	
	// internal slots
	'_attrsInView' : null, // {}
	'_numIS'		: null, // unsigned natural number
	
	// Parent slot settings for the widget
	'title' 		: '', // will be set in the constructor
	'templateString': '<div dojoAttachPoint="containerNode" style="width:100%;height:100%;"></div>',
	
	// Widget life cycle
	'constructor' : function() {
		// Your constructor method will be called before the parameters are mixed into the widget, and can be used to initialize arrays, etc.
		// this.inherited(arguments);
		
		// some initialisations
		this.widgets 		= {};
		this.ISWidgets 		= {};
		this._numIS			= 0;
		
		// some translations
		this.title = T('viewConf_CBR.js/constructor_calcTitle_TIT', 'Case-based Reasoning');
		
	} // end of method constructor
	,
	'postMixInProperties' : function () {
		this.inherited(arguments);
		
		this.localiseValues(['CBRIsActive', 'CBRJSONConfig']);
		
		if 		(typeof this.CBRIsActive!='boolean') 	this.CBRIsActive	= false;
		if (	(typeof this.CBRJSONConfig!='string') 
			||	(!this.CBRJSONConfig.length)
			) 											this.CBRJSONConfig	= '{}';
		
		this.CBR_config = dojo.fromJson(this.CBRJSONConfig);
	
		// set-up the default CBR configuration, if necessary
		var defaultConfig = {
			// format:
			// 'slotName'							: defaultValue, ...
			'numberOfCandidateCasesForSimilarity'	: 50,
			'numberOfCandidateCasesForAdaptation'	: 10,
			'distanceThreshold'						: .5,
			'attrsForIdentifyingSimilarCases'		: [],
			'influenceMatrix'						: [],
		};
		// integrate the default configuration into the current one
		// this cannot be solved by dojo.saveMixin because already present values should not be overwritten
		for (var slotName in defaultConfig) {
			if ( !(slotName in this.CBR_config) ) this.CBR_config[slotName] = defaultConfig[slotName]; // defaultValue		
		} // end for ... in
				
	} // end of method postMixInProperties
	,
	'postCreate' : function () {
		this.inherited(arguments);
	
		// the border container for all contents
		this.widgets.BC = new dijit.layout.BorderContainer({
			'style'		: 'width:100%;height:100%;',
			'gutters'	: false,
		}).placeAt(this.containerNode);
	
		// the title pane
		this.widgets.topPane = new dijit.layout.ContentPane({
			'region'	: 'top',
			'style'		: 'margin:.25em',
			'content'	: ''
				+'<p>'
					+'<span class="activateCBRDOMNode"></span> '
					+'<span class="activateCBRMessage" style="cursor:pointer;">' 
						+ T(	'CBR_config.js/enableCBR_TXT',
								'Activate Case-based Reasoning for this view.'
							) 
					+ '</span>'
				+'</p>'
				+'<p>'
					+ T( 'CBR_config.js/generalInfoAboutCBR_TXT',
						 'Case-based reasoning (CBR) lets the users estimate an object\'s attribute value tuples by reusing attribute value tuples from similar objects.'
						 ) 
				+'</p>'
			,
		});
		this.widgets.BC.addChild(this.widgets.topPane);
		
		// place the checkbox for activating CBR
		this.widgets.activateCBRCheckBox = new dijit.form.CheckBox({
			'checked'	: this.CBRIsActive,
			'style'		: 'cursor:pointer',
		}).placeAt( dojo.query('.activateCBRDOMNode', this.widgets.topPane.containerNode ).pop() );
		this.connect( dojo.query('.activateCBRMessage', this.widgets.topPane.containerNode ).pop(),
						'onclick',
						'_activateCBRMessage_clicked');
		this.connect( this.widgets.activateCBRCheckBox, 'onChange', '_CBRIsActive_onChange' );
		
		// set the center pane with the main input widgets
		this.widgets.centerPane = new dijit.layout.ContentPane({
			'region'		: 'center',
			'style'			: 'padding:.25em',
			'content'		: ''
				
				+'<div style="">'
					+'<h3>'
						+T(	'viewConf_CBR.js/headIdentifySimilarCases_TXT',
							'Which attributes shall be used to identify similar cases?'
							)
					+'</h3>'
					+'<p>'
						+T(	'viewConf_CBR.js/identifySimilarCasesExpl_TXT',
							'If you do not select attributes here, all objects of the type will be considered for similarity assessment. In case you choose attributes, similar objects need to have the same attribute values as the object to be adapted.'
							)
					+'</p>'
					+'<div class="_attrsIdentifyingSimilarCases_domNode">LIST OF ATTRIBUTES FOR IDENTIFYING SIMILAR CASES</div>'
				+'</div>'
				
				+'<div style="">'
					+'<h3>'
						+T(	'viewConf_CBR.js/InfluenceSetsTitle_TXT', 
							'Influence Sets'
							)
					+'</h3>'
					
					+'<div class="dijitMenuBar">'
						+'<p class="_noISYet_domNode small dijitMenuItemDisabled">'
							+T( 'viewConf_CBR.js/notInfluenceSetYet_TXT', 
								'There are no influence sets, yet.'
								)
						+'</p>'
						+'<div class="_influenceSets_domNode">'
							// +'INFLUENCE SETS'
						+'</div>'
					+'</div>'
					+'<p>'
						+'<a class="_addNewInfluenceSet_domNode" style="cursor:pointer;">'
							+T( 'viewConf_CBR.js/addNewInfluenceSet_TXT', 
								'Add a new influence set.'
								)
						+'</a>'
					+'</p>'
					
					+'<p>'
						+T(	'viewConf_CBR.js/hintAssessSimilarity_TXT', 
							'Attributes for assessing similarity and attributes to be estimated need to have the following configuration:-'
							)
					+'</p>'
					
					+'<ul>'
						+T(	'viewConf_CBR.js/hintAssessSimilarityCriteria_HTM', 
							'<li>« <i>must be set</i>»  needs to be activated,</li> <li>The cardinality needs to be « <code>1</code>» ,</li> <li>There needs to be a <i>min</i> value and</li> <li>a <i>max</i> value.</li>'
							)
					+'</ul>'


				+'</div>'

				+'<div style="">'				
					+'<h3>'
						+T(	'viewConf_CBR.js/GeneralSettings_TXT',
							'General Settings'
							)
					+'</h3>'
					
					+'<table class="fullWidth listWithRows">'
					
						+'<tr>'
						+'<th width="33%">'
								+T(	'viewConf_CBR.js/SimilarityThreshold_TXT', 
									'What is the distance threshold for similarity?'
									)
							+'</th>'
							+'<td>'
								+'<div class="_similarityThreshold_domNode">SLIDER FOR SETTING THE SIMILARITY THRESHOLD</div>'
								+'<p class="small">'
									+T(	'viewConf_CBR.js/similarityThresholdHints_TXT', 
										'The similarity of two items is a value between <code>[0&nbsp;…&nbsp;1]</code> with 1 meaning that they their dependent attributes equal.Increasing the simuilarity threshold means that less objects will be taken into account for estimating dependent attributes.'
										)
								+'</p>'
							+'</td>'
						+'</tr>'
						
						+'<tr>'
							+'<th width="33%">'
								+T(	'viewConf_CBR.js/maxNumberOfCandidateCasesHeader_TXT', 
									'What is the maximum number of candidate cases for similarity assessment?'
									)
							+'</th>'
							+'<td>'
								+'<div class="_maxCandidateCasesSimilarity_domNode">INPUT BOX WITH INCREMENT/DECREMENT FUNCTIONALIY</div>'
								+'<p class="small">'
									+T(	'viewConf_CBR.js/maxNumberOfCandidateCasesHint_txt', 
										'This number is a compromise between performance and result quality: The more candidate cases are used for estimating dependent attributes, the better is the estimation quality. Using less candidate cases improves performance and the user-perceived response latency.'
										)
								+'</p>'
							+'</td>'
						+'</tr>'
						
						+'<tr>'
							+'<th width="33%">'
								+T(	'viewConf_CBR.js/maxNumberOfAdaptationCasesHeader_TXT', 
									'What is the maximum number of candidate cases for adaptation?'
									)
							+'</th>'
							+'<td>'
								+'<div class="_maxCandidateCasesAdaptation_domNode">INPUT BOX WITH INCREMENT/DECREMENT FUNCTIONALIY</div>'
								+'<p class="small">'
									+T(	'viewConf_CBR.js/maxNumberOfCandidateCasesAdpatationHint_txt', 
										'This number needs to be smaller than or equal to the maximum number of candidate cases for similarity assessment.'
										)
								+'</p>'
							+'</td>'
						+'</tr>'
						
					+'</table>'
					
				+'</div>'
				
		});
		this.widgets.BC.addChild(this.widgets.centerPane);
		
		// add slots for the DOM nodes
		dojo.forEach([
			'_attrsIdentifyingSimilarCases_domNode',
			'_similarityThreshold_domNode',
			'_influenceSets_domNode',
			'_noISYet_domNode',
			'_addNewInfluenceSet_domNode',
			'_maxCandidateCasesSimilarity_domNode',
			'_maxCandidateCasesAdaptation_domNode',
		], function (s) {
			this[s] = dojo.query( '.'+s, this.widgets.centerPane.containerNode ).pop();
		}, this);
		
		// create the widgets for the general settings
		
		this.widgets.similarityThreshold = new dijit.form.NumberSpinner({
			'constraints'			: {
					'min'			: 0,
					'max'			: 1,
					'places'		: 2,
				},
			'smallDelta'			: .05,
			'value'					: this.CBR_config.distanceThreshold,
			'intermediateChanges'	: true,
			'class'					: 'code',
		}).placeAt(this._similarityThreshold_domNode, 'only');
		this.connect(this.widgets.similarityThreshold, 'onChange', '_similarityThreshold_changed');
		
		this.widgets.maxCandidateCasesSimilarity = new dijit.form.NumberSpinner({
			'constraints'			: {
					'min'			: 10,
					'max'			: 500,
					'places'		: 0,
				},
			'smallDelta'			: 10,
			'value'					: this.CBR_config.numberOfCandidateCasesForSimilarity,
			'intermediateChanges'	: true,
			'class'					: 'code',
		}).placeAt(this._maxCandidateCasesSimilarity_domNode, 'only');
		this.connect(this.widgets.maxCandidateCasesSimilarity, 'onChange', '_maxCandCasesSimilarity_changed');
		
		this.widgets.maxCandidateCasesAdaptation = new dijit.form.NumberSpinner({
			'constraints'			: {
					'min'			: 10,
					'max'			: 500,
					'places'		: 0,
				},
			'smallDelta'			: 10,
			'value'					: this.CBR_config.numberOfCandidateCasesForAdaptation,
			'intermediateChanges'	: true,
			'class'					: 'code',
		}).placeAt(this._maxCandidateCasesAdaptation_domNode, 'only');
		this.connect(this.widgets.maxCandidateCasesAdaptation, 'onChange', '_maxCandCasesAdaptation_changed');
		
	} // end of method postCreate
	,
	'startup' : function() {
		this.inherited(arguments);
		this.widgets.BC.startup();
		
		// Connect methods
		this.connect( this._addNewInfluenceSet_domNode, 'onclick', '_newInfluenceSet_clicked' );
		this.connect( this, 'onShow', '_updateListOfAvailableAttributes' );
		
		this._showHide_noIsYetMessage();
	} // startup
	,
	/*'resize'  : function() {
		this.inherited(arguments);
			
	} // end of method resize
	,*/
	'destroy' : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		
		for (var i in this.widgets) {
			this.widgets[i].destroyRecursive();
			delete this.widgets[i];
		} // end for .. in
		
		for (var i in this.ISWidgets) {
			this.ISWidgets[i].destroyRecursive();
			delete this.ISWidgets[i];
		} // end for .. in
		
		this.inherited(arguments);
	} // end of method destroy
	,
	
	
	// Internal methods
	'_updateListOfAvailableAttributes' : function () {
	
		// this method is executed after the onShow event
	
		// get the list of available attributes
		delete this._attrsWithCBR;
		this._attrsWithCBR = this.dialogWidget.getListOfAttributesInCurrentView({
			'mustBeSet'		: true,
			'cardinality'	: 1,
			'kind'			: function (kind, attrObj) {
				return application.attributeKinds.supportsCBR(attrObj);
			} // end of test function
		});
		
		// iterate over all attributes an detect whether they have CBR methods
		delete this._attrsWithCBRStoreData;
		this._attrsWithCBRStoreData = {
			'identifier'	: 'UUID',
			'label'			: 'name',
			'items'			: [],
		};
		
		for (var A_UUID in this._attrsWithCBR) {
			this._attrsWithCBRStoreData.items.push( dojo.clone(this._attrsWithCBR[A_UUID]) );
		} // end for ... in
		
		
		
		// create a selection widget for the attributes that identify similar cases
		var attrsInView = this.dialogWidget.getListOfAttributesInCurrentView();
		for (var UUID in attrsInView) attrsInView[UUID] = attrsInView[UUID].name;
		
		if (this._attrsIdentifyingSimilarCases_onChangeHandle) {
			this.disconnect(this._attrsIdentifyingSimilarCases_onChangeHandle);
		} // end if
		if (this.widgets.attrsIdentifyingSimilarCases) {
			this.widgets.attrsIdentifyingSimilarCases.destroy();
			delete this.widgets.attrsIdentifyingSimilarCases;
		} // end if
		this.widgets.attrsIdentifyingSimilarCases = new common.widgets.sortableCheckList ({
			'itemList'			: attrsInView, 										// type: { 'UUID' : 'Item label/ name', 'UUID' : 'Item label/ name', 'UUID' : 'Item label/ name', ...}
			'checkedItems' 		: this.CBR_config.attrsForIdentifyingSimilarCases,	// type: [ 'UUID', 'UUID', 'UUID', ...]
		}).placeAt(this._attrsIdentifyingSimilarCases_domNode, 'only');
		
		this._attrsIdentifyingSimilarCases_onChangeHandle = this.connect ( this.widgets.attrsIdentifyingSimilarCases, 'onChange', '_attrsIdentifyingSimilarCases_changed');
		
		// instantiate existing influence sets
		for (var IS_UUID in this.ISWidgets) {
			this.ISWidgets[IS_UUID].destroy();
			delete this.ISWidgets[IS_UUID];
		} // end for .. in
		dojo.forEach( this.CBR_config.influenceMatrix, function (ISConfig) {
			this.__addInfluenceSetWidget(ISConfig);			
		}, this);
	
	} // end of method _updateListOfAvailableAttributes
	,
	'_CBRIsActive_onChange' : function () {
		this.CBRIsActive = this.widgets.activateCBRCheckBox.attr('checked');
		this.valueHasChanged('CBRIsActive');
	} // end of method _CBRIsActive_onChange
	,
	'_CBRConfig_onChange' : function () {
		this.CBRJSONConfig = dojo.toJson(this.CBR_config);
		// console.log( '_CBRConfig_onChange' );
		// console.log( dojo.toJson(this.CBR_config,true) );
		this.valueHasChanged('CBRJSONConfig');
	} // end of method _CBRIsActive_onChange
	,
	'_activateCBRMessage_clicked' : function () {
		// toggle the checked status of the activate-CBR-Checkbox
		var CBRStatus = this.widgets.activateCBRCheckBox.attr('checked');
		this.widgets.activateCBRCheckBox.attr('checked', !CBRStatus);
	} // end of method _activateCBRMessage_clicked
	,
	'__addInfluenceSetWidget' : function (ISConfig) {
	
		var IS 	= this.ISWidgets[ISConfig.IS_UUID] 
					= new application.widgets.CBRInfluenceSet ({
						'IS_UUID'			: ISConfig.IS_UUID,
						'ISconfig'			: ISConfig,
						'CBRAttrStore'		: new dojo.data.ItemFileWriteStore({
							'data'	: dojo.clone(this._attrsWithCBRStoreData)
							}),
						'attrsObjForLookUp'	: this._attrsWithCBR, // to avoid store.fetch ...
						
					}).placeAt(this._influenceSets_domNode);
		IS.startup(); // for some reason, this needs to be done, explicitly
	
		this.connect( IS, 'onRequestDelete', 				'_deleteIS' 		);
		this.connect( IS, 'influenceSet_repositioned', 		'_updateISConfig'	);
		this.connect( IS, 'influenceSetConfig_hasChanged',	'_updateISConfig' 	);

		this._numIS++;
		this._showHide_noIsYetMessage();
	
		this.showHideUpDownArrows();
	
	} // end of method __addInfluenceSetWidget
	,
	'_newInfluenceSet_clicked' : function (e) {
	
		dojo.stopEvent(e);
		
		// add a  widget for the new influence set
		var num_InfluenceSets	= Object.keys(this.ISWidgets).length;
			ISdefaultConfig 	= {
				'IS_UUID'		: Math.uuid(),
				'IS_name'		: T( 	'viewConf_CBR.js/newInfSetLabel_TXT', 
										'Influence set #$[0]',
										[num_InfluenceSets+1]
									),
				'dependencies'	: {},
				'AttrList'		: {},
		};
		
		this.__addInfluenceSetWidget(ISdefaultConfig);
		
	} // end of method _newInfluenceSet_clicked
	,
	'_deleteIS' : function (IS_UUID) {
		var IS = this.ISWidgets[IS_UUID];
		// this.widgets.influenceSetContainer.removeChild(IS);
		IS.destroy(false);
		delete this.ISWidgets[IS_UUID];
		
		this._numIS--;
		this._showHide_noIsYetMessage();

		this.showHideUpDownArrows();
		this._updateISConfig();
	} // end of method _deleteIS
	,
	'_showHide_noIsYetMessage' : function () {
		dojo.style(this._noISYet_domNode, 'display', ( (this._numIS<1) ? 'table' : 'none' ) );
	} // end of method _showHide_noIsYetMessage
	,
	'showHideUpDownArrows' : function () {
		for (var UUID in this.ISWidgets) this.ISWidgets[UUID]._showHideUpDownArrows();	
	} // end of method showHideUpDownArrows
	,
	'_updateISConfig' : function () {
		
		// delete the list of all influence sets in this.CBR_config
		delete this.CBR_config.influenceMatrix;
		
		// rebuild the list of influence sets from scratch
		this.CBR_config.influenceMatrix = [];
		
		var influenceWidgets = dijit.findWidgets(this._influenceSets_domNode);
		
		dojo.forEach(influenceWidgets, function(w) {
			this.CBR_config.influenceMatrix.push( w.getConfig() );		
		}, this);
		
		this._CBRConfig_onChange();
	} // end of method _updateISConfig
	,
	'_similarityThreshold_changed' : function () {
		if ( this.widgets.similarityThreshold.isValid() ) {
			this.CBR_config.distanceThreshold = this.widgets.similarityThreshold.attr('value');
			this._CBRConfig_onChange();
		} // end if
	} // end of method _similarityThreshold_changed
	,
	'_maxCandCasesSimilarity_changed' : function () {
		if ( this.widgets.maxCandidateCasesSimilarity.isValid() ) {
			this.CBR_config.numberOfCandidateCasesForSimilarity = this.widgets.maxCandidateCasesSimilarity.attr('value');
			this._CBRConfig_onChange();
		} // end if
	} // end of method '_maxCandCasesSimilarity_changed'
	,
	'_maxCandCasesAdaptation_changed' : function () {
		if ( this.widgets.maxCandidateCasesAdaptation.isValid() ) {
			this.CBR_config.numberOfCandidateCasesForAdaptation = this.widgets.maxCandidateCasesAdaptation.attr('value');
			this._CBRConfig_onChange();
		} // end if
	} // end of method '_maxCandCasesAdaptation_changed'
	,
	'_attrsIdentifyingSimilarCases_changed' : function (attrListAsArray) {
		this.CBR_config.attrsForIdentifyingSimilarCases = attrListAsArray;
		this._CBRConfig_onChange();
	} // end of method _attrsIdentifyingSimilarCases_changed
	,
});



dojo.declare( 'application.widgets.CBRInfluenceSet', [dijit._Widget, dijit._Templated], {
	
	// these slots need to be passed
	'ISconfig'			: null,	// {}
	'IS_UUID'			: null,	// UUID string
	'CBRAttrStore' 		: null,	// dojo.data.ItemFileWriteStore
	'attrsObjForLookUp'	: null, // {'A_UUID' : {...}, ... }
	
	// these slots are private
	'_dialogWidget' 	: null
	,
	'_dialogConnects'	: null
	,
	
	
	// properties of dijit._Widget, dijit._Templated
	'title'				: T(	'CBR_config.js/clickHereToEditIS_TIT',
								'Click here to edit this influence set.'
							),	
	'templateString'	: ''
		+'<table class="compact fullWidth" dojoAttachEvent="onmouseenter:_onHover,onmouseleave:_onUnHover">'
			+'<tr>'
				+'<td>'
					+'<a dojoAttachEvent="onclick:_editInfluenceSet_clicked" dojoAttachPoint="influenceSetName_domNode" style="cursor:pointer;">'
						// +'${influenceSet_name}'
					+'</a>'
				+'</td>'
				+'<td style="margin-left:1em;width:.5em;vertical-align:middle;">'
					+'<div dojoAttachPoint="upDownArrowBox_domNode" style="display:inline-block;height:1em;position:relative;">'
						+'<img src="./third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/arrow-up-3.png" class="RS_sortableCheckListUpDownBox" style="position:absolute;top:0;right:0;" dojoAttachPoint="_upButton_domNode" dojoAttachEvent="onclick:_upButtonClicked" title="Move this list item up."/>'
						+'<img src="./third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/arrow-down-3.png" class="RS_sortableCheckListUpDownBox" style="position:absolute;bottom:0;right:0;" dojoAttachPoint="_downButton_domNode" dojoAttachEvent="onclick:_downButtonClicked" title="Move this list item down."/>'
					+'</div>'
				+'</td>'
				+'<td style="text-align:center;width:1em;">'
					+'<img style="cursor:pointer;" width="12" '
						+'src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/bullet-delete.png" '
						+'dojoAttachPoint="_deleteButton_domNode" dojoAttachEvent="onclick:_deleteButton_clicked" '
						+'title="'
							+T('BTN_Delete','Delete')
						+'" /> '
				+'</td>'
			+'</tr>'
		+'</table>'
	,
	
	// widget life cycle
	'postCreate' : function () {
		this.inherited(arguments);
	
		dojo.attr( this.influenceSetName_domNode, 'innerHTML', this.ISconfig.IS_name );
		
	} // end of method postCreate
	,
	'startup' : function() {
		this.inherited(arguments);
				
		this._showHideUpDownArrows();
	} // end of method startup
	,
	'destroy' : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		
		this._deleteDialog();
		
		this.inherited(arguments);
	} // end of method destroy
	,
	
	
	// internal methods
	'_deleteButton_clicked' : function (e) {
		dojo.stopEvent(e);
		this._onUnHover();
	
		// trigger event
		this.onRequestDelete(this.IS_UUID);
	
	} // end of method _deleteButton_clicked
	,
	'_upButtonClicked' : function(e) {
		this._onUnHover();
		dojo.stopEvent(e);

		var previousNode	= this.domNode.previousSibling;
		
		if( previousNode /*&& dijit.byNode(previousNode)*/ ) {
			var previousWidget	= dijit.byNode(previousNode);
			this.placeAt(previousNode, 'before');
			this._showHideUpDownArrows();
			previousWidget._showHideUpDownArrows();
		} // end if 
		
		this.influenceSetRepositioned();
	} // end of method _upButtonClicked
	,
	'_downButtonClicked' : function(e) {
		this._onUnHover();
		dojo.stopEvent(e);
	
		var nextNode		= this.domNode.nextSibling;
		
		if( nextNode /*&& dijit.byNode(nextNode)*/ ) {
			var nextWidget		= dijit.byNode(nextNode);
			this.placeAt(nextNode, 'after');
			this._showHideUpDownArrows();
			nextWidget._showHideUpDownArrows();
		} // end if
		
		this.influenceSetRepositioned();
	} // end of method _downButtonClicked
	,
	'_showHideUpDownArrows' : function () {
		
		var previousNode	= this.domNode.previousSibling,
			nextNode 		= this.domNode.nextSibling;
		
		dojo.style( this._upButton_domNode, 	'display', (previousNode 	&& dijit.byNode(previousNode)	?'inline-block':'none') );
		dojo.style( this._downButton_domNode, 	'display', (nextNode 		&& dijit.byNode(nextNode)		?'inline-block':'none') );
		
	} // end of method _showHideUpDownArrows
	,
	'_editInfluenceSet_clicked' : function(e) {
		this._onUnHover();
	
		dojo.stopEvent(e);
		
		this.showDialog();
	} // end of method _editInfluenceSet_clicked
	,
	'_hoverclasses' : 'dijitReset dijitMenuItemSelected dijitMenuItemFocused dijitFocused'
	,
	'_onHover' : function() {
		dojo.addClass(this.domNode, this._hoverclasses);
	} // end of method _onHover
	,
	'_onUnHover' : function() {
		dojo.removeClass(this.domNode, this._hoverclasses);
	} // end of method _onUnHover
	,

	
	
	'showDialog' : function() {
		if (this._dialogWidget) this._deleteDialog(); // destroy a potentially existing dialog widget
		
		this._dialogWidget = new application.widgets.modifyInfluenceSetDialog({
			'IS_UUID'			: this.IS_UUID,
			'CBRAttrStore' 		: this.CBRAttrStore,
			'attrsObjForLookUp'	: this.attrsObjForLookUp,
			'ISconfig'			: this.ISconfig,
		});
		
		this.connect( this._dialogWidget, 'onExecute', '_onExecuteDialog' 	),
		
		this._dialogWidget.startup();
		this._dialogWidget.show();
		
	} // end-of-method showDialog
	,
	'getConfig' : function () {
		return this.ISconfig;
	} // end of method getConfig
	,
	
	
	'_closeDialog' : function() {
		this.dialogWidget.hide();
	} // end of method closeDialog
	,
	'_onExecuteDialog' : function( config ) {
		this.ISconfig = config;
		
		dojo.attr( this.influenceSetName_domNode, 'innerHTML', this.ISconfig.IS_name );
		
		this.influenceSetConfig_hasChanged ( );
	} // end-of-method execute
	,
	'_deleteDialog' : function () {
	
		dojo.forEach( this.dialogConnects, function (c) {
			dojo.disconnect(c);
		}, this);
		
		if(!this._dialogWidget) return;
		
		this._dialogWidget.destroyRecursive(false);
		this._dialogWidget.destroy();
		this._dialogWidget=null;
					
	} // end of method deleteDialog
	,
	
	
	
	
	// Events -----------------------------------------------------
	'onRequestDelete'				: function (IS_UUID) 		{},
	'influenceSet_repositioned'		: function () 				{},	
	'influenceSetConfig_hasChanged'	: function (){},	
});



dojo.declare('application.widgets.modifyInfluenceSetDialog',[common.widgets.fixedSizeDialog],{
	
	// these slots have values need to be passed when creating the widget
	'IS_UUID'			: null, // mandantory UUID STRING --- the UUID of the influence set
	'ISconfig' 			: null,	// {}
	'CBRAttrStore' 		: null,	// dojo.data.ItemFileWriteStore
	'attrsObjForLookUp'	: null, // {'A_UUID' : {...}, ... }
	
	
	// the following slots form internal variables / containers
	
	
	
	// settings of the parent class common.widgets.fixedSizeDialog
	'innerWidth'	: 800
	,
	'innerHeight'	: 600
	,
	
	
	
	// widget life cycle
	'constructor' : function () {
	
		// some initialisations	
		
		this.ISname = '';
		
		this.widgets 		= {};
		this._inflAttrs		= {};
		this._adaptAttrs	= {};
		
	} // end of method constructor
	,
	/*'postMixInProperties' : function () {
		this.inherited(arguments);
	
	} // end of method postMixInProperties
	,*/
	'buildRendering' : function () {
		this.inherited(arguments);
		
		this.widgets.BC = new dijit.layout.BorderContainer({
			'style'		: 'width:100%;height:100%;',
			'gutters'	: false,
		}).placeAt(this.containerNode);
	
	
		// button row & buttons ----------------------------------------
		this.widgets.buttonRow = new dijit.layout.ContentPane({
			'region'	: 'bottom',
			'style'		: 'padding-top:1.5em;',
		}).placeAt(this.widgets.BC);
	
		this.widgets.CancelButton = new dijit.form.Button({
			'label' 	: '<img width="12" src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/dialog-cancel-4.png"/> '
				+T('BTN_Cancel', 'Cancel'),
			'style'		: 'float:right;',
		}).placeAt(this.widgets.buttonRow.containerNode);
	
		this.widgets.OkButton = new dijit.form.Button({
			'label' 	: '<img src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/dialog-ok-apply-4.png"/> '
				+T('BTN_OK', 'OK'),
			// 'type'		: 'submit',
			// 'disabled'	: true,
			'style'		: 'float:right;',
		}).placeAt(this.widgets.buttonRow.containerNode);
		
		
		// influence set name pane
		this.widgets.influenceSetName_VTB = new dijit.form.ValidationTextBox({
			'content'				: '',
			'value'					: this.ISconfig.IS_name,
			'class'					: 'h4',
			'region'				: 'top',
			'selectOnClick'			: true,
			'title'					: ''
					+T(	'CBR_config.js/clickHeretoChangeName_TXT',
						'Click here to change the name of this influence set.'
						),
			'style'					: 'margin-bottom:.25em;',
			'intermediateChanges'	: true,
			'regExp'				: '.{2,}',
		}).placeAt(this.widgets.BC);
		this.connect( this.widgets.influenceSetName_VTB, 'onChange', '_influenceSetName_changed' );
		
		// set up a general separator pane for influencing and dependent attributes
		
		this.widgets.separatorPane = new dijit.layout.BorderContainer ({
			'region'	: 'center',
			'gutters'	: false,
		}).placeAt(this.widgets.BC);
		
		
		// set up the pane for dependent attributes
		
		this.widgets.dependenciesPane = new dijit.layout.BorderContainer({
			'region'	: 'left',
			'style'		: 'width:50%;padding-right:.25em;border-right:.1ex solid lightgrey;',
			'gutters'	: false,
		}).placeAt(this.widgets.separatorPane);
	
		this.widgets.dependenciesTitle = new dijit.layout.ContentPane ({
			'style'		: 'margin-bottom:0;padding-bottom',
			'content'	: ''
				+'<h5>'
					+T(	'CBR_config.js/inflAttrs_TIT',
						'Influencing attributes'
						)
				+'</h5>'

				+'<table class="fullWidth listWithRows" style="margin-bottom:0;">'
					+'<thead>'
						+'<tr>'
							+'<th>'
								+T(	'CBR_config.js/attrName_TXT',
									'Attribute Name'
								)
							+'<th>'
							+'<th style="width:10em;">'
								+T(	'CBR_config.js/simMethod_TXT',
									'Similarity Method'
								)
							+'<th>'
							+'<th style="width:3em;">'
								+T(	'CBR_config.js/weight_TXT',
									'Weight'
								)
							+'<th>'
							+'<th  style="width:1em;">'
								// +'Del?'
								+'&nbsp;'
							+'</th>'
						+'</tr>'
					+'</thead>'
				+'</table>'
				,
			'region'	: 'top',
		}).placeAt(this.widgets.dependenciesPane);
	
		this.widgets.influencingAttrPane = new dijit.layout.ContentPane({
			'region'	: 'center',
			'style'		: 'padding-top:0;margin-top:0;',
			'content'	: ''
				+'<table class="fullWidth listWithRows noSeparatorLine" style="border-top:0;margin-top:0;">'
					+'<tbody class="_influencingAttrList_domNode">'
					+'</tbody>'
				+'</table>'
		}).placeAt(this.widgets.dependenciesPane);
		this._influencingAttrList_domNode 	= dojo.query('tbody._influencingAttrList_domNode', this.widgets.influencingAttrPane.containerNode).pop();
		
		this.widgets.dependenciesNewAttrPane = new dijit.layout.ContentPane ({
			'region'	: 'bottom',
			'content'	: ''
				+'<table class="fullWidth compact">'
					+'<tr>'
						+'<td class="_newDependencyFS_domNode">'
							+T(	'CBR_config.js/attrListDD_TXT',
								'Attribute List as DropDown'
								)
						+'</td>'
						+'<td style="width:3em;" class="_newDependencyButton_domNode">+B</td>'
					+'</tr>'
				+'</table>'		
		}).placeAt(this.widgets.dependenciesPane);
		this._newDependencyFS_domNode 		= dojo.query('td._newDependencyFS_domNode', 	this.widgets.dependenciesNewAttrPane.containerNode).pop();
		this._newDependencyButton_domNode 	= dojo.query('td._newDependencyButton_domNode', this.widgets.dependenciesNewAttrPane.containerNode).pop();
		
		this.widgets.influencingAttrDD = new dijit.form.FilteringSelect({
			'class'	: 'fullWidth',
			'store'	:	this.CBRAttrStore,
		}).placeAt(this._newDependencyFS_domNode, 'only' );
		
		this.widgets.addInfluencingAttrButton = new dijit.form.Button({
			'label'		: ''
				+'<img width="12" src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/edit-add.png"/> '
				,
			'title'		: ''
				+T(	'CBR_config.js/addSelInflAttr_TXT',
					'Add the selected influencing attribute'
					),
		}).placeAt(this._newDependencyButton_domNode, 'only');

		
		// set up the pane for attributes to be adapted
	
		this.widgets.adaptationPane = new dijit.layout.BorderContainer({
			'region'	: 'center',
			'style'		: 'margin-left:.25em;',
			'gutters'	: false,
		}).placeAt(this.widgets.separatorPane);
	
		this.widgets.adaptationTitle = new dijit.layout.ContentPane ({
			'content'	: ''
				+'<h5>'
					+T(	'CBR_config.js/attrsToBeAdapted_TXT',
						'Attributes to be adapted'
						)				
				+'</h5>'

				+'<table class="fullWidth listWithRows" style="margin-bottom:0;">'
					+'<thead>'
						+'<tr>'
							+'<th>'
								+'Attribute Name'
							+'<th>'
							+'<th width="33%">'
								+'Adaptation Method'
							+'<th>'
							+'<th style="width:3em;">'
								+'&nbsp;'
							+'<th>'
							+'<th  style="width:1em;">'
								// +'Del?'
								+'&nbsp;'
							+'</th>'
						+'</tr>'
					+'</thead>'
				+'</table>'
				,
			'region'	: 'top',
			'style'		: 'padding-bottom:0;',
		}).placeAt(this.widgets.adaptationPane);
	
		this.widgets.adaptAttrPane = new dijit.layout.ContentPane({
			'region'	: 'center',
			'style'		: 'margin-top:0;padding-top:0;',
			'content'	: ''
				+'<table class="fullWidth listWithRows noSeparatorLine" style="margin-top:0;">'
					+'<tbody class="_adaptAttrList_domNode">'
					+'</tbody>'
				+'</table>',
		}).placeAt(this.widgets.adaptationPane);
		this._adaptAttrList_domNode 	= dojo.query('tbody._adaptAttrList_domNode', this.widgets.adaptAttrPane.containerNode).pop();
		
		this.widgets.adaptationNewAttrPane = new dijit.layout.ContentPane ({
			'region'	: 'bottom',
			'content'	: ''
				+'<table class="fullWidth compact">'
					+'<tr>'
						+'<td class="_newAdaptationAttr_domNode">Attribute List as DropDown</td>'
						+'<td style="width:3em;" class="_newAdaptAttrButton_domNode">+B</td>'
					+'</tr>'
				+'</table>'		
		}).placeAt(this.widgets.adaptationPane);;
		this._newAdaptationAttr_domNode 	= dojo.query('td._newAdaptationAttr_domNode', 	this.widgets.adaptationPane.containerNode).pop();
		this._newAdaptAttrButton_domNode 	= dojo.query('td._newAdaptAttrButton_domNode', 	this.widgets.adaptationPane.containerNode).pop();
	
		this.widgets.adaptAttrDD = new dijit.form.FilteringSelect({
			'class'	: 'fullWidth',
			'store'	:	this.CBRAttrStore,
		}).placeAt(this._newAdaptationAttr_domNode, 'only' );
		
		this.widgets.addAdaptAttrButton = new dijit.form.Button({
			'label'		: ''
				+'<img width="12" src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/edit-add.png"/> '
				,
			'title'		: ''
					+T(	'CBR_config.js/addAttrToBeAdapted_TXT',
						'Add the selected attribute that shall be adapted.'
						),
		}).placeAt(this._newAdaptAttrButton_domNode, 'only');
	
	
		// add influencing attributes as necessary
		for (var A_UUID in this.ISconfig.dependencies) {
			var inflAttrConfig = this.ISconfig.dependencies[A_UUID];
			this.__addInfluencingAttrToList( A_UUID, inflAttrConfig['function'], inflAttrConfig.weightPoints);
		} // end for .. in
		
		// add adaptable attributes as necessary
		for (var A_UUID in this.ISconfig.AttrList) {
			var adaptableAttrConfig = this.ISconfig.AttrList[A_UUID];
			this.__addAdaptableAttrToList( A_UUID, adaptableAttrConfig['function']);
		} // end for .. in
	
	} // end of method buildRendering
	,
	'startup' : function () {
		this.inherited(arguments);
	
		this.widgets.BC.startup();
	
		// set the widget title ...
		this.attr( 'title', T(	'viewConfiguration_CBR.js/CreateANewSType_TIT',
								'Modify the influence set «$[0]»',
								[this.ISconfig.IS_name]
								)
					);
	
		// it's time now for the connects ...
		this.connect( this.widgets.OkButton,				'onClick',	'_execute'					);
		this.connect( this.widgets.CancelButton,			'onClick',	'hide'						);
		this.connect( this.widgets.influenceSetName_VTB,	'onChange', '_influenceSetName_changed'	);
		
		this.connect( this.widgets.influencingAttrDD, 		'onChange', '_influencingAttrDD_changed');
		this.connect( this.widgets.addInfluencingAttrButton, 'onClick', '_addInfluencingAttr_clicked');
		
		this.connect( this.widgets.adaptAttrDD, 			'onChange', '_adaptableAttrDD_changed');
		this.connect( this.widgets.addAdaptAttrButton, 'onClick', 		'_addAdaptableAttr_clicked');
		
		// initialisations ...
		this._influencingAttrDD_changed();
		this._adaptableAttrDD_changed();
				
	} // end of method startup
	,
	'destroy' : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		
		for (var i in this.widgets) {
			if (this.widgets[i].destroyRecursive) this.widgets[i].destroyRecursive(false);
			delete this.widgets[i];
		} // end for .. in
		
		for (var i in this._inflAttrs) {
			if (this._inflAttrs[i].destroyRecursive) this._inflAttrs[i].destroyRecursive(false);
			delete this._inflAttrs[i];
		} // end for .. in
		
		for (var i in this._adaptAttrs) {
			if (this._adaptAttrs[i].destroyRecursive) this._adaptAttrs[i].destroyRecursive(false);
			delete this._adaptAttrs[i];
		} // end for .. in
		
		// this.inherited(arguments);
	} // end of method destroy
	,
	
	// internal methods
	'_influenceSetName_changed' : function (v) {
	
		if ( this.widgets.influenceSetName_VTB.isValid() ) {
			this.ISconfig.IS_name = this.widgets.influenceSetName_VTB.attr('value');
		} // end if
		
		this.attr( 'title', T(	'viewConfiguration_CBR.js/CreateANewSType_TIT',
								'Modify the influence set «$[0]»',
								[this.ISconfig.IS_name]
								)
					);
	} // end of method _influenceSetName_changed
	,
	'_execute' : function (e) {
		dojo.stopEvent(e);
		
		
		// gather the necessary information about the influencing attributes
		var sumWeightPoints = 0;
		
		delete this.ISconfig.dependencies;
		this.ISconfig.dependencies = {};
		
		for (var A_UUID in  this._inflAttrs) {
			this.ISconfig.dependencies[A_UUID] = this._inflAttrs[A_UUID].getSettings();
			sumWeightPoints += this.ISconfig.dependencies[A_UUID].weightPoints;
		} // end for ... in
		
		for (var A_UUID in  this._inflAttrs) {
			this.ISconfig.dependencies[A_UUID].weight = this.ISconfig.dependencies[A_UUID].weightPoints / sumWeightPoints;
		} // end for ... in
		
		
		// gather the necessary information about the attributes that undergo adaptation

		delete this.ISconfig.AttrList;
		this.ISconfig.AttrList = {};

		for (var A_UUID in  this._adaptAttrs) {
			this.ISconfig.AttrList[A_UUID] = this._adaptAttrs[A_UUID].getSettings();
		} // end for ... in
	
		// call the onExecute event and hide the dialog
		this.onExecute( this.ISconfig );
		this.hide();
	} // end of method _execute
	,
	'_influencingAttrDD_changed' : function (v) {
		this.widgets.addInfluencingAttrButton.attr( 'disabled', 
			!(		this.widgets.influencingAttrDD.isValid()
				&&	this.widgets.influencingAttrDD.attr('value')
				)
			);
	} // end of method _influencingAttrDD_changed
	,
	'_adaptableAttrDD_changed' : function (v) {
		this.widgets.addAdaptAttrButton.attr( 'disabled', 
			!(		this.widgets.adaptAttrDD.isValid()
				&&	this.widgets.adaptAttrDD.attr('value')
				)
			);
	} // end of method _influencingAttrDD_changed
	,
	'__addInfluencingAttrToList' : function ( A_UUID, /* optional */ similarityMethod, /* optional */ weight) {
	
		var attrConf			= this.attrsObjForLookUp[A_UUID],
			kind 				= attrConf.kind,
			attrName			= attrConf.name,
			similarityMethods 	= application.attributeKinds.getCBRSimilarityMethods(kind);
	
		// some default values
		if( !similarityMethod ) similarityMethod 	= Object.keys(similarityMethods)[0];
		if( !weight ) 			weight 				= 5;
	
		var iA = this._inflAttrs[A_UUID] = new application.widgets.CBRattr({
			'A_UUID'			: A_UUID, 
			'kind'				: kind,
			'attrName'			: attrName, 
			'methods'			: similarityMethods, 
			'method'			: similarityMethod, 
			'weight'			: weight,
		}).placeAt( this._influencingAttrList_domNode );
		this.connect( iA, 'CBRAttr_deleteRequested' , '_deleteInflAttr' );
	
	} // end of method __addInfluencingAttrToList
	,
	'_addInfluencingAttr_clicked' : function (e) {
		dojo.stopEvent(e);
	
		var A_UUID = this.widgets.influencingAttrDD.attr('value');
		
		if ( !A_UUID || (A_UUID in this.widgets) ) return;
	
		this.__addInfluencingAttrToList(A_UUID);	
	} // end of method _addInfluencingAttr_clicked
	,
	'__addAdaptableAttrToList' : function ( A_UUID, /* optional */ adaptationMethod) {
	
		var kind 				= this.attrsObjForLookUp[A_UUID].kind,
			attrName			= this.attrsObjForLookUp[A_UUID].name,
			adaptationMethods 	= application.attributeKinds.getCBRAdaptationMethods(this.attrsObjForLookUp[A_UUID].kind);
	
		// some default values
		if( !adaptationMethod ) adaptationMethod 	= Object.keys(adaptationMethods)[0];
	
		var iA = this._adaptAttrs[A_UUID] = new application.widgets.CBRattr({
			'A_UUID'			: A_UUID, 
			'kind'				: kind,
			'attrName'			: attrName, 
			'methods'			: adaptationMethods, 
			'method'			: adaptationMethod, 
		}).placeAt( this._adaptAttrList_domNode );
		this.connect( iA, 'CBRAttr_deleteRequested' , '_deleteAdaptAttr' );
	
	} // end of method __addAdaptableAttrToList
	,
	'_addAdaptableAttr_clicked' : function (e) {
		dojo.stopEvent(e);
	
		var A_UUID = this.widgets.adaptAttrDD.attr('value');
		
		if ( !A_UUID || (A_UUID in this.widgets) ) return;
	
		this.__addAdaptableAttrToList( A_UUID );
	
	} // end of method _addAdaptableAttr_clicked
	,
	'_deleteInflAttr' : function (A_UUID) {
	
		this._inflAttrs[A_UUID].destroy();
		delete this._inflAttrs[A_UUID];
	
	} // end of method _deleteInflAttr
	,
	'_deleteAdaptAttr' : function (A_UUID) {
	
		this._adaptAttrs[A_UUID].destroy();
		delete this._adaptAttrs[A_UUID];
	
	} // end of method _deleteAdaptAttr
	,
	
	
	
	// events
	'onExecute' : function ( config ) {},
	
});	// end of declaration application.widgets.createOTDialog
	


dojo.declare( 'application.widgets.CBRattr', [dijit._Widget, dijit._Templated], {
	
	// these parameters must be passed on instantiation
	'A_UUID'			: null, // UUID string
	'kind'				: null, // string
	'attrName'			: null, // string
	'methods'			: null, // { 'methodIdentifier' : 'methodName', ... }
	'method'			: null, // OPTIONAL methodIdentifier
	'weight'			: null, // OPTIONAL natural number 0<number<=10
	
	
	// internal variables
	'_widgets'			: null, // {}
	
	// parent widget settings
	'widgetsInTemplate'	: true,
	'templateString'	: ''
			+'<tr  dojoAttachPoint="containerNode">'
				+'<th title="${kind}">'
					+'${attrName}'
				+'</th>'
				+'<td style="width:33%;" dojoAttachPoint="_methodDD_domNode">'
					+'METHOD DropDown'
				+'</td>'
				+'<td style="width:3em;" dojoAttachPoint="_weight_domNode">'
					+'WEIGHT INPUT BOX'
				+'</td >'
				+'<td style="text-align:center;width:1em;">'
					+'<img style="cursor:pointer;" width="12" '
						+'src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/bullet-delete.png" '
						+'dojoAttachPoint="_deleteButton_domNode" dojoAttachEvent="onclick:_deleteButton_clicked" '
						+'title="'
							+T('BTN_Delete','Delete')
						+'" /> '
				+'</td>'
			+'</tr>'
		,
	
	// widget life cycle
	'constructor'	: function () {
	
		// initialisations
		this.A_UUID		= '';
		this.attrName	= '';
		this.methods	= {};
		this.method		= null;
		this.weight		= null;
		
		this._widgets	= {};
		
		this.title		= '';
	
	} // end of method constructor
	,
	'postCreate' : function () {
		this.inherited(arguments);
		
		// set up the method selector
		var options = [];
		for (var m in this.methods) {
			options.push({
				'value'		: m,
				'label'		: this.methods[m],
			});
		} // end for ... in
		
		// if no method is given: select the first one as default
		if( !this.method ) this.method = Object.keys(this.methods)[0];
		
		this._widgets.methodSelector = new dijit.form.Select({
			'class'		: 'fullWidth',
			'style'		: 'width:100%;',
			'options'	: options,
			'value'		: this.method,
		}).placeAt(this._methodDD_domNode, 'only');
		
		
		// set up the weight number spinner
		if (typeof this.weight == 'number') {
			this._widgets.weightNumberSpinner = new dijit.form.NumberSpinner({
				'constraints'			: {
						'min'			: 1,
						'max'			: 10,
						'places'		: 0,
					},
				'smallDelta'			: 1,
				'value'					: this.weight,
				'intermediateChanges'	: true,
				'class'					: 'code',
				'style'					: 'width:3em;',
			}).placeAt(this._weight_domNode, 'only');
		
		} else {
			dojo.attr( this._weight_domNode, 'innerHTML', '&nbsp;' );
		} // end if show number spinner
		
	} // end of method postCreate
	,
	'destroy' : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		
		for (var i in this._widgets) {
			this._widgets[i].destroyRecursive();
			delete this._widgets[i];
		} // end for .. in
		
		this.inherited(arguments);
	} // end of method destroy
	,
	
	
	// internal methods
	'_deleteButton_clicked' : function (e) {
		dojo.stopEvent(e);
		this.CBRAttr_deleteRequested(this.A_UUID);
	} // end of method _deleteButton_clicked
	,
	
	
	// External methods
	'getSettings'	: function () {
		var s = {
			'function'	: this._widgets.methodSelector.attr('value'),
		};
		
		if (typeof this.weight == 'number') {
			s.weightPoints	= this._widgets.weightNumberSpinner.attr('value');
		} // end if
		
		return s;
	} // end of method getSettings
	,
	
	
	// Events
	'CBRAttr_deleteRequested' : function (A_UUID) {},
	
});
