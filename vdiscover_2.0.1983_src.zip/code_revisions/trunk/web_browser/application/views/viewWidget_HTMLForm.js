﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare("application.widgets.HTMLFormView",[application.widgets.genericView],{
	'buildContent' : function(){
		var replaceWith = this.buildAttributeReplacementTable('embedded');
		var replaceCautiously=function(_,needle){
			if (needle in replaceWith) return replaceWith[needle];
			return '<span class="deleted">${'+needle+'}</span>';
		};
		var output = dojo.replace(this.viewConfig.content, replaceCautiously, /\$\{([^\}]+)\}/g );
		
		// create the DOM from the output string
		return dojo.create('div',{'innerHTML':output});
				
	} // end of method buildContent
});

// register all available menu bar options and the corresponding code
dojo.addOnLoad(function(){
	application.viewKinds.register({ name: T('viewWid_HTMLForm.js/HTMLForm_TIT', 'HTML Form'), 
		'kind'							: "cHTMLFormViewType", // class name in the backend
		'widgetClass'					: "application.widgets.HTMLFormView",
		'configurationWidgetClass'		: "cHTMLFormView",
		'mayBeUsedAsDescriptionTemplate': true,
		'hasCalculationFacilities'		: true,
		'hasCBRFacilities'				: true,
	});
}); // end dojo.addOnLoad