/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// dojo.require('application.widgets.manageViews_viewEditor_template');

dojo.declare('application.widgets.viewConfiguration.cHTMLFormView',[application.widgets.manageViews_viewEditor_template],{
	'defaultHTMLContent' : 'HTMLFormView.js/defaultHTMLContent_HTM' // will be set in the constructor
	,
	'constructor' : function() {
		// Your constructor method will be called before the parameters are mixed into the widget, and can be used to initialize arrays, etc.
		// this.inherited(arguments);
		
		this.defaultHTMLContent = ''
			+'<p>'
				+T(	'HTMLFormView.js/defaultHTMLContent_HTM',
					'<span style="background-color:pink;">There is no content, yet.</span>'
					)
			+'</p>';
		
	} // end of method constructor
	,
	'postMixInProperties' : function() {
		// If you provide a postMixInProperties method for your widget, 
		// it will be invoked before rendering occurs, and before 
		// any dom nodes are created. If you need to add or change the 
		// instance's properties before the widget is rendered 
		// - this is the place to do it.
		this.inherited(arguments);
		
		// localise all necessary properties
		
		this.localiseValues(['contentWithVariables','parentContentWithVariables']);
		
		if(!this.contentWithVariables) 		this.contentWithVariables		= this.defaultHTMLContent;
		if(!this.parentContentWithVariables) this.parentContentWithVariables= '';
		
		this.templateString=''
			+'<div>'
				+'<h3>'
					+T(	'HTMLFormView.js/postMixInProperties_templateString_HTM',
						'HTML template for the view contents'
					) 
				+'</h3>'
				+'<p>'
					+'<a dojoAttachEvent="onclick:editTemplate_clicked" style="cursor:pointer;">'
						+T(	'HTMLFormView.js/postMixInProperties_templateString_edit_LNK',
							'Click here to edit the template'
						)
					+'</a>.'
				+'</p>'
				
				+'<div dojoAttachPoint="viewTemplate_domNode" class="dijitTextBox DIN_A4_width" style="border-radius:.75em;margin-top:.25em;padding:.25em;"></div>'
				
			+(this.isInherited?''
					+'<h4>'
						+T(	'HTMLFormView.js/InherHTMLTempl',
							'Inherited HTML template'
							)
					+'</h4>'
					+'<p>'
						+'<a dojoAttachEvent="onclick:copyInheritedTemplate_clicked" style="cursor:pointer;">'
							+T(	'HTMLFormView.js/postMixInProperties_isInherited_LNK',
								'Click here use the inherited template for this view, as well'
								)
						+'</a>.'
					+'</p>'
					+'<div dojoAttachPoint="inheritedTemplate_domNode" class="dijitTextBox DIN_A4_width" style="border-radius:.75em;margin-top:.25em;padding:.25em;"></div>'
				:
					''
				)
			+'</div>';
		
		// build the attribute store
		this.attrStore = new dojo.data.ItemFileReadStore({
			'data'	: this.dialogWidget.getListOfAvailableAttributes(),
		});
		
	} // end of method postMixInProperties
	,
	/*buildRendering : function() {
		// dijit._Templated provides an implementation of buildRendering 
		// that most times will do what you need. The template is fetched/read, 
		// nodes created and events hooked up during buildRendering. The end 
		// result is assigned to this.domNode. If you don't mixin dijit._Templated 
		// (and most OOTB dijits do) and want to handle rendering yourself 
		// (e.g. to really streamline a simple widget, or even use a different 
		// templating system) this is where you'd do it.
		this.inherited(arguments);
	} // end of method buildRendering
	,*/
	'postCreate' : function() {
		// This is typically the workhorse of a custom widget. The widget has 
		// been rendered (but note that sub-widgets in the containerNode have not!). 
		// The widget though may not be attached to the DOM yet so you shouldn't 
		// do any sizing calculations in this method.
		this.inherited(arguments);
		
		// display the templates -- this needs to be carried out like this in order to display embedded content (pasted images), correctly
		dojo.attr(this.viewTemplate_domNode, 'innerHTML', this.contentWithVariables);
		if (this.isInherited) dojo.attr(this.inheritedTemplate_domNode, 'innerHTML', this.parentContentWithVariables);
		
	} // end of method postCreate
	,
	/*startup : function() {
		// If you need to be sure parsing and creation of any child widgets has 
		// completed, use startup. This is often used for layout widgets like 
		// BorderContainer. If the widget does JS sizing, then startup() should 
		// call resize(), which does the sizing.
		this.inherited(arguments);
	} // end of method startup
	,*/
    /*resize : function() {
		// All widgets that do JS sizing should have a method called resize(), that lays 
		// out the widget. Resize() should be called from startup() and will also be 
		// called by parent widgets like dijit.layout.ContentPane.
	}
	,*/
	/*destroy : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		this.inherited(arguments);
	} // end of method destroy
	*/
	'editTemplate_clicked' : function () {
		application.attributes.cMultiLineAttribute.showDialog({
			'calledByWidget'		: this, 
			'title'					: T('HTMLFormView.js/editTemplate_clicked_EditDialogTitle_TXT', 'Edit the HTML template for the view « $[0]» ', [this.name]), 
			'editText'				: this.contentWithVariables,
			'insertSpecialContent'	: function() {
				// this is here a Widget instance of application.widgets.Dialogs.HTMLEditor
		
				// create the variable pane
				this.widgets.variablePane = new dijit.layout.AccordionPane({
					'title'			: T('HTMLFormView.js/editTemplate_clicked_insertVariableTitle_TXT', 'Insert variables'), 
					'selected'		: true,
					'content'		: ''
						+'<p>'
							+T('HTMLFormView.js/editTemplate_clicked_insertVariablesP1_TXT', 'Available variables for the template:')
						+'</p>'
						,
					'style'			: 'padding-right:.5ex',
				});
				
				// fill the variable pane with widgets
				
				this.widgets.attributeCB = new dijit.form.ComboBox({
					'labelAttr' : 'name',
					'searchAttr': 'name',
					'labelType'	: 'html',
					'queryExpr' : '*${0}*',
					'disabled'	: this.calledByWidget.isInherited,
					'style'		: 'width:67%;',
					'store' 	: this.calledByWidget.attrStore,
					'scope'		: this
				});
				this.widgets.attributeCB.placeAt(this.widgets.variablePane.containerNode);

				this.widgets.attributeB = new dijit.form.Button({
					'label'		: ''
									+T('BTN_Insert', 'Insert'),
					'style'		: 'width:25%;',
					'disabled'	: this.calledByWidget.isInherited,
				});
				this.widgets.attributeB.placeAt(this.widgets.variablePane.containerNode);
				
				this.connect(this.widgets.attributeB, 'onClick', function(){
					var v = this.widgets.attributeCB.get('value');
					if(!v) return;
					this.widgets.editor.execCommand("inserthtml", '${'+v+'}');
				});
		
				this.widgets.insertContainer.addChild(this.widgets.variablePane);
			} // end of method insertSpecialContent
		});
	} // end of method editTemplate_clicked
	,
	'copyInheritedTemplate_clicked' : function () {
		this.notifyAttributeOfChangedValue(this.parentContentWithVariables);
	} // end of method editTemplate_clicked
	,
	'notifyAttributeOfChangedValue' : function (changedContent) {
		this.contentWithVariables=changedContent;
		dojo.attr(this.viewTemplate_domNode, 'innerHTML', this.contentWithVariables);
		this.valueHasChanged('contentWithVariables');
	} // end of method notifyAttributeOfChangedValue
	,
	
	
	
	'_getListOfUsedAttributes' : function () {

		// extract all attribute names from this.contentWithVariables
		var pattern = /\$\{([^\}]+)\}/gm,
			aNames	= this.contentWithVariables.match(pattern),
			attrList = [];
	
		// iterate over all aNames and get their UUID
		dojo.forEach(aNames, function(aNameString) {
			
			// strip the ${ ... } from the attribute name
			var aName	= aNameString.slice(2, aNameString.length-1),
				A_UUID	= '';
			
			// get the corresponding A_UUID from the store
			this.attrStore.fetch({
				'scope'	: this,
				'query'	: {'name' : aName},
				'onItem': function (item) {
					A_UUID = this.attrStore.getValue(item, 'UUID');
				} // end of method onItem
			});
			
			attrList.push(A_UUID);
			
		},this);
	
		return attrList;
	} // end of method _getListOfUsedAttributes
	,
});

