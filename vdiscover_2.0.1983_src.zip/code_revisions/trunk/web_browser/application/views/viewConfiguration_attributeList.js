/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// dojo.require('application.widgets.manageViews_viewEditor_template');

dojo.declare('application.widgets.viewConfiguration.cAttributeListView',[application.widgets.manageViews_viewEditor_template],{
	'availableAttributesStore' : null,
	'constructor' : function() {
		// Your constructor method will be called before the parameters are mixed into the widget, and can be used to initialize arrays, etc.
		
		// some initialisations
		this.widgets = {};
		
	} // end of method constructor
	,
	'postMixInProperties' : function() {
		// If you provide a postMixInProperties method for your widget, 
		// it will be invoked before rendering occurs, and before 
		// any dom nodes are created. If you need to add or change the 
		// instance's properties before the widget is rendered 
		// - this is the place to do it.
		
		this.inherited(arguments);
		
		// localise all necessary properties
		
		this.localiseValues(['attributeList', 'parentAttributeList', 'showEmptyAttributesInReadMode']);
		
		if (typeof this.showEmptyAttributesInReadMode == 'undefined') this.showEmptyAttributesInReadMode=true;
		this.hideEmptyAttributesInReadMode = !this.showEmptyAttributesInReadMode;
		
		if(typeof this.attributeList =='string')
			this.attributeList		= dojo.fromJson(this.attributeList);
		if(typeof this.parentAttributeList =='string')
			this.parentAttributeList= dojo.fromJson(this.parentAttributeList);
		
		if(!this.attributeList) 		this.attributeList		=[];
		if(!this.parentAttributeList) 	this.parentAttributeList=[];
		
		this.templateString = '<div>'
				+'<table class="fullWidth listWithRows arrangement3070">'
					
					// hideAttributesWithoutValueTuplesInReadMode
					+'<tr>'
						+'<th>'
							+T( 'attributeListView.js/postMixInProperties_templateString_Show_TXT',
								'Show attributes without value tuples in read mode?'
								)
						+'</th>'
						+'<td>'
							+'<div dojoType="dijit.form.Form">'
								+'<p><label><nobr>'
									+'<input type="radio" dojoType="dijit.form.RadioButton" '
										+'name="hideAttributesWithoutValueTuplesInReadMode" '
										+'value="1" '
										+'checked="${showEmptyAttributesInReadMode}"  '
										+'disabled="${isInherited}" '
										+'dojoAttachEvent="onChange:hideAttributesWithoutValueTuplesInReadMode_changed" '
										+'dojoAttachPoint="showAttributesWithoutValueTuplesInReadMode_widget" '
									+'/>&nbsp;'
									+T( 'FUT_Yes', 'Yes' )
								+'</nobr></label></p>'

								+'<p><label><nobr>'
									+'<input type="radio" dojoType="dijit.form.RadioButton" '
										+'name="hideAttributesWithoutValueTuplesInReadMode" '
										+'value="0" '
										+'checked="${hideEmptyAttributesInReadMode}"  '
										+'disabled="${isInherited}" '
									+'/>&nbsp;'
									+T( 'FUT_No', 'No' )
								+'</nobr></label></p>'
							+'</div>'
						+'</td>'
					+'</tr>'
					
				+'</table>'
					
				+'<h3>'
					+T( 'attributeListView.js/postMixInProperties_templateString_WhichAttr_TXT',
						'Which attributes shall this view display?'
						)
				+'</h3>'
				+'<div dojoAttachPoint="_displayTheseAttributesList_domNode"></div>'
				
				+(this.isInherited?''
					+'<p>&nbsp;</p>'
					+'<div dojoAttachPoint="_inheritedConfiguration_domNode">'
						+'<h4>'
							+T( 'attributeListView.js/postMixInProperties_isInherited_SelectedAttrParentView_TXT',
								'Selected Attributes of the parent view'
								)
						+'</h4>'
						+'<div dojoAttachPoint="_inheritedAttributesList_domNode"></div>'
						+'<p>&nbsp;</p>'
						+'<p>'
							+'<a dojoAttachPoint="_useInheritedAttributeList_domNode" dojoAttachEvent="onclick:revertToParentViewConfiguration_clicked">'
								+T( 'attributeListView.js/postMixInProperties_templateString_UseInherAttrList_TXT',
									'Use the inherited attribute list.'
									)
							+'</a>'
						+'</p>'
					+'</div>'
				:'')
			+'</div>';
		
	} // end of method postMixInProperties
	,
	'postCreate' : function() {
		// This is typically the workhorse of a custom widget. The widget has 
		// been rendered (but note that sub-widgets in the containerNode have not!). 
		// The widget though may not be attached to the DOM yet so you shouldn't 
		// do any sizing calculations in this method.
		this.inherited(arguments);
		
		// create the list of available attributes (with slot 'name', only)
		this._build_availableAttributeMap( 'name' ); // sets up this.availableAttributeMap
		
		// create the widget for choosing attributes
		this.widgets.attrSelector = new common.widgets.sortableCheckList({
			'itemList'			: this.availableAttributeMap,
			'checkedItems'		: this.attributeList,
			'checkedItemsLabel'	: ''
				+'<h4>'
					+T(	'attributeListView.js/_SelectedAttr_TXT',
						'Selected attributes'
						)
				+'</h4>',
			'uncheckedItemsLabel': ''
				+'<h4>'
					+T( 'attributeListView.js/_AvailableAttr_TXT',
						'Available attributes'
						)
				+'</h4>',
			'style'				: 'width:100%'
		}).placeAt(this._displayTheseAttributesList_domNode);
		this.connect( this.widgets.attrSelector, 'onChange', 'attrList_changed' );
		
		
		if (this.isInherited) {
			
			dojo.style( this._inheritedConfiguration_domNode, 'display', (this.isInherited?'block':'none') );
			
			// place a list of all selected attributes of the parent view into this._inheritedAttributesList_domNode
			var pVSelectedAttributes = [];
			
			dojo.forEach(this.parentAttributeList, function (UUID) {
				pVSelectedAttributes.push(this.availableAttributeMap[UUID]);
			}, this);
		
			dojo.attr(this._inheritedAttributesList_domNode, 'innerHTML', '<code>'+pVSelectedAttributes.join('<br/>')+'</code>');
		
			this.showHide_revertToInheritedConfig_message();
		
		} // end if
		
	} // end of method postCreate
	,
	'startup' : function () {
		this.inherited(arguments);
		
		this.widgets.attrSelector.startup();
	
	} // end of method startup
	,
	'destroy' : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		
		for (var i in this.widgets) {
			if (this.widgets[i].destroyRecursive) try{
				this.widgets[i].destroyRecursive();
			} catch(e) {
				console.error('Problem in '+this.declaredClass+'::destroy():\nWhen trying to delete subwidget "'+i+'", the following error was thrown:');
				console.error(e);
				console.log('this', this);
				console.log('this.widgets[i]', this.widgets[i]);
				dijit.registry.remove(this.widgets[i].id);
			} // end if .. try
			delete this.widgets[i];
		} // end for .. in
		
		this.inherited(arguments);
	} // end of method destroy
	,
	'showHide_revertToInheritedConfig_message' : function () {
		if (this.isInherited) {
			dojo.style( this._useInheritedAttributeList_domNode, 
						'display', 
						( 		( this.parentAttributeList.toString() == this.attributeList.toString() ) 
							? 	'none' 
							:	'block' 
						));
		} // end if
		
	} // end of method showHide_revertToInheritedConfig_message
	,
	'revertToParentViewConfiguration_clicked' : function () {
		
		// uncheck all options
		this.widgets.attrSelector.uncheckAll();
		
		// check all attributes of the parent view
		dojo.forEach (this.parentAttributeList, function (UUID){
			this.widgets.attrSelector.check(UUID);
		}, this);
		
	} // end of method revertToParentViewConfiguration_clicked
	,
	'attrList_changed' : function (attrUUIDS) {

		this.attributeList = dojo.toJson(attrUUIDS);
		this.valueHasChanged('attributeList');
		this.attributeList = attrUUIDS;
		
		this.showHide_revertToInheritedConfig_message();
		
	} // end of method attrList_changed
	,
	'hideAttributesWithoutValueTuplesInReadMode_changed' : function () {
		this.showEmptyAttributesInReadMode = this.showAttributesWithoutValueTuplesInReadMode_widget.get('checked');
		this.valueHasChanged('showEmptyAttributesInReadMode');
	} // end of method hideAttributesWithoutValueTuplesInReadMode_changed
	,
	
	
	'_getListOfUsedAttributes' : function () {
		return this.attributeList;
	} // end of method _build_availableAttributeMap
	,
});

