/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

//dojo.require('application.widgets.manageViews_viewEditor_template');

dojo.declare('application.widgets.viewConfiguration.cAllAttributesView',[application.widgets.manageViews_viewEditor_template],{
	/*constructor : function() {
		// Your constructor method will be called before the parameters are mixed into the widget, and can be used to initialize arrays, etc.
		this.inherited(arguments);
	} // end of method constructor
	,*/
	'postMixInProperties' : function() {
		// If you provide a postMixInProperties method for your widget, 
		// it will be invoked before rendering occurs, and before 
		// any dom nodes are created. If you need to add or change the 
		// instance's properties before the widget is rendered 
		// - this is the place to do it.
		
		this.inherited(arguments);
		
		// localise all necessary properties
		
		this.localiseValues(['showEmptyAttributesInReadMode']);
		
		if (typeof this.showEmptyAttributesInReadMode == 'undefined') this.showEmptyAttributesInReadMode=true;
		
		this.hideEmptyAttributesInReadMode = !this.showEmptyAttributesInReadMode;
		
		this.templateString = '<div>'
		
			+'<p>'
				+T( 'allAttributesView.js/postMixInProperties_attrListDescr_TXT', 
					'Views of the kind « Attribute List»  list all attributes of an object. Tis view gives an overview about an information object, but is less suitable for carrying out special tasks or summarising information.'
					)
			+'</p>'
		
			+(this.isInherited?''
					+'<p>'
						+T( 'allAttributesView.js/postMixInProperties_templateString_inherited_HTM', 
							'This view is <i>inherited</i>. It is defined at the object type « ${viewDefinedAt}» . Hence, certain properties need to be modified, there.'
							)
					+'</p>'
					+'<p>&nbsp;</p>'
				:'')
			
			+'<table class="fullWidth listWithRows arrangement3070">'
			
				// +'<tr>'
					// +'<th>'
						// +'Property'
					// +'</th>'
					// +'<th>'
						// +'Value'
					// +'</th>'
				// +'</tr>'

				// hideAttributesWithoutValueTuplesInReadMode
				+'<tr>'
					+'<th>'
						+T( 'allAttributesView.js/postMixInProperties_templateString_showAttributes_TXT',
							'Show attributes without value tuples in read mode?'
							)
					+'</th>'
					+'<td>'
						+'<div dojoType="dijit.form.Form">'
							+'<p><label><nobr>'
								+'<input type="radio" dojoType="dijit.form.RadioButton" '
									+'name="hideAttributesWithoutValueTuplesInReadMode" '
									+'value="1" '
									+'checked="${showEmptyAttributesInReadMode}"  '
									+'disabled="${isInherited}" '
									+'dojoAttachEvent="onChange:hideAttributesWithoutValueTuplesInReadMode_changed" '
									+'dojoAttachPoint="showAttributesWithoutValueTuplesInReadMode_widget" '
								+'/>&nbsp;'
								+T( 'FUT_Yes', 'Yes' )
							+'</nobr></label></p>'

							+'<p><label><nobr>'
								+'<input type="radio" dojoType="dijit.form.RadioButton" '
									+'name="hideAttributesWithoutValueTuplesInReadMode" '
									+'value="0" '
									+'checked="${hideEmptyAttributesInReadMode}"  '
									+'disabled="${isInherited}" '
								+'/>&nbsp;'
								+T( 'FUT_No', 'No' )
							+'</nobr></label></p>'
						+'</div>'
					+'</td>'
				+'</tr>'
				
			+'</table>'
			
			+'</div>' // end dijit.layout.ContentPane for General Properties
		
	} // end of method postMixInProperties
	,
	/*buildRendering : function() {
		// dijit._Templated provides an implementation of buildRendering 
		// that most times will do what you need. The template is fetched/read, 
		// nodes created and events hooked up during buildRendering. The end 
		// result is assigned to this.domNode. If you don't mixin dijit._Templated 
		// (and most OOTB dijits do) and want to handle rendering yourself 
		// (e.g. to really streamline a simple widget, or even use a different 
		// templating system) this is where you'd do it.
		this.inherited(arguments);
	} // end of method buildRendering
	,*/
	/*postCreate : function() {
		// This is typically the workhorse of a custom widget. The widget has 
		// been rendered (but note that sub-widgets in the containerNode have not!). 
		// The widget though may not be attached to the DOM yet so you shouldn't 
		// do any sizing calculations in this method.
		this.inherited(arguments);
	} // end of method postCreate
	,*/
	/*startup : function() {
		// If you need to be sure parsing and creation of any child widgets has 
		// completed, use startup. This is often used for layout widgets like 
		// BorderContainer. If the widget does JS sizing, then startup() should 
		// call resize(), which does the sizing.
		this.inherited(arguments);
	} // end of method startup
	,*/
    /*resize : function() {
		// All widgets that do JS sizing should have a method called resize(), that lays 
		// out the widget. Resize() should be called from startup() and will also be 
		// called by parent widgets like dijit.layout.ContentPane.
	}
	,*/
	/*destroy : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		this.inherited(arguments);
	} // end of method destroy
	*/
	'hideAttributesWithoutValueTuplesInReadMode_changed' : function () {
		this.showEmptyAttributesInReadMode = this.showAttributesWithoutValueTuplesInReadMode_widget.get('checked');
		this.valueHasChanged('showEmptyAttributesInReadMode');
	} // end of method hideAttributesWithoutValueTuplesInReadMode_changed
	,
	
	
	
	
	'_getListOfUsedAttributes' : function () {
		this._build_availableAttributeMap('name');
		var uAs = [];
		for (var UUID in this.availableAttributeMap) uAs.push(UUID);
		return uAs;
	} // end of method _build_availableAttributeMap
	,	
});

