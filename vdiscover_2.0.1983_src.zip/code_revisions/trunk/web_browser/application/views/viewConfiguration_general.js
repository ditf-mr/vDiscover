/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// the widget for the general view configuration
dojo.declare('application.widgets.manageViews_viewEditor_generalProperties', [application.widgets.manageViews_viewEditor_template],{
	/*constructor : function() {
		// Your constructor method will be called before the parameters are mixed into the widget, and can be used to initialize arrays, etc.
		this.inherited(arguments);
	} // end of method constructor
	,*/
	'postMixInProperties' : function () {
		this.inherited(arguments);

		// editing level
		this.editingLevel_0_checked	= 'false';
		this.editingLevel_1_checked	= 'false';
		this.editingLevel_2_checked	= 'false';
		switch (this.editingLevel) {
			case 1: // read only
				this.editingLevel_1_checked='true';
				break;
			case 2: // invisible
				this.editingLevel_2_checked='true';
				break;
			case 0: // visible and editable
			default:
				this.editingLevel_0_checked='true'; 
		} // end switch editing level
		
		this.viewTypeString		= application.viewKinds.viewKindList[this.kind].name;
		
		this.localiseValues(['mayBeUsedAsNameTemplate', 'isTemplateName', 'templateNameInherited', 'mayBeUsedAsDescriptionTemplate', 'isTemplateDescription', 'templateDescriptionInherited', ]);
		
		this.parentTemplate = (this.isTemplateName ?
				this.getParentNameTemplate()
			:
				this.getParentDescriptionTemplate()
			).name;
		
		this.templateString = '<div>' // this template is invalid without this DIV tag
					
			+(this.isInherited?''
					+'<p>'
						+T('viewConf_general.js/postMixInProperties_templateString_inherited_HTM', 'This view is <i>inherited</i>. It is defined at the parent object type « ${viewDefinedAt}» . Hence, certain properties need to be modified, there.')
					+'</p>'
					+'<p>&nbsp;</p>'
				:''
					+T('viewConf_general.js/postMixInProperties_templateString_editViewName_HTM', '<p>To edit the view&#39;s name, click on view name, above.</p>')
				)
			
			+'<table class="fullWidth listWithRows arrangement3070">'
							
				// View Type
				+'<tr>'
					+'<th>'
						+T('viewConf_general.js/ViewType_TXT', 'View Type')
					+'</th>'
					+'<td>'
						+'<pre>${viewTypeString}</pre>'
					+'</td>'
				+'</tr>'
				
			+(this.isInherited?''
					+'<tr>'
						+'<th>'
							+T('viewConf_general.js/InheritenceChain_TXT','Inheritance chain')
						+'</th>'
						+'<td>'
							+this.inheritanceChain.join(' '+this.dialogWidget.inheritedChar+' ')
							+this.dialogWidget.inheritedChar+' '
							+'${name}'
						+'</td>'
					+'</tr>'
				
					+'<tr>'
						+'<th>'
							+T('viewConf_general.js/DescrOfParentView_HTM','Description of the <i>parent</i> view')
						+'</th>'
						+'<td>'
							+'<textarea name="description" '
								+'dojoType="dijit.form.Textarea" '
								+'class="fullWidth" '
								+'disabled="true" '
								+'>${descriptionOfParentView}</textarea>'
						+'</td>'
					+'</tr>'
				:'')
				
				// Description
				+'<tr>'
					+'<th>'
						+(this.isInherited?''
                                +T('viewConf_general.js/DescriptionOfThisView_HTM', 'Description of <i>this</i> view')
                            : 	T('FUT_Description', 'Description') )
					+'</th>'
					+'<td>'
						+'<textarea name="description" '
							+'dojoType="dijit.form.Textarea" '
							+'class="fullWidth" '
							+'disabled="false" '
							+'dojoAttachPoint="descriptionOfThisView_widget" '
							+'intermediateChanges="true" '
							+'dojoAttachEvent="onChange:description_changed" '
							+'>${description}</textarea>'
							
			+(this.isInherited?''
						+'<p class="small">'
							+'<a style="cursor:pointer;" dojoAttachEvent="onclick:replaceDescrWithParentDescr">'
								+T('viewConf_general.js/ClickToReplaceDescription_LNK', 'Click here to replace this description with the parent view&#39;s description')
							+'</a>.'
						+'</p>'
				:'')
						
					+'</td>'
				+'</tr>'
				
				+'<tr>'
					+'<th>'
						+T('viewConf_general.js/ViewUUID', 'View UUID')
					+'</th>'
					+'<td>'
						+'<input type="text" value="${V_UUID}"'
							+'dojoType="dijit.form.ValidationTextBox" '
							+'class="fullWidth code" '
							+'selectOnClick="true" '
							+'readOnly="true" '
							+'/>'
					+'</td>'
				+'</tr>'
				
			+(this.mayBeUsedAsNameTemplate?''
				
				// Default name view
				+'<tr>'
					+'<th>'
						+T('viewConf_general.js/DefaultNameView_TXT','Default name view?')
					+'</th>'
					+'<td>'
						+'<p><label><input dojoType="dijit.form.CheckBox" checked="${isTemplateName}" dojoAttachEvent="onChange:isNameTemplate_changed" dojoAttachPoint="isNameTemplate_CB" /> '
							+T(	'viewConf_general.js/DefViewForOT_TXT',
								'This view is the default name view for this object type.'
								)
						+'</label></p>'
						+ (this.parentTemplate ? ''
								+'<p>' 
									+ T(	'viewConf_general.js/InherDefView_TXT',
											'The inherited default name view is « $[0]» .', 
											['${parentTemplate}' /* this will be replaced later by the dijit template engine */]
											)
								+'</p>'
							:
								''
							)
						// +( (this.isInherited && ('VT_UUID' in parentTemplate) && this.V_UUID==parentTemplate.VT_UUID) ?'<p>This view is the inherited default name view.</p>':'')
						// +( (this.isInherited && !this.templateNameInherited && ('name' in parentTemplate)) ?'<p>The inherited default name view is « '+parentTemplate.name+'» .</p>':'')
						+'<p class="small">' 
							+T(	'viewConf_general.js/DefNameViewOfObj_TXT',
								'The default name view of an object is used as the object name. It should contain all identifiers and be human-readable.'
								)
						+'</p>'
						+'<p class="small">'
							+ T('viewConf_general.js/AttrAsUniqueTip_HTM',
								'<strong>Hint</strong>: to use an attribute value as a "unique" identifier in the object name, prepend a unique letter to it. Example: the number attribute «Production lot»  has the value format <code>000000</code>. To be able to find lots directly, configure the default name view with e.g. <code>L${Production lot} …</code>. Then, searching e.g. for <code>L001234</code> leads directly to the object that describes the lot <code>001234</code>.'
								)
						+'</p>'
					+'</td>'
				+'</tr>'
				
			:'')
				
			+(this.mayBeUsedAsDescriptionTemplate?''
				
				// Default description view
				+'<tr>'
					+'<th>'
						+ T('viewConf_general.js/DefDescrView_TXT','Default description view?')
					+'</th>'
					+'<td>'
						+'<p><label>'
							+'<input dojoType="dijit.form.CheckBox" checked="${isTemplateDescription}" dojoAttachEvent="onChange:isDescriptionTemplate_changed" dojoAttachPoint="isDescriptionTemplate_CB" /> '
							+T(	'viewConf_general.js/DefDescrViewLbl_LBL', 
								'This view is the default description view for this object type.'
								) 
						+'</label></p>'
						+ (this.parentTemplate ? ''
								+'<p>'
									+T(	'viewConf_general.js/InherDefDescrView_TXT', 
										'The inherited default description view is « $[0]» .', 
										['${parentTemplate}' /* this will be replaced later by the dijit template engine */]
									)
								+ '</p>'
							:
								''
							)
						// +( (this.isInherited && ('VT_UUID' in parentTemplate) && this.V_UUID==parentTemplate.VT_UUID) ?'<p>This view is the inherited default description view.</p>':'')
						// +( (this.isInherited && !this.templateDescriptionInherited && ('description' in parentTemplate)) ?'<p>The inherited default description view is « '+parentTemplate.name+'» .</p>':'')
						+'<p class="small">'
							+T(	'viewConf_general.js/DefDescrViewHint_TXT',
								'The default description view of an object is displayed in the list of all objects. It should contain the most important (searched) attributes.'
								)
						+'</p>'
					+'</td>'
				+'</tr>'
				
			:'')
				
				+'<tr>'
					+'<th>'
						+ T('viewConf_general.js/SrchResPts_LBL','Search result points')
					+'</th>'
					+'<td>'
						+'<input dojoType="dijit.form.NumberSpinner" '
							+'value="${searchPoints}" '
							+'smallDelta="1" '
							+'constraints="{min:0,max:100,places:0}" '
							+'intermediateChanges="true" '
							+'dojoAttachEvent="onChange:searchPoints_changed" '
							+'dojoAttachPoint="searchPoints_widget" '
							+'class="fullWidth" '
							+'disabled="${isInherited}" '
						+'/>'
					+'</td>'
				+'</tr>'
				
				// Read & Edit <--- Editing Level
				+'<tr>'
					+'<th>'
						+ T('viewConf_general.js/Rd&Ed_TXT', 'Read & Edit')
					+'</th>'
					+'<td>'
						+'<div dojoType="dijit.form.Form">'
							+'<p><label>'
								+'<input type="radio" dojoType="dijit.form.RadioButton" '
									+'name="editingLevel" '
									+'value="0" '
									+'checked="${editingLevel_0_checked}"  '
									+'disabled="${isInherited}" '
									+'dojoAttachEvent="onClick:editingLevel_changed" '
									+'dojoAttachPoint="editingLevel_0" '
								+'/> '
								+ T('viewConf_general.js/VisAndEdit_LBL', 'visible and editable')
							+'</label></p>'

							+'<p><label>'
								+'<input type="radio" dojoType="dijit.form.RadioButton" '
									+'name="editingLevel" '
									+'value="1" '
									+'checked="${editingLevel_1_checked}"  '
									+'disabled="${isInherited}" '
									+'dojoAttachPoint="editingLevel_1" '
									+'dojoAttachEvent="onClick:editingLevel_changed" '
								+'/> '
								+ T('viewConf_general.js/VisAndRO_LBL', 'visible and read-only (e.g. for forms or reports to be printed)')
							+'</label></p>'

							+'<p><label>'
								+'<input type="radio" dojoType="dijit.form.RadioButton" '
									+'name="editingLevel" '
									+'value="2" '
									+'checked="${editingLevel_2_checked}"  '
									+'disabled="${isInherited}" '
									+'dojoAttachPoint="editingLevel_2" '
									+'dojoAttachEvent="onClick:editingLevel_changed" '
								+'/> '
								+ T('viewConf_general.js/Invis_LBL', 'invisible (e.g. for name views)')
							+'</label></p>'
						+'</div>'
					+'</td>'
				+'</tr>'
				
			+'</table>'
			
			+'</div>';
		
	} // end of method postMixInProperties
	,
	'isNameTemplate_changed' : function () {
		this.isTemplateName = this.isNameTemplate_CB.attr('checked');
		
		// tell the view dialog to reset the slot isTemplateName at all other views
		if (this.isTemplateName) this.resetConfigurationValue('isTemplateName', false);
		
		//this.set_isTemplateNameInherited();
		
		this.valueHasChanged('isTemplateName');
	} // end of method isNameTemplate_changed
	,
	/*'set_isTemplateNameInherited' : function () {
		 if (this.isInherited && ('VT_UUID' in parentTemplate) && this.V_UUID==parentTemplate.VT_UUID && this.isTemplateName) {
			this.templateNameInherited = true;
		} else {
			this.templateNameInherited = false;
		} // end if
	
		this.valueHasChanged('templateNameInherited');
	} // end of method set_isTemplateNameInherited
	,*/
	/*'set_isTemplateDescriptionInherited' : function () {
		 if (this.isInherited && ('VT_UUID' in parentTemplate) && this.V_UUID==parentTemplate.VT_UUID && this.isTemplateDescription) {
			this.templateDescriptionInherited = true;
		} else {
			this.templateDescriptionInherited = false;
		} // end if
	
		this.valueHasChanged('templateDescriptionInherited');
	} // end of method set_isTemplateNameInherited
	,*/
	'isDescriptionTemplate_changed' : function () {
		this.isTemplateDescription = this.isDescriptionTemplate_CB.attr('checked');

		// tell the view dialog to reset the slot isTemplateName at all other views
		if (this.isTemplateDescription) this.resetConfigurationValue('isTemplateDescription', false);

		//this.set_isTemplateDescriptionInherited();

		this.valueHasChanged('isTemplateDescription');
	} // end of method isDescriptionTemplate_changed
	,
	'description_changed' : function () {
		this.description = this.descriptionOfThisView_widget.attr('value');
		this.valueHasChanged('description');
	} // end of method name_changed
	,
	'replaceDescrWithParentDescr' : function (){
		this.descriptionOfThisView_widget.attr('value', this.descriptionOfParentView); // this triggers automatically the method description_changed
	} // end of method replaceDescrWithParentDescr
	,
	'editingLevel_changed' : function () {
		
		this.editingLevel = 0;
		
		if (this.editingLevel_2.attr('checked')) this.editingLevel = 2;
		if (this.editingLevel_1.attr('checked')) this.editingLevel = 1;
		if (this.editingLevel_0.attr('checked')) this.editingLevel = 0;
		
		this.valueHasChanged('editingLevel');
	} // end of method editingLevel_changed
	,
	'searchPoints_changed' : function () {
		if(this.searchPoints_widget.isValid()) {
			this.searchPoints = this.searchPoints_widget.attr('value');
			this.valueHasChanged('searchPoints');
		} // end if
	} // end of method searchPoints_changed
	,
});
