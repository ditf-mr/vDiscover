/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare("application.widgets.nameView",[application.widgets.genericView],{
	buildContent:function(r){

		var output = '';
		
		// special output in edit mode?
		if(this.edit) { // edit mode
		
			var template=dojo.replace(this.viewConfig.contentWithVariables, function(match,name,offset,templateString){
				return'« <em>'+name+'</em>» ';
			}, /\$\{([^\}]+)\}/g );
			
		
			var replaceWith = this.buildAttributeReplacementTable();
			var editAttrList = '<table class="fullWidth listWithRows compact">';
			dojo.forEach(this.viewConfig.attributeList,function(A_UUID){
				editAttrList += '<tr><th width="25%" class="textRight" style="vertical-align:baseline;">'+this.attributesWithValueSets[A_UUID].attribute.name+'</th><td>'+replaceWith[A_UUID]+'</td></tr>'
			},this); // end dojo.forEach
			editAttrList+='</table>';
		
			// replace all attribute UUIDs  with code for widget instantiation
			var editOutput = dojo.replace(editAttrList, replaceWith, /\$\{([^\}]+)\}/g );
		
			output = '<h3>' + T('nameView.js/buildContent_output_Templ_TXT', 'Template for the name:') + '</h3>'
						+'<p>'
							+template
						+'</p>'
					+'<h3>' + T('nameView.js/buildContent_output_EditAttrVal_TXT', 'Edit the attribute values:') + '</h3>'
						+editOutput;
		
		} else { // read mode
			var replaceWith = this.buildAttributeReplacementTable('embedded');
			output = dojo.replace(this.viewConfig.content, replaceWith, /\$\{([^\}]+)\}/g );
			if(this.displayEmbedded) {
				
				// the output needs to be a link to the target object, here
				var O_v_UUID=this.rA_valueTuple.atEndObject.object.O_v_UUID;
				output='<div dojoType="application.widgets.internalLink" O_v_UUID="'+O_v_UUID+'">'
						+output
					+'</div>';
			} // end if embedded
		} // end if in edit mode

		return dojo.create((this.displayEmbedded?'span':'div'),{innerHTML:output});
	} // end of method buildContent
});

// register all available menu bar options and the corresponding code
dojo.addOnLoad(function(){
	application.viewKinds.register({ 'name' : T('nameView.js/Name_TIT', 'Name'),
		'kind'						: "cNameViewType",
		'widgetClass'				: "application.widgets.nameView",
		'configurationWidgetClass'	: "cNameView",
		'mayBeUsedAsNameTemplate' 	: true,
		'is_default_view' 			: true,
		'hasCalculationFacilities'	: false,
		'hasCBRFacilities'			: false,
	});
}); // end dojo.addOnLoad