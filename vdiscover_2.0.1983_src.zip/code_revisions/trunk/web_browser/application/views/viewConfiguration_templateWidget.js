/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// the template widget for any kind of view configuration widget
dojo.declare('application.widgets.manageViews_viewEditor_template', [dijit._Widget,dijit._Templated],{
	'V_UUID'			: 'this value needs to be replaced on instantiation',
	'dialogWidget'		: null, // needs to be passed
	'widgetsInTemplate'	: true,
	'templateString' 	: '',
	'valueHasChanged' : function (slotName) {
		if(!(slotName in this)) throw {'message':'View configuration:valueHasChanged there is no slot called"'+slotName+'" in this object.'};
		// console.log(this.declaredClass+'::valueHasChanged(\''+slotName+'\')',this[slotName]);
		this.dialogWidget.valueHasChanged(this.V_UUID, slotName, this[slotName]);
	} // end of method valueHasChanged
	,
	'localiseValues' : function (propertyArray) {
		dojo.forEach(propertyArray,function(property){
			this[property]=this.dialogWidget.getPropertyValue(this.V_UUID, property);
		},this);
	} // end of method localiseValues
	,
	'resetConfigurationValue'	: function (slotName, value) {
		this.dialogWidget.resetConfigurationValue(slotName, value);
	} // end of method resetConfigurationValue
	,
	'getParentNameTemplate' : function () {
		return this.dialogWidget.parentNameTemplate;
	} // end of method getParentNameTemplate
	,
	'getParentDescriptionTemplate' : function () {
		return this.dialogWidget.parentDescriptionTemplate;
	} // end of method getParentNameTemplate
	,
	
	
	
	
	'_build_availableAttributeMap' : function (restrictMapToSlot) {
		var l = this.dialogWidget.getListOfAvailableAttributes().items;
		
		this.availableAttributeMap={};
		
		dojo.forEach(l, function (i) {
			this.availableAttributeMap[i.UUID] = dojo.clone(restrictMapToSlot?i[restrictMapToSlot]:i);
		}, this);
		
		delete l;
	} //end of method _build_availableAttributeMap
	,
	'_getListOfUsedAttributes' : function () {
		// This method returns all attributes that are used in a view. It needs to be implemented, only, in specific views.
		var msg = this.declaredClass+'::_getListOfUsedAttributes() called, This method needs to be implemented!';
		alert (msg);
		console.error(msg);
		return [];
	} // end of method _build_availableAttributeMap
	,	
	'lookupAttrProperty' : function (A_UUID, p, defaultValue) {
		if(typeof defaultValue=='undefined') defaultValue='';
		if(!this.availableAttributeMap) this._build_availableAttributeMap();
		if (	!(A_UUID in this.availableAttributeMap)
			||  !(p in this.availableAttributeMap[A_UUID])
			) return defaultValue;
		return this.availableAttributeMap[A_UUID][p];
	} // end of method lookupAttrProperty
	,
});

