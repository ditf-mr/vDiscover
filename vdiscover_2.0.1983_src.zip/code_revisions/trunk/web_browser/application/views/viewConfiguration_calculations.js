/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// the widget for calculations
dojo.declare('application.widgets.manageViews_viewEditor_calculationProperties', [application.widgets.manageViews_viewEditor_template],{
	'title' 		: '', // will be set in the constructor
	'templateString': '<div dojoAttachPoint="containerNode" style="width:100%;height:100%;"></div>',
	'constructor' : function() {
		// Your constructor method will be called before the parameters are mixed into the widget, and can be used to initialize arrays, etc.
		this.inherited(arguments);
		
		// some initialisations
		this.widgets 		= {};
		this.attrVarWidgets = {};
		this.varGroupWidgets= {};
		
		// some translations
		this.title = T( 'viewConf_calc.js/constructor_calcTitle_TIT', 'Calculations' );
		
	} // end of method constructor
	,
	'postMixInProperties' : function () {
		this.inherited(arguments);
		
		this.localiseValues(['eqSolverIsActive', 'eqSolverJSONConfig']);
		
		if		(typeof this.eqSolverIsActive!='boolean') 	this.eqSolverIsActive	= false;
		if(		(typeof this.eqSolverJSONConfig!='string') 
			|| 	(!this.eqSolverJSONConfig.length)
			) 	this.eqSolverJSONConfig	= '{}';
		
		this.eqSolverConfig = dojo.fromJson(this.eqSolverJSONConfig);
	
		// set the default eqSolver configuration if necessary
		if (!('showUnusedAttributes' in this.eqSolverConfig)) this.eqSolverConfig = {
			'showUnusedAttributes'	: true,
			'attrVarTable'			: {},
			'eqSystem'				: ''
				+'\n'
				+ /*T('viewConf_calc.js/EqSysEdTip_1_TXT',*/'# Equation system editor\n'/*)*/
				+'\n'
				+ /*T('viewConf_calc.js/EqSysEdTip_2_TXT',*/'# Place your equations, here. Example:\n'/*)*/
				+'\n'
				+ /*T('viewConf_calc.js/EqSysEdTip_3_TXT',*/'# Doppler equation --- see http://en.wikipedia.org/wiki/Doppler_equations \n'/*)*/
				+ /*T('viewConf_calc.js/EqSysEdTip_4_TXT',*/'f * (c + v_s) = f_0 * (c + v_r)\n'/*)*/
				+'\n'
				+ /*T('viewConf_calc.js/EqSysEdTip_5_TXT',*/'# with\n'/*)*/
				+ /*T('viewConf_calc.js/EqSysEdTip_6_TXT',*/'#   f   --- observed frequency\n'/*)*/
				+ /*T('viewConf_calc.js/EqSysEdTip_7_TXT',*/'#   f_0 --- emitted frequency\n'/*)*/
				+ /*T('viewConf_calc.js/EqSysEdTip_8_TXT',*/'#   c   --- velocity of waves in the medium\n'/*)*/
				+ /*T('viewConf_calc.js/EqSysEdTip_9_TXT',*/'#   v_r --- receiver velocity, positive if moving towards the source\n'/*)*/
				+ /*T('viewConf_calc.js/EqSysEdTip_10_TXT',*/'#   v_s --- source velocity, positive if moving away from the receiver\n'/*)*/
				+'\n'
				+ /*T('viewConf_calc.js/EqSysEdTip_11_TXT',*/'# You need to either set constants for these variables\n# or to assign these variables to attributes.\n'/*)*/
		};
		if( !('varGroups' in this.eqSolverConfig)) this.eqSolverConfig.varGroups = {};
	
		this.initialEQSystem = dojo.clone(this.eqSolverConfig.eqSystem);
	
	} // end of method postMixInProperties
	,
	'postCreate' : function () {
		this.inherited(arguments);
	
		// the border container for all contents
		this.widgets.BC = new dijit.layout.BorderContainer({
			'style'		: 'width:100%;height:100%;',
			'gutters'	: false,
		}).placeAt(this.containerNode);
	
		// the title pane
		this.widgets.topPane = new dijit.layout.ContentPane({
			'region'	: 'top',
			'style'		: 'margin:.25em',
			'content'	: ''
				+'<p>'
					+'<span class="activateSolverDOMNode"></span> '
					+'<span class="activateSolverMessage" style="cursor:pointer;">'
						+T( 'viewConf_calc.js/ActEqSolver_TXT',
							'Activate the equation solver for this view'
							)
					+'</span>'
					+'&nbsp;'
					+'&nbsp;'
					+'&nbsp;'
					+'&nbsp;'
					+'&nbsp;'
					+'<span class="showHideAttrsWithoutVarDOMNode"></span> '
					+'<span class="showHideAttrsWithoutVarMessage" style="cursor:pointer;">'
						+T( 'viewConf_calc.js/ShwUnusedAttr_TXT',
							'Show unused attributes'
							)
					+'</span>'
				+'</p>'
				+'<h3>'
					+T( 'viewConf_calc.js/AttrVarBnd_TXT',
						'Attribute-variable bindings'
						)
				+'</h3>'
			,
		});
		this.widgets.BC.addChild(this.widgets.topPane);
		
			// place the checkbox for activating the equation solver
			this.widgets.activateSolverCheckBox = new dijit.form.CheckBox({
				'checked'	: this.eqSolverIsActive,
				'style'		: 'cursor:pointer',
			}).placeAt( dojo.query('.activateSolverDOMNode', this.widgets.topPane.containerNode ).pop() );
			this.connect( dojo.query('.activateSolverMessage', this.widgets.topPane.containerNode ).pop(),
							'onclick',
							'_activateSolverMessage_clicked');
			this.connect( this.widgets.activateSolverCheckBox, 'onChange', '_eqSolverIsActive_onChange' );
	
			// place the checkbox for showing/ hiding unused attributes
			this.widgets.showHideUnusedAttrsCheckBox = new dijit.form.CheckBox({
				'checked'	: true,
				'style'		: 'cursor:pointer',
			}).placeAt( dojo.query('.showHideAttrsWithoutVarDOMNode', this.widgets.topPane.containerNode ).pop() );
			this.connect( dojo.query('.showHideAttrsWithoutVarMessage', this.widgets.topPane.containerNode ).pop(),
							'onclick',
							'_showHideUnusedAttributes_clicked');
			this.connect(this.widgets.showHideUnusedAttrsCheckBox, 'onChange', '_showUnusedAttributes_onChange') ;
		// the bottom pane
		
		this.widgets.bottomPane = new dijit.layout.BorderContainer({
			// 'style'		: 'width:100%;height:10em;',
			// 'region'	: 'bottom',
			'region'	: 'center',
			'gutters'	: false,
			'design'	: 'sidebar',
		});
		this.widgets.BC.addChild(this.widgets.bottomPane);
		
		this.widgets.eqSystemTA = new dijit.form.SimpleTextarea({
			'region'	: 'center',
			'value'		: this.eqSolverConfig.eqSystem,
			'class'		: 'code small',
			'style'		: 'margin:.25em;margin-top:0;padding: 0.25em;',
		});
		this.widgets.bottomPane.addChild(this.widgets.eqSystemTA);
		this.connect( this.widgets.eqSystemTA, 'onChange', '_eqSystem_onChange');
	
		this.widgets.bottomPaneTitle = new dijit.layout.ContentPane({
			'region'	: 'top',
			'content' : ''
				+'<h3>' + T('viewConf_calc.js/EquSystem_TXT','Equation System') + '</h3>'
			,
			'style'		: 'margin:.25em',
		});
		this.widgets.bottomPane.addChild(this.widgets.bottomPaneTitle);
		
		this.widgets.eqSolverMenuBar = new dijit.MenuBar({
			'region'	: 'top',
			'style'		: 'margin:.25em;margin-bottom:0;border-bottom:0;',
		});
		this.widgets.bottomPane.addChild(this.widgets.eqSolverMenuBar);
		
			this.widgets.showHideSolverManual  = new dijit.MenuBarItem ({
				'label'	: T('viewConf_calc.js/HideManual_MNU','Hide manual'),
				'style'	: 'float:right;',
			});
			this.widgets.eqSolverMenuBar.addChild(this.widgets.showHideSolverManual);
			this.connect( this.widgets.showHideSolverManual, 'onClick', 'showHideSolverManual' );
		
			this.widgets.solveMBI  = new dijit.MenuBarItem ({
				'label'	: T('viewConf_calc.js/Solve_MNU','Solve'),
			});
			this.widgets.eqSolverMenuBar.addChild(this.widgets.solveMBI);
			this.connect( this.widgets.solveMBI, 'onClick', 'solve' );
		
			this.widgets.solveWithDebugMBI  = new dijit.MenuBarItem ({
				'label'	: T('viewConf_calc.js/SolveWDbg_MNU','Solve with debug output'),
			});
			this.widgets.eqSolverMenuBar.addChild(this.widgets.solveWithDebugMBI);
			this.connect( this.widgets.solveWithDebugMBI, 'onClick', 'solveWithDebugOutput' );
		
			this.widgets.resetEQSMBI  = new dijit.MenuBarItem ({
				'label'	: T('viewConf_calc.js/Reset_MNU','Reset'),
			});
			this.widgets.eqSolverMenuBar.addChild(this.widgets.resetEQSMBI);
			this.connect( this.widgets.resetEQSMBI, 'onClick', 'resetEQSystem' );
		
		this.widgets.solverManual = new dijit.layout.ContentPane({
			'class'		: 'small',
			'href'		: './third_party_libraries/Multidimensional_Equation_Solver/hints.php',
			'region' 	: 'right',
			'style'		: 'width:30em;padding:.5ex;overflow-y:auto;',
			'parseOnLoad': true,
			'splitter' 	: true,
		});
		this.widgets.bottomPane.addChild(this.widgets.solverManual);
		
		// the center pane
		
		
		// The menu bar for the variable groups
		this.widgets.varGroupMenuBar = new dijit.MenuBar ({
			'region'	: 'top',
			'style'		: 'margin:.5ex;margin-bottom:0;border-bottom:0;padding-top:.25em;',
			'title'		: T('viewConf_calc.js/VarGrpMnuBar_MNU','Click on a variable group to set all of its members constant.'),
		});
		this.widgets.BC.addChild(this.widgets.varGroupMenuBar);
		
		dojo.create('SPAN', {
				'innerHTML': '<strong>' + T('viewConf_calc.js/VarGrps_TXT','Variable groups') + '</strong>',
				'class': 'dijitReset dijitInline dijitMenuItemLabel dijitMenuItem'
			}, 
			this.widgets.varGroupMenuBar.containerNode
		);
		
		this.widgets.newVarGroupForm = new dijit.form.Form({
			'style'		: 'width:12.5em;float:right;text-align:right;',
			'onSubmit'	: function() {
				return false;
			} // end of method onSubmit
		});
		this.widgets.varGroupMenuBar.addChild(this.widgets.newVarGroupForm);
		this.connect( this.widgets.newVarGroupForm, 'onSubmit', 'createNewVarGroup' );
		
		this.widgets.newVarGroupInputBox = new dijit.form.ValidationTextBox({
			'value' 				: '',
			'placeHolder'			: T('viewConf_calc.js/NewVarGrp_TXT','New variable group'),
			'regExp'				: '.{3,}',
			'style'					: 'width:8.5em;text-align:left;',
			'intermediateChanges'	: true,
		}).placeAt(this.widgets.newVarGroupForm.containerNode);
		this.connect( this.widgets.newVarGroupInputBox, 'onChange', 'enableDisable_newVarGroupButton' );
		
		this.widgets.newVarGroupButton = new dijit.form.Button({
			'type'		: 'submit',
			'title'		: T('BTN_create','create'),
			'disabled' 	: true,
			'label'		: ''
				+'<img style="vertical-align:middle;cursor:pointer;" src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/edit-add.png"/>'
			,
			// 'style'			: 'width:10em;',
		}).placeAt(this.widgets.newVarGroupForm.containerNode);
		
		// create the variable group widgets
		for (var varGroupName in this.eqSolverConfig.varGroups) {
			this.createMenuItemForVarGroup(varGroupName);
		} // end for .. in
		
		/*
		this.widgets.tagsMBToolTip = new common.widgets.Tooltip ({
			'label'		: T('viewConf_calc.js/postCreate_tagToolTip_HTM', 'Click on a tag to set its value <i>constant</i>.'),
			'connectId'	: this.widgets.varGroupMenuBar.containerNode,
			'position'	: ['above'],
		});
		*/

		// the attribute-variable table
		var decimalChar = dojo.i18n.getLocalization("dojo.cldr", "number", dojo.i18n.normalizeLocale()).decimal,
			colGroup = ''
					+'<colgroup>'
						+'<col width="20%"/>'
						+'<col width="10%"/>'
						+'<col width="10%" align="center"/>'
						+'<col width="10%" align="center"/>'
						+'<col width="10%" align="'+decimalChar+'"/>'
						+'<col width="10%" align="center"/>'
						+'<col width="20%"/>'
					+'</colgroup>'
			;
		
		this.widgets.centerPaneHeading = new dijit.layout.ContentPane ({
			'region'	: 'top',
			'style'		: 'margin-left:.5ex;margin-right:.5ex;padding:.5ex;padding-bottom:0;padding-right:17px;padding-left:0;margin-bottom:0;border-bottom:0;',
			'class'		: 'dijitMenuBar compact',
			'content'	: ''
				+'<table class="listWithRows">'
					+colGroup
					+'<thead>'
						+'<tr>'
							+'<th>'
								+ T('viewConf_calc.js/AttrName_TXT','Attribute name')
							+'</th>'
							+'<th>'
								+ T('FUT_Variable','Variable')
							+'</th>'
							+'<th class="textCenter">'
								+ T('viewConf_calc.js/TestVal_TXT','Test Value')
							+'</th>'
							+'<th class="textCenter">'
								+ T('viewConf_calc.js/Const?','const?')
							+'</th>'
							+'<th>'
								+ T('FUT_Result','Result')
							+'</th>'
							+'<th class="textCenter">'
								+ T('FUT_Unit','Unit')
							+'</th>'
							+'<th>'
								+ T('viewConf_calc.js/VarGrps_TXT','Variable groups')
							+'</th>'
						+'</tr>'
					+'</thead>'
				+'</table>'
		});
		this.widgets.BC.addChild(this.widgets.centerPaneHeading);
		
		this.widgets.centerPane = new dijit.layout.ContentPane ({
			// 'region'	: 'center',
			'region'	: 'top',
			'class'		: 'dijitMenuBar',
			'splitter'	: 'true',
			'style'		: 'margin:.5ex;margin-top:0;padding:.5ex;padding-top:0;border-top:0;height:10em;overflow-y:scroll',
			'content'	: ''
				+'<table class="fullWidth listWithRows compact">'
					+colGroup
					+'<tbody class="attrListNode">'
					+'</tbody>'
				+'</table>'
		});
		this.widgets.BC.addChild(this.widgets.centerPane);
		this.attrListNode = dojo.query('.attrListNode', this.widgets.centerPane.containerNode).pop();
		this.connect(this, 'onShow', 'updateAttributeList');
		
		this.widgets.centerPaneToolTip = new common.widgets.Tooltip ({
			'label'		: T('viewConf_calc.js/postCreate_centerPaneToolTip_HTM', '<p>You may assign to each listed attribute a variable that appears in the equation system, below. To test the entered equation system, set a test value. In case that you set the variable constant, the test value will be treated as fixed, otherwise, the variable value will be estimated. In the latter case, an entered test value will be treated as a starting value for the solver.</p>'),
			'connectId'	: this.widgets.centerPane,
			'position'	: ['left'],
		});
		
	} // end of method postCreate
	,
	'startup' : function() {
		this.inherited(arguments);
		this.widgets.BC.startup();
		this.widgets.bottomPane.startup();
	} // startup
	,
	'resize'  : function() {
		this.inherited(arguments);
		
		var headerTableNode		= dojo.query( 'table', this.widgets.centerPaneHeading.containerNode	).pop(),
			contentTableNode	= dojo.query( 'table', this.widgets.centerPane.containerNode		).pop(),
			
			contentTableWidth	= Math.round(dojo.style( contentTableNode, 'width'));
	
		dojo.style(headerTableNode, 'width', contentTableWidth+'px');
	
	} // end of method resize
	,
	'destroy' : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		
		for (var i in this.widgets) {
			this.widgets[i].destroyRecursive();
			delete this.widgets[i];
		} // end for .. in
		
		for (var i in this.attrVarWidgets) {
			this.attrVarWidgets[i].destroyRecursive();
			delete this.attrVarWidgets[i];
		} // end for .. in
		
		for (var i in this.varGroupWidgets) {
			this.varGroupWidgets[i].destroyRecursive();
			delete this.varGroupWidgets[i];
		} // end for .. in
		
		this.inherited(arguments);
	} // end of method destroy
	,
	'_activateSolverMessage_clicked' : function(e){
		dojo.stopEvent(e);
		var status = this.widgets.activateSolverCheckBox.attr('checked') ? true : false;
		this.widgets.activateSolverCheckBox.attr('checked', !status);
	} // end of method _activateSolverMessage_clicked
	,
	'_showHideUnusedAttributes_clicked' : function(e){
		dojo.stopEvent(e);
		var status = this.widgets.showHideUnusedAttrsCheckBox.attr('checked') ? true : false;
		this.widgets.showHideUnusedAttrsCheckBox.attr('checked', !status);
	} // end of method _showHideUnusedAttributes_clicked
	,
	
	
	'updateAttributeList' : function () {
		var attrs = this.dialogWidget.getListOfAttributesInCurrentView({
				// 'mustBeSet'		: true,
				'cardinality'	: 1,
			}),
			updateUUID = Math.uuid();
		
		// create / mark all attrVarWidgets that need to be shown
		for (var A_UUID in attrs) {
			if (this.lookupAttrProperty(A_UUID, 'kind')=='cNumberAttribute') {
				
				// attribute-variable bindings
				if ( !(A_UUID in this.attrVarWidgets) 
					) {
					this.attrVarWidgets[A_UUID] = new application.widgets.manageViews_CalcProperty_attr({
						'parentWidget'	: this,
						'A_UUID'		: A_UUID,
						'varName'		: (		(A_UUID in this.eqSolverConfig.attrVarTable)
											?	this.eqSolverConfig.attrVarTable[A_UUID]
											:	''),
					}).placeAt(this.attrListNode);
					
					this.connect(this.attrVarWidgets[A_UUID], 'varName_changed', 'varName_changed');
					
					// tell the attrVarWidget to which var groups it belongs to
					for (var varGroupName in this.eqSolverConfig.varGroups) {
						if (A_UUID in this.eqSolverConfig.varGroups[varGroupName])
							this.attrVarWidgets[A_UUID].addToVarGroup(varGroupName);
							
					} // end for .. in
					
				} // end if
				// set the update UUID to ensure that the attrVarWidget is actual
				this.attrVarWidgets[A_UUID].updateUUID = updateUUID;
				
			} // end if 
		}; // end for ... in
		
		// remove all attrVarWidgets that are obsolete
		for (var A_UUID in this.attrVarWidgets) 
			if (this.attrVarWidgets[A_UUID].updateUUID!=updateUUID) {
				this.attrVarWidgets[A_UUID].destroyRecursive();
				delete this.attrVarWidgets[A_UUID];
		} // end if / for .. in
	
		this.resize();
	} // end of method updateAttributeList
	,
	
	
	'solve' : function (e) {
		this.executeSolver();
		dojo.stopEvent(e);
	} // end of method solve
	,
	'solveWithDebugOutput' : function (e) {
		this.executeSolver('debug');
		dojo.stopEvent(e);
	} // end of method solveWithDebugOutput
	,
	'resetEQSystem' : function () {
		this.widgets.eqSystemTA.attr('value', this.initialEQSystem);
	} // end of method resetEQSystem
	,
	'showHideSolverManual' : function () {
		var isChild = (this.widgets.bottomPane.getIndexOfChild(this.widgets.solverManual) >= 0) ? true : false;
		if (isChild) {
			this.widgets.showHideSolverManual.attr('label', 
				T('viewConf_calc.js/showManual_MNU','Show manual')
			);
			this.widgets.bottomPane.removeChild(this.widgets.solverManual);
		} else {
			this.widgets.showHideSolverManual.attr('label', 
				T('viewConf_calc.js/HideManual_MNU','Hide manual')
			);
			this.widgets.bottomPane.addChild(this.widgets.solverManual);
		} // end if
	} // end of method showHideSolverManual
	,
	'setAttrVarssInVarGroupConstant' : function (varGroupName) {
		
		// iterate over all this.attrVarWidgets and set them variable
		var noGroup = '';
		for (var A_UUID in this.attrVarWidgets) {
			this.attrVarWidgets[A_UUID].setConstantIfInVarGroup(noGroup);
		} // end for ... in
		
		//iterate over all this.attrVarWidgets and set them constant if necessary
		for (var A_UUID in this.eqSolverConfig.varGroups[varGroupName]) {
			if(A_UUID in this.attrVarWidgets) this.attrVarWidgets[A_UUID].setConstantIfInVarGroup(varGroupName);
		} // end for ... in
		
	} // end of method setAttrVarssInVarGroupConstant
	,
	'_eqSolverIsActive_onChange' : function () {
		this.eqSolverIsActive = this.widgets.activateSolverCheckBox.attr('checked');
		this.valueHasChanged('eqSolverIsActive');
	} // end of method _eqSolverIsActive_onChange
	,
	'_showUnusedAttributes_onChange' : function () {
	
		this.eqSolverConfig.showUnusedAttributes = this.widgets.showHideUnusedAttrsCheckBox.attr('checked');
		
		//iterate over all this.attrVarWidgets[A_UUID] and show/ hide them as necessary
		for (var A_UUID in this.attrVarWidgets) {
			this.attrVarWidgets[A_UUID].showIfUnused(this.eqSolverConfig.showUnusedAttributes);
		} // end for ... in
	
		this._eqSolverConfigHasChanged();
	} // end of method _showUnusedAttributes_onChange
	,
	'_eqSolverConfigHasChanged' : function () {
		this.eqSolverJSONConfig = dojo.toJson(this.eqSolverConfig);
		this.valueHasChanged('eqSolverJSONConfig');		
	} // end of method _eqSolverConfigHasChanged
	,
	'_eqSystem_onChange' : function () {
		this.eqSolverConfig.eqSystem = this.widgets.eqSystemTA.attr('value');
		this._eqSolverConfigHasChanged();
	} // end of method _eqSystem_onChange
	,
	'varName_changed' : function (A_UUID, varName) {
	
		// store the changed variable name
		if( (!varName) && (A_UUID in this.eqSolverConfig.attrVarTable)) delete this.eqSolverConfig.attrVarTable[A_UUID];
		if (varName) this.eqSolverConfig.attrVarTable[A_UUID]=varName;
		
		// store the changes
		this._eqSolverConfigHasChanged();
	} // end of method _varName_changed
	,
	'executeSolver' : function (showDebugOutput) {
		
		var solverOutput 	= '';
		
		// clear the console
		console.clear();
		
		// read all current values, set all estimated values to ""
		var attrValues 			= {}, // A_UUID => JavaScript numerical value
			bindings			= ''; // EQ Solver string
			
		for (var A_UUID in this.attrVarWidgets) {
		
			var w 				= this.attrVarWidgets[A_UUID],
				varName 		= w.attr('varName');
		
			// reset the result of the attribute value
			w.setEstimatedValue('&mdash;');
		
			if(!varName) continue;
			
			var	value 			= w.attr('value'),
				keepConstant 	= w.attr('isConstant'),
				A_name			= w.attr('A_name');
			
			if((typeof value != 'undefined') && value.toString().length && !isNaN(value)) {
				attrValues[A_UUID] = {
					'keepConstant'	: keepConstant,
					'value'			: value
				};
			} // end if
			
			// add a variable binding
			bindings +='bind variable '+varName+' to ${'+A_UUID+'} # '+A_name+'\n';
			
		} // end for ... in
		
		// execute the solver
				
		var //A_UUID 			= this.vTEditorWidget.config.A_UUID,
			eqSolver		= new EquationSolver(),
			eqSystem		= this.eqSolverConfig.eqSystem// this.widgets.EquationEditor.attr('value'),
			results			= {};
			
		try {
			eqSolver.parameterise(''
				+bindings
				+'\n'
				+'# --------------------------------------------'
				+'\n'
				+'\n'
				+eqSystem);
			eqSolver.parse();
			eqSolver.set_attributeValues(attrValues);
			eqSolver.identifyVariablesInEquations();
			results = eqSolver.solve();
			console.log('EqSolver results', results);
		} catch(e) {
			console.log("Equation solver error!");
			console.log(eqSolver.debugMessages);
			throw e;
		} // end try ... catch
		
		// set the changed attribute values
		if (results.newAttrValues) {
			
			for (var A_UUID in results.newAttrValues) {
				
				this.attrVarWidgets[A_UUID].setEstimatedValue(results.newAttrValues[A_UUID]);
				
			} // end for .. in
			
		} // end if there are results
		
		var solvabilityMessage = '',
			DoF = results.numVariables-results.numEquations;
		if (DoF==0) solvabilityMessage = T('viewConf_calc.js/DoF_IS0_HTM','The degree of freedom is <code>0</code>. There as as many variables as equations. If there is no error, everything was specified, correctly.');
		if (DoF<0) 	solvabilityMessage = T('viewConf_calc.js/DoF_LT0_HTM','The degrees of freedom are <code>$[0]</code>. This means that there are less variables than equations. Have a look at the constants that appear in the equations with the biggest error. One or more of them should be variables.', [DoF]);
		if (DoF>0) 	solvabilityMessage = T('viewConf_calc.js/DoF_GT0','The degrees of freedom are <code>$[0]</code>. The euqation system is underspecified. You need to set more constants, e.g. in the equations with the biggest error.', [DoF]);
		
		solverOutput +=''
				+'<h2>' + T('viewConf_calc.js/SlvrRes_TXT','The solver\'s results') + '</h2>\n'
				+'<h3>' + T('viewConf_calc.js/RemErr_TXT','Remaining Error') + '</h3>\n'
				+'<pre>R² = '+dojo.number.format(results.remainingError)+'</pre>\n'
				+'<h3>' + T('viewConf_calc.js/jacobiMatrxi_TXT','Jacobi Matrix') + '</h3>'
				+'<p>'+solvabilityMessage+'</p>'
				+results.jacobiMatrix
				+'<h3>' + T('FUT_Iterations','Iterations') + '</h3>\n'
				+'<pre>'+dojo.number.format(results.iterations)+'</pre>\n'
				+'<h3>Log</h3>\n\n<pre>'+results.log+'</pre>\n'
				// +'<pre>'+dojo.toJson(results,true)+'</pre>\n'
			;
		
		// show the debug messages
		if(showDebugOutput) {
			solverOutput +=''
					+'<h2>' + T('viewConf_calc.js/SlvrDbgLog_TXT','The solver\'s debug log') + '</h2>'
					+'<pre>'+results.debug+'</pre>'
				;
			
		} // end if showDebugOutput
		
		application.showMessage( T('app.wid.Dial.EstDep.js/SolverRes_TIT','Results of the equation solver'), solverOutput);
		
	} // end of method executeSolver
	,
	'enableDisable_newVarGroupButton' : function () {
		this.widgets.newVarGroupButton.attr( 'disabled', !this.widgets.newVarGroupInputBox.isValid() );
	} // end of method enableDisable_newVarGroupButton
	,
	'createNewVarGroup' : function () {
		
		if(!this.widgets.newVarGroupInputBox.isValid()) return false;
		
		var varGroupName = this.widgets.newVarGroupInputBox.attr('value');
		
		if (varGroupName in this.eqSolverConfig.varGroups) return false;
		
		this.eqSolverConfig.varGroups[varGroupName] = {};
		this._eqSolverConfigHasChanged();
		
		this.createMenuItemForVarGroup(varGroupName);
		
		this.widgets.newVarGroupButton.attr( 'disabled', true);
		this.widgets.newVarGroupInputBox.attr('value', '');
		
		return false;
	} // end of method createNewVarGroup
	,
	'createMenuItemForVarGroup' : function (varGroupName) {
		
		this.varGroupWidgets[varGroupName] = new application.widgets.manageViews_CalcProperty_varGroup({
			'varGroupName' : varGroupName,
			'configWidget'	: this,
			'onDeleteClick' : function (e) {
				dojo.stopEvent(e);
				this.configWidget.deleteVarGroup(this.varGroupName);
			} // end of method onDeleteClick
			,
			'onClick'	: function (e) {
				dojo.stopEvent(e);
				this.configWidget.setAttrVarssInVarGroupConstant(this.varGroupName);
			} // end of method onClick
		});
		
		this.widgets.varGroupMenuBar.addChild(this.varGroupWidgets[varGroupName]);
		
	} // end of method createMenuItemForVarGroup
	,
	'deleteVarGroup' : function (varGroupName) {
		delete this.eqSolverConfig.varGroups[varGroupName];
		this._eqSolverConfigHasChanged();
		
		// iterate over all attributes and remove the variable group
		for(var A_UUID in this.attrVarWidgets) {
			var w = this.attrVarWidgets[A_UUID];
			w.removeVarGroup(varGroupName);
		} // end for ... in
		
		
		// delete the widget
		this.widgets.varGroupMenuBar.removeChild(this.varGroupWidgets[varGroupName]);
		this.varGroupWidgets[varGroupName].destroyRecursive();
		delete this.varGroupWidgets[varGroupName];
		
	} // end of method deleteVarGroup
	,
	'removeAttrFromVarGroup' : function (A_UUID, varGroupName) {
		if(this.eqSolverConfig.varGroups[varGroupName]) {
			delete this.eqSolverConfig.varGroups[varGroupName][A_UUID];
			this._eqSolverConfigHasChanged();
		} // // end if 
	} // end of method removeAttrFromVarGroup
	,
	'addAttrToVarGroup' : function (A_UUID, varGroupName) {
		if(!(varGroupName in this.eqSolverConfig.varGroups))
			this.eqSolverConfig.varGroups[varGroupName] = {};
		this.eqSolverConfig.varGroups[varGroupName][A_UUID]=A_UUID;
		this._eqSolverConfigHasChanged();		
	} // end of method addAttrToVarGroup
});

dojo.declare('application.widgets.manageViews_CalcProperty_attr',[dijit._Widget, dijit._Templated], {

	// these properties need to be set on initialisation
	'parentWidget'	: null,
	'A_UUID'		: null,
	
	// properties that are changable from postCreate on ...
	'isConstant'	: false,
	'varName'		: null,

	
	
	'constructor' : function() {
		// Your constructor method will be called before the parameters are mixed into the widget, and can be used to initialize arrays, etc.
		
		this.widgets = {};
		this.varGroupWidgets = {};
		
		this.varName = '';
		
		this.inherited(arguments);
	} // end of method constructor
	,
	'templateString'	: ''
					+'<tr class="" dojoAttachEvent="onmouseenter:_onHover,onmouseleave:_onUnHover" >'
						+'<th>'
							+'${A_name}'
						+'</th>'
						+'<td>'
							+'<span dojoAttachPoint="varDOMNode"></span>'
						+'</td>'
						+'<td class="textCenter">'
							+'<span dojoAttachPoint="testValDOMNode"></span>'
						+'</td>'
						+'<td class="textCenter">'
							+'<span dojoAttachPoint="constCBDOMNode"></span>'
						+'</td>'
						+'<td dojoAttachPoint="resultDOMNode" class="code">'
							+''
						+'</td>'
						+'<td class="code textCenter">'
							+'${A_unit}'
						+'</td>'
						/*
						+'<td dojoAttachPoint="tagsDOMNode" class="small textCenter">'
							+'Tags'
						+'</td>'
						*/
						+'<td dojoAttachPoint="groupsDOMNode" class="small">'
							// +'Variable groups'
							+'<span dojoAttachPoint="addVarGroup_dDButton_domNode"></span>'
						+'</td>'
					+'</tr>'
	,
	'postMixInProperties' : function () {
	
		// locate the unit and the tags
		this.A_name=this.parentWidget.lookupAttrProperty(this.A_UUID, 'name', '');
		this.A_unit=this.parentWidget.lookupAttrProperty(this.A_UUID, 'unitsAsString', '');
		this.A_tags=dojo.fromJson(this.parentWidget.lookupAttrProperty(this.A_UUID, 'tags', ''));
	
	} // end of method postMixInProperties
	,
	'postCreate' : function () {
		this.inherited(arguments);
		
		// create an input box for the variable name
		this.widgets.varIB = new dijit.form.TextBox({
			'class'	: 'fullWidth strong',
			//'style'	: 'width:5em;',
			'value' : this.varName,
		}).placeAt(this.varDOMNode);
		this.connect( this.widgets.varIB, 'onChange', '_varName_onChange');
	
		var formatOptions = {},
			formatDisplay = this.parentWidget.lookupAttrProperty(this.A_UUID, 'formatDisplay', '');
		if (formatDisplay) formatOptions.pattern = formatDisplay;

		var constraints = {	pattern: this.parentWidget.lookupAttrProperty(this.A_UUID, 'format', '') },
			title = '',
			minValue = this.parentWidget.lookupAttrProperty(this.A_UUID, 'minValue', ''),
			maxValue = this.parentWidget.lookupAttrProperty(this.A_UUID, 'maxValue', '');
		if (minValue!=null) {
			constraints.min=minValue;
			title += '['+dojo.number.format(minValue, formatOptions);
		} // end if

		if (maxValue!=null) {
			constraints.max=maxValue;
			title += ((title.length)?' 	… ':'')+dojo.number.format(maxValue, formatOptions)+']';
		} else {
			title += ((title.length)?' 	… ':'');
		} // end if

		// create an input box for the test value
		this.widgets.testValIB = new dijit.form.NumberTextBox({
			'class':		'cNumberAttribute_VTE_cV_tB code fullWidth',//'RS_VTE_number_number',
			'selectOnClick': true
		}).placeAt(this.testValDOMNode);
		this.widgets.testValIB.attr('constraints', constraints);
		this.connect( this.widgets.testValIB, 'onChange', '_value_onChange' );
		
		// create the const? check box
		this.widgets.constCB = new dijit.form.CheckBox({
			'checked'	: this.isConstant,
		}).placeAt(this.constCBDOMNode);
		this.connect( this.widgets.constCB, 'onChange', '_isConstant_onChange');
		
		// the tooltip dialog for adding variable groups
		this.widgets.addVarGroup_toolTip = new dijit.TooltipDialog({
			'style'	: 'height:15em;',
            'content': ''
				// +'<div style="width:15em;height:10em;">'
					+'<p class="textLeft">' + T('viewConf_calc.js/AssignAttrToVarGrp_TTP','To which variable group do you want to assign this attribute?') + '</p>'
					+'<p><div dojoType="dijit.form.Select" class="varGroupSelect" style="width:100%;"></div></p>'
					+'<p class="textRight"><button dojoType="dijit.form.Button" type="submit" class="vGroupAddButton">' + T('BTN_Add','Add') + '</button>&nbsp;</p>'
				// +'</div>'
        });
		this.connect(this.widgets.addVarGroup_toolTip, 'onShow', 'actualiseAvailableVariableGroups');
		this.connect(this.widgets.addVarGroup_toolTip, 'onExecute', 'addVariableGroup');
		
		this.widgets.varGroupSelectWidget = dijit.byNode(dojo.query('.varGroupSelect', this.widgets.addVarGroup_toolTip.containerNode).pop());
		this.widgets.varGroupAddButton = dijit.byNode(dojo.query('.vGroupAddButton', this.widgets.addVarGroup_toolTip.containerNode).pop());
		
		// the dropDown button for adding new variable groups
		this.widgets.addVarGroup_dDButton = new dijit.form.DropDownButton({
            // 'label': 'Add variable group',
            'title': T('viewConf_calc.js/AddVarGrp_TIT','Add variable group'),
            'label': '<img style="vertical-align:middle;" src="./third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/bullet-add.png">',
			'style'	: 'float:right;',
            'dropDown': this.widgets.addVarGroup_toolTip
        }).placeAt(this.addVarGroup_dDButton_domNode);
		
	} // end of method postCreate
	,
	'destroy' : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		
		for (var i in this.widgets) {
			this.widgets[i].destroyRecursive();
			delete this.widgets[i];
		} // end for .. in
		
		for (var i in this.varGroupWidgets) {
			this.varGroupWidgets[i].destroyRecursive();
			delete this.varGroupWidgets[i];
		} // end for .. in
		
		this.inherited(arguments);
	} // end of method destroy
	,
	'_hoverclasses' : 'dijitReset dijitMenuItemSelected dijitMenuItemFocused dijitFocused'
	,
	'_onHover' : function() {
		dojo.addClass(this.domNode, this._hoverclasses);
	} // end of method _onHover
	,
	'_onUnHover' : function() {
		dojo.removeClass(this.domNode, this._hoverclasses);
	} // end of method _onUnHover
	,
	'_setIsConstantAttr': function(isConstant){
		this.isConstant = isConstant;
		this.widgets.constCB.attr('checked', this.isConstant);
    } // end of method _setCheckedAttr
	,
	'isConstantClasses' : 'RS_attrIsConstant'
	,
	'_isConstant_onChange' : function (isConstant) {
		this.isConstant = isConstant;
		dojo.toggleClass(this.widgets.testValIB.textbox.parentNode, this.isConstantClasses, this.isConstant);
	} // end of method isConstant_onChange
	,
	'_isInVarGroup' : function (varGroupName) {
		return (varGroupName in this.varGroupWidgets)?true:false;
	} // end of method _hasTag
	,
	'setConstantIfInVarGroup' : function (varGroupName) {
		this.attr( 'isConstant', this._isInVarGroup(varGroupName));
	} // end of method setConstantIfInVarGroup
	,
	'showIfUnused' : function (show) {
		var isUsed = (this.widgets.varIB.attr('value'))?true:false;
		dojo.style( this.domNode, 'display', (show||isUsed?'table-row':'none') );
	} // end of method showIfUnused
	,
	'_setVarNameAttr': function(varName){
		// convert the varName to a string if necessary
		if(!(typeof varName == 'string')) varName = varName+'';
		this.varName = varName;
		if ('varIB' in this.widgets) this.widgets.varIB.attr('value', this.varName);
    } // end of method _setCheckedAttr
	,
	'_varName_onChange' : function(varName) {
		this.varName = varName;
		this.varName_changed (this.A_UUID, varName);
	} // end of method _varName_onChange
	,
	'varName_changed' : function (A_UUID, varName) {
		// this method is for dojo.connect
	} // end of method varName_changed
	,
	'_value_onChange' : function (v) {
	 this.value = v;
	} // end of method _value_onChange
	,
	'setEstimatedValue' : function (v) {
	
		var formattedValue = '';
		
		if (typeof v == 'number') {
		
			var formatOptions = {},
				formatDisplay = this.parentWidget.lookupAttrProperty(this.A_UUID, 'formatDisplay', '');
			if (formatDisplay) formatOptions.pattern = formatDisplay;
	
			formattedValue =  dojo.number.format(v, formatOptions);
	
		} else {
		
			formattedValue = v+'';
		
		} // end if
	
		dojo.attr( this.resultDOMNode, 'innerHTML', formattedValue );
	
	} // end of method setEstimatedValue
	,
	'addToVarGroup' : function (varGroupName) {
		this.varGroupWidgets[varGroupName]=new application.widgets.manageViews_CalcProperty_varGroup ({
			'varGroupName'	: varGroupName,
			'deleteTitle'	: T('RemVarGrpFromAttr_TIT','Click here to remove the variable group from this attribute.'),
			'parentWidget'	: this,
		});
		this.varGroupWidgets[varGroupName].placeAt(this.addVarGroup_dDButton_domNode, 'after');
		this.connect( this.varGroupWidgets[varGroupName], 'removeAttrFromVarGroup', 'removeAttrFromVarGroup');
	} // end of method addToVarGroup
	,
	'removeVarGroup' : function (varGroupName) {
		if (this.varGroupWidgets[varGroupName]) {
			this.varGroupWidgets[varGroupName].destroy();
			delete this.varGroupWidgets[varGroupName];
		} // end if
	} // end of method removeVarGroup
	,
	'actualiseAvailableVariableGroups' : function () {
	
		// identify all available var groups
		var definedVarGroups = this.parentWidget.varGroupWidgets, // {}, we will need the keys, only
			availableVarGroups = [];
			
		for (var varGroupName in definedVarGroups) {
			if (!this.varGroupWidgets[varGroupName]) 
				availableVarGroups.push({'label':varGroupName,'value':varGroupName});
		} // end for .. in
		
		// set the reduced var group list
		this.widgets.varGroupSelectWidget.removeOption(this.widgets.varGroupSelectWidget.options);
		this.widgets.varGroupSelectWidget.addOption(availableVarGroups);
		this.widgets.varGroupAddButton.attr('disabled', (availableVarGroups.length?false:true));
		} // end of method actualiseAvailableVariableGroups
	,
	'addVariableGroup' : function () {
	
		var vGroup = this.widgets.varGroupSelectWidget.attr('value');
	
		// dojo.forEach(vGroups, function (vGroup) {
			this.addToVarGroup(vGroup);
			this.parentWidget.addAttrToVarGroup(this.A_UUID, vGroup);
		// }, this); // end dojo.forEach
		
		return false;
	} // end of method addVariableGroup
	,
	'removeAttrFromVarGroup' : function (varGroupName) {
		this.parentWidget.removeAttrFromVarGroup(this.A_UUID, varGroupName);
		this.varGroupWidgets[varGroupName].destroy();
		delete this.varGroupWidgets[varGroupName];
	} // end of method removeAttrFromVarGroup
	,
});

dojo.declare('application.widgets.manageViews_CalcProperty_varGroup',[dijit._Widget, dijit._Templated], {
	'varGroupName'	: '',
	'maxNameDisplayLength'	: 15,
	'deleteTitle'	: T('viewConf_calc.js/DelVarGrp_TIT','Click here to delete this variable group.'),
	'templateString' : ''
		+'<span class="RS_varGroup dijitReset dijitInline dijitMenuItemLabel dijitMenuItem dijitMenuBar" style="margin-right:.75em;"  dojoAttachEvent="onmouseenter:_onHover,onmouseleave:_onUnHover" >'
			+'<span dojoAttachPoint="_varGroupName_domNode">'
				+'${varGroupName}'
			+'</span>'
			+'<span dojoAttachEvent="onclick:onDeleteClick" class="RS_iconButton RS_icon_delete" title="${deleteTitle}">'
			+'</span>'
		+'</span>'
	,
	'onDeleteClick' : function (e) {
		dojo.stopEvent(e);
		this.removeAttrFromVarGroup(this.varGroupName);
	} // end of method onDeleteClick
	,
	'_hoverclasses' : 'dijitReset dijitMenuItemSelected dijitMenuItemFocused dijitFocused'
	,
	'_onHover' : function() {
		dojo.addClass(this.domNode, this._hoverclasses);
	} // end of method _onHover
	,
	'_onUnHover' : function() {
		dojo.removeClass(this.domNode, this._hoverclasses);
	} // end of method _onUnHover
	,
	'postCreate' : function () {
		this.inherited(arguments);
		
		var varGroupName_shortened = this.varGroupName;
		
		if (varGroupName_shortened.length > this.maxNameDisplayLength) varGroupName_shortened = varGroupName_shortened.substr(0,this.maxNameDisplayLength)+'&hellip;';
		
		dojo.attr( this._varGroupName_domNode, 'innerHTML', varGroupName_shortened );
	
		this.attr('title', this.varGroupName);
	
	} // end of method postCreate
	,
	
	// Events
	'removeAttrFromVarGroup' : function (varGroupName) {},
});