<?php if (!defined('APPLICATION_started')) {header('Location: .');exit;} 
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// this file registers all view components

// the registry component for all view kinds
$r->register_JavaScriptFile('application/views/viewRegistry.js');
$r->register_JavaScriptFile('application/views/viewMenuBarRegistry.js');

// the abstract template for any kind of view
$r->register_JavaScriptFile('application/views/views_generalTemplateWidget.js');

// specific view kinds

$viewKinds = Array( // all view kinds in the correct loading sequence
	'name',
	'attributeList',
	'allAttributes', // take care - this view is inherited from attributeListView and hencs needs to be loaded, afterwards
	'HTMLForm',
);

reset($viewKinds);
while( list($k,$vK)=each($viewKinds)) $r->register_JavaScriptFile('application/views/viewWidget_'.$vK.'.js');

global /*$r, */$backend;

if($backend->isAdmin()){
	// the abstract template template for any view configuration widget
	$r->register_JavaScriptFile('application/views/viewConfiguration_templateWidget.js');
	
	// general view configuration
	$r->register_JavaScriptFile('application/views/viewConfiguration_general.js');
	$r->register_JavaScriptFile('application/views/viewConfiguration_calculations.js');
	$r->register_JavaScriptFile('application/views/viewConfiguration_CBR.js');
	
	// view kind specific configuration
	reset($viewKinds);
	while( list($k,$vK)=each($viewKinds)) $r->register_JavaScriptFile('application/views/viewConfiguration_'.$vK.'.js');
	
} // end if admin
	
	
$r->register_cssContent( '
	
	.editableAttributeValueSet_compact {
		cursor: pointer;
		border: .1ex solid lightblue;
		background: url("third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/edit-3.png") no-repeat scroll right top transparent;
		padding-right: 24px; /* due to image width of 16px */
		/*padding: 2px;*/
	}
	
	.editableAttributeValueSet_compact > img {
		vertical-align: middle;
		padding-left: .25em;
		border: none;
	}
	
	.editableAttributeValueSet_normal {
		cursor: pointer;
		background: url("third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/edit-3.png") no-repeat scroll right top transparent;
		padding-right: 24px; /* due to image width of 16px */
	}
	
');
?>