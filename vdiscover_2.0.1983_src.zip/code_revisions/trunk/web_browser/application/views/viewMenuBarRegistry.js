/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// set up the plug-in registry and add specific options
if(!application.plugins) application.plugins={};
if(!application.plugins.view) application.plugins.view={};
application.plugins.registerViewMenuBarItem_editMode = 
	function (viewType_UUID, label, title, onClickFunction) {
		if (typeof viewType_UUID != 'string') 		throw ""
			+"Cannot register new plug-in ViewMenuBarItem_editMode, "
			+"because there is no view type UUID.";
		if (typeof onClickFunction != 'function') 	throw ""
			+"Cannot register new plug-in ViewMenuBarItem_editMode, "
			+"because there is no function to be executed.";
		
		if(!application.plugins.view[viewType_UUID])
			application.plugins.view[viewType_UUID]={};
		if(!application.plugins.view[viewType_UUID].menuBar)
			application.plugins.view[viewType_UUID].menuBar={};
		application.plugins.view[viewType_UUID].menuBar.editMode = {
			'label'		:	label,
			'title'		:	title,
			'onClick'	:	onClickFunction
		};
	}; // end of function
