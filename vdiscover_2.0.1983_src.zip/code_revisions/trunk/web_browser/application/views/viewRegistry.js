﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// registry class declaration for a view kind of an object
dojo.declare("application.classes.viewKind_class",null,{
	kind : "not specified, yet"
	,
	name : "Abstract view"
	,
	defaultConfiguration : {} // will be modified later on to
	,
	is_default_view : false
	,
	constructor : function(args) {dojo./*safeMixin*/mixin(this, args);}
	,
	positionOfView : 1000 // natural number
	,
	defaultDescription : ""
	,
	content : ""
	,
	searchPoints : 5 // natural number
	,
	buildContent : function () {return 'not specified';}
	,
	'mayBeUsedAsNameTemplate' 		: false
	,
	'mayBeUsedAsDescriptionTemplate': false
	,
	'isTemplateName' 				: false
	,
	'templateNameInherited' 		: false
	,
	'isTemplateDescription' 		: false
	,
	'templateDescriptionInherited'	: false
	,
	'hasCalculationFacilities'		: false // set this option to true to make the equation solver available for views of this kind
	,
	'hasCBRFacilities'				: false // set this option to true to enable the CBR engine available for views of this kind
	,
	'createWidget' : function (p){
		return new application.widgets[this.widgetClass.replace('application.widgets.','')](p);
	} // end of method createWidget
	,
	'widgetClass' : null // the widget class -- needs to be set
}); // end of class declaration

// initialisation of the application part that is responsible for the view kind management
application.viewKinds = {
	viewKindList : {}
	,
	register : function(confObj){
		/* The structure of confObj:
			kind : UUID string
			name : view Type Name
			defaultConfiguration : OPTIONAL -- JS object with the view-specific default configuration options
			configurationWidget : string -- name of the widget that is used to edit the view type's configuration
			prepareConfigurationForEditing : OPTIONAL function(configurationObject) -- should return the configurationObject in an extended version that can be used to create the configurationWidget
			is_default_view : OPTIONAL -- BOOLEAN set this to true to make this view available for all information objects of a new type by default
		*/

		if (!confObj.kind) 			throw "No kind passed in  \""+dojo.toJson(confObj)+"\". Aborting.";
		if (!confObj.name) 			throw "No name passed in  \""+dojo.toJson(confObj)+"\". Aborting.";
		if (!confObj.widgetClass) 	throw "No widgetClass passed in  \""+dojo.toJson(confObj)+"\". Aborting.";
		
		if (dojo.isObject(this.viewKindList[confObj.kind])) throw "A view model with the passed UUID \""+UUID+"\" does already exist. Aborting.";
		
		this.viewKindList[confObj.kind]=new application.classes.viewKind_class(confObj);
	} // end of method new_ViewType
	
}; // end of object definition viewTypes

