/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// dojo.require('application.widgets.manageViews_viewEditor_template');

dojo.declare('application.widgets.viewConfiguration.cNameView',[application.widgets.manageViews_viewEditor_template],{
	/*constructor : function() {
		// Your constructor method will be called before the parameters are mixed into the widget, and can be used to initialize arrays, etc.
		this.inherited(arguments);
	} // end of method constructor
	,*/
	'postMixInProperties' : function() {
		// If you provide a postMixInProperties method for your widget, 
		// it will be invoked before rendering occurs, and before 
		// any dom nodes are created. If you need to add or change the 
		// instance's properties before the widget is rendered 
		// - this is the place to do it.
		
		this.inherited(arguments);
		
		// localise all necessary properties
		
		this.localiseValues(['contentWithVariables']);
		
		if(typeof this.contentWithVariables=='undefined') this.contentWithVariables='';
		
		this.templateString='<div>'
				+(this.isInherited?''
					+'<p>'
						+T('nameView.js/postMixInProperties_templateString_isInherited_HTM','This view is <i>inherited</i>. It is defined at the object type « ${viewDefinedAt}» . Hence, certain properties need to be modified, there.')
					+'</p>'
					+'<p>&nbsp;</p>'
				:'')
				+'<h3>'+T('nameView.js/postMixInProperties_templateString_NameTemplStr_TXT','Name template string')+'</h3>'
				+'<p>'
					+'<input type="text" '
						+'value="${contentWithVariables}" '
						+'dojoType="dijit.form.ValidationTextBox" '
						+'class="fullWidth code" '
						+'regExp=".{5,}" '
						+'disabled="${isInherited}" '
						+'dojoAttachPoint="template_widget" '
						+'intermediateChanges="true" ' 
						+'dojoAttachEvent="onChange:template_changed" '
						+'/> '
				+'</p>'
				+'<p>&nbsp;</p>'
				+'<p>'+T('nameView.js/postMixInProperties_templateString_AvailableVars_TXT','Available variables for the name template string:')+'</p>'
				+'<table class="compact fullWidth">'
					+'<tr>'
						+'<td style="width:70%;">'
						+'<div dojoAttachPoint="select_domNode">'
						+'</div>'				
						+'</td>'
						+'<td style="width:30%;">'
						+'<button  '
							+'dojoType="dijit.form.Button" type="button"  '
							+'disabled="${isInherited}" '
							+'dojoAttachEvent="onClick:insert_clicked" '
							+'>'
							+ T('BTN_Insert!', 'Insert!')
						+'</button>'
						+'</td>'
					+'</tr>'
				+'</table>'
				+'<p>&nbsp;</p>'				
				+T('nameView.js/postMixInProperties_templateString_VarsLike_HTM', '<p>Variables like <code>&#x24;{Attribute name}</code> will be replaced with the corresponding value of « Attribute name» .</p><p>If you used numbers in object names, it would come handy to put some chars in front of them to be able to identify them, uniquely. Example: <code>L&#x24;{Lot number} (&#x24;{year})</code> permits to find the lot <code>2012</code> by entering « <code>L2012</code>»  in the search box, but not lots in the year <code>2012</code>.</p>')
		
			+'</div>';
		
	} // end of method postMixInProperties
	,
	/*buildRendering : function() {
		// dijit._Templated provides an implementation of buildRendering 
		// that most times will do what you need. The template is fetched/read, 
		// nodes created and events hooked up during buildRendering. The end 
		// result is assigned to this.domNode. If you don't mixin dijit._Templated 
		// (and most OOTB dijits do) and want to handle rendering yourself 
		// (e.g. to really streamline a simple widget, or even use a different 
		// templating system) this is where you'd do it.
		this.inherited(arguments);
	} // end of method buildRendering
	,*/
	'postCreate' : function() {
		// This is typically the workhorse of a custom widget. The widget has 
		// been rendered (but note that sub-widgets in the containerNode have not!). 
		// The widget though may not be attached to the DOM yet so you shouldn't 
		// do any sizing calculations in this method.
		this.inherited(arguments);
		
		this.selectWidget = new dijit.form.ComboBox({
			'labelAttr' : 'name',
			'searchAttr': 'name',
			'labelType'	: 'html',
			'queryExpr' : '*${0}*',
			'disabled'	: this.isInherited,
			'class'		: 'fullWidth',
			'store' 	: new dojo.data.ItemFileReadStore({
				'data'	: this.dialogWidget.getListOfAvailableAttributes(),
				// 'url'		:	'?'+dojo.objectToQuery({
					// 'v'			: 'JSON_ObjectType',
					// 'task'		: 'get_OT_attributes', 
					// 'OT_UUID'	: this.dialogWidget.OT_UUID,
					// 'UUID'		: this.dialogWidget.OT_UUID
					// })
			}),
			'scope'		: this
		}).placeAt(this.select_domNode);
				
	} // end of method postCreate
	,
	/*startup : function() {
		// If you need to be sure parsing and creation of any child widgets has 
		// completed, use startup. This is often used for layout widgets like 
		// BorderContainer. If the widget does JS sizing, then startup() should 
		// call resize(), which does the sizing.
		this.inherited(arguments);
	} // end of method startup
	,*/
    /*resize : function() {
		// All widgets that do JS sizing should have a method called resize(), that lays 
		// out the widget. Resize() should be called from startup() and will also be 
		// called by parent widgets like dijit.layout.ContentPane.
	}
	,*/
	'destroy' : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		
		this.selectWidget.destroyRecursive();
		
		this.inherited(arguments);
	} // end of method destroy
	,
	'template_changed' : function(){
		if(this.template_widget.isValid()) {
			this.contentWithVariables=this.template_widget.get('value');
			this.valueHasChanged('contentWithVariables');
		} // end if
	} // end of method template_changed
	,
	'insert_clicked' : function () {
		// this routine inserts the selected attribute name into the template string
		
		var v = this.selectWidget.get('value');
		
		if(v) {
			var variable 			= '${'+v+'}',
				template_domNode 	= this.template_widget.focusNode,
				
				selectionStart		= template_domNode.selectionStart,
				selectionEnd 		= template_domNode.selectionEnd,
				
				template 			= this.template_widget.get('value'),
				changedTemplate 	= '';
			
			if(selectionStart&&selectionEnd) {
				var keepBefore 		= template.substring(0,selectionStart),
					keepAfter 		= template.substring(selectionEnd);
				
				changedTemplate 	= keepBefore+variable+keepAfter;
			} else {
				changedTemplate		= (template?template+' ':'')+variable;
			} // end if
				
			this.template_widget.set('value', changedTemplate);
		} // end if there is a value
	} // end of method insert_clicked
	,
	
	
	
	'_getListOfUsedAttributes' : function () {

		// extract all attribute names from this.contentWithVariables
		var pattern = /\$\{([^\}]+)\}/gm,
			aNames	= this.contentWithVariables.match(pattern),
			attrList = [];
	
		// iterate over all aNames and get their UUID
		dojo.forEach(aNames, function(aNameString) {
			
			// strip the ${ ... } from the attribute name
			var aName	= aNameString.slice(2, aNameString.length-1),
				A_UUID	= '';
			
			// get the corresponding A_UUID from the store
			this.attrStore.fetch({
				'scope'	: this,
				'query'	: {'name' : aName},
				'onItem': function (item) {
					A_UUID = this.attrStore.getValue(item, 'UUID');
				} // end of method onItem
			});
			
			attrList.push(A_UUID);
			
		},this);
	
		return attrList;
	} // end of method _getListOfUsedAttributes
	,	
});

