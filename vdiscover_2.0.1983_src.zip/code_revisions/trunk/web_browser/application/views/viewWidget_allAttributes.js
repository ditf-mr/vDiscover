﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare("application.widgets.allAttributesView",[application.widgets.attributeListView],{});

// register all available menu bar options and the corresponding code
dojo.addOnLoad(function(){
	application.viewKinds.register({ 'name' : T('viewWid_allAttr.js/AllAttr_TIT', 'All Attributes'), 
		'kind'							: "cAllAttributesViewType", 
		'widgetClass'					: "application.widgets.allAttributesView",
		'configurationWidgetClass'		: "cAllAttributesView",
		'mayBeUsedAsDescriptionTemplate': true,
		'hasCalculationFacilities'		: true,
		'hasCBRFacilities'				: true,
	});
}); // end dojo.addOnLoad