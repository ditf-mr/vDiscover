/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare("application.widgets.attributeListView",[application.widgets.genericView],{
	'buildContent':function(){
		// build a table of all listed attributes
		var output='<table class="fullWidth listWithRows compact">';
		var replaceWith = this.buildAttributeReplacementTable();
		
		dojo.forEach(this.viewConfig.attributeList, function(A_UUID){
			var attrWithValueSet = this.attributesWithValueSets[A_UUID],
			
				// show this attribute, if ...
				showAttribute = 		this.edit 										// we are in edit mode
									||	this.viewConfig.showEmptyAttributesInReadMode 	// we shall show the attribute always
									||	Object.keys(attrWithValueSet.values).length; 	// the attribute has value tuples 
				
			if(!attrWithValueSet) {
				output += '<tr><th width="25%" class="textRight deleted" style="vertical-align:top;">'
									+'???'
								+'</th><td class="deleted">'+T('attributeListView.js/buildContent_AttributeDeleted_TXT', 'Cannot find attribute with UUID « $[0]» .',[A_UUID])+'</td>'
							+'</tr>';
			} else if (showAttribute) {
				if(attrWithValueSet.attribute.displayInFullWidth) {
					// display values over 2 columns
					output += '<tr><th colspan="2" class="textLeft" style="vertical-align:top;">'
									+attrWithValueSet.attribute.name
								+'</th><td></td></tr>'
								+'<tr class="noSeparatorLine"><td colspan="2" style="vertical-align:top;">'
									+replaceWith[A_UUID]
								+'</td></tr>';				
				} else {
					// display the values in the right column, only
					output += '<tr><th width="25%" class="textRight" style="vertical-align:top;">'
									+attrWithValueSet.attribute.name
								+'</th><td>'
									+replaceWith[A_UUID]
								+'</td></tr>';
				} // end if
			} // end if show attribute
		},this); // end dojo.forEach attribute in the list
		
		output+='</table>';
		
		// create the DOM from the output string
		return dojo.create('div',{innerHTML:output});
				
	} // end of method buildContent
});

// register all available menu bar options and the corresponding code
dojo.addOnLoad(function(){
	application.viewKinds.register({ name: T('viewWid_attrList.js/attrList_TIT', 'Attribute List'), 
		'kind'							: "cAttributeListViewType", 
		'widgetClass'					: "application.widgets.attributeListView",
		'configurationWidgetClass'		: "cAttributeListView",
		'mayBeUsedAsDescriptionTemplate': true,
		'hasCalculationFacilities'		: true,
		'hasCBRFacilities'				: true,
	});
}); // end dojo.addOnLoad