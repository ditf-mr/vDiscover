/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare('application.widgets.printableDocument',[dijit._Widget,dijit._Templated],{

	// these parameters need to be set when creating the widget

	document : null // HTML string
	,
	// TG: QUESTION: was bedeutet Text nach "header" und "footer"? Auch übersetzen?
	header : '<h1>Test header</h1>'
	,
	footer : '<p>Test footer</p>'
	,
	// see file:///Y:/Gespiegelte%20Webseiten/Dojo%20Toolkit%20Documentation/DOJOTOOL/REFERENC/DIJIT/_WIDGET.HTM#dijit-widget
	// see as well file:///Y:/Gespiegelte%20Webseiten/Dojo%20Toolkit%20Documentation/DOJOTOOL/REFERENC/QUICKSTA/WRITINGW.HTM#quickstart-writingwidgets
	/*constructor : function() {
		// Your constructor method will be called before the parameters are mixed into the widget, and can be used to initialize arrays, etc.
		this.inherited(arguments);
	} // end of method constructor
	,*/
	templateString: null // will be set in postMixInProperties
	,
	_onDeleteClick : function (e) {
		dojo.stopEvent(e);
		
		try {
			dojo.empty(this.domNode);
			this.destroyRecursive(false); // destroy DOM, as well
		} catch(exception) {
			console.log(exception);
		} // end try ... catch
		
		delete this;
	} // end of method _onDeleteClick
	,	
	postMixInProperties : function() {
		// If you provide a postMixInProperties method for your widget, 
		// it will be invoked before rendering occurs, and before 
		// any dom nodes are created. If you need to add or change the 
		// instance's properties before the widget is rendered 
		// - this is the place to do it.
		this.inherited(arguments);
		
		
		this.templateString = ""
		+"<div class='RS_printableDocument_outer'>"
			+"<div class='RS_printableDocument_document'>"
				+"<table class='fullWidth'>"
					+"<thead><tr><td class='RS_printableDocument_header'>"
						+"<div dojoAttachPoint='header_DOMNode'></div>"
					+"</td></tr></thead>"
					+"<tbody><tr><td class='RS_printableDocument_contents'>"
						+"<div dojoAttachPoint='containerNode'></div>"
					+"</td></tr></tbody>"
					+"<tfoot><tr><td class='RS_printableDocument_footer'>"
						+"<div dojoAttachPoint='footer_DOMNode'></div>"
					+"</td></tr></tfoot>"
				+"</table>"
			+"</div>"
			+"<img dojoAttachEvent='onclick:_onDeleteClick' "
				+"class='RS_printableDocument_deleteButton' "
				+"src='./third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/dialog-cancel-4.png' "
				+"dojoAttachEvent='ondijitclick:_onDeleteClick' "
				+"title= "
				    +T('app.wid.printableDocument.js/DelDoc_TXT', 'Delete this document.')
				+"/>"
		+"</div>";
		
	} // end of method postMixInProperties
	,
	/*buildRendering : function() {
		// dijit._Templated provides an implementation of buildRendering 
		// that most times will do what you need. The template is fetched/read, 
		// nodes created and events hooked up during buildRendering. The end 
		// result is assigned to this.domNode. If you don't mixin dijit._Templated 
		// (and most OOTB dijits do) and want to handle rendering yourself 
		// (e.g. to really streamline a simple widget, or even use a different 
		// templating system) this is where you'd do it.
		this.inherited(arguments);
	} // end of method buildRendering
	,*/
	postCreate : function() {
		// This is typically the workhorse of a custom widget. The widget has 
		// been rendered (but note that sub-widgets in the containerNode have not!). 
		// The widget though may not be attached to the DOM yet so you shouldn't 
		// do any sizing calculations in this method.
		//this.inherited(arguments);
		
		// place the header
		// dojo.place(this.header,this.header_DOMNode,'replace');
		dojo.attr(this.header_DOMNode,'innerHTML', this.header);
		
		// place the contents
		dojo.place(this.document,this.containerNode);
		
		// place the footer
		// dojo.place(this.footer,this.footer_DOMNode,'replace');
		dojo.attr(this.footer_DOMNode,'innerHTML', this.footer);
		
	} // end of method postCreate
	,
	/*startup : function() {
		// If you need to be sure parsing and creation of any child widgets has 
		// completed, use startup. This is often used for layout widgets like 
		// BorderContainer. If the widget does JS sizing, then startup() should 
		// call resize(), which does the sizing.
		this.inherited(arguments);
	} // end of method startup
	,*/
	/*destroy : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you.
		this.inherited(arguments);
	} // end of method destroy
	*/
}); // end dojo declare