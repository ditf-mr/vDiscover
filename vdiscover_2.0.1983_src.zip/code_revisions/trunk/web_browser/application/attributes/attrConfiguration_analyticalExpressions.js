/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare(
	'application.widgets.configureAttribute.analyticalExpressionConfiguration',
	[application.widgets.configureAttribute.genericConfigurationWidget],{
	
	// WIDGET LIFE CYCLE METHODS
	'constructor' : function () {
		// initialisations
		this._widgets 			= {};	
	} // end of method
	,
	'postMixInProperties' : function() {
		// If you provide a postMixInProperties method for your widget, 
		// it will be invoked before rendering occurs, and before 
		// any dom nodes are created. If you need to add or change the 
		// instance's properties before the widget is rendered 
		// - this is the place to do it.
		this.inherited(arguments);
		
		this.locateProperties([
			'enableAnalyticalExpressions',
			'analyticalExpressionConfig_asJSON',
		]);
		
		// set up the assignation configuration
		if (!this.analyticalExpressionConfig_asJSON.length) this.analyticalExpressionConfig_asJSON = '{}';
		this.exprConfig = dojo.fromJson(this.analyticalExpressionConfig_asJSON);
		
		if(!this.exprConfig.attrVars) this.exprConfig.attrVars = {
				// format: 'A_UUID' : {'varName': '...', 'testValueTuple': '{...}'}, ...
			};
		if(!this.exprConfig.funcBody) this.exprConfig.funcBody = '';
		
		
		{ // add the template sections
		this.addTemplateSection( ''
			+"<tr>"
				+"<td class='textRight'>"
					+T('attrConfiguration_analyticalExpressions.js/VTdependsOnOtherAttrVTs_TXT','Generate the value tuple for this attribute in function of other attribute\'s value tuples?')
				+"</td>"
				+"<td>"
					+"<p>"
						+"<label>"
							+"<input type='radio' dojoType='dijit.form.RadioButton' "
								+"name='application.admin.manageAttributes.enableAnalyticalExpressions' "
								+"dojoAttachPoint='rB_assignations_yes' "
								+"dojoAttachEvent='onfocus:showEditHints' "
								+"disabled='${isInherited}' "
								+"value='yes' />"
								+T("FUT_Yes","Yes")
						+"</label>"
						+'&nbsp;'
						+"<label>"
							+"<input type='radio' dojoType='dijit.form.RadioButton' "
								+"name='application.admin.manageAttributes.enableAnalyticalExpressions' "
								+"dojoAttachPoint='rB_assignations_no' "
								+"dojoAttachEvent='onfocus:showEditHints' "
								+"disabled='${isInherited}' "
								+"value='no' />"
								+T("FUT_No","No")
						+"</label>"
					+"</p>"
				+"</td>"
			+"</tr>"
			
			+"<tr>"
				+"<td colspan='2'>"
					+"<p>"
						+T('attrConfiguration_analyticalExpressions.js/analExpreConfig_TXT','Analytical expression configuration')
					+"</p>"
					+'<p class="small" dojoAttachPoint="_openConfigLink" style="display:hidden;cursor:pointer;"><a dojoAttachEvent="onclick:_openConfigDialog">'
						+T('attrConfiguration_analyticalExpressions.js/ClickToEdit_TXT','Click here to edit the configuration.')
					+'</a></p>'
					+"<div class='code small' style='overflow-x:auto;white-space:pre'>"
						+"function(\n"
							+'<div dojoAttachPoint="_inputValues_domNode" style="margin-left:1em;background-color:rgb(200,200,200);padding:.25em;border-radius:.25em;">'
								// +'Parameter_1, // cNumberAttribute value tuple\n'
								// +'Parameter_2, // cNumberAttribute value tuple\n'
								// +'Parameter_3, // cNumberAttribute value tuple\n'
							+'</div>'
						+") {\n"
						+'<div style="margin-left:1em;">'
							+"var valueTuple	= {}; // cNumberAttribute value tuple\n"
						+'</div>'
						+'<div dojoAttachPoint="_functionBody_domNode" style="margin-left:1em;background-color:rgb(200,200,200);padding:.25em;border-radius:.25em;">'
							// +'valueTuple.value = Parameter_3.value/2;\n'
						+'</div>'
						+'<div style="padding-left:1em;">'
							+"return valueTuple;\n"
						+'</div>'
						+"}\n"				
					+"</div>"
				+"</td>"
			+"</tr>"
		);}
				
		// generate the template string
		this.generateTemplateString();
	} // end of method postMixInProperties
	,
	'postCreate' : function() {
		// This is typically the workhorse of a custom widget. The widget has 
		// been rendered (but note that sub-widgets in the containerNode have not!). 
		// The widget though may not be attached to the DOM yet so you shouldn't 
		// do any sizing calculations in this method.
		this.inherited(arguments);
		
		// set up all check boxes and radio buttons ...
		if(this.enableAnalyticalExpressions) {
			this.rB_assignations_yes.attr('checked',true);
		} else {
			this.rB_assignations_no.attr('checked',true);
		} // end if
		
		// take care of inheritance
		if(!this.isInherited) {
			this.connect( this.rB_assignations_yes, 'onChange', '_enableAssignations_changed');
			dojo.style( this._openConfigLink, 'display', 'block' );
		} // end if
		
		// show the configuration
		this._renderFunction();
		
	} // end of method postCreate
	,
	'destroy' : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		
		for (var i in this._widgets) {
			if (this._widgets[i].destroyRecursive) this._widgets[i].destroyRecursive(false);
			delete this._widgets[i];
		} // end for .. in
		delete this._widgets;
				
		this.inherited(arguments);
	} // end of method destroy
	,
	
	
	// WIDGET-specific methods
	
	'_enableAssignations_changed' : function(e) {
		this.propertyHasChanged('enableAnalyticalExpressions', this.rB_assignations_yes.attr('checked'));
	} // end of method _enableAssignations_changed
	,
	'_openConfigDialog' : function(e) {
		dojo.stopEvent(e);
	
		if (this._widgets.dialog) this._closeConfigDialog();
		
		this._widgets.dialog = new application.widgets.configureAttribute.assignationConfiguration_dialog({
			'attrStore'			: this.dialog.attrStore,	// the manageAttribute dialog's attribute store
			'A_UUID'			: this.UUID, 				// the current attribute UUID
			'A_name'			: this.name, 				// the current attribute name
			'A_kind'			: this.kind, 				// the current attribute kind
			'exprConfig' 		: this.exprConfig, 			// {}
		});
		
		this.connect( this._widgets.dialog, 'onHide', 			'_closeConfigDialog' );
		this.connect( this._widgets.dialog, 'onSaveAndClose', 	'_saveAndcloseConfigDialog' );
		
		this._widgets.dialog.show();
		
	} // end of method _openConfigDialog
	,
	'_saveAndcloseConfigDialog' : function (exprConfigAsJSON) {
		
		this.propertyHasChanged('analyticalExpressionConfig_asJSON', exprConfigAsJSON);
		this.exprConfig = dojo.fromJson(this.analyticalExpressionConfig_asJSON);
		
		// update the configuration
		this._renderFunction();		
		
		this._closeConfigDialog();
	} // end of method _saveAndcloseConfigDialog
	,
	'_closeConfigDialog'	: function () {
		if (this._widgets.dialog) {
			this._widgets.dialog.hide();
			this._widgets.dialog.destroy();
			delete this._widgets.dialog;
		} // end if
	} // end of method _closeDialog
	,
	'_renderFunction' : function () {
	
	var vars = [];
	for (var A_UUID in this.exprConfig.attrVars) {
		var varName 		= this.exprConfig.attrVars[A_UUID].varName,
			attrName		= this.exprConfig.attrVars[A_UUID].name,
			var_formatted	= varName + ' <span style="color:green;">/* '+attrName+' */</span>';
		vars.push( var_formatted );
	} // end for .. in
	
	dojo.attr( this._inputValues_domNode,	'innerHTML', (vars.length ? vars.join(',\n') : '&nbsp;' ) );
	
	dojo.attr( this._functionBody_domNode,	'innerHTML', (this.exprConfig.funcBody ? this.exprConfig.funcBody : '&nbsp;' ) );

	} // end of method _renderFunction
	,
});

dojo.declare('application.widgets.configureAttribute.assignationConfiguration_dialog', [common.widgets.fixedSizeDialog], {
	
	// these values need to be passed on instantiation
	'attrStore'			: null,	// the manageAttribute dialog's attribute store
	'A_UUID'			: null, // the current attribute UUID
	'A_name'			: null, // the current attribute name
	'A_kind'			: null, // the current attribute kind
	'exprConfig' 		: null, // {}
	

	// presets for common.widgets.fixedSizeDialog
	'innerWidth'	: 1000,
	'innerHeight' 	: 1000,
	
	// WIDGET LIFE CYCLE METHODS
		'constructor' : function () {
		// initialisations
		this.attrVarList 	= {};
		this._widgets 		= {};	
	} // end of method
	,
	'postMixInProperties' : function () {
		this.inherited(arguments);
	
		this.attrVars = this.exprConfig.attrVars;
		this.funcBody = this.exprConfig.funcBody;
		
		this.availableAttrStore = new dojo.data.ItemFileWriteStore({
			'data' : { 
				'identifier': 'A_UUID',
				'label'		: 'name',
				'items'		: [
					],
				},
		});		
		
		this.attrStore.fetch({
			'scope' : this,
			'onItem': function(item, request){
				var store		= this.attrStore,
					A_UUID		= store.getValue(item, 'A_UUID'),
					name		= store.getValue(item, 'name'),
					cardinality	= store.getValue(item, 'cardinality'),
					kind		= store.getValue(item, 'kind');
					
				// conditions for adding an attribute to the list of available attributes:-
				//  * the kind permits to use attribute value tuples as input
				//	* the cardinality is === 1
				//  * the attribute is not the current one
					
				if (		(cardinality==1)
						&&	 application.attributeKinds.kindPermitsAnalyticalExpressionInput(kind)
						&&	(this.A_UUID != A_UUID)
					) {
					if (A_UUID in this.attrVars) {
					
						// put the attribute in the list for creating a new attrVar widget, later
						this.attrVarList[A_UUID] = this.attrVars[A_UUID];
						
					} else {
						this.availableAttrStore.newItem({
							'A_UUID'	: A_UUID,
							'name'		: name,
							'kind'		: kind,
						});
					
					} // end if
				} // end if
				
			}, // end of method onItem
		});
		
		this.defaultValueTuple = application.attributeKinds.getDefaultValueTupleasJson(this.A_kind);
		this.defaultValueTuple_HTMLFormatted = this.defaultValueTuple
			// add the attribute kind at the beginning
			.replace(/^\{/,  "{ // attribute kind: <a style='cursor:pointer;' class='_thisAKind_aDOMNode'>"+this.A_kind+"</a>" )
			// format all comments in green
			.replace( /\/\/[^\n]*\n/g, function(f){return '<span style="color:green;">'+f.replace(/\s+$/, '')+'</span>\n'});
		
	} // end of method postMixInProperties
	,
	'buildRendering' : function () {
		this.inherited(arguments);
	
		this.attr('title', T('attrConfiguration_analyticalExpressions.js/assignationConfiguration_dialog_TIT','Assignation configuration for « $[0]&raquo', [this.A_name]));
	
		{// create the dialog body
			this._widgets.body = new dijit.layout.BorderContainer({
				'style'		: 'width:100%;height:100%;',
				'gutters'	: false,
			})
				.placeAt(this.containerNode);
		} // end create the dialog body
	
		{// create the dialog title
		this._widgets.topPane = new dijit.layout.ContentPane({
			'region': 'top',
			'content'	: ''
				+T('attrConfiguration_analyticalExpressions.js/assignationConfiguration_dialog_intro_TXT', 
					"<p>Executing an analytical expression combines input values to an output value,<br/>e.g. <code>output := (input_1-input_2)/(input_1 + input_2)*100</code></p<p>The following JavaScript expression function is executed, …</p><ul><li>after one of its input parameters got changed</li><li>and all input parameters are valid.</li></ul>" )
			,
		});
		this._widgets.body.addChild(this._widgets.topPane);
		} // end create dialog title
		
		{// create the button pane
			this._widgets.buttonPane = new dijit.layout.ContentPane({
				'region': 'bottom',
				'style'	: 'margin-top:.5em;'
			});
			this._widgets.body.addChild(this._widgets.buttonPane);
			
				// add the buttons to the button pane
				
				this._widgets.cancelButton = new dijit.form.Button({
					'style' : 'float:right',
					'label'	: '<img width="12" src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/dialog-cancel-4.png"/> '
						+T('BTN_Cancel', 'Cancel'),
				})
					.placeAt(this._widgets.buttonPane.containerNode);
			
				this._widgets.okButton = new dijit.form.Button({
					'style' : 'float:right',
					'label'	: '<img src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/dialog-ok-apply-4.png"/> '
						+T('BTN_OK', 'OK'),
				})
					.placeAt(this._widgets.buttonPane.containerNode);
			
				this._widgets.testButton = new dijit.form.Button({
					'style' : 'float:left',
					'label'	: T('attrConfiguration_analyticalExpressions.js/assignationConfiguration_dialog_test_BTN', 'Test the assignation function'),
				})
					.placeAt(this._widgets.buttonPane.containerNode);
			
		} // end create the button pane
		
		{// create the help pane
			this._widgets.helpPane = new dijit.layout.ContentPane({
				'region'	: 'right',
				'style'		: 'width:20em;padding-left:.25em;',
				'class'		: 'small',
				'splitter'	: true,
				// 'content'	: '',
			});
			this._widgets.body.addChild(this._widgets.helpPane);
		} // end create the help pane
		
		{// create the edit pane
			this._widgets.editPane = new dijit.layout.ContentPane({
				'region'	: 'center',
				'style'		: 'margin:.25em;',
				'content'	: ''
					+"<h3>Variable list and function body</h3>"
					// +'<p>&nbsp;</p>'
					+"<div class='code small' style='white-space:pre;'>"
						+"<p><strong>function(</strong></p>"
						+'<div style="margin-left:1em;">'
							+'<div dojoAttachPoint="_inputValues_domNode" '
								+'class="dijitTextBox dijitTextArea dijitExpandingTextArea" '
								+'style="padding:.25em;border-radius:.25em;width:95%;-moz-box-sizing:border-box;margin-top:.25em;">'
									+'<table class="fullWidth compact" >'
										+'<thead>'
											+'<tr>'
												+'<th width="10%">'
													+'// Var'
												+'</th>'
												+'<th width="40%" >'
													+T('attrConfiguration_analyticalExpressions.js/assignationConfiguration_dialog_attrNameKind', 'Attribute name (Attribute kind)')
												+'</th>'
												+'<th width="45%" >'
													+T('attrConfiguration_analyticalExpressions.js/assignationConfiguration_dialog_TestVT', 'Test value tuple')
												+'</th>'
												+'<th width="5%">'
													+'&nbsp;'
												+'</th>'
											+'</tr>'
										+'</thead>'
										+'<tbody class="_insertParameters_domNode">'
										+'</tbody>'
									+'</table>'
									+'<table class="fullWidth compact" >'
										+'<tr>'
											+'<td>'
												+"<div "
														+"dojoType='dijit.form.FilteringSelect' "
														+"dojoAttachPoint='_selectNewAttr_FS' "
														+"placeHolder='Select an attribute' "
														+"searchAttr='name' "
														+"required='false' "
														+"class='' "
														+"style='width:15em;' "
													+"></div>"
												+"&nbsp;"
												+"<div dojoType='dijit.form.Button' "
													+"dojoAttachPoint='_addAttr_B' "
													+"disabled='true' "
													+"class='small'>"
														+T('FUT_Add', 'Add')
													+"</div>"
											+'</td>'
										+'</tr>'
									+'</table>'
							+'</div>'
						+'</div>'
						+"<p><strong>) {</strong></p>"
						+'<div style="margin-left:1em;">'
							+"<p style='color:green;'>// "
								+T('attrConfiguration_analyticalExpressions.js/assignationConfiguration_dialog_defVT', "let's set up the value tuple that needs to be returned")
							+"</p>"
							+"<p>var valueTuple	= "+this.defaultValueTuple_HTMLFormatted+";</p>"
							+'<p>&nbsp;</p>'
							+'<p class="RS_inputErrorBox _FBErrorMessage_domNode" style="display:none;">'
								+T('attrConfiguration_analyticalExpressions.js/assignationConfiguration_dialog_invalidFuncBody', 'Sorry &mdash; the entered function body is not valid.\n You need to correct the syntax.\n')
							+'</p>'
							+'<div dojoType="dijit.form.Textarea" dojoAttachPoint="_functionBody_TA" style="padding:.25em;border-radius:.25em;width:95%;margin-top:.25em;" spellcheck="false">'
							+'</div>'
							+'<p>&nbsp;</p>'
							+"<p>return valueTuple;</p>"
						+'</div>'
						+"<p><strong>} <span style='color:green;'>// "
							+T('attrConfiguration_analyticalExpressions.js/assignationConfiguration_dialog_endOfFunc', "end of function with analytical expression")
						+"</strong></p>"
						+"<hr />"
						+"<h3>"
							+T('attrConfiguration_analyticalExpressions.js/assignationConfiguration_dialog_testResults', "Test results")
						+"</h3>"
						+"<p class='code strong'>"+this.A_name+" = </p>"
						+"<p class='code _testResults_domNode'>"
							+T('attrConfiguration_analyticalExpressions.js/assignationConfiguration_dialog_noResultsYet', "There are no test results, yet.")
						+"</p>"
					+"</div>"
				,
			});
			this._widgets.body.addChild(this._widgets.editPane);
			this._insertParameters_domNode 	= dojo.query('._insertParameters_domNode',	this._widgets.editPane.containerNode).pop();
			this._thisAKind_aDOMNode 		= dojo.query('._thisAKind_aDOMNode', 		this._widgets.editPane.containerNode).pop();
			this._testResults_domNode 		= dojo.query('._testResults_domNode', 		this._widgets.editPane.containerNode).pop();
			this._FBErrorMessage_domNode 	= dojo.query('._FBErrorMessage_domNode', 	this._widgets.editPane.containerNode).pop();
			
			// create local links to relevant DOM nodes/ widgets in the edit pane
			var ePWs = this._widgets.editPane.getChildren();
			dojo.forEach(ePWs, function (w) {
				if (w.dojoAttachPoint) this._widgets[w.dojoAttachPoint] = w;
			}, this);
				
			// set up the filtering select for adding new attributes
			this._widgets._selectNewAttr_FS.attr('store', this.availableAttrStore);
		
		} // end create the edit pane
		
		{ // insert an attrVar widget for each attrVar
			for (var A_UUID in this.attrVars) {
				this._createAttrVarWidget(this.attrVars[A_UUID]);
			} // end for .. in
			
		} // end insert an attrVar widget for each attrVar
		
		{ // place the current function body into the widget
			this._widgets._functionBody_TA.attr( 'value', this.funcBody );
		
		} // end place the function body
		
	} // end of method buildRendering
	,
	'startup' : function () {
		this.inherited(arguments);
		
		this._widgets.body.startup();
		
		// connect the buttons, etc.
		this.connect( this._widgets.cancelButton, 		'onClick', 'hide' 					);
		
		this.connect( this._widgets._addAttr_B, 		'onClick',	'_addAttrVar_clicked' 	);
		this.connect( this._thisAKind_aDOMNode, 		'onclick', 	'_thisAKind_clicked'	);
		this.connect( this._widgets._selectNewAttr_FS, 	'onChange',	'_selectNewAttr_changed');
		this.connect( this._widgets._selectNewAttr_FS, 	'onChange',	'_exprBody_changed'		);
		this.connect( this._widgets.testButton, 		'onClick',	'_onTestButton_clicked' );
		this.connect( this._widgets._functionBody_TA, 	'onChange',	'_exprBody_changed' 	);
		this.connect( this._widgets.okButton, 			'onClick',	'_OKButton_clicked' 	);
		
		// check if everything is valid
		this.isValid();
		
	} // end of method startup
	,
	'destroy' : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		
		for (var i in this._widgets) {
			if (this._widgets[i].destroyRecursive) this._widgets[i].destroyRecursive(false);
			delete this._widgets[i];
		} // end for .. in
		delete this._widgets;
				
		this.inherited(arguments);
	} // end of method destroy
	,
	
	
	
	
	
	
	
	
	
	
	// Internal Methods
	'_addAttrVar_clicked' : function () {
	
		var add_A_UUID  = this._widgets._selectNewAttr_FS.attr('value'),
			attrItem 	= this._widgets._selectNewAttr_FS.attr('item'),
			
			name		= this.availableAttrStore.getValue(attrItem, 'name'),
			kind		= this.availableAttrStore.getValue(attrItem, 'kind');
		
		// add the attribute to the variable list
		this.attrVarList[add_A_UUID] = {
			'A_UUID'		: add_A_UUID,
			'name'			: name,
			'kind'			: kind,
			'varName'		: '', 
			'testValueTuple': '', // JSON string - if an empty one is passed, the default one will be used
		};
		this._createAttrVarWidget( this.attrVarList[add_A_UUID] );
		
		// remove the attribute item from the store
		this._widgets._selectNewAttr_FS.attr('value', '');
		this.availableAttrStore.deleteItem(attrItem);
	
	} // end of method _addAttrVar_clicked
	,
	'_createAttrVarWidget' : function (d) {
		this._widgets[d.A_UUID] = new application.widgets.configureAttribute.assignationConfiguration_varAttrAssignation(d)
			.placeAt(this._insertParameters_domNode);
		
		this.connect(this._widgets[d.A_UUID], 'removeAttrVar', 				'_removeAttrVarWidget');
		this.connect(this._widgets[d.A_UUID], 'showHelpForAttributeKind', 	'_showHelpForAttributeKind');
		this.connect(this._widgets[d.A_UUID], 'onChange', 					'_attrVarWidget_changed');
		
	} // end of method _createAttrVarWidget
	,
	'_removeAttrVarWidget' : function (A_UUID) {
		
		// add an item for the attribute to the store
		this.availableAttrStore.save();
		this.availableAttrStore.newItem({
			'A_UUID'	: A_UUID,
			'name'		: this.attrVarList[A_UUID].name,
			'kind'		: this.attrVarList[A_UUID].kind,
		});
				
		// remove the attribute from the variable list
		delete this.attrVarList[A_UUID];
		
		// destroy the widget
		this._widgets[A_UUID].destroy(false);
		delete this._widgets[A_UUID];
		
	} // end of method _removeAttrVarWidget
	,
	'_thisAKind_clicked' : function (e) {
		dojo.stopEvent(e);
		
		// show the help for the attribute kind
		this._showHelpForAttributeKind(this.A_kind);
		
	} // end of method _thisAKind_clicked
	,
	'_showHelpForAttributeKind' : function (kind) {
	
		this._widgets.helpPane.attr('content', ''
			+'<h3>'
				+T('attrConfiguration_analyticalExpressions.js/analExpreConfig_clickToEdit', 'Value tuples of the attribute kind <code>$[0]</code>', [kind])
			+'</h3>'
			+application.attributeKinds.getValueTupleDescription(kind)
		);
	
	} // end of method _showHelpForAttributeKind
	,
	'_selectNewAttr_changed' : function (c) {
	
		this._widgets._addAttr_B.attr('disabled', (c.length==0));
	
	} // end of method _selectNewAttr_changed
	,
	'_attrVarWidget_changed' : function (A_UUID, attrVarObj ) {
	
		if ( this._widgets[A_UUID].isValid() ) this.attrVarList[A_UUID] = attrVarObj;
		
		// enable/ disable the test button
		this.isValid();
		
	} // end of method _attrVarWidget_changed
	,
	'_validateExprBody' : function () {
		var v = false;
		var exprBody = this._widgets._functionBody_TA.attr('value');
		try {
			dojo.fromJson('{"f":function(){'+exprBody+'},}');
			
			dojo.style( this._FBErrorMessage_domNode, 'display', 'none' );
			// dojo.toggleClass( this._widgets._functionBody_TA.containerNode, this._tVT_isInvalid_class, false);
			v = true;
		} catch(e) {
			dojo.style( this._FBErrorMessage_domNode, 'display', 'block' );
			// dojo.toggleClass( this._widgets._functionBody_TA.containerNode, this._tVT_isInvalid_class, true);		
		} // end try ... catch
		return v;
	} // end of method _validateExprBody
	,
	'_exprBody_changed' : function(b) {	
		
		if ( this._validateExprBody() ) this.funcBody = b;
		
		// enable/ disable the test button
		this.isValid();
	} // end of method _exprBody_changed
	,
	'_onTestButton_clicked' : function () {
	
		// test if everything is valid
		if (!this.isValid()) return;
		
		// build the test function
		
		// build the function body
		var testFunc = 'function () {\n'
			+'// INPUT VALUE TUPLES -----------------------------------------------------\n'
			;
		// build the variable list
		for (var A_UUID in this.attrVarList) {
			testFunc += ''
				+'var '+this.attrVarList[A_UUID].varName
					+' = '+this.attrVarList[A_UUID].testValueTuple+';\n';
		} // end for .. in
		
		testFunc += ''
			+'// OUTPUT VALUE TUPLE ----------------------------------------------------\n'
			+'var valueTuple = '+this.defaultValueTuple+';\n'
			+'// FUNCTION BODY ----------------------------------------------------------\n\n'
			+this.funcBody+'\n\n'
			+'// ------------------------------------------------------------------------\n'
			+'return valueTuple;\n'
			+'}\n';
	
		var tJSON 	= '', 
			tObj	= {},
			res		= {};
		
		try{
			tJSON 	= '{"f":'+testFunc+'}';
			tObj	= dojo.fromJson(tJSON);
			
			res = tObj.f();
			
		} catch(e) {
		
			alert( T('attrConfiguration_analyticalExpressions.js/analExpreConfig_clickToEdit', 'Cannot execute the assignation function, correctly. The JavaScript error:\n$[0]', [e.toString()]));
		
		} // end try .. catch
	
		// assign the results
		dojo.attr(this._testResults_domNode, 'innerHTML', dojo.toJson(res, true));
	
	} // end of method _onTestButton_clicked
	,
	'_OKButton_clicked' : function () {
		this.onSaveAndClose(dojo.toJson({
			'attrVars' : this.attrVarList,
			'funcBody' : this.funcBody,
		}));
	} // end of method _OKButton_clicked
	,
	
	
	
	
	
	
	
	// External methods
	'isValid' : function () {
		var v = true;
	
		// there needs to be at least one attrVar
		v = v && ( Object.keys(this.attrVarList).length > 0);
	
		// test if all attrVars are valid
		for (var A_UUID in this.attrVarList) {
			v = v && this._widgets[A_UUID].isValid();
		} // end for .. in
		
		// test if the function body is valid
		v = v && this._validateExprBody();
		
		
		// enable/ disable the test button
		this._widgets.testButton.attr('disabled', !v);
		
		return v;
	} // end of method isValid
	,
	
	
	
	
	
	
	// Events
	'onSaveAndClose' : function (exprConfigAsJSON) {},
	
});



dojo.declare( 'application.widgets.configureAttribute.assignationConfiguration_varAttrAssignation', [dijit._Widget, dijit._Templated], {
	
	// these slot values need to be passed on instantiation
	'A_UUID'		: null, // UUID string
	'name'			: null,	// string
	'kind'			: null,	// string
	'testValueTuple': null,	// JSON string
	
	// these slot values are optional on instantiation
	'varName'	: null, // string
	
	
	// WIDGET LIFE CYCLE
	'widgetsInTemplate'	: true,
	'constructor' : function () {
		// initialisations
		this.A_UUID				='';
		this.name				='';
		this.varName			='';
	} // end of method constructor
	,
	'templateString'	: ''
		+'<tr>'
			+'<td width="10%" style="vertical-align:baseline;" >'
				+'<div dojoType="dijit.form.ValidationTextBox" '
					+'dojoAttachPoint="_varName_VTB" '
					+'dojoAttachEvent="onChange:_varName_changed" '
					+'regExp="[a-zA-Z][a-zA-Z0-9_]*" '
					+'value="${varName}" '
					+'title="'+T('attrConfiguration_analyticalExpressions.js/assignationConfiguration_varAttrAssignation_varName', 'The variable name for the value tuple of this attribute.')+'" '
					+'class="code strong" '
					+'style="width:auto;" '
				+'></div>'
			+'</td>'
			+'<th class="code" style="white-space:pre;color:green;vertical-align:baseline;" width="30%" >'
				+', // ${name}\n  // (<a dojoAttachEvent="onclick:_kind_clicked">${kind}</a>)'
			+'</th>'
			+'<td width="55%" style="vertical-align:baseline;" >'
				+'<p dojoAttachPoint="_TVErrorMessage_domNode" class="RS_inputErrorBox" style="display:none;">'
					+T(	'attrConfiguration_analyticalExpressions.js/assignationConfiguration_varAttrAssignation_invalidVT', 
						'Sorry &mdash; the entered test value tuple is not valid.<br/>You need to correct the syntax.')
				+'</p>'
				+'<div dojoType="dijit.form.Textarea" '
						+'dojoAttachPoint="_testValue_TB" '
						+'dojoAttachEvent="onChange:_testValuetuple_changed" '
						+'title="'+T('attrConfiguration_analyticalExpressions.js/assignationConfiguration_varAttrAssignation_configureTestVTHere', 'Configure the test value tuple, here.')+'" '
						+'spellcheck="false" ' // see https://developer.mozilla.org/en-US/docs/HTML/Controlling_spell_checking_in_HTML_forms
						+'class="fullWidth small code" '
					+'></div>'
			+'<td>'
			+'<td width="5%" align="center" style="vertical-align:baseline;" >'
				+'<img width="12" '
					+'dojoAttachEvent="onclick:_removeThisClicked" '
					+'title="'+T('attrConfiguration_analyticalExpressions.js/assignationConfiguration_varAttrAssignation_removeAttr', 'Remove this attribute from the expression.')+'" '
					+'src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/bullet-delete.png" '
					+'style="vertical-align:middle;cursor:pointer;" '
				+'/>'
			+'<td>'
		+'</tr>'
	,
	'postMixInProperties' : function () {
		this.inherited(arguments);
	
		this.kindName = application.attributeKinds.nameOfKind(this.kind);
		if(!this.testValueTuple.length) this.testValueTuple = application.attributeKinds.getDefaultValueTupleasJson(this.kind);
	
	} // end of method postMixInProperties
	,
	'postCreate' : function () {
		this.inherited(arguments);
	
		this._testValue_TB.attr('value', this.testValueTuple);
	
	} // end of method postCreate
	,
	
	
	
	
	
	// internal methods
	'_removeThisClicked' : function(e) {
		dojo.stopEvent(e);
		this.removeAttrVar(this.A_UUID);
	} // end of method _removeThisClicked
	,
	'_kind_clicked' : function (e) {
		dojo.stopEvent(e);
		this.showHelpForAttributeKind(this.kind);
	} // end of method _kind_clicked
	,
	'_varName_changed' : function () {
		if ( this._varName_VTB.isValid() ) {
			this.varName = this._varName_VTB.attr('value');
			this._callOnChange();
		} // end if
	} // end of method _varName_changed
	,
	// '_tVT_isInvalid_class' : 'RS_invalidJSONString'
	// ,
	'_testValueTuple_isValid' : function () {
		var v = false;
		var tVT = this._testValue_TB.attr('value');
		try {
			var tVT_obj = dojo.fromJson(tVT);
			// TODO: test if tVGT_obj is a valid value tuple
			
			dojo.style( this._TVErrorMessage_domNode, 'display', 'none' );
			dojo.style( this._TVErrorMessage_domNode, 'display', 'none' );
			// dojo.toggleClass( this._testValue_TB.containerNode, this._tVT_isInvalid_class, false);
			// dojo.toggleClass( this.domNode, this._tVT_isInvalid_class, false);
			v = true;
		} catch(e) {
			dojo.style( this._TVErrorMessage_domNode, 'display', 'block' );
			// dojo.toggleClass( this._testValue_TB.containerNode, this._tVT_isInvalid_class, true);		
			// dojo.toggleClass( this.domNode, this._tVT_isInvalid_class, true);		
		} // end try ... catch
		return v;
	} // end of method _testValueTuple_isValid
	,
	'_testValuetuple_changed' : function () {		
		if ( this._testValueTuple_isValid() ) {
			this.testValueTuple = this._testValue_TB.attr('value');		
			this._callOnChange();
		} // end if
	} // end of method _varName_changed
	,
	'_callOnChange' : function () {
		this.onChange( this.A_UUID, {
			'A_UUID'		: this.A_UUID,
			'name'			: this.name,
			'kind'			: this.kind,
			'varName'		: this.varName, 
			'testValueTuple': this.testValueTuple
		});
	} // end of method _callOnChange
	,
	
	
	
	
	// Public methods
	'isValid' : function() {
		var v = true;
	
		// the attribute-variable assignation is valid, if
		//  * the variable name is valid
		//  * the entered test value tuple is valid
		v = (		v 
				&&	( this._varName_VTB.isValid() 		)
				&&	( this._testValueTuple_isValid() 	)
			);
	
		return v;
	} // end of method isValid
	,
	
	
	// Events
	'removeAttrVar' 			: function ( A_UUID )  	{},
	'showHelpForAttributeKind'	: function ( attrKind )	{},
	'onChange'					: function ( A_UUID, attrVarObj ) {},
	
});