/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare(
	'application.widgets.configureSpecialAttribute.cMultiLineAttribute',
	[application.widgets.configureAttribute.genericConfigurationWidget],{
	
	'postMixInProperties': function() {
		this.inherited(arguments);
				
		//localise the necessary variables
		this.locateProperties(['htmlAllowed']);
		
		// expand the template string
		this.addTemplateSection(""
			+"<tr>"
				+"<td class='textRight'>" + T('attrConf_cMultiLine.js/HTMLText_TXT','HTML formatted text?') + "</td>"
				+"<td>"
					+"<label>"
						+"<input type='radio' dojoType='dijit.form.RadioButton' "
							+"name='application.widgets.configureAttributes.cMultiLineAttribute.HTMLallowed' "
							+"dojoAttachEvent='onfocus:showEditHints' "
							+"value='true' "
							+"disabled='${isInherited}' "
							+"dojoAttachPoint='radioButton_HTMLallowed_yes'/>"
							+ T('FUT_Yes','Yes')
					+"</label>"
					+"&nbsp;&nbsp;"
					+"<label>"
						+"<input type='radio' dojoType='dijit.form.RadioButton' "
							+"name='application.widgets.configureAttributes.cMultiLineAttribute.HTMLallowed' "
							+"dojoAttachEvent='onfocus:showEditHints' "
							+"disabled='${isInherited}' "
							+"value='false'  dojoAttachPoint='radioButton_HTMLallowed_no' />"
							+ T('FUT_No','No')
					+"</label>"
				+"</td>"
			+"</tr>"
		);
		
		// generate the template string
		this.generateTemplateString();
		
	} // end of method postMixInProperties
	,
	'postCreate' : function() {
		this.inherited(arguments);
		
		if(this.htmlAllowed) {
			this.radioButton_HTMLallowed_yes.attr('checked',true);
		} else {
			this.radioButton_HTMLallowed_no.attr('checked',true);
		} // end if
		
		if(!this.isInherited) {
			this.connect(this.radioButton_HTMLallowed_yes, 'onChange', 	'rB_HTMLallowed_changed');
		} // end if
		
	} // end of method postCreate
	,
	'rB_HTMLallowed_changed' : function(e) {
		this.propertyHasChanged('htmlAllowed',this.radioButton_HTMLallowed_yes.attr('checked'));
	} // end of method rB_HTMLallowed_changed
});
