/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// extend the application functionality with relation management for objects
application.attributes.cMultiLineAttribute = {
	'dialogId' : 'application.Dialogues.multiLineAttribute_HTMLEditor'
	,
	'editorId' : 'application.Dialogues.multiLineAttribute_HTMLEditor.editor'
	,
	'dialog' : null // the dialog widget
	,
	'editor' : null // the editor widget
	,
	'calledByWidget' : null // application.widgets.valueTupleEditor_multiLine
	,
	'showDialog' : function (p/*calledByWidget, title, editText*/) {
		try {
			loader.show('now');
			
			// dojo.require("common.widgets.HTMLEditor");			
			
			// register the calling widget
			this.calledByWidget = p.calledByWidget;
			
			// create the dialog
			var parameters = {
				'title'				: p.title,
				'editText' 			: p.editText,
				'calledByWidget' 	: p.calledByWidget
			};
			if ('insertSpecialContent' in p) 	parameters.insertSpecialContent	= p.insertSpecialContent;
			this.dialog= new application.widgets.Dialogs.HTMLEditor(parameters);
			this.dialog.startup();
					
			// show the dialog	
			this.dialog.show();
		
			loader.hide();
		} catch(exception) {
			loader.hide();
			console.log(exception);
			throw('Problem in application.attributes.cMultiLineAttribute.showDialog():\n'+exception);
		}
	} // end of method showDialog
	,
	'DialogCancel' : function(){
		this.dialog.hide();
		//try{this.dialog.destroyRecursive(false);}catch(e){}
		this.dialog.destroy();
		delete this.dialog;
	}
	,
	'DialogExecute' : function() {
		this.calledByWidget.notifyAttributeOfChangedValue(this.dialog.getEditorContents());
	
		// hide the dialog
		this.dialog.hide();
		
	} // end of method execute
	
}; // end extension of the application functionality

dojo.declare("application.widgets.valueTupleEditor_multiLine",[application.widgets.valueTupleEditor_generic],{
	
	'defaultHTMLText' : '<p>'
			+ T('attrValTplEdit_cMultiLine.js/DefaultTxt_TXT','This is some default text …')
		+'</p>'
	,
	'textArea' : null // dijit.form.Textarea
	,
	'buildTemplateContainer' : function() {
		this.templateContainer = ''
			+'<div dojoAttachPoint="textBoxOuter">'
				+(this.config.htmlAllowed ?
					// HTML editor
					'<p>'
						+'<a style="cursor:pointer;" dojoAttachEvent="onclick:openEditor">' + T('attrValTplEdit_cMultiLine.js/ClkToEdit_LNK','Click here to edit the following text.') + '</a>'
					+'</p>'
					+'<div dojoAttachPoint="editContents" dojoAttachEvent="onclick:openEditor" style="cursor:pointer;">'
						+(this.valueTuple.value_text?this.valueTuple.value_text:this.defaultHTMLText)
					+'</div>'
				:
					// normal plain text editor
					'<textarea dojoType="dijit.form.Textarea" dojoAttachPoint="textArea" intermediateChanges="true" class="fullWidth" rows="7" dojoAttachEvent="onChange:notifyAttributeOfChangedValue">'
						+this.valueTuple.value_text
					+'</textarea>'
				)
			+'</div>';
			
	} // end of method buildTemplateContainer
	,
	'insertSpecialContent' : function () {
		// this function will be executed when creating a HTML editor in the context of an instance of application.widgets.Dialogs.HTMLEditor
		
		if (Object.keys(this.calledByWidget.linkedObjs).length) {
			
			var contentHTML = ''
				+'<p>' + T('attrValTplEdit_cMultiLine.js/AddLnkTip_TXT','To add a link, drag it into the text:') +'</p>'
				+'';
			
			for (var O_v_UUID in this.calledByWidget.linkedObjs) {
				var name = this.calledByWidget.linkedObjs[O_v_UUID],
					title = T('attrValTplEdit_cMultiLine.js/JumpTo_TIT', 'Jump to \"$[0]\"', [name]),
					url = '?'+dojo.objectToQuery({jumpTo:'O','O_v_UUID':O_v_UUID});
				
				contentHTML += ''
					+'<p> <a href="'+url+'" onclick="application.O.show(\''+O_v_UUID+'\');return false;" class="internalLink" title="'+title+'">'
						+'<img class="internalLink_image" src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/page-white_link.png"/>'
						+name
					+'</a> </p>'
				
			} // end for .. in
		
			contentHTML +='';
		
		
			this.widgets.addRelationsContainer = new dijit.layout.ContentPane({
				'title'	: T('attrValTplEdit_cMultiLine.js/AddLinks_TIT','Add links'),
				'content': contentHTML
			});
			this.widgets.insertContainer.addChild(this.widgets.addRelationsContainer);
			// this._supportingWidgets.push(this.widgets.addRelationsContainer);
		
		} // end if add links pane
	
		if (Object.keys(this.calledByWidget.images).length) {

			var contentHTML = '<p>' + T('attrValTplEdit_cMultiLine.js/AddImgTip_TXT','To add an image, drag it into the text.') + '</p>';
		
			for (var AV_v_UUID in this.calledByWidget.images) {
				var i=this.calledByWidget.images[AV_v_UUID];
			
				contentHTML += ''
					+"<div class='RS_A_cFA_outer RS_A_cFA_outerImage'>"
						+"<div class='RS_A_cFA_imageOuter textCenter'>"
							+"<img dojoAttachPoint='image_domNode' class='RS_A_cFA_image' src='"+i.qString+"' alt='"+i.title+"' "
								+" style='max-height:"+i.value_imageHeight+"px !important;max-width:"+i.value_imageWidth+"px !important;width:85%;border:0.1ex solid #7F7F7F;'/>"
						+"</div>"
						+"<div class='RS_A_cFA_imageTitle strong textCenter'>"
							+i.value_fileTitle
						+"</div>"
					+"</div>"
			
			} // end for .. in images
		
			this.widgets.addImagesContainer = new dijit.layout.ContentPane({
				'title'	: T('attrValTplEdit_cMultiLine.js/AddImg_TIT','Add images'),
				'content': contentHTML //'<pre>'+dojo.toJson(images,true)+'</pre>'
			});
			this.widgets.insertContainer.addChild(this.widgets.addImagesContainer);
			// this._supportingWidgets.push(this.widgets.addImagesContainer);

		} // end if
			
	} // end of method insertSpecialContent
	,
	'openEditor' : function (e) {
		// call application.Dialogues.multiLineAttribute_HTMLEditor
		var dialogTitle	= T('attrValTplEdit_cMultiLine.js/EditConfName_TIT','Edit « $[0]» ', [this.config.name]),
			p 			= {
				'calledByWidget'	: this, 
				'title'				: dialogTitle, 
				'editText'			: this.valueTuple.value_text,
			};
		
		// preparations for the link and image pane
		this.linkedObjs 		= {}; 
		this.images 			= {};
		
		var view = this.attrWidget.viewWidget;
		
		var validFileMimeTypes 	= ['image/jpeg', 'image/png', 'image/gif'];
		
		for (var A_UUID in view.attributeWidgetList) {
			switch (view.attributeWidgetList[A_UUID].config.kind) {
			
				case 'cRelationAttribute':
					// show relations as links
					var A_widget = view.attributeWidgetList[A_UUID];
				
					for (var VT_UUID in A_widget.valueTuples) {
						var vT = A_widget.valueTuples[VT_UUID];
					
						if(vT.atEndObject) this.linkedObjs[vT.atEndObject.object.O_v_UUID] = vT.atEndObject.object.name;
					
					} // end for .. in
					
					break;
					
				case 'cFileAttribute':
					// show images
					var A_widget = view.attributeWidgetList[A_UUID];
				
					for (var VT_UUID in A_widget.valueTuples) {
						var vT = A_widget.valueTuples[VT_UUID];
						
						if (dojo.indexOf(validFileMimeTypes, vT.value_fileMimeType) >= 0) this.images[vT.AV_v_UUID] ={
								'qString'			: vT.qString,
								'value_fileTitle' 	: vT.value_fileTitle,
								'value_imageHeight'	: vT.value_imageHeight,
								'value_imageWidth'	: vT.value_imageWidth,
							};
						
					} // end for .. in
					
					break;
					
				default: // do nothing
			} // end switch
		} // end for .. in

		console.log('openEditor', this);
		
		// is there any special content that may be shown?
		if(Object.keys(this.images).length+Object.keys(this.linkedObjs).length) 
			p['insertSpecialContent']=this.insertSpecialContent;
		
		application.attributes.cMultiLineAttribute.showDialog(p);
		return false;
	} // end of method openEditor
	,
	'notifyAttributeOfChangedValue' : function (textFromEditorDialog) {
		// this method informs the connected attribute about the changed value tuple
		this.attrWidget.valueTupleHasChanged(this.valueTupleUUID, this.getValueTuple(textFromEditorDialog) );
	} // end of method notifyAttributeOfChangedValue
	,
	'getValueTuple' : function (textFromEditorDialog) {
		var changedValue=this.valueTuple.value_text;
		
		if(this.config.htmlAllowed) {
			if(typeof textFromEditorDialog!='undefined') changedValue=textFromEditorDialog;
			this.editContents.innerHTML=changedValue;
		} else {
			changedValue=this.textArea.attr('value');
		} // end if
		this.valueTuple.value_text=changedValue;

		return {
			'value_text'		: 	changedValue,
			'AV_UUID' 			: 	this.valueTuple.AV_UUID,
			'UUID'				:	this.valueTuple.UUID,
			'positionOfValue' 	: 	this.valueTuple.positionOfValue		
		};
	} // end of method getValueTuple
	,
	'isValid' : function () {
		var isValid = true;
		if(this.config.mustBeSet) 	isValid = isValid && !this.attrWidget.tuple_isEmpty( this.getValueTuple() );
		return isValid;
	} // end of method isValid
	,
	'destroy' : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		
		for (var i in this.widgets) {
			if (this.widgets[i].destroyRecursive) this.widgets[i].destroyRecursive(false);
			if (this.widgets[i].destroy) this.widgets[i].destroy();
			delete this.widgets[i];
		} // end for .. in
		
		//this.inherited(arguments);
	} // end of method destroy
	,
	'startup' : function () {
		this.inherited(arguments);
			
	} // end of method startup
});

