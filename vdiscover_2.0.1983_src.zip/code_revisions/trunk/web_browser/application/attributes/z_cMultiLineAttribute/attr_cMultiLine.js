/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare("application.widgets.cMultiLineAttribute",[application.widgets.standardAttribute],{
	'_emptyValueTuple': { 'value_text' : '', 'positionOfValue':89879879 }
	,
	'valueTupleEditor_name': 'application.widgets.valueTupleEditor_multiLine'
	,
	'tuple_isEmpty' : function (tuple) {
		var isEmpty=false;
		if (this.config.htmlAllowed) {
			if(tuple.value_text=="<br>\n") isEmpty=true;
		} else {
			if(!dojo.isString(tuple.value_text) || (tuple.value_text.length==0)) isEmpty=true;
		} // end if
		return isEmpty;
	} // end of method tuple_isEmpty
	,
	'htmlFormatValueTuple_readMode' : function (valueTuple) {
		if (this.config.htmlAllowed) {
			return valueTuple.value_text;
		} else {
			var quotedHTMLString = this._encodeHTMLTags( valueTuple.value_text );
			return ''
				+'<div class="code" style="">'
					+'<p>'
						+quotedHTMLString.replace(/\n/g,'</p><p>')
					+'</p>'
				+'</div>'
				;
		} // end if
	} // end of method htmlFormatValueTuple_ReadMode

	,
	'_encodeHTMLTags' : function (str) {
		// source: http://stackoverflow.com/questions/5499078/fastest-method-to-escape-html-tags-as-html-entities
		var HTMLencoded = str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
		
		var withTabs = HTMLencoded.replace( /\t/g, '&nbsp;&nbsp;&nbsp;&nbsp;' );
		
		return withTabs;
	} // end of method _encodeHTMLTags
}); // end of declaration

