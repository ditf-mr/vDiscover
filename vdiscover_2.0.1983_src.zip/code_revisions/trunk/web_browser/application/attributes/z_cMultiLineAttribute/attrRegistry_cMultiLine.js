/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

application.attributeKinds.register({kind: "cMultiLineAttribute", 
	defaultConfiguration : {
		htmlAllowed: true
	}
	,
	// defaultValues:{
		// value_text:""
	// }
	// ,	
	defaultRetrievalValues:['search_text']
	,	
	widgetClass: 'application.widgets.cMultiLineAttribute'
	,
	configurationWidgetClass : 'application.widgets.configureAttributes.cMultiLineAttribute'
	,
	fixedCardinality : true
	,
	getParsedQuery: function(item,rqWidget) {
		search_text = rqWidget.attributeStore.getValue(item,'search_text');
		if (search_text) {
			if (search_text.substr(0, 1) == "!") {
				return T('attrRegistry_cMultiLine.js/SearchResNot_TXT','$[0] does not match "$[1]"', [rqWidget.attributeStore.getValue(item,'name'), search_text.substr(1, search_text.length-1)]);
			}
			else {
				return T('attrRegistry_cMultiLine.js/SearchRes_TXT','$[0] matches "$[1]"', [rqWidget.attributeStore.getValue(item,'name'), search_text]);
			}
		}
		return "";
	} // end of method getParsedQuery
	,
	'useValueTupleAsExpressionInput'	: false
	,
	'expressionsPermitted'				: false
	,


});
