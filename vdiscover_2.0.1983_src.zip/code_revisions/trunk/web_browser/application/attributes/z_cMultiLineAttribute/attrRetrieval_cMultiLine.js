/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare('application.widgets.retrieveAttributes.cMultiLineAttribute',[application.widgets.retrieveAttributes.cSingleLineAttribute],{});
