/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare(
		'application.widgets.configureAttribute.readOnlyConfiguration',
		[application.widgets.configureAttribute.genericConfigurationWidget],{

	'postMixInProperties' : function() {
		// If you provide a postMixInProperties method for your widget, 
		// it will be invoked before rendering occurs, and before 
		// any dom nodes are created. If you need to add or change the 
		// instance's properties before the widget is rendered 
		// - this is the place to do it.
		this.inherited(arguments);
		
		this.locateProperties(['readOnly', 'mustBeSet', 'mustBeUnique']);
		
		this.addTemplateSection( ''
			+"<tr>"
				+"<td class='textRight'>" + T('attrConfiguration_readOnly.js/ReadOnly_TXT','Read only?') + "</td>"
				+"<td>"
					+"<label>"
						+"<input type='radio' dojoType='dijit.form.RadioButton' "
							+"name='application.admin.manageAttributes.attributeConfig.Widgets.generalReadOnly' "
							+"dojoAttachEvent='onfocus:showEditHints' "
							+"value='true' "
							+"disabled='${isInherited}' "
							+" dojoAttachPoint='radioButton_readOnly_yes'/>"
							+ T('FUT_Yes','Yes')
					+"</label>"
					+"&nbsp;&nbsp;"
					+"<label>"
						+"<input type='radio' dojoType='dijit.form.RadioButton' "
							+"name='application.admin.manageAttributes.attributeConfig.Widgets.generalReadOnly' "
							+"dojoAttachEvent='onfocus:showEditHints' "
							+"disabled='${isInherited}' "
							+"value='false'  dojoAttachPoint='radioButton_readOnly_no' />"
							+ T('FUT_No','No')
					+"</label>"
				+"</td>"
			+"</tr>"
			
			+"<tr>"
				+"<td class='textRight'>" + T('attrConfiguration_readOnly.js/MustBeSet_TXT','Must be set?') + "</td>"
				+"<td>"
					+"<label>"
						+"<input type='radio' dojoType='dijit.form.RadioButton' "
							+"name='application.admin.manageAttributes.attributeConfig.Widgets.generalMustBeSet' "
							+"dojoAttachEvent='onfocus:showEditHints' "
							+"disabled='${isInherited}' "
							+"value='true'  dojoAttachPoint='radioButton_mustBeSet_yes' />"
							+ T('FUT_Yes','Yes')
					+"</label>"
					+"&nbsp;&nbsp;"
					+"<label>"
						+"<input type='radio' dojoType='dijit.form.RadioButton' "
							+"name='application.admin.manageAttributes.attributeConfig.Widgets.generalMustBeSet' "
							+"dojoAttachEvent='onfocus:showEditHints' "
							+"disabled='${isInherited}' "
							+"value='false' dojoAttachPoint='radioButton_mustBeSet_no' />"
							+ T('FUT_No','No')
					+"</label>"
					+'&nbsp;' + T('attrConfiguration_readOnly.js/SetThisOptToYes_HTM','Set this option to « Yes»  to force that this value tuple needs to be present when saving.')
				+"</td>"
			+"</tr>"
			
			+"<tr>"
				+"<td class='textRight'>" + T('attrConfiguration_readOnly.js/ValsNeedToBeUnique_TXT','Values need to be unique?') + "</td>"
				+"<td>"
					+"<label>"
						+"<input type='radio' dojoType='dijit.form.RadioButton' "
							+"name='application.admin.manageAttributes.attributeConfig.Widgets.generalMustBeUnique' "
							+"dojoAttachEvent='onfocus:showEditHints' "
							+"disabled='${isInherited}' "
							+"value='true'  dojoAttachPoint='radioButton_mustBeUnique_yes' />"
							+ T('FUT_Yes','Yes')
					+"</label>"
					+"&nbsp;&nbsp;"
					+"<label>"
						+"<input type='radio' dojoType='dijit.form.RadioButton' "
							+"name='application.admin.manageAttributes.attributeConfig.Widgets.generalMustBeUnique' "
							+"dojoAttachEvent='onfocus:showEditHints' "
							+"disabled='${isInherited}' "
							+"value='false'  dojoAttachPoint='radioButton_mustBeUnique_no' />"
							+ T('FUT_No','No')
					+"</label>"
				+"</td>"
			+"</tr>"		
		);
				
		// generate the template string
		this.generateTemplateString();
		
	} // end of method postMixInProperties
	,
	'postCreate' : function() {
		// This is typically the workhorse of a custom widget. The widget has 
		// been rendered (but note that sub-widgets in the containerNode have not!). 
		// The widget though may not be attached to the DOM yet so you shouldn't 
		// do any sizing calculations in this method.
		this.inherited(arguments);
		
		// set the radio button check options, correctly
		this.radioButton_readOnly_yes		.attr('checked',	 this.readOnly);
		this.radioButton_readOnly_no		.attr('checked',	!this.readOnly);
	
		this.radioButton_mustBeSet_yes		.attr('checked',	 this.mustBeSet);
		this.radioButton_mustBeSet_no		.attr('checked',	!this.mustBeSet);

		this.radioButton_mustBeUnique_yes	.attr('checked',	 this.mustBeUnique);
		this.radioButton_mustBeUnique_no	.attr('checked',	!this.mustBeUnique);

		// connect the onChange events
		if (!this.isInherited) {
			this.connect( this.radioButton_readOnly_yes,		'onChange', 'rB_readOnly_changed' );
			this.connect( this.radioButton_mustBeSet_yes,		'onChange', 'rB_mustBeSet_changed' );
			this.connect( this.radioButton_mustBeUnique_yes,	'onChange', 'rB_mustBeUnique_changed' );
		
		} // end if connect the onChange events
		
	} // end of method postCreate
	,
	'rB_readOnly_changed' : function () {
		this.propertyHasChanged( 'readOnly', 	this.radioButton_readOnly_yes.attr('checked') );
	} // end of method rB_readOnly_changed
	,
	'rB_mustBeSet_changed' : function () {
		this.propertyHasChanged( 'mustBeSet', 	this.radioButton_mustBeSet_yes.attr('checked') );
	} // end of method rB_readOnly_changed
	,
	'rB_mustBeUnique_changed' : function () {
		this.propertyHasChanged( 'mustBeUnique',this.radioButton_mustBeUnique_yes.attr('checked') );
	} // end of method rB_readOnly_changed
});

