﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare("application.widgets.cFileAttribute",[application.widgets.standardAttribute],{
	'_emptyValueTuple': { 
		'value_fileTitle' 			: '',
		'value_fileName' 			: '',
		'value_fileExtension' 		: '',
		'value_fileStoreFileName'	: '',
		'value_fileSize' 			: 0,
		'value_fileDescription'		: '',
		'value_fileUploadTimepoint'	: ''
	}
	,
	'_valueTupleSeparator' :'<hr />'
	,
	'valueTupleEditor_name': 'application.widgets.valueTupleEditor_cFileAttribute'
	,
	'tuple_isEmpty' : function (tuple) {
		
		var isEmpty = false;
		if(!tuple.value_fileSize || (tuple.value_fileName=='')) isEmpty=true;
		
		return isEmpty;
	} // end of method tuple_isEmpty
	,
	'htmlFormatValueTuple_readMode' : function (valueTuple) {
	
		// build the download query string
		// console.log('htmlFormatValueTuple_readMode');
		// console.log(this);
		// console.log(valueTuple);
		
		var q={
			'v' 		: 	'cFileAttribute_downloadFile',
			// 'O_v_UUID' 	: 	this.O_UUID,
			'A_UUID' 	: 	this.A_UUID,
			'AV_UUID'	: 	valueTuple.AV_UUID
		};
		
		if(valueTuple.fileStatus && valueTuple.fileStatus=='newFileUploaded') {
			q['status']='newFileUploaded';
			q['uploadFileName']=valueTuple.value_fileStoreFileName;
		};
		
		var qString = "?"+dojo.objectToQuery(q);
		
		// build the title
		var title=(this.config.showTitle?
								valueTuple.value_fileTitle
							:
								valueTuple.value_fileName);
		
		var parameters		= valueTuple;
		parameters.qString	= qString;
		parameters.title	= title;
		
		switch(parameters.value_fileMimeType) {
			case 'image/gif':
			case 'image/png':
			case 'image/jpeg': 	return this.htmlFormatImage(parameters);
			default: 			return this.htmlFormatFile(parameters);
		} // end switch
				
	} // end of method htmlFormatValueTuple_ReadMode
	,
	'htmlFormatImage' : function(p) {
		var fileSize = dojo.number.format(p.value_fileSize/1024,{'pattern':'###,###,##0'}); // kBytes
		var imageSize = dojo.number.format(p.value_imageWidth*p.value_imageHeight/1e6,{pattern:'###,##0.#'}); // Mpx

		var detailParts = Array();
		detailParts.push( T('FUT_Sizes','Sizes') + ":&nbsp;<code>"+fileSize+"</code>&nbsp;kBytes");
		detailParts.push("w×h:&nbsp;<code>"+p.value_imageWidth+"</code>×<code>"+p.value_imageHeight+"</code>&nbsp;px"
							+"=&nbsp;<code>"+imageSize+"</code>&nbsp;Mpx");
		detailParts.push( T('attr_cFile.js/LastChgAt_HTM','last&nbsp;change&nbsp;at') + "&nbsp;<code>"+dojo.date.locale.format(new Date(p.value_fileUploadTimepoint))+"</code>");
		var details = "("+detailParts.join("; ")+")";
		
		var esc = function(s) {
			return s
					.replace(/\\/g, '\\\\')
					.replace(/\n/g, '\\n')
					.replace(/\t/g, '\\t')
					.replace(/"/g, '\\"')
					.replace(/'/g, "\\'")
					.replace(/\u0000/g, '\\0')
				;
		} // end of func def
							
		return ''
			+'<div dojoType="application.widgets.cImage" '
				+'qString="\''+esc(p.qString)+'\'" '
				+(this.config.UploadDatetime	? 'details="\''+esc(details)+'\'" '									:'')
				+(this.config.showTitle			? 'title="\''+esc(p.title)+'\'" '									:'')
				+(this.config.showDescription	? 'value_fileDescription="\''+esc(p.value_fileDescription)+'\'" '	:'')
			+'></div>'
			;
	} // end of method htmlFormatImage
	,
	'htmlFormatFile' : function(p) {
		return ""
			+"<div class='RS_A_cFA_outer'>"
				+"<p class='RS_A_cFA_download'>"
					+"<a class='RS_MenuBarItem_withIcon RS_icon_download' "
						+"target='_new' title='" + T('attr_cFile.js/ClkToDL_LNK','Click here to download the file') + "' href='"+p.qString+"'>"
							+p.title
					+"</a>"
					+" (" + T('FUT_size','size') + ":&nbsp;<span class='code'>"
						+dojo.number.format(p.value_fileSize/1024,{'pattern':'###,###,##0'})
					+"</span>&nbsp;KBytes&nbsp;"
					+(this.config.showUploadDatetime?
						", "+ T('attr_cFile.js/lastChange_TXT','last change') + ":&nbsp;<span class='RS_A_cFA_uploadDateTime code'>"
							+dojo.date.locale.format(new Date(p.value_fileUploadTimepoint))
						+"</span>"
						:"")
					+")"
				+"</p>"
				+(this.config.showDescription?
						"<p class='RS_A_cFA_description small'>"+p.value_fileDescription+"</p>"
					:
						"")
			+"</div>"
			;
	} // end of method htmlFormatFile
}); // end of declaration
