﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

application.attributeKinds.register({kind: "cFileAttribute", 
	defaultConfiguration : {
		maxFileSize: 1024*1024*8, // this should be 8 MBytes
		allowedMimeTypesAsString:'', // a comma-separated list of all permitted mime types
		showTitle : true, // boolean
		showDescription : false, // boolean
		showUploadDatetime : false, // boolean
		
		cardinality: 1, 
		svFormatActivated: false,
		svHtmlBefore: '',
		svHtmlBetween: '',
		svHtmlAfter: ''
	},
	defaultRetrievalValues:['search_text']
	,
	widgetClass: 'application.widgets.cFileAttribute'
	,
	configurationWidgetClass : 'application.widgets.configureAttributes.cFileAttribute'
	,
	'useValueTupleAsExpressionInput'	: false
	,
	'expressionsPermitted'				: false
	,

});

