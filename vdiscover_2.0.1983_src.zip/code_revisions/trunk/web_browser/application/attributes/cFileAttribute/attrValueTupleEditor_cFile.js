﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare("application.widgets.valueTupleEditor_cFileAttribute",[application.widgets.valueTupleEditor_generic],{
	
	'buildTemplateContainer' : function() {
						
		this.formUUID=Math.uuid();
		this.templateContainer = ""
			+"<div dojoAttachPoint='cFileAttribute_DOMNode'>"
			
				// DOM for uploading a new file
				+"<div dojoAttachPoint='uploadNewFile_domNode'>"
					+"<div dojoType='dijit.form.Form' id='"+this.formUUID+"' enctype='multipart/form-data' method='post'>"
						+"<p>"
							+"<img dojoAttachPoint='uploadImage_DOMNode' "
								+"style='display:none;padding-right:.5ex;height:24px;' "
								+"src='third_party_libraries/"+application.configuration.global.DOJO_TOOLKIT_path+"/dojox/image/resources/images/loading.gif' "
								+"align='middle'/>"
							+"<input type='file' name='file' dojoAttachPoint='file_inputTag' accept='"+this.config.allowedMimeTypesAsString+"' dojoAttachEvent='onchange:file_changed' style='display:none;'/>"
							+"<span dojoType='dijit.form.Button' type='button' dojoAttachPoint='uploadButton_widget' dojoAttachEvent='onClick:uploadButton_clicked'>" + T('attrValueTupleEditor_cFile.js/UploadFile_BTN','Upload a file …') + "</span>"
							+"<input type='hidden' name='MAX_FILE_SIZE' value='"+this.config.maxFileSize+"' />"
						+"</p>"
					+"</div>" // end dijit.form.Form
				+"</div>" 
				
				// DOM for changing an already existing file
				+"<div dojoAttachPoint='changeExistingFile_domNode'>"
					+"<div class='RS_A_cFA_section' dojoAttachPoint='readMode_DOMNode'></div>"
					+"<hr/>"
					
					+(this.config.showTitle?
						"<div class='RS_A_cFA_section'>"
							+"<div class='RS_A_cFA_label'>"
								+ T('attrValueTupleEditor_cFile.js/FileTitle_TXT','File title:')
							+"</div>"					
							+"<div dojoType='dijit.form.ValidationTextBox' class='RS_A_cFA_inputBox' "
									+"dojoAttachPoint='fileTitle_inputWidget' "
									// +"intermediateChanges='true' "
									+"invalidMessage='<p>" + T('attrValueTupleEditor_cFile.js/FTitleInvMsg_HTM','Min length: <code>2</code> chars.') + "</p> ' "
									+"maxLength='255' "
									+"regExp='.{2,}' "
									+"trim='true' "
									+"required='true' "
									+"selectOnClick='true' "
								+"></div>"
						+"</div>"
					:"")
					
					+"<div class='RS_A_cFA_section'>"
						+"<div class='RS_A_cFA_label'>"
							+ T('attrValueTupleEditor_cFile.js/FileName_TXT','File name:')
						+"</div>"
						+"<div dojoType='dijit.form.ValidationTextBox' class='RS_A_cFA_inputBox' "
								+"dojoAttachPoint='fileName_inputWidget' "
								// +"intermediateChanges='true' "
								+"invalidMessage='" + T('attrValueTupleEditor_cFile.js/FNameInvMsg_HTM','<p>The file name is invalid.</p><p>Permitted chars: <code>a-zA-Z0-9,-_</code></p><p>Min length: <code>2</code> chars.</p>') + "' "
								+"maxLength='255' "
								+"regExp='[a-zA-Z0-9,-_]{2,}' "
								+"required='true' "
								+"selectOnClick='true' "
							+"></div>"
						+"<div class='RS_A_cFA_FileExtension code small' dojoAttachPoint='fileExtension_DOMNode'>"
							+".ext"
						+"</div>"
					+"</div>"
					
					+"<div class='RS_A_cFA_section'>"
						+"<div class='RS_A_cFA_label'>"
							+ T('attrValueTupleEditor_cFile.js/FileSize_TXT','File size:')
						+"</div>"
						+"<div style='display:inline-block'>"
							+"<span class='code' dojoAttachPoint='fileSize_DOMNode'>"
							+"xxx.xxx"
							+"</span>&nbsp;KBytes"
						+"</div>"
					+"</div>"
					
					+"<div class='RS_A_cFA_section'>"
						+"<div class='RS_A_cFA_label'>"
							+ T('attrValueTupleEditor_cFile.js/MIMEType_TXT','MIME type:')
						+"</div>"
						+"<div style='display:inline-block'>"
							+"<span class='code' dojoAttachPoint='fileMimeType_DOMNode'>"
							+"xxx.xxx"
							+"</span>"
						+"</div>"
					+"</div>"
					
					+"<div class='RS_A_cFA_section' dojoAttachPoint='imageDimensions_DOMNode'>"
						+"<div class='RS_A_cFA_label'>"
							+ T('attrValueTupleEditor_cFile.js/Dimensions_TXT','Dimensions:')
						+"</div>"
						+"<div style='display:inline-block;text-align:left;'>"
							+ T('attrValueTupleEditor_cFile.js/ImgWxH_HTM','width &times; height') + " = <span class='code' dojoAttachPoint='imageWidth_DOMNode'></span>&nbsp;px&nbsp;&times;&nbsp;"
							+"<span class='code' dojoAttachPoint='imageHeight_DOMNode'></span>&nbsp;px&nbsp;=&nbsp;<span class='code' dojoAttachPoint='imageMPixel_DOMNode'></span>&nbsp;Mpx"
						+"</div>"
					+"</div>"
					
					+(this.config.showDescription?
						"<div class='RS_A_cFA_section'>"
							+"<div class='RS_A_cFA_label'>"
								+ T('FUT_Description','Description') + ":"
							+"</div>"
							+"<div><textarea dojoType='dijit.form.Textarea' "
									+"dojoAttachPoint='fileDescription_inputWidget' "
									// +"intermediateChanges='true' "
									+"trim='true' "
									+"class='RS_A_cFA_inputBox' "
								+"></textarea></div>"
						+"</div>"
						:"")
					
					+(this.config.showUploadDatetime?
						"<div class='RS_A_cFA_section'>"
							+"<div class='RS_A_cFA_label'>"
								+ T('FUT_LastChange','Last change') + ":"
							+"</div>"
							+"<div style='display:inline-block' class='code' dojoAttachPoint='uploadTimePoint_DOMNode'>"
								+"xxx.xxx"
							+"</div>"
						+"</div>"
						:"")
					
				+"</div>" 

			+"</div>";		
	} // end of method postMixInProperties
	,
	'uploadButton_clicked' : function (e) {
		this.file_inputTag.click();
		dojo.stopEvent(e);
	} // end of method uploadButton_clicked
	,
	'file_changed' : function(e) {
		if(!this.file_inputTag.files[0]) return;
		
		// test if the file's mime type and size are in the specifications
		var 	file			=	this.file_inputTag.files[0],
				errorMessage 	= 	'';
		
		if(file.size>this.config.maxFileSize) errorMessage +=""
			+"<p>"
				+ T( 'attrValueTupleEditor_cFile.js/SizeOfFileErr_HTM',
					'The size of this file is <code>$[0]</code>&nbsp;kBytes and therefore bigger than the maximum permitted file size (<code>$[1]</code>&nbsp;kBytes).', 
					[	dojo.number.format(file.size/1024,{'pattern':'###,###,##0'}),
						dojo.number.format(this.config.maxFileSize/1024,{'pattern':'###,###,##0'}),
					] )
			+"</p>";
			//TG: Old Version without T() Call:
			// +"<p>"
			//	+ "The size of this file is <code>"
			//		+dojo.number.format(file.size/1024,{'pattern':'###,###,##0'})
			//	+"</code>&nbsp;kBytes and therefore bigger than the maximum permitted file size (<code>"
			//		+dojo.number.format(this.config.maxFileSize/1024,{'pattern':'###,###,##0'})
			//	+"</code>&nbsp;kBytes)."
			// +"</p>";
			
			
			
		if((this.config.allowedMimeTypes.length) && (dojo.indexOf(this.config.allowedMimeTypes, file.type)==-1)) errorMessage +=""
			+"<p>"
				+ T('attrValueTupleEditor_cFile.js/MIMETypeNotPerm_HTM','The MIME type of this file is <code>$[0]</code>. This MIME type is not permitted.' , [file.type])
			+"</p>"
				+"<p>" + T('attrValueTupleEditor_cFile.js/PermMTypes_TXT','Permitted MIME types are:') + "</p>"
				+"<ul><li class='code'>"
					+this.config.allowedMimeTypes.join("</li><li class='code'>")
				+"</li></ul>"
				;
		
		if(errorMessage) {
			application.showErrorMessage( ""
				+"<p>" + T('attrValueTupleEditor_cFile.js/YouWantToUpl_P1_HTM','You want to upload the file « <code>$[0]</code>» .' , [file.name] ) + "</p>"
				+errorMessage
				+"<p>" + T('attrValueTupleEditor_cFile.js/YouWantToUpl_P2_HTM','Therefore, this file cannot be uploaded. Sorry about that.') + "</p>"
			);
			return;
		} // end if
		
		// switch the widget to loading mode ...
		dojo.style(this.uploadImage_DOMNode,'display','inline-block');
		this.uploadButton_widget.attr('label','Uploading …');
		this.uploadButton_widget.attr('disabled',true);
		
		// upload the widget to the server ...
		dojo.require("dojo.io.iframe");
		var r = dojo.io.iframe.send({
			url: 	"?v=cFileAttribute_uploadFile",
			form: 	this.formUUID,
			method: "post",
			content: {
				'A_UUID'  : this.attrWidget.A_UUID,
			},
			scope: this,
			formId : this.id,
			timeoutSeconds: 5000,
			preventCache: true,
			handleAs: "json",
			load: function(data, ioArgs){
				if(data.type && data.type=='Exception') {
					application.showErrorMessage( (data.message)?data.message:
						""
						+ T('attrValueTupleEditor_cFile.js/UploadFailedMsg_TXT','Upload failed because of a server-side exception.')
						+"URL: <span class='code'>"+ioArgs.url+"</span>"
						+ T('attrValueTupleEditor_cFile.js/QueryCont_TXT','Query content:') + " <span class='code'>"+dojo.toJson(ioArgs.args.content)	+"</span>"
						); 
					
					dojo.style(ioArgs.args.scope.uploadImage_DOMNode,'display','none');
					ioArgs.args.scope.uploadButton_widget.attr('label','Upload a file …');
					ioArgs.args.scope.uploadButton_widget.attr('disabled',false);
				} else {
					ioArgs.args.scope.file_uploaded(data);
				} // end if exception
			},							
			error: function (error,ioArgs) {
				// it seems that all output goes to the "load" method, always ...
				application.showErrorMessage(error.message); 
				dojo.style(ioArgs.args.scope.uploadImage_DOMNode,'display','none');
				ioArgs.args.scope.uploadButton_widget.attr('label','Choose a file …');
				ioArgs.args.scope.uploadButton_widget.attr('disabled',false);
			}
		});
	} // end of method file_changed
	,
	'file_uploaded': function (data) {
	
		// localise the received data
		this.valueTuple.value_fileExtension 	= data.value_fileExtension;
		this.valueTuple.value_fileName 			= data.value_fileName;
		this.valueTuple.value_fileSize 			= data.value_fileSize;
		this.valueTuple.value_fileStoreFileName = data.value_fileStoreFileName;
		this.valueTuple.value_fileTitle 		= data.value_fileName;
		this.valueTuple.value_fileDescription 	= '';
		this.valueTuple.value_fileUploadTimepoint= data.value_fileUploadTimepoint;
		this.valueTuple.value_fileMimeType 		= data.value_fileMimeType;
		this.valueTuple.value_imageWidth 		= data.value_imageWidth;
		this.valueTuple.value_imageHeight 		= data.value_imageHeight;
		
		// set an additional flag for new files
		this.valueTuple.fileStatus				= 'newFileUploaded';
		
		// set each of these values		
		this.fileName_inputWidget.attr('value',this.valueTuple.value_fileName);
		this.fileExtension_DOMNode.innerHTML='.'+this.valueTuple.value_fileExtension;
		this.fileSize_DOMNode.innerHTML=dojo.number.format(this.valueTuple.value_fileSize/1024,{'pattern':'###,###,##0'});
		if(this.config.showTitle) 			this.fileTitle_inputWidget.attr('value',this.valueTuple.value_fileTitle);
		if(this.config.showDescription) 	this.fileDescription_inputWidget.attr('value',this.valueTuple.value_fileDescription);
		if(this.config.showUploadDatetime) 	this.uploadTimePoint_DOMNode.innerHTML=
												dojo.date.locale.format(
													new Date(this.valueTuple.value_fileUploadTimepoint)
												);
		this.fileMimeType_DOMNode.innerHTML=this.valueTuple.value_fileMimeType;
		if(this.valueTuple.value_imageWidth && this.valueTuple.value_imageHeight) {
			this.imageWidth_DOMNode.innerHTML=this.valueTuple.value_imageWidth;
			this.imageHeight_DOMNode.innerHTML=this.valueTuple.value_imageHeight;
			this.imageMPixel_DOMNode.innerHTML=dojo.number.format(this.valueTuple.value_imageWidth*this.valueTuple.value_imageHeight/1e6,{pattern:'###,##0.#'});
		} else {
			dojo.style(this.imageDimensions_DOMNode,'display','none');
		} // end if
		
		// connect the onChange functions
		this.connect(this.fileName_inputWidget, 'onChange', this.valuesChanged);
		if(this.config.showTitle) dojo.connect(this.fileTitle_inputWidget,'onChange',this,this.valuesChanged);
		if(this.config.showDescription) dojo.connect(this.fileDescription_inputWidget,'onChange',this,this.valuesChanged);

		// display the normal edit part of this widget
		dojo.style(this.uploadNewFile_domNode,'display','none');
		dojo.style(this.changeExistingFile_domNode,'display','block');		
		
	} // end of method file_uploaded
	,
	'postCreate' : function () {
		this.inherited(arguments);
		
		// two cases:
		// #1 : there is no file, yet --> offer an upload box
		// #2: there is file data : offer the usual input boxes
		
		if(!this.valueTuple.value_fileSize) { // there is no file, yet
			dojo.style(this.uploadNewFile_domNode,'display','block');
			dojo.style(this.changeExistingFile_domNode,'display','none');
			
			this.tooltip = new dijit.Tooltip({
				'label' : ""
					+"<p>" + T('attrValueTupleEditor_cFile.js/MaxFSize_TXT','Max. file size:') + " <code>"
						+dojo.number.format(this.config.maxFileSize/1024,{'pattern':'###,###,##0'})
					+"</code>&nbsp;KBytes</p>"
					+"<p>" + T('attrValueTupleEditor_cFile.js/PermFTypes_TXT','Permitted file types:') + " <ul><li class='code'>"
						+((this.config.allowedMimeTypes.length)?this.config.allowedMimeTypes.join("</li><li class='code'>"):'*.*')
					+"</li></ul></p>"
			}).addTarget(this.uploadButton_widget.domNode);
			
		} else { // there is file data
		
			// set the values of the tuple
			this.fileName_inputWidget.attr('value',this.valueTuple.value_fileName);
			this.fileExtension_DOMNode.innerHTML='.'+this.valueTuple.value_fileExtension;
			this.fileSize_DOMNode.innerHTML=dojo.number.format(this.valueTuple.value_fileSize/1024,{'pattern':'###,###,##0'});
			if(this.config.showTitle) 			this.fileTitle_inputWidget.attr('value',this.valueTuple.value_fileTitle);
			if(this.config.showDescription) 	this.fileDescription_inputWidget.attr('value',this.valueTuple.value_fileDescription);		
			if(this.config.showUploadDatetime) 	if (this.valueTuple.value_fileUploadTimepoint) {
				this.uploadTimePoint_DOMNode.innerHTML=dojo.date.locale.format(new Date(this.valueTuple.value_fileUploadTimepoint));
			}
			this.fileMimeType_DOMNode.innerHTML=this.valueTuple.value_fileMimeType;
			if(this.valueTuple.value_imageWidth && this.valueTuple.value_imageHeight) {
				this.imageWidth_DOMNode.innerHTML=this.valueTuple.value_imageWidth;
				this.imageHeight_DOMNode.innerHTML=this.valueTuple.value_imageHeight;
				this.imageMPixel_DOMNode.innerHTML=dojo.number.format(this.valueTuple.value_imageWidth*this.valueTuple.value_imageHeight/1e6,{pattern:'###,##0.#'});
			} else {
				dojo.style(this.imageDimensions_DOMNode,'display','none');
			} // end if

			dojo.style(this.uploadNewFile_domNode,'display','none');
			dojo.style(this.changeExistingFile_domNode,'display','block');
		
			// connect the onChange functions
			this.connect(this.fileName_inputWidget, 'onChange', this.valuesChanged);
			if(this.config.showTitle) 		dojo.connect( this.fileTitle_inputWidget,		'onChange', this,this.valuesChanged);
			if(this.config.showDescription) dojo.connect( this.fileDescription_inputWidget,	'onChange', this,this.valuesChanged);
			
			this.renderReadMode();

		} // end if
				
	} // end of method postCreate
	,
	'valuesChanged' : function (e) {
	
		//if(e) dojo.stopEvent(e);
	
		// localise the changed values
										this.valueTuple.value_fileName			= this.fileName_inputWidget.attr('value');
		if(this.config.showTitle) 		this.valueTuple.value_fileTitle			= this.fileTitle_inputWidget.attr('value');
		if(this.config.showDescription) this.valueTuple.value_fileDescription	= this.fileDescription_inputWidget.attr('value');

		// do nothing if some input is not valid
		if(!this.isValid()) return;
	
		// notify the attribute that the values have changed
		this.attrWidget.valueTupleHasChanged(this.valueTupleUUID, this.valueTuple);
		
		this.renderReadMode();
		
	} // end of method valuesChanged
	,
	'notifyAttributeOfChangedValue' : function () {
		// this method informs the connected attribute about the changed value tuple
		
		this.valuesChanged();
	} // end of method notifyAttributeOfChangedValue
	,
	'isValid' : function () {
	
		// trivial case: nothing uploaded, yet
		if (!this.config.mustBeSet && !this.valueTuple.value_fileSize) return true;
	
		// the normal case: there needs to be at least a file name
		var 							isValid	= this.fileName_inputWidget.isValid();
		if (this.fileTitle_inputWidget) isValid	= isValid && this.fileTitle_inputWidget.isValid();
		if(this.config.mustBeSet) 		isValid = isValid && !this.attrWidget.tuple_isEmpty(this.valueTuple);
		
		return isValid;
		
	} // end of method isValid
	,
	'renderReadMode' : function() {
		dojo.html.set(
			this.readMode_DOMNode,
			this.attrWidget.htmlFormatValueTuple_readMode(this.valueTuple),
			{'parseContent':true}
		);
	} // end of method renderReadMode
});

