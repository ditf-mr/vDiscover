<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # check if application is started correctly
		if ( ! defined('APPLICATION_started') or ! $repository_config ) {
			header('Location: ../../../..');
			exit;
		}
	}

	try { 

		# user permission are validated either in each task or in the backend functions 

		{ # get parameter
			$A_UUID = sanitize_string($_POST, 'A_UUID', $_GET); 
			if (is_null($attribute = $backend->getAttribute($A_UUID))) {
				throw new Exception('Attribute with A_UUID = "'.$A_UUID.'" not found.');
			}
			$status = sanitize_string($_GET, 'status', $_POST);
		}
		{ # decide whether a new file form uploads directory or an existing file from file_store 
		  # directory should be display.
			if ($status != 'newFileUploaded') { # existing file in file_store directory
				{ # get parameter
					$AV_UUID = sanitize_string($_GET, 'AV_UUID', $_POST);
					if (is_null($attributeValue = $backend->getCurrentAttributeValue($AV_UUID)))
						throw new Exception('Attribute value with AV_UUID = "'.$AV_UUID.'" not found.');
				}
				{ # get filename and check if file exists
					$filePathName = $repository_config['path_fileStore'] . DIRECTORY_SEPARATOR . $attributeValue->getStoreFileNameRegardingVersionType();
					if (! file_exists($filePathName)) {
						throw new Exception('File does not exist.');
					}
				}
			}
			else { # new temporary file in uploads directory
				{ # get parameter
					$uploadFileName = sanitize_string($_GET, 'uploadFileName', $_POST);
				}
				{ # check if file exists
					$filePathName = $repository_config['path_uploads'] . DIRECTORY_SEPARATOR . $uploadFileName;
					if (! file_exists($filePathName)) {
						throw new Exception('File does not exist.');
					}
				}
			} # end-of-if ($status != 'newFileUploaded')
		}
		{ # get mime type, see http://www.php.net/manual/de/function.finfo-file.php
			$finfo = finfo_open(FILEINFO_MIME_TYPE);
			$fileMimeType = finfo_file($finfo, $filePathName);
			finfo_close($finfo);
		}
		{ # send header and return file content
			header('Content-type: '.$fileMimeType);
			# do not send file as attachment.
			# header('Content-Disposition: attachment; filename="' . $attributeValue->value_fileName() . '"');
			readfile($filePathName);
		}
	} catch (Exception $e) {
		header('HTTP/1.1 500 Internal Server Error');
		header('Content-type: text/text');
		echo '<textarea>' 
				.
			json_encode(
				array(
					'type'		=> 'Exception',
					'message'	=> $e->getMessage(),
					'code'		=> $e->getCode(),
					'file'		=> $e->getFile(),
					'line'		=> $e->getLine(),
					'trace'		=> $e->getTraceAsString()
				)
				 
			).'</textarea>';
	} # end-of-try ... catch
?>