﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare('application.widgets.configureSpecialAttribute.cFileAttribute',[application.widgets.configureAttribute.genericConfigurationWidget],{
	'postMixInProperties': function() {
		this.inherited(arguments);
		
		// expand the template string
		this.addTemplateSection(""
			+"<tr>"
				+"<td class='textRight'>" + T('attrConfiguration_cFiles.js/MaxFSize_TXT','Max file size:') + "</td> "
				+"<td> "
					+"<input dojoType='dijit.form.NumberSpinner' smallDelta='"+(1*1024)+"' "
					+"constraints='{min:1,max:"+(20*1024)+",places:0}' style='width:7em;' "
					+"dojoAttachEvent='onChange:maxFileSize_changed,onFocus:showEditHints' "
					+"dojoAttachPoint='maxFileSize_nS' />"
					+"&nbsp;KBytes"
				+"</td>"
			+"</tr>"
			
			+"<tr>"
				+"<td class='textRight'>" + T('attrConfiguration_cFiles.js/PermMimeTypes_LBL','Permitted mime types<br/>(one per line):') + "</td>"
				+"<td>"
					+"<textarea dojoType='dijit.form.Textarea' class='code fullWidth' "
					+"dojoAttachPoint='allowedMimeTypesAsString_tA' "
					+"dojoAttachEvent='onChange:allowedMimeTypesAsString_changed,onFocus:showMimeTypeEditHints' "
					//+"dojoAttachEvent='onChange:allowedMimeTypesAsString_changed' "
					+">${allowedMimeTypesAsString_formatted}</textarea>"
				+"</td>"
			+"</tr>"
			
			+"<tr>"
				+"<td class='textRight'>" + T('attrConfiguration_cFiles.js/ShowTit_LBL','Show the title?') + "</td>"
				+"<td>"
					+"<label>"
						+"<input type='radio' dojoType='dijit.form.RadioButton' "
							+"name='application.widgets.configureAttributes.cFileAttribute.showTitle' "
							+"dojoAttachEvent='onChange:showTitle_changed,onFocus:showEditHints' "
							+"value='true' "
							+"dojoAttachPoint='showTitle_yes'/>"
							+ T('FUT_Yes','Yes')
					+"</label>"
					+"&nbsp;&nbsp;"
					+"<label>"
						+"<input type='radio' dojoType='dijit.form.RadioButton' "
							+"name='application.widgets.configureAttributes.cFileAttribute.showTitle' "
							+"dojoAttachEvent='onFocus:showEditHints' "
							+"value='false'  dojoAttachPoint='showTitle_no' />"
							+ T('FUT_No','No')
					+"</label>"
				+"</td>"
			+"</tr>"

			+"<tr>"
				+"<td class='textRight'>" + T('attrConfiguration_cFiles.js/ShowDescr_LBL','Show the description?') + "</td>"
				+"<td>"
					+"<label>"
						+"<input type='radio' dojoType='dijit.form.RadioButton' "
							+"name='application.widgets.configureAttributes.cFileAttribute.showDescription' "
							+"dojoAttachEvent='onChange:showDescription_changed,onFocus:showEditHints' "
							+"value='true' "
							+"dojoAttachPoint='showDescription_yes'/>"
							+ T('FUT_Yes','Yes')
					+"</label>"
					+"&nbsp;&nbsp;"
					+"<label>"
						+"<input type='radio' dojoType='dijit.form.RadioButton' "
							+"name='application.widgets.configureAttributes.cFileAttribute.showDescription' "
							+"dojoAttachEvent='onFocus:showEditHints' "
							+"value='false'  dojoAttachPoint='showDescription_no' />"
							+ T('FUT_No','No')
					+"</label>"
				+"</td>"
			+"</tr>"

			+"<tr>"
				+"<td class='textRight'>" + T('attrConfiguration_cFiles.js/ShowUploadTime_LBL','Show the upload time?') + "</td>"
				+"<td>"
					+"<label>"
						+"<input type='radio' dojoType='dijit.form.RadioButton' "
							+"name='application.widgets.configureAttributes.cFileAttribute.showUploadDatetime' "
							+"dojoAttachEvent='onChange:showUploadDatetime_changed,onFocus:showEditHints' "
							+"value='true' "
							+"dojoAttachPoint='showUploadDatetime_yes'/>"
							+ T('FUT_Yes','Yes')
					+"</label>"
					+"&nbsp;&nbsp;"
					+"<label>"
						+"<input type='radio' dojoType='dijit.form.RadioButton' "
							+"name='application.widgets.configureAttributes.cFileAttribute.showUploadDatetime' "
							+"dojoAttachEvent='onFocus:showEditHints' "
							+"value='false' dojoAttachPoint='showUploadDatetime_no' />"
							+ T('FUT_No','No')
					+"</label>"
				+"</td>"
			+"</tr>"
		);
		
		//localise the necessary variables
		this.locateProperties(['maxFileSize','allowedMimeTypesAsString','showTitle','showDescription','showUploadDatetime']);
		
		// generate the template string
		this.generateTemplateString();
		
		// provide the converted mime type list
		//console.log('WICHTIG');
		//console.log(this.allowedMimeTypesAsString);
		this.allowedMimeTypesAsString_formatted=this.allowedMimeTypesAsString.replace(/[,]/g,"\n");
		//console.log(this.allowedMimeTypesAsString_formatted);
		
	} // end of method postMixInProperties
	,
	'postCreate' : function() {
		this.inherited(arguments);

		// set the boolean options
		this.showTitle_yes			.attr('checked', this.showTitle);
		this.showTitle_no			.attr('checked', !this.showTitle);
		this.showDescription_yes	.attr('checked', this.showDescription);
		this.showDescription_no		.attr('checked', !this.showDescription);
		this.showUploadDatetime_yes	.attr('checked', this.showUploadDatetime);
		this.showUploadDatetime_no	.attr('checked', !this.showUploadDatetime);
		this.maxFileSize_nS			.attr('value', 	 this.maxFileSize/1024);
		
		
		// deal with inheritance
		this.maxFileSize_nS			.attr('disabled', this.isInherited);
		this.allowedMimeTypesAsString_tA.attr('disabled', this.isInherited);
		
		this.showTitle_yes			.attr('disabled', this.isInherited);
		this.showTitle_no			.attr('disabled', this.isInherited);

		this.showDescription_yes	.attr('disabled', this.isInherited);
		this.showDescription_no		.attr('disabled', this.isInherited);

		this.showUploadDatetime_yes	.attr('disabled', this.isInherited);
		this.showUploadDatetime_no	.attr('disabled', this.isInherited);
		
	} // end of method postCreate
	,
	'maxFileSize_changed' : function (e) {
		var v = this.maxFileSize_nS.attr('value');
		if (isNaN(v)) v=1;
		this.propertyHasChanged('maxFileSize',1024*v);
	} // end of method
	,
	'allowedMimeTypesAsString_changed' : function (e) {
		var input = this.allowedMimeTypesAsString_tA.attr('value').replace(' ','');
		// this.propertyHasChanged('allowedMimeTypesAsString',dojo.trim(input));
		this.propertyHasChanged('allowedMimeTypesAsString',input.replace(/[\r\n]+/g,','));
	} // end of method
	,
	'showTitle_changed' : function (e) {
		this.propertyHasChanged('showTitle',this.showTitle_yes.attr('checked'));
	} // end of method
	,
	'showDescription_changed' : function (e) {
		this.propertyHasChanged('showDescription',this.showDescription_yes.attr('checked'));
	} // end of method
	,
	'showUploadDatetime_changed' : function (e) {
		this.propertyHasChanged('showUploadDatetime',this.showUploadDatetime_yes.attr('checked'));
	} // end of method
});

