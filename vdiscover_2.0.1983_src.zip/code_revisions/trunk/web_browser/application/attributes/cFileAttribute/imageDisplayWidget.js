﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare('application.widgets.cImage',[dijit._Widget,dijit._Templated],{
	widgetsInTemplate: true
	,
	title	: null
	,
	qString	: null
	,
	value_fileDescription : null
	, 
	details	: null
	,
	/*constructor : function() {
		// Your constructor method will be called before the parameters are mixed into the widget, and can be used to initialize arrays, etc.
		//this.inherited(arguments);
		
	} // end of method constructor
	,*/
	postMixInProperties : function() {
		// If you provide a postMixInProperties method for your widget, 
		// it will be invoked before rendering occurs, and before 
		// any dom nodes are created. If you need to add or change the 
		// instance's properties before the widget is rendered 
		// - this is the place to do it.
		this.inherited(arguments);
		
		this.templateString = ""
			+"<div class='RS_A_cFA_outer RS_A_cFA_outerImage'>"
				+"<div class='RS_A_cFA_imageOuter textCenter'>"
					+"<img dojoAttachPoint='image_domNode' class='RS_A_cFA_image' src='${qString}' alt='${title}'/>"
				+"</div>"
				+(this.title?''
					+"<div class='RS_A_cFA_imageTitle strong textCenter'>"
						+"${title}"
						+"<a class='RS_MenuBarItem_withIcon RS_icon_download RS_A_cFA_imageDownloadIcon' "
							+"target='_new' title='" + T('imageDisplayWidget.js/ClickToDLImg_LNK','Click here to download this image') + "' href='${qString}'>"
						+"</a>"
					+"</div>"
				:'')
				+(this.value_fileDescription?''
					+"<div class='RS_A_cFA_imageDescription textCenter'>${value_fileDescription}</div>"
				:'')
				+(this.details?''
					+"<div class='RS_A_cFA_imageDetails small textCenter'>${details}</div>"
				:'')
			+"</div>"
		
	} // end of method postMixInProperties
	,
	/*
	buildRendering : function() {
		// dijit._Templated provides an implementation of buildRendering 
		// that most times will do what you need. The template is fetched/read, 
		// nodes created and events hooked up during buildRendering. The end 
		// result is assigned to this.domNode. If you don't mixin dijit._Templated 
		// (and most OOTB dijits do) and want to handle rendering yourself 
		// (e.g. to really streamline a simple widget, or even use a different 
		// templating system) this is where you'd do it.
		this.inherited(arguments);
	} // end of method buildRendering
	,*/
	/*
	postCreate : function() {
		// This is typically the workhorse of a custom widget. The widget has 
		// been rendered (but note that sub-widgets in the containerNode have not!). 
		// The widget though may not be attached to the DOM yet so you shouldn't 
		// do any sizing calculations in this method.
		this.inherited(arguments);
	} // end of method postCreate
	,
	*/
	startup : function() {
		// If you need to be sure parsing and creation of any child widgets has 
		// completed, use startup. This is often used for layout widgets like 
		// BorderContainer. If the widget does JS sizing, then startup() should 
		// call resize(), which does the sizing.
		//this.inherited(arguments);
		this._windowConnectLink = dojo.connect(window, "onresize", this, this.resize);
		this.resize();
	} // end of method startup
	,
    resize : function() {
		// All widgets that do JS sizing should have a method called resize(), that lays 
		// out the widget. Resize() should be called from startup() and will also be 
		// called by parent widgets like dijit.layout.ContentPane.

		if(this.domNode==null) return;

		var height	= this.domNode.clientHeight,
			width	= this.domNode.clientWidth;

		if (!height || !width) return;
		
		dojo.style( this.image_domNode, 'maxWidth',		Math.round(width*.8)	+"px" );
		dojo.style( this.image_domNode, 'maxHeight', 	Math.round(width*.8*1.5)+"px" );
	} // end of method resize
	,
	destroy : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you.
		
		dojo.disconnect(this._windowConnectLink);
		
		this.inherited(arguments);
	} // end of method destroy
	,
}); // end dojo.declare