<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # check if application is started correctly
		if ( ! defined('APPLICATION_started') or ! $repository_config ) {
			header('Location: ../../../..');
			exit;
		}
	}

	try { 

		{ # get parameter
			$A_UUID = sanitize_string($_POST, 'A_UUID', $_GET); 
			if (is_null($attribute = $backend->getAttribute($A_UUID))) {
				throw new Exception('Attribute with A_UUID = "'.$A_UUID.'" not found.');
			}
		}
		{ # read the file parameters
			$fileInfo=false;
			if (! $fileInfo = current($_FILES)) {
				throw new fatalError('No file uploaded.');
			}
		}
		{ # test of uploaded file
			if(array_key_exists('error', $fileInfo) and $fileInfo['error']) {
				switch ($fileInfo['error']) {
					case UPLOAD_ERR_OK: # everything ok
						break;
					case UPLOAD_ERR_INI_SIZE :
					case UPLOAD_ERR_FORM_SIZE :
						throw new Exception('Upload failed. The uploaded file exceeds the maximum permitted file size of '.number_format($a->maxFileSize(),0,'',',').' Bytes.'); 
						break;
					case UPLOAD_ERR_PARTIAL  :
						throw new Exception('Upload failed. The file was uploaded partially, only. Try again.');
						break;
					case UPLOAD_ERR_NO_FILE  :
						throw new Exception('Upload failed. No file was uploaded.');
						break;
					case UPLOAD_ERR_NO_TMP_DIR:
						throw new Exception('Upload failed. No temporary folder is specified in the php.ini file (see the <a target="PHP_manual" href="http://de.php.net/manual/en/ini.core.php#ini.upload-tmp-dir">php.ini settings reference in the PHP manual</a> about this.).');
						break;
						return 'Missing a temporary folder';
					case UPLOAD_ERR_CANT_WRITE:
						throw new Exception('Upload failed. Cannot write the file to the temporary folder.');
						break;
						return 'Failed to write file to disk';
					case UPLOAD_ERR_EXTENSION:
						throw new Exception('Upload failed. The file extension is not permitted.');
						break;
						return 'File upload stopped by extension'; 
					default:
						throw new Exception('Upload failed. The cause is unknown.');
				} # end-of-switch
			}
			{ # file size ok?
				if (filesize($fileInfo['tmp_name']) > $attribute->maxFileSize()) {
					throw new userError('The uploaded file is too big. The permitted maximum file size is '.number_format($attribute->maxFileSize(),0,'',',').' Bytes.');
				}
			}
			{ # file mime type ok?
				# (see http://www.php.net/manual/de/function.finfo-file.php) available for PHP >= 5.3.0
				$finfo = finfo_open(FILEINFO_MIME_TYPE);
				$file_MIME_type = finfo_file($finfo, $fileInfo['tmp_name']);
				finfo_close($finfo);
				if (count($attribute->allowedMimeTypes()) AND (! in_array($file_MIME_type, $attribute->allowedMimeTypes()))) { 
					throw new userError('The mime type "' . $file_MIME_type . '" of the uploaded file is not permitted.');
				}
			}
			{ # try to read width and height of image. On failure set width, heigth to 0.
				$imageWidth = 0;
				$imageHeight = 0;
				$size = getimagesize($fileInfo['tmp_name']);
				if (is_array($size)) {
					$imageWidth = $size[0];
					$imageHeight = $size[1];
				}
			}
				
		} 
		{ # move the uploaded file to the temporary file folder
			$fileName		= '';
			$fileEnding		= '';
			$localFileName	= '';
			$file_path		= '';
	
			{ # split file name in its parts
				$basename = sanitize_string($fileInfo, 'name');
				$fileEnding = pathinfo($basename, PATHINFO_EXTENSION); # taken from http://cowburn.info/2008/01/13/get-file-extension-comparison/
				$fileName = pathinfo($basename, PATHINFO_FILENAME);
			}
		
			$randomName = md5(uniqid('', true) . uniqid('', true));
		
			$localFileName= $randomName . '.' . $fileEnding;
		
			$file_path = $repository_config['path_uploads'] . DIRECTORY_SEPARATOR . $localFileName;
			if (! move_uploaded_file($fileInfo['tmp_name'], $file_path)) {
				throw new Exception ('Cannot move file "' . $fileInfo['tmp_name'] . '" to its new location "' . $file_path . '".');
			}

		}
		{ # return all necessary information to the web browser
			{ # clean the file name
				$fileName = preg_replace('/([=]|[^a-zA-Z0-9,-_])+/', '_', $fileName);
			}
			echo ( 
				'<textarea>' . 
				json_encode(
					array(
						'value_fileName'			=> $fileName,
						'value_fileExtension'		=> $fileEnding,
						'value_fileStoreFileName'	=> $localFileName,
						'value_fileSize'			=> filesize($file_path),
						'value_fileMimeType'		=> $file_MIME_type,
						'value_imageWidth'			=> $imageWidth,
						'value_imageHeight'			=> $imageHeight,
						'value_fileUploadTimepoint'	=> date('c',time())
					)
				) .
				'</textarea>'
			);
		}

	} catch (Exception $e) {
	
		header('HTTP/1.1 500 Internal Server Error');
		// # header('Content-type: application/json');
		echo (
			'<textarea>' .
			json_encode(
				array(
					'type'		=> 'Exception',
					'message'	=> $e->getMessage(),
					'code'		=> $e->getCode(),
					'file'		=> $e->getFile(),
					'line'		=> $e->getLine(),
					'trace'		=> $e->getTraceAsString()
				)
			) .
			'</textarea>'
		);
		
	} # end-of-try ... catch
	
	
?>