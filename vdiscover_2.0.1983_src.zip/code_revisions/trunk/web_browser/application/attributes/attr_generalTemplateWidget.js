﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// the following general class displays an attribute in both read and edit mode

dojo.declare("application.widgets.genericAttribute",[dijit._Widget,dijit._Templated],{

	// This attribute widget contains the main routines for displaying, retrieving and changing attribute values.
	// Children: application.widgets.standardAttribute AND application.widgets.cKeyValuePairAttribute

	// see file:///Y:/Gespiegelte%20Webseiten/Dojo%20Toolkit%20Documentation/DOJOTOOL/REFERENC/DIJIT/_WIDGET.HTM#dijit-widget
	// see as well file:///Y:/Gespiegelte%20Webseiten/Dojo%20Toolkit%20Documentation/DOJOTOOL/REFERENC/QUICKSTA/WRITINGW.HTM#quickstart-writingwidgets
	/*constructor : function() {
		// Your constructor method will be called before the parameters are mixed into the widget, and can be used to initialize arrays, etc.
		//console.log("application.widgets.genericAttribute",arguments);
	} // end of method constructor
	,*/
	'widgetsInTemplate' : true,

	// constants
	'_valueTupleSeparator':'; ',
	'_noValueSet':'<span title="' + T('attr_generalTemplateWidget.js/NoValueSet_TIT','This attribute has no value sets.') + '">&mdash;</span>',
	'_emptyValueTuple': {}, // needs to be overwritten in sub classes
	'addEmptyValueSet_inEditMode':true,

	'hasEstimationFunctionality' : false,

	// this variables need to be set on initialisation
	'isEmbedded' : false,
	'A_UUID'	: '',
	'O_UUID'	: '',
	'VT_UUID'	: '',
	'V_widgetId'	: '',
	'edit' : false,
	//subWidgets : null, // will be later set to []


	// these variables will be set automatically
	'viewWidget' : null, // dijit.widget.*
	'config' : {},
	'outputMode' : '', // either 'edit' or 'read'
	'valueTuples' : {},
	'valueTuples_edit_count' : 0, // the number of value tuples that are currently shown to the user
	'valueTuples_deleted' : null, // will be set to {}
	'valueTuples_changed' : null, // will be set to {}




	'templateString':'will be overwritten by postMixInProperties'
	,
	'postMixInProperties' : function() {
		// If you provide a postMixInProperties method for your widget,
		// it will be invoked before rendering occurs, and before
		// any dom nodes are created. If you need to add or change the
		// instance's properties before the widget is rendered
		// - this is the place to do it.
		this.inherited(arguments);

		// test if everything necessary was passed
	   if(typeof(this.A_UUID)		=='undefined' ) throw ('Cannot initialise application.widgets.genericAttribute without A_UUID. Aborting.');
	   if(typeof(this.O_UUID)		=='undefined' ) throw ('Cannot initialise application.widgets.genericAttribute without O_UUID. Aborting.');

		// some initialisations
		if(!this.valueTuples) this.valueTuples={};
		this.valueTuples_changed={};
		this.valueTuples_deleted={};
		//this.subWidgets=[];

		// get the attribute configuration and the value sets
		if (this.V_widgetId) {
			this.viewWidget = dijit.byId(this.V_widgetId);
			if(!this.viewWidget) throw 'Attribute widget with id="'+this.id+'": cannot locate the widget with id="'+this.V_widgetId+'".';

			// create a local reference to the configuration
			this.config={};
			if (this.viewWidget.relationAttributes) {
				this.config = this.viewWidget.relationAttributes[this.A_UUID];
			} else {
				this.config = this.viewWidget.attributesWithValueSets[this.A_UUID].attribute;
			} // end if

			// create local references to the value tuples, if any
			this.valueTuples={};
			if (this.viewWidget.attributesWithValueSets && this.viewWidget.attributesWithValueSets[this.A_UUID]) {
				if (this.viewWidget.attributesWithValueSets[this.A_UUID].values)
					this.valueTuples = this.viewWidget.attributesWithValueSets[this.A_UUID].values;
				else
					this.valueTuples = this.viewWidget.attributesWithValueSets[this.A_UUID];
			} // end if

			// tell the view widget that this attribute exists
			this.viewWidget.addToAttributeWidgetList(this.A_UUID, this);
			
		} // end if

		// decide the output mode
		this.outputMode= this.decideOutputMode();

		var tagType = (this.isEmbedded?'span':'div');
		var HTMLTagBefore 	= '<'+tagType+'>',
			HTMLTagAfter 	= '</'+tagType+'>';

		if ( (this.outputMode=='read') && this.config.svFormatActivated) {
			HTMLTagBefore 	= this.config.svHtmlTagBeforeValueTupleSet;
			HTMLTagAfter 	= this.config.svHtmlTagAfterValueTupleSet;
		} // end if

		// if HTMLTagBefore or HTMLTagAfter is empty: send an error message and apply some default HTML tags
		if ( !HTMLTagBefore || !HTMLTagAfter) {
			HTMLTagBefore 	= '<div title="Please enter some valid HTML tags for special formatting for this attribute!" style="background-color:red;">';
			HTMLTagAfter 	= '</div>';
		} // end if 
		
		// add the attach point for the containerNode
		HTMLTagBefore = HTMLTagBefore.replace('>', ' dojoAttachPoint="containerNode">');

		this.templateString=''
			+'<'+tagType+' '
				+'class="'
					+'RS_attribute '
					+((this.outputMode=='edit')?' RS_attribute_notCurrent':'')
					+(this.isEmbedded?' RS_attribute_embedded':'')
				+'" '
				+'dojoAttachEvent="onmouseenter:_onHover,onmouseleave:_onUnHover" '
			+' >'
					+HTMLTagBefore
						+((this.outputMode=='edit')?this.outputInEditMode():this.outputInReadMode())
					+HTMLTagAfter

					+((this.outputMode=='read')?'<'+tagType+' dojoAttachPoint="noValueSets_domNode">'+this._noValueSet+'</'+tagType+'>':'')
			+'</'+tagType+'>';

	} // end of method postMixInProperties
	,
	/*isInEditMode : function() {
		return (this.outputMode=='edit'); // boolean
	} // end of method isInEditMode
	,*/
	/*buildRendering : function() {
		// dijit._Templated provides an implementation of buildRendering
		// that most times will do what you need. The template is fetched/read,
		// nodes created and events hooked up during buildRendering. The end
		// result is assigned to this.domNode. If you don't mixin dijit._Templated
		// (and most OOTB dijits do) and want to handle rendering yourself
		// (e.g. to really streamline a simple widget, or even use a different
		// templating system) this is where you'd do it.
		this.inherited(arguments);
	} // end of method buildRendering
	,*/
	'showToolTips' : function () {
	
		// decide whether to output the attribute values in read or write mode
		if(this.outputMode=='edit') {

			// show tooltip
			if(this.config.editModeHint) {
				this.toolTip = new dijit.Tooltip({
					connectId: [this.domNode],
					label: this.config.editModeHint
				})
			} else if(this.config.readModeHint) {
				this.toolTip = new dijit.Tooltip({
					connectId: [this.domNode],
					label: this.config.readModeHint
				});
			};

		} else { // this.outputMode=='read'

			// show tooltip
			if(this.config.readModeHint) {
				this.toolTip = new dijit.Tooltip({
					connectId: [this.domNode],
					label: this.config.readModeHint
				})
			};
		} // end if output in edit/read mode

		// register the toolTip for the destroy routines
		if (this.toolTip) this._supportingWidgets.push(this.toolTip);
	
	} // end of method showToolTips
	,
	'postCreate' : function() {
		// This is typically the workhorse of a custom widget. The widget has
		// been rendered (but note that sub-widgets in the containerNode have not!).
		// The widget though may not be attached to the DOM yet so you shouldn't
		// do any sizing calculations in this method.
		this.inherited(arguments);

		this.showToolTips();
	} // end of method postCreate
	,
	'decideOutputMode' : function () {
		// this function decides, how an attribute is displayed
		if(this.edit && !this.config.readOnly) {
			 return 'edit';
		} else {
			 return 'read';
		} // end if
	} // end of method decideOutputMode
	,


	// read mode ------------------------------------

	'htmlFormatValueTuple_readMode' : function (valueTuple) {
		return '<div class="code small">'+dojo.toJson(this.config,true)+dojo.toJson(valueTuple,true)+'</div>';
	} // end of method htmlFormatValueTuple_ReadMode
	,
	'htmlFormatTupleSet_readMode' : function (valueTuples/*array*/){

		// this method returns the values sets in the valueSets formatted as a HTML string

		// set the formatting constants
		var svHtmlBefore					= (this.config.svFormatActivated
												?
													/*this.config.svHtmlTagBeforeValueTupleSet
													+*/	this.config.svHtmlTagBeforeValueTuple
												:
													''
												);

		var svHtmlBetween					= (this.config.svFormatActivated
												?
													this.config.svHtmlTagAfterValueTuple
													+	this.config.svHtmlTagBeforeValueTuple
												:
													''
												);
		if(!svHtmlBetween) svHtmlBetween	= this._valueTupleSeparator;

		var svHtmlAfter						= (this.config.svFormatActivated
												?
													this.config.svHtmlTagAfterValueTuple
													/*+	this.config.svHtmlTagAfterValueTupleSet*/
												:
													''
												);

		return ((valueTuples.length)?svHtmlBefore+valueTuples.join(svHtmlBetween)+svHtmlAfter:'');
	} // end of method
	,
	'outputInReadMode' : function() {

		// build the output value tuple set
		var vTSet=[], i='';
		for(i in this.valueTuples)
			if(!this.valueTuples_deleted[i])
				vTSet.push( this.htmlFormatValueTuple_readMode(this.valueTuples[i]) );

		// return the formatted value tuple set
		return this.htmlFormatTupleSet_readMode(vTSet);
	} // end of method outputInReadMode
	,
	'showHide_noValueTuplesMessage' : function () {
		if (this.noValueSets_domNode /*&& this.containerNode*/) {
			dojo.style(this.noValueSets_domNode,'display',( ( Object.keys(this.valueTuples).length ) ? 'none' : 'inline-block' ));
		} // end if
	} // end of method showHide_noValueTuplesMessage
	,


	// edit mode ----------------------------------

	'htmlFormatTuple_editMode' : function (tuple) {
		// this method returns a value tuple formatted for editing

		// Overwrite this method in a subclass!

		return this.htmlFormatValueTuple_readMode(tuple);
	} // end of method htmlFormatTuple_editMode
	,
	'htmlFormatTupleSet_editMode' : function (tupleSet/*array*/){
		// this method returns the values sets in the valueSets formatted as a HTML string for editing

		// Overwrite this method in a subclass!

		return '<p>Overwrite htmlFormatTupleSet_editMode in a subclass of application.widgets.genericAttribute!</p>\n'
			+this.htmlFormatTupleSet_readMode(tupleSet);

	} // end of method
	,
	'outputInEditMode' : function() {

		// build the output value set
		var valueTuples={};

		for(var i in this.valueTuples){
			valueTuples[i]=this.htmlFormatTuple_editMode(this.valueTuples[i]);
			this.valueTuples_edit_count++;
		} // end for .. in

		// add an empty value tuple, if there are no value tuples
		if( this.addEmptyValueSet_inEditMode && (Object.keys(valueTuples).length==0) ) {
			var new_UUID=Math.uuid();
			valueTuples[new_UUID] = this.htmlFormatTuple_editMode( this.getValueTuple(new_UUID) );
			this.valueTuples_edit_count++;
		} // end if

		// output the formatted value set
		 return this.htmlFormatTupleSet_editMode(valueTuples);

	} // end of method outputInEditMode
	,


	'setValueTuple_deleted' : function (valueTupleUUID) {
		// this method sets the value tuple with the specified number on the list of deleted ones

		this.valueTuples_deleted[valueTupleUUID]=valueTupleUUID;

		// tell the view that the value tuple got deleted
		if (this.viewWidget && this.viewWidget.attrValueTuple_hasChanged) {
			var vT=this.getValueTuple(valueTupleUUID);
			vT.status = 'deleted';
			this.viewWidget.attrValueTuple_hasChanged(this.A_UUID, valueTupleUUID, vT );
		} // end if
	} // end of method setValueTuple_deleted
	,


	'getValueTuple' : function(id) {
		// this method returns the requested value tuple or an empty value tuple, if the requested one does not exist.
		if (id in this.valueTuples_changed) return this.valueTuples_changed[id];
		if (id in this.valueTuples) 		return this.valueTuples[id];

		// If we get here, there is no value tuple, yet.
		// Let's create and return a new value tuple with empty values:
		return dojo.mixin( {}, this._emptyValueTuple, {
			'AV_UUID'			: id,
			'UUID' 				: Math.uuid(),
			'positionOfValue'	: 987654321,
			'status'			: 'new'
		});
	} // end of method getValueTuple
	,
	'valueTupleHasChanged' : function (valueTupleUUID, tupleObj) {
		// This method is called by the value tuple editors for communicating changes.
		// Its task is to store changed attribute value tuples.

		this.valueTuples_changed[valueTupleUUID]=tupleObj;

		// tell the view that the value tuple got changed
		if (this.viewWidget && this.viewWidget.attrValueTuple_hasChanged) {
			tupleObj.status = 'modified';
			this.viewWidget.attrValueTuple_hasChanged(this.A_UUID, valueTupleUUID, tupleObj);
		} // end if
	} // end of method valueTupleHasChanged
	,
	'getCleanAndOriginalVT' : function (VT_UUID) {
		// this method returns a the cleaned and original value tuple with the given VT_UUID
		// overwrite this method if necessary
		return this.valueTuples[VT_UUID];
	} // end of method getCleanAndOriginalVT
	,
	'getModifiedVT' : function (VT_UUID) {
		// this method returns the modified or new value tuple with the given VT_UUID
		if (this.valueTuples_changed[VT_UUID]) return this.valueTuples_changed[VT_UUID];
		return null;
	} // end of method getModifiedVT
	,
	'getChangedTupleSet' : function(/*optional*/cleaned) {
		// this method compiles the value tuple set that shall be sent to the server

		// passing the parameter cleaned forces to return just the slots that empty value tuples need to have

		var vTSet={};

		// iterate over all initial value tuples and mark them as 'untouched'
		for (var VT_UUID in this.valueTuples) {
			vTSet[VT_UUID]					= this.getCleanAndOriginalVT(VT_UUID);
			vTSet[VT_UUID].status			= 'untouched';
		} // end for .. in

		// iterate over all changed value tuples and mark them as 'changed'
		for (var VT_UUID in this.valueTuples_changed) {
			var changed_VT=this.getModifiedVT(VT_UUID);
			// does the changed value set already exist?
			if (vTSet[VT_UUID]) {
				// does already exist -> copy it as "modified"
				vTSet[VT_UUID]=dojo.mixin(vTSet[VT_UUID],changed_VT);
				vTSet[VT_UUID].status='modified';
			} else {
				// does not exist yet -> create a new one
				vTSet[VT_UUID]=changed_VT;
				vTSet[VT_UUID].status='new';
			} // end if
		} // end for .. in

		// iterate over all deleted value tuples and mark them as 'deleted'
		for (var VT_UUID in this.valueTuples_deleted) if (VT_UUID in vTSet) {
			if (vTSet[VT_UUID].kind=='cRelationAttribute') {
				vTSet[VT_UUID].status='deleted';
			} else {
				delete vTSet[VT_UUID];
			} // end if
		} // end for .. in

		// iterate over all value tuples and strip undefined ones
		var compactedVTSet={};
		for (var VT_UUID in vTSet)  {
			var vT = vTSet[VT_UUID];
			 // does the value set exist? Is it valid or deleted?
			if( dojo.isObject(vT) && Object.keys(vT).length &&	!this.tuple_isEmpty(vT) ) {
				compactedVTSet[VT_UUID]=vT;
			} // end if
		} // end for ... in

		// order everything according to the slot positionOfValue ascending		
		// A T T E N T I O N -- variable names need to be corrected in the return code, below!
		// var orderedVTSets = [];
		// for (var VT_UUID in compactedVTSet)  {
			// orderedVTSets[ compactedVTSet[VT_UUID].positionOfValue ] = VT_UUID;
		// } // end for .. in
		// var finalvTSet={};
		// dojo.forEach(orderedVTSets, function(VT_UUID, pOV) {
			// if (VT_UUID) finalvTSet[VT_UUID] = compactedVTSet[VT_UUID];
		// }, this); // end dojo.forEach
		
		// return the value tuples
		if (cleaned) { // return a cleaned version
			var eVT = this._emptyValueTuple;

			var cleanedVTSet = {};

			for (var VT_UUID in compactedVTSet) {
				var VT = compactedVTSet[VT_UUID];

				cleanedVTSet[VT_UUID] = {};
				for (var s in eVT) cleanedVTSet[VT_UUID][s]=VT[s];

			} // end for .. in

			return cleanedVTSet;
		} else {
			return  compactedVTSet;
		};

	} // end of method getChangedTupleSet
	,


	'tuple_isEmpty' : function (tuple) {
		// overwrite this method in sub classes
		alert('application.widgets.genericAttribute.tuple_isEmpty(tuple) called.\n'
			+'You need to overwrite this generic function in sub classes.\n'
			+'\nDebug info: tuple='+dojo.toJson(tuple)+'\n'
			+'The function needs to return true if the tuple is considered to be an empty one, otherwise false.');
		return true;
	} // end of method tuple_isEmpty
	,
	'isValid' : function () {
		// overwrite this method in sub classes
		alert('application.widgets.genericAttribute.isValid() called.\n'
			+'You need to overwrite this generic function in sub classes.\n'
			+'The function needs to return true if all values in the tuple are valid ones, otherwise false.');
		return false;
	} // end of method isValid
	,


	/*startup : function() {
		// If you need to be sure parsing and creation of any child widgets has
		// completed, use startup. This is often used for layout widgets like
		// BorderContainer. If the widget does JS sizing, then startup() should
		// call resize(), which does the sizing.
		this.inherited(arguments);
	} // end of method startup
	,*/
	/*markAsCurrent : function () {

		if (this.viewWidget) {

			// tell all other attributes that they are not current
			this.viewWidget.markAllAttributes_normal();

			// mark this attribute as 'current'
			dojo.toggleClass(this.domNode, 'RS_attribute_current', true);

			// tell the view that the current widget has the focus
			// this.viewWidget.setCurrentAttr_widget(this);

		} // end if

	} // end of function markAsCurrent
	,
	markAsNormal : function () {
		dojo.toggleClass(this.domNode, 'RS_attribute_current', false);
		dojo.toggleClass(this.domNode, 'RS_attribute_dependent', false);
	} // end of function markAsNormal
	,
	markAsDependent : function () {
		dojo.toggleClass(this.domNode, 'RS_attribute_dependent', true);
	} // end of method markAsDependent
	,*/
	'formsPartOfAnEquationSystem' : function () {
		if (!this.viewWidget || !(typeof this.viewWidget.attrFormsPartOfEQSystem=='function') ) return false;
		return this.viewWidget.attrFormsPartOfEQSystem(this.A_UUID);
	} // end of method formsPartOfAnEquationSystem
	,
	'setConstant' : function(c) {
		// overwrite this method in child widgets
	} // end of method setConstant
	,

	// the following slot needs to be set to true if the current attribute value
	// can be accessed via the function getCurrentValue
	'currentValueAccessible' : false // boolean
	,
	'getCurrentValue' : function () {
		return null;
	} // end of method getCurrentValue
	,


	'markAs_notValid' : function () {
		dojo.toggleClass(this.domNode, 'RS_VTE_notValid', true);
		this.attr('title', T('attr_generalTemplateWidget.js/ValueTplNotValid_TXT','This value tuple is not valid.') );
	} // end of method markAs_notValid
	,
	'remove_notValidMark' : function () {
		dojo.toggleClass(this.domNode, 'RS_VTE_notValid', false);
		this.attr('title', '');
	} // end of method remove_notValidMark
	,


	'_highlightClasses' : 'RS_attribute_highlight' // 'dijitMenuBar RS_attribute_highlight'
	,
	'highlightIfTagged' : function ( T_UUID ) {
		dojo.toggleClass(this.domNode, this._highlightClasses, (dojo.indexOf(this.config.tags, T_UUID)>=0));
	} // end of method highlightIfTagged
	,


	// let's highlight this attribute on mouseOver
	'_hoverclasses' : 'RS_attribute_current'
	,
	'_onHover' : function() {
		dojo.addClass(this.domNode, this._hoverclasses);
	} // end of method _onHover
	,
	'_onUnHover' : function() {
		dojo.removeClass(this.domNode, this._hoverclasses);
	} // end of method _onUnHover
	,








	'executeAnalyticalExpression' : function () {

		// return if nothing to do
		if (!this.config.enableAnalyticalExpressions || !this.config.analyticalExpressionConfig_asJSON) return;

		// unpack the analytical expression configuration, if necessary
		if (!this.config.analyticalExpressionConfig) this.config.analyticalExpressionConfig = dojo.fromJson(this.config.analyticalExpressionConfig_asJSON);
		if(! 'attrVars' in this.config.analyticalExpressionConfig) this.config.analyticalExpressionConfig.attrVars = {};
		// return if there is no function body
		if(! 'funcBody' in this.config.analyticalExpressionConfig || !this.config.analyticalExpressionConfig.funcBody.length) return;

		// get the current value tuple UUID
		var VT_UUID = Object.keys(this.getChangedTupleSet())[0]; // the first key in the returned value tuple set
		// get a default value tuple
		var defaultVT_JSON = application.attributeKinds.getDefaultValueTupleasJson(this.config.kind);

		// get the input value tuples
		var inputVTs 			= {},
			allInputVTsAreValid = true,
			resVT				= {};

		for (var A_UUID in this.config.analyticalExpressionConfig.attrVars) {
			var attrVar = this.config.analyticalExpressionConfig.attrVars[A_UUID];
			var vT = this.viewWidget.attributeWidgetList[A_UUID].buildSimplifiedValueTuple();
			if (vT == null) {
				//console.log("The attribute "+A_UUID+" has no valid value tuple.");
				allInputVTsAreValid = false;
				break;
			} // end if
			// console.log(vT);
			inputVTs[A_UUID]=vT;
		} // for ... in

		// everything ok?
		if (allInputVTsAreValid) {

		// build the analytical expression

			// build the function body
			var func = 'function () {\n'
				+'// INPUT VALUE TUPLES -----------------------------------------------------\n'
				;
			// build the variable list
			for (var A_UUID in inputVTs) {
				func += ''
					+'var '+this.config.analyticalExpressionConfig.attrVars[A_UUID].varName
						+' = '+dojo.toJson(inputVTs[A_UUID])+';\n';
			} // end for .. in

			func += ''
				+'// OUTPUT VALUE TUPLE ----------------------------------------------------\n'
				+'var valueTuple = '+defaultVT_JSON+';\n'
				+'// FUNCTION BODY ---------------------------------------------------------\n\n'
				+this.config.analyticalExpressionConfig.funcBody+'\n\n'
				+'// -----------------------------------------------------------------------\n'
				+'return valueTuple;\n'
				+'}\n';
			// console.log(func);

			// execute the analytical expression and store the changes
			var tJSON 	= '',
				tObj	= {};

			try{
				tJSON 	= '{"f":'+func+'}';
				tObj	= dojo.fromJson(tJSON);

				resVT = tObj.f();
				// console.log(dojo.toJson(resVT, true));

			} catch(e) {
				console.error(e);
				alert( T('attr_generalTemplateWidget.js/analExpreConfig_clickToEdit', 'Cannot execute the assignation function, correctly.\nThe JavaScript error:\n$[0]\nThe function:\n$[1]', [e.toString(), func]));

				return;
			} // end try .. catch
		} else {

			resVT = dojo.clone(this._emptyValueTuple);

		}// end if everything ok

		// tell the value tuple editor that the value tuple has changed -- the value tuple editor should take care of the rest
		this.setValueTuple(VT_UUID, resVT);

	} // end of method executeAnalyticalExpression
	,
	'buildSimplifiedValueTuple' : function () {
		// This method copies all relevant slots of the current value tuple to a default value tuple and returns it.
		var defaultVT = application.attributeKinds.getDefaultValueTuple(this.config.kind),

			vTSet 			= this.getChangedTupleSet(),
			firstVT_UUID 	= Object.keys(vTSet)[0],
			currentVT 		= vTSet[firstVT_UUID];

		// return null if the current value tuple is empty
		if (this.tuple_isEmpty(currentVT)) return null;

		for (var s in defaultVT) {
			defaultVT[s]=currentVT[s];
		} // end for .. in

		return defaultVT;
	} // end of method buildSimplifiedValueTuple
	,
	'setValueTuple' : function (VT_UUID, vT) {

		alert(this.declaredClass+' :: setValueTuple (): this method is not defined, but called.' );

	} // end of method setValueTuple
	,
	'attrVTIsInputForAnalyticalExpression' : function (A_UUID) {

		// return if nothing to do
		if (!this.config.enableAnalyticalExpressions || !this.config.analyticalExpressionConfig_asJSON) return;

		// unpack the analytical expression configuration, if necessary
		if (!this.config.analyticalExpressionConfig) this.config.analyticalExpressionConfig = dojo.fromJson(this.config.analyticalExpressionConfig_asJSON);
		if(! 'attrVars' in this.config.analyticalExpressionConfig) this.config.analyticalExpressionConfig.attrVars = {};

		return (A_UUID in this.config.analyticalExpressionConfig.attrVars);
	} // end of method attrVTIsInputForAnalyticalExpression
	,
});
