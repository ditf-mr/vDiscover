/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare(
	'application.widgets.configureAttribute.generalConfiguration',
	[application.widgets.configureAttribute.genericConfigurationWidget],{
	
	'postMixInProperties' : function() {
		// If you provide a postMixInProperties method for your widget, 
		// it will be invoked before rendering occurs, and before 
		// any dom nodes are created. If you need to add or change the 
		// instance's properties before the widget is rendered 
		// - this is the place to do it.
		this.inherited(arguments);
		
		this.locateProperties([
			'displayedUUID',
			'description',
			'readModeHint',
			'editModeHint',
			'displayInFullWidth'
		]);
		
		this.addTemplateSection( ''
			+"<tr>"
				+"<td class='textRight'>" + T('attrConfiguration_general.js/AttrKind_TXT','Attribute kind:') + "</td>"
				+"<td class='code small'>${kind}</td>"
			+"</tr>"
			
			+"<tr>"
				+"<td class='textRight'>UUID:</td>"
				+"<td class='code small'>${displayedUUID}</td>"
			+"</tr>"
			
			+"<tr>"
				+"<td class='textRight' style='vertical-align:baseline;'>" + T('attrConfiguration_general.js/DocuAdmOnly_TXT','Documentation (admin-only):') + "</td>"
				+"<td>"
						+"<textarea name='description' "
							+"dojoType='dijit.form.Textarea' "
							+"dojoAttachPoint='description_Ta' "
							+"dojoAttachEvent='onfocus:showEditHints' "
							+"class='fullWidth' "
							+"disabled='${isInherited}' "
							+">${description}</textarea>"
				+"</td>"
			+"</tr>"
			
			+"<tr>"
				+"<td class='textRight' style='vertical-align:baseline;'>" + T('attrConfiguration_general.js/HintForUserReadMode_HTM','Hint for the users in <i>read</i> mode:') + "</td>"
				+"<td>"
						+"<textarea name='readModeHint' "
							+"dojoType='dijit.form.Textarea' "
							+"dojoAttachPoint='readModeHint_Ta' "
							+"dojoAttachEvent='onfocus:showEditHints' "
							+"class='fullWidth' "
							+"disabled='${isInherited}' "
							+">${readModeHint}</textarea>"
				+"</td>"
			+"</tr>"
			
			+"<tr>"
				+"<td class='textRight' style='vertical-align:baseline;'>" + T('attrConfiguration_general.js/HintForUserEditMode_HTM','Hint for the users in <i>edit</i> mode:') + "</td>"
				+"<td>"
						+"<textarea name='editModeHint' "
							+"dojoType='dijit.form.Textarea' "
							+"dojoAttachPoint='editModeHint_Ta' "
							+"dojoAttachEvent='onfocus:showEditHints' "
							+"class='fullWidth' "
							+"disabled='${isInherited}' "
							+">${editModeHint}</textarea>"
				+"</td>"
			+"</tr>"
			
			+"<tr>"
				+"<td class='textRight'>" + T('attrConfiguration_general.js/DispValTpls_TXT','Display the value tuples') + " …</td>"
				+"<td>"
					+"<p style='padding-left:2em;text-indent:-2em;'>"
						+"<label>"
							+"<input type='radio' dojoType='dijit.form.RadioButton' "
								+"name='application.admin.manageAttributes.displayInFullWidth' "
								+"dojoAttachPoint='rB_displayInFullWidth_no' "
								+"dojoAttachEvent='onfocus:showEditHints' "
								+"disabled='${isInherited}' "
								+"value='no' />"
								+ T('attrConfiguration_general.js/InStdWidth_HTM','in <em>standard width</em> (the attribute name will be displayed on the left hand side of the value tuples).')
						+"</label>"
					+"</p>"
					+"<p style='padding-left:2em;text-indent:-2em;'>"
						+"<label>"
							+"<input type='radio' dojoType='dijit.form.RadioButton' "
								+"name='application.admin.manageAttributes.displayInFullWidth' "
								+"dojoAttachPoint='rB_displayInFullWidth_yes' "
								+"dojoAttachEvent='onfocus:showEditHints' "
								+"disabled='${isInherited}' "
								+"value='true' />"
								+ T('attrConfiguration_general.js/InFullWidth_HTM','in <em>full width</em> (the attribute name will be displayed ontop on the value tuples).')
						+"</label>"
					+"</p>"
					+"<p>"
						+ T('attrConfiguration_general.js/ThisSettingsOnlyAppl_TXT','This setting only applies for views containing attribute lists.')
					+"</p>"
				+"</td>"
			+"</tr>"
		);
				
		// generate the template string
		this.generateTemplateString();
	} // end of method postMixInProperties
	,
	'rB_displayInFullWidth_changed' : function (e) {
		this.propertyHasChanged('displayInFullWidth', this.rB_displayInFullWidth_yes.attr('checked'));
	} // end of method rB_displayInFullWidth_changed
	,
	'postCreate' : function() {
		// This is typically the workhorse of a custom widget. The widget has 
		// been rendered (but note that sub-widgets in the containerNode have not!). 
		// The widget though may not be attached to the DOM yet so you shouldn't 
		// do any sizing calculations in this method.
		this.inherited(arguments);
		
		if(this.displayInFullWidth) {
			this.rB_displayInFullWidth_yes.attr('checked',true);
		} else {
			this.rB_displayInFullWidth_no.attr('checked',true);
		} // end if
		
		// connect all input widgets
		if(!this.isInherited) {
			this.connect(	this.description_Ta,			'onChange', 'description_changed');
			this.connect(	this.readModeHint_Ta,			'onChange', 'readModeHint_changed');
			this.connect(	this.editModeHint_Ta,			'onChange', 'editModeHint_changed');
			this.connect(	this.rB_displayInFullWidth_no,	'onChange', 'rB_displayInFullWidth_changed');
			this.connect(	this.rB_displayInFullWidth_yes,	'onChange', 'rB_displayInFullWidth_changed');
		
		} // end if
		
	} // end of method postCreate
	,
	'description_changed' : function(e) {
		this.propertyHasChanged('description', this.description_Ta.attr('value'));
	} // end of method
	,
	'readModeHint_changed' : function(e) {
		this.propertyHasChanged('readModeHint', this.readModeHint_Ta.attr('value'));
	} // end of method
	,
	'editModeHint_changed' : function(e) {
		this.propertyHasChanged('editModeHint', this.editModeHint_Ta.attr('value'));
	} // end of method
	,
});

