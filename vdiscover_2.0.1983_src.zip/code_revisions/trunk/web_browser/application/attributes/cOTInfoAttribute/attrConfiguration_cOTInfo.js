﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare(
	'application.widgets.configureSpecialAttribute.cOTInfoAttribute',
	[application.widgets.configureAttribute.genericConfigurationWidget],{
	
	'infoKind_changed': function() {
	
		this.infoKind = 'name'; // default value		
		var permittedConfigurationOptions =dojo.fromJson(this.configurationParameter);
		for (var option in permittedConfigurationOptions) {
			if (this['rB_'+option+'_widget'].get('checked')) 	{
				this.infoKind = option;
			} // break;
		} // end for .. in 
		
		this.propertyHasChanged('infoKind', 	this.infoKind);
	} // end of infoKind_changed
	,
	'postMixInProperties'			: function() {
		this.inherited(arguments);
		
		//localise the necessary variables
		this.locateProperties(['infoKind', 'configurationParameter']);
		
		var permittedConfigurationOptions = {};
		
		if(!this.configurationParameter) { // this happens when creating the object
			dojo.xhrGet({
				'scope'			: this,
				'url'			: '?',
				'content' 		: {
					'v'			: 'JSON_Attribute',
					'task'		: 'get_cOTInfoAttribute_configurationParameter',
				},
				'sync' 			: true,
				'handleAs' 		: 'json',
				'load' 			: function (a, ioargs) {
					ioargs.args.scope.configurationParameter=a;
				} // end of method load
			});
			permittedConfigurationOptions	= this.configurationParameter;
			this.configurationParameter		= dojo.toJson(this.configurationParameter);
			this.propertyHasChanged('configurationParameter', this.configurationParameter);
		} else {
			permittedConfigurationOptions =dojo.fromJson(this.configurationParameter);
		} // end if
		
		if (!(this.infoKind in permittedConfigurationOptions)) {
			this.infoKind='name';
			this.propertyHasChanged('infoKind', 	this.infoKind);
		} // end if
		
		var templateSections = [];
		for (var option in permittedConfigurationOptions) {
			var optionDescription = permittedConfigurationOptions[option];
			
			templateSections.push( ''
				+"<p style='text-indent:-2em;padding-left:2em;'><label>"
					+'<input type="radio" dojoType="dijit.form.RadioButton" '
						+'name="infoKind" '
						+'value="'+option+'" '
						+'checked="'+(this.infoKind==option)+'"  '
						// +'disabled="${isInherited}" '
						+'dojoAttachEvent="onClick:infoKind_changed" '
						+'dojoAttachPoint="rB_'+option+'_widget" '
					+'/> '
					+optionDescription
				+"</label></p>"			
			);
		} // end for .. in
		
		// expand the template string
		this.addTemplateSection(""
			+"<tr>"
				+"<td class='textRight'>" + T('attrConf_cOTInfo.js/WhatInfoToDisp_TXT','What information do you want to display?') + "</td>"
				+"<td>"
					+"<div dijit.form.Form>"
						+templateSections.join('')
					+"</div>"
				+"</td>"
			+"</tr>"
		);
		
		// generate the template string
		this.generateTemplateString();
		
	} // end of method postMixInProperties
	,
	'postCreate' : function () {
	
		if (this.isInherited) {
			var subWidgets = dijit.findWidgets(this.domNode);
			
			dojo.forEach(subWidgets, function(w){ w.attr('disabled', true )});
		
		} // end if
	
	} // end of method postCreate
});
