﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare("application.widgets.cOTInfoAttribute",[application.widgets.standardAttribute],{
	/*_emptyValueTuple: { value_text : '' }
	,
	valueTupleEditor_name: 'application.widgets.valueTupleEditor_cOTInfoAttribute'
	,*/
	tuple_isEmpty : function (tuple) {		
		return false;
	} // end of method tuple_isEmpty
	,
	htmlFormatValueTuple_readMode : function (valueTuple) {
		return valueTuple.valueAsText;
	} // end of method htmlFormatValueTuple_ReadMode

}); // end of declaration
