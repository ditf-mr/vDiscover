﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

application.attributeKinds.register({kind: "cOTInfoAttribute", 
	defaultConfiguration : {
	
		'configurationParameter': '', // this forces loading the configuration parameter list from the server
		'infoKind'				: 'name',
	
		'cardinality'			: 1, 
		
		'svFormatActivated'		: false,
		'svHtmlBefore'			: '',
		'svHtmlBetween'			: '',
		'svHtmlAfter'			: '',
	}
	,
	'fixedReadOnly' 			: true
	,
	'fixedCardinality' 			: true
	,
	'widgetClass'				: 'application.widgets.cOTInfoAttribute'
	,
	// defaultRetrievalValues:['search_text']
	// ,
	'configurationWidgetClass' : 'application.widgets.configureAttributes.cOTInfoAttribute'
	// , 
	// getParsedQuery: function(item,rqWidget) {
		// if (rqWidget.attributeStore.getValue(item,'search_text')){
			// return rqWidget.attributeStore.getValue(item,'name')+' contains \"'+rqWidget.attributeStore.getValue(item,'search_text')+'\"';
		// }
	// } // end of method getParsedQuery
	,
	'useValueTupleAsExpressionInput'	: false
	,
	'expressionsPermitted'				: false
	,


});

