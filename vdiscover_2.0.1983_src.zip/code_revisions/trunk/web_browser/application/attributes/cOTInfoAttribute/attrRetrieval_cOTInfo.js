﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

/*
dojo.declare('application.widgets.retrieveAttributes.cSingleLineAttribute',[application.widgets.retrieveAttributes.genericAttribute],{
	searchString_changed: function(e){
		this.propertyHasChanged('search_text',this.searchString_tB.attr('value'));
	}
	,
	postMixInProperties : function() {
		// If you provide a postMixInProperties method for your widget, 
		// it will be invoked before rendering occurs, and before 
		// any dom nodes are created. If you need to add or change the 
		// instance's properties before the widget is rendered 
		// - this is the place to do it.
		this.inherited(arguments);

		//localise the necessary variables
		this.locateProperties(['search_text','name']);
		
		this.title = "Search for * in « "+this.name+"» ";
		
		// expand the template string
		this.addTemplateSection(""
			+"<tr>"
				+"<td>"
					+"<input type='text' style='width:100%'"
						+"value='${search_text}'" 
						+"dojoAttachEvent='onChange:searchString_changed' "
						+"dojoAttachPoint='searchString_tB' "
						+"dojoType='dijit.form.ValidationTextBox'"
					+"/>"
				+"</td>"
			+"</tr>"	
			+"<tr>"
				+"<td>"
					+"<p>You can use wildcards to improve the results:</p>"
						+"<ul>"
							+"<li><code>*</code> finds any char sequence, "
								+"e.g.<br/>« <code>black*</code>»  finds <code>black<i>bear</i></code>,"
								+"<code>black<i>bird</i></code> and just <code>black</code>. Otherwise"
								+"<br/>« <code>*berry</code>»  finds <code><i>black</i>berry</code>,"
								+"<code><i>straw</i>berry</code> and of course <code>berry</code>."
							+"</li>"
						+"</ul>"
				+"</td>"
			+"</tr>"
		);
		

		if(!this.search_text) {
			this.search_text ='';
		}		
		// generate the template string
		this.generateTemplateString();
		
	} // end of method postMixInProperties
});
*/
