/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// the following generic class is for attribute value retrieval

// this widget is a super class for value tuple editor. It puts a delete button next to the editor.
dojo.declare("application.widgets.editStdValTuple_delWrapper",[dijit._Widget,dijit._Templated],{
	// the main functionality of this class is to wrap a 
	// value tuple to be edited into the necessary HTML 
	// and to provide deleting functionality.
	
	// general settings
	'widgetsInTemplate'		: true,
	'_destroyOnRemove' 		: true, // see http://dojotoolkit.org/reference-guide/dojox/grid/DataGrid.html
	
	// these variables need to be passed
	'valueTupleUUID' 		: null, // the corresponding value tuple UUID within the set
	'valueTupleEditor_name' : null,
	'attrWidget'			: null,

	// internal variables
	'_deleted'				: false, // boolean
	'templateContainer'		: '', // string
	
	'constructor' : function() {
		// Your constructor method will be called before the parameters are mixed into the widget, and can be used to initialize arrays, etc.
		this._deleted = false;
		this.templateContainer = '';
	} // end of method constructor
	,
	'postMixInProperties' : function() {
	
		// test if everything necessary was passed on initialising
		if(typeof(this.attrWidget)!='object') throw ('Cannot initialise "'+this.declaredClass+'" without attrWidget reference. Aborting.');
		if(typeof(this.valueTupleUUID)		!='string') throw ('Cannot initialise "'+this.declaredClass+'" without valueTupleUUID. Aborting.');

		// register this value tuple editor	
		this.templateString = ''
			+'<div class="RS_valueTuple_edit" >'
			
				// delete button
				+'<div dojoAttachEvent="onclick:_deleteClick" class="RS_valueTuple_editIcon RS_icon_delete" title="' + T('attrValueTupleEditor_delWrapper.js/DelThisValTpl_BTN','Delete this value tuple.') + '"></div>'
				
				// up & down buttons
				// +(this.attrWidget.isEmbedded && (this.config.cardinality!=1))? ''
					+'<table class="RS_valueTuple_upDownBox compact" dojoAttachPoint="_upDownButtonBox_domNode"></tbody>'
						+'<tr><td class="RS_valueTuple_upDownBox_td">'
							+'<img src="./third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/go-up-7.png" class="RS_valueTuple_upDownButton" dojoAttachPoint="_upButton_domNode" dojoAttachEvent="onclick:_upButtonClicked" title="' + T('attrValueTupleEditor_delWrapper.js/MvValUp_BTN','Move this value tuple up.') + '"/>'
						+'</td></tr>'
						+'<tr><td class="RS_valueTuple_upDownBox_td">'
							+'<img src="./third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/go-down-7.png" class="RS_valueTuple_upDownButton" dojoAttachPoint="_downButton_domNode" dojoAttachEvent="onclick:_downButtonClicked" title="' + T('attrValueTupleEditor_delWrapper.js/MvValDown_BTN','Move this value tuple down.') + '"/>'
						+'<td><tr>'
					+'</tbody></table>'
				// :'')
				
				// container for the value tuple editor
				+'<div class="RS_valueTuple_editInner'+(this.attrWidget.isEmbedded?'_isEmbedded':'')+'" '
					+'dojoAttachPoint="containerNode">\n\n'+this.templateContainer+'\n\n</div>'
				
			+'</div>'
		;
	
	} // end of method postMixInProperties
	,
	'_upButtonClicked' : function (e) {
		dojo.stopEvent(e);
		this.attrWidget.moveVTWidget(this, 'up');
	} // end of method _upButtonClicked
	,
	'_downButtonClicked' : function (e) {
		dojo.stopEvent(e);
		this.attrWidget.moveVTWidget(this, 'down');		
	} // end of method _downButtonClicked
	,
	'_deleteClick' : function (e) {
		dojo.style(this.domNode,'display','none');
		this.deleted=true;
		// tell the attribute that the value tuple got deleted
		this.attrWidget.setValueTuple_deleted(this.valueTupleUUID);
	} // end of method _deleteClick
	,
	'_showHide_upDownArrows' : function (index, numVTEditors) {
	
		if (!this.attrWidget.config.valueTupleReordering_permitted) return;
	
		// show the up arrow only, if needed
		dojo.style( this._upButton_domNode, 	'display', ( (index>1)				? 'block'	: 'none' ));
		
		// show the down arrow only, if needed
		dojo.style( this._downButton_domNode, 	'display', ( (index<numVTEditors)	? 'block'	: 'none' ));
		
	} // end of method _showHide_upDownArrows
	,
	'postCreate' : function () {
		this.inherited(arguments);
		
		if(!this.attrWidget.config.valueTupleReordering_permitted || (this.attrWidget.config.cardinality==1)) 
			dojo.style(this._upDownButtonBox_domNode, 'display', 'none');
		
	} // end of method postCreate
	,
}); // end of class definition application.widgets.editStdValTuple_delWrapper

