/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// the following generic class is for attribute value retrieval

dojo.declare('application.widgets.retrieveAttributes.chooseAttribute',[dijit._Widget,dijit._Templated],{
	rqWidget : null // dijit.widget of class application.widgets.RetrievalQueryWidget
	,
	generateTemplateString : function () {
		this.templateString = ""
			+"<div class='RS_attributeConfig_section'>"
				+((this.title)?"<h3>${title}</h3>":"")
			+"</div>"
			;
	} // end of method generateTemplateString
	,
	postMixInProperties : function() {
		// If you provide a postMixInProperties method for your widget, 
		// it will be invoked before rendering occurs, and before 
		// any dom nodes are created. If you need to add or change the 
		// instance's properties before the widget is rendered 
		// - this is the place to do it.
		this.inherited(arguments);
		
		this.title = T('attrRetrieval_chooseAttribute.js/chooseAttribute_HTM','Double-click on an attribute in the list on the left side to edit the criterium.');
		
		// generate the template string
		this.generateTemplateString();
		
	} // end of method postMixInProperties
});

