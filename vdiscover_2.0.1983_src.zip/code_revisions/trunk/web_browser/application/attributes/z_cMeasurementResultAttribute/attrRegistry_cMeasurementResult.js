﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

application.attributeKinds.register({kind: "cMeasurementResultAttribute", 
	defaultConfiguration : { 
		cardinality: 		1, 

		svFormatActivated:	false,
		svHtmlBefore: 		'',
		svHtmlBetween: 		'',
		svHtmlAfter: 		'',

		format:'###,###.##',
		unitsAsString:'',
		minValue:'',
		maxValue:'',

		inputMeasuredValues :	false,
		fixedNumberOfMeasurements : 0, // > 0 means that there is a fixed number of measurements
		inputStdDev			: false
	}
	,
	fixedCardinality : 		true
	,
	widgetClass: 			'application.widgets.cMeasurementResultAttribute'
	,
	configurationWidgetClass : 'application.widgets.configureAttributes.cMeasurementResultAttribute'
	,
/*	,
	getParsedQuery: function(item,rqWidget) {
		switch ( rqWidget.attributeStore.getValue(item,'searchMode') ) {
			case 'fromTo': {
				if ( (rqWidget.attributeStore.getValue(item,'value1') || rqWidget.attributeStore.getValue(item,'value1') === 0)
						&&
					(rqWidget.attributeStore.getValue(item,'value2') || rqWidget.attributeStore.getValue(item,'value2') === 0) ){
					return rqWidget.attributeStore.getValue(item,'value1')+" \u2264 " // less or equal
							+rqWidget.attributeStore.getValue(item,'name')+" \u2264 " // less or equal
							+rqWidget.attributeStore.getValue(item,'value2');
				} 
				break;
			}
			case 'exactly': {
				if (rqWidget.attributeStore.getValue(item,'value1') || rqWidget.attributeStore.getValue(item,'value1') === 0 ){
					return rqWidget.attributeStore.getValue(item,'name')+' = '+rqWidget.attributeStore.getValue(item,'value1');
				} 
				break;
			}
			case 'plusMinusMultipleOfStandardDeviation': {
				if ( (rqWidget.attributeStore.getValue(item,'value1') || rqWidget.attributeStore.getValue(item,'value1') === 0)
						&&
					(rqWidget.attributeStore.getValue(item,'value2') || rqWidget.attributeStore.getValue(item,'value2') === 0) ){
					return rqWidget.attributeStore.getValue(item,'name')+" = "
							+rqWidget.attributeStore.getValue(item,'value1')+" \261 " // plus-minus
							+rqWidget.attributeStore.getValue(item,'value2') + "%";
				} 
				break;
			}
			default : { //plusMinusPercentageConfidence
				if ( (rqWidget.attributeStore.getValue(item,'value1') || rqWidget.attributeStore.getValue(item,'value1') === 0)
						&&
					(rqWidget.attributeStore.getValue(item,'value2') || rqWidget.attributeStore.getValue(item,'value2') === 0) ){
					return rqWidget.attributeStore.getValue(item,'name')+" = "
							+rqWidget.attributeStore.getValue(item,'value1')+" \261 " // plus-minus
							+rqWidget.attributeStore.getValue(item,'value2');
				} 
				break;				
			}				
		}
		
		return '';
	} // end of method getParsedQuery
*/
	'useValueTupleAsExpressionInput'	: false
	,
	'expressionsPermitted'				: false
	,

});
