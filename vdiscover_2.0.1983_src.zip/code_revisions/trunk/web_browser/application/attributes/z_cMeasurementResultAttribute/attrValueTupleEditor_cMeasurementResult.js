﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare("application.widgets.valueTupleEditor_cMeasurementResult",[application.widgets.valueTupleEditor_generic],{
	
	'buildTemplateContainer' : function() {

		// localise the value tuple's data
		this.mean			= this.valueTuple.mean;
		this.numValues		= this.valueTuple.numberOfMeasurements;
		if(this.config.fixedNumberOfMeasurements &&!this.numValues)
			this.numValues	= this.config.fixedNumberOfMeasurements;
		this.CV				= this.valueTuple.coefficientOfVariation;
		this.stdDev			= this.CV/1e2*this.mean;
		this.measuredValues = this.valueTuple.measuredValues;
		this.unit			= this.valueTuple.unit;
		this.number_title	= '';
					
		// unit
		var units		=this.config.unitsAsString.split('\n'),
			unitSelector= '';
		if(!this.unit) this.unit = units[0];
		if(units.length>1) {
			unitSelector=""
				+"<select "
					+"dojoType='dijit.form.ComboBox' "
					+"dojoAttachEvent='onChange:unit_changed' "
					+"dojoAttachPoint='unitSelector_widget' "
					+"class='fullWidth' "
					+"value='"+this.unit+"' "
				+">"
					+"<option>"+units.join("</option><option>")+"</option>"
				+"</select>"
				;
		} else {
			var unitSelector=units[0];
			this.unit = units[0];
		} // end if

		this.templateContainer = ""
			+"<div dojoAttachPoint='vTEditor_outer'>"
				+"<div dojoAttachPoint='inputMeasuredValues_DOMNode'>"
					+"<div class='RS_A_cMRS_vtEditor_section'>"
						+"<div class='RS_A_cMRS_vtEditor_label'>" + T('attrValTplEd_cMeasRes.js/MeasVal_TXT', 'Measured values:') + "</div>"
						+"<div class='RS_A_cMRS_vtEditor_inputBoxOuter'>"
							+"<ol dojoAttachPoint='measurements_outerDOMNode'>"
							+"</ol>"
						+"</div>"
						+(this.config.inputMeasuredValues?
							"<div dojoAttachPoint='measurements_unit_DOMNode' class='RS_A_cMRS_vtEditor_unit'>"
								+unitSelector
							+"</div>"
						:'')
					+"</div>"
				+"</div>"
				+"<div>"
					+"<div class='RS_A_cMRS_vtEditor_section'>"
						+"<div class='RS_A_cMRS_vtEditor_label'>" + T('FUT_Mean:','Mean:') + "</div>"
						+"<div class='RS_A_cMRS_vtEditor_inputBoxOuter'>"
							+"<div dojoType='dijit.form.NumberTextBox' class='fullWidth' " //intermediateChanges='true' "
								+"selectOnClick='true' "
								+"dojoAttachPoint='mean_widget' dojoAttachEvent='onChange:mean_changed' value='${mean}'>"
							+"</div>"
						+"</div>"
						+"<div dojoAttachPoint='mean_unit_DOMNode' class='RS_A_cMRS_vtEditor_unit'>"
							+(!this.config.inputMeasuredValues?
								"<div dojoAttachPoint='measurements_unit_DOMNode' class='RS_A_cMRS_vtEditor_unit'>"
									+unitSelector
								+"</div>"
							:this.unit)
						+"</div>"
					+"</div>"
					+"<div class='RS_A_cMRS_vtEditor_section'>"
						+"<div class='RS_A_cMRS_vtEditor_label'>" + T('attrValTplEd_cMeasRes.js/SmplStdDev_TXT','Sample standard Deviation:') + "</div>"
						+"<div class='RS_A_cMRS_vtEditor_inputBoxOuter'>"
							+"<div dojoType='dijit.form.NumberTextBox' class='fullWidth' " //intermediateChanges='true' "
								+"selectOnClick='true' "
								+"dojoAttachPoint='stdDev_widget' dojoAttachEvent='onChange:stdDev_changed' value='${stdDev}'>"
							+"</div>"
						+"</div>"
						+"<div dojoAttachPoint='stdDev_unit_DOMNode' class='RS_A_cMRS_vtEditor_unit'>Unit</div>"
					+"</div>"
					+"<div class='RS_A_cMRS_vtEditor_section'>"
						+"<div class='RS_A_cMRS_vtEditor_label'>" + T('attrValTplEd_cMeasRes.js/CoeffOfVar_TXT','Coefficient of variation:') + "</div>"
						+"<div class='RS_A_cMRS_vtEditor_inputBoxOuter'>"
							+"<div dojoType='dijit.form.NumberTextBox' class='fullWidth' " //intermediateChanges='true' "
								+"selectOnClick='true' "
								+"dojoAttachPoint='CV_widget' dojoAttachEvent='onChange:CV_changed' value='${CV}'>"
							+"</div>"
						+"</div>"
						+"<div class='RS_A_cMRS_vtEditor_unit'>%</div>"
					+"</div>"
					+"<div class='RS_A_cMRS_vtEditor_section'>"
						+"<div class='RS_A_cMRS_vtEditor_label'>" + T('FUT_Measurements:','Measurements:') + "</div>"
						+"<div class='RS_A_cMRS_vtEditor_inputBoxOuter'>"
							+"<div dojoType='dijit.form.NumberTextBox' class='fullWidth' "//intermediateChanges='true' "
								+"selectOnClick='true' "
								+"dojoAttachPoint='nM_widget'  dojoAttachEvent='onChange:nM_changed' required='true' value='${numValues}'>"
							+"</div>"
						+"</div>"
					+"</div>"
				+"</div>"
			+"</div>"
			;
			
	} // end of method postMixInProperties
	,
	'postCreate' : function () {
		this.inherited(arguments);
		
		this.mV_constraints = {	pattern: this.config.format },
		this.number_title = '';
		
		if (this.config.minValue!=null) {
			this.mV_constraints.min=this.config.minValue;
			this.number_title += '['+dojo.number.format(this.config.minValue, this.mV_constraints);
		} // end if
		if (this.config.maxValue!=null) {
			this.mV_constraints.max=this.config.maxValue;
			this.number_title += ((this.number_title.length)?' 	… ':'')+dojo.number.format(this.config.maxValue, this.mV_constraints)+']';
		} else {
			this.number_title += ((this.number_title.length)?' 	… ':'');
		}// end if
		
		// set the constraints
		this.mean_widget.attr(	'constraints',	this.mV_constraints);
		this.stdDev_widget.attr('constraints',	{'pattern':'###.##'});
		this.CV_widget.attr(	'constraints',	{'pattern':'###,##0.##','min':0});
		this.nM_widget.attr(	'constraints',	{'pattern':'###,##0','min':1,'places':0});
		
		// set the unit
		//dojo.attr(this.measurements_unit_DOMNode,	'innerHTML', this.config.unit);
		dojo.attr(this.mean_unit_DOMNode,			'innerHTML', this.unit);
		this.mean_widget.attr(	'title',			this.number_title);
		dojo.attr(this.stdDev_unit_DOMNode,			'innerHTML', this.unit);
		
		// configure the interface according to the input type
		if(this.config.inputMeasuredValues) {

			// input measured values
			
			// set all measurement result widgets to readOnly
			this.mean_widget.attr(	'readOnly', true);
			this.stdDev_widget.attr('readOnly', true);
			this.CV_widget.attr(	'readOnly', true);
			this.nM_widget.attr(	'readOnly', true);
		
			// prepare the measured values and generate input boxes for them
			this.mV_inputWidgets = [];
			var measuredValues=this.measuredValues.split('\n');
			dojo.forEach(measuredValues, this.create_mV_InputBox, this);
			
			// create additional input boxes until the max number of measurements is reached
			if(this.config.fixedNumberOfMeasurements==0) {
				
				// flexible number of measurements
				
				// just create one additional input box
				this.create_mV_InputBox('');
			
			} else {
				
				// fixed number of measurements
								
				// generate additional input boxes as necessary
				while (this.mV_inputWidgets.length<this.config.fixedNumberOfMeasurements) this.create_mV_InputBox('');
				
			} // end if number of measurements flexible or fixed
			
		} else {
		
			// input the measurement results, directly
			
			dojo.style(this.inputMeasuredValues_DOMNode,'display','none');
		
			// input standard deviation or coefficient of variability?
			if (this.config.inputStdDev) 	this.CV_widget		.attr('readOnly', true)
				else 						this.stdDev_widget	.attr('readOnly', true);
		
		} // end if
				
		if(this.config.fixedNumberOfMeasurements)  this.nM_widget.attr('readOnly',true);
		
		// set the unit, if necessary
		if(this.unitSelector_widget) {
			//		no unit yet? -> set the first unit as default value
			this.unitSelector_widget.attr('value', (this.valueTuple.unit?this.valueTuple.unit:this.config.unitsAsString.split('\n')[0]));
		} // end if there is a unit selector
		
	} // end of method postCreate
	,
	'create_mV_InputBox' : function (v) {
			
			// create a li node
			var li = dojo.create('li',{'class':'RS_A_cMRS_vtEditor_inputBox_li'},this.measurements_outerDOMNode);
			
			// create and place the input box 
			var mV_tB = new dijit.form.NumberTextBox({
				'title':				this.number_title,
				'constraints':			this.mV_constraints,
				'class':				'fullWidth',
				// 'intermediateChanges' : true, // this must be deactivated!
				'value' : 				v,
				'required' : 			true,
				'selectOnClick'	:		true
			});
			mV_tB.placeAt(li);
			this.connect(mV_tB,'onChange','measuredValuesChanged');
			
			// store the input box
			this.mV_inputWidgets.push(mV_tB);
			this._supportingWidgets.push(mV_tB);
			
	} // end of method create_mV_InputBox
	,
	'measuredValuesChanged' : function () {
		// This method is called upon changes of a measured value.
		// It compiles all measured values and stores them.
	
		var sum=0, numValues=0, mVals=[];
	
		// iterate over all input boxes and collect the values
		dojo.forEach(this.mV_inputWidgets,function(iW,index){
			if(iW.isValid()) {
				var v = iW.attr('value');
				sum +=v;
				numValues++;
				mVals.push(v);
			} // end if
		},this);
		
		// calculate and set mean
		var mean = null;
		if(numValues) mean=sum/numValues;
		this.mean_widget.attr('value',mean);
		
		// calculate and set standard deviation
		var stdDev=null;
		if(numValues>1) {
			var d=0;
			dojo.forEach(mVals,function(v){d+=(v-mean)*(v-mean);},this);
			stdDev=Math.sqrt(d/(numValues-1)); // sample standard deviation -- see http://en.wikipedia.org/wiki/Standard_deviation
		} // end if
		this.stdDev_widget.attr('value',stdDev);
		
		// calculate and set coefficient of variation 
		var CV=null;
		if (stdDev) {
			CV=stdDev/mean;
		} // end if calculate CV
		this.CV_widget.attr('value',CV*100);
		
		// set the number of measurements
		this.nM_widget.attr('value',numValues);
		
		// in case there is any number of measurements permitted and there is a valid value in the last box: create a new input box
		if(this.config.fixedNumberOfMeasurements==0) {
			var lastInputBox=this.mV_inputWidgets[this.mV_inputWidgets.length-1];
			if(lastInputBox.isValid() && lastInputBox.attr('value') !='') this.create_mV_InputBox('');
		} // end if
		
		// store all calculated values
		this.mean		= mean;
		this.stdDev		= stdDev;
		this.CV			= CV;
		this.numValues	= numValues;
		this.measuredValues = mVals.join('\n').replace(/\n{2,}/g, '\n').replace(/\n+$/g,'');
		
		// tell the attribute that things have changed
		this.notifyAttributeOfChangedValue();
	
	} // end of  method measuredValuesChanged
	,
	'unit_changed' : function () {
	
		// unit
		var units=this.config.unitsAsString.split('\n');
	
		this.unit = this.unitSelector_widget.attr('value');
		
		if (dojo.indexOf(units, this.unit)==-1) {
			this.unit=units[0];
			this.unitSelector_widget.attr('value', this.unit);
		} // end if
		
		if(this.config.inputMeasuredValues) dojo.attr( this.mean_unit_DOMNode, 'innerHTML', this.unit );
		dojo.attr( this.stdDev_unit_DOMNode, 'innerHTML', this.unit );
	
		// tell the attribute that things have changed
		this.notifyAttributeOfChangedValue();
		
	} // end of method unit_changed
	,
	'mean_changed' : function(e) {
		this.mean = this.mean_widget.attr('value');
		
		// update CV OR stdDev, if necessary
		if (this.config.inputStdDev) {
			// perhaps the CV needs to be updated
			if (this.stdDev) {
				this.CV=this.stdDev/this.mean*100;
				this.CV_widget.attr('value',this.CV);
			} // end if update CV
		} else {
			// perhaps the standard deviation needs to be updated
			if (this.CV) {
				this.stdDev=this.CV/1e2*this.mean;
				this.stdDev_widget.attr('value',this.stdDev);
			} // end if update CV
		} // end if
						
		this.notifyAttributeOfChangedValue();
	} // end of method mean_changed
	,
	'stdDev_changed' : function(e) {
		if(!this.config.inputStdDev) return;
		
		this.stdDev=this.stdDev_widget.attr('value');
		// update the coefficient of variation
		if(this.stdDev && this.mean) {
			this.CV=this.stdDev/this.mean*1e2;
		} else {
			this.CV='';
		} // end if
		this.CV_widget.attr('value',this.CV);
		this.notifyAttributeOfChangedValue();
	} // end of method stdDev_changed
	,
	'CV_changed' : function(e) {
		if(this.config.inputStdDev) return;
		
		this.CV=this.CV_widget.attr('value');
		// update the standard deviation
		if(this.mean) {
			this.stdDev=this.mean*this.CV/1e2;
		} else {
			this.stdDev='';
		} // end if
		this.stdDev_widget.attr('value',this.stdDev);
		this.notifyAttributeOfChangedValue();
	} // end of method mean_changed
	,
	'nM_changed' : function(e) {
		if(this.config.fixedNumberOfMeasurements!=0) return;
		
		this.numValues= this.nM_widget.attr('value');
		this.notifyAttributeOfChangedValue();
	} // end of method mean_changed
	,
	'getValueTuple' : function () {
		// this method returns the current value tuple
				
		dojo.attr(this.mean_unit_DOMNode,			'innerHTML', this.unit);
		dojo.attr(this.stdDev_unit_DOMNode,			'innerHTML', this.unit);
		
		var vT = {
			'mean': 					(!isNaN(this.mean)?this.mean:''),
			'numberOfMeasurements': 	(!isNaN(this.numValues)?this.numValues:0),
			'coefficientOfVariation': 	(!isNaN(this.CV)?this.CV:0),
			'measuredValues': 			((this.config.inputMeasuredValues)?this.measuredValues:''),
			'meanPlus1CV':				'',
			'meanPlus2CV':				'',
			'meanPlus3CV':				'',
			'meanMinus1CV':				'',
			'meanMinus2CV':				'',
			'meanMinus3CV':				'',
			'AV_UUID' : 				this.valueTuple.AV_UUID,
			'UUID':						this.valueTuple.UUID,
			'unit':						this.unit,
			'positionOfValue' 	: 		this.valueTuple.positionOfValue
		};
		
		if(!isNaN(this.mean) && (typeof this.CV == 'number') && (this.CV!=0)) {
			var coefficientOfVariation = this.CV/100;
			vT['meanPlus1CV']=dojo.number.parse(dojo.number.format(	this.mean*(1+1*coefficientOfVariation),{'pattern':this.config.format}));
			vT['meanPlus2CV']=dojo.number.parse(dojo.number.format(	this.mean*(1+2*coefficientOfVariation),{'pattern':this.config.format}));
			vT['meanPlus3CV']=dojo.number.parse(dojo.number.format(	this.mean*(1+3*coefficientOfVariation),{'pattern':this.config.format}));
			vT['meanMinus1CV']=dojo.number.parse(dojo.number.format(this.mean*(1-1*coefficientOfVariation),{'pattern':this.config.format}));
			vT['meanMinus2CV']=dojo.number.parse(dojo.number.format(this.mean*(1-2*coefficientOfVariation),{'pattern':this.config.format}));
			vT['meanMinus3CV']=dojo.number.parse(dojo.number.format(this.mean*(1-3*coefficientOfVariation),{'pattern':this.config.format}));
		} // end if
	
		return vT;
	
	} // end of method getValueTuple
	,
	'notifyAttributeOfChangedValue' : function () {
		this.attrWidget.valueTupleHasChanged(this.valueTupleUUID, this.getValueTuple());
	} // end of method notifyAttributeOfChangedValue
	,
	'isValid' : function () {
		var isValid = 		true
						&&	this.mean_widget.isValid();
						
		if(this.config.mustBeSet) 	
			isValid = 		isValid 
						&& 	!this.attrWidget.tuple_isEmpty( this.getValueTuple() );
		
		if(		this.config.inputMeasuredValues
			&&	(this.config.fixedNumberOfMeasurements!=0)	) 
				isValid = isValid && (this.measuredValues.split('\n').length==this.config.fixedNumberOfMeasurements);
				
		return isValid;
	} // end of method isValid
});
