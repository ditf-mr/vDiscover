﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare("application.widgets.cMeasurementResultAttribute",[application.widgets.standardAttribute],{
	'_emptyValueTuple': { 
		'mean' : 					null,
		'numberOfMeasurements' : 	0,
		'coefficientOfVariation' : 	null,
		'measuredValues' : 			'',
		'meanPlus1CV' : 			null,
		'meanPlus2CV' : 			null,
		'meanPlus3CV' : 			null,
		'meanMinus1CV' : 			null,
		'meanMinus2CV' : 			null,
		'meanMinus3CV' : 			null,
		'unit' :					''
	}
	,
	'valueTupleEditor_name': 'application.widgets.valueTupleEditor_cMeasurementResult'
	,
	'tuple_isEmpty' : function (tuple) {
		return (typeof tuple.mean != 'number');
	} // end of method tuple_isEmpty
	,
	'htmlFormatValueTuple_readMode' : function (valueTuple) {
	
		// prepare the format options
		var formatOptions = {};
		if (this.config.formatDisplay)	formatOptions.pattern = this.config.formatDisplay; 
		
		// prepare the unit
		var units 		= this.config.unitsAsString.split('\n'),
			first_unit 	= units[0],
			unit 		= valueTuple.unit?valueTuple.unit:first_unit;
		
		return ''
			+'<code>'+dojo.number.format(valueTuple.mean, formatOptions)+'</code>'
			+(this.config.inputStdDev && valueTuple.coefficientOfVariation && valueTuple.mean ?
				'&nbsp;&plusmn;&nbsp;<code>'+dojo.number.format(valueTuple.coefficientOfVariation/1e2*valueTuple.mean, formatOptions)+'</code>':'')
			+(this.config.unitsAsString?'&nbsp;'+unit:'')
			+(!this.config.inputStdDev && valueTuple.coefficientOfVariation?'&nbsp;&plusmn;&nbsp;<code>'+dojo.number.format(valueTuple.coefficientOfVariation, {'pattern':'###,##0.0#'})+'</code>&nbsp;%':'')
			;
	} // end of method htmlFormatValueTuple_ReadMode

}); // end of declaration
