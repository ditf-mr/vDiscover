﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

/*
dojo.declare('application.widgets.retrieveAttributes.cMeasurementResultAttribute',[application.widgets.retrieveAttributes.genericAttribute],{
	values_changed: function(e){
		switch ( this.searchMode_S.attr('value') ) {
			case 'fromTo':
				if (this.value2_nTB.attr('value'))
					this.value1_nTB.attr('constraints',{max:this.value2_nTB.attr('value')}) ;
				if (this.value1_nTB.attr('value'))
					this.value2_nTB.attr('constraints',{min:this.value1_nTB.attr('value')})  ;

				this.value2_nTB.attr('disabled',false);
					
				if (this.value1_nTB.isValid() && this.value2_nTB.isValid()){
					this.propertyHasChanged('searchMode',this.searchMode_S.attr('value'));
					this.propertyHasChanged('value1',this.value1_nTB.attr('value'));
					this.propertyHasChanged('value2',this.value2_nTB.attr('value'));
				} else {
					this.propertyHasChanged('searchMode','');					
				}
				break;
			case 'exactly':
				// reset with default values of dojo
				this.value1_nTB.attr('constraints',{max:9000000000000000}) ;
				this.value2_nTB.attr('constraints',{min:-9000000000000000}) ;

				this.value2_nTB.attr('disabled',true);
				if (this.value1_nTB.isValid()) {
					this.propertyHasChanged('searchMode',this.searchMode_S.attr('value'));
					this.propertyHasChanged('value1',this.value1_nTB.attr('value'));
				} else {
					this.propertyHasChanged('searchMode','');					
				}				
				break;
			default :
				// reset with default values of dojo
				this.value1_nTB.attr('constraints',{max:9000000000000000}) ;
				this.value2_nTB.attr('constraints',{min:-9000000000000000}) ;

				this.value2_nTB.attr('disabled',false);
				
				if (this.value1_nTB.attr('value')&&this.value2_nTB.attr('value')) {
					this.propertyHasChanged('searchMode',this.searchMode_S.attr('value'));
					this.propertyHasChanged('value1',this.value1_nTB.attr('value'));
					this.propertyHasChanged('value2',this.value2_nTB.attr('value'));
				} else {
					this.propertyHasChanged('searchMode','');					
				}				
		}
	}
	,
	postMixInProperties : function() {
		// If you provide a postMixInProperties method for your widget, 
		// it will be invoked before rendering occurs, and before 
		// any dom nodes are created. If you need to add or change the 
		// instance's properties before the widget is rendered 
		// - this is the place to do it.
		this.inherited(arguments);

		//localise the necessary variables
		this.locateProperties(['searchMode','value1','value2','name']);

		// initialisation of variables 
		disabled='';
		constraintsValue1='';
		constraintsValue2='';

		if(!this.searchMode) {
			this.searchMode ='exactly';
		}		
		if(!this.value1) {
			this.value1 ='';
		}		
		if(!this.value2) {
			this.value2 ='';
		}		
		
		switch ( this.searchMode ) {
			case 'fromTo':
				disabled='';
				if(this.value2)
					constraintsValue1="constraints='{max:"+this.value2+"}'";
				if(this.value1)
					constraintsValue2="constraints='{min:"+this.value1+"}'";
				break;
			case 'exactly':
				disabled='disabled';
				break;
			default :
				break;
		}		
		
		this.title = "Search for * in «"+this.name+"»";
		
		// expand the template string
		this.addTemplateSection(""
			+"<tr>"
				+"<td class='textRight' width='30%'>Choose search mode:</td>"
				+"<td width='70%'>"
					+"<select style='width:100%'"
						+"value='${searchMode}'" 
						+"dojoAttachEvent='onChange:values_changed' "
						+"dojoAttachPoint='searchMode_S' "
						+"dojoType='dijit.form.Select'"
					+">"
						+"<option value='exactly'>mean value = «Value 1»</option>"
						+"<option value='fromTo'>«Value 1» &le; mean value &le; «Value 2»</option>"
						+"<option value='plusMinusMultipleOfStandardDeviation'>mean value = «Value 1» &plusmn; «Value 2» * standard deviation</option>"
						+"<option value='plusMinusPercentageConfidence'>mean value = «Value 1» with «Value 2» % confidence</option>"
					+"</select>"
				+"</td>"
			+"</tr>"	
			+"<tr>"
				+"<td class='textRight' width='30%'>Value 1 (mean value):</td>"
				+"<td width='70%'>"
					+"<input type='text' style='width:100%'"
						+"value='${value1}'" 
						+"dojoAttachEvent='onChange:values_changed' "
						+"dojoAttachPoint='value1_nTB' "
						+"dojoType='dijit.form.NumberTextBox'"
						+"required='true'"
						+constraintsValue1
					+"/>"
				+"</td>"
			+"</tr>"	
			+"<tr>"
				+"<td class='textRight' width='30%'>Value 2:</td>"
				+"<td width='70%'>"
					+"<input type='text' style='width:100%'"
						+"value='${value2}'" 
						+"dojoAttachEvent='onChange:values_changed' "
						+"dojoAttachPoint='value2_nTB' "
						+"dojoType='dijit.form.NumberTextBox'"
						+"required='true'"
						+disabled
						+constraintsValue2
					+"/>"
				+"</td>"
			+"</tr>"	
			+"<tr>"
				+"<td class='textRight' width='30%'>"
					+"<p>You can select the search mode for ${name}:</p>"
				+"</td>"				
				+"<td width='70%'>"
						+"<ul>"
							+"<li>The fist option finds all objects where the mean value of ${name} is exactly <code>value 1</code></li>"
							+"<li>The second option finds all objects where the mean value of ${name} is between <code>value 1</code> and <code>value 2</code></li>"
							+"<li>The third option finds all objects where the mean value of ${name} is between <code>value 1 - value 2 * standard deviation</code> and <code>value 1 + value 2 * standard deviation</code></li>"
							+"e.g. <br/><code>value 1</code> = 10, the standard deviation is 2 and <code>value 2</code> = 1.5 the search range goes from 7 to 13</li>"
							+"<li>The fourth option finds all objects where the mean value of ${name} is value 1 with confidence of <code>value 2 %</code></li>"
						+"</ul>"
				+"</td>"
			+"</tr>"	
		);
				
		// generate the template string
		this.generateTemplateString();
		
	} // end of method postMixInProperties
});
*/

