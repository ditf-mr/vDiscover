﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare(
	'application.widgets.configureSpecialAttribute.cMeasurementResultAttribute',
	[application.widgets.configureSpecialAttribute.numericalAttribute],{
	
	'postMixInProperties' : function() {
		this.inherited(arguments);

		// expand the template string
		this.addTemplateSection(""
			+"<tr>"
				+"<td class='textRight'>" + T('attrConf_cMeasRes.js/InputTp_LBL', 'Input type:') + "</td>"
				+"<td>"
					+"<p><label>"
						+"<input type='radio' dojoType='dijit.form.RadioButton' "
							+"name='application.widgets.configureAttributes.cMeasurementResultAttribute.inputType' "
							+"dojoAttachPoint='inputType_measuredValues' "
							+"dojoAttachEvent='onChange:inputType_measuredValues_changed,onfocus:showEditHints' "
							+"value='true' />"
							+ T('attrConf_cMeasRes.js/ListOfValsTip_TXT', 'a list of measured values')
					+"</label></p>"
					+"<div>"
						+"<p><label>"
							+"<input type='radio' dojoType='dijit.form.RadioButton' "
								+"name='application.widgets.configureAttributes.cMeasurementResultAttribute.inputType' "
								+"dojoAttachPoint='inputType_meanStdDev' "
								+"dojoAttachEvent='onfocus:showEditHints' "
								+"value='false' />"
								+ T('attrConf_cMeasRes.js/MeasResTip_TXT', 'measurement results (mean, etc.)')
						+"</label></p>"
						+"<div dojoAttachPoint='variationInputFields'>"
							+"<table><tbody>"
								+"<tr>"
									+"<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>"
									+"<td rowspan='2' class='textRight'>" + T('attrConf_cMeasRes.js/InputVariation_LBL', 'Input variation as:') + "</td>"
									+"<td>"
										+"<label>"
											+"<input type='radio' dojoType='dijit.form.RadioButton' "
												+"name='application.widgets.configureAttributes.cMeasurementResultAttribute.inputVariation' "
												+"dojoAttachPoint='inputType_inputStdDev' "
												+"dojoAttachEvent='onChange:inputType_inputStdDev_changed,onfocus:showEditHints' "
												+"value='true' />"
												+ T('attrConf_cMeasRes.js/SmplStdDev_TXT', 'sample standard deviation')
										+"</label>"
									+"</td>"
								+"</tr>"
								+"<tr>"
									+"<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>"
									+"<td>"
										+"<label>"
											+"<input type='radio' dojoType='dijit.form.RadioButton' "
												+"name='application.widgets.configureAttributes.cMeasurementResultAttribute.inputVariation' "
												+"dojoAttachPoint='inputType_inputVarCoeff' "
												+"dojoAttachEvent='onfocus:showEditHints' "
												+"value='true' />"
												+ T('attrConf_cMeasRes.js/CoeffOfVar_TXT', 'coefficient of variation')
										+"</label>"
									+"</td>"
								+"</tr>"
							+"</tbody></table>"
						+"</div>"
					+"</div>"
				+"</td>"
			+"</tr>"
			+"<tr>"
				+"<td class='textRight'>" + T('attrConf_cMeasRes.js/NumOfMeas_LBL', 'Number of measurements:') + "</td> "
				+"<td> "
					+"<label>"
						+"<input type='radio' dojoType='dijit.form.RadioButton' "
							+"name='application.widgets.configureAttributes.cMeasurementResultAttribute.nMR' "
							+"dojoAttachPoint='numMeasurements_flexible' "
							+"dojoAttachEvent='onChange:numMeasurements_flexible_changed,onfocus:showEditHints' "
							+"value='true' />"
							+ T('attrConf_cMeasRes.js/Flex_TXT', 'flexible')
					+"</label>"
					+"&nbsp;&nbsp;"
					+"<label>"
						+"<input type='radio' dojoType='dijit.form.RadioButton' "
							+"name='application.widgets.configureAttributes.cMeasurementResultAttribute.nMR' "
							+"onfocus='application.admin.manageAttributes.showEditHints();' "
							+"dojoAttachPoint='numMeasurements_fixed' "
							+"dojoAttachEvent='onfocus:showEditHints' "
							+"value='false' />"
							+ T('attrConf_cMeasRes.js/FixedTo_TXT', 'fixed to')
					+"</label>"
					+"<input dojoType='dijit.form.NumberSpinner' value='${fixedNumberOfMeasurements}' smallDelta='1' "
						+"constraints='{min:1,max:255,places:0}' style='width:4em;' selectOnClick='true' intermediateChanges='true' "
						+"dojoAttachPoint='numMeasurements_nS' "
						+"dojoAttachEvent='onChange:numMeasurements_changed,onfocus:showEditHints' />"
				+"</td>"
			+"</tr>"
		);
		
		//localise the necessary variables
		this.locateProperties(['inputMeasuredValues','fixedNumberOfMeasurements','inputStdDev']);
		
		// generate the template string
		this.generateTemplateString();
		
	} // end of method postMixInProperties
	,
	'postCreate' : function () {
		this.inherited(arguments);
	
		if (this.inputMeasuredValues) {
			this.inputType_measuredValues.attr('checked',true);
			dojo.style(this.variationInputFields,'display','none');
		} else {
			this.inputType_meanStdDev.attr('checked',true);
			dojo.style(this.variationInputFields,'display','block');
		} // end if
			
		if (this.fixedNumberOfMeasurements==0)	{
			this.numMeasurements_flexible.attr('checked',true);
			this.numMeasurements_nS.attr('value',10);
			this.numMeasurements_nS.attr('disabled',true);
		} else {
			this.numMeasurements_fixed.attr('checked',true);
			this.numMeasurements_nS.attr('disabled',false);
		} // end if
	
		if (this.inputStdDev)	this.inputType_inputStdDev.attr('checked',true)
			else				this.inputType_inputVarCoeff.attr('checked',true);
		
		// take care of inheritance aspects
		if (this.isInherited) {
			this.inputType_measuredValues	.attr('disabled', true);
			this.inputType_meanStdDev		.attr('disabled', true);
			this.inputType_inputStdDev		.attr('disabled', true);
			this.inputType_inputVarCoeff	.attr('disabled', true);
			this.numMeasurements_flexible	.attr('disabled', true);
			this.numMeasurements_fixed		.attr('disabled', true);
			this.numMeasurements_nS			.attr('disabled', true);
		} // end if 
		
	} // end of method postCreate
	,
	'inputType_measuredValues_changed' : function(e) {
		this.inputMeasuredValues = this.inputType_measuredValues.attr('checked');
		this.propertyHasChanged('inputMeasuredValues');		
		dojo.style(this.variationInputFields,'display',((!this.inputMeasuredValues)?'block':'none'));
	} // end of method inputType_measuredValues_changed
	,
	'numMeasurements_flexible_changed' : function(e) {
		this.fixedNumberOfMeasurements = (this.numMeasurements_flexible.attr('checked')?0:this.numMeasurements_nS.attr('value'));
		if (this.fixedNumberOfMeasurements==0)	{
			this.numMeasurements_nS.attr('disabled',true);
		} else {
			this.numMeasurements_nS.attr('disabled',false);
			if (this.numMeasurements_nS.attr('value')==0) this.numMeasurements_nS.attr('value',10);
		} // end if
		this.propertyHasChanged('fixedNumberOfMeasurements');		
	} // end of method numMeasurements_flexible_changed
	,
	'numMeasurements_changed' : function(e) {
		if(this.numMeasurements_flexible.attr('checked')) return;
		
		var v = this.numMeasurements_nS.attr('value');
		if (isNaN(v)) v=10;
		this.fixedNumberOfMeasurements = v;
		this.propertyHasChanged('fixedNumberOfMeasurements');		
	} // end of method numMeasurements_changed
	,
	'inputType_inputStdDev_changed' : function(e) {
		this.inputStdDev = this.inputType_inputStdDev.attr('checked');
		this.propertyHasChanged('inputStdDev');		
	} // end of method inputType_measuredValues_changed
});
