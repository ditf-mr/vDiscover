﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare("application.widgets.cPasswordAttribute",[application.widgets.standardAttribute],{
	'_emptyValueTuple': { 'value_password' : '' }
	,
	'valueTupleEditor_name': 'application.widgets.valueTupleEditor_password'
	,
	'tuple_isEmpty' : function (tuple) {	
		return false; // because an empty password is as well a valid one
	} // end of method tuple_isEmpty
	,
	'htmlFormatValueTuple_readMode' : function (valueTuple) {
		// valueTuple.value_password contains just ****
		// return some runic chars, see http://www.utf8-chartable.de/unicode-utf8-table.pl -- Range: &#5792; &#5872; (80 chars)
		var s='', maxChars=12, minCharCode=5792, maxCharCode=5872;
		for (var i=0; i<maxChars;i++) s+=	'&#'+(Math.floor(minCharCode + (1+maxCharCode-minCharCode)*Math.random()))+';';
		// the random number generator code is taken from http://www.javascripter.net/faq/randomnu.htm
		
		return s;
	} // end of method htmlFormatValueTuple_ReadMode

}); // end of declaration
