﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare("application.widgets.valueTupleEditor_password",[application.widgets.valueTupleEditor_generic],{
	
	'textBoxPassword' 	: null, // dijit.form.ValidationTextBox
	'textBoxValidation' : null, // dijit.form.ValidationTextBox
	'maxPasswordLength' : 255, // chars
	'isInEditMode' 		: false
	,
	'postMixInProperties' : function () {
		this.inherited(arguments);
		this.isInEditMode = false;
	} // end of method postMixInProperties
	,
	'buildTemplateContainer' : function() {
		this.templateContainer = ''
			+'<div>'
				+'<p dojoAttachPoint="changePasswordMessage_domNode">'
					+this.attrWidget.htmlFormatValueTuple_readMode('*')
					+' (<a dojoAttachEvent="onclick:showDialog" style="cursor:pointer;">' + T('attrValTplEditor_cPassword.js/ClkToChPW_LNK','Click here to change the password.') + '</a>)'
				+'</p>'
				+'<div dojoAttachPoint="changePasswordDialog_domNode">'
					+'<p>'
						+'<div class="RS_VTE_password_labels">' + T('attrValTplEditor_cPassword.js/NewPW_LBL','New password:') + '</div>'
						+'<div dojoAttachPoint="textBoxOuterPassword" class="RS_VTE_password_inputBoxContainer"></div>'
					+'</p>'
					+'<p>'
						+'<div class="RS_VTE_password_labels">' + T('attrValTplEditor_cPassword.js/PWValidation_LBL','Validation:') + '</div>'
						+'<div dojoAttachPoint="textBoxOuterValidation" class="RS_VTE_password_inputBoxContainer"></div>'
					+'</p>'
					+'<div>'
						+'<div class="RS_icon_OkApply RS_VTE_password_validMessage_outer" dojoAttachPoint="pwdsMatch_domNode">'
							+'<p class="RS_VTE_password_validMessage">' + T('attrValTplEditor_cPassword.js/PWsMatch_TXT','The passwords match.') + '</p>'
						+'</div>'
						+'<div class="RS_icon_Cancel RS_VTE_password_invalidMessage_outer" dojoAttachPoint="pwdsDoNotMatch_domNode">'
							+'<p class="RS_VTE_password_invalidMessage">' + T('attrValTplEditor_cPassword.js/PWsDoNotMatch_TXT','The passwords do <strong>not match</strong>.') + '</p>'
						+'</div>'
					+'</div>'
					+'<div>'
						+'<p class="textRight small"  style="clear:both">'
							+ T('attrValTplEditor_cPassword.js/PWLength_HTM', 'Password length: <code>$[0]&nbsp;…&nbsp;$[1]</code> chars.', [this.config.minLength, this.maxPasswordLength])
						+'</p>'
					+'</div>'
				+'</div>'
			+'</div>';
	} // end of method postMixInProperties
	,
	'showDialog' : function () {
		// this method hides the link "click here to change the password" and displays the change password dialog
		dojo.style(this.changePasswordMessage_domNode,'display','none');	
		dojo.style(this.changePasswordDialog_domNode,'display','block');
		this.isInEditMode = true;
	} // end of method showDialog
	,
	'postCreate' : function () {
		this.inherited(arguments);
		
		this.textBoxPassword = new dijit.form.ValidationTextBox({
			maxLength:		this.maxPasswordLength,
			regExp:			'.{'+this.config.minLength+',}',
			required: 		(this.config.mustBeSet==true),
			style:			"width:100%",
			value:			'',
			type:			'password',
			intermediateChanges : true
		}).placeAt(this.textBoxOuterPassword);
		this._supportingWidgets.push(this.textBoxPassword);
		this.connect(this.textBoxPassword,'onChange',this.notifyAttributeOfChangedValue);
		
		this.textBoxValidation = new dijit.form.ValidationTextBox({
			maxLength:		this.maxPasswordLength,
			regExp:			'.{'+this.config.minLength+',}',
			required: 		(this.config.mustBeSet==true),
			style:			"width:100%",
			value:			'',
			type:			'password',
			intermediateChanges : true
		}).placeAt(this.textBoxOuterValidation);
		this._supportingWidgets.push(this.textBoxValidation);
		this.connect(this.textBoxValidation,'onChange',this.notifyAttributeOfChangedValue);
		
		// hide all messages
		dojo.style(this.pwdsMatch_domNode,'display','none');
		dojo.style(this.pwdsDoNotMatch_domNode,'display','none');
		
		// some convenience formatting
		if (this.valueTuple.value_password) {
			dojo.style(this.changePasswordMessage_domNode,'display','block');	
			dojo.style(this.changePasswordDialog_domNode,'display','none');	
		} else {
			// the editor was created by clicking on + (new value tuple)
			dojo.style(this.changePasswordMessage_domNode,'display','none');	
			dojo.style(this.changePasswordDialog_domNode,'display','block');	
			this.isInEditMode = true;
		} // end if
		
	} // end of method postCreate
	,
	'notifyAttributeOfChangedValue' : function () {
		// this method informs the connected attribute about the changed value tuple
		
		// continue only, if the password and its validation are both valid
		if( !(this.textBoxPassword.isValid() && this.textBoxValidation.isValid()) ) {
			// hide all messages
			dojo.style(this.pwdsMatch_domNode,'display','none');
			dojo.style(this.pwdsDoNotMatch_domNode,'display','none');
		
			return; // do nothing
		} // end if
		
		// test if the password and its validation match and display the corresponding message
		if (this.passWordsMatch()) { // match
			dojo.style(this.pwdsMatch_domNode,		'display', 'block'	);
			dojo.style(this.pwdsDoNotMatch_domNode,	'display', 'none'	);
			
			// notify the attribute widget about the changes
			this.attrWidget.valueTupleHasChanged(this.valueTupleUUID, this.getValueTuple() );	
		} else { // no match
			dojo.style(this.pwdsMatch_domNode,'display','none');
			dojo.style(this.pwdsDoNotMatch_domNode,'display','block');
		} // end if
		
	} // end of method notifyAttributeOfChangedValue
	,
	'getValueTuple' : function () {
		var vT= {
			// 'value_password'	: this.textBoxPassword.attr('value'),
			'AV_UUID' 			: this.valueTuple.AV_UUID,
			'UUID'				: this.valueTuple.UUID,
			'positionOfValue'	: this.valueTuple.positionOfValue
			};

		if (this.isInEditMode) vT.new_password = this.textBoxPassword.attr('value');
		return vT;
	} // end of method getValueTuple
	,
	'passWordsMatch' : function () {
		var		password	= this.textBoxPassword.attr('value'), 
				validation	= this.textBoxValidation.attr('value');
		return  (password==validation);
	} // end of method passWordsMatch
	,
	'isValid' : function () {
		if(!this.isInEditMode) return true; // already stored passwords are valid, always
		
		var isValid = true
				&& 	this.textBoxPassword.isValid()
				&& 	this.textBoxValidation.isValid()
				&& 	this.passWordsMatch()
			;
		if(this.config.mustBeSet) 	isValid = isValid && !this.attrWidget.tuple_isEmpty( this.getValueTuple() );
		return isValid;
	} // end of method
	/*,
	'destroy' : function () {
	
		this.textBoxPassword.destroyRecursive();
		this.textBoxValidation.destroyRecursive();
	
		this.inherited(arguments);
	} // end of method destroy
	*/
});
