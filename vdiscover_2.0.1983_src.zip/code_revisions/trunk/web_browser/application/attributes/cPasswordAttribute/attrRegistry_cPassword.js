﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

application.attributeKinds.register({kind: "cPasswordAttribute", 
	defaultConfiguration : {
		minLength: 3
	}
	,
	// defaultValues:{
		// value_password:"", 		
	// }
	// ,	
	widgetClass: 'application.widgets.cPasswordAttribute'
	,
	configurationWidgetClass : 'application.widgets.configureAttributes.cPasswordAttribute'
	,
	fixedCardinality : true
	,
	'useValueTupleAsExpressionInput'	: false
	,
	'expressionsPermitted'				: false
	,

});

