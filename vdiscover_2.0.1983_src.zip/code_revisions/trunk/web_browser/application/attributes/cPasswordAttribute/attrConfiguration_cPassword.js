﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare('application.widgets.configureSpecialAttribute.cPasswordAttribute',
[application.widgets.configureAttribute.genericConfigurationWidget],{

	'minLength_changed' : function(e) {
		var v = this.minLength_nS.attr('value');
		if (isNaN(v)) v=1;
		this.propertyHasChanged('minLength',v);
	} // end of methodregexChanged
	,
	'postMixInProperties': function() {
		this.inherited(arguments);
		
		// expand the template string
		this.addTemplateSection(""
			+"<tr>"
				+"<td class='textRight'>" + T('attrConf_cPassword.js/MinPWLength_TXT','Minimum length of the password:') + "</td> "
				+"<td> "
					+"<input dojoType='dijit.form.NumberSpinner' value='${minLength}' smallDelta='1' "
					+"constraints='{min:1,max:255,places:0}' class='fullWidth' "
					+"dojoAttachEvent='onChange:minLength_changed,onfocus:showEditHints' "
					+"disabled='${isInherited}' "
					+"dojoAttachPoint='minLength_nS' />"
				+"</td>"
			+"</tr>"
		);
		
		//localise the necessary variables
		this.locateProperties(['minLength']);
		
		// generate the template string
		this.generateTemplateString();
		
	} // end of method postMixInProperties
});

