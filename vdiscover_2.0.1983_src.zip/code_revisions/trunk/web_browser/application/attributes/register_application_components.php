<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// register the common attribute components #######################################

// the attribute registry
$r->register_JavaScriptFile('application/attributes/attributeRegistry.js');

// the common templates for attribute widgets
$r->register_JavaScriptFile('application/attributes/attr_generalTemplateWidget.js');
$r->register_JavaScriptFile('application/attributes/attr_standardTemplateWidget.js'); // this widget is inherited from attr_generalTemplateWidget.js and hence needs to be loaded, afterwards

// the value tuple editor templates
$r->register_JavaScriptFile('application/attributes/attrValueTupleEditor_delWrapper.js');
$r->register_JavaScriptFile('application/attributes/attrValueTupleEditor_genericWidget.js'); // this widget is inherited from attrValueTupleEditor_delWrapper.js and hence needs to be loaded, afterwards

// the attribute configuration
global /*$r, */$backend;
if($backend->isAdmin()){
	// the template widget for any configuration widget
	$r->register_JavaScriptFile('application/attributes/attrConfiguration_templateWidget.js');
	
	// common configuration widgets
	$r->register_JavaScriptFile('application/attributes/attrConfiguration_general.js');
	$r->register_JavaScriptFile('application/attributes/attrConfiguration_readOnly.js');
	$r->register_JavaScriptFile('application/attributes/attrConfiguration_cardinality.js');
	// $r->register_JavaScriptFile('application/attributes/attrConfiguration_MODSIMTex.js');
	$r->register_JavaScriptFile('application/attributes/attrConfiguration_analyticalExpressions.js');
} // end if user is admin

$r->register_JavaScriptFile('application/attributes/attrRetrieval_templateWidget.js');
$r->register_JavaScriptFile('application/attributes/attrRetrieval_noSearch.js');
$r->register_JavaScriptFile('application/attributes/attrRetrieval_chooseAttribute.js');

// register all special components in the sub dirs
cApplicationRegistry::registerModuleComponents(PLUGIN_REGISTRY_parseAllSubDirs, __DIR__ );

?>