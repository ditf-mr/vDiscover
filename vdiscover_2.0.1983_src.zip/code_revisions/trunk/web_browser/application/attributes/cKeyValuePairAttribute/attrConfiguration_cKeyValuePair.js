﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare(
	'application.widgets.configureSpecialAttribute.cKeyValuePairAttribute',
	[application.widgets.configureAttribute.genericConfigurationWidget],{

	'postMixInProperties' : function () {
		this.inherited(arguments);
		
		// expand the template string
		this.addTemplateSection(""
			+"<tr vertical-align='top'>"
				+"<td class='textRight'>" + T('attrConfiguration_cKeyValuePair.js/KeyValPair_TXT','Key-value pairs:') + "</td>"
				+"<td>"
					+"<textarea "
					+"dojoType='dijit.form.SimpleTextarea' rows='10' style='width:100%;' "
					+"class='code fullWidth' intermediateChanges='true' "
					+"dojoAttachPoint='keyValuePairsAsString_tA' "
					+"dojoAttachEvent='onChange:keyValuePairsAsString_changed,onFocus:showKeyValuePairEditHints' "
					+">${keyValuePairsAsString}</textarea>"
				+"</td>"
			+"</tr>"
			
			+"<tr>"
				+"<td class='textRight'>" + T('attrConfiguration_cKeyValuePair.js/DisplStyle_TXT','Display style:') + "</td>"
				+"<td>"
					+"<label>"
						+"<input type='radio' dojoType='dijit.form.RadioButton' "
							+"dojoAttachPoint='displayAsCheckbox_no_rB' "
							+"dojoAttachEvent='onChange:displayAsCheckbox_changed,onFocus:showEditHints' "
							+"value='false' />"
						+ T('attrConfiguration_cKeyValuePair.js/DDList_TXT','Drop down list')
					+"</label>"
					+"<br />"
					+"<label>"
						+"<input type='radio' dojoType='dijit.form.RadioButton' "
							+"dojoAttachPoint='displayAsCheckbox_yes_rB' "
							+"dojoAttachEvent='onChange:displayAsCheckbox_changed,onFocus:showEditHints' "
							+"value='false' />"
						+ T('attrConfiguration_cKeyValuePair.js/RadioOrChkBox_TXT','Radio buttons (cardinality 1) or check boxes (cardinality > 1)')
					+"</label>"
					+"<div dojoAttachPoint='showAllOptions_DOMNode'>"
						+"<label>"
							+"<input dojoType='dijit.form.CheckBox'"
								+"dojoAttachPoint='showAllOptions_cB' "
								+"dojoAttachEvent='onChange:showAllOptions_changed,onFocus:showEditHints' "
								+"value='true' />"
							+ T('attrConfiguration_cKeyValuePair.js/DisplOptInRM_TXT','Display all options in read mode, as well.')
						+"</label>"
					+"</div>"
				+"</td>"
			+"</tr>"

			+"<tr>"
				+"<td class='textRight'>" + T('attrConfiguration_cKeyValuePair.js/DefValOpt_TXT','Default value (optional):') + "</td>"
				+"<td>"
					+"<p>" + T('attrConfiguration_cKeyValuePair.js/SelDefValOpt_TXT','Please select all options that are default values:') + "</p>"
					+"<select class='fullWidth dijitTextBox dijitTextArea' style='height:12.5em;' "
						+"dojoType='dijit.form.MultiSelect' "
						+"dojoAttachPoint='defaultValue_MSWidget' "
						+"dojoAttachEvent='onChange:defaultValues_changed,onFocus:showEditHints'>"
					+"</select>"
					+"<div class='small' style='display:none;' dojoAttachPoint='parentDefaultValueMessage_node'><p>"
						+ T('attrConfiguration_cKeyValuePair.js/InherDefVal_TXT','The inherited default value is') + " « <span dojoAttachPoint='parentDefaultValue_string_formatted'></span>» .</br>"
						+ T('attrConfiguration_cKeyValuePair.js/ClkToUseInherDefVal_LNK','Click <a dojoAttachEvent="onclick:useInheritedDefaultValue_clicked">here</a> to use the inherited default value.')
					+"</p></div>"
				+"</td>"
			+"</tr>"
			
		);
		
		//localise the necessary variables
		this.locateProperties([	'keyValuePairsAsString',
								'displayAsCheckbox', 'showAllOptions', 
								'defaultValueAsString', 
								'parentDefaultValue', 'parentDefaultValueAsString',
							]);
		
		// generate the template string
		this.generateTemplateString();

	} // end of method
	,
	'keyValuePairsAsString_changed' : function (e) {
		this.keyValuePairsAsString = this.keyValuePairsAsString_tA.attr('value');
		this.propertyHasChanged('keyValuePairsAsString');
		this.setOptionsForDefaultValues();
	} // end of method keyValuePairsAsString_changed
	,
	'defaultValues_changed' : function (e) {
		this.defaultValueAsString=this.defaultValue_MSWidget.attr('value').join('\n');
		this.propertyHasChanged('defaultValueAsString');
		this.setOptionsForDefaultValues();
		
		if (this.isInherited && (this.parentDefaultValueAsString != this.defaultValueAsString)) dojo.style(this.parentDefaultValueMessage_node, 'display', 'block');
	} // end of method defaultValues_changed
	,
	'displayAsCheckbox_changed' : function (e) {
		this.displayAsCheckbox = this.displayAsCheckbox_yes_rB.attr('checked');
		this.propertyHasChanged('displayAsCheckbox');
		
		dojo.style(this.showAllOptions_DOMNode,'display',((this.displayAsCheckbox)?'block':'none'));
	} // end of method displayAsCheckbox_changed
	,
	'showAllOptions_changed' : function (e) {
		this.showAllOptions = this.showAllOptions_cB.attr('checked');
		this.propertyHasChanged('showAllOptions');
	} // end of method showAllOptions_changed
	,
	'postCreate' : function() {
		this.inherited(arguments);

		if(this.displayAsCheckbox) 	this.displayAsCheckbox_yes_rB.attr('checked',true)
			else					this.displayAsCheckbox_no_rB.attr('checked',true);
			
		this.showAllOptions_cB.attr('checked',this.showAllOptions);
		
		dojo.style(this.showAllOptions_DOMNode,'display',((this.displayAsCheckbox)?'block':'none'));
		
		this.keyValuePairsAsString_tA.attr('disabled', this.isInherited);
		this.displayAsCheckbox_no_rB.attr('disabled', this.isInherited);
		this.displayAsCheckbox_yes_rB.attr('disabled', this.isInherited);
		this.showAllOptions_cB.attr('disabled', this.isInherited);
		
		// show the interited default value, if necessary
		if (this.isInherited) {
			// set the list of inherited default values
			var defaultKeyArray = this.parentDefaultValueAsString.split('\n'),
				formattedParentDefaultValues = [];

			var kVPairs = this.keyValuePairsAsString.split('\n');
			dojo.forEach(kVPairs,function(kVString, i){
				var kVString_splitted 	= 			kVString.split('|');
				if(kVString_splitted.length<=1) return; // exit if kVString is no valid key-value pair
				
				var	key					= dojo.trim(kVString_splitted[0]),
					value 				= dojo.trim(kVString_splitted[1]);
					
				if(dojo.indexOf(defaultKeyArray, key)>-1) formattedParentDefaultValues.push('<code>'+value+'</code>');
				
			},this);

			dojo.attr(this.parentDefaultValue_string_formatted, 'innerHTML', formattedParentDefaultValues.join('; ') );
			
			if (this.parentDefaultValueAsString != this.defaultValueAsString) dojo.style(this.parentDefaultValueMessage_node, 'display', 'block');
		} // end if isInherited
		
		this.setOptionsForDefaultValues();
	} // end of method postcreate
	,
	'setOptionsForDefaultValues' : function () {
		dojo.empty(this.defaultValue_MSWidget.domNode);
		
		// convert defaultValueAsString to an object
		var defaultKey_array 	= this.defaultValueAsString.split('\n'),
			defaults_object = {};

		dojo.forEach(defaultKey_array,function(dKey_string,i){
			var dK=dojo.trim(dKey_string);
			if(dK.length) defaults_object[dK]=dK;
		},this);
		
		// iterate over all key-value pairs and insert an <option> DOM node into this.defaultValue_MSWidget
		var kVPairs = this.keyValuePairsAsString.split('\n');
		dojo.forEach(kVPairs,function(kVString, i){
			var kVString_splitted 	= 			kVString.split('|');
			if(kVString_splitted.length<=1) return; // exit if kVString is no valid key-value pair
			
			var	key					= dojo.trim(kVString_splitted[0]),
				value 				= dojo.trim(kVString_splitted[1]),
				optionObject		= {
										'innerHTML' : value,
										'value'		: key
										};
			if(defaults_object[key]) optionObject.selected=true;
			
			dojo.create('OPTION',optionObject, this.defaultValue_MSWidget.domNode);
		},this);
			
	} // end of method setOptionsForDefaultValues
	,
	'useInheritedDefaultValue_clicked' : function (e) {
		dojo.stopEvent(e);
		
		this.defaultValueAsString=this.parentDefaultValueAsString;
		this.propertyHasChanged('defaultValueAsString');
	
		this.setOptionsForDefaultValues();
		
		dojo.style(this.parentDefaultValueMessage_node, 'display', 'none');
	} // end of method useInheritedDefaultValue_clicked
});
