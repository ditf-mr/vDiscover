﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare("application.widgets.cKeyValuePairAttribute",[application.widgets.genericAttribute],{
	'outputInReadMode' : function() {

		if(!Object.keys(this.valueTuples).length) return '';
		
		// some preparations
		if (!('keyValuePairs' in this.config) || (typeof this.config.keyValuePairs != 'object')) {
			this.config.keyValuePairs = {};
			var kvArray = this.config.keyValuePairsAsString.split('\n');
			dojo.forEach(kvArray, function (kvPair){
				var kvPair_split=kvPair.split('|');
				this.config.keyValuePairs[kvPair_split[0]]=kvPair_split[1];
			},this);
		} // end if 
		
		// there are principally two cases:
		// 1) output all values separated by this._valueTupleSeparator
		// 2) output all values with an empty/ filled checkbox/ radio button before it
		
		// the 2nd case is true, if:
		
		//showAllOptions == true
		
		// cardinality==1
		// radio & checked : class="dijit dijitReset dijitInline dijitRadio dijitRadioChecked dijitChecked"
		// radio & unchecked : class="dijit dijitReset dijitInline dijitRadio"
		
		// cardinality otherwise
		// checkbox & checked : class="dijit dijitReset dijitInline dijitCheckBox dijitCheckBoxChecked dijitChecked"
		// checkbox & unchecked : class="dijit dijitReset dijitInline dijitCheckBox"
		
		var k,o=[];
		
		
		// 2nd case:
		if (this.config.showAllOptions) {
			// sort out the dijitXXX classes
			var classList='dijit dijitReset dijitInline ', checkedCListExtension='dijitChecked ';
			if (this.config.cardinality==1) {
				classList+='dijitRadio ';
				checkedCListExtension+='dijitRadioChecked';
			} else {
				classList+='dijitCheckBox ';
				checkedCListExtension+='dijitCheckBoxChecked';
			} // end if
		
			// build a list of all options
			var options={};
			for (k in this.config.keyValuePairs) options[k]={v:this.config.keyValuePairs[k],selected:false};
			for (k in this.valueTuples) {
				var t=this.valueTuples[k];
				if(options[t.value_listKey]) {
					options[t.value_listKey].selected=true;
				} else {
					options[t.value_listKey]={v:'Unknown key: « '+t.value_listKey+'» !'};
				} // end if
			} // end for .. in
			
			// build the output string
			var s='';
			for (k in options) {
				var t=options[k];
				s+=''
					+'<tr>'
						+'<td class="RS_VTE_kV_clickMeCol">'
							+'<div class="'+classList+((t.selected)?checkedCListExtension:'')+'"></div>'
						+'</td>'
						+'<td class="RS_VTE_kV_labelCol">'
							+t.v
						+'</td>'
					+'</tr>';
			} // end for .. in
		
			return '<table class="fullWidth RS_VTE_kV_table"><tbody>'+s+'</tbody></table>';
		} // end if show all options
		
		// let's continue with the 1st case
		
		for(k in this.valueTuples) {
			var t=this.valueTuples[k];
			if (this.config.keyValuePairs[t.value_listKey]) {
				o.push(this.config.keyValuePairs[t.value_listKey]);
			} else {
				o. push('Unknown key: « '+t.value_listKey+'» !');
			} //
		} // end for .. in
		
		return this.htmlFormatTupleSet_readMode(o);
	} // end of method outputInReadMode
	,
	'outputInEditMode' : function() {
		return '';// dojo.toJson(this.config,true);
	} // end of method outputInEditMode
	,
	'tuple_isEmpty' : function (tuple) {
		if(!tuple.value_listKey) return true;
		return false;
	} // end of method tuple_isEmpty
	,
	'_emptyValueTuple': {'value_listKey':''}
	,
	'constructor' : function () {
		this.changeList = {};
		this.widgets	= {};
	
	} // end of method constructor
	,
	'destroy' : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		
		for (var i in this.widgets) {
			if (this.widgets[i].destroyRecursive) try{
				this.widgets[i].destroyRecursive();
			} catch(e) {
				console.error('Problem in '+this.declaredClass+'::destroy():\nWhen trying to delete subwidget "'+i+'", the following error was thrown:');
				console.error(e);
				console.log('this', this);
				console.log('this.widgets[i]', this.widgets[i]);
				dijit.registry.remove(this.widgets[i].id);
			} // end if .. try
			delete this.widgets[i];
		} // end for .. in
				
		this.inherited(arguments);
	} // end of method destroy
	,
	
	
	// ###############################
	// some methods that are necessary to handle the changes
	
	'changeList'	: null,
	'widgets'		: null,

	'usedCardinality' : 0
	,
	'prepareChangeList' : function () {
		// this function converts this.config.keyValuePairs and this.valueTuples into this.changeList
		var i, j=1, k, v;
		this.changeList={};
		
		// iterate over all this.config.keyValuePairs and put them into the change list
		for (i in this.config.keyValuePairs) this.changeList[i]={
			'value_listKey'		: i,
			'value'				: this.config.keyValuePairs[i],
			'selected'			: false,
			'AV_UUID'			: Math.uuid(),
			'UUID' 				: Math.uuid(),
			'positionOfValue' 	: j++,
		}; // end for .. in
		
		var vT				= this.valueTuples;
			
		if(!(Object.keys(this.valueTuples).length) && this.config.defaultValueAsString && this.config.defaultValueAsString.length) {
			// no value tuples? -> set default values
			
			var dV = this.config.defaultValueAsString.split('\n');
			dojo.forEach(dV,function(defVal,index){
				vT[index]={
					'value_listKey' : dV,
					'AV_UUID' 		: Math.uuid(),
					'UUID' 			: Math.uuid()
				};
			},this);
			
		} // end if
		
		// iterate over all this.valueTuples and put them into the change list
		for (k in vT) {
			var v=vT[k];
			if(!this.changeList[v.value_listKey]) continue;
			
			this.changeList[v.value_listKey].selected	= true;
			this.changeList[v.value_listKey].AV_UUID	= v.AV_UUID;
			this.changeList[v.value_listKey].UUID		= v.UUID;
			
			this.usedCardinality++;
		}; // end for .. in
		
	} // end of method prepareChangeList
	,
	'informViewWidgetAboutChanges' : function() {
		if (this.viewWidget && this.viewWidget.attrValueTuple_hasChanged) {
		
			var cTS = this.getChangedTupleSet();
			
			// for this attribute, it is necessary to tell the view the changed value tuples one by one ...
			for(var vT_UUID in cTS) this.viewWidget.attrValueTuple_hasChanged(this.A_UUID, cTS[vT_UUID].AV_UUID, cTS[vT_UUID] );
	
		} // end if
	} // end of function informViewWidgetAboutChanges
	,
	'selectKey' : function (k, unselectAllOthers) {
		if(unselectAllOthers) this.unselectAllKeys();
		if(k) {
			this.changeList[k].selected=true;
			this.usedCardinality++;
		} // end if
		this.informViewWidgetAboutChanges();
	} // end of method selectKey
	,
	'selectKeySet' : function (kArray) {
		this.unselectAllKeys();
		dojo.forEach(kArray,function(k) {
			if (		
						(this.config.cardinality==0) 
					|| 	(this.usedCardinality<this.config.cardinality)
				) {
				this.changeList[k].selected=true; 
				this.usedCardinality++;
			} else {
				// unselect the corresponding node
				this.option_DOMNodes[k].selected=false;		
			} // end if
		},this); // end dojo.forEach
		this.informViewWidgetAboutChanges();
	} // end of method selectKeySet
	,
	'unselectKey' : function (k) {
		this.changeList[k].selected=false;
		this.usedCardinality--;
		this.informViewWidgetAboutChanges();
	} // end of method unselectKey
	,
	'unselectAllKeys' : function () {
		var k;
		for (k in this.changeList) this.changeList[k].selected=false;
		this.usedCardinality=0;
		// as this method is called as a helper function, only, there is no need to inform the view widget about the changes
	} // end of method unselectAllKeys
	,
	'getChangedTupleSet' : function () {
		// iterate over this.changeList and return an object with all slots that are selected
		
		var l={};
		
		for (var k in this.changeList) {
			var kVP=this.changeList[k];
			if(kVP.selected) l[kVP.AV_UUID]=({
				'value_listKey'		: kVP.value_listKey,
				'value'				: kVP.value,
				'AV_UUID'			: kVP.AV_UUID,
				'UUID' 				: kVP.UUID,
				'positionOfValue' 	: kVP.positionOfValue,
				// 'selected'			: kVP.selected
			});
		} // end for .. in
		
		return l;
	} // end of method getChangedTupleSet
	,
	// ###########################################
	'cardinalityInformer' : null
	,
	'outputCardinalityInformer' : function () {
		this.cardinalityInformer = dojo.create('div',{innerHTML: T('attr_cKeyValuePair.js/UsingXValTplOfY_TXT','Using x value tuples of y.'), 'class':'RS_VTE_kV_outer textRight'},this.containerNode);	
		this.updateCardinalityInformer();
	} // end of method outputCardinalityInformer
	,
	'updateCardinalityInformer' : function () {
		var kVPairs=Object.keys(this.config.keyValuePairs).length;
		
		//TG: Old version without T() Call
		// this.cardinalityInformer.innerHTML=
		//	'Using '+this.usedCardinality+' values'
		//	+((this.config.cardinality!=0)?' of '+Math.min(this.config.cardinality,kVPairs):'')
		//	+'.';
		this.cardinalityInformer.innerHTML=
			T('attr_cKeyValuePair.js' , 'Using $[0] values' , [this.usedCardinality])
			+ ((this.config.cardinality!=0)?' '+T('FUT_of','of')+' '+Math.min(this.config.cardinality,kVPairs):'')
			+'.';
		
	} // end of method updateCardinalityInformer
	,
	'updateCheckBoxEditStatus' : function () {
		if (this.config.cardinality!=0) {
			if (this.usedCardinality>=this.config.cardinality) {
				// disable all remaining checkboxes
				dojo.forEach( this.checkboxList,function(cB){
					if(!cB.attr('checked')) cB.attr('disabled',true);
				},this); // end dojo.forEach
			} else {
				// enable all checkboxes
				dojo.forEach( this.checkboxList,function(cB){
					cB.attr('disabled',false);
				},this); // end dojo.forEach
			} // end if
		} // end if
	} // end of method updateCheckBoxEditStatus
	,
	'updateOptionListEditStatus' : function () {
		if (this.config.cardinality!=0) {
			var k;
			if (this.usedCardinality>=this.config.cardinality) {
				// disable all remaining options
				for (k in this.option_DOMNodes) {
					var oN=this.option_DOMNodes[k];
					if(!oN.selected) oN.disabled=true;//dojo.setSelectable(oN,false);
				} // end for .. in
			} else {
				// enable all options
				for (k in this.option_DOMNodes) {
					var oN=this.option_DOMNodes[k];
					oN.disabled=false;//dojo.setSelectable(oN,true);
				} // end for .. in
			} // end if
		} // end if

		for (k in this.changeList) dojo.attr(this.option_DOMNodes[k],'selected',(this.changeList[k].selected));
	} // end of method updateOptionListEditStatus
	,
	'postCreate' : function() {
		if(this.outputMode=='read') {
			this.showHide_noValueTuplesMessage();			
			return;
		} // end if
		
		// the following code is executed, ONLY, if the output mode is "edit"
		
		this.prepareChangeList();
		
		var optionList_outer = dojo.create('div',{'class': 'RS_VTE_kV_outer'}, this.containerNode);
		
		switch (true) {
			case (this.config.displayAsCheckbox && (this.config.cardinality==1)):
				{ // output options as a list of the type dijit.form.RadioButton
				
					// create a table and place it at this.containerNode
					this.optionsTable = dojo.create('table',{'class': 'fullWidth RS_VTE_kV_table'}, optionList_outer);
					
					// add rows to the table, a col for the radio button, another one for the label
					var kVPs=this.config.keyValuePairs;
					for (var k in kVPs) {
						var v		= kVPs[k],
							row 	= dojo.create('tr',{},this.optionsTable),
							selCol	= dojo.create('td',{'class':'RS_VTE_kV_clickMeCol'},row),
							widgetId= Math.uuid();
						
						this.widgets[k] = new dijit.form.RadioButton({
							'id'		: widgetId,
							'checked'	: (this.changeList[k].selected),
							'value'		: k,
							'name'		: 'rB_'+this.id,
							'attribute' : this,
							'onClick'	: function(e) {
								this.attribute.selectKey(this.attr('value'), 'unselectAllOthers');
							} // end onClick
							,
						}).placeAt(selCol);
						
						var labelCol= dojo.create( 'td',	{'class' : 'RS_VTE_kV_labelCol' },										row		),
							label	= dojo.create( 'label',	{'innerHTML' : v, 'for' : widgetId, 'class' : 'RS_VTE_kV_labelCol' },	labelCol);
							
					} // end for .. in
				
					break; }
			case (this.config.displayAsCheckbox && (this.config.cardinality!=1)):
				{ // output options as a list of the type dijit.form.CheckBox
				
					// create a table and place it at this.containerNode
					this.optionsTable = dojo.create('table',{'class': 'fullWidth RS_VTE_kV_table'}, optionList_outer);
					
					// add rows to the table, a col for the radio button, another one for the label
					this.checkboxList=[];
					
					var kVPs=this.config.keyValuePairs;
					
					for (var k in kVPs) {
						var v=kVPs[k],
							row = dojo.create('tr',{},this.optionsTable),
							selCol = dojo.create('td',{'class':'RS_VTE_kV_clickMeCol'},row),
							widgetId= Math.uuid();
							
						this.widgets[k] = new dijit.form.CheckBox({
							'id'		: widgetId,
							'checked'	: (this.changeList[k].selected),
							'key'		: k,
							'attribute' : this,
							'value'		: k,
							//name: 'rB_'+this.id,
							'onClick' : function(e) {
								var status = this.attr('value');
								if(status) {
									this.attribute.selectKey(this.key);
								} else {
									this.attribute.unselectKey(this.key);
								}; // end if status
								this.attribute.updateCardinalityInformer();
								this.attribute.updateCheckBoxEditStatus();
							} // end onClick
						}).placeAt(selCol);
						
						var labelCol 	= dojo.create( 'td',	{ 'class' : 'RS_VTE_kV_labelCol'}, 									row),
							label 		= dojo.create( 'label', { 'innerHTML' : v, 'for':widgetId, 'class':'RS_VTE_kV_labelCol'},	labelCol);
						
						this.checkboxList.push(this.widgets[k]);
					} // end for .. in
					
					// add div with the still available cardinality
					// this needs to be improved!
					this.outputCardinalityInformer();
					this.updateCheckBoxEditStatus();
					
					break; }
			case (!this.config.displayAsCheckbox && (this.config.cardinality==1)):	
				{ // output options as a dijit.form.filteringSelect
				
					// build an option list
					var optionList = [],
						kVP=this.config.keyValuePairs;
						
					for (var k in  kVP) optionList.push({ 'listKey': k, 'value_string': kVP[k] }); 
					
					// get the selected key
					var selectedKey='';
					for (var k in this.changeList) if(this.changeList[k].selected) selectedKey=k;
					
					// build data for store
					this.widgets.filteringSelect = new dijit.form.FilteringSelect({
							'store'			: new dojo.data.ItemFileReadStore({data:{label:'listKey',identifier:'listKey',items: optionList}}),
							'value'			: selectedKey,
							'searchAttr'	: "value_string",
							'class'			: 'fullWidth',
							'highlightMatch': 'all',
							'queryExpr'		: '*${0}*',
							'ignoreCase'	: true,
							'missingMessage': T('attr_cKeyValuePair.js/ChooseAVal_TXT','Please choose a value.'),
							'emptyLabel'	: T('attr_cKeyValuePair.js/DefineListOfVal_TXT','Please define a list of values.'),
							'attribute'		: this,
							'onChange'		: function(selectedKey){
								this.attribute.selectKey(selectedKey, 'unselectAllOtherKeys');
							} // end method onChange
							,
					}).placeAt(optionList_outer);
				
					break; }
			case (!this.config.displayAsCheckbox && (this.config.cardinality!=1)):
				{ // output options as a dijit.form.multiSelect
				
					var optionList = [], kVP=this.config.keyValuePairs;
					this.option_DOMNodes={};
					
					// create a select node
					var selectNode = dojo.create('select',{},optionList_outer);
					
					// create the options
					for (var k in  kVP) this.option_DOMNodes[k] = dojo.create('option', {'value':k,'innerHTML':kVP[k]}, selectNode);
				
					// instantiate the famous dijit.form.MultiSelect ontop of the select node 
					this.widgets.multiSelect = new dijit.form.MultiSelect({
						'size'		: Object.keys(this.config.keyValuePairs).length,
						'class'		: 'fullWidth',
						'attribute' : this,
						'onChange'	: function(selKeyArray){
							this.attribute.selectKeySet(selKeyArray);
							this.attribute.updateCardinalityInformer();
							this.attribute.updateOptionListEditStatus();
						} // end method onChange
					}, selectNode);
					
					// set the selected option on the corresponding nodes
					for (var k in  this.changeList) 
						dojo.attr( this.option_DOMNodes[k], 'selected', (this.changeList[k].selected) );
				
					// add div with the still available cardinality
					// this needs to be improved!
					this.outputCardinalityInformer();
					this.updateOptionListEditStatus();
				
					break; }
			default: // do nothing
		} // end switch which kind of output mode
	} // end of method postCreate
	,
	'isValid' : function () {
		var isValid = true;
		if(this.config.mustBeSet && !(Object.keys(this.getChangedTupleSet()).length)) isValid=false;

		// mark the whole attribute as invalid, if necessary
		if(isValid) {
			this.remove_notValidMark();
		} else {
			this.markAs_notValid();
		}; // end if
		
		return isValid;
	} // end of method isValid
	,
	'setValueTuple' : function (VT_UUID, vT) {
	
		// unselect all selected values
		switch (true) {
			case ((Object.keys(this.widgets).length==1) && ('filteringSelect' in this.widgets)):
				this.widgets.filteringSelect.attr('value', '');
			break;
			
			case ((Object.keys(this.widgets).length==1) && ('multiSelect' in this.widgets)):
				this.widgets.filteringSelect.attr('value', []);
			break;
			
			default:
				for (var k in this.widgets) this.widgets[k].attr('checked', false);
		
		} // end switch
		
		// set the passed value tuple vT
		var selectedListKey = vT.value_listKey;
		
		switch (true) {
			case ((Object.keys(this.widgets).length==1) && ('filteringSelect' in this.widgets)):
				this.widgets.filteringSelect.attr('value', selectedListKey);
			break;
			
			case ((Object.keys(this.widgets).length==1) && ('multiSelect' in this.widgets)):
				this.widgets.filteringSelect.attr('value', [selectedListKey]);
			break;
			
			default:
				this.widgets[selectedListKey].attr('checked', true);
		
		} // end switch
	
	} // end of method setValueTuple
	,
}); // end of class declaration keyValuePairAttribute
