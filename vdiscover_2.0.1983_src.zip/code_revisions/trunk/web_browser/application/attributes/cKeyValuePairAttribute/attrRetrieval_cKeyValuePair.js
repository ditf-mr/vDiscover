﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare(
	'application.widgets.retrieveAttributes.cKeyValuePairAttribute',
	[application.widgets.retrieveAttributes.genericAttribute],
	{

		'values_changed': function() {
			/**
			 * Entry point for all changes done in the retrieval form of this attribute.
			 * - calls function to adapt (correct) the inputs in the form
			 * - calls parent retrieval modul to inform it about the changes
			 */
			this._adaptInputForm();
			this._informRetrievalModul();
		}, // end-of-method values_changed
		
		
		'_informRetrievalModul': function(e){
			/**
			 * Calls the parent retrieval modul to inform it about the changes in this
			 * attribute.
			 */
			{ // Inform retrieve modul about changes
			{ // Get current values
				var search_key = this.searchKey_S.get('value');
				var not = this.not_cB.checked;
				var parsedQuery = this._parseQuery();
			}
				application.OT.retrieve.changeRetrievalAttribute(
					this.UUID,
					{
						'search_key': search_key,
						'not': not,
						'parsedQuery': parsedQuery,
						'ok': (parsedQuery != '')
					}
				);
			}
		},  // end-of-method values_changed
		
		
		'_parseQuery': function() {
			/**
			 * Generates a text form of the query, that can be displayed.
			 * @return string.
			 */
			var returnValue = '';
			{ // Get current values
				var search_key = this.searchKey_S.get('value');
				var not = this.not_cB.checked;
			}
			{ // Generate return value 
				if (search_key) {
					var keyValuePairsAsArray = this.keyValuePairsAsString.split('\n');			
					var keyValuePairs = {};
					dojo.forEach(keyValuePairsAsArray, function(keyValuePair, i){
						kVP = keyValuePair.split('|');
						keyValuePairs[kVP[0]] = kVP[1];
					});
					var output = '';
					dojo.forEach(search_key, function(key, i) {
						if (output != '') {
							output += ' ' + T('FUT_OR','OR') + ' ';
						}
						output += keyValuePairs[key];
					});
					if (not) {
						returnValue = T('attrRetrieval_cKeyValuePair.js/SearchRes_isNot_TXT','$[0] is not "$[1]"', [this.name, output]);
					}
					else {
						returnValue = T('attrRetrieval_cKeyValuePair.js/SearchRes_is_TXT','$[0] is "$[1]"', [this.name, output]);
					}
				}
			}
			return (returnValue);
		}, // end-of-method _parseQuery
		
		
		'postMixInProperties': function() {
			// If you provide a postMixInProperties method for your widget, 
			// it will be invoked before rendering occurs, and before 
			// any dom nodes are created. If you need to add or change the 
			// instance's properties before the widget is rendered 
			// - this is the place to do it.
			this.inherited(arguments);
			
			//localise the necessary variables
			this.locateProperties(['search_key', 'not', 'keyValuePairsAsString', 'name']);

			if ( this.keyValuePairsAsString ){
				var keyValuePairsAsArray = this.keyValuePairsAsString.split('\n');
				var options = "";
				dojo.forEach(keyValuePairsAsArray, function(keyValuePair, i){
					kVP = keyValuePair.split('|');
					options += "<option value='"+kVP[0]+"'>"+kVP[1]+"</option>";
				});
			}

			if (!this.search_key) {
				this.search_key ='';
			}		

			if (!this.not) {
				this.not = false;
			}		

			// prepare output
			var checked = "";
			if (this.not == true) {
				checked = " checked='checked'";
			}
			this.title = T('attrRetrieval_cKeyValuePair.js/SearchParas_TIT','Search parameters');
			
			// expand the template string
			this.addTemplateSection(""
				+'<tr>'
					+'<td class="textRight" width="30%" style="vertical-align: top;">'
						+T('attrRetrieval_cKeyValuePair.js/SearchFor_LBL','Search for:')
					+'</td>'
					+'<td width="70%">'
						+"<select style='width:100%;'"
							+"value='${search_key}'" 
							+"dojoAttachEvent='onChange: values_changed' "
							+"dojoAttachPoint='searchKey_S' "
							+"dojoType='dijit.form.MultiSelect'"
						+">"
							+options
						+"</select>"
					+'</td>'
				+'</tr>'
				+"<tr>"
					+"<td class='textRight' width='30%'> </td>"
					+"<td width='70%'>"
						+"<input type='checkbox'"
							+" value='1'"
							+checked
							+" dojoAttachEvent='onChange:values_changed'"
							+" dojoAttachPoint='not_cB'"
							+" dojoType='dijit.form.CheckBox'"
						+"/>"
						+" "
						+T('attrRetrieval_cKeyValuePair.js/Not_LBL', 'Negate condition of search mode')
					+"</td>"
				+"</tr>"
				+"<tr>"
					+"<td class='textRight' width='30%'>"
						+T('attrRetrieval/SearchRemarks_TXT','Remarks:')
					+"</td>"				
					+"<td width='70%'>"
							+"<ul>"
								+"<li>"
									+T('attrRetrieval_cKeyValuePair.js/SelectTip_TXT','You can select one, or more by holding \"ctrl\"-key pressed, of the options to find the related objects')
								+"</li>"
								+"<li>"
									+T('attrRetrieval_cKeyValuePair.js/SelNot_HTM', 'Negating the condition of the search mode results in a logical not in the query condition.')
								+"</li>"
							+"</ul>"
					+"</td>"
				+"</tr>"	
			);
			
			// generate the template string
			this.generateTemplateString();
			
		}, // end-of-method postMixInProperties
	
	
		'postCreate': function(){
			// set the pre-selected values
			this.searchKey_S.set('value', this.search_key);
		}, // end-of-method postCreate
		
		
		'_end_': null	
	
});
