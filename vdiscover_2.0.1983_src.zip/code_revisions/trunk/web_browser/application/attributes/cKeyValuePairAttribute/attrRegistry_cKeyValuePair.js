﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

application.attributeKinds.register({kind: "cKeyValuePairAttribute", 
	defaultConfiguration : { 
		cardinality: 1, 
		unit:'',
		svFormatActivated: false,
		svHtmlBefore: '',
		svHtmlBetween: '',
		svHtmlAfter: '',
		displayAsCheckbox: false,		/* >>boolean<< cKeyValuePairAttribute */
		showAllOptions:	false,			/* >>boolean<< cKeyValuePairAttribute */
		keyValuePairsAsString:	''		/* >>text<< cKeyValuePairAttribute */
	}
	,
	// defaultValues:{
		// value_listKey:""
	// }
	// ,
	defaultRetrievalValues:['search_key','keyValuePairsAsString']
	,
	widgetClass: 'application.widgets.cKeyValuePairAttribute',
	configurationWidgetClass : 'application.widgets.configureAttributes.cKeyValuePairAttribute',
	standardCardinality : false // the cKeyValuePairAttribute has a special behaviour for cardinality which means that a select becomes a multiselect or a radiobutton becomes a checkbox
	,
	'useValueTupleAsExpressionInput'	: false
	,
	'expressionsPermitted'				: false
	,

	
	// CBR configuration -------------------------------------------------------------
	'supportsCBR'						: function ( attrConfigAsObj ) {
		return		true
				&&	(attrConfigAsObj.cardinality == 1)
				&&	(		(attrConfigAsObj.mustBeSet == "true")
						||	(attrConfigAsObj.mustBeSet == true)
					);
	} // end of method
	,
	'similarityMethods'		: {
		'cEquality'			: T('aR_cKVP_CBR_eq', 'Equality'),
	}
	,
	'adaptationMethods'		: {
		'cMainValue'		: T('aR_cKVP_CBR_mFV', 'Most frequent value / Mode'),
	}
	,
	

});
