<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// register all attribute components
$attrName = 'cSingleLine';

$mainPath = 'application/attributes/cSingleLineAttribute/';

$attrComponentPaths = array (
	'attr',
	// 'attrConfiguration', // --- admin only
	'attrRegistry',
	'attrRetrieval',
	'attrValueTupleEditor',
);

reset($attrComponentPaths);
while(list($k, $cP)=each($attrComponentPaths)) 
	$r->register_JavaScriptFile($mainPath.$cP.'_'.$attrName.'.js');

// attribute configuration
global /*$r, */$backend;
if($backend->isAdmin()){
	$r->register_JavaScriptFile($mainPath.'attrConfiguration'.'_'.$attrName.'.js');
} // end if user is admin

?>