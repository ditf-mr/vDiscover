﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare(
	'application.widgets.retrieveAttributes.cSingleLineAttribute',
	[application.widgets.retrieveAttributes.genericAttribute],
	{
		'values_changed': function() {
			/**
			 * Entry point for all changes done in the retrieval form of this attribute.
			 * - calls function to adapt (correct) the inputs in the form
			 * - calls parent retrieval modul to inform it about the changes
			 */
			this._adaptInputForm();
			this._informRetrievalModul();
		}, // end-of-method values_changed
		
		
		'_informRetrievalModul': function(e){
			/**
			 * Calls the parent retrieval modul to inform it about the changes in this
			 * attribute.
			 */
			{ // Inform retrieve modul about changes
			{ // Get current values
				var search_text = this.searchString_tB.get('value');
				var not = this.not_cB.checked;
				var parsedQuery = this._parseQuery();
			}
				application.OT.retrieve.changeRetrievalAttribute(
					this.UUID,
					{
						'search_text': search_text,
						'not': not,
						'parsedQuery': parsedQuery,
						'ok': (parsedQuery != '')
					}
				);
			}
		},  // end-of-method values_changed
		
		
		'_parseQuery': function() {
			/**
			 * Generates a text form of the query, that can be displayed.
			 * @return string.
			 */
			var returnValue = '';
			{ // Get current values
				var search_text = this.searchString_tB.get('value');
				var not = this.not_cB.checked;
			}
			{ // Generate return value 
				if (search_text) {
					if (not) {
						returnValue = T('attrRegistry_cSingleLine.js/SearchResNot_TXT','$[0] does not match "$[1]"', [this.name, search_text]);
					}
					else {
						returnValue = T('attrRegistry_cSingleLine.js/SearchRes_TXT','$[0] matches "$[1]"', [this.name, search_text]);
					}
				}
			}
			return (returnValue);
		}, // end-of-method _parseQuery
		
		
		'postMixInProperties': function() {
			// If you provide a postMixInProperties method for your widget, 
			// it will be invoked before rendering occurs, and before 
			// any dom nodes are created. If you need to add or change the 
			// instance's properties before the widget is rendered 
			// - this is the place to do it.
			this.inherited(arguments);

			// localise the necessary variables
			this.locateProperties(['search_text', 'not', 'name']);
			
			// check variable and initialise them, if necessary
			if (!this.search_text) {
				this.search_text ='';
			}		
			if (!this.not) {
				this.not = false;
			}		

			// prepare output
			var checked = "";
			if (this.not == true) {
				checked = " checked='checked'";
			}
			
			this.title = T('attrRetrieval_cSingleLine.js/SearchParas_TIT', 'Search parameters');
			
			// expand the template string
			this.addTemplateSection(""
				+'<tr>'
					+'<td class="textRight" width="30%">'
						+T('attrRetrieval_cSingleLine.js/SearchTextPattern_LBL', 'Search text pattern:')
					+'</td>'
					+'<td width="70%">'
						+"<input type='text' style='width:100%'"
							+"value='${search_text}'" 
							+"dojoAttachEvent='onChange:values_changed' "
							+"dojoAttachPoint='searchString_tB' "
							+"dojoType='dijit.form.ValidationTextBox'"
						+"/>"
					+'</td>'
				+'</tr>'
				+'<tr>'
					+'<td class="textRight" width="30%"> </td>'
					+'<td width="70%">'
						+'<input type="checkbox"'
							+' value="1"'
							+checked
							+' dojoAttachEvent="onChange:values_changed"'
							+' dojoAttachPoint="not_cB"'
							+' dojoType="dijit.form.CheckBox"'
						+'/>'
						+' '
						+T('attrRetrieval_cSingleLine.js/Not_LBL', 'Negate condition of search mode')
					+'</td>'
				+"</tr>"
				+'<tr>'
					+'<td class="textRight" width="30%">'
						+T('attrRetrieval/SearchRemarks_TXT','Remarks:')
					+'</td>'				
					+'<td width="70%">'
						+"<ul>"
							+"<li>"
								+ T('attrRetrieval_cSingleLine.js/SearchTipDescr_P2_HTM',
								'You can use wildcards to improve the results:<br />\<code>*</code> finds any char sequence, e.g.<br/>«<code>black*</code>» finds <code>black<i>bear</i></code>, <code>black<i>bird</i></code> and just <code>black</code>. Otherwise <br/>«<code>*berry</code>» finds <code><i>black</i>berry</code>, <code><i>straw</i>berry</code> and of course <code>berry</code>.')
							+"</li>"
							+"<li>"
								+T('attrRetrieval_cSingleLine.js/SelNot_HTM', 'Negating the condition of the search mode results in a logical not in the query condition.')
							+"</li>"
						+"</ul>"
					+'</td>'
				+'</tr>'	
			);
			
			// generate the template string
			this.generateTemplateString();
		}, // end-of-method postMixInProperties
		
		
		'_end_': null
		
	}
	
); // end-of-declaration

