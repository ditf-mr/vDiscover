﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare("application.widgets.cSingleLineAttribute",[application.widgets.standardAttribute],{
	'_emptyValueTuple': { 'value_text' : '' }
	,
	'valueTupleEditor_name': 'application.widgets.valueTupleEditor_singleLine'
	,
	'tuple_isEmpty' : function (tuple) {
		if(!tuple) return true;
		return (		!dojo.isString(tuple.value_text)
					|| 	(tuple.value_text.length==0)
				);
	} // end of method tuple_isEmpty
	,
	'htmlFormatValueTuple_readMode' : function (valueTuple) {
		return valueTuple.value_text;
	} // end of method htmlFormatValueTuple_ReadMode

}); // end of declaration
