﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare('application.widgets.configureSpecialAttribute.cSingleLineAttribute',[application.widgets.configureAttribute.genericConfigurationWidget],{

	'regexChanged' : function(e) {
		var newValue = this.regex_tB.attr('value');
		this.propertyHasChanged('format',newValue);
		this.defaultValue_tB.attr('regExp', this.format);
		this.defaultValue_tB.validate();
	} // end of methodregexChanged
	,
	'maxLengthChanged'	: function(e) {
		var v = this.maxLength_nS.attr('value');
		if (isNaN(v)) v=255;
		this.propertyHasChanged('maxLength',v);
		this.defaultValue_tB.attr('maxLength', this.maxLength);
	} // end of methodregexChanged
	,
	'defaultValueChanged' : function(e) {
		this.propertyHasChanged('defaultValue', this.defaultValue_tB.attr('value'));
		
		if (this.isInherited && (this.parentDefaultValue!=this.defaultValue))
			dojo.style(this.replaceDefaultValueMessageNode, 'display', 'block');
		
	} // end of method defaultValueChanged
	,
	'postMixInProperties': function() {
		this.inherited(arguments);
		
		//localise the necessary variables
		this.locateProperties(['format','maxLength','defaultValue', 'parentDefaultValue']);
		
		// expand the template string
		this.addTemplateSection(""
			+"<tr>"
				+"<td class='textRight'>" + T('attrConfig_cSingleLine.js/FormatDef_LBL', 'Format definition<br />(regular expresssion):') + "</td>"
				+"<td>"
				+"<input type='text' class='fullWidth' "
					+"value='${format}' "
					+"dojoAttachEvent='onFocus:showRegexEditHints' "
					+"dojoAttachPoint='regex_tB' "
					//+"disabled='{isInherited}' "
					+"dojoType='dijit.form.TextBox' "
					+"/>"
				+"</td>"
			+"</tr>"
			
			+"<tr>"
				+"<td class='textRight'>" + T('attrConfig_cSingleLine.js/MaxLengthOfStr_LBL', 'Max length of the string:') + "</td> "
				+"<td> "
					+"<input dojoType='dijit.form.NumberSpinner' value='${maxLength}' smallDelta='1' "
						+"constraints='{min:1,max:255,places:0}' style='width:100%;' "
						//+"disabled='{isInherited}' "
						+"dojoAttachEvent='onFocus:showEditHints' "
						+"dojoAttachPoint='maxLength_nS' "
						+"/>"
				+"</td>"
			+"</tr>"
			
			+"<tr>"
				+"<td class='textRight'>" + T('attrConfig_cSingleLine.js/DefVal_LBL', 'Default value:') + "</td>"
				+"<td>"
				+"<input type='text' class='fullWidth' "
					+"value='${defaultValue}' "
					+"dojoAttachEvent='onFocus:showEditHints' "
					+"dojoAttachPoint='defaultValue_tB' "
					+"dojoType='dijit.form.ValidationTextBox' "
					+"regExp='${format}' "
					+"maxLength='${maxLength}' "
					+"/>"
					+"<p dojoAttachPoint='replaceDefaultValueMessageNode' style='display:none'>" + T('attrConfig_cSingleLine.js/DefValMsg_P1_HTM', 'The inherited default value is « ${parentDefaultValue}» .') + "<br/>"
						+"<a style='cursor:pointer;' dojoAttachEvent='onclick:replaceDefaultValueWithParentDefaultValue'>" + T('attrConfig_cSingleLine.js/DefValMsg_P2_LNK', 'Click here to replace the current default value with the inherited one') + "</a>."
					+"</p>"
				+"</td>"
			+"</tr>"
		);
		
		// generate the template string
		this.generateTemplateString();
		
	} // end of method postMixInProperties
	,
	'replaceDefaultValueWithParentDefaultValue' : function (e) {
		this.defaultValue_tB.attr('value', this.parentDefaultValue);
	
		dojo.style(this.replaceDefaultValueMessageNode, 'display', 'none');
	
		dojo.stopEvent(e);
	} // end of method replaceDefaultValueWithParentDefaultValue
	,
	'postCreate' : function () {
		this.inherited(arguments);
	
		// take care of inheritance
		this.regex_tB		.attr('disabled', this.isInherited);
		this.maxLength_nS	.attr('disabled', this.isInherited);
	
		// inform that the inherited default value is different?
		if (this.isInherited && (this.parentDefaultValue!=this.defaultValue))
			dojo.style(this.replaceDefaultValueMessageNode, 'display', 'block');

		// connect the onChange methods
		if (!this.isInherited) {
			this.connect( this.regex_tB, 		'onChange', 'regexChanged');
			this.connect( this.maxLength_nS, 	'onChange', 'maxLengthChanged');
		} // end if
		this.connect( this.defaultValue_tB, 	'onChange', 'defaultValueChanged');
	
	} // end of method postCreate
});
