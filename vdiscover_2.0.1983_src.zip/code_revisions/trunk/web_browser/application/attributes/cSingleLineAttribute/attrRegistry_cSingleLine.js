﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

application.attributeKinds.register({kind: "cSingleLineAttribute", 
	defaultConfiguration : {
		'maxLength'			: 255, 
		'format'			:'.*',
		'cardinality'		: 1, 
		'svFormatActivated'	: false,
		'svHtmlBefore'		: '',
		'svHtmlBetween'		: '',
		'svHtmlAfter'		: '',
		'defaultValue'		: ''
	},
	widgetClass: 'application.widgets.cSingleLineAttribute'
	,
	'defaultRetrievalValues': ['search_text', 'not']
	,	
	// Analytical expression configuration -------------------------------------------
	'useValueTupleAsExpressionInput'	: true
	,
	'expressionsPermitted'				: true
	,
	'defExprValTasJSON'					: "{\n  \"value_text\" : \"ABC\", // req. string\n}"
	,

});
