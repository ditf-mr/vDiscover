﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare("application.widgets.valueTupleEditor_singleLine",[application.widgets.valueTupleEditor_generic],{
	
	'textBox' : null, // dijit.form.ValidationTextBox
	
	'buildTemplateContainer' : function() {
		this.templateContainer = '';//'<div dojoAttachPoint="textBox_domNode"></div>';
	} // end of method postMixInProperties
	,
	'postCreate' : function () {
		this.inherited(arguments);
		
		this.textBox = new dijit.form.ValidationTextBox({
			'intermediateChanges'	: true,
			'maxLength'				: this.config.maxLength,
			'regExp'				: this.config.formatDisplay,
			'required'				: (this.config.mustBeSet==true),
			'class'					: 'fullWidth',
			'value'					: this.valueTuple.value_text
		}).placeAt(this.containerNode);
		
		// set the default value, if necessary and specified
		if(		!this.textBox.attr('value') 
			&& 	this.config.defaultValue	) 
			this.textBox.attr('value', this.config.defaultValue);

		// register the widget and connect it, properly
		this._supportingWidgets.push(this.textBox);
		this.connect(this.textBox,'onChange', 'notifyAttributeOfChangedValue');
		
	} // end of method postCreate
	,
	'notifyAttributeOfChangedValue' : function () {
		// this method informs the connected attribute about the changed value tuple
		
		if(this.textBox.isValid()) {
			this.valueTuple.value_text = this.textBox.attr('value');
			this.attrWidget.valueTupleHasChanged(this.valueTupleUUID, this.getValueTuple() );
		} // end if is valid
	} // end of method notifyAttributeOfChangedValue
	,
	'getValueTuple' : function () {
		// this method is strictly speaking not necessary, but reduces overhead
		return {
			'value_text'			: this.valueTuple.value_text,
			'AV_UUID' 				: this.valueTuple.AV_UUID,
			'UUID'					: this.valueTuple.UUID,
			'positionOfValue' 		: this.valueTuple.positionOfValue,
			'intermediateChanges'	: true,
		};
	} // end of method getValueTuple
	,
	'setValueTuple' : function (vT) {
		// this method updates the value tuple and sets the input boxes, accordingly
		
		this.textBox.attr('value', vT.value_text);
		
		this.notifyAttributeOfChangedValue();
	} // end of method setValueTuple
	,
	'isValid' : function () {
		var 						isValid = this.textBox.isValid();
		if(this.config.mustBeSet) 	isValid = isValid && !this.attrWidget.tuple_isEmpty( this.getValueTuple() );
		return isValid;
	} // end of method
	,
});
