﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare("application.widgets.cMaintenanceInfoAttribute",[application.widgets.standardAttribute],{
	htmlFormatValueTuple_readMode : function (valueTuple) {
		var formatOptions = {};
		var nameBlock = '';
		
		if (this.config.dateFormat)	formatOptions.datePattern = this.config.dateFormat;
		if (this.config.timeFormat)	formatOptions.timePattern = this.config.timeFormat;
		
		if (this.config.showDate && !this.config.showTime){ // display time, date or both
			formatOptions.selector = 'date';
		} else if (!this.config.showDate && this.config.showTime){
			formatOptions.selector = 'time';
		} // end if
		
		if (valueTuple.user_P_UUID == '') {
			nameBlock = valueTuple.name;
		}
		else {
			nameBlock = '<div dojoType="application.widgets.internalLink" O_v_UUID="' + valueTuple.user_P_UUID + '">'
						+ valueTuple.name
						+ '</div>';
		}

		return (
			dojo.date.locale.format(dojo.date.stamp.fromISOString(valueTuple.timepoint.replace(' ','T')), formatOptions)
			+ " (" + nameBlock + ')'
		);
	} // end of method htmlFormatValueTuple_ReadMode
}); // end of declaration
