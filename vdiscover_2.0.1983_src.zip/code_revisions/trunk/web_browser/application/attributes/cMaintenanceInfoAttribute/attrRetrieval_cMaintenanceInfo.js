﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

/*
dojo.declare('application.widgets.retrieveAttributes.cMaintenanceInfoAttribute',[application.widgets.retrieveAttributes.genericAttribute],{

	dateBox1 : null, // dijit.form.DateTextBox
	timeBox1 : null, //dijit.form.TimeTextBox

	dateBox2 : null, // dijit.form.DateTextBox
	timeBox2 : null, //dijit.form.TimeTextBox

	values_changed: function(e){
		switch ( this.searchMode_S.attr('value') ) {
			case 'fromTo': {
				// handle constraints for editing 
				if (this.dateBox2.attr('value'))
					this.dateBox1.attr('constraints',{max:this.dateBox2.attr('value'), datePattern: this.dateFormat}) ;
				if (this.dateBox1.attr('value')) {
					this.dateBox2.attr('constraints',{min:this.dateBox1.attr('value'), datePattern: this.dateFormat})  ;
					this.dateBox2.attr('required',true);
				}
				if ( this.timeBox2.attr('value') ){
					if ( Date.parse(this.dateBox1.attr('value')) == Date.parse(this.dateBox2.attr('value')) ) {
						this.timeBox1.attr('constraints',{max:this.timeBox2.attr('value'), timePattern: this.timeFormat}) ;
					} else {
						this.timeBox1.attr('constraints',{timePattern: this.timeFormat}) ;					
					}
				}
				if ( this.timeBox1.attr('value') ) {
					if ( Date.parse(this.dateBox1.attr('value')) == Date.parse(this.dateBox2.attr('value')) ){
						this.timeBox2.attr('constraints',{min:this.timeBox1.attr('value'), timePattern: this.timeFormat})  ;
					} else {
						this.timeBox2.attr('constraints',{timePattern: this.timeFormat})  ;					
					}
					this.timeBox2.attr('required',true);

				}

				this.dateBox2.attr('disabled',false);
				this.timeBox2.attr('disabled',false);
				
				//get values from widget
				var date1 = this.dateBox1.attr('value');
				var time1 = this.timeBox1.attr('value');
				var date2 = this.dateBox2.attr('value');
				var time2 = this.timeBox2.attr('value');
	
				if ( (this.dateBox1.isValid() && this.timeBox1.isValid()) && (this.dateBox2.isValid() && this.timeBox2.isValid()) ) {
					
					// set searchMode to search store
					this.propertyHasChanged('searchMode',this.searchMode_S.attr('value'));

					// save value1
					if(date1 && time1) {
						dateTime1 =	(		dojo.date.stamp.toISOString(date1,{selector:'date'})
										+	dojo.date.stamp.toISOString(time1,{selector:'time'})
									).replace('T'," ");
									
						this.propertyHasChanged('value1', dateTime1);
					} else if (date1) {
						dateString1 = ( dojo.date.stamp.toISOString(date1,{selector:'date'}) ).replace('T'," ");

						this.propertyHasChanged('value1',dateString1);
					} else if (time1) {
						timeString1 = ( dojo.date.stamp.toISOString(time1,{selector:'time'}) ).replace('T'," ");

						this.propertyHasChanged('value1',timeString1);					
					} else {
						this.propertyHasChanged('value1','');
					} // end if	

					// save value2
					if(date2 && time2) {
						dateTime2 =	(		dojo.date.stamp.toISOString(date2,{selector:'date'})
										+	dojo.date.stamp.toISOString(time2,{selector:'time'})
									).replace('T'," ");
									
						this.propertyHasChanged('value2', dateTime2);
					} else if (date2) {
						dateString2 = ( dojo.date.stamp.toISOString(date2,{selector:'date'}) ).replace('T'," ");

						this.propertyHasChanged('value2',dateString2);
					} else if (time2) {
						timeString2 = ( dojo.date.stamp.toISOString(time2,{selector:'time'}) ).replace('T'," ");

						this.propertyHasChanged('value2',timeString2);					
					} else {
						this.propertyHasChanged('value2','');
					} // end if
					
				}	else {
					this.propertyHasChanged('searchMode',this.searchMode_S.attr('value'));
					this.propertyHasChanged('value1','');
					this.propertyHasChanged('value2','');
				}
				
				break;
			}
			default :{
				// reset with default values of dojo
				
				this.dateBox1.attr('constraints',{datePattern: this.dateFormat}) ;
				this.timeBox1.attr('constraints',{timePattern: this.timeFormat}) ;
				this.dateBox2.attr('constraints',{datePattern: this.dateFormat}) ;
				this.timeBox2.attr('constraints',{timePattern: this.timeFormat}) ;

				this.dateBox2.attr('disabled',true);
				this.timeBox2.attr('disabled',true);

				var date1 = this.dateBox1.attr('value');
				var time1 = this.timeBox1.attr('value');

				if (this.dateBox1.isValid() && this.timeBox1.isValid()) {
					
					// set searchMode to search store
					this.propertyHasChanged('searchMode',this.searchMode_S.attr('value'));

					if( date1 && time1 ) {
						dateTime1 =	(		dojo.date.stamp.toISOString(date1,{selector:'date'})
										+	dojo.date.stamp.toISOString(time1,{selector:'time'})
									).replace('T'," ");
									
						this.propertyHasChanged('value1', dateTime1);
					} else if (date1) {
							dateString1 = ( dojo.date.stamp.toISOString(date1, {selector: 'date'}) ).replace('T'," ");

						this.propertyHasChanged('value1',dateString1);
					} else if (time1) {
						timeString1 = ( dojo.date.stamp.toISOString(time1, {selector: 'time'}) ).replace('T'," ");

						this.propertyHasChanged('value1',timeString1);					
					} else {
						this.propertyHasChanged('value1','');
					} // end if
					
				} else {
					this.propertyHasChanged('searchMode',this.searchMode_S.attr('value'));
					this.propertyHasChanged('value1','');
				}
				break;
			}					
		}
	}
	,
	postMixInProperties : function() {
		// If you provide a postMixInProperties method for your widget, 
		// it will be invoked before rendering occurs, and before 
		// any dom nodes are created. If you need to add or change the 
		// instance's properties before the widget is rendered 
		// - this is the place to do it.
		this.inherited(arguments);

		//localise the necessary variables
		this.locateProperties(['searchMode','value1','value2','dateFormat','timeFormat']);

		// initialisation of variables 
		disabled='';
		constraintsValue1='';
		constraintsValue2='';

		if(!this.searchMode) {
			this.searchMode ='exactly';
		}		
		if(!this.value1) {
			this.value1 ='';
		} else {
			this.value1 = this.value1.replace(' ',"T");
		}
		
		if(!this.value2) {
			this.value2 ='';
		} else {
			this.value2 = this.value2.replace(' ',"T");
		}
		
		switch ( this.searchMode ) {
			case 'fromTo':
				disabled='';
				if(this.value2)
					constraintsValue1="constraints='{max:"+this.value2+"}'";
				if(this.value1)
					constraintsValue2="constraints='{min:"+this.value1+"}'";
				break;
			case 'exactly':
				disabled='disabled';
				break;
			default :
				break;
		}		

		this.title = "Search for * in « "+this.name+"» ";

		// expand the template string
		this.addTemplateSection(""			
			+"<tr>"
				+"<td class='textRight' width='30%'>Value 1: </td>"
				+"<td width='70%'>"
						+'<div class="RS_VTE_date" dojoAttachPoint="value1_dateBoxNode"></div>'
						+'&nbsp;'
						+'<div class="RS_VTE_time" dojoAttachPoint="value1_timeBoxNode"></div>'
				+"</td>"
			+"</tr>"
			+"<tr>"
				+"<td class='textRight' width='30%'>Choose search mode: </td>"
				+"<td width='70%'>"
					+"<select style='width:100%'"
						+"value='${searchMode}'" 
						+"dojoAttachEvent='onChange:values_changed' "
						+"dojoAttachPoint='searchMode_S' "
						+"dojoType='dijit.form.Select'"
					+">"
						+"<option value='exactly'>${name} = « Value 1» </option>"
						+"<option value='before'>${name} is prior to « Value 1» </option>"
						+"<option value='after'>${name} is after « Value 1» </option>"
						// +"<option value='plusMinusAbsoluteValue'>${name} = « Value 1»  &plusmn; « Value 2» </option>"
						+"<option value='fromTo'>${name} lies between « Value 1»  and « Value 2» </option>"
					+"</select>"
				+"</td>"
			+"</tr>"
			+"<tr>"
				+"<td class='textRight' width='30%'>Value 2: </td>"
				+"<td width='70%'>"
					+'<div class="RS_VTE_date" dojoAttachPoint="value2_dateBoxNode"></div>'
					+'&nbsp;'
					+'<div class="RS_VTE_time" dojoAttachPoint="value2_timeBoxNode"></div>'
				+"</td>"
			+"</tr>"
		);
		
		// generate the template string
		this.generateTemplateString();
		
	} // end of method postMixInProperties
	,
	postCreate : function () {
		this.inherited(arguments);	
		
		{// prepare the value1 for retrieval
			var value1=new Date(this.value1);
			
			this.dateBox1 = new dijit.form.DateTextBox({
				'value' : value1,
				style : 'width:100%;',
				constraints : {datePattern: this.dateFormat},
				intermediateChanges : true
			}).placeAt(this.value1_dateBoxNode);
			dojo.connect(this.dateBox1,'onChange',this,this.values_changed);
			
			// remove value if only the time search is required
			if ( value1 <  new Date('1970-01-02') ) {	this.dateBox1.attr('value',''); }
			
			//create the widget for the time editor
			this.timeBox1 = new dijit.form.TimeTextBox({
				'value' : value1,
				style : 'width:100%;',
				constraints : {timePattern: this.timeFormat},
				intermediateChanges : true
			}).placeAt(this.value1_timeBoxNode);
			dojo.connect(this.timeBox1,'onChange',this,this.values_changed);
			
			// hide not required input boxes
			if(!this.showDate) dojo.style(this.value1_dateBoxNode,'display','none');
			if(!this.showTime) dojo.style(this.value1_timeBoxNode,'display','none');
			
			// set required attribute
			if(this.showDate) this.dateBox1.attr('required',true);
			if(this.showTime) this.timeBox1.attr('required',true);

		}
		
		{// prepare the value2 for retrieval
			var value2=new Date(this.value2);
					
			this.dateBox2 = new dijit.form.DateTextBox({
				'value' : value2,
				style : 'width:100%;',
				constraints : {datePattern: this.dateFormat},
				intermediateChanges : true
			}).placeAt(this.value2_dateBoxNode);
			dojo.connect(this.dateBox2,'onChange',this,this.values_changed);
			
			// remove value if only the time search is required
			if ( value2 <  new Date('1970-01-02') ) {	this.dateBox2.attr('value',''); }
			
			//create the widget for the time editor
			this.timeBox2 = new dijit.form.TimeTextBox({
				'value' : value2,
				style : 'width:100%;',
				constraints : {timePattern: this.timeFormat},
				intermediateChanges : true
			}).placeAt(this.value2_timeBoxNode);
			dojo.connect(this.timeBox2,'onChange',this,this.values_changed);
			
			// hide not required input boxes
			if(!this.showDate) dojo.style(this.value2_dateBoxNode,'display','none');
			if(!this.showTime) dojo.style(this.value2_timeBoxNode,'display','none');

			// set required attribute
			if(this.showDate) this.dateBox2.attr('required',true);
			if(this.showTime) this.timeBox2.attr('required',true);

		}
		
		switch (this.searchMode){
			case 'fromTo': { break;}
			case 'plusMinusAbsoluteValue': { break;}
			default: { 
				this.dateBox2.attr('disabled',true);
				this.timeBox2.attr('disabled',true);
			}
		} // end switch searchMode
		
	} // end of method postCreate
	
});
*/
