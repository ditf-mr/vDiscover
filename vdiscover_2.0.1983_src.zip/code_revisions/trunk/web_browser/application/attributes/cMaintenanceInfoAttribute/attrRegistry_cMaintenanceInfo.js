﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

application.attributeKinds.register({kind: "cMaintenanceInfoAttribute", 
	defaultConfiguration : { 
		cardinality: 1, 
		
		unit:'',
		
		svFormatActivated: false,
		svHtmlBefore: '',
		svHtmlBetween: '',
		svHtmlAfter: '',
		
		dateFormat: '',		/* >>text<< cMaintenanceInfoAttribute */
		timeFormat: '',		/* >>text<< cMaintenanceInfoAttribute */
		infoKind: '',		/* >>char<< cMaintenanceInfoAttribute */
	}
	,
	defaultRetrievalValues:['searchMode','value1','value2']
	,
	widgetClass: 'application.widgets.cMaintenanceInfoAttribute'
	,
	configurationWidgetClass : 'application.widgets.configureAttributes.cMaintenanceInfoAttribute'
	,
	fixedReadOnly : true
	,
	fixedCardinality : true
	,
	getParsedQuery: function(item,rqWidget) {
		
		// extract date and time from store
		// first value
		var dateTimeString1 = rqWidget.attributeStore.getValue(item,'value1');
		if ( dateTimeString1 ){
			var dateTime1 = dojo.date.stamp.fromISOString(dateTimeString1.replace(' ',"T"));
			
			if (rqWidget.attributeStore.getValue(item,'showDate') && rqWidget.attributeStore.getValue(item,'showTime')){
				var formatedDate1 = dojo.date.locale.format(dateTime1,{
																datePattern:rqWidget.attributeStore.getValue(item,'dateFormat'),
																timePattern:rqWidget.attributeStore.getValue(item,'timeFormat')
															});
			} else if (rqWidget.attributeStore.getValue(item,'showDate')){
				var formatedDate1 = dojo.date.locale.format(dateTime1,{
																datePattern:rqWidget.attributeStore.getValue(item,'dateFormat'),
																selector: 'date'
															});				
			} else { // rqWidget.attributeStore.getValue(item,'showTime')
				var formatedDate1 = dojo.date.locale.format(dateTime1,{
																timePattern:rqWidget.attributeStore.getValue(item,'timeFormat'),
																selector: 'time'
															});			
			}
		}
		// second value
		var dateTimeString2 = rqWidget.attributeStore.getValue(item,'value2');
		if ( dateTimeString2 ){
			var dateTime2 = dojo.date.stamp.fromISOString(dateTimeString2.replace(' ',"T"));
			if (rqWidget.attributeStore.getValue(item,'showDate') && rqWidget.attributeStore.getValue(item,'showTime')){
				var formatedDate2 = dojo.date.locale.format(dateTime2,{
																datePattern:rqWidget.attributeStore.getValue(item,'dateFormat'),
																timePattern:rqWidget.attributeStore.getValue(item,'timeFormat')
															});
			} else if (rqWidget.attributeStore.getValue(item,'showDate')){
				var formatedDate2 = dojo.date.locale.format(dateTime2,{
																datePattern:rqWidget.attributeStore.getValue(item,'dateFormat'),
																selector: 'date'
															});				
			} else { // rqWidget.attributeStore.getValue(item,'showTime')
				var formatedDate2 = dojo.date.locale.format(dateTime2,{
																timePattern:rqWidget.attributeStore.getValue(item,'timeFormat'),
																selector: 'time'
															});			
			}		}
		
		switch ( rqWidget.attributeStore.getValue(item,'searchMode') ) {
			case 'fromTo': {
				if (dateTime1&&rqWidget.attributeStore.getValue(item,'value2')){
					//TG: Old version without T() Calls for reference:
					//return rqWidget.attributeStore.getValue(item,'name')+" lies between \""
					//		+formatedDate1+"\" and \""
					//		+formatedDate2+"\"";
					return T('attrRegistry_cMaintenanceInfo.js/LiesBetwAnd_TXT', 
								'$[0] lies between \"$[1]\" and \"$[2]\"', 
								[rqWidget.attributeStore.getValue(item,'name'), formatedDate1, formatedDate2]
							);		
				} 
				break;
			}
			case 'exactly': {
				if (dateTime1){
					return rqWidget.attributeStore.getValue(item,'name')+' ' + T('FUT_is','is') + ' '+formatedDate1;
				} 
				break;
			}
			case 'before': {
				if (dateTime1){
					return rqWidget.attributeStore.getValue(item,'name')+' ' + T('attrRegistry_cMaintenanceInfo.js/IsPriorTo_TXT','is prior to') +' \"'+formatedDate1+'\"';
				} 
				break;
			}
			case 'after': {
				if (dateTime1){
					return rqWidget.attributeStore.getValue(item,'name')+' ' + T('attrRegistry_cMaintenanceInfo.js/IsAfter_TXT','is after') + ' \"'+formatedDate1+'\"';
				} 
				break;
			}
			default : { //'plusMinusAbsoluteValue'
				if (dateTime1&&rqWidget.attributeStore.getValue(item,'value2')){
					return rqWidget.attributeStore.getValue(item,'name')+" " + T('FUT_is','is') + "  "
							+formatedDate1+" \261 " // plus-minus
							+formatedDate2;
				} 
				break;
			}				
		}
		
		return '';
	} // end of method getParsedQuery
	,
	'useValueTupleAsExpressionInput'	: false
	,
	'expressionsPermitted'				: false
	,

});
