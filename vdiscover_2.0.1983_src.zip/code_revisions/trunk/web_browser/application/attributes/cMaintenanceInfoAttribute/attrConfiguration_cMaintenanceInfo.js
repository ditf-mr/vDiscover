﻿dojo.declare(	'application.widgets.configureSpecialAttribute.cMaintenanceInfoAttribute',
				[application.widgets.configureAttribute.genericConfigurationWidget],{

	'infoKind_Creation_changed': function (e) {
		if (this.infoKind_Creation_rB.attr('checked')) {
			this.infoKind = 'C';
			this.propertyHasChanged('infoKind');
		}
	} // end-of-function infoKind_Creation_changed
	,
	'infoKind_Modification_changed': function (e) {
		if (this.infoKind_Modification_rB.attr('checked')) {
			this.infoKind = 'M';
			this.propertyHasChanged('infoKind');
		}
	} // end-of-function infoKind_Modification_changed
	,
	'dateFormat_changed' : function (e) {
		this.dateFormat = this.dateFormat_tB.attr('value');
		this.propertyHasChanged('dateFormat');
	} // end of method dateFormat_changed
	,
	'timeFormat_changed' : function (e) {
		this.timeFormat = this.timeFormat_tB.attr('value');
		this.propertyHasChanged('timeFormat');
	} // end of method dateFormat_changed
	,
	'postMixInProperties': function() {
		this.inherited(arguments);
		
		// expand the template string
		this.addTemplateSection(""

			+"<tr>"
				+"<td class='textRight'>" + T('attrConfiguration_cMaintenanceInfo.js/InfoKind_TXT','Information kind:') + "</td>"
				+"<td>"
					+"<label>"
						+"<input type='radio' dojoType='dijit.form.RadioButton' "
							+"name='application.widgets.configureAttributes.cMaintenanceInfoAttribute.show?' "
							+"dojoAttachPoint='infoKind_Creation_rB' "
							+"dojoAttachEvent='onChange:infoKind_Creation_changed,onFocus:showEditHints' "
							+"value='true' />"
						+ T('attrConfiguration_cMaintenanceInfo.js/CrDateAndCrtor_LBL','Creation date and creator')
					+"</label>"
					+"<br />"
					+"<label>"
						+"<input type='radio' dojoType='dijit.form.RadioButton' "
							+"name='application.widgets.configureAttributes.cMaintenanceInfoAttribute.show?' "
							+"dojoAttachPoint='infoKind_Modification_rB' "
							+"dojoAttachEvent='onChange:infoKind_Modification_changed,onFocus:showEditHints' "
							+"value='true' />"
						+ T('attrConfiguration_cMaintenanceInfo.js/DateLastModAndCrtor_LBL','Date of last modification and editor')
					+"</label>"
				+"</td>"
			+"</tr>"

			+"<tr>"
				+"<td class='textRight'>" + T('attrConfiguration_cMaintenanceInfo.js/DatePtrn_LBL','Date pattern:') + "</td>"
				+"<td>"
					+"<input type='text' style='width:100%' "
						+"value='${dateFormat}' "
						+"dojoAttachPoint='dateFormat_tB' "
						+"dojoAttachEvent='onChange:dateFormat_changed,onFocus:showDateTimeEditHints' "
						+"dojoType='dijit.form.TextBox' "
						+"trim='true' "
						+"/>"
				+"</td>"
			+"</tr>"
			
			+"<tr>"
				+"<td class='textRight'>" + T('attrConfiguration_cMaintenanceInfo.js/TimePtrn_LBL','Time pattern:') + "</td>"
				+"<td>"
					+"<input type='text' style='width:100%' "
						+"value='${timeFormat}' "
						+"dojoAttachPoint='timeFormat_tB' "
						+"dojoAttachEvent='onChange:timeFormat_changed,onFocus:showDateTimeEditHints' "
						+"dojoType='dijit.form.TextBox' "
						+"trim='true' "
						+"/>"
				+"</td>"
			+"</tr>"
			
		);
		
		//localise the necessary variables
		this.locateProperties(['infoKind', 'timeFormat', 'dateFormat']);
		
		// generate the template string
		this.generateTemplateString();

	} // end of method postMixInProperties
	,
	'postCreate' : function() {
		this.inherited(arguments);

		switch (this.infoKind) {
			case "C":
				this.infoKind_Creation_rB.attr('checked',true);
				break;
			case "M":
			default:
				this.infoKind_Modification_rB.attr('checked',true);
		} // end switch
		
		this.infoKind_Creation_rB		.attr('disabled', this.isInherited);
		this.infoKind_Modification_rB	.attr('disabled', this.isInherited);
		this.dateFormat_tB				.attr('disabled', this.isInherited);
		this.timeFormat_tB				.attr('disabled', this.isInherited);
		
	} // end of method postCreate
});

