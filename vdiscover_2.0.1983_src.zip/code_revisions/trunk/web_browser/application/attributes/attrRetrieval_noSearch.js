/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// the following generic class is for attribute value retrieval

dojo.declare('application.widgets.retrieveAttributes.noSearch',[application.widgets.retrieveAttributes.genericAttribute],{
	postMixInProperties : function() {
		// If you provide a postMixInProperties method for your widget, 
		// it will be invoked before rendering occurs, and before 
		// any dom nodes are created. If you need to add or change the 
		// instance's properties before the widget is rendered 
		// - this is the place to do it.
		this.inherited(arguments);

		//localise the necessary variables
		this.locateProperties(['name']);
		
		this.title = T('attrRetrieval_noSearch.js/NoSearchDefined_HTM','There is no Search defined for « $[0]» ',[this.name]);
		// expand the template string
		this.addTemplateSection("");
		
		// generate the template string
		this.generateTemplateString();
		
	} // end of method postMixInProperties
});

