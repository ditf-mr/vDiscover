/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// the following widget provides general functionality for editing individual value tuples
dojo.declare("application.widgets.valueTupleEditor_generic",[application.widgets.editStdValTuple_delWrapper],{
	
	// general settings
	'widgetsInTemplate' : true,
	'status' 			: '',
	
	// variables that need to be set
	'attrWidget'		: null,
	'valueTuple' 		: null,
	'attrConfig'		: null,
		
	'postMixInProperties' : function() {
	
		this.status = 'untouched';
		
		// test if everything necessary was passed on initialising
		if(typeof(this.attrWidget)		!='object' ) 	throw ('Cannot initialise application.widgets.valueTupleEditor_generic without attrWidget. Aborting.');
		if(typeof(this.valueTuple)		!='object' ) 		throw ('Cannot initialise application.widgets.valueTupleEditor_generic without valueTuple. Aborting.');
		if(typeof(this.valueTupleUUID)	!='string' ) 	throw ('Cannot initialise application.widgets.valueTupleEditor_generic without valueTupleUUID. Aborting.');

		// get the attribute configuration
		this.config = this.attrWidget.config;
				
		this.buildTemplateContainer();
				
		this.inherited(arguments);
	} // end of method postMixInProperties
	,
	'buildTemplateContainer' : function () {
	
		// this needs to be overwritten in sub classes
		this.templateContainer = '<div class="small" style="max-height:8cm;overflow:auto;"><p>application.widgets.valueTupleEditor_generic</p><pre class="small">'+dojo.toJson({
				'attrConfig':			this.config,
				'valueTuple':			this.valueTuple,
				'this.attrWidgetId':	this.attrWidgetId,
				'this.valueTupleUUID':	this.valueTupleUUID,
				'tupleWidgetId':		this.tupleWidgetId
			},true)+'</pre></div>';
	
	} // end of method buildTemplateString
	,
	'notifyAttributeOfChangedValue' : function () {
		// overwrite this method in sub classes!
		alert ('Called '+this.declaredClass+'::notifyAttributeOfChangedValue -- this method needs to be implemented!');
	} // end of method notifyAttributeOfChangedValue
	,
	'set_deleted' : function () {
		this.status = 'deleted';	
	} // end of method set_deleted
	,
	'setValue' : function (newValue) {
		// overwrite this method in sub classes!
		alert ('Called '+this.declaredClass+'::setValue -- this method needs to be implemented!');
	} // end of method setValue
	,
	'getValueTuple' : function () {
		return this.valueTuple;
	} // end of method getValueTuple
	,
	'isValid' : function () {
		// overwrite this method in sub classes!
		alert(''
			+this.declaredClass
			+' :: isValid called.\n'
			+'This method needs to be implemented!'
		);
		return false;
	} // end of method isValid
});

