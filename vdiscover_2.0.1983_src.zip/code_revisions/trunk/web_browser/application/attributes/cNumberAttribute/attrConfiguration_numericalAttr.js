﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare(
	'application.widgets.configureSpecialAttribute.numericalAttribute',
	[application.widgets.configureAttribute.genericConfigurationWidget],
	{
'setConstraints' : function () {
	var constraints = {'pattern': this.format};

	this.minValue_nTB.attr(		'constraints', constraints);
	this.maxValue_nTB.attr(		'constraints', constraints);
	
		}, // end-of-method setConstraints
		
'format_changed' : function(e) {
	this.propertyHasChanged('format',this.format_tB.attr('value'));
	this.setConstraints();
		}, // end-of-method format_changed
		
'minValue_changed' : function(e) {
	var v = this.minValue_nTB.attr('value');
	if (isNaN(v)) v='';
	this.propertyHasChanged('minValue', v);
	this.setConstraints();
		}, // end-of-method format_changed
		
'maxValue_changed' : function(e) {
	var v = this.maxValue_nTB.attr('value');
	if (isNaN(v)) v='';
	this.propertyHasChanged('maxValue', v);
	this.setConstraints();
		}, // end-of-method format_changed
		
'units_changed' : function(e) {
	var 	u 		= this.units_tB.attr('value').split('\n'),
			units 	= []; // array with cleaned units
	dojo.forEach(u,function(unit) {
		// trim the unit
		var uCleaned=unit.replace(/(\s)+/g,''); // strip all white spaces
		if (uCleaned) units.push(uCleaned);
	},this);
	this.propertyHasChanged('unitsAsString', units.join('\n'));
		}, // end-of-method format_changed
	
'postMixInProperties': function() {
	this.inherited(arguments);
	
	// expand the template string 
	this.addTemplateSection(""
		+"<tr>"
			+"<td class='textRight' style='vertical-align:top;'>" + T('FUT_Unit','Unit') + ":</td>"
			+"<td>"
				+"<textarea dojoType='dijit.form.Textarea' "
					+"class='fullWidth' "
					+"dojoAttachPoint='units_tB' "
					+"selectOnClick='true' "
					+"dojoAttachEvent='onFocus:showEditHints'>"
					+"${unitsAsString}"
				+"</textarea>"
				+"<p class='small'>" + T('attrConf_numAttr.js/InCaseChooseUnit_TXT', 'In case that you want to permit the user to choose a unit, enter multiple units &ndash; each in a new line. The first one needs to be the default unit.') + "</p>"
			+"</td>"
		+"</tr>"
		
		+"<tr>"
			+"<td class='textRight'>" + T('attrConf_numAttr.js/FormatDef_HTM','Format definition<br/>(number pattern):') + "</td>"
			+"<td>"
				+"<input type='text' class='fullWidth' "
					+"value='${format}' "
					+"dojoAttachEvent='onFocus:showNumberEditHints' "
					+"dojoAttachPoint='format_tB' "
					+"dojoType='dijit.form.TextBox' "
					+"trim='true' "
					+"/>"
			+"</td>"
		+"</tr>"
		
		+"<tr> "
			+"<td class='textRight'>" + T('attrConf_numAttr.js/MinValOpt_HTM','Minimum value<br/>(optional):') + "</td>"
			+"<td>"
				+"<input dojoType='dijit.form.NumberTextBox' "
					+"value='${minValue}' class='fullWidth' "
					+"selectOnClick='true' "
					+"dojoAttachPoint='minValue_nTB' "
					+"dojoAttachEvent='onFocus:showEditHints' "
					+"/>"
			+"</td>"
		+"</tr>"
		
		+"<tr>"
			+"<td class='textRight'>" + T('attrConf_numAttr.js/MaxValOpt_HTM','Maximum value<br/>(optional):') + "</td>"
			+"<td>"
				+"<input dojoType='dijit.form.NumberTextBox' "
					+"value='${maxValue}' class='fullWidth' "
					+"selectOnClick='true' "
					+"dojoAttachPoint='maxValue_nTB' "
					+"dojoAttachEvent='onFocus:showEditHints' "
					+"/>"
			+"</td>"
		+"</tr>"
		
	);
	
	//localise the necessary variables
	this.locateProperties([
			'format', 
			'unitsAsString',
			'minValue','maxValue', 
			// 'parentDefaultUnit' // not implemented, yet
		]);
	
	// generate the template string
	// this.generateTemplateString();
	
		}, // end-of-method postMixInProperties
	
'postCreate' : function() {
	this.inherited(arguments);

	this.setConstraints();
	
	this.units_tB		.attr('disabled', this.isInherited);
	this.format_tB		.attr('disabled', this.isInherited);
	this.minValue_nTB	.attr('disabled', this.isInherited);
	this.maxValue_nTB	.attr('disabled', this.isInherited);
	
	if(!this.isInherited) {
		this.connect ( this.units_tB, 'onChange', 'units_changed');
		this.connect ( this.format_tB, 'onChange', 'format_changed');
		this.connect ( this.minValue_nTB, 'onChange', 'minValue_changed');
		this.connect ( this.maxValue_nTB, 'onChange', 'maxValue_changed');
			}
		} // end-of-method postCreate
	}
); // end-of-declaration
