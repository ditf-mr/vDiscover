﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare( 	'application.widgets.valueTupleEditor_number', [application.widgets.valueTupleEditor_generic], {
	'numberBox' : null // dijit.form.NumberTextBox
	,
	'isConstant' : false,
	
	'constructor' : function () {
	
		this.isConstant = false;
	
	} // end of method constructor
	,
	'buildTemplateContainer' : function() {
		var units=this.config.unitsAsString.split('\n'),
			unit=units[0];
		
		if(units.length>1) {
			unit=""
				+"<select "
				+"dojoType='dijit.form.ComboBox' "
				+"dojoAttachPoint='unitSelector_widget' "
				+"class='fullWidth' "
				+"autoComplete='true' "
				+"selectOnClick='true' "
				+"value='"+units[0]+"' "
				+">"
				+"<option>"+units.join("</option><option>")+"</option>"
				+"</select>"
				;
		} // end-if
		
		// the outer template and that for the number, as well
		this.templateContainer = ''
			+'<table class="cNumberAttribute_VTE_outer compact">'
				+'<tr>'
					+'<td class="cNumberAttribute_VTE_cV">'
						+'<div dojoAttachPoint="currentValue_domNode"></div>'
					+'</td>'
					+'<td class="cNumberAttribute_VTE_unit '
						+(this.attrWidget.isEmbedded?'embeddedAttr ':'')
					+'">'
						+unit
					+'</td>'
					+(this.attrWidget.formsPartOfAnEquationSystem()?''
						+'<td class="RS_cNumberAttribute_VTE_constant">'
							+'<div dojoType="dijit.form.CheckBox" dojoAttachPoint="const_CB" checked="'+this.isConstant+'" dojoAttachEvent="onChange:_isConstantChanged"></div>'
							+'<span dojoAttachEvent="onclick:_toggle_const_CB" style="cursor:pointer;">&nbsp;' + T('FUT_const.','const.') + '</span>'
						+'</td>'
					:'')
				+'</tr>'
			+'</table>'
			;
	}, // end-of-method postMixInProperties
	
	'postCreate' : function () {
		this.inherited(arguments);
		var formatOptions = {};
		if (this.config.formatDisplay){ // number format
			formatOptions.pattern = this.config.formatDisplay;
		}
		var constraints = {	pattern: this.config.format },
		title = '';
		if (this.config.minValue!=null) {
			constraints.min=this.config.minValue;
			title += '['+dojo.number.format(this.config.minValue, formatOptions);
		} // end-if			
		if (this.config.maxValue!=null) {
			constraints.max=this.config.maxValue;
			title += ((title.length)?' 	… ':'')+dojo.number.format(this.config.maxValue, formatOptions)+']';
		} 
		else {
			title += ((title.length)?' 	… ':'');
		} // end-if
		this.numberBox = new dijit.form.NumberTextBox({
			'title'					: title,
			'maxLength'				: ((this.config.format.length === 0)? 10: this.config.format.length),
			'required'				: (this.config.mustBeSet==true),
			'class'					: 'cNumberAttribute_VTE_cV_tB code', // RS_VTE_number_number',
			'value'					: this.valueTuple.value_number,
			'style'					: 'width:'+((this.config.format.length<30)? ((this.config.format.length === 0)? 7:this.config.format.length*0.7): 24)+'em;',
			'intermediateChanges'	: true,
			// 'intermediateChanges' : true, // this must stay deactivated!
			'selectOnClick': true
		}).placeAt(this.currentValue_domNode);
		this.numberBox.attr('constraints', constraints);
		this._supportingWidgets.push(this.numberBox);
		
		// set the default value, if necessary
		if (!this.numberBox.attr('value').length && this.config.defaultValue && this.config.defaultValue.length) 
		this.numberBox.attr('value', this.config.defaultValue);						
		
		// set the unit, if necessary
		if(this.unitSelector_widget) {
			//		no unit yet? -> set the first unit as default value
			this.unitSelector_widget.attr('value', (this.valueTuple.unit?this.valueTuple.unit:this.config.unitsAsString.split('\n')[0]));
		} // end-if there is a unit selector				
		
		this.connect(this.numberBox,'onChange',this.notifyAttributeOfChangedValue);
		if (this.unitSelector_widget) 
		this.connect(this.unitSelector_widget, 'onChange', this.notifyAttributeOfChangedValue);
	}, // end-of-method postCreate
	
	'getValueTuple' : function () {
		// This method returns the current value tuple without having it validated.
		// unit
		var units=this.config.unitsAsString.split('\n'),
		unit=units[0];
		if(this.unitSelector_widget) {
			unit = this.unitSelector_widget.attr('value');
			// if the entered unit is not valid, choose automatically the first given unit
			if(dojo.indexOf(units,unit)==-1) {
				unit=units[0];
				this.unitSelector_widget.attr('value', unit);
			} // end if
		} // end if
		
		return {
			'value_number'		: 	this.numberBox.attr('value'),
			'AV_UUID' 			: 	this.valueTuple.AV_UUID,
			'UUID'				:	this.valueTuple.UUID,
			'unit'				:	unit,
			'positionOfValue' 	: 	this.valueTuple.positionOfValue
		};
	}, // end of method getValueTuple
	
	'setValueTuple' : function (vT) {
		// this method updates the value tuple and sets the input boxes, accordingly
		
		this.numberBox.attr('value', vT.value_number);
		
		if(this.unitSelector_widget) {
			this.unitSelector_widget.attr('value', vT.unit);
		} // end if		
	
		this.notifyAttributeOfChangedValue();
	} // end of method setValueTuple
	,
	'notifyAttributeOfChangedValue' : function () {
		// this method informs the connected attribute about the changed value tuple
		if(this.isValid()) 
			this.attrWidget.valueTupleHasChanged(this.valueTupleUUID, this.getValueTuple() );
	}, // end-of-method notifyAttributeOfChangedValue
	
	'setValue' : function (newValue) {
		this.numberBox.attr('value',newValue);
	} // end-of-method setValue
	,
	'setEstimatedValue' : function (estimatedValue) {
		this.setValue(estimatedValue);
		this.notifyAttributeOfChangedValue();
	} // end-of-method setValue
	,
	'isValid' : function () {
		// var isValid = this.numberBox.isValid();
		var isValid = true,
			v		= this.numberBox.attr('value');
		
		// Constraints that need to be met
		
		// * v >= minValue
		// * v <= maxValue
		// if mustBeSet -> v is not empty
		
		if (this.config.minValue!=null) isValid = isValid && (v >= this.config.minValue);
		if (this.config.maxValue!=null) isValid = isValid && (v <= this.config.maxValue);
		
		if(this.config.mustBeSet) 	isValid = isValid && !this.attrWidget.tuple_isEmpty(this.getValueTuple() );	
		
		return isValid;
	}, // end-of-method isValid
	
	'destroy' : function () {
		this.numberBox.destroyRecursive();
		if(this.unitSelector_widget) 	this.unitSelector_widget.destroyRecursive();
		this.inherited(arguments);
	} // end-of-method destroy
	,
	'_toggle_const_CB' : function (e) {
		dojo.stopEvent(e);
		var c = this.const_CB.attr('checked');
		this.const_CB.attr('checked', !c);
	} // end of method _toggle_const_CB
	,
	'isConstantClasses' : 'RS_attrIsConstant'
	,
	'setConstant' : function(c) {
		if(this.const_CB) {
			this.const_CB.attr('checked', c==true);
		} // end if
	} // end of method setConstant
	,
	'_isConstantChanged' : function (e) {

		this.isConstant = this.const_CB.attr('checked');
		dojo.toggleClass(this.numberBox.textbox.parentNode, this.isConstantClasses, this.isConstant);
		
	} // end of method _isConstantChanged
}); // end-of-declaration
