﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare( 'application.widgets.cNumberAttribute', [application.widgets.standardAttribute], {
	'_emptyValueTuple': { 
		'value_number'	: '', 
		'unit'			: '',
	}
	,	
	'hasEstimationFunctionality' : true
	,
	'valueTupleEditor_name': 'application.widgets.valueTupleEditor_number',

	'tuple_isEmpty' : function (tuple) {
		var isEmpty = false;
		if(		(!tuple)
			||	(!(tuple.value_number.toString().length))
			||	isNaN(tuple.value_number) 
			) isEmpty=true;
		return isEmpty;
			}, // end-of-method tuple_isEmpty

	'htmlFormatValueTuple_readMode' : function (valueTuple) {
		var formatOptions = {};
		if (this.config.formatDisplay){ // number format
			formatOptions.pattern = this.config.formatDisplay;
		}
		var units 		= this.config.unitsAsString.split('\n'),
			first_unit 	= units[0],
			unit 		= valueTuple.unit?valueTuple.unit:first_unit;
		return ''
			+'<code>'
				+dojo.number.format(valueTuple.value_number, formatOptions)
			+'</code>'
			+'&nbsp;'
			+unit
			;
			}, // end-of-method htmlFormatValueTuple_ReadMode
		
			// BEGIN equation solver-specific code ----------
			
	'getCurrentValueTupleEditor' : function() {
		var id_vTE=Object.keys(this.valueTupleEditors);
		var n_vTE=id_vTE.length;
		return this.valueTupleEditors[id_vTE[n_vTE-1]];
			}, // end-of-method getCurrentValueTupleEditor
			
	'getCurrentUnit' : function() {
		var unit			= '',
			i				= '', 
			changedTuples 	= this.getChangedTupleSet();
		// are there any changed value tuples?
		if(Object.keys(changedTuples).length) {
			// iterate over the changed value tuples and take the unit of the last one
			for (i in changedTuples) {
				if (changedTuples[i].status!='deleted') unit=changedTuples[i].unit;
			} // end for .. in
				} 
				else {
			// take the first available unit
			unit = this.config.units[0];
				} // end-if
			
				if (typeof unit == 'undefined') 
					unit = '';
				return unit;
			}, // end-of-method getCurrentUnit

	'getFormat' : function () {
		return this.config.format;
			}, // end-of-method getFormat
			
	'getMinValue' : function () {
		return this.config.minValue;
			}, // end-of-method minValue
			
	'getMaxValue' : function () {
		return this.config.maxValue;
			}, // end-of-method maxValue
		
	'getCurrentValue' : function() {
		var value='';
		// iterate over this.getChangedTupleSet()
		var i, changedTuples = this.getChangedTupleSet();
		for (i in changedTuples) {
					if (changedTuples[i].status != 'deleted') 
						value = changedTuples[i].value_number;
		} // end for .. in
		return value;
	}, // end-of-method getCurrentValue

	'setCurrentValue' : function (newValue) {
		// iterate over all value tuple editors and insert the newValue into the first one that is not deleted
		var vT_UUID;
		for (vT_UUID in this.valueTupleEditors) {
			if (this.valueTupleEditors[vT_UUID].status!='deleted') {
				this.valueTupleEditors[vT_UUID].setValue(newValue); 
				break;
			} 
		} // end-of-for
	}, // end-of-method setCurrentValue
		
	'setEstimatedValue' : function (newValue) {
		// iterate over all value tuple editors and insert the newValue into the first one that is not deleted
		for (var vT_UUID in this.valueTupleEditors) {
			if (this.valueTupleEditors[vT_UUID].status != 'deleted') {
				this.valueTupleEditors[vT_UUID].setEstimatedValue(newValue); 
				break;
			}
		} // end-of-for
	}, // end-of-method setCurrentValue
		
	'acceptEstimatedValue' : function () {
		// iterate over all value tuple editors and tell them to acept the estimated value
		for (var vT_UUID in this.valueTupleEditors) {
			if (this.valueTupleEditors[vT_UUID].status != 'deleted') {
				this.valueTupleEditors[vT_UUID].acceptEstimatedValue(); 
				break;
			}
		} // end-of-for
	}, // end-of-method acceptEstimatedValue
			
	// END equation solver-specific code ----------

	'highlight' : function (highlightType, currentAttributeId) {
		var highlightClass='RS_attribute_highlight_';
		switch(highlightType) {
					case 'determined':	
						highlightClass += 'dependent';
						break;		
					case 'underdetermined':
						highlightClass += 'dependent_underdetermined';
						break;		
					case 'overdetermined':	
						highlightClass += 'dependent_overdetermined';
						break;		
				} // end-switch
		// if(highlightClass=='RS_attribute_highlight_dependent') {
			// var vT_editor = this.getCurrentValueTupleEditor();
			// vT_editor.showEstimateButton();
				// } // end-if
				if ((this.getCurrentValue() == '') && (highlightClass == 'RS_attribute_highlight_dependent')) {
			highlightClass='RS_attribute_highlight_iAmDependent';
			// var vT_editor = this.getCurrentValueTupleEditor();
			// vT_editor.showEstimateButton();
			// console.log(this);
				}
				dojo.toggleClass(this.domNode,highlightClass,true);
				// if (this.id == currentAttributeId) 
					// dojo.toggleClass(this.domNode, 'RS_attribute_currentAttribute', true);
			}, // end-of-method highlight

	'displayNormal' : function () {
		dojo.toggleClass(this.domNode,'RS_attribute_highlight_dependent',false);
		dojo.toggleClass(this.domNode,'RS_attribute_highlight_dependent_underdetermined',false);
		dojo.toggleClass(this.domNode,'RS_attribute_highlight_dependent_overdetermined',false);
		//dojo.toggleClass(this.domNode,'RS_attribute_currentAttribute',false);
		dojo.toggleClass(this.domNode,'RS_attribute_highlight_iAmDependent',false);
		// var vT_editor = this.getCurrentValueTupleEditor();
		// if(vT_editor) vT_editor.hideEstimateButton();
			}, // end-of-method displayNormal
			
	'estimateDependencies' : function () {
		this.viewWidget.estimateDependencies(this.A_UUID);
	}, // end-of-method estimateDependencies
			
	'postMixInProperties' : function () {
		this.inherited(arguments);
		// make the number attribute's value available if cardinality is 1
		if(this.config.cardinality==1) this.currentValueAccessible=true;
	} // end-of-method postMixInProperties
	,
	'setConstant' : function(c) {
		var cVTE = this.getCurrentValueTupleEditor();
		cVTE.setConstant(c);
	} // end of method setConstant
	,
	'isConstant' : function () {
		var cVTE = this.getCurrentValueTupleEditor();
		return cVTE.isConstant;
	} // end of method isConstant
	,
	
}); // end-of-declaration
