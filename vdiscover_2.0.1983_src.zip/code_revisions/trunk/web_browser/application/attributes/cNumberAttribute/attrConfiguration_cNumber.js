﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/
	
dojo.declare(
	'application.widgets.configureSpecialAttribute.cNumberAttribute',
	[application.widgets.configureSpecialAttribute.numericalAttribute],
	{
	'setConstraints' : function () {
		this.inherited(arguments);
		
		var constraints = {'pattern': this.format};
		
		this.defaultValue_nTB.attr(	'constraints', constraints);
		this.defaultValue_nTB.validate();
	}, // end-of-method setConstraints
			
	'defaultValue_changed' : function(e) {
		var v = this.defaultValue_nTB.attr('value');
		if (isNaN(v)) v='';
		this.propertyHasChanged('defaultValue', v);
		
		dojo.style(this.parentDefaultValueMessage_node, 'display', 
			(this.parentDefaultValue && (this.defaultValue!=this.parentDefaultValue)?'block':'none'));
	}, // end-of-method defaultValue_changed
		
	'postMixInProperties': function() {
		this.inherited(arguments);
		
		//localise the necessary variables
		this.locateProperties(['defaultValue', 'parentDefaultValue']);
		
		this.parentDefaultValue_string = (this.parentDefaultValue?
			dojo.number.format(this.parentDefaultValue, {'pattern': this.format})
			: '');
		
		// expand the template string
		this.addTemplateSection(""
		
			+"<tr dojoAttachPoint='defaultValue_number_rowDOMNode'>"
				+"<td class='textRight'>" + T('attrConf_cNumber.js/DefValOpt_HTM', 'Default value<br/>(optional):') + "</td>"
				+"<td>"
					+"<input dojoType='dijit.form.NumberTextBox' "
						+"value='${defaultValue}' class='fullWidth' "
						+"dojoAttachPoint='defaultValue_nTB' "
						+"intermediateChanges='true' "
						+"dojoAttachEvent='onFocus:showEditHints' "
						+"/>"
					+"<div class='small' style='display:none;' dojoAttachPoint='parentDefaultValueMessage_node'><p>"
						+ T('attrConf_cNumber.js/InherDefVal_HTM','The inherited default value is <code>${parentDefaultValue_string}</code>&nbsp;.') + "</br>"
						+ T('attrConf_cNumber.js/ClkUseInherDefVal_LNK','Click <a dojoAttachEvent="onclick:useInheritedDefaultValue_clicked">here</a> to use the inherited default value.')
					+"</p></div>"
				+"</td>"
			+"</tr>"
		);
		// generate the template string
		this.generateTemplateString();
	}, // end of method postMixInProperties
		
	'useInheritedDefaultValue_clicked' : function (e) {
		this.defaultValue_nTB.attr('value', this.parentDefaultValue);
		dojo.stopEvent(e);
	}, // end-of-method useInheritedDefaultValue_clicked
	
	'postCreate' : function() {
		this.inherited(arguments);
		
		if(this.isInherited) {
			dojo.style(this.parentDefaultValueMessage_node, 'display', 
				(this.parentDefaultValue && (this.defaultValue!=this.parentDefaultValue)?'block':'none'));
		} // end if
		
		this.connect(this.defaultValue_nTB, 'onChange', 'defaultValue_changed');
		
	}, // end-of-method postCreate

}); // end-of-declaration
