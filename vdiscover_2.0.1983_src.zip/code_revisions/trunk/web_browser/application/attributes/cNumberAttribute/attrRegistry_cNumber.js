﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

application.attributeKinds.register({
	'kind': 'cNumberAttribute', 
	'defaultConfiguration': { 
		'format'			: '###,###.##',
		'unitsAsString'		: '',
		'minValue'			: '',
		'maxValue'			: '',
		'cardinality'		: 1, 
		'svFormatActivated'	: false,
		'svHtmlBefore'		: '',
		'svHtmlBetween'		: '',
		'svHtmlAfter'		: '',
		'defaultValue'		: ''
	},
	
	'defaultRetrievalValues': ['searchMode', 'not', 'value1', 'value2'],

	'widgetClass': 'application.widgets.cNumberAttribute',

	'configurationWidgetClass': 'application.widgets.configureAttributes.cNumberAttribute',
	
	// Analytical expression configuration -------------------------------------------
	'useValueTupleAsExpressionInput'	: true
	,
	'expressionsPermitted'				: true
	,
	'defExprValTasJSON'					: "{\n  \"value_number\" : 1.23, // req. number\n  \"unit\"         : \"\"    // opt. string\n}"
	,
	
	// CBR configuration -------------------------------------------------------------
	'supportsCBR'						: function ( attrConfigAsObj ) {
		return		true
				&&	(attrConfigAsObj.cardinality == 1)
				&&	((attrConfigAsObj.mustBeSet == "true") || (attrConfigAsObj.mustBeSet === true))
				;
	} // end of method
	,
	'similarityMethods'		: {
		'cLogarithmicMean'	: T('aR_cKVP_CBR_logMean',	'Logarithmic mean'			),
		'cCanberraMean'		: T('aR_cKVP_CBR_canbMean', 'Canberra mean'				),
		'cRelativeMean'		: T('aR_cKVP_CBR_relMean',	'Relative mean'				),
		'cEquality'			: T('aR_cKVP_CBR_eq',		'Equality'					),
	}
	,
	'adaptationMethods'		: {
		'cMeanValue'		: T('aR_cKVP_CBR_mean',		'Mean value'				),
		'cMainValue'		: T('aR_cKVP_CBR_mFV',		'Most frequent value / Mode'),
	}
	,
	
}); // end-of-register

