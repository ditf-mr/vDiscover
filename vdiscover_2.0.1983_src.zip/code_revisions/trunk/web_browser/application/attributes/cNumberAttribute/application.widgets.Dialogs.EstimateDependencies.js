/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare('application.widgets.Dialogs.EstimateDependencies_variableTable', [dijit._Widget, dijit._Templated], {
	/*constructor : function() {
		// Your constructor method will be called before the parameters are mixed into the widget, and can be used to initialize arrays, etc.
		this.inherited(arguments);
	} // end of method constructor
	,*/
	
	// this needs to be set on instantiation
	'variableStore'	: null // dojo.data.itemFileWriteStore
	,
	
	
	
	'widgetsInTemplate' : true
	,
	'buildPathToAttachPoint' : function (A_UUID, colName) {return 'cell|'+A_UUID+'|'+colName;}
	,
	'buildPathToInputBox' : function (A_UUID, colName) {return 'inputBox|'+colName+'|'+A_UUID;}
	,
	'postMixInProperties' : function() {
		// If you provide a postMixInProperties method for your widget, 
		// it will be invoked before rendering occurs, and before 
		// any dom nodes are created. If you need to add or change the 
		// instance's properties before the widget is rendered 
		// - this is the place to do it.
		
		var headerNames = [], rows = [];
		
		this.widgets 	= {};
		this.links		= [];
		
		// extract the header names
		dojo.forEach(this.columnDefs,function(colDef) {
			headerNames.push(colDef.name);
		},this);
		
		// build the rows
		this.variableStore.fetch({
			'scope'	: this,
			'sort': [{ 'attribute': 'position'/*, descending: false*/}],
			'onItem' : function (item) {
				var row = [];
				
				dojo.forEach(this.columnDefs,function(colDef) {
				
					var colName 	=  colDef.field,
						A_UUID		= this.variableStore.getValue(item,'A_UUID'),
						value 		= this.variableStore.getValue(item,colName),
						formatter	= colDef.formatter;
					
					row.push( '<td dojoAttachPoint="'+this.buildPathToAttachPoint(A_UUID, colName)+'">'+((typeof formatter=='function') ? formatter(value, item, this.variableStore) : value)+'</td>' );
					
				},this);
				
				rows.push( row.join('') );
				
			} // end of method onItem
		});
		
		this.templateString = ''
			+'<table dojoAttachPoint="domNode" class="listWithRows compact fullWidth">'
				+'<thead dojoAttachPoint="tHeadNode">' // style="display:block;width:100%;"
					+'<tr>'
						+'<th>'+headerNames.join('</th><th>')+'</th>'
					+'</tr>'
				+'</thead>'
				+'<tbody dojoAttachPoint="containerNode">' // style="overflow-y:auto;display:block;width:100%;"
					+'<tr>'+rows.join('</tr><tr>')+'</tr>'
				+'</tbody>'
			+'</table>';
		
		this.inherited(arguments);		
		
	} // end of method postMixInProperties
	,
	'createNumberInputBox' : function (item, colName) {
		// this.variableStore.fetch({
			// 'scope'	: this,
			// 'onItem' : function (item) {
				
		var A_UUID		= this.variableStore.getValue(item, 'A_UUID'		),
			format		= this.variableStore.getValue(item, 'format'		),
			minValue	= this.variableStore.getValue(item, 'minValue'		),
			maxValue	= this.variableStore.getValue(item, 'maxValue'		),
			value 		= this.variableStore.getValue(item, colName			),
			constraints = {}												 ,
			attachPoint = this[this.buildPathToAttachPoint(A_UUID, colName)];
			
		if(format)		constraints.pattern = format;
		if(minValue)	constraints.min 	= minValue;
		if(maxValue)	constraints.max 	= maxValue;
		
		this.widgets[this.buildPathToInputBox(A_UUID, colName)]=new dijit.form.NumberTextBox({
			'value'			: value,
			'constraints' 	: constraints,
			'item'			: item,
			'variableStore' : this.variableStore,
			'colName'		: colName,
			'scope'			: this,
			'selectOnClick'	: true,
			'class'			: 'code',
			'style'			: 'width:4em;',
			'onChange'		: function() {
				this.variableStore.setValue(this.item, this.colName, this.attr('value'));
			} // end of onChange
			
		}, dojo.create('DIV', {}, attachPoint, 'only'));
								
			// } // end of method onItem
		// }); // end fetch each attribute/ variable		
	} //end of method 
	,
	'columnDefs' : [
		{
			field: 	'name',
			name:	T('FUT_Name','Name'),
			// width:	'10em',
		},
		{
			field: 'varName',
			name: '<b>' + T('app.wid.Dial.EstDep.js/VarName_TXT','Variable name') + '</b>',
			// width: '10em',
			formatter: function(value, item, variableStore){						
				return '<code>'+value+'</code>';
			} // end of formatter function
		},
		{
			field: 'originalValue',
			name: T('app.wid.Dial.EstDep.js/OrigVal_TXT','Original value'),
			// width: '7.5em',
			formatter: function(value, item, variableStore){						
				var format=variableStore.getValue(item,'format');
				return (value.toString().length?'<code>'+dojo.number.format(value,{'pattern':format})+'</code>':'&mdash;');
			} // end of formatter function
		},
		{
			field: 'readOnly',
			name: T('app.wid.Dial.EstDep.js/ReadOnly_TXT','Read only?'),
			// width: '7.5em',
			formatter: function(value, item, variableStore){						
				// return '<div class="dijit dijitReset dijitInline dijitCheckBox'+(value?' dijitCheckBoxChecked dijitChecked':'')+'"></div>';
				return /*'<div class="textCenter">'+*/(value?'✔':'&ndash;')/*+'</div>'*/;
			} // end of formatter function
		},
		{
			field: 				'currentValue',
			name: 				T('app.wid.Dial.EstDep.js/CurrVal_TXT','Current value'),
			// width: 				'7.5em',
			// editable : 			'true', 
			// singleClickEdit : 	'true',
			// formatter: function(value, item, variableStore){						
				// var format		= variableStore.getValue(item, 'format'		),
					// minValue	= variableStore.getValue(item, 'minValue'	),
					// maxValue	= variableStore.getValue(item, 'maxValue'	),
					// constraints	= {'pattern':format};

				// if (typeof minValue!='undefined') constraints.min = minValue;
				// if (typeof maxValue!='undefined') constraints.max = maxValue;
				
				// return (value.toString().length?dojo.number.format(value,{'pattern':format}):'');
			// } // end of formatter function
			'createInputBox' : function (item, colName) {this.createNumberInputBox(item, colName);}
		},
		{
			'field': 'keepConstant',
			'name': T('app.wid.Dial.EstDep.js/Const_TXT','Constant?'),
			'createInputBox' : function (item, colName) {
				var A_UUID		= this.variableStore.getValue(item, 'A_UUID'		),
					// format		= this.variableStore.getValue(item, 'format'		),
					// minValue	= this.variableStore.getValue(item, 'minValue'		),
					// maxValue	= this.variableStore.getValue(item, 'maxValue'		),
					value 		= this.variableStore.getValue(item, colName			),
					// constraints = {}												 ,
					attachPoint = this[this.buildPathToAttachPoint(A_UUID, colName)];
									
				this.widgets[this.buildPathToInputBox(A_UUID, colName)]=new dijit.form.CheckBox({
					'checked'			: (value?true:false),
					// 'constraints' 	: constraints,
					'item'			: item,
					'variableStore' : this.variableStore,
					'colName'		: colName,
					'scope'			: this,
					// 'selectOnClick'	: true,
					// 'class'			: 'code',
					// 'style'			: 'width:6em;',
					'onChange'		: function() {
						this.variableStore.setValue(this.item, this.colName, this.attr('checked'));
					} // end of onChange
					
				}, dojo.create('DIV', {}, attachPoint, 'only'));
				
				dojo.create('SPAN',{'innerHTML':'const.'},attachPoint);
				
			} // end of method createInputBox
		},
		{
			field: 'estimatedValue',
			name: T('app.wid.Dial.EstDep.js/EstVal_TXT','Estimated value'),
			// width: '7.5em',
			// 'formatter': function(value, item, variableStore){						
				// var format=variableStore.getValue(item,'format');
				// return (value.toString().length?dojo.number.format(value,{'pattern':format}):'');
			// } // end of formatter function
			'createInputBox' : function (item, colName) {this.createNumberInputBox(item, colName);}
		},
		{
			field: 'unit',
			name: T('FUT_Unit','Unit'),
			// width: '7.5em',
		},
		/*{
			field: 'valueType',
			name: 'Type',
		}*/
	]	// end of grid_headerStructure
	,
	/*buildRendering : function() {
		// dijit._Templated provides an implementation of buildRendering 
		// that most times will do what you need. The template is fetched/read, 
		// nodes created and events hooked up during buildRendering. The end 
		// result is assigned to this.domNode. If you don't mixin dijit._Templated 
		// (and most OOTB dijits do) and want to handle rendering yourself 
		// (e.g. to really streamline a simple widget, or even use a different 
		// templating system) this is where you'd do it.
		this.inherited(arguments);
	} // end of method buildRendering
	,*/
	'postCreate' : function() {
		// This is typically the workhorse of a custom widget. The widget has 
		// been rendered (but note that sub-widgets in the containerNode have not!). 
		// The widget though may not be attached to the DOM yet so you shouldn't 
		// do any sizing calculations in this method.
		this.inherited(arguments);
		
		// iterate over all corresponding rows and insert the input boxes
		
		// var colNames = ['currentValue', 'estimatedValue'];
		
		dojo.forEach(this.columnDefs, function(colDef) {
			this.variableStore.fetch({
				'scope'	: this,
				'onItem' : function (item) {
					
					var colName		= colDef.field,
						createInputBox = colDef.createInputBox;//,
						// A_UUID		= this.variableStore.getValue(item, 'A_UUID'		),
						// format		= this.variableStore.getValue(item, 'format'		),
						// minValue	= this.variableStore.getValue(item, 'minValue'		),
						// maxValue	= this.variableStore.getValue(item, 'maxValue'		),
						// value 		= this.variableStore.getValue(item, colName			),
						// constraints = {}												 ,
						// attachPoint = this[this.buildPathToAttachPoint(A_UUID, colName)];
					
					if(typeof colDef.createInputBox=='function') {
					
						dojo.hitch(this, colDef.createInputBox)(item,colName);
					
					} // end if
					
					// if(format)		constraints.pattern = format;
					// if(minValue)	constraints.min 	= minValue;
					// if(maxValue)	constraints.max 	= maxValue;
					
					// this.widgets[this.buildPathToInputBox(A_UUID, colName)]=new dijit.form.NumberTextBox({
						// 'value'			: value,
						// 'constraints' 	: constraints,
						// 'item'			: item,
						// 'variableStore' : this.variableStore,
						// 'colName'		: colName,
						// 'scope'			: this,
						// 'selectOnClick'	: true,
						// 'class'			: 'code',
						// 'style'			: 'width:6em;',
						// 'onChange'		: function() {
							// this.variableStore.setValue(this.item, this.colName, this.attr('value'));
						// } // end of onChange
						
					// }, dojo.create('DIV', {}, attachPoint, 'only'));
					
				} // end of method onItem
			}); // end fetch each attribute/ variable		
		},this);
		
		this.links.push(dojo.connect(this.variableStore, 'onSet', this, 'onSet'));
		
	} // end of method postCreate
	,
	'onSet' : function(item, colName, oldValue, newValue) {
		
		// do nothing if this method was called on the wrong cols
		var colNames = ['currentValue', 'estimatedValue'];
		if(dojo.indexOf(colNames, colName)<0) return;
	
		// try to locate the input box widget
		var A_UUID = this.variableStore.getValue(item, 'A_UUID'),
			iB_path = this.buildPathToInputBox(A_UUID, colName);
		
		if (iB_path in this.widgets){
			var valInInputBox = this.widgets[iB_path].attr('value');
			
			if(valInInputBox.toString()!=newValue.toString()) // funny - in Firefox, NaN==NaN returns false
				this.widgets[iB_path].attr('value', newValue);
			
		} // end if
		
	} // end of method onSet
	,
	/*'startup' : function() {
		// If you need to be sure parsing and creation of any child widgets has 
		// completed, use startup. This is often used for layout widgets like 
		// BorderContainer. If the widget does JS sizing, then startup() should 
		// call resize(), which does the sizing.
		this.inherited(arguments);
		
		// this.resize();
	} // end of method startup
	,*/
   /*'resize' : function(sizeObj) {
		// All widgets that do JS sizing should have a method called resize(), that lays 
		// out the widget. Resize() should be called from startup() and will also be 
		// called by parent widgets like dijit.layout.ContentPane.

		console.log('--------------------');
		console.log('domNode::clientHeight', this.domNode.clientHeight);
		this.inherited(arguments);
		
		console.log('resize', arguments);
		console.log('domNode::clientHeight', this.domNode.clientHeight);
		
		// if(sizeObj) {
			// if (sizeObj.h) dojo.style(this.domNode,'height',sizeObj.h+'px');
			// if (sizeObj.w) dojo.style(this.domNode,'width',sizeObj.w+'px');
		// } // end if
		
		// set the height of tbody
		
		// var headHeight 		= this.tHeadNode.clientHeight,
			// widgetHeight 	= this.domNode.clientHeight;
		
		// console.log(widgetHeight);
		
		// dojo.style(this.containerNode,'height', (widgetHeight-headHeight).toString()+'px' );
		
		
	} // end of method resize
	,*/
	destroy : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		
		// disconnect all links
		dojo.forEach(this.links,function(l){
			dojo.disconnect(l);
		},this);
		
		// eliminate all child widgets
		for (var i in this.widgets) this.widgets[i].destroyRecursive();
		delete this.widgets;
		
		this.inherited(arguments);
	} // end of method destroy
	
});

dojo.declare('application.widgets.Dialogs.EstimateDependencies', [common.widgets.fixedSizeDialog], {
	'innerHeight'	: 2000 // overwrite these values as necessary
	,
	'innerwidth'	: 2000 // overwrite these values as necessary
	,
	'vTEditorWidget': null // e.g. application.widgets.valueTupleEditor_number
	,
	'constructor' : function() {
		// Your constructor method will be called before the parameters are mixed into the widget, and can be used to initialize arrays, etc.
		this.inherited(arguments);
		
		// some initialisations
		this.widgets 		= {};
		this.links			= [];
		
	} // end of method constructor
	,
	'postMixInProperties' : function () {
		this.inherited(arguments);
			
		this.title = T('app.wid.Dial.EstDep.js/EstDep_TIT','Estimate dependencies');
		
	} // end of method postMixInProperties
	,
	'postCreate' : function() {
		// This is typically the workhorse of a custom widget. The widget has 
		// been rendered (but note that sub-widgets in the containerNode have not!). 
		// The widget though may not be attached to the DOM yet so you shouldn't 
		// do any sizing calculations in this method.
		this.inherited(arguments);
			
		// build the main structure of the dialog
		this.widgets.borderContainer = new dijit.layout.BorderContainer({
			'style' 	: 'width:100%;height:100%;',
			'gutters'	: false
		}).placeAt(this.containerNode);
		
		// create the action bar at the bottom of the dialog
		this.widgets.actionBar = new dijit.layout.ContentPane({
			'region'	: 'bottom',
			'class'		: 'dijitDialogPaneActionBar textRight',
			'style'		: 'padding-top:1em;'
		});
		this.widgets.borderContainer.addChild(this.widgets.actionBar);

		this.widgets.OkButton = new dijit.form.Button({
			'label' 	: '<img src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/dialog-ok-apply-4.png"/> '
							+ T('app.wid.Dial.EstDep.js/AccEstVal_BTN','Accept estimated values'),
			'type'		: 'button'
		}).placeAt(this.widgets.actionBar.containerNode);

		this.links.push(dojo.connect(this.widgets.OkButton,'onClick',this,'acceptEstimatedValues'));
		
		this.widgets.CancelButton = new dijit.form.Button({
			'label' 	: '<img width="12" src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/dialog-cancel-4.png"/> '
							+T('BTN_Cancel','Cancel'),
			'type'		: 'button',
			'style'		: 'margin-right:0;'
		}).placeAt(this.widgets.actionBar.containerNode);
		
		this.links.push(dojo.connect( this.widgets.CancelButton,	'onClick', this.vTEditorWidget, 'closeEstimateDependenciesDialog'));
		this.links.push(dojo.connect( this.closeButtonNode,			'onClick', this.vTEditorWidget, 'closeEstimateDependenciesDialog'));
		
		this.DoF_domNode = dojo.create('SPAN',{
			'innerHTML'	: T('app.wid.Dial.EstDep.js/DegrOfFreedom_TXT','45 variables - 123 equations = 45 degrees of freedom'),
			'style'		: 'float:left;padding:.25ex;border-radius:.5ex;padding-left:1ex;padding-right:1ex;',
		}, this.widgets.actionBar.containerNode);
		
		// create a menu bar at the top of the dialog
		this.widgets.menuBar = new dijit.MenuBar({
			'region'	: 'top',
			'style'		: 'margin-bottom:.5ex;'
		});
		this.widgets.borderContainer.addChild(this.widgets.menuBar);
		
		this.widgets.solveMBI = new dijit.MenuBarItem({
			'label'	: T('FUT_Solve','Solve'),
		});
		this.widgets.menuBar.addChild(this.widgets.solveMBI);
		this.links.push(dojo.connect( this.widgets.solveMBI,				'onClick', this, 'solve'));
		
		this.widgets.solvewithDebugOutputMBI = new dijit.MenuBarItem({
			'label'	: T('app.wid.Dial.EstDep.js/SolveWDbgOutp_TXT','Solve with debug output')
		});
		this.widgets.menuBar.addChild(this.widgets.solvewithDebugOutputMBI);
		this.links.push(dojo.connect( this.widgets.solvewithDebugOutputMBI,	'onClick', this, 'solve_withDebugOutput'));
		
		this.widgets.resetMBI = new dijit.MenuBarItem({
			'label'	: T('app.wid.Dial.EstDep.js/ResetEquSys_TXT','Reset equation system')
		});
		this.widgets.menuBar.addChild(this.widgets.resetMBI);
		this.links.push(dojo.connect( this.widgets.resetMBI,	'onClick', this, 'resetEQSystem'));
		
		this.widgets.resetVars = new dijit.MenuBarItem({
			'label'	: T('app.wid.Dial.EstDep.js/ResetVars_TXT','Reset variables')
		});
		this.widgets.menuBar.addChild(this.widgets.resetVars);
		this.links.push(dojo.connect( this.widgets.resetVars,	'onClick', this, 'reset_vars'));
		
		// create a border container 
		this.widgets.innerBorderContainer = new dijit.layout.BorderContainer({
			'style' 	: 'width:100%;height:100%;',
			'gutters'	: false,
			'region'	: 'center',
		});
		this.widgets.borderContainer.addChild(this.widgets.innerBorderContainer);
		
		this.widgets.TabContainer = new dijit.layout.TabContainer({
			'region'	: 'center',
			'style'		: 'margin-bottom:.5ex;'
		});
		this.widgets.innerBorderContainer.addChild(this.widgets.TabContainer);
		
		this.widgets.HintPane = new dijit.layout.ContentPane({
			'region'	: 'right',
			'class'		: 'small',
			'style'		: 'width:220px;margin-left:.5ex;overflow-y:auto;padding-right:.25ex;',
			'splitter'	: true,
			'href'		: './third_party_libraries/Multidimensional_Equation_Solver/hints.php'
		});
		this.widgets.borderContainer.addChild(this.widgets.HintPane);
		
		this.widgets.eqEditorContainer = new dijit.layout.ContentPane({
			'title'		: T('app.wid.Dial.EstDep.js/EquSystem_TIT','Equation System'),
			'style'		: 'overflow-y:auto;'
		});
		this.widgets.TabContainer.addChild(this.widgets.eqEditorContainer);
		
		this.widgets.EquationEditor = new dijit.form.Textarea({
			'title'		: T('app.wid.Dial.EstDep.js/EquSystem_TIT','Equation System'),
			'value'		: this.vTEditorWidget.attrWidget.viewWidget.eqSolver.getCode_withoutBindingsAndTestValues(),
			'class'		: 'code fullWidth',
			'style'		: 'margin:0;border:0;'
		});
		// this.widgets.TabContainer.addChild(this.widgets.EquationEditor);
		this.widgets.EquationEditor.placeAt(this.widgets.eqEditorContainer.containerNode);
		
		this.links.push(dojo.connect( this.widgets.EquationEditor,	'onBlur', 	this, 'showDoF'));
		
		// create the store and the table for the variables
		
		this.buildVariableStore();
		this.links.push(dojo.connect( this.variableStore,			'onSet', 	this, 'showDoF'));

		this.widgets.vTContainer = new dijit.layout.ContentPane({
			'region'		: 'bottom',
			'splitter'		: true,
			'style'			: 'margin-top:.5ex;height:15em;overflow-y:auto;',
		});
		this.widgets.innerBorderContainer.addChild(this.widgets.vTContainer);
		
		this.widgets.variableTable = new application.widgets.Dialogs.EstimateDependencies_variableTable({
			'variableStore'	: this.variableStore,
			// 'region'		: 'bottom',
			// 'splitter'		: true,
			// 'style'			: 'margin-top:.5ex;',
		});
		this.widgets.variableTable.placeAt(this.widgets.vTContainer.containerNode);
		// this.widgets.innerBorderContainer.addChild(this.widgets.variableTable);
		
		this.showDoF();
		
	} // end of method postCreate
	,
	'startup' : function() {
		// If you need to be sure parsing and creation of any child widgets has 
		// completed, use startup. This is often used for layout widgets like 
		// BorderContainer. If the widget does JS sizing, then startup() should 
		// call resize(), which does the sizing.
		this.inherited(arguments);
		
		this.widgets.borderContainer.startup();
		this.widgets.borderContainer.resize();
				
	} // end of method startup
	,
	'onCancel' : function(){
		return false;
	} // end of method
	,
	'destroy' : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		
		// disconnect all links
		dojo.forEach(this.links,function(l){
			dojo.disconnect(l);
		},this);
		
		// eliminate all child widgets
		for (var i in this.widgets) this.widgets[i].destroyRecursive();
		delete this.widgets;
		
		this.inherited(arguments);
	} // end of method destroy
	,
	'acceptEstimatedValues' : function () {
		
		var viewWidget 		= this.vTEditorWidget.attrWidget.viewWidget;
		
		// iterate over all variables and pass their values back to the corresponding attributes
		this.variableStore.fetch({
			'scope'	: this,
			'onItem' : function (item) {
			
				var A_UUID			= this.variableStore.getValue(item,'A_UUID'),
					currentValue	= this.variableStore.getValue(item,'currentValue'),
					estimatedValue	= this.variableStore.getValue(item,'estimatedValue'),
					readOnly		= this.variableStore.getValue(item,'readOnly'),
					
					v = ( (estimatedValue) ? estimatedValue : currentValue );
					
				if ( 		!readOnly 
						&&	(typeof viewWidget.attributeWidgetList[A_UUID].setEstimatedValue == 'function')
					) 
						viewWidget.attributeWidgetList[A_UUID].setEstimatedValue(v);
				
			} // end of method onItem
		});
		
		this.vTEditorWidget.closeEstimateDependenciesDialog();
		
	} // end of method acceptEstimatedValues
	,
	'variableStore' : null // dojo.data.ItemFileWriteStore
	,
	'buildVariableStore' : function () {

		this.variableStore = new dojo.data.ItemFileWriteStore({
			'data' : { 
				'identifier' 	: 'A_UUID',
				'label'			: 'name',
				'items'			: []
			} // end of data definition
		});	
	
		// iterate over all attributes that appear in the equation system and put them into the store
		var viewWidget 		= this.vTEditorWidget.attrWidget.viewWidget,
			A_UUID 			= this.vTEditorWidget.config.A_UUID,
			dependencies 	= viewWidget.eqSolver.findDependencies(A_UUID),
			dependentVars	= dependencies.dependentVariables;
			
		for (var varName in dependentVars) {
			var var_A_UUID 		= dependentVars[varName],
				attributeWidget = viewWidget.attributeWidgetList[var_A_UUID];
			
			if(!attributeWidget) throw T('app.wid.Dial.EstDep.js/ConfigProblemMsg_HTM',
				'<h2>There is a Configuration Problem</h2> <p>The attribute that is connected to the variable « <code>$[0]</code>»  is not available in this view, but necessary for the equation system.</p> <p>You need to add the corresponding attribute to the view « <code>$[1]</code>»  as well.</p>',
				[varName, viewWidget.title]
				);
			
			this.variableStore.newItem({
				'A_UUID'		: var_A_UUID,
				'name'			: attributeWidget.config.name,
				'varName'		: varName,
				'originalValue'	: attributeWidget.getCurrentValue(),
				'unit'			: attributeWidget.getCurrentUnit(),
				'currentValue'	: attributeWidget.getCurrentValue(),
				'estimatedValue': '',
				'keepConstant'	: false,
				'format'		: attributeWidget.config.format,
				'minValue'		: attributeWidget.config.minValue,
				'maxValue'		: attributeWidget.config.maxValue,
				'readOnly'		: attributeWidget.config.readOnly,
				'position'		: attributeWidget.config.positionOfAttribute,
			});
		
		} // end for ... in
	
		this.variableStore.save();
	
	} // end of method buildVariableStore
	,
	'showDoF' : function () {
		
		var variables=0, constants=0;
		
		this.variableStore.fetch({
			'scope'	: this,
			'onItem': function (item) {
				if (this.variableStore.getValue(item, 'keepConstant')) 	constants++ 
					else 												variables++;
			} // end of method onItem
		});
		
		var eqSolver		= new EquationSolver(),
			eqSystem		= this.widgets.EquationEditor.attr('value');
			
		eqSolver.parameterise(eqSystem);
		eqSolver.parse();
		eqSolver.identifyVariablesInEquations();
		
		var equations = Object.keys(eqSolver.variablesInEquations).length,
			DoF = variables-equations,
			bgColor = '',
			hint='';
		
		if (DoF==0) { bgColor='Chartreuse'; 	hint= T('app.wid.Dial.EstDep.js/solvable_TXT','solvable');	}
		if (DoF>0) 	{ bgColor='khaki';			hint = T('app.wid.Dial.EstDep.js/Underspec_TXT','underspecified &mdash; set more values constant');	}
		if (DoF<0) 	{ bgColor='orangered';		hint = T('app.wid.Dial.EstDep.js/Overspec_TXT','overspecified &mdash; there should be more variables');	}
		
		var message = T('app.wid.Dial.EstDep.js/DoFMsg_HTM',
			'<code>$[0]</code> variables - <code>$[1]</code> equations = <strong><code>$[2]</code> degrees of freedom</strong> &#x279E; ', 
			[variables, equations, DoF]
			)
			+hint;
		
		dojo.attr(this.DoF_domNode, 'innerHTML', message);
		dojo.style(this.DoF_domNode, 'backgroundColor', bgColor);
		
	} // end of method showDoF
	,
	'executeSolver' : function (showDebugOutput) {
		
		// clear the output panes
		console.clear();
		if(this.widgets.solverOutput) 					this.widgets.solverOutput.attr('content', '');
		if(showDebugOutput && this.widgets.debugOutput) this.widgets.debugOutput.attr('content', '');
		
		// read all current values, set all estimated values to ""
		var attrValues 			= {}, // A_UUID => Wert
			bindings			= '';
		this.variableStore.fetch({
			'scope'		: this,
			'onItem' 	: function (item) {
				var store		= this.variableStore,
					A_UUID 		= store.getValue(item, 'A_UUID'),
					varName 	= store.getValue(item, 'varName'),
					name 		= store.getValue(item, 'name'),
					value		= store.getValue(item, 'currentValue'),
					keepConstant= (store.getValue(item, 'keepConstant')?true:false);
				
				// is a current value given?
				if(value.toString().length && !isNaN(value)) {
					attrValues[A_UUID] = {
						'keepConstant'	: keepConstant,
						'value'			: value
					};
				} // end if
				
				// set the estimated value in the store to ""
				store.setValue(item, 'estimatedValue', '');
				
				// add a variable binding
				//TG: QUESTION: Must the following line be translated? -> T()
				bindings +='bind variable '+varName+' to ${'+A_UUID+'} # '+name+'\n';
				
			} // end of method onItem
		});
		
		// execute the solver
				
		var A_UUID 			= this.vTEditorWidget.config.A_UUID,
			eqSolver		= new EquationSolver(),
			eqSystem		= this.widgets.EquationEditor.attr('value'),
			results			= {};
			
		try {
			
			
			eqSolver.parameterise(bindings+'\n'+eqSystem);
			eqSolver.parse();
			var dependencies = /*this.vTEditorWidget.attrWidget.viewWidget.*/eqSolver.findDependencies(A_UUID);
			eqSolver.set_attributeValues(attrValues);
			
			results = eqSolver.solve(dependencies.equations);
			console.log('EqSolver results', results);
		} catch(e) {
			console.log("Equation solver error!");
			console.log(eqSolver.debugMessages);
			throw e;
		} // end try ... catch
		
		// write all estimated values back
		// set the changed attribute values
		if (results.newAttrValues) {
			
			for (var a in results.newAttrValues) {
				var estimatedValue=results.newAttrValues[a];
				this.variableStore.fetchItemByIdentity({
					'identity'	: a,
					'scope'		: this,
					'onItem'	: function (item) {
						this.variableStore.setValue(item, 'estimatedValue', estimatedValue);
					} // end of method onItem
				});
			
			} // end for .. in
			
		} // end if there are results
		
		// show the solver's output
		if(!this.widgets.solverOutput) {
				this.widgets.solverOutput = new dijit.layout.ContentPane({
					'title'		: T('app.wid.Dial.EstDep.js/SolverRes_TIT','Results of the equation solver'),
					'closable'	: true,
					'content' 	: ''
				});
				
				this.widgets.TabContainer.addChild(this.widgets.solverOutput);
		} // end if

		var solvabilityMessage = '',
			DoF = results.numVariables-results.numEquations;
		if (DoF==0) solvabilityMessage = T('app.wid.Dial.EstDep.js/SolvMsgEQ0_TXT','The degree of freedom is <code>0</code>. There are as many variables as equations. If there is no error, everything was specified, correctly.');
		if (DoF<0) 	solvabilityMessage = T('app.wid.Dial.EstDep.js/SolvMsgLT0_TXT','The degrees of freedom are <code>$[0]</code>. This means that there are less variables than equations. Have a look at the constants that appear in the equations with the biggest error. One or more of them should be variables.', [DoF]);
		if (DoF>0) 	solvabilityMessage = T('app.wid.Dial.EstDep.js/SolvMsgGT0_TXT','The degrees of freedom are <code>$[0]</code>. The euqation system is underspecified. You need to set more constants, e.g. in the equations with the biggest error.', [DoF]);
		
		this.widgets.solverOutput.attr('content', ''
				+'<h2>' + T('app.wid.Dial.EstDep.js/SolverResults_TXT','The solver\'s results') + '</h2>\n'
				+'<h3>' + T('app.wid.Dial.EstDep.js/RemainingErr_TXT','Remaining Error') + '</h3>\n'
				+'<pre>R² = '+dojo.number.format(results.remainingError)+'</pre>\n'
				+'<h3>Jacobi Matrix</h3>'
				+'<p>'+solvabilityMessage+'</p>'
				+results.jacobiMatrix
				+'<h3>' + T('app.wid.Dial.EstDep.js/Iterations_TXT','Iterations') + '</h3>\n'
				+'<pre>'+dojo.number.format(results.iterations)+'</pre>\n'
				+'<h3>' + T('app.wid.Dial.EstDep.js/Log_TXT','Log') + '</h3>\n\n<pre>'+results.log+'</pre>\n'
				// +'<pre>'+dojo.toJson(results,true)+'</pre>\n'
			);
		this.widgets.TabContainer.selectChild(this.widgets.solverOutput);
		
		// show the debug messages
		if(showDebugOutput) {
			// create a pane for the debug output
			if(!this.widgets.debugOutput) {
				this.widgets.debugOutput = new dijit.layout.ContentPane({
					'title'		: T('app.wid.Dial.EstDep.js/SolverDbgOutput_TXT','The solver\'s debug output'),
					'closable'	: true,
					'content' 	: ''
				});
				
				this.widgets.TabContainer.addChild(this.widgets.debugOutput);
			} // end if there is no debug output widget, yet
			
			this.widgets.debugOutput.attr('content', ''
				+'<h2>' + T('app.wid.Dial.EstDep.js/SolverDbgOutput_TXT','The solver\'s debug output') + '</h2>'
				+'<h3>' + T('app.wid.Dial.EstDep.js/Log_TXT','Log') + '</h3>\n\n<pre>'+results.log+'</pre>\n'
				// +'<hr/>'
				+'<h3>' + T('app.wid.Dial.EstDep.js/DbgLog_TXT','Debug log') + '</h3>\n\n<pre>'+results.debug+'</pre>'
			);
			this.widgets.TabContainer.selectChild(this.widgets.debugOutput);
			
		} // end if showDebugOutput
				
	} // end of method executeSolver
	,
	'solve' : function (e) {
		this.executeSolver();
		dojo.stopEvent(e);
	} // end of method solve
	,
	'solve_withDebugOutput' : function (e) {
		this.executeSolver('debug');
		dojo.stopEvent(e);
	} // end of method solve_withDebugOutput
	,
	'resetEQSystem' : function () {
		this.widgets.EquationEditor.attr('value',
			this.vTEditorWidget.attrWidget.viewWidget.eqSolver.getCode_withoutBindingsAndTestValues()
		);
	} // end of method resetEQSystem
	,
	'reset_vars' : function () {
		this.variableStore.revert();
		
		var colNames = ['currentValue', 'estimatedValue'];
		
		this.variableStore.fetch({
			'scope'		: this,
			'onItem' 	: function (item) {
				
				dojo.forEach(colNames, function(colName) {
					var v = this.variableStore.getValue(item, colName);
					this.widgets.variableTable.onSet(item, colName, 12345/* any value*/, v);
				},this); // end for each col
				
			} // end onItem
		});
		
	} // end of method reset_vars
});