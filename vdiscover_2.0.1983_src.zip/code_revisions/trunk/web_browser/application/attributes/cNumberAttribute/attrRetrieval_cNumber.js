﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare(
	'application.widgets.retrieveAttributes.cNumberAttribute',
	[application.widgets.retrieveAttributes.genericAttribute],
	{
		'values_changed': function() {
			/**
			 * Entry point for all changes done in the retrieval form of this attribute.
			 * - calls function to adapt (correct) the inputs in the form
			 * - calls parent retrieval modul to inform it about the changes
			 */
			this._adaptInputForm();
			this._informRetrievalModul();
		}, // end-of-method values_changed
		
		
		'_adaptInputForm': function() {
			/**
			 * Check the inputs of the retrieval form of this attributes and adapts (corrects)
			 * them if necessaray.
			 * Method is called from method 'values_changed'.
			 */
			{ // Collect all changes
				var searchMode = this.searchMode_S.get('value');
				var not = this.not_cB.checked;
				var value1 = this.value1_nTB.get('value');
				var value2 = this.value2_nTB.get('value');
			}
			this.value1_nTB.set('required', true) ;
			this.value1_nTB.set('disabled', false);
			this.value2_nTB.set('disabled', true);
			this.not_cB.set('disabled', false);
			switch (searchMode) {
				case 'plusMinusAbsoluteValue': 
				case 'fromTo': {
					this.value1_nTB.set('constraints', {min: -9000000000000000}) ;
					this.value1_nTB.set('constraints', {max: 9000000000000000}) ;
					this.value2_nTB.set('required', true) ;
					this.value2_nTB.set('constraints', {min: -9000000000000000}) ;
					this.value2_nTB.set('constraints', {max: 9000000000000000}) ;
					this.value2_nTB.set('disabled', false);
					if (isNaN(value1) || !this.value1_nTB.isValid() || isNaN(value2) || !this.value2_nTB.isValid()) {
						searchMode = '';					
					}
					break;
				}
				case 'plusMinusPercentage': {
					this.value1_nTB.set('constraints', {min: -9000000000000000}) ;
					this.value1_nTB.set('constraints', {max: 9000000000000000}) ;
					this.value2_nTB.set('required', true) ;
					this.value2_nTB.set('constraints', {min: 0}) ;
					this.value2_nTB.set('constraints', {max: 100000000}) ;
					this.value2_nTB.set('disabled', false);
					if (isNaN(value1) || !this.value1_nTB.isValid() || isNaN(value2) || !this.value2_nTB.isValid()) {
						searchMode = '';					
					}
					break;
				}
				case 'exists': {
					this.value1_nTB.set('required', false) ;
					this.not_cB.set('disabled', true);
					this.not_cB.set('checked', false);
					not = this.not_cB.checked;
					this.value1_nTB.set('disabled', true);
					break;
				}
				case 'exactly':
				case 'lessThan':
				case 'lessThanOrEqual':
				case 'greaterThan':
				case 'greaterThanOrEqual': 
				default : {
					// reset with default values of dojo
					this.value1_nTB.set('constraints', {min: -9000000000000000}) ;
					this.value1_nTB.set('constraints', {max: 9000000000000000}) ;
					if (isNaN(value1) || ! this.value1_nTB.isValid()) {
						searchMode = '';					
					}		
					break;
				}
			} // end-of-switch
		}, // end-of-method _adaptInputForm
		
		
		'_informRetrievalModul': function() {
			/**
			 * Calls the parent retrieval modul to inform it about the changes in this
			 * attribute.
			 */
			{ // Collect all values
				var searchMode = this.searchMode_S.get('value');
				var not = this.not_cB.checked;
				var value1 = this.value1_nTB.get('value');
				var value2 = this.value2_nTB.get('value');
				var parsedQuery = this._parseQuery();
			}
			if (isNaN(value1)) {
				value1 = 0;
			}
			if (isNaN(value2)) {
				value2 = 0;
			}
			if (parsedQuery != '') {
				application.OT.retrieve.changeRetrievalAttribute(
					this.UUID,
					{
						'searchMode': searchMode,
						'not': not,
						'value1': value1,
						'value2': value2,
						'parsedQuery': parsedQuery,
						'ok': true
					}
				);
			}
			else {
				application.OT.retrieve.changeRetrievalAttribute(
					this.UUID,
					{
						'searchMode': '',
						'not': false,
						'value1': 0,
						'value2': 0,
						'parsedQuery': '',
						'ok': false
					}
				);
			}
		}, // end-of-method _informRetrievalModul
	
	
		'_parseQuery': function() {
			/**
			 * Generates a text form of the query, that can be displayed.
			 * @return string.
			 */
			var returnValue = '';
			{ // Get current values
				var searchMode = this.searchMode_S.get('value');
				var not = this.not_cB.checked;
				var value1 = this.value1_nTB.get('value');
				var value2 = this.value2_nTB.get('value');
			}
			{ // Generate parsed query for output
				{ // Switch on the basis of the searchMode
					switch (searchMode) {
						case '': {
							// Do nothing - error
							break;
						}
						case 'fromTo': {
							if ((value1 || (value1 === 0)) && (value2 || (value2 === 0))) {
								if (not) {
									returnValue = T('attrRetrieval_cNumber.js/notBetween_TXT','not ($[1] ≤ $[0] ≤ $[2])', [this.name, value1, value2]);
								}
								else {
									returnValue = T('attrRetrieval_cNumber.js/between_TXT','$[1] ≤ $[0] ≤ $[2]', [this.name, value1, value2]);
								}
							} 
							break;
						}
						case 'lessThan': {
							if (value1 || (value1 === 0)) {
								if (not) {
									returnValue = T('attrRetrieval_cNumber.js/notLessThan_TXT','not ($[0] < $[1])', [this.name, value1]);
								}
								else {
									returnValue = T('attrRetrieval_cNumber.js/lessThan_TXT','$[0] < $[1]', [this.name, value1]);
								}
							} 
							break;
						}
						case 'lessThanOrEqual': {
							if (value1 || (value1 === 0)) {
								if (not) {
									returnValue = T('attrRetrieval_cNumber.js/notLessThanOrEqual_TXT','not ($[0] ≤ $[1])', [this.name, value1]);
								}
								else {
									returnValue = T('attrRetrieval_cNumber.js/lessThanOrEqual_TXT','$[0] ≤ $[1]', [this.name, value1]);
								}
							} 
							break;
						}
						case 'greaterThan': {
							if (value1 || (value1 === 0)) {
								if (not) {
									returnValue = T('attrRetrieval_cNumber.js/notGreaterThan_TXT','not ($[0] > $[1])', [this.name, value1]);
								}
								else {
									returnValue = T('attrRetrieval_cNumber.js/greaterThan_TXT','$[0] > $[1]', [this.name, value1]);
								}
							} 
							break;
						}
						case 'greaterThanOrEqual': {
							if (value1 || (value1 === 0)) {
								if (not) {
									returnValue = T('attrRetrieval_cNumber.js/notGreaterThanOrEqual_TXT','not ($[0] ≥ $[1])', [this.name, value1]);
								}
								else {
									returnValue = T('attrRetrieval_cNumber.js/greaterThanOrEqual_TXT','$[0] ≥ $[1]', [this.name, value1]);
								}
							} 
							break;
						}
						case 'plusMinusPercentage': {
							if ((value1 || (value1 === 0)) && (value2 || (value2 === 0))) {
								if (not) {
									returnValue = T('attrRetrieval_cNumber.js/notPlusMinusPercentage_TXT','not ($[0] = $[1] ± $[2]%)', [this.name, value1, value2]);
								}
								else {
									returnValue = T('attrRetrieval_cNumber.js/plusMinusPercentage_TXT','$[0] = $[1] ± $[2]%', [this.name, value1, value2]);
								}
							} 
							break;
						}
						case 'plusMinusAbsoluteValue' : {
							if ((value1 || (value1 === 0)) && (value2 || (value2 === 0))) {
								if (not) {
									returnValue = T('attrRetrieval_cNumber.js/notPlusMinusAbsolute_TXT','not ($[0] = $[1] ± $[2])', [this.name, value1, value2]);
								}
								else {
									returnValue = T('attrRetrieval_cNumber.js/plusMinusAbsolute_TXT','$[0] = $[1] ± $[2]', [this.name, value1, value2]);
								}
							} 
							break;				
						}		
						case 'exists': {
							returnValue = T('attrRetrieval_cNumber.js/hasAValue_TXT','$[0] has a value', [this.name]);
							break;
						}
						case 'exactly':
						default: {
							if (value1 || (value1 === 0)){
								if (not) {
									returnValue = T('attrRetrieval_cNumber.js/exactly_TXT','not ($[0] = $[1])', [this.name, value1]);
								}
								else {
									returnValue = T('attrRetrieval_cNumber.js/exactly_TXT','$[0] = $[1]', [this.name, value1]);
								}
							} 
							break;
						}
					} // end-of-switch
				}
			}
			return (returnValue);
		}, // end-of-method _parseQuery
		
		
		'postMixInProperties': function() {
			this.inherited(arguments);
			//localise the necessary variables
			this.locateProperties(['searchMode', 'not', 'value1', 'value2', 'name']);
			
			// check variable and initialise them, if necessary
			disabled='';
			constraintsValue1='';
			constraintsValue2='';
			if (!this.searchMode) {
				this.searchMode = 'exactly';
			}		
			if (!this.not) {
				this.not = false;
			}		
			if (!this.value1) {
				this.value1 = '';
			}		
			if (!this.value2) {
				this.value2 = '';
			}		
			
			// prepare output
			switch ( this.searchMode ) {
				case 'fromTo':
					disabled='';
					if(this.value2)
						constraintsValue1="constraints='{" + T('attrRetrieval_cNumber.js/max_TXT','max:') +this.value2+"}'";
					if(this.value1)
						constraintsValue2="constraints='{" + T('attrRetrieval_cNumber.js/min_TXT','min:') +this.value1+"}'";
					break;
				case 'exactly':
				case 'lessThan':
				case 'lessThanOrEqual':
				case 'greaterThan':
				case 'greaterThanOrEqual':
					disabled = 'disabled';
					break;
				default :
					break;
			}		
			var checked = "";
			if (this.not == true) {
				checked = " checked='checked'";
			}
			this.title = T('attrRetrieval_cNumber.js/SearchParas_TIT','Search parameters');
			// expand the template string
			this.addTemplateSection(""
				+"<tr>"
					+"<td class='textRight' width='30%'>" + T('attrRetrieval_cNumber.js/ChSearchMode_LBL', 'Choose search mode:') + "</td>"
					+"<td width='70%'>"
						+"<select style='width:100%'"
							+"value='${searchMode}'" 
							+"dojoAttachEvent='onChange:values_changed'"
							+"dojoAttachPoint='searchMode_S'"
							+"dojoType='dijit.form.Select'"
						+">"
							+"<option value='exactly'>${name} = value1</option>"
							+"<option type='separator'></option>"
							+"<option value='lessThan'>${name} < value1</option>"
							+"<option value='lessThanOrEqual'>${name} ≤ value1</option>"
							+"<option value='greaterThan'>${name} > value1</option>"
							+"<option value='greaterThanOrEqual'>${name} ≥ value1</option>"
							+"<option value='fromTo'>value1 ≤ ${name} ≤ value2</option>"
							+"<option type='separator'></option>"
							+"<option value='plusMinusAbsoluteValue'>${name} = value1 ± value2</option>"
							+"<option value='plusMinusPercentage'>${name} = value1 ± value2 %</option>"
							+"<option type='separator'></option>"
							+"<option value='exists'>${name} has a value</option>"
						+"</select>"
					+"</td>"
				+"</tr>"	
				+"<tr>"
					+"<td class='textRight' width='30%'> </td>"
					+"<td width='70%'>"
						+"<input type='checkbox'"
							+" value='1'"
							+checked
							+" dojoAttachEvent='onChange:values_changed'"
							+" dojoAttachPoint='not_cB'"
							+" dojoType='dijit.form.CheckBox'"
						+"/>"
						+" "
						+T('attrRetrieval_cNumber.js/Not_LBL', 'Negate condition of search mode')
					+"</td>"
				+"</tr>"
				+"<tr>"
					+"<td class='textRight' width='30%'>" + T('FUT_value','value<sub>1</sub>:') + "</td>"
					+"<td width='70%'>"
						+"<input type='text' style='width:100%'"
							+"value='${value1}'" 
							+"dojoAttachEvent='onChange:values_changed'"
							+"dojoAttachPoint='value1_nTB'"
							+"dojoType='dijit.form.NumberTextBox'"
							+"required='true'"
							+constraintsValue1
						+"/>"
					+"</td>"
				+"</tr>"	
				+"<tr>"
					+"<td class='textRight' width='30%'>" + T('FUT_value','value<sub>2</sub>:') + "</td>"
					+"<td width='70%'>"
						+"<input type='text' style='width:100%'"
							+"value='${value2}'" 
							+"dojoAttachEvent='onChange:values_changed'"
							+"dojoAttachPoint='value2_nTB'"
							+"dojoType='dijit.form.NumberTextBox'"
							+"required='true'"
							+disabled
							+constraintsValue2
						+"/>"
					+"</td>"
				+"</tr>"	
				+"<tr>"
					+"<td class='textRight' width='30%'>"
						+T('attrRetrieval/SearchRemarks_TXT','Remarks:')
					+"</td>"				
					+"<td width='70%'>"
						+"<ul>"
							+"<li>"
								+T('attrRetrieval_cNumber.js/SelSrchModeFor_HTM', 'You can select one of the following search modes:')
								+"<ul>"
									+"<li>" 
										+T('attrRetrieval_cNumber.js/SrchTips_P1_HTM','<strong>«${name} = <i>value<sub>1</sub></i>»</strong> finds all objects where «${name}» is exactly <code>value<sub>1</sub></code>') 
									+"</li>"
									+"<li>"
										+T('attrRetrieval_cNumber.js/SrchTips_P2_HTM','<strong>«${name} < <i>value<sub>1</sub></i>»</strong> finds all objects where «${name}» is less than <code>value<sub>1</sub></code>') 
									+"</li>"
									+"<li>"
										+T('attrRetrieval_cNumber.js/SrchTips_P3_HTM','<strong>«${name} ≤ <i>value<sub>1</sub></i>»</strong> finds all objects where «${name}» is less than or equal <code>value<sub>1</sub></code>')
									+"</li>"
									+"<li>"
										+T('attrRetrieval_cNumber.js/SrchTips_P4_HTM','<strong>«${name} > <i>value<sub>1</sub></i>»</strong> finds all objects where «${name}» is greater than <code>value<sub>1</sub></code>')
									+"</li>"
									+"<li>"
										+T('attrRetrieval_cNumber.js/SrchTips_P5_HTM','<strong>«${name} ≥ <i>value<sub>1</sub></i>»</strong> finds all objects where «${name}» is greater than or equal <code>value<sub>1</sub></code>')
									+"</li>"
									+"<li>"
										+T('attrRetrieval_cNumber.js/SrchTips_P6_HTM','<strong>«<i>value<sub>1</sub></i> ≤ ${name} ≤ <i>value<sub>2</sub></i>»</strong> finds all objects where «${name}» is between <code>value<sub>1</sub></code> and <code>value<sub>2</sub></code>.<br /><code>value<sub>1</sub></code> and <code>value<sub>2</sub></code> may be swapped.')
									+"</li>"
									+"<li>"
										+T('attrRetrieval_cNumber.js/SrchTips_P7_HTM','<strong>«${name} = <i>value<sub>1</sub></i> ± <i>value<sub>2</sub></i>»</strong> finds all objects where «${name}» is between <code>value<sub>1</sub>-value<sub>2</sub></code> and <code>value<sub>1</sub>+value<sub>2</sub></code>, e.g. if <code><i>value<sub>1</sub></i></code>=10 and the absolute deviation is 5 (<code>value<sub>2</sub></code>=5), then the search range goes from 5 to 15')
									+"</li>"
									+"<li>"
										+T('attrRetrieval_cNumber.js/SrchTips_P8_HTM','<strong>«${name} = <i>value<sub>1</sub></i> ± <i>value<sub>2</sub></i>%»</strong> finds all objects where «${name}» is between <code>value<sub>1</sub></code> &plusmn; (<code>value<sub>2</sub>% of value<sub>1</sub></code>), e.g. if <code><i>value<sub>1</sub></i></code>=10 and the percentaged deviation is 5 (<code>value<sub>2</sub></code>=5), then the search range goes from 9.5 to 10.5')
									+"</li>"
									+"<li>"
										+T('attrRetrieval_cNumber.js/SrchTips_P9_HTM','<strong>«${name} has a value»</strong> finds all objects where a value in «${name}» exists.')
									+"</li>"
								+"</ul>"
							+"</li>"
							+"<li>"
								+T('attrRetrieval_cNumber.js/SelNot_HTM', 'Negating the condition of the search mode results in a logical not in the query condition.')
							+"</li>"
						+"</ul>"
					+"</td>"
				+"</tr>"	
			);
			// generate the template string
			this.generateTemplateString();
		}, // end-of-method postMixInProperties
		
		
		'postCreate': function(){
			this._adaptInputForm();
		}, // end-of-method postCreate
		
		
		'_end_': null
		
	}
	
); // end-of-declaration
