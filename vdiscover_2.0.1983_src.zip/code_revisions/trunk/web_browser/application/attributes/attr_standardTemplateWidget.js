﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// the following two classes display an attribute in both read and edit mode

dojo.declare("application.widgets.standardAttribute",[application.widgets.genericAttribute],{

	'generateNewTupleIfLastGotDeleted' : true,

	// these variables need to be set
	'valueTupleEditors' : null // {}
	,
	'vTEditor_delWrappers' : null // {}
	,
	'htmlFormatTuple_editMode' : function (vT_UUID) {

		// this method is not necessary, here, because this is carried out with
		// special widgets of the class application.widgets.valueTupleEditor_generic

	return '';
	} // end of method htmlFormatTuple_editMode
	,
	'addValueTupleIcon_title' : T('attr_standardTemplateWidget.js/AddNewValTpl_TIT','Add a new value tuple.')
	,
	'htmlFormatTupleSet_editMode' : function (valueTuples) {
		var num_Valuetuples = Object.keys(valueTuples).length;
		return ''
			+'<div class="RS_attributeEditor">\n'
				+'<div class="RS_attributeEditor_valueSets" dojoAttachPoint="valueTupleEditors_domNode">\n\n'
					// the value tuple editors will go here
				+'</div>\n'
				+'<div dojoAttachPoint="RS_attributeEditor_menu_DOMNode" '
					+'class="RS_attributeEditor_menu" '
					+'style="'+((this.config.cardinality==1&&!(num_Valuetuples==0))?'display:none;':'')+'">\n'
					+'<div dojoAttachPoint="addValueTupleIcon_domNode" '
						+'dojoAttachEvent="onclick:_addValueTupleButton_clicked" '
						+'class="RS_valueTuple_editIcon RS_icon_add" title="'+this.addValueTupleIcon_title+'"></div>\n'
					+'<div class="textRight RS_valueTuple_editInner small" dojoAttachpoint="usedValueTuplesDomNode">\n'
						+ 'Using 5 of max. 5 value tuples.\n</div>\n'
				+'</div>\n'
			+'</div>\n'
			;
	}
	,
	'createNewValueTuple' : function () {
		var 	vT_UUID 			= Math.uuid(),
				valueTuple 			= this.getValueTuple(vT_UUID);

		valueTuple.positionOfValue	= 10*this.valueTuples_edit_count + 10;

		return	this.valueTuples[vT_UUID]= valueTuple;
	} // end of method createNewValueTuple
	,
	'postCreate' : function() {
		// This is typically the workhorse of a custom widget. The widget has
		// been rendered (but note that sub-widgets in the containerNode have not!).
		// The widget though may not be attached to the DOM yet so you shouldn't
		// do any sizing calculations in this method.
		//this.inherited(arguments);
		this.inherited(arguments);

		// the value tuples are being displayed, already
		// show or hide the noValueSets Message
		this.showHide_noValueTuplesMessage();

		if (this.outputMode!='edit') return; // -- nothing to do in read mode

		this.valueTupleEditors 		= {};
		this.vTEditor_delWrappers 	= {};
		this.valueTuples_edit_count	= 0;

		// output the existing value tuple set
		for(var valueTupleUUID in this.valueTuples)
			this.createValueTupleEditor(this.valueTuples[valueTupleUUID]);

		// create and output an empty value set if there are no value sets, yet
		if(		this.addEmptyValueSet_inEditMode
			&& 	!Object.keys(this.valueTuples).length	) {
			this._addValueTupleButton_clicked();
		} // end if

		if (this.outputMode=='edit') this.updateNumberOfValueTuples();

	} // end of method postCreate
	,
	'createNewValueTuple_whenAddButtonClicked' : true
	,
	'_addValueTupleButton_clicked' : function(e) {
		if (this.createNewValueTuple_whenAddButtonClicked) {
			this.createValueTupleEditor(this.createNewValueTuple());
		} else {
			this.createValueTupleEditor();
		} // end if

		this.updateNumberOfValueTuples();
		if (e) dojo.stopEvent(e);
	} // end of method
	,
	'createValueTupleEditor' : function (valueTuple) {
		// insert a value tuple editor widget into this.valueTupleEditors_domNode

		var valueTupleUUID	= valueTuple.AV_UUID,
			vTEditorType 	= this.valueTupleEditor_name.replace('application.widgets.',''),
			vTEditor		= new application.widgets[vTEditorType]({
				'attrWidget' 					: this,
				'valueTupleUUID' 				: valueTupleUUID,
				'valueTuple'	 				: valueTuple,
			}).placeAt(this.valueTupleEditors_domNode);

		this.valueTuples_edit_count++;
		this.valueTupleEditors[valueTupleUUID]=vTEditor;
		this._supportingWidgets.push(vTEditor);

	} // end of method createValueTupleEditor
	,
	'startup' : function () {
		this.inherited(arguments);

		if (this.outputMode=='edit') this.updateNumberOfValueTuples();
	} // end of method startup
	,
	'updateNumberOfValueTuples' : function () {
		if (this.outputMode=='edit') {

			// set the number of used value tuples
			this.usedValueTuplesDomNode.innerHTML= ''
				+ T('attr_standardTemplateWidget.js/UsedValTplDomN_P1_TXT','Using')+ ' '+this.valueTuples_edit_count+ ' '
				+((this.config.cardinality==0)?
					'':
					' ' + T('attr_standardTemplateWidget.js/UsedValTplDomN_P2_TXT','of max.') + ' '+this.config.cardinality)
				+(this.valueTuples_edit_count!=1? T('attr_standardTemplateWidget.js/ValTples_TXT','value tuples'): T('attr_standardTemplateWidget.js/ValTpl_TXT','value tuple') )
				+'.';

			// set or remove the add icon
			dojo.style(this.addValueTupleIcon_domNode,'display',
				(( 		(this.config.cardinality==0) // means infinite
					|| 	(this.config.cardinality>this.valueTuples_edit_count)
					)
				?'block':'none')
			);

			// show number of used value tuples?
			dojo.style(this.RS_attributeEditor_menu_DOMNode,'display',
				(((this.config.cardinality==0)||this.config.cardinality>this.valueTuples_edit_count)?'block':'none'));

			// update all up/down buttons

			// build a list of all open value tuple editors
			var vTEditors 		= [],
				num_vTEditors	= 0;
			for (var valueTupleUUID in this.valueTupleEditors)
				if(this.valueTupleEditors[valueTupleUUID].status!='deleted') {
					var vtEditor = this.valueTupleEditors[valueTupleUUID];
					vTEditors[vtEditor.valueTuple.positionOfValue] = vtEditor;
					num_vTEditors++;
				} // end if // end for ... in

			// iterate over all open value tuple editors and show/hide the up & down arrows
			var index			= 0;
			dojo.forEach(vTEditors, function(vTEditor) {
				if(vTEditor) {

					index++;
					var oldPos = vTEditor.valueTuple.positionOfValue,
						newPos = index*10;

					if(oldPos!=newPos) {
						vTEditor.valueTuple.positionOfValue = newPos;
						vTEditor.notifyAttributeOfChangedValue();
					} // end if

					vTEditor._showHide_upDownArrows(index, num_vTEditors);

				} // end if
			}, this); // end for each

		} // end if in editing mode
	} // end of method updateNumberOfValueTuples
	,
	'setValueTuple_deleted' : function(valueTupleUUID) {
		this.inherited(arguments);

		// 2 cases: read or edit mode

		if (this.outputMode=='read') {

			// this does not seem to be necessary, anymore
			// var domNode = dojo.byId(valueTupleUUID);
			// if (domNode) dojo.destroy(domNode);

			// this is carried out in this.inherited(arguments);
			// this.valueTuples_deleted[valueTupleUUID]=valueTupleUUID;

			// show or hide the noValueSets Message
			this.showHide_noValueTuplesMessage();

		} else { // this.outputMode=='edit'

			// tell the value tuple editor that it got deleted
			this.valueTupleEditors[valueTupleUUID].set_deleted();

			this.valueTuples_edit_count--;

			if(		this.generateNewTupleIfLastGotDeleted
				&& (this.valueTuples_edit_count<1)			)
				this.createValueTupleEditor(this.createNewValueTuple());

			this.updateNumberOfValueTuples();
		} // end if read or edit mode
	} // end of method setValueTuple_deleted
	,
	'setValueTuple' : function (VT_UUID, vT) {
		// 2 cases: read or edit mode

		if (this.outputMode=='read') {
			// ???
		} else { // this.outputMode=='edit'
			// if there is no valid value tuple UUID yet, take the one of the first value tuple editor
			if ( !(VT_UUID in this.valueTupleEditors) ) VT_UUID = Object.keys(this.valueTupleEditors)[0];
			this.valueTupleEditors[VT_UUID].setValueTuple(vT);
		} // end if read or edit mode
	} // end of method setValueTuple
	,
	'moveVTWidget' : function (vTWidget, direction /* either 'up' or 'down' */ ) {

		var currentVT_domNode 	= null,
			nextWidget 			= null,
			up 					= (direction=='up');

		try {
			// find the first domNode next the current one that is not deleted
			currentVT_domNode = vTWidget.domNode;
			while	(		(nextWidget = dijit.byNode(currentVT_domNode[up?'previousSibling':'nextSibling']))
						&&	(nextWidget.status=='deleted')
					) {
				currentVT_domNode = nextWidget.domNode;
			} // end while

		} catch(e){
			console.log(arguments.callee.name+' has no dijit widget "'+direction+'" of it.\nCannot move the current value tuple editor.');
			console.log(e);
		}; // end try .. catch

		// place the current valueTuple Editor before the previous one
		if (vTWidget && nextWidget) {

			// carry out the placement in the DOM tree
			dojo.place(vTWidget.domNode, nextWidget.domNode, (up?'before':'after') );

			vTWidget.valueTuple.positionOfValue+=(up?-1:1)*15;

			this.updateNumberOfValueTuples();

		} // end if

	} // end of method moveVTWidget
	,
	'isValid' : function () {
		// test if all value tuple editors that are currently displayed have valid contents

		var isValid 	= true,
			vTEditors	= 0;

		for (var VT_UUID in this.valueTupleEditors) {
			var vTEditor = this.valueTupleEditors[VT_UUID];
			if (
						!('status' in vTEditor)
					||	(('status' in vTEditor) && (vTEditor.status!='deleted'))
				) {
					isValid = isValid && vTEditor.isValid();
					vTEditors++;
			} // end if
		} // end for .. in

		// there needs to be one or more value tuple editor
		if (this.config.mustBeSet && !vTEditors) isValid=false;

		return isValid;
	} // end of method isValid

}); // end of declaration

// ========================================================================


