﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	dojo.declare(
		'application.widgets.cCounterAttribute',
		[application.widgets.standardAttribute],
		{
	htmlFormatValueTuple_readMode : function (valueTuple) {
		var formatOptions = {};
		if (this.config.formatDisplay){ // number format
			formatOptions.pattern = this.config.formatDisplay;
		}
		return ''
			+'<code>'
				+dojo.number.format(valueTuple.value_number, formatOptions)
			+'</code>'
			;
			} // end-of-method htmlFormatValueTuple_ReadMode
		}
	); // end-of-declaration
