﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

application.attributeKinds.register({
	'kind': "cCounterAttribute", 
	'defaultConfiguration' : { 
		'format':	'######',
		'nextValue': 			1,
		'increment': 			1,
		'cardinality':	 		1, 
		'svFormatActivated':	false,
		'svHtmlBefore':			'',
		'svHtmlBetween':		'',
		'svHtmlAfter':			'',
	},
		
	'defaultRetrievalValues': ['searchMode', 'not', 'value1', 'value2'],
		
	'widgetClass': 'application.widgets.cCounterAttribute',
		
	'configurationWidgetClass': 'application.widgets.configureAttributes.cCounterAttribute',
		
	'fixedReadOnly': true,
		
	'fixedCardinality': true,
		
	'useValueTupleAsExpressionInput': false
	,
	'expressionsPermitted': false
	,


}); // end-of register