﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare(
	'application.widgets.configureSpecialAttribute.cCounterAttribute',
		[application.widgets.configureAttribute.genericConfigurationWidget],
		{
	'format_changed' : function(e) {
		var format = this.format_tB.attr('value');
		this.propertyHasChanged('format',format);
		
		this.nextValue_nTB.attr('constraints',{'pattern':format});
		this.increment_nTB.attr('constraints',{'pattern':format});
			}, // end-of-method format_changed
		
	'nextValue_changed' : function(e) {
		var v = this.nextValue_nTB.attr('value');
		if (isNaN(v)) v=1;
		this.propertyHasChanged('nextValue', v);
			}, // end-of-method nextValue_changed
		
	'increment_changed' : function(e) {
		var v = this.increment_nTB.attr('value');
		if (isNaN(v)) v=1;
		this.propertyHasChanged('increment', v);
			}, // end-of-method increment_changed
		
	'postMixInProperties': function() {
		this.inherited(arguments);
		
		// expand the template string
		this.addTemplateSection(""
			+"<tr>"
				+"<td class='textRight'>" + T('attrConf_cCounter.js/FormatDef_LBL', 'Format definition<br/>(number pattern):') + "</td>"
				+"<td>"
					+"<input type='text' class='fullWidth' "
						+"value='${format}' "
						+"dojoAttachEvent='onChange:format_changed,onFocus:showNumberEditHints' "
						+"dojoAttachPoint='format_tB' "
						+"dojoType='dijit.form.TextBox' "
						+"trim='true' "
						+"disabled='${isInherited}' "
					+"/>"
				+"</td>"
			+"</tr>"
			
			+"<tr> "
				+"<td class='textRight'>" + T('attrConf_cCounter.js/NextVal_LBL', 'Next value:') + "</td>"
				+"<td>"
					+"<input dojoType='dijit.form.NumberTextBox' "
						+"value='${nextValue}' class='fullWidth' "
						+"dojoAttachPoint='nextValue_nTB' "
						+"dojoAttachEvent='onChange:nextValue_changed,onFocus:showEditHints' "
						+"disabled='${isInherited}' "
					+"/>"
				+"</td>"
			+"</tr>"
			
			+"<tr>"
				+"<td class='textRight'>" + T('FUT_Increment', 'Increment') + ":</td>"
				+"<td>"
					+"<input dojoType='dijit.form.NumberTextBox' "
						+"value='${increment}' class='fullWidth' "
						+"dojoAttachPoint='increment_nTB' "
						+"dojoAttachEvent='onChange:increment_changed,onFocus:showEditHints' "
						+"disabled='${isInherited}' "
					+"/>"
				+"</td>"
			+"</tr>"
		);
		
		//localise the necessary variables
		this.locateProperties(['format','nextValue','increment']);
		
		// generate the template string
		this.generateTemplateString();
		
			}, // end-of-method postMixInProperties
		
	'postCreate' : function() {
		this.inherited(arguments);

		this.nextValue_nTB.attr('constraints',{'pattern':this.format});
		this.increment_nTB.attr('constraints',{'pattern':this.format});
		
			}, // end-of-method postCreate
		}
	); // end-of-declaration
