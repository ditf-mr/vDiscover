﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare(
	'application.widgets.configureSpecialAttribute.cValueRangeAttribute',
	[application.widgets.configureSpecialAttribute.numericalAttribute],{
	
	'postMixInProperties': function() {
		this.inherited(arguments);
		
		//localise the necessary variables
		this.locateProperties(['defaultValue_rangeMin', 'defaultValue_rangeMax', 'parentDefaultValue_rangeMin', 'parentDefaultValue_rangeMax',]);
		
		this.inheritedDefaultValue_string = ''
			+(this.parentDefaultValue_rangeMin?
				'['+dojo.number.format(this.parentDefaultValue_rangeMin, {'pattern': this.format})
				: '')
			+((this.parentDefaultValue_rangeMin||this.parentDefaultValue_rangeMax)?'…':'')
			+(this.parentDefaultValue_rangeMax?
				dojo.number.format(this.parentDefaultValue_rangeMax, {'pattern': this.format})+']'
				: '');
		
		// expand the template string
		this.addTemplateSection(""
			+"<tr>"
				+"<td class='textRight'>" + T('attrConf_cValueRange.js/DefValRange_LBL','Default value range<br/>(optional):') + "</td>"
				+"<td>"
					+"<input dojoType='dijit.form.NumberTextBox' "
						+"value='${defaultValue_rangeMin}' style='width:10em;' "
						+"dojoAttachPoint='defaultValue_rangeMin_nTB' "
						+"dojoAttachEvent='onChange:defaultValues_changed,onFocus:showEditHints' "
						+"intermediateChanges='true' "
						+"/>"
					+"&nbsp;…&nbsp;"
					+"<input dojoType='dijit.form.NumberTextBox' "
						+"value='${defaultValue_rangeMax}' style='width:10em;' "
						+"dojoAttachPoint='defaultValue_rangeMax_nTB' "
						+"dojoAttachEvent='onChange:defaultValues_changed,onFocus:showEditHints' "
						+"intermediateChanges='true' "
						+"/>"
					+"<div dojoAttachPoint='parentDefaultValueMessage_node'>"
						+"<p>"
							+ T('attrConf_cValueRange.js/InherDefVal_P1_HTM','The inherited default value is <code>${inheritedDefaultValue_string}</code>.')
							+ "<br/>"
							+ T('attrConf_cValueRange.js/InherDefVal_P2_LNK','Click <a dojoAttachEvent="onclick:useInheritedDefaultValue_clicked">here</a> to use the inherited default value.')
						+"</p>"
					+"</div>"
				+"</td>"
			+"</tr>"
		);
		
		// generate the template string
		this.generateTemplateString();
		
	} // end of method postMixInProperties
	,
	postCreate : function() {
		this.inherited(arguments);
		
		var showMessage = 		(		this.parentDefaultValue_rangeMin
									||	this.parentDefaultValue_rangeMax
								)
							&&	(		(this.parentDefaultValue_rangeMin != this.defaultValue_rangeMin)
									||	(this.parentDefaultValue_rangeMax != this.defaultValue_rangeMax)
								);
							
		dojo.style(this.parentDefaultValueMessage_node, 'display', 
			(showMessage?'block':'none'));

	} // end of method postCreate
	,
	'setConstraints' : function () {
		this.inherited(arguments);
	
		var constraints = {'pattern': this.format};
	
		this.minValue_nTB.attr(					'constraints', constraints);
		this.maxValue_nTB.attr(					'constraints', constraints);
		
		this.defaultValue_rangeMin_nTB.attr(	'constraints', constraints);
		this.defaultValue_rangeMax_nTB.attr(	'constraints', constraints);
		this.defaultValue_rangeMin_nTB.validate();
		this.defaultValue_rangeMax_nTB.validate();
	} // end of method setConstraints
	,
	'defaultValues_changed' : function(e) {
		var v = this.defaultValue_rangeMin_nTB.attr('value');
		if (isNaN(v)) v='';
		var w = this.defaultValue_rangeMax_nTB.attr('value');
		if (isNaN(w)) w='';
		this.propertyHasChanged( 'defaultValue_rangeMin', v);
		this.propertyHasChanged( 'defaultValue_rangeMax', w);
		
		var showMessage = 		(		this.parentDefaultValue_rangeMin
									||	this.parentDefaultValue_rangeMax
								)
							&&	(		(this.parentDefaultValue_rangeMin != this.defaultValue_rangeMin)
									||	(this.parentDefaultValue_rangeMax != this.defaultValue_rangeMax)
								);
		
		dojo.style(this.parentDefaultValueMessage_node, 'display', 
			(showMessage?'block':'none'));
	} // end of method format_changed
	,
	'useInheritedDefaultValue_clicked' : function (e) {
		this.defaultValue_rangeMin_nTB.attr('value', this.parentDefaultValue_rangeMin);
		this.defaultValue_rangeMax_nTB.attr('value', this.parentDefaultValue_rangeMax);
		dojo.stopEvent(e);
	} // end of method useInheritedDefaultValue_clicked
});
