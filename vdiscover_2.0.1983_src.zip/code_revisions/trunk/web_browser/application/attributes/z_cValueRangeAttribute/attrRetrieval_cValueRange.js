﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare(
	'application.widgets.retrieveAttributes.cValueRangeAttribute',
	[application.widgets.retrieveAttributes.genericAttribute],
	{
	
		'values_changed': function() {
			/**
			 * Entry point for all changes done in the retrieval form of this attribute.
			 * - calls function to adapt (correct) the inputs in the form
			 * - calls parent retrieval modul to inform it about the changes
			 */
			this._adaptInputForm();
			this._informRetrievalModul();
		}, // end-of-method values_changed
		
		
		'_adaptInputForm': function() {
			/**
			 * Check the inputs of the retrieval form of this attributes and adapts (corrects)
			 * them if necessaray.
			 * Method is called from method 'values_changed'.
			 */
			{ // Collect all changes
				var searchMode = this.searchMode_S.get('value');
				var not = this.not_cB.checked;
				var value1 = this.value1_nTB.get('value');
				var value2 = this.value2_nTB.get('value');
			}
			this.value1_nTB.set('required', true) ;
			this.value1_nTB.set('disabled', false);
			this.value2_nTB.set('disabled', true);
			this.not_cB.set('disabled', false);
			switch (searchMode) {
				case 'rangePlusMinusAbsoluteValueIn':
				case 'rangePlusMinusAbsoluteValuePartlyIn':
				case 'rangeFromToIn':
				case 'rangeFromToPartlyIn': 
				case 'rangeInRangePlusMinusAbsolute':
				case 'rangeInRangeFromTo': {
					this.value1_nTB.set('constraints', {min: -9000000000000000}) ;
					this.value1_nTB.set('constraints', {max: 9000000000000000}) ;
					this.value2_nTB.set('required', true) ;
					this.value2_nTB.set('constraints', {min: -9000000000000000}) ;
					this.value2_nTB.set('constraints', {max: 9000000000000000}) ;
					this.value2_nTB.set('disabled', false);
					if (isNaN(value1) || !this.value1_nTB.isValid() || isNaN(value2) || !this.value2_nTB.isValid()) {
						searchMode = '';					
					}
					break;
				}
				case 'rangePlusMinusPercentageIn':
				case 'rangePlusMinusPercentagePartlyIn': 
				case 'rangeInRangePlusMinusPercentage': {
					this.value1_nTB.set('constraints', {min: -9000000000000000}) ;
					this.value1_nTB.set('constraints', {max: 9000000000000000}) ;
					this.value2_nTB.set('required', true) ;
					this.value2_nTB.set('constraints', {min: 0}) ;
					this.value2_nTB.set('constraints', {max: 100000000}) ;
					this.value2_nTB.set('disabled', false);
					if (isNaN(value1) || !this.value1_nTB.isValid() || isNaN(value2) || !this.value2_nTB.isValid()) {
						searchMode = '';					
					}
					break;
				}
				case 'exists': {
					this.value1_nTB.set('required', false) ;
					this.not_cB.set('disabled', true);
					this.not_cB.set('checked', false);
					not = this.not_cB.checked;
					this.value1_nTB.set('disabled', true);
					break;
				}
				case 'valueIsExactlySizeOfRange':						 
				case 'valueIsLessThanSizeOfRange':
				case 'valueIsGreaterThanSizeOfRange': {
					this.value1_nTB.set('constraints', {min: 0}) ;
					this.value1_nTB.set('constraints', {max: 9000000000000000}) ;
					if (isNaN(value1) || ! this.value1_nTB.isValid()) {
						searchMode = '';					
					}		
					break;
				}
				case 'valueIn':
				case 'valueBelow':
				case 'valueAbove': 
				default: {
					this.value1_nTB.set('constraints', {min: -9000000000000000}) ;
					this.value1_nTB.set('constraints', {max: 9000000000000000}) ;
					if (isNaN(value1) || ! this.value1_nTB.isValid()) {
						searchMode = '';					
					}		
					break;
				}
			} // end-of-switch
		}, // end-of-method _adaptInputForm
		
		
		'_informRetrievalModul': function() {
			/**
			 * Calls the parent retrieval modul to inform it about the changes in this
			 * attribute.
			 */
			{ // Collect all values
				var searchMode = this.searchMode_S.get('value');
				var not = this.not_cB.checked;
				var value1 = this.value1_nTB.get('value');
				var value2 = this.value2_nTB.get('value');
				var parsedQuery = this._parseQuery();
			}
			if (isNaN(value1)) {
				value1 = 0;
			}
			if (isNaN(value2)) {
				value2 = 0;
			}
			if (parsedQuery != '') {
				application.OT.retrieve.changeRetrievalAttribute(
					this.UUID,
					{
						'searchMode': searchMode,
						'not': not,
						'value1': value1,
						'value2': value2,
						'parsedQuery': parsedQuery,
						'ok': true
					}
				);
			}
			else {
				application.OT.retrieve.changeRetrievalAttribute(
					this.UUID,
					{
						'searchMode': '',
						'not': false,
						'value1': 0,
						'value2': 0,
						'parsedQuery': '',
						'ok': false
					}
				);
			}
		}, // end-of-method _informRetrievalModul
	
	
		'_parseQuery': function() {
			/**
			 * Generates a text form of the query, that can be displayed.
			 * @return string.
			 */
			var returnValue = '';
			{ // Get current values
				var searchMode = this.searchMode_S.get('value');
				var not = this.not_cB.checked;
				var value1 = this.value1_nTB.get('value');
				var value2 = this.value2_nTB.get('value');
			}
			{ // Generate parsed query for output
				{ // Switch on the basis of the searchMode
					switch (searchMode) {
						case 'valueIn': {
							if (value1 || (value1 === 0)) {
								if (not) {
									returnValue = T('attrRetrieval_cValueRange.js/valueIsNotIn_TXT','$[1] is not in $[0]', [this.name, value1]);
								}
								else {
									returnValue = T('attrRetrieval_cValueRange.js/valueIsIn_TXT','$[1] is in $[0]', [this.name, value1]);
								}
							} 
							break;
						}
						case 'valueBelow': {
							if (value1 || (value1 === 0)) {
								if (not) {
									returnValue = T('attrRetrieval_cValueRange.js/valueIsNotBelow_TXT','$[1] is not below $[0]', [this.name, value1]);
								}
								else {
									returnValue = T('attrRetrieval_cValueRange.js/valueIsBelow_TXT','$[1] is below $[0]', [this.name, value1]);
								}
							} 
							break;
						}
						case 'valueAbove': {
							if (value1 || (value1 === 0)) {
								if (not) {
									returnValue = T('attrRetrieval_cValueRange.js/valueIsNotAbove_TXT','$[1] is not above $[0]', [this.name, value1]);
								}
								else {
									returnValue = T('attrRetrieval_cValueRange.js/valueIsAbove_TXT','$[1] is above $[0]', [this.name, value1]);
								}
							} 
							break;
						}
						case 'rangePlusMinusAbsoluteValueIn': {
							if ((value1 || (value1 === 0)) && (value2 || (value2 === 0))) {
								if (not) {
									returnValue = T('attrRetrieval_cValueRange.js/rangePlusMinusAbsoluteIsNotIn_TXT','$[1] ± $[2] is not in $[0]', [this.name, value1, value2]);
								}
								else {
									returnValue = T('attrRetrieval_cValueRange.js/rangePlusMinusAbsoluteIsIn_TXT','$[1] ± $[2] is in $[0]', [this.name, value1, value2]);
								}
							} 
							break;
						}
						case 'rangeFromToPartlyIn': {
							if ((value1 || (value1 === 0)) && (value2 || (value2 === 0))) {
								if (not) {
									returnValue = T('attrRetrieval_cValueRange.js/rangeFromToIsNotPartlyIn_TXT','$[1] … $[2] is not partly in $[0]', [this.name, value1, value2]);
								}
								else {
									returnValue = T('attrRetrieval_cValueRange.js/rangeFromToIsPartlyIn_TXT','$[1] … $[2] is partly in $[0]', [this.name, value1, value2]);
								}
							} 
							break;
						}
						case 'rangeFromToIn': {
							if ((value1 || (value1 === 0)) && (value2 || (value2 === 0))) {
								if (not) {
									returnValue = T('attrRetrieval_cValueRange.js/rangeFromToIsNotIn_TXT','$[1] … $[2] is not in $[0]', [this.name, value1, value2]);
								}
								else {
									returnValue = T('attrRetrieval_cValueRange.js/rangeFromToIsIn_TXT','$[1] … $[2] is in $[0]', [this.name, value1, value2]);
								}
							} 
							break;
						}
						case 'rangePlusMinusAbsoluteValuePartlyIn': {
							if ((value1 || (value1 === 0)) && (value2 || (value2 === 0))) {
								if (not) {
									returnValue = T('attrRetrieval_cValueRange.js/rangePlusMinusAbsoluteIsNotPartlyIn_TXT','$[1] ± $[2] is not partly in $[0]', [this.name, value1, value2]);
								}
								else {
									returnValue = T('attrRetrieval_cValueRange.js/rangePlusMinusAbsoluteIsPartlyIn_TXT','$[1] ± $[2] is partly in $[0]', [this.name, value1, value2]);
								}
							} 
							break;
						}
						case 'rangePlusMinusPercentageIn': {
							if ((value1 || (value1 === 0)) && (value2 || (value2 === 0))) {
								if (not) {
									returnValue = T('attrRetrieval_cValueRange.js/rangePlusMinusPercentageIsNotIn_TXT','$[1] ± $[2]% is not in $[0]', [this.name, value1, value2]);
								}
								else {
									returnValue = T('attrRetrieval_cValueRange.js/rangePlusMinusPercentageIsIn_TXT','$[1] ± $[2]% is in $[0]', [this.name, value1, value2]);
								}
							} 
							break;
						}
						case 'rangePlusMinusPercentagePartlyIn': {
							if ((value1 || (value1 === 0)) && (value2 || (value2 === 0))) {
								if (not) {
									returnValue = T('attrRetrieval_cValueRange.js/rangePlusMinusPercentageIsNotPartlyIn_TXT','$[1] ± $[2]% is not partly in $[0]', [this.name, value1, value2]);
								}
								else {
									returnValue = T('attrRetrieval_cValueRange.js/rangePlusMinusPercentageIsPartlyIn_TXT','$[1] ± $[2]% is partly in $[0]', [this.name, value1, value2]);
								}
							} 
							break;
						}
						case 'rangeInRangePlusMinusAbsolute': {
							if ((value1 || (value1 === 0)) && (value2 || (value2 === 0))) {
								if (not) {
									returnValue = T('attrRetrieval_cValueRange.js/rangeNotInRangePlusMinusAbsolute_TXT','$[0] is not in $[1] ± $[2]', [this.name, value1, value2]);
								}
								else {
									returnValue = T('attrRetrieval_cValueRange.js/rangeInRangePlusMinusAbsolute_TXT','$[0] is in $[1] ± $[2]', [this.name, value1, value2]);
								}
							} 
							break;
						}
						case 'rangeInRangePlusMinusPercentage': {
							if ((value1 || (value1 === 0)) && (value2 || (value2 === 0))) {
								if (not) {
									returnValue = T('attrRetrieval_cValueRange.js/rangeNotInRangePlusMinusPercentage_TXT','$[0] is not in $[1] ± $[2]%', [this.name, value1, value2]);
								}
								else {
									returnValue = T('attrRetrieval_cValueRange.js/rangeInRangePlusMinusPercentage_TXT','$[0] is in $[1] ± $[2]%', [this.name, value1, value2]);
								}
							} 
							break;
						}
						case 'rangeInRangeFromTo': {
							if ((value1 || (value1 === 0)) && (value2 || (value2 === 0))) {
								if (not) {
									returnValue = T('attrRetrieval_cValueRange.js/rangeNotInRangeFromTo_TXT','$[0] is not in $[1]  $[2]%', [this.name, value1, value2]);
								}
								else {
									returnValue = T('attrRetrieval_cValueRange.js/rangeInRangeFromTo_TXT','$[0] is in$[1]  $[2]%', [this.name, value1, value2]);
								}
							} 
							break;
						}
						case 'valueIsExactlySizeOfRange': {	
							if ((value1 || (value1 === 0)) && (value2 || (value2 === 0))) {
								if (not) {
									returnValue = T('attrRetrieval_cValueRange.js/valueIsNotExactlySizeOfRange_TXT','not ($[1] = size of $[0])', [this.name, value1]);
								}
								else {
									returnValue = T('attrRetrieval_cValueRange.js/valueIsExactlySizeOfRange_TXT','$[1] = size of $[0]', [this.name, value1]);
								}
							} 
							break;
						}
						case 'valueIsLessThanSizeOfRange': {
							if ((value1 || (value1 === 0)) && (value2 || (value2 === 0))) {
								if (not) {
									returnValue = T('attrRetrieval_cValueRange.js/valueIsNotLessThanSizeOfRange_TXT','not ($[1] < size of $[0])', [this.name, value1]);
								}
								else {
									returnValue = T('attrRetrieval_cValueRange.js/valueIsLessThanSizeOfRange_TXT','$[1] < size of $[0])', [this.name, value1]);
								}
							} 
							break;
						}
						case 'valueIsGreaterThanSizeOfRange': {
							if ((value1 || (value1 === 0)) && (value2 || (value2 === 0))) {
								if (not) {
									returnValue = T('attrRetrieval_cValueRange.js/valueIsNotGreaterThanSizeOfRange_TXT','not ($[1] > size of $[0])', [this.name, value1]);
								}
								else {
									returnValue = T('attrRetrieval_cValueRange.js/valueIsGreaterThanSizeOfRange_TXT','$[1] > size of $[0]', [this.name, value1]);
								}
							} 
							break;
						}
						case 'exists': {
							returnValue = T('attrRetrieval_cValueRange.js/hasAValue_TXT','$[0] has a value', [this.name]);
							break;
						}
					} // end-of-switch
				}
			}
			return (returnValue);
		}, // end-of-method _parseQuery
		
	
		'postMixInProperties' : function() {
			// If you provide a postMixInProperties method for your widget, 
			// it will be invoked before rendering occurs, and before 
			// any dom nodes are created. If you need to add or change the 
			// instance's properties before the widget is rendered 
			// - this is the place to do it.
			this.inherited(arguments);

			//localise the necessary variables
			this.locateProperties(['searchMode', 'value1', 'value2', 'name']);

			// initialisation of variables 
			disabled='';
			constraintsValue1='';
			constraintsValue2='';

			if (!this.searchMode) {
				this.searchMode ='valueIn';
			}		
			if (!this.not) {
				this.not = false;
			}		
			if (!this.value1) {
				this.value1 ='';
			}		
			if (!this.value2) {
				this.value2 ='';
			}		
			
			switch ( true ) {
				case ((this.searchMode === 'rangeFromToIn') ||
					(this.searchMode === 'rangeFromToPartlyIn')):
					{
						disabled='';
						if(this.value2)
							constraintsValue1="constraints='{max:"+this.value2+"}'";
						if(this.value1)
							constraintsValue2="constraints='{min:"+this.value1+"}'";
						break;
					}
				case ((this.searchMode === 'valueIn') ||
					(this.searchMode === 'valueBelow') ||
					(this.searchMode === 'valueAbove') ):
					{
						disabled='disabled';
						break;
					}
				default :
					break;
			}		
			
			var checked = "";
			if (this.not == true) {
				checked = " checked='checked'";
			}
			this.title = T('attrRetr_cValRng.js/SearchParas_TIT','Search parameters');
			
			// expand the template string
			this.addTemplateSection(""
				+"<tr>"
					+"<td class='textRight' width='30%'>" + T('attrRetr_cValRng.js/ChSearchMode_LBL', 'Choose search mode:') + "</td>"
					+"<td width='70%'>"
						+"<select style='width:100%'"
							+"value='${searchMode}'" 
							+"dojoAttachEvent='onChange:values_changed' "
							+"dojoAttachPoint='searchMode_S' "
							+"dojoType='dijit.form.Select'"
						+">"
							+"<option value='valueIn'>"
								+T('attrRetr_cValRng.js/srchOpt_valueIn_TXT', 'value1 is in ${name}')
							+"</option>"
							+"<option value='valueBelow'>"
								+T('attrRetr_cValRng.js/srchOpt_valueBelowIn_TXT', 'value1 is below (<) ${name}')
							+"</option>"
							+"<option value='valueAbove'>"
								+T('attrRetr_cValRng.js/srchOpt_valueAboveIn_TXT', 'value1 is above (>) ${name}')
							+"</option>"
							+"<option type='separator'></option>"
							+"<option value='rangePlusMinusAbsoluteValueIn'>"
								+T('attrRetr_cValRng.js/srchOpt_rangePlusMinusAbsoluteValueIn_TXT', 'value1 ± value2 is in ${name}') 
							+"</option>"
							+"<option value='rangePlusMinusPercentageIn'>" 
								+T('attrRetr_cValRng.js/srchOpt_rangePlusMinusPercentageIn_TXT', 'value1 ± value2 % is in ${name}') 
							+"</option>"
							+"<option value='rangeFromToIn'>" 
								+T('attrRetr_cValRng.js/srchOpt_rangeFromToIn_TXT', 'value1 … value2 is in ${name}') 
							+"</option>"
							+"<option type='separator'></option>"
							+"<option value='rangePlusMinusAbsoluteValuePartlyIn'>"
								+T('attrRetr_cValRng.js/srchOpt_rangePlusMinusAbsoluteValuePartlyIn_TXT', 'value1 ± value2 is partly in ${name}') 
							+"</option>"
							+"<option value='rangePlusMinusPercentagePartlyIn'>" 
								+T('attrRetr_cValRng.js/srchOpt_rangePlusMinusPercentagePartlyIn_TXT', 'value1 ± value2 % is partly in ${name}') 
							+"</option>"
							+"<option value='rangeFromToPartlyIn'>" 
								+T('attrRetr_cValRng.js/srchOpt_rangeFromToPartlyIn_TXT', 'value1 … value2 is partly in ${name}') 
							+"</option>"
							+"<option type='separator'></option>"
							+"<option value='rangeInRangePlusMinusAbsolute'>" 
								+T('attrRetr_cValRng.js/srchOpt_rangeInRangePlusMinusAbsolute_TXT', '${name} is in value1 ± value2') 
							+"</option>"
							+"<option value='rangeInRangePlusMinusPercentage'>" 
								+T('attrRetr_cValRng.js/srchOpt_rangeInRangePlusMinusPercentage_TXT', '${name} is in value1 ± value2 %') 
							+"</option>"
							+"<option value='rangeInRangeFromTo'>" 
								+T('attrRetr_cValRng.js/srchOpt_rangeInRangeFromTo_TXT', '${name} is in value1 … value2') 
							+"</option>"
							+"<option type='separator'></option>"
							+"<option value='valueIsExactlySizeOfRange'>" 
								+T('attrRetr_cValRng.js/srchOpt_valueIsExactlySizeOfRange_TXT', 'value1 = size of ${name}') 
							+"</option>"
							+"<option value='valueIsLessThanSizeOfRange'>" 
								+T('attrRetr_cValRng.js/srchOpt_valueIsLessThanSizeOfRange_TXT', 'value1 < size of ${name}') 
							+"</option>"
							+"<option value='valueIsGreaterThanSizeOfRange'>" 
								+T('attrRetr_cValRng.js/srchOpt_valueIsGreaterThanSizeOfRange_TXT', 'value1 > size of ${name}') 
							+"</option>"
							+"<option type='separator'></option>"
							+"<option value='exists'>"
								+T('attrRetr_cValRng.js/srchOpt_exists_TXT', '${name} has a value')
							+ "</option>"
						+"</select>"
					+"</td>"
				+"</tr>"	
				+"<tr>"
					+"<td class='textRight' width='30%'> </td>"
					+"<td width='70%'>"
						+"<input type='checkbox'"
							+" value='1'"
							+checked
							+" dojoAttachEvent='onChange:values_changed'"
							+" dojoAttachPoint='not_cB'"
							+" dojoType='dijit.form.CheckBox'"
						+"/>"
						+" "
						+T('attrRetrieval_cNumber.js/Not_LBL', 'Negate condition of search mode')
					+"</td>"
				+"</tr>"
				+"<tr>"
					+"<td class='textRight' width='30%'>" + T('attrRetr_cValRng.js/Val_1_LBL', 'alue<sub>1</sub>:') + "</td>"
					+"<td width='70%'>"
						+"<input type='text' style='width:100%'"
							+"value='${value1}'" 
							+"dojoAttachEvent='onChange:values_changed' "
							+"dojoAttachPoint='value1_nTB' "
							+"dojoType='dijit.form.NumberTextBox'"
							+"required='true'"
							+constraintsValue1
						+"/>"
					+"</td>"
				+"</tr>"	
				+"<tr>"
					+"<td class='textRight' width='30%'>" + T('attrRetr_cValRng.js/Val_2_LBL', 'value<sub>2</sub>:') + "</td>"
					+"<td width='70%'>"
						+"<input type='text' style='width:100%'"
							+"value='${value2}'" 
							+"dojoAttachEvent='onChange:values_changed' "
							+"dojoAttachPoint='value2_nTB' "
							+"dojoType='dijit.form.NumberTextBox'"
							+"required='true'"
							+disabled
							+constraintsValue2
						+"/>"
					+"</td>"
				+"</tr>"	
				+"<tr>"
					+"<td class='textRight' width='30%'>"
						+T('attrRetr_cValRng/SearchRemarks_TXT','Remarks:')
					+"</td>"				
					+"<td width='70%'>"
						+"<ul>"
							+"<li>"
								+T('attrRetr_cValRng.js/SelSrchModeFor_HTM', 'You can select one of the following search modes:')
								+"<ul>"
									+"<li>" 
										+T('attrRetr_cValRng.js/srchTips_valueIn_HTM','<strong>«value1 is in ${name}»</strong> finds all objects where <code>value<sub>1</sub></code> is within the range spanned by «${name}». ') 
									+"</li>"
									+"<li>" 
										+T('attrRetr_cValRng.js/srchTips_valueBelow_HTM','<strong>«value1 is below (<) ${name}»</strong> finds all objects where <code>value<sub>1</sub></code> is less than the lower margin of the range spanned by «${name}». ') 
									+"</li>"
									+"<li>" 
										+T('attrRetr_cValRng.js/srchTips_valueAbove_HTM','<strong>«value1 is above (>) ${name}»</strong> finds all objects where <code>value<sub>1</sub></code> is greater than the upper margin of the range spanned by «${name}». ') 
									+"</li>"
									+"<li>" 
										+T('attrRetr_cValRng.js/srchTips_rangePlusMinusAbsoluteValueIn_HTM','<strong>«value1 ± value2 is in ${name}»</strong> finds all objects where the range from <code>value<sub>1</sub></code> - <code>value<sub>2</sub></code> to <code>value<sub>1</sub></code> + <code>value<sub>2</sub></code> is completely within the range spanned by «${name}». ') 
									+"</li>"
									+"<li>" 
										+T('attrRetr_cValRng.js/srchTips_rangePlusMinusPercentageIn_HTM','<strong>«value1 ± value2 % is in ${name}»</strong> finds all objects where the range from <code>value<sub>1</sub></code> - <code>(value<sub>2</sub>% of value<sub>1</sub>)</code> to <code>value<sub>1</sub></code> + <code>(value<sub>2</sub>% of value<sub>1</sub>)</code> is completely within the range spanned by «${name}».') 
									+"</li>"
									+"<li>" 
										+T('attrRetr_cValRng.js/srchTips_rangeFromToIn_HTM','<strong>«value1 … value2 is in ${name}»</strong> finds all objects where the range from <code>value<sub>1</sub></code> to <code>value<sub>2</sub></code> is completely within the range spanned by «${name}».<br /><code>value<sub>1</sub></code> and <code>value<sub>2</sub></code> may be swapped.') 
									+"</li>"
									+"<li>" 
										+T('attrRetr_cValRng.js/srchTips_rangePlusMinusAbsoluteValuePartlyIn_HTM','<strong>«value1 ± value2 is partly in ${name}»</strong> finds all objects where ont of the margins of the range spanned by «${name}» is within the range from <code>value<sub>1</sub></code> - <code>value<sub>2</sub></code> to <code>value<sub>1</sub></code> + <code>value<sub>2</sub></code> and the other one is outside.') 
									+"</li>"
									+"<li>" 
										+T('attrRetr_cValRng.js/srchTips_rangePlusMinusPercentagePartlyIn_HTM','<strong>«value1 ± value2 % is partly in ${name}»</strong> finds all objects where one of the margins of the range spanned by «${name}» is completely the range from <code>value<sub>1</sub></code> - <code>(value<sub>2</sub>% of value<sub>1</sub>)</code> to <code>value<sub>1</sub></code> + <code>(value<sub>2</sub>% of value<sub>1</sub>)</code> and the other one is outside.') 
									+"</li>"
									+"<li>" 
										+T('attrRetr_cValRng.js/srchTips_rangeFromToPartlyIn_HTM','<strong>«value1 … value2 % is partly in ${name}»</strong> finds all objects where one of the margins of the range spanned by «${name}» is within the range from <code>value<sub>1</sub></code> to <code>value<sub>2</sub></code> and the other one is outside. <br /><code>value<sub>1</sub></code> and <code>value<sub>2</sub></code> may be swapped.') 
									+"</li>"
									+"<li>" 
										+T('attrRetr_cValRng.js/srchTips_rangeInRangePlusMinusAbsolute_HTM','<strong>«${name} is in value1 ± value2»</strong> finds all objects where the range spanned by «${name}» is completely within the range from <code>value<sub>1</sub></code> - <code>value<sub>2</sub></code> to <code>value<sub>1</sub></code> + <code>value<sub>2</sub></code>. ') 
									+"</li>"
									+"<li>" 
										+T('attrRetr_cValRng.js/srchTips_rangeInRangePlusMinusPercentage_HTM','<strong>«${name} is in value1 ± value2 %»</strong> finds all objects where the range spanned by «${name}» is completely within the range from <code>value<sub>1</sub></code> - <code>(value<sub>2</sub>% of value<sub>1</sub>)</code> to <code>value<sub>1</sub></code> + <code>(value<sub>2</sub>% of value<sub>1</sub>)</code>. ') 
									+"</li>"
									+"<li>" 
										+T('attrRetr_cValRng.js/srchTips_rangeInRangeFromTo_HTM','<strong>«${name} is in value1 … value2»</strong> finds all objects where the range spanned by «${name}» is completely within the range from <code>value<sub>1</sub></code> to <code>value<sub>2</sub></code>. <br /><code>value<sub>1</sub></code> and <code>value<sub>2</sub></code> may be swapped.') 
									+"</li>"
									+"<li>" 
										+T('attrRetr_cValRng.js/srchTips_valueIsExactlySizeOfRange_HTM','<strong>«value1 = size of ${name}»</strong> finds all objects where <code>value<sub>1</sub></code> is equal to the diference between the upper and the lower margin of the range spanned by «${name}».') 
									+"</li>"
									+"<li>" 
										+T('attrRetr_cValRng.js/srchTips_valueIsLessThanSizeOfRange_HTM','<strong>«value1 < size of ${name}»</strong> finds all objects where <code>value<sub>1</sub></code> is less than the diference between the upper and the lower margin of the range spanned by «${name}».') 
									+"</li>"
									+"<li>" 
										+T('attrRetr_cValRng.js/srchTips_valueIsGreaterThanSizeOfRange_HTM','<strong>«value1 > size of ${name}»</strong> finds all objects where <code>value<sub>1</sub></code> is greater than the difference between the upper and the lower margin of the range spanned by «${name}».') 
									+"</li>"
									+"<li>" 
										+T('attrRetr_cValRng.js/srchTips_exists_HTM','<strong>«${name} has a value»</strong> finds all objects where «${name}» specifies a range, that means a lower and a upper margin are defined.') 
									+"</li>"
								+"</ul>"
							+"</li>"
							+"<li>"
								+T('attrRetrieval_cNumber.js/SelNot_HTM', 'Negating the condition of the search mode results in a logical not in the query condition.')
							+"</li>"
						+"</ul>"
					+"</td>"
				+"</tr>"	
			);
			
			// generate the template string
			this.generateTemplateString();
			
		}, // end-of-method postMixInProperties
		
		
		'postCreate': function(){
			this._adaptInputForm();
		}, // end-of-method postCreate
		
		
		'_end_': null
		
	}
);
