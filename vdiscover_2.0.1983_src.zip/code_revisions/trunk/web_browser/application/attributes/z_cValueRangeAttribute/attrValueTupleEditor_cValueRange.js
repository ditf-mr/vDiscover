﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare("application.widgets.valueTupleEditor_numericRange",[application.widgets.valueTupleEditor_generic],{
	
	'textBoxMin' : null, // dijit.form.NumberTextBox
	'textBoxMax' : null, // dijit.form.NumberTextBox
	
	'buildTemplateContainer' : function() {
		// unit
		var units=this.config.unitsAsString.split('\n');
		var unit=units[0];
		if(units.length>1) {
			unit=""
				+"<select "
					+"dojoType='dijit.form.ComboBox' "
					+"dojoAttachEvent='onChange:notifyAttributeOfChangedValue' "
					+"dojoAttachPoint='unitSelector_widget' "
					+"class='fullWidth' "
					+"value='"+units[0]+"' "
				+">"
					+"<option>"+units.join("</option><option>")+"</option>"
				+"</select>"
				;
		} // end if

		this.templateContainer = ''
			+'<div class="cNumericRange_VTE_outer">'
				+'<div dojoAttachPoint="textBoxOuter" class="cNumericRange_VTE_cV">'
				+'</div>'
				+'<div class="cNumericRange_VTE_unit">'
					+unit
				+'</div>'
			+'</div>'
			;
	} // end of method postMixInProperties
	,
	'postCreate' : function () {
		this.inherited(arguments);
				
		var formatOptions = {};
		if (this.config.formatDisplay){ // number format
			formatOptions.pattern = this.config.formatDisplay;
		}

		var constraints = {	pattern: this.config.format },
			title = '';
		if (this.config.minValue!=null) {
			constraints.min=this.config.minValue;
			title += '['+dojo.number.format(this.config.minValue, formatOptions);
		} // end if
		if (this.config.maxValue!=null) {
			constraints.max=this.config.maxValue;
			title += ((title.length)?' 	… ':'')+dojo.number.format(this.config.maxValue, formatOptions)+']';
		} else {
			title += ((title.length)?' 	… ':'');
		} // end if
		
		// textbox for the min value
		this.textBoxMin = new dijit.form.NumberTextBox({
			'title':				title,
			'required': 			(this.config.mustBeSet==true),
			'class':				'RS_VTE_number_RangeNumber cNumberAttribute_VTE_cV_tB',
			'value':				this.valueTuple.value_rangeMin,
			//'intermediateChanges' : true, // this must be deactivated!
			'selectOnClick': 		true
		}).placeAt(this.textBoxOuter);
		this._supportingWidgets.push(this.textBoxMin);
		
		// set the default value if necessary
		if (		!this.textBoxMin.attr('value') 
				&& 	this.config.defaultValue_rangeMin 
				&& 	this.config.defaultValue_rangeMin.length 
			)	this.textBoxMin.attr('value', this.config.defaultValue_rangeMin);
		
		this.textBoxMin.attr('constraints', constraints);
		this.connect(this.textBoxMin,'onChange','notifyAttributeOfChangedValue');
		
		// add ... to the textbox
		dojo.create('div',{ 'class': 'RS_VTE_number_RangeSign', innerHTML:'…'},this.textBoxOuter);
		
		// textbox for the max value
		this.textBoxMax = new dijit.form.NumberTextBox({
			'title':				title,
			'required': 			(this.config.mustBeSet==true),
			'class':				'RS_VTE_number_RangeNumber cNumberAttribute_VTE_cV_tB',
			'value':				this.valueTuple.value_rangeMax,
			// 'intermediateChanges' : true, // this must be deactivated!
			'selectOnClick': 		true
		}).placeAt(this.textBoxOuter);
		this._supportingWidgets.push(this.textBoxMax);
		
		// set the default value if necessary
		if (		!this.textBoxMax.attr('value') 
				&& 	this.config.defaultValue_rangeMax 
				&& 	this.config.defaultValue_rangeMax.length 
			)	this.textBoxMax.attr('value', this.config.defaultValue_rangeMax);

		this.textBoxMax.attr('constraints', constraints);
		this.connect(this.textBoxMax,'onChange', 'notifyAttributeOfChangedValue');
		
		// set the unit, if necessary
		if(this.unitSelector_widget) {
			//		no unit yet? -> set the first unit as default value
			this.unitSelector_widget.attr('value', (this.valueTuple.unit?this.valueTuple.unit:this.config.unitsAsString.split('\n')[0]));
		} // end if there is a unit selector
		
	} // end of method postCreate
	,
	'notifyAttributeOfChangedValue' : function () {
		// this method informs the connected attribute about the changed value tuple
		
		if (this.isValid()) this.attrWidget.valueTupleHasChanged(this.valueTupleUUID, this.getValueTuple());
	} // end of method notifyAttributeOfChangedValue
	,
	'getValueTuple' : function () {
		// unit
		var units=this.config.unitsAsString.split('\n'),
			unit=units[0];
		if (this.unitSelector_widget) {
			unit = this.unitSelector_widget.attr('value');
			// if the entered unit is not valid, choose automatically the first given unit
			if(dojo.indexOf(units,unit)==-1) {
				unit=units[0];
				this.unitSelector_widget.attr('value', unit);
			} // end if
		} // end if

		// value_rangeMin
		var value_rangeMin = this.textBoxMin.attr('value');

		// value_rangeMax
		var value_rangeMax = this.textBoxMax.attr('value');

		return {
			'value_rangeMin': 	value_rangeMin,
			'value_rangeMax': 	value_rangeMax,
			'AV_UUID' 		: 	this.valueTuple.AV_UUID,
			'UUID'			:	this.valueTuple.UUID,
			'unit'			:	unit,
			'positionOfValue' : this.valueTuple.positionOfValue			
		};
	} // end of method getValueTuple
	,
	'isValid' : function () {
		var isValid = (this.textBoxMin.isValid() && this.textBoxMax.isValid());
		if(this.config.mustBeSet) 	isValid = isValid && !this.attrWidget.tuple_isEmpty(this.getValueTuple() );
		return isValid;
	} // end of method isValid
});
