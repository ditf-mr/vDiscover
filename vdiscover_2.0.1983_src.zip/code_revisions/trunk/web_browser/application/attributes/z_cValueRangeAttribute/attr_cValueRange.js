﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare("application.widgets.cValueRangeAttribute",[application.widgets.standardAttribute],{
	'_emptyValueTuple': { 
		'value_rangeMin' :	'', 
		'value_rangeMax' :	'', 
		'unit' :			''
	}
	,
	'valueTupleEditor_name': 'application.widgets.valueTupleEditor_numericRange'
	,
	'tuple_isEmpty' : function (tuple) {
		var isEmpty = false;
		if(		
				!(tuple.value_rangeMin.toString().length)
			||	!(tuple.value_rangeMax.toString().length)
			||	isNaN(tuple.value_rangeMin) 
			||	isNaN(tuple.value_rangeMax) 
			) isEmpty=true;
		return isEmpty;
	} // end of method tuple_isEmpty
	,
	'htmlFormatValueTuple_readMode' : function (valueTuple) {
		var formatOptions = {};
		if (this.config.formatDisplay) formatOptions.pattern = this.config.formatDisplay;
		var units 		= this.config.unitsAsString.split('\n'),
			first_unit 	= units[0],
			unit 		= valueTuple.unit?valueTuple.unit:first_unit,
			numberOutput= '';
		
		// format the numbers -- together or on it's own
		numberOutput		= ''
			+'<code>'
				+dojo.number.format(valueTuple.value_rangeMin, formatOptions) 
			+'</code>';
		if (valueTuple.value_rangeMin!=valueTuple.value_rangeMax) {
			numberOutput	+= ''
				+'&nbsp;…&nbsp;'
				+'<code>'
					+dojo.number.format(valueTuple.value_rangeMax, formatOptions) 
				+'</code>';
		} // end if
		
		return numberOutput
			+'&nbsp;'
			+unit
			;
	} // end of method htmlFormatValueTuple_ReadMode
	/*,
	htmlFormatTupleSet_readMode : function (valueTuples) {
		// return the standard value set formatting + the unit, afterwards
		// (although this is maybe not a good idea, if there is HTML block formatting)
		var fTS = this.inherited(arguments);
		if(fTS==this._noValueSet) return this._noValueSet;
		return '<code>'+this.inherited(arguments)+'</code>' + (this.config.unit?'&nbsp;'+this.config.unit:'');
	} // end of method htmlFormatTupleSet_readMode
	*/
}); // end of declaration
