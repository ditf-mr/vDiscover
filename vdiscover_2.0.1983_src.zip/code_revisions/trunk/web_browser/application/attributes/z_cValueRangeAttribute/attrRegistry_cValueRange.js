/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

application.attributeKinds.register({kind: "cValueRangeAttribute", 
	defaultConfiguration : { 
		format:'###,###.##',
		cardinality: 1, 
		unitsAsString:'',
		minValue:'',
		maxValue:'',
		svFormatActivated: false,
		svHtmlBefore: '',
		svHtmlBetween: '',
		svHtmlAfter: ''		
	}
	,
	// defaultValues:['value_rangeMin','value_rangeMax']
	// ,
	widgetClass: 'application.widgets.cValueRangeAttribute'
	,
	configurationWidgetClass : 'application.widgets.configureAttributes.cNumberAttribute'
	,
	'useValueTupleAsExpressionInput'	: false
	,
	'expressionsPermitted'				: false
	,
	
});
