/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare('application.widgets.configureAttribute.genericConfigurationWidget',[dijit._Widget,dijit._Templated],{
	
	// these properties need to be set on initialisation
	'dialog'	: null // the dialog widget
	,
	'attrItem'	: null // dojo store item
	,
	
	'postMixInProperties'	: function () {
		this.inherited(arguments);
	
		if(typeof this.dialog 	!= 'object') throw ''+this.declaredClass+'.postMixInProperties() : no  dialog object passed. Aborting.';
		if(typeof this.attrItem != 'object') throw ''+this.declaredClass+'.postMixInProperties() : no  attrItem object passed. Aborting.';
	
		this.UUID = this.dialog.currentUUID;
	
		this.locateProperties(['name', 'kind', 'isInherited']);
	
		if(!this.isInherited) this.isInherited=false;
	
	} // end of method postMixInProperties
	,
	'locateProperties' : function (propertyNameArray) {
		// this method localises the passed property names.
		
		if (arguments.length==0) return;
		
		// comfort function for single properties
		if (typeof propertyNameArray=='string') propertyNameArray=[propertyNameArray];
				
		dojo.forEach(propertyNameArray,function(propertyName){
			if (typeof propertyName == 'undefined') return; /* Internet Explorer bugfix */
			var value = this.dialog.attrStore.getValue(this.attrItem, propertyName);
			if (typeof value=='undefined') value='';
			this[propertyName] = value;
		},this);
		
	} // end of method locateProperties
	,
	'propertyHasChanged' : function (propertyName, newPropertyValue /* optional */) {
		// this method notifies the attribute management dialog about a changed configuration property
		// property needs to be a string.

		if(typeof this[propertyName]=="undefined") throw 'propertyHasChanged: The property "'+propertyName+'" does not exist.';
		
		var newValue = ((typeof newPropertyValue!= "undefined")?newPropertyValue:this[propertyName]);
		
		this.dialog.changeAttribute( propertyName, newValue );
		
		this[propertyName]=newValue;
	} // end of method changeProperty
	,
	'templateSections' : null
	,
	'addTemplateSection' : function(s) {
		if(!this.templateSections) this.templateSections = [];
		
		this.templateSections.push(s);
	} // end of method addTemplateSection
	,
	'commentTemplates' : null
	,
	'addCommentTemplateSection' : function(s) {
		if(!this.commentTemplates) this.commentTemplates = [];
		
		this.commentTemplates.push(s);
	} // end of method addTemplateSection
	,
	'generateTemplateString' : function () {
	
		var commentTemplates = '';
	
		if (this.commentTemplates) commentTemplates=this.commentTemplates.join('');
	
		this.templateString = ""
			+"<div class='RS_attributeConfig_section'>"
				+"<table class='fullWidth arrangement3070 listWithRows'><tbody>"
					+this.templateSections.join('')
				+"</tbody></table>"
				+commentTemplates
			+"</div>"
			;
	} // end of method generateTemplateString
	,
	'showEditHints' : function (hintType){
		this.dialog.showEditHints(hintType);
	} // end of method showEditHints
	,
	'showRegexEditHints' : function (){
		this.showEditHints('regex');
	} // end of method showRegexEditHints
	,
	'showDateTimeEditHints' : function (){
		this.showEditHints('time');
	} // end of method showDateTimeEditHints
	,
	'showMimeTypeEditHints' : function (){
		this.showEditHints('mimeTypes');
	} // end of method showMimeTypeEditHints
	,
	'showFuzzyValueEditHints' : function (){
		this.showEditHints('fuzzyValue');
	} // end of method showMimeTypeEditHints
	,
	'showKeyValuePairEditHints' : function (){
		this.showEditHints('keyValuePair');
	} // end of method showMimeTypeEditHints
	,
	'showNumberEditHints' : function (){
		this.showEditHints('number');
	} // end of method showMimeTypeEditHints
	,
	
	// internal variables / slots
	'UUID'	: null 	// UUID string
	,
	
	// some settings
	
	'widgetsInTemplate'		: true
	,

});

