﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare( 'application.widgets.valueTupleEditor_timePoint',
	[application.widgets.valueTupleEditor_generic], {
	'dateBox' : null, // dijit.form.DateTextBox
	'timeBox' : null, //dijit.form.TimeTextBox

	'buildTemplateContainer' : function() {
		this.templateContainer = ''
			// +'<div>'
				+'<div class="RS_VTE_date" dojoAttachPoint="dateBoxNode"></div>'
				+'&nbsp;'
				+'<div class="RS_VTE_time" dojoAttachPoint="timeBoxNode"></div>'
			// +'</div>'
			;
			}, // end-of-method buildTemplateContainer
			
	'postCreate' : function () {
		this.inherited(arguments);
		// prepare the timepoint value
		var value = this.valueTuple.value_timepoint; // string
		var useDefaultValue=false;
		if ( value ) {
					value = value.replace(' ', 'T');
		} else if (this.config.currentAsDefault) {
			value = new Date();
			value = dojo.date.stamp.toISOString(value, {selector: 'date'})+dojo.date.stamp.toISOString(value, {selector: 'time'});
			useDefaultValue = true;
		} // end check current value
		value=new Date(value);
		// create the widget for the date editor
		var dateConstraints = {'datePattern': this.config.dateFormat};
		if (!this.config.futureValuesAllowed) 
			dateConstraints.max = dojo.date.stamp.toISOString(new Date(), {'selector': 'date'});
		if (!this.config.pastValuesAllowed)   
			dateConstraints.min = dojo.date.stamp.toISOString(new Date(), {'selector': 'date'});
		
		this.dateBox = new dijit.form.DateTextBox({
			'required' 				: (this.config.mustBeSet==true),
			'value' 				: value,
			'style' 				: 'width:100%;',
			'constraints' 			: dateConstraints,
		}).placeAt(this.dateBoxNode);
		this._supportingWidgets.push( this.dateBox );
		this.connect(this.dateBox, 'onChange', this.notifyAttributeOfChangedValue );
		
		//create the widget for the time editor
		this.timeBox = new dijit.form.TimeTextBox({
			'required' 				: (this.config.mustBeSet==true),
			'value' 				: value,
			'style' 				: 'width:100%;',
			'constraints' 			: {timePattern: this.config.timeFormat},
			'intermediateChanges' 	: true
		}).placeAt(this.timeBoxNode);
		this._supportingWidgets.push( this.timeBox );
		this.connect(this.timeBox, 'onChange', this.notifyAttributeOfChangedValue );
		
		// hide not required input boxes
		if(!this.config.showDate) dojo.style(this.dateBoxNode,'display','none');
		if(!this.config.showTime) dojo.style(this.timeBoxNode,'display','none');
		
		// was a default value generated? If yes, notify the attribute widget about this change.
		if (useDefaultValue) this.notifyAttributeOfChangedValue();
			}, // end-of-method postCreate
		
	'getValueTuple' : function () {
		// this method returns the current value tuple -- whether it is valid or not
		var date = this.dateBox.attr('value'); // object of type Date
		var time = this.timeBox.attr('value'); // object of type Date
		var dateTime=	(		((date)?dojo.date.stamp.toISOString(date,{selector:'date'}):'0001-01-01')
							+	((time)?dojo.date.stamp.toISOString(time,{selector:'time'}):'T00:00:00')
						).replace('T'," ");
		return {
			'value_timepoint'	: 	dateTime,
			'AV_UUID' 			: 	this.valueTuple.AV_UUID,
			'UUID'				:	this.valueTuple.UUID,
			'positionOfValue' 	: 	this.valueTuple.positionOfValue
		};
			}, // end-of-method getValueTuple
		
	'notifyAttributeOfChangedValue' : function () {
		// this method informs the connected attribute about the changed value tuple
		// invalid input? -> return
		if (!this.isValid()) return;
				this.attrWidget.valueTupleHasChanged(this.valueTupleUUID, this.getValueTuple());
			}, // end-of-method notifyAttributeOfChangedValue
			
	'isValid' : function () {
		var isValid=true;
		if(this.config.mustBeSet) 	isValid = isValid && !this.attrWidget.tuple_isEmpty(this.getValueTuple());
		if(this.config.showDate) 	isValid = isValid && this.dateBox.isValid();
		if(this.config.showTime) 	isValid = isValid && this.timeBox.isValid();
		return isValid;
			}, // end-of-method isValid
}); // end-of-declaration

