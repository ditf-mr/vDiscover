﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare(
	'application.widgets.cDateTimeAttribute',
	[application.widgets.standardAttribute],
	{
		'_emptyValueTuple': { 'value_timepoint': '' },
		
		'valueTupleEditor_name': 'application.widgets.valueTupleEditor_timePoint',
		
'tuple_isEmpty' : function (tuple) {
	var isEmpty = false;
			if (!(tuple.value_timepoint.length)) {
				isEmpty = true;
			}
	return isEmpty;
		}, // end-of-method tuple_isEmpty
		
'htmlFormatValueTuple_readMode' : function (valueTuple) {
	var formatOptions = {};
			if (this.config.dateFormat)	{
				formatOptions.datePattern = this.config.dateFormat;
			}
			if (this.config.timeFormat)	{
				formatOptions.timePattern = this.config.timeFormat;
			}
	if (this.config.showDate && !this.config.showTime){ // display time, date or both
		formatOptions.selector = 'date';
	} else if (!this.config.showDate && this.config.showTime){
		formatOptions.selector = 'time';
			} // end-if
	return dojo.date.locale.format(dojo.date.stamp.fromISOString(valueTuple.value_timepoint.replace(' ','T')), formatOptions);
		} // endof-method htmlFormatValueTuple_ReadMode
	}
); // end-of-declaration
