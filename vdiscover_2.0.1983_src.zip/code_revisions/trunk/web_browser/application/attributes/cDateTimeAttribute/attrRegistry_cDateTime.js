﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

//dojo.require('application.attributeKinds');
	
application.attributeKinds.register({
	kind: 'cDateTimeAttribute', 

	'defaultConfiguration': { 
		cardinality: 1, 
		unit: '',
		svFormatActivated: false,
		svHtmlBefore: '',
		svHtmlBetween: '',
		svHtmlAfter: '',
		showDate: true,
		showTime: true,
		dateFormat: '',
		timeFormat: '',
		currentAsDefault: true,
		futureValuesAllowed: true,
		pastValuesAllowed: true
	},

	'defaultRetrievalValues': [
		'searchMode', 'value1', 'value2',
		'periodYears', 'periodMonths', 'periodDays', 'periodHours', 'periodMinutes', 'periodSeconds' 
	],
	
	'widgetClass': 'application.widgets.cDateTimeAttribute',
	
	'configurationWidgetClass': 'application.widgets.configureAttributes.cDateTimeAttribute',
	
	'useValueTupleAsExpressionInput'	: false
	,
	'expressionsPermitted'				: false
	,

}); // end-of-register
		
