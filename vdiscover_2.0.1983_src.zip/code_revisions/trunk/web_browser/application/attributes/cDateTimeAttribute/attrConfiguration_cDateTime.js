﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare(
	'application.widgets.configureSpecialAttribute.cDateTimeAttribute',
	[application.widgets.configureAttribute.genericConfigurationWidget],
	{
'showDateTime_changed' : function(e) {
	this.showDate=false;
	this.showTime=false;
	
	if (this.showDate_rB.attr('checked')) 		 this.showDate=true;
	if (this.showDateTime_rB.attr('checked')) 	{this.showDate=true; this.showTime=true;}
	if (this.showTime_rB.attr('checked')) 		 					 this.showTime=true;
	
	var show_dF_tB = (this.showDate||(this.showDate && this.showTime)),
		show_tF_tB = (this.showTime||(this.showDate && this.showTime))	;
	this.dateFormat_tB.attr('disabled',!show_dF_tB);
	this.timeFormat_tB.attr('disabled',!show_tF_tB);
	
	this.propertyHasChanged('showDate');
	this.propertyHasChanged('showTime');
		}, // end-of-method format_changed
	
'dateFormat_changed' : function (e) {
	this.dateFormat = this.dateFormat_tB.attr('value');
	this.propertyHasChanged('dateFormat');
	// format an example value
	try {
		this.dateFormat_example_DOMNode.innerHTML=
			dojo.date.locale.format(new Date(), {'datePattern':this.dateFormat, 'selector': 'date'});
	} catch(e) {
		console.error('Invalid chars in date format: '+this.dateFormat);
		this.dateFormat_example_DOMNode.innerHTML= T('attrConfiguration_cDateTime.js/ErrInvChars_TXT','Error! Invalid chars in the format string.');
	} // end try .. catch
		}, // end-of-method dateFormat_changed
	
'timeFormat_changed' : function (e) {
	this.timeFormat = this.timeFormat_tB.attr('value');
	this.propertyHasChanged('timeFormat');
	// format an example value
	try {
		this.timeFormat_example_DOMNode.innerHTML=
			dojo.date.locale.format(new Date(), {'timePattern':this.timeFormat, 'selector': 'time'});
	} catch(e) {
		console.error('Invalid chars in time format: '+this.timeFormat);
		this.timeFormat_example_DOMNode.innerHTML= T('attrConfiguration_cDateTime.js/ErrInvChars_TXT','Error! Invalid chars in the format string.');
	} // end try .. catch
		}, // end-of-method dateFormat_changed
	
'timestampIsDefault_changed' : function (e) {
	this.currentAsDefault = this.timestampIsDefault_cB.attr('checked');
	this.propertyHasChanged('currentAsDefault');
		}, // end-of-method timestampIsDefault_changed
		
'pastValuesAllowed_changed' : function (e) {
	this.pastValuesAllowed = this.pastValuesAllowed_cB.attr('checked');
	this.propertyHasChanged('pastValuesAllowed');
		}, // end-of-method pastValuesAllowed_changed
		
'futureValuesAllowed_changed' : function (e) {
	this.futureValuesAllowed = this.futureValuesAllowed_cB.attr('checked');
	this.propertyHasChanged('futureValuesAllowed');
		}, // end-of-method futureValuesAllowed_changed
		
'postMixInProperties' : function() {
	this.inherited(arguments);
	// expand the template string
	this.addTemplateSection(""
		+"<tr>"
			+"<td class='textRight'>Show …</td>"
			+"<td>"
				+"<label>"
					+"<input type='radio' dojoType='dijit.form.RadioButton' "
						+"name='application.widgets.configureAttributes.cDateTimeAttribute.show?' "
						+"dojoAttachPoint='showDate_rB' "
						+"dojoAttachEvent='onFocus:showEditHints' "
						+"value='true' />"
						+ T('attrConfiguration_cDateTime.js/DateOnly_LBL','the date, only.')
				+"</label>"
				+"&nbsp;&nbsp;"
				+"<label>"
					+"<input type='radio' dojoType='dijit.form.RadioButton' "
						+"name='application.widgets.configureAttributes.cDateTimeAttribute.show?' "
						+"dojoAttachPoint='showDateTime_rB' "
						+"dojoAttachEvent='onFocus:showEditHints' "
						+"value='true' />"
						+ T('attrConfiguration_cDateTime.js/DateAndTime_LBL','both, date and time.')
				+"</label>"
				+"&nbsp;&nbsp;"
				+"<label>"
					+"<input type='radio' dojoType='dijit.form.RadioButton' "
						+"name='application.widgets.configureAttributes.cDateTimeAttribute.show?' "
						+"dojoAttachPoint='showTime_rB' "
						+"dojoAttachEvent='onFocus:showEditHints' "
						+"value='true' />"
						+ T('attrConfiguration_cDateTime.js/TimeOnly_LBL','the time, only.')
				+"</label>"
			+"</td>"
		+"</tr>"
		+"<tr>"
			+"<td class='textRight'>" + T('attrConfiguration_cDateTime.js/DatePattern_LBL','Date pattern:') + "</td>"
			+"<td>"
				+"<input type='text' style='width:50%' "
					+"value='${dateFormat}' "
					+"dojoAttachPoint='dateFormat_tB' "
					+"dojoAttachEvent='onFocus:showDateTimeEditHints' "
					+"dojoType='dijit.form.TextBox' "
					+"trim='true' "
					+"intermediateChanges='true' "
					+"/> "
				+ T('FUT_Example','Example') + ":&nbsp;"
				+"<span dojoAttachPoint='dateFormat_example_DOMNode' class='code'>&mdash;</span>"
			+"</td>"
		+"</tr>"
		+"<tr>"
			+"<td class='textRight'>" + T('attrConfiguration_cDateTime.js/TimePattern_LBL','Time pattern:') + "</td>"
			+"<td>"
				+"<input type='text' style='width:50%' "
					+"value='${timeFormat}' "
					+"dojoAttachPoint='timeFormat_tB' "
					+"dojoAttachEvent='onFocus:showDateTimeEditHints' "
					+"dojoType='dijit.form.TextBox' "
					+"trim='true' "
					+"intermediateChanges='true' "
					+"/> "
				+ T('FUT_Example','Example') + ":&nbsp;"
				+"<span dojoAttachPoint='timeFormat_example_DOMNode' class='code'>&mdash;</span>"
			+"</td>"
		+"</tr>"
		+"<tr>"
			+"<td class='textRight'>" + T('FUT_Options','Options') + ":</td>"
			+"<td>"
				+"<p><label>"
					+"<input dojoType='dijit.form.CheckBox' "
					+"dojoAttachPoint='timestampIsDefault_cB' "
					+"dojoAttachEvent='onFocus:showEditHints' "
					+"value='true'/>"
					+ T('attrConfiguration_cDateTime.js/UseCurrTOptasDef_TXT','Use the current time point as default value.')
				+"</label></p>"
				+"<p class='noIndent'><label>"
					+"<input dojoType='dijit.form.CheckBox' "
					+"dojoAttachPoint='pastValuesAllowed_cB' "
					+"dojoAttachEvent='onFocus:showEditHints' "
					+"value='true'/>"
					+ T('attrConfiguration_cDateTime.js/ValInPastPerm_TXT','Values in the past are permitted.')
				+"</label></p>"
				+"<p class='noIndent'><label>"
					+"<input dojoType='dijit.form.CheckBox' "
					+"dojoAttachPoint='futureValuesAllowed_cB' "
					+"dojoAttachEvent='onFocus:showEditHints' "
					+"value='true'/>"
					+ T('attrConfiguration_cDateTime.js/ValInFuturePerm_TXT','Values in the future are permitted.')
				+"</label></p>"
			+"</td>"
		+"</tr>"
	);
	//localise the necessary variables
	this.locateProperties(['timeFormat','dateFormat','showTime','showDate','futureValuesAllowed','pastValuesAllowed','currentAsDefault']);
	// generate the template string
	this.generateTemplateString();
		}, // end-of-method postMixInProperties

'postCreate' : function() {
	this.inherited(arguments);

	if (this.showDate && !this.showTime) 	this.showDate_rB.attr('checked',true);
	if (this.showDate && this.showTime) 	this.showDateTime_rB.attr('checked',true);
	if (!this.showDate && this.showTime) 	this.showTime_rB.attr('checked',true);
	
	this.timestampIsDefault_cB.attr('checked',	this.currentAsDefault);
	this.pastValuesAllowed_cB.attr('checked',	this.pastValuesAllowed);
	this.futureValuesAllowed_cB.attr('checked',	this.futureValuesAllowed);
	
	var show_dF_tB = (this.showDate||(this.showDate && this.showTime)),
		show_tF_tB = (this.showTime||(this.showDate && this.showTime))	;
	this.dateFormat_tB.attr('disabled',!show_dF_tB);
	this.timeFormat_tB.attr('disabled',!show_tF_tB);
	
	this.showDate_rB.attr('disabled', this.isInherited);
	this.showDateTime_rB.attr('disabled', this.isInherited);
	this.showTime_rB.attr('disabled', this.isInherited);

	this.dateFormat_tB.attr('disabled', this.isInherited);
	this.timeFormat_tB.attr('disabled', this.isInherited);

	this.timestampIsDefault_cB.attr('disabled', this.isInherited);
	this.pastValuesAllowed_cB.attr('disabled', this.isInherited);
	this.futureValuesAllowed_cB.attr('disabled', this.isInherited);
	
	if(!this.isInherited) {
		this.connect( this.showDate_rB, 			'onChange', 'showDateTime_changed');
		this.connect( this.showDateTime_rB, 		'onChange', 'showDateTime_changed');
		this.connect( this.showTime_rB, 			'onChange', 'showDateTime_changed');
		
		this.connect( this.dateFormat_tB, 			'onChange', 'dateFormat_changed');
		this.connect( this.timeFormat_tB, 			'onChange', 'timeFormat_changed');
		
		this.connect( this.timestampIsDefault_cB, 	'onChange', 'timestampIsDefault_changed');
		this.connect( this.pastValuesAllowed_cB, 	'onChange', 'pastValuesAllowed_changed');
		this.connect( this.futureValuesAllowed_cB, 	'onChange', 'futureValuesAllowed_changed');
		
	} // end if
		}, // end-of-method postCreate
	}
); // end-of-declaration
