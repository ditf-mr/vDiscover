﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare(
	'application.widgets.retrieveAttributes.cDateTimeAttribute',
	[application.widgets.retrieveAttributes.genericAttribute],
	{
		dateBox1 : null, // dijit.form.DateTextBox
		timeBox1 : null, //dijit.form.TimeTextBox
		dateBox2 : null, // dijit.form.DateTextBox
		timeBox2 : null, //dijit.form.TimeTextBox

		numberBox_years: null,		// dijit.form.NumberSpinner
		numberBox_months: null,		// dijit.form.NumberSpinner
		numberBox_days: null,		// dijit.form.NumberSpinner
		numberBox_hours: null,		// dijit.form.NumberSpinner
		numberBox_minutes: null,	// dijit.form.NumberSpinner
		numberBox_seconds: null,	// dijit.form.NumberSpinner

		'initialiseProperties': function () {
			{ // set default search mode if necessary
				if (!this.searchMode) {
					this.searchMode = 'exactly';
				}		
			}
			if (!this.not) {
				this.not = false;
			}		
			{ // initialise value1, value2 and period
				if (!this.value1) {
					this.value1 = '';
				} 
				else {
					this.value1 = this.value1.replace(' ', 'T');
				}
				if (!this.value2) {
					this.value2 ='';
				}
				else {
					this.value2 = this.value2.replace(' ', 'T');
				}
				if (!this.periodYears) {
					this.periodYears = 0;
				}
				if (!this.periodMonths) {
					this.periodMonths = 0;
				}
				if (!this.periodDays) {
					this.periodDays = 0;
				}	
				if (!this.periodHours) {
					this.periodHours = 0;
				}
				if (!this.periodMinutes) {
					this.periodMinutes = 0;
				}
				if (!this.periodSeconds) {
					this.periodSeconds = 0;
				}
			}
		}, // end-of-function initialiseProperties


		'values_changed': function (e){
			/**
			 * Entry point for all changes done in the retrieval form of this attribute.
			 * - calls function to adapt (correct) the inputs in the form
			 * - calls parent retrieval modul to inform it about the changes
			 */
			this._adaptInputForm();
			this._informRetrievalModul();
		}, // end-of-method values_changed
		
		
		'_adaptInputForm': function() {
			/**
			 * Check the inputs of the retrieval form of this attributes and adapts (corrects)
			 * them if necessaray.
			 * Method is called from method 'values_changed'.
			 */
			this.enableDisableFields(this.searchMode_S.attr('value'));
		}, // end-of-method _adaptInputForm
		
		
		'_informRetrievalModul': function() {
			/**
			 * Calls the parent retrieval modul to inform it about the changes in this
			 * attribute.
			 */
			{ // Collect all values
				var searchMode = this.searchMode_S.get('value');
				var not = this.not_cB.checked;
				var date1 = this.dateBox1.attr('value');
				var time1 = this.timeBox1.attr('value');
				var date2 = this.dateBox2.attr('value');
				var time2 = this.timeBox2.attr('value');
				var periodYears = this.numberBox_years.attr('value');
				var periodMonths = this.numberBox_months.attr('value');
				var periodDays = this.numberBox_days.attr('value');
				var periodHours = this.numberBox_hours.attr('value');
				var periodMinutes = this.numberBox_minutes.attr('value');
				var periodSeconds = this.numberBox_seconds.attr('value');
				var parsedQuery = '';
				var value1 = '';
				var value2 = '';
			}
			// handle constrains
			this.dateBox1.attr('constraints', {datePattern: this.dateFormat}) ;
			this.timeBox1.attr('constraints', {timePattern: this.timeFormat}) ;
			this.dateBox2.attr('constraints', {datePattern: this.dateFormat}) ;
			this.timeBox2.attr('constraints', {timePattern: this.timeFormat}) ;
			// check values and save them to the store and handle constrains
			var inputsOk = 0;
			var datePeriodExists = (periodYears || periodMonths || periodDays);
			var timePeriodExists = (periodHours || periodMinutes || periodSeconds);
			switch ( this.searchMode_S.attr('value') ) {
				case 'exactly':
				case 'before':
				case 'after': {
					var dateTimeString1 = '';
					if (this.dateBox1.isValid() && this.timeBox1.isValid()) {
						if (date1 && time1) {
							dateTimeString1 = dojo.date.stamp.toISOString(date1,{selector:'date'})+dojo.date.stamp.toISOString(time1,{selector:'time'});
						}
						else if (date1) {
							dateTimeString1 = dojo.date.stamp.toISOString(date1, {selector: 'date'});
						}
						else if (time1) {
							dateTimeString1 = dojo.date.stamp.toISOString(time1, {selector: 'time'});
						} // end-if
					}
					if (dateTimeString1) {
						inputsOk = 1;
						value1 = dateTimeString1;
					}
					break;
				}
				case 'fromTo': {
					var dateTimeString1 = '';
					var dateTimeString2 = '';
					if ( (this.dateBox1.isValid() && this.timeBox1.isValid()) && (this.dateBox2.isValid() && this.timeBox2.isValid()) ) {
						// value1 
						if(date1 && time1) {
							dateTimeString1 = dojo.date.stamp.toISOString(date1, {selector: 'date'})+dojo.date.stamp.toISOString(time1, {selector: 'time'});		
						} 
						else if (date1) {
							dateTimeString1 = dojo.date.stamp.toISOString(date1, {selector:'date'});
						}
						else if (time1) {
							dateTimeString1 = dojo.date.stamp.toISOString(time1, {selector:'time'});
						} // end-if
						// value2 
						if(date2 && time2) {
							dateTimeString2 = dojo.date.stamp.toISOString(date2, {selector: 'date'})+dojo.date.stamp.toISOString(time2, {selector: 'time'});				
						}
						else if (date2) {
							dateTimeString2 = dojo.date.stamp.toISOString(date2, {selector: 'date'});
						} 
						else if (time2) {
							dateTimeString2 = dojo.date.stamp.toISOString(time2, {selector: 'time'});
						} // end-if
					} // end-if	
					if (dateTimeString1 && dateTimeString2 
						&& !(date1 && !time1 && !date2 && time2)
						&& !(!date1 && time1 && date2 && !time2)) {
						inputsOk = 1;
						value1 = dateTimeString1;
						value2 = dateTimeString2;
					}
					break;
				}
				case 'plusMinusPeriod': {
					var dateTimeString1 = '';
					if (this.dateBox1.isValid() && this.timeBox1.isValid()) {
						if (date1 && time1 && (datePeriodExists || timePeriodExists)) {
							dateTimeString1 = dojo.date.stamp.toISOString(date1,{selector:'date'})+dojo.date.stamp.toISOString(time1,{selector:'time'});
						}
						else if (date1 && datePeriodExists) {
							dateTimeString1 = dojo.date.stamp.toISOString(date1, {selector: 'date'});
						}
						else if (time1 && timePeriodExists) {
							dateTimeString1 = dojo.date.stamp.toISOString(time1, {selector: 'time'});
						} // end-if
					} 
					if (dateTimeString1) {
						inputsOk = 1;
						value1 = dateTimeString1;
					}
					break;
				}					
				case 'inPastPeriod':
				case 'inNextPeriod': {
					if (datePeriodExists || timePeriodExists) {
						inputsOk = 1;
					}
					break;
				}
				case 'inPast':
				case 'inFuture': 
				case 'exists': {
					inputsOk = 1;
					break;
				}		
			} // end-of-switch
			if (inputsOk) {
				parsedQuery = this._parseQuery(value1, value2);
			}
			if (isNaN(periodYears)) {
				periodYears = 0;
			}
			if (isNaN(periodMonths)) {
				periodMonths = 0;
			}
			if (isNaN(periodDays)) {
				periodDays = 0;
			}
			if (isNaN(periodHours)) {
				periodHours = 0;
			}
			if (isNaN(periodMinutes)) {
				periodMinutes = 0;
			}
			if (isNaN(periodSeconds)) {
				periodSeconds = 0;
			}
			if (parsedQuery != '') {
				application.OT.retrieve.changeRetrievalAttribute(
					this.UUID,
					{
						'searchMode': searchMode,
						'not': not,
						'value1': value1,
						'value2': value2,
						'periodYears': periodYears,
						'periodMonths': periodMonths,
						'periodDays': periodDays,
						'periodHours': periodHours,
						'periodMinutes': periodMinutes,
						'periodSeconds': periodSeconds,
						'parsedQuery': parsedQuery,
						'ok': true
					}
				);
			}
			else {
				application.OT.retrieve.changeRetrievalAttribute(
					this.UUID,
					{
						'searchMode': '',
						'not': false,
						'value1': value1,
						'value2': value2,
						'periodYears': 0,
						'periodMonths': 0,
						'periodDays': 0,
						'periodHours': 0,
						'periodMinutes': 0,
						'periodSeconds': 0,
						'parsedQuery': '',
						'ok': false
					}
				);
			}
		}, // end-of-method _informRetrievalModul

			
		'_parseQuery': function(value1, value2) {
			/**
			 * Generates a text form of the query, that can be displayed.
			 * @return string.
			 */
			var returnValue = '';
			{ // Get current values
				var searchMode = this.searchMode_S.get('value');
				var not = this.not_cB.checked;
				var date1 = this.dateBox1.attr('value');
				var time1 = this.timeBox1.attr('value');
				var date2 = this.dateBox2.attr('value');
				var time2 = this.timeBox2.attr('value');
				var periodYears = this.numberBox_years.attr('value');
				var periodMonths = this.numberBox_months.attr('value');
				var periodDays = this.numberBox_days.attr('value');
				var periodHours = this.numberBox_hours.attr('value');
				var periodMinutes = this.numberBox_minutes.attr('value');
				var periodSeconds = this.numberBox_seconds.attr('value');
			}
			{ // Generate parsed query for output
				var formattedValue1 = '';
				var formattedDate1 = '';
				var formattedTime1 = '';
				var formattedValue2 = '';
				var formattedDate2 = '';
				var formattedTime2 = '';
				{ // format value1
					var dateTime1 = dojo.date.stamp.fromISOString(value1);
					var value1TimeOnly = false;
					var value1DateOnly = false;
					if (value1) {
						if (value1.charAt(0) == 'T') { // time only
							value1TimeOnly = true;
							formattedValue1 = dojo.date.locale.format(
								dateTime1,
								{
									timePattern: this.timeFormat,
									selector: 'time'
								}
							);
							formattedTime1 = formattedValue1;
						}
						else if (value1.length == 10) { // date only
							value1DateOnly = true;
							formattedValue1 = dojo.date.locale.format(
								dateTime1, 
								{
									datePattern: this.dateFormat,
									selector: 'date'
								}
							);				
							formattedDate1 = formattedValue1;
						}
						else { // date and time
							formattedValue1 = dojo.date.locale.format(
								dateTime1, 
								{
									datePattern: this.dateFormat,
									timePattern: this.timeFormat
								}
							);
							formattedDate1 = dojo.date.locale.format(
								dateTime1, 
								{
									datePattern: this.dateFormat,
									selector: 'date'
								}
							);				
							formattedTime1 = dojo.date.locale.format(
								dateTime1, 
								{
									datePattern: this.dateFormat,
									selector: 'time'
								}
							);				
						}
					}
				}
				{ // format value2
					var dateTime2 = dojo.date.stamp.fromISOString(value2);
					var value2TimeOnly = false;
					var value2DateOnly = false;
					if (value2) {
						if (value2.charAt(0) == 'T') { // time only
							value2TimeOnly = true;
							formattedValue2 = dojo.date.locale.format(
								dateTime2,
								{
									timePattern: this.timeFormat,
									selector: 'time'
								}
							);
							formattedTime2 = formattedValue2;
						}
						else if (value2.length == 10) { // date only
							value2DateOnly = true;
							formattedValue2 = dojo.date.locale.format(
								dateTime2, 
								{
									datePattern: this.dateFormat,
									selector: 'date'
								}
							);			
							formattedDate2 = formattedValue2;
						}
						else { // date and time
							formattedValue2 = dojo.date.locale.format(
								dateTime2, 
								{
									datePattern: this.dateFormat,
									timePattern: this.timeFormat
								}
							);
							formattedDate2 = dojo.date.locale.format(
								dateTime2, 
								{
									datePattern: this.dateFormat,
									selector: 'date'
								}
							);				
							formattedTime2 = dojo.date.locale.format(
								dateTime2, 
								{
									datePattern: this.dateFormat,
									selector: 'time'
								}
							);				
						}
					}
				}
				{ // check if period exists and generate string
					var periodExists = (periodYears || periodMonths || periodDays || periodHours || periodMinutes || periodSeconds);
					var datePeriodExists = (periodYears || periodMonths || periodDays);
					var timePeriodExists = (periodHours || periodMinutes || periodSeconds);
					var periodString = '«';
					if (periodYears) {
						periodString += T('attrRetrieval_cDateTime.js/years_TXT','$[0]year(s)', [periodYears]) + ' ';
					}
					if (periodMonths) {
						periodString += T('attrRetrieval_cDateTime.js/months_TXT','$[0]month(s)', [periodMonths]) + ' ';
					}
					if (periodDays) {
						periodString += T('attrRetrieval_cDateTime.js/days_TXT','$[0]day(s)', [periodDays]) + ' ';
					}
					if (periodHours) {
						periodString += T('attrRetrieval_cDateTime.js/hours_TXT','$[0]hour(s)', [periodHours]) + ' ';
					}
					if (periodMinutes) {
						periodString += T('attrRetrieval_cDateTime.js/minutes_TXT','$[0]minute(s)', [periodMinutes]) + ' ';
					}
					if (periodSeconds) {
						periodString += T('attrRetrieval_cDateTime.js/seconds_TXT','$[0]second(s)', [periodSeconds]) + ' ';
					}
					periodString += '»';
				}
				switch (searchMode) {
					case 'exactly': {
						if (value1) {
							if (not) {
								return ( T('attrRetrieval_cDateTime.js/isNot_TXT','$[0] is not $[1]', [this.name, formattedValue1]) );
							}
							else {
								return ( T('attrRetrieval_cDateTime.js/is_TXT','$[0] is $[1]', [this.name, formattedValue1]) );
							}
						} 
						break;
					}
					case 'before': {
						if (value1) {
							if (not) {
								return ( T('attrRetrieval_cDateTime.js/IsNotBefore_TXT','$[0] is not before $[1]', [this.name, formattedValue1]) );
							}
							else {
								return ( T('attrRetrieval_cDateTime.js/IsBefore_TXT','$[0] is before $[1]', [this.name, formattedValue1]) );
							}
						}
						break;
					}
					case 'after': {
						if (value1){
							if (not) {
								return ( T('attrRetrieval_cDateTime.js/IsNotAfter_TXT','$[0] is not after $[1]', [this.name, formattedValue1]) );
							}
							else {
								return ( T('attrRetrieval_cDateTime.js/IsAfter_TXT','$[0] is after $[1]', [this.name, formattedValue1]) );
							}
						} 
						break;
					}
					case 'fromTo': {
						if (value1 && value2){
							if (value1DateOnly && value2DateOnly) { 
								if (not) {
									returnValue = T('attrRetrieval_cDateTime.js/IsNotBetween_TXT','$[0] is not between $[1] and $[2]', [this.name, formattedDate1, formattedDate2]);
								}
								else {
									returnValue = T('attrRetrieval_cDateTime.js/IsBetween_TXT','$[0] is between $[1] and $[2]', [this.name, formattedDate1, formattedDate2]);
								}
							}
							if (value1TimeOnly && value2TimeOnly) { 
								if (not) {
									returnValue = T('attrRetrieval_cDateTime.js/IsNotBetween_TXT','$[0] is not between $[1] and $[2]', [this.name, formattedTime1, formattedTime2]);
								}
								else {
									returnValue = T('attrRetrieval_cDateTime.js/IsBetween_TXT','$[0] is between $[1] and $[2]', [this.name, formattedTime1, formattedTime2]);
								}
							} 
							if (value1TimeOnly && value2DateOnly) { 
								returnValue = '';
							}
							else if (value1DateOnly && value2TimeOnly) { 
								returnValue = '';
							}
							else if (value1TimeOnly) {
								if (not) {
									returnValue = T('attrRetrieval_cDateTime.js/IsNotOnBetwAnd_TXT','$[0] is not on $[1] between $[2] and $[3]', [this.name, formattedDate2, formattedTime1, formattedTime2]);
								}
								else {
									returnValue = T('attrRetrieval_cDateTime.js/IsOnBetwAnd_TXT','$[0] is on $[1] between $[2] and $[3]', [this.name, formattedDate2, formattedTime1, formattedTime2]);
								}
							}
							else if (value1DateOnly) {
								if (not) {
									returnValue = T('attrRetrieval_cDateTime.js/isNotBetweenInclAnd_TXT','$[0] is not between $[1] (inclusive) and $[2]', [this.name, formattedDate1, formattedValue2]);
								}
								else {
									returnValue = T('attrRetrieval_cDateTime.js/isBetweenInclAnd_TXT','$[0] is between $[1] (inclusive) and $[2]', [this.name, formattedDate1, formattedValue2]);
								}
							}
							else if (value2TimeOnly) {
								if (not) {
									returnValue = T('attrRetrieval_cDateTime.js/IsNotOnBetwAnd_TXT','$[0] is not on $[1] between $[2] and $[3]', [this.name, formattedDate1, formattedTime1, formattedTime2]);
								}
								else {
									returnValue = T('attrRetrieval_cDateTime.js/IsOnBetwAnd_TXT','$[0] is on $[1] between $[2] and $[3]', [this.name, formattedDate1, formattedTime1, formattedTime2]);
								}
							}
							else if (value2DateOnly) {
								if (not) {
									returnValue = T('attrRetrieval_cDateTime.js/isNotBetweenAndIncl_TXT','$[0] is not between $[1] and $[2] (inclusive)', [this.name, formattedValue1, formattedDate2]);
								}
								else {
									returnValue = T('attrRetrieval_cDateTime.js/isBetweenAndIncl_TXT','$[0] lies between $[1] and $[2] (inclusive)', [this.name, formattedValue1, formattedDate2]);
								}
							}
							else {
								if (not) {
									returnValue = T('attrRetrieval_cDateTime.js/isNotBetweenAnd_TXT','$[0] is not between $[1] and $[2]', [this.name, formattedValue1, formattedValue2]);
								}
								else {
									returnValue = T('attrRetrieval_cDateTime.js/isBetweenAnd_TXT','$[0] is between $[1] and $[2]', [this.name, formattedValue1, formattedValue2]);
								}
							}
						} 
						break;
					}
					case 'plusMinusPeriod': {
						if (value1 && periodExists){
							if (value1TimeOnly && !timePeriodExists) { // time only
								returnValue = '';
							}
							else if (value1DateOnly && !datePeriodExists) { // date only
								returnValue = '';
							} 
							else {
								if (not) {
									returnValue = T('attrRetrieval_cDateTime.js/isNotPlusMinusPeriod_TXT','$[0] is not $[1] ± $[2]', [this.name, formattedValue1, periodString]);
								}
								else {
									returnValue = T('attrRetrieval_cDateTime.js/isPlusMinusPeriod_TXT','$[0] is $[1] ± $[2]', [this.name, formattedValue1, periodString]);
								}
							}
						} 
						break;
					}
					case 'inPastPeriod': {
						if (periodExists){
							if (not) {
								returnValue = T('attrRetrieval_cDateTime.js/WasNotInPastPeriod_TXT','$[0] was not in the past period $[1]', [this.name, periodString]);
							}
							else {
								returnValue = T('attrRetrieval_cDateTime.js/WasInPastPeriod_TXT','$[0] was in the past period $[1]', [this.name, periodString]);
							}
						}
						break;
					}
					case 'inNextPeriod': {
						if (periodExists){
							if (not) {
								returnValue = T('attrRetrieval_cDateTime.js/IsNotInNextPeriod_TXT','$[0] is not in the next period $[1]', [this.name, periodString]);
							}
							else {
								returnValue = T('attrRetrieval_cDateTime.js/IsInNextPeriod_TXT','$[0] is in the next period $[1]', [this.name, periodString]);
							}
						} 
						break;
					}
					case 'inPast': {
						if (not) {
							returnValue = T('attrRetrieval_cDateTime.js/WasNotInPast_TXT','$[0] was not in the past', [this.name]);
						}
						else {
							returnValue = T('attrRetrieval_cDateTime.js/WasInPast_TXT','$[0] was in the past', [this.name]);
						}
						break;
					}
					case 'inFuture': {
						if (not) {
							returnValue = T('attrRetrieval_cDateTime.js/IsNotInFuture_TXT','$[0] is not in the future', [this.name]);
						}
						else {
							returnValue = T('attrRetrieval_cDateTime.js/IsInFuture_TXT','$[0] is in the future', [this.name]);
						}
						break;
					}
					case 'exists': {
						returnValue = T('attrRetrieval_cDateTime.js/exists_TXT','$[0] has a value', [this.name, periodString]);
						break;
					}
				} // end-of-switch
			}
			return (returnValue);
		}, // end-of-method _parseQuery
		
		
		'postMixInProperties': function() {
			// If you provide a postMixInProperties method for your widget, it will be invoked 
			// before rendering occurs, and before any dom nodes are created. If you need to 
			// add or change the instance's properties before the widget is rendered 
			// - this is the place to do it.
			this.inherited(arguments);
			this.locateProperties([
				'searchMode', 'not', 'value1', 'value2', 
				'periodYears', 'periodMonths', 'periodDays', 'periodHours', 'periodMinutes', 'periodSeconds', 
				'showDate', 'showTime', 'dateFormat', 'timeFormat', 'name'
			]);
			this.initialiseProperties();
			// set field parameter considering search mode
			var value1Disabled = '';
			var value2Disabled = 'disabled ';
			var periodDisabled = 'disabled ';
			switch ( this.searchMode ) {
							case 'exactly':
							case 'before':
							case 'after':
								break;
				case 'fromTo':
								value2Disabled = '';
					break;
							case 'plusMinusPeriod':
							case 'inPastPeriod':
							case 'inNextPeriod':
								periodDisabled = '';
					break;
							case 'inPast':
							case 'inFuture':
								value1Disabled = 'disabled ';
					break;
			} // end-of-switch
			var checked = "";
			if (this.not == true) {
				checked = " checked='checked'";
			}
			this.title = T('attrRetrieval_cDateTime.js/SearchParas_TIT','Search parameters');
			// expand the template string
			this.addTemplateSection(''			
				+'<tr>'
					+'<td class="textRight" width="30%">' + T('attrRetrieval_cDateTime.js/ChooseSMode_TXT','Choose search mode:') + '</td>'
					+'<td width="70%">'
						+'<select style="width:100%"'
							+'value="${searchMode}"' 
							+'dojoAttachEvent="onChange:values_changed"'
							+'dojoAttachPoint="searchMode_S"'
							+'dojoType="dijit.form.Select"'
						+'>'
							+'<option value="exactly">' + T('attrRetrieval_cDateTime.js/SModeOpt_1_TXT','«${name}» = value1') + '</option>'
							+"<option type='separator'></option>"
							+'<option value="before">' + T('attrRetrieval_cDateTime.js/SModeOpt_2_TXT','«${name}» is before value1') + '</option>'
							+'<option value="after">' + T('attrRetrieval_cDateTime.js/SModeOpt_3_TXT','«${name}» is after value1') + '</option>'
							+"<option type='separator'></option>"
							+'<option value="fromTo">' + T('attrRetrieval_cDateTime.js/SModeOpt_4_TXT','«${name}» is between value1 and value2') + '</option>'
							+'<option value="plusMinusPeriod">' + T('attrRetrieval_cDateTime.js/SModeOpt_5_TXT','«${name}» = value1 ± period') + '</option>'
							+"<option type='separator'></option>"
							+'<option value="inPast">' + T('attrRetrieval_cDateTime.js/SModeOpt_6_TXT','«${name}» was in the past') + '</option>'
							+'<option value="inFuture">' + T('attrRetrieval_cDateTime.js/SModeOpt_7_TXT','«${name}» is in the future') + '</option>'
							+'<option value="inPastPeriod">' + T('attrRetrieval_cDateTime.js/SModeOpt_8_TXT','«${name}» was in the past period') + '</option>'
							+'<option value="inNextPeriod">' + T('attrRetrieval_cDateTime.js/SModeOpt_9_TXT','«${name}» is in the coming period') + '</option>'
							+"<option type='separator'></option>"
							+"<option value='exists'>${name} has a value</option>"
						+'</select>'
					+'</td>'
				+'</tr>'
				+"<tr>"
					+"<td class='textRight' width='30%'> </td>"
					+"<td width='70%'>"
						+"<input type='checkbox'"
							+" value='1'"
							+checked
							+" dojoAttachEvent='onChange:values_changed'"
							+" dojoAttachPoint='not_cB'"
							+" dojoType='dijit.form.CheckBox'"
						+"/>"
						+" "
						+T('attrRetrieval_cDateTime.js/Not_LBL', 'Negate condition of search mode')
					+"</td>"
				+"</tr>"
				+'<tr>'
					+'<td class="textRight" width="30%">' + T('FUT_value','value<sub>1</sub>:') + '</td>'
					+'<td width="70%">'
						+'<div class="RS_VTE_date" '
							+'dojoAttachPoint="value1_dateBoxNode"></div>'
						+' '
						+'<div class="RS_VTE_time" '
							+'dojoAttachPoint="value1_timeBoxNode"></div>'
					+'</td>'
				+'</tr>'
				+'<tr>'
					+'<td class="textRight" width="30%">' + T('FUT_value','value<sub>2</sub>:') + '</td>'
					+'<td width="70%">'
				+'<div class="RS_VTE_date" dojoAttachPoint="value2_dateBoxNode"></div>'
						+' '
				+'<div class="RS_VTE_time" dojoAttachPoint="value2_timeBoxNode"></div>'
					+'</td>'
				+'</tr>'
				+'<tr>'
					+'<td class="textRight" width="30%">' + T('attrRetrieval_cDateTime.js/Period_TXT','period:') + '</td>'
					+'<td width="70%">'
						+'<div dojoAttachPoint="period_yearsNode" style="display: inline"></div>'
						+'<div dojoAttachPoint="labelYears" style="display: inline">' + T('FUT_years','years') + '</div>&nbsp;&nbsp;&nbsp;'
						+'<div dojoAttachPoint="period_monthsNode" style="display: inline"></div>'
						+'<div dojoAttachPoint="labelMonths" style="display: inline">' + T('FUT_months','months') + '&nbsp;&nbsp;&nbsp;</div>'
						+'<div dojoAttachPoint="period_daysNode" style="display: inline"></div>'
						+'<div dojoAttachPoint="labelDays" style="display: inline">' + T('FUT_days','days') + '&nbsp;&nbsp;&nbsp;</div>'
						+'<div dojoAttachPoint="period_hoursNode" style="display: inline"></div>'
						+'<div dojoAttachPoint="labelHours" style="display: inline">' + T('FUT_hours','hours') + '&nbsp;&nbsp;&nbsp;</div>'
						+'<div dojoAttachPoint="period_minutesNode" style="display: inline"></div>'
						+'<div dojoAttachPoint="labelMinutes" style="display: inline">' + T('FUT_minutes','minutes') + '&nbsp;&nbsp;&nbsp;</div>'
						+'<div dojoAttachPoint="period_secondsNode" style="display: inline"></div>'
						+'<div dojoAttachPoint="labelSeconds" style="display: inline">' + T('FUT_seconds','seconds') + '</div>'
					+'</td>'
				+'</tr>'
				+"<tr>"
					+"<td class='textRight' width='30%'>"
						+T('attrRetrieval/SearchRemarks_TXT','Remarks:')
					+"</td>"				
					+"<td width='70%'>"
							+"<ul>"
								+"<li>"
									+T('attrRetrieval_cNumber.js/SelSrchModeFor_HTM', 'You can select one of the following search modes:')
									+"<ul>"
										+'<li>' 
											+T('attrRetrieval_cDateTime.js/SelSMDesc_P1_HTM','<strong>«${name}» = <i>value<sub>1</sub></i></strong> finds all objects where «${name}» is exactly <code>value<sub>1</sub></code>') 
										+'</li>'
										+'<li>' 
											+T('attrRetrieval_cDateTime.js/SelSMDesc_P2_HTM','<strong>«${name}» is before to <i>value<sub>1</sub></i></strong> finds all objects where «${name}» is a day or time point before <code>value<sub>1</sub></code>') 
										+'</li>'
										+'<li>' 
											+T('attrRetrieval_cDateTime.js/SelSMDesc_P3_HTM','<strong>«${name}» is after <i>value<sub>1</sub></i></strong> finds all objects where «${name}» is a day or time point after <code>value<sub>1</sub></code>') 
										+'</li>'
										+'<li>' 
											+T('attrRetrieval_cDateTime.js/SelSMDesc_P4_HTM','<strong>«${name}» is between <i>value<sub>1</sub></i> and <i>value<sub>2</sub></i></strong> finds all objects where «${name}» is a day or time point after <code>value<sub>1</sub></code></li> and before <code>value<sub>2</sub></code>') 
										+'</li>'
										+'<li>' 
											+T('attrRetrieval_cDateTime.js/SelSMDesc_P5_HTM','<strong>«${name}» = <i>value<sub>1</sub></i> ± <i>period</i></strong> finds all objects\ where «${name}» is a day or time point, which is after <code>value<sub>1</sub></code></li> minus the <code>period</code> and before <code>value<sub>1</sub></code> plus the <code>period</code>, e.g. if <code>value<sub>1</sub></i></code>=<i>2012-06-01</i> and <code>period</code>=2months, then all objects will be found with <code>value<sub>1</sub></code> is between <i>2012-04-01</i> and <i>2012-08-01</i>') 
										+'</li>'
										+'<li>' 
											+T('attrRetrieval_cDateTime.js/SelSMDesc_P6_HTM','<strong>«${name}» is in the past</strong> finds all objects where «${name}» is a day (respectively time point) before <code>today</code> (respectively before <code>now</code>)') 
										+'</li>'
										+'<li>' 
											+T('attrRetrieval_cDateTime.js/SelSMDesc_P7_HTM','<strong>«${name}» is in the future</strong> finds all objects where «${name}» is a day (respectively time point) after <code>today</code> (respectively after <code>now</code>)') 
										+'</li>'
										+'<li>' 
											+T('attrRetrieval_cDateTime.js/SelSMDesc_P8_HTM','<strong>«${name}» was in the past period</strong> finds all objects where «${name}» is a day or time point before <code>today</code> (resp. <code>now</code>) and after <code>today-period</code> (resp. <code>now+period</code>)') 
										+'</li>'
										+'<li>' 
											+T('attrRetrieval_cDateTime.js/SelSMDesc_P9_HTM','<strong>«${name}» is in the coming period</strong> finds all objects where «${name}» is a day or time point after <code>today</code> (resp. <code>now</code>) and before <code>today+period</code> (resp. <code>now+period</code>)') 
										+'</li>'
										+"<li>" 
											+T('attrRetrieval_cNumber.js/SrchTips_P^10_HTM','<strong>${name} has a value</strong> finds all objects where a value in <code>${name}</code> exists.') 
										+"</li>"
									+"</ul>"
								+"</li>"
								+"<li>"
									+T('attrRetrieval_cNumber.js/SelNot_HTM', 'Negating the condition of the search mode results in a logical not in the query condition.')
								+"</li>"
							+"</ul>"
					+"</td>"
				+"</tr>"	
			);
			// generate the template string
			this.generateTemplateString();
		}, // end-of-method postMixInProperties
			

		'postCreate': function () {
			this.inherited(arguments);	
			// prepare the value1 for retrieval
			if (!this.value1) { // empty
				var date1 = new Date('');
				var time1 = new Date('');
			}
			else if (this.value1.charAt(0) == 'T') { // time only
				var date1 = new Date('');
				var time1 = new Date(this.value1);
			}
			else if (this.value1.length == 10) { // date only
				var date1 = new Date(this.value1);
				var time1 = new Date('');
			}
			else { // date and time
				var date1 = new Date(this.value1);
				var time1 = new Date(this.value1);
			}
			this.dateBox1 = new dijit.form.DateTextBox({
						'value': date1,
						'style': 'width: 100%;',
						'constraints': {datePattern: this.dateFormat},
						'intermediateChanges': true
			}).placeAt(this.value1_dateBoxNode);
			dojo.connect(this.dateBox1,'onChange',this,this.values_changed);
			this.timeBox1 = new dijit.form.TimeTextBox({
						'value': time1,
						'style': 'width: 100%;',
						'constraints': {timePattern: this.timeFormat},
						'intermediateChanges':	true
			}).placeAt(this.value1_timeBoxNode);
			dojo.connect(this.timeBox1,'onChange',this,this.values_changed);
			// prepare the value2 for retrieval
			if (!this.value2) { // empty
				var date2 = new Date('');
				var time2 = new Date('');
			}
			else if (this.value2.charAt(0) == 'T') { // time only
				var date2 = new Date('');
				var time2 = new Date(this.value2);
			}
			else if (this.value2.length == 10) { // date only
				var date2 = new Date(this.value2);
				var time2 = new Date('');
			}
			else { // date and time
				var date2 = new Date(this.value2);
				var time2 = new Date(this.value2);
			}
			var value2=new Date(this.value2);
			this.dateBox2 = new dijit.form.DateTextBox({
						'value': date2,
						'style': 'width: 100%;',
						'constraints': {datePattern: this.dateFormat},
						'intermediateChanges': true
			}).placeAt(this.value2_dateBoxNode);
			dojo.connect(this.dateBox2,'onChange',this,this.values_changed);
			this.timeBox2 = new dijit.form.TimeTextBox({
						'value': time2,
						'style': 'width: 100%;',
						'constraints': {timePattern: this.timeFormat},
						'intermediateChanges': true
			}).placeAt(this.value2_timeBoxNode);
			dojo.connect(this.timeBox2,'onChange',this,this.values_changed);
			// build number spinners for period
			// years
			this.numberBox_years = new dijit.form.NumberSpinner({
				'value': this.periodYears,
				'style': 'width: 3em',
				'smallDelta': 1,
				'constraints': {min: 0, max: 999, places: 0},
				'intermediateChanges':	true
			}).placeAt(this.period_yearsNode);
			dojo.connect(this.numberBox_years, 'onChange', this, this.values_changed);
			// months
			this.numberBox_months = new dijit.form.NumberSpinner({
				'value': this.periodMonths,
				'style': 'width: 3em',
				'smallDelta': 1,
				'constraints': {min: 0, max: 999, places: 0},
				'intermediateChanges':	true
			}).placeAt(this.period_monthsNode);
			dojo.connect(this.numberBox_months, 'onChange', this, this.values_changed);
			// days
			this.numberBox_days = new dijit.form.NumberSpinner({
				'value': this.periodDays,
				'style': 'width: 3em',
				'smallDelta': 1,
				'constraints': {min: 0, max: 999, places: 0},
				'intermediateChanges':	true
			}).placeAt(this.period_daysNode);
			dojo.connect(this.numberBox_days, 'onChange', this, this.values_changed);
			// hours
			this.numberBox_hours = new dijit.form.NumberSpinner({
				'value': this.periodHours,
				'style': 'width: 3em',
				'smallDelta': 1,
				'constraints': {min: 0, max: 999, places: 0},
				'intermediateChanges':	true
			}).placeAt(this.period_hoursNode);
			dojo.connect(this.numberBox_hours, 'onChange', this, this.values_changed);
			// minutes
			this.numberBox_minutes = new dijit.form.NumberSpinner({
				'value': this.periodMinutes,
				'style': 'width: 3em',
				'smallDelta': 1,
				'constraints': {min: 0, max: 999, places: 0},
				'intermediateChanges':	true
			}).placeAt(this.period_minutesNode);
			dojo.connect(this.numberBox_minutes, 'onChange', this, this.values_changed);
			// seconds
			this.numberBox_seconds = new dijit.form.NumberSpinner({
				'value': this.periodSeconds,
				'style': 'width: 3em',
				'smallDelta': 1,
				'constraints': {min: 0, max: 999, places: 0},
				'intermediateChanges':	true
			}).placeAt(this.period_secondsNode);
			dojo.connect(this.numberBox_seconds, 'onChange', this, this.values_changed);
			this.showHideFields();
			this.enableDisableFields(this.searchMode);
		}, // end-of-method postCreate

		
		'showHideFields': function () {
			if (!this.showDate) {
				dojo.style(this.value1_dateBoxNode,'display', 'none');
				dojo.style(this.value2_dateBoxNode,'display', 'none');
				dojo.style(this.period_yearsNode,'display', 'none');
				dojo.style(this.period_monthsNode,'display', 'none');
				dojo.style(this.period_daysNode,'display', 'none');
				dojo.style(this.labelYears,'display', 'none');
				dojo.style(this.labelMonths,'display', 'none');
				dojo.style(this.labelDays,'display', 'none');
			}
			if (!this.showTime) {
				dojo.style(this.value1_timeBoxNode,'display', 'none');
				dojo.style(this.value2_timeBoxNode,'display', 'none');
				dojo.style(this.period_hoursNode,'display', 'none');
				dojo.style(this.period_minutesNode,'display', 'none');
				dojo.style(this.period_secondsNode,'display', 'none');
				dojo.style(this.labelHours,'display', 'none');
				dojo.style(this.labelMinutes,'display', 'none');
				dojo.style(this.labelSeconds,'display', 'none');
			}
		}, // end-of-function showHideFields

		
		'enableDisableFields': function (searchMode) {
			var value1Disabled = false;
			var value2Disabled = true;
			var periodDisabled = true;
			var notDisabled = false;
			switch (searchMode) {
				case 'exactly':
				case 'before':
				case 'after':
					break;
				case 'fromTo':
					value2Disabled = false;
					break;
				case 'plusMinusPeriod':
					periodDisabled = false;
					break;
				case 'inPastPeriod':
				case 'inNextPeriod':
					value1Disabled = true;
					periodDisabled = false;
					break;
				case 'exists':
					notDisabled = true;
				case 'inPast':
				case 'inFuture':
					value1Disabled = true;
					break;
			} // end-of-switch
			this.not_cB.set('disabled', notDisabled);
			if (notDisabled) {
				this.not_cB.set('checked', false);
			}
			this.dateBox1.attr('disabled', value1Disabled);
			this.timeBox1.attr('disabled', value1Disabled);
			this.dateBox2.attr('disabled', value2Disabled);
			this.timeBox2.attr('disabled', value2Disabled);
			this.numberBox_years.attr('disabled', periodDisabled);
			this.numberBox_months.attr('disabled', periodDisabled);
			this.numberBox_days.attr('disabled', periodDisabled);
			this.numberBox_hours.attr('disabled', periodDisabled);
			this.numberBox_minutes.attr('disabled', periodDisabled);
			this.numberBox_seconds.attr('disabled', periodDisabled);
		}, // end-of-function this.searchMode_S.attr('value')

	}
); // end-of-declaration
