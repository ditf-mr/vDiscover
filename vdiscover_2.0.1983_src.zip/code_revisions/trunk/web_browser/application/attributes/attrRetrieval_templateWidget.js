/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// the following generic class is for attribute value retrieval

dojo.declare('application.widgets.retrieveAttributes.genericAttribute',[dijit._Widget,dijit._Templated],{
	attrInfo : null // item
	,
	rqWidget : null // dijit.widget of class application.widgets.RetrievalQueryWidget
	,
	parsedQuery: '' // 
	,
	parentWidget: null // here is the widget of the parent relation attribute stored if it exists
	,
	widgetsInTemplate: true
	,
	locateProperties : function (propertyNameArray) {
		// this method localises the passed property names.
		
		if(!this.attrInfo) throw 'locateProperties: there is no attribute information. Aborting';
		
		var rqWidget = this.rqWidget;

		dojo.forEach(propertyNameArray,function(propertyName){
			var valueArray = rqWidget.attributeStore.getValues(this.attrInfo, propertyName);
			if ( valueArray.length > 1 ) {
				this[propertyName] = valueArray;
			} else {
				this[propertyName] = rqWidget.attributeStore.getValue(this.attrInfo, propertyName);
			}
			
		},this);
	} // end of method locateProperties
	,
	
	
		'_adaptInputForm': function() {
			/**
			 * Check the inputs of the retrieval form of this attributes and adapts (corrects)
			 * them if necessaray.
			 * Method is called from method 'values_changed'.
			 *
			 * Must be overwritten in sub classes if necessary.
			 */
			// Nothing to do
		}, // end-of-method _adaptInputForm
		
		
	propertyHasChanged : function (propertyName, newPropertyValue) {
		/**
		 * This method notifies the attribute management dialog about a changed configuration property.
		 * The property needs to be a string.
		 * @param propertyName string. Name of the property
		 * @param newPropertyValue string. ???
		 * @return void
		 */
		if (typeof this[propertyName]=="undefined") {
			throw 'propertyHasChanged: The property "'+propertyName+'" does not exist.';
		}
		application.OT.retrieve.changeRetrievalAttribute(
			this.UUID,
			((typeof newPropertyValue!= "undefined")?newPropertyValue:this[propertyName]),
			propertyName
		);
	} // end of method changeProperty
	,
	
	'getValue': function(label) {
		/**
		 * Returns the value, identified by label, of the retrieval attribute, that belongs to this wdiget
		 * The value is saved in the attribute store of the retrieval widget of the object type.
		 * @param label string. The name of the slot, which contains the value.
		 * @return mixed. (see application.OT_retrieve.getRetrievalAttributeValue)
		 */
		return(application.OT.retrieve.getRetrievalAttributeValue(this.UUID, label));
	}, // end-of-method getAttributeWidget
	
	
	deleteCriterium : function () {
		application.OT.retrieve.deleteRetrievalAttribute( this.UUID );
		
		// reset the queryEditArea
		application.OT.retrieve.resetQueryEditArea(this.rqWidget);
	} // end of method deleteCriterium
	,
	templateSections : null
	,
	addTemplateSection : function(s) {
		if(!this.templateSections) this.templateSections = [];
		this.templateSections.push(s);
	} // end of method addTemplateSection
	,
	generateTemplateString : function () {
		this.templateString = ""
			+"<div class='RS_attributeConfig_section'>"
				+((this.title)?"<h3>${title}</h3>":"")
				+"<table class='fullWidth listWithRows'><tbody>"
					+this.templateSections.join('');
				+"</tbody></table>"
			+"</div>"
			;
	} // end of method generateTemplateString
	,
	postMixInProperties: function() {
		this.inherited(arguments);
		
		if(!((typeof this.attrInfo) == 'object')) throw ''+this.declaredClass+'.postMixInProperties() : no  attrInfo (attribute information item) passed. Aborting.';
	
		this.locateProperties(['UUID']);
	} // end of method postMixInProperties
});

