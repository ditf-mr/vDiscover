﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// this file enhances the main application object with 
// 	* a specific slot for attribute-specific functionality (e.g. dialogs)
//	* the registry for attribute kinds

application.attributes={};

// class declaration for an attribute kind of an information object type
dojo.declare("application.classes.attributeKind_class", [],{
	kind : "not specified, yet"
	,
	valueKind: function() {return this.kind+'Value'} /* default kind of attribute values is the kind name extended by 'Value' */
	,
	name : T('attributeRegistry.js/AbstrAttr_TXT','Abstract attribute')
	,
	defaultConfiguration : {} // will be modified later on to
	,
	defaultRetrievalValues:[] // will be modified later on to
	,
	getDefaultRetrievalValues : function () {
		return this.defaultRetrievalValues;
	} // end of method getDefaultRetrievalValues
	,
	manageAttributeValuesAction: function(O_UUID,A_UUID,VT_UUID) {
		application.O.manageAttributeValues.showDialogue(O_UUID,A_UUID,VT_UUID);
	}	// default dialogue for management of attribute values
	,
	getConfigurationWidget: function(conf_extended) { // can be rewriten in the definition of the attribute kinds
		var widget = new application.admin.Dialogues.manageAttributes[this.kind]( /*this line must be changed if the id of the widget is not application.admin.Dialogues.manageAttributes."kind" */
					conf_extended
				);
		return widget;
	} // end of method getConfigurationWidget
	,
	getRetrivalWidget: function(conf_extended) { // can be rewriten in the definition of the attribute kinds
		var widget = new application.OT.Dialogues.retrieveAttributeValues[this.kind]( /*this line must be changed if the id of the widget is not application.O.Dialogues.manageAttributeValues."kind" */
					conf_extended
				);
		return widget;
	} // end of method getRetrivalWidget
	,
	prepareConfigForRetrieval: function () {alert('Function is not yet defined!'); return false;} // must be set in the definition of the attribute kinds
	,
	inputValueTransformation : false // optional -- function (item,slot,value) will be executed after changing values before the value will be stored
	,
	constructor : function(args) {dojo./*safeMixin*/mixin(this, args);}
	,
	createAttribute : function () {application.admin.manageAttributes.createAttribute(this);}
	,
	positionOfAttribute : 1000 // natural number
	,
	defaultDescription : ""
	,
	standardCardinality : true // that means normal behaviour for attributes with cardinality
	,
	searchPoints : 5 // natural number
	
	// new options since 2011-07-25
	,
	fixedCardinality : false // setting this to true means that the attribute can only have cardinality 1
	// this is important for the configuration dialog
	,
	getParsedQuery: function() {alert('Sorry, no function for parsing of query data implemented yet.')}
	,
	
	// analytical expressions
	'useValueTupleAsExpressionInput'	: false
	,
	'expressionsPermitted'				: false
	,
	'defExprValTasJSON'					: ""
	,
	'exprValTDescription'				: ""
	,
	
	// CBR configuration -------------------------------------------------------------
	'supportsCBR'						: false
	,
	
}); // end of class declaration

// initialisation of the application part that is responsible for the attribute kind management
application.attributeKinds = {
	'attributeKindList' : {}
	,
	
	// Public methods
	'register' : function(confObj){
		/* The structure of confObj:
			kind : unique string
			??? name : attribute Type Name ??? specified in backend
			defaultConfiguration : OPTIONAL -- JS object with the attribute-specific default configuration options
			prepareConfigurationForEditing : OPTIONAL function(configurationObject) -- should return the configurationObject in an extended version that can be used to create the configurationWidget
			is_default_attribute : OPTIONAL -- BOOLEAN set this to true to make this attribute available for all information objects of a new type by default
		*/
		if (!confObj.kind) throw "No kind passed in  \""+dojo.toJson(confObj)+"\". Aborting.";
		if (!confObj.widgetClass) throw "No widgetClass passed in  \""+dojo.toJson(confObj)+"\". Aborting.";
		if (dojo.isObject(this.attributeKindList[confObj.kind])) throw "A attribute kind with the passed kind \""+confObj.kind+"\" does already exist. Aborting.";
		this.attributeKindList[confObj.kind]=new application.classes.attributeKind_class(confObj);
	} // end of method new_ViewType
	,
	
	'kindPermitsAnalyticalExpressionInput' : function (kind) {
		this._testIfKindExists(kind);
		return (this.attributeKindList[kind].useValueTupleAsExpressionInput == true);
	} // end of method kindPermitsAssignationInput
	,
	'kindPermitsAnalyticalExpressions' : function (kind) {
		this._testIfKindExists(kind);
		return (this.attributeKindList[kind].expressionsPermitted == true);
	} // end of method kindPermitsAssignationInput
	,
	'nameOfKind' : function (kind) {
		this._testIfKindExists(kind);
		return this.attributeKindList[kind].name;
	} // end of method kindPermitsAssignationInput
	,
	'getDefaultValueTupleasJson' : function (kind) {
		this._testIfKindExists(kind);
		return this.attributeKindList[kind].defExprValTasJSON || ''+
			+"{\n// "
				+ T('attributeRegistry.js/getDefaultValueTupleasJson_noDefaultValueTuple', 
					'The attribute kind \"$[0]\" has no default value tuple, yet.',
					[kind]) 
			+ "\n}";
	} // end of method getDefaultValueTupleasJson
	,
	'getDefaultValueTuple' : function (kind) {
		return dojo.fromJson(this.getDefaultValueTupleasJson(kind));
	} // end of method getDefaultValueTupleasJson
	,
	'getValueTupleDescription' : function (kind) {
		this._testIfKindExists(kind);
		return this.attributeKindList[kind].exprValTDescription || (""
			+'<p>' + T('attributeRegistry.js/getValueTupleDescription_noVTDescription', 'The attribute kind "$[0]" has no value tuple description, yet.', [kind])+'</p>'
		);
	} // end of method getValueTupleDescription
	,
	'supportsCBR' : function (attrConfigAsObj) {
		this._testIfKindExists(attrConfigAsObj.kind);
		var kind = this.attributeKindList[attrConfigAsObj.kind];
		return 		('supportsCBR' in kind) 
				&& 	(typeof kind.supportsCBR == 'function')
				&& 	kind.supportsCBR(attrConfigAsObj)
				;
	} // end of method
	,
	'getCBRSimilarityMethods' : function (kind) {
		if ('similarityMethods' in this.attributeKindList[kind]) return this.attributeKindList[kind].similarityMethods;
		else return {};
	} // end of method
	,
	'getCBRAdaptationMethods' : function (kind) {
		if ('adaptationMethods' in this.attributeKindList[kind]) return this.attributeKindList[kind].adaptationMethods;
		else return {};
	} // end of method getCBRAdaptationMethods
	,
	
	// internal methods
	'_testIfKindExists' : function (kind) {
		if( !(kind in this.attributeKindList)) 
			throw "application.attributeKinds::kindPermitsAssignationInput\n The passed kind\""+kind+"\" is not registered.";
	} // end of method _testIfKindExists
	,
	
	
	
	
}; // end of object definition attributeTypes

