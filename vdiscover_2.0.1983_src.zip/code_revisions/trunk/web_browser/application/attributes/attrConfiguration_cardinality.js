/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare(
	'application.widgets.configureAttribute.cardinalityConfiguration',
	[application.widgets.configureAttribute.genericConfigurationWidget],{

	'postMixInProperties' : function() {
		// If you provide a postMixInProperties method for your widget, 
		// it will be invoked before rendering occurs, and before 
		// any dom nodes are created. If you need to add or change the 
		// instance's properties before the widget is rendered 
		// - this is the place to do it.
		this.inherited(arguments);
				
		this.locateProperties([
				'cardinality', 'svFormatActivated', 
				// 'svHtmlBefore', 'svHtmlBetween', 'svHtmlAfter', 
				'svHtmlTagBeforeValueTupleSet', 'svHtmlTagAfterValueTupleSet', 'svHtmlTagBeforeValueTuple', 'svHtmlTagAfterValueTuple',
				'valueTupleReordering_permitted',
		]);
		
		if(typeof this.svHtmlTagBeforeValueTupleSet!='string')	this.svHtmlTagBeforeValueTupleSet	= '';
		if(typeof this.svHtmlTagAfterValueTupleSet!='string')	this.svHtmlTagAfterValueTupleSet	= '';
		if(typeof this.svHtmlTagBeforeValueTuple!='string')		this.svHtmlTagBeforeValueTuple		= '';
		if(typeof this.svHtmlTagAfterValueTuple!='string')		this.svHtmlTagAfterValueTuple		= '';
		
		this.hideValueTupleRepordering_configOption = 
			!application.attributeKinds.attributeKindList[this.kind]
				.standardCardinality;
		
		this.addTemplateSection( ''
			+"<tr>"
				+"<td class='textRight'>" + T('attrConfiguration_cardinality.js/Cardinality_TXT','Cardinality:') + "</td>"
				+"<td >"
					+"<p><label>"
						+"<input type='radio' dojoType='dijit.form.RadioButton' "
							+"name='application.admin.manageAttributes.CardinalityType' "
							+"dojoAttachPoint='rB_cardinalityType_any' "
							+"dojoAttachEvent='onfocus:showEditHints' "
							+"disabled='${isInherited}' "
							+"value='true' />"
							+ T('attrConfiguration_cardinality.js/AnyNumOfVT_TXT',"Any number of value tuples")
					+"</label>"
					+"<br />"
					+"<label>"
						+"<input type='radio' dojoType='dijit.form.RadioButton' "
							+"name='application.admin.manageAttributes.CardinalityType' "
							+"dojoAttachPoint='rB_cardinalityType_special' "
							+"dojoAttachEvent='onfocus:showEditHints' "
							+"disabled='${isInherited}' "
							+"value='false'/>"
							+ T('attrConfiguration_cardinality.js/ACardOf_TXT',"A cardinality of") + ' '
							+"<input dojoType='dijit.form.NumberSpinner' value='1' smallDelta='1' "
								+"constraints='{min:1,max:254,places:0}' "
								+"style='width:5em;' "
								+"disabled='${isInherited}' "
								+"dojoAttachPoint='cardinality_nS' "
								+"dojoAttachEvent='onfocus:showEditHints' "
								+"name='application.admin.manageAttributes.cardinality' />"
					+"</label></p>"
				+"</td>"
			+"</tr>"
			
			+"<tr dojoAttachPoint='_valueTupleReordering_row_domNode'>"
				+"<td class='textRight'>" + T('attrConfiguration_cardinality.js/PermToReorderVT_TXT', 'Permit to reorder the value tuples?') + "</td>"
				+"<td>"
					+"<p><label>"
						+"<input type='radio' dojoType='dijit.form.RadioButton' "
							+"name='manageAttributes.valueTupleReordering_permitted' "
							+"disabled='${isInherited}' "
							+"dojoAttachPoint='rB_valueTupleReordering_permitted_yes' "
							+"dojoAttachEvent='onfocus:showEditHints' "
							+"value='true' />"
							+ T('FUT_Yes',"Yes") + ' '
					+"</label>"
					+"&nbsp;"
					+"<label>"
						+"<input type='radio' dojoType='dijit.form.RadioButton' "
							+"name='manageAttributes.valueTupleReordering_permitted' "
							+"disabled='${isInherited}' "
							+"dojoAttachPoint='rB_valueTupleReordering_permitted_no' "
							+"dojoAttachEvent='onfocus:showEditHints' "
							+"value='false' />"
							+ T('FUT_No',"No") + ' '
					+"</label></p>"
					+"<p class='small'>" +T('attrConfiguration_cardinality.js/OptOnlyChgCardGT1_TXT','This option may only be changed if the cardinality is bigger than <code>1</code>.') + "</p>"
				+"</td>"
			+"</tr>"
			
			+"<tr>"
				+"<td class='textRight'>" + T('attrConfiguration_cardinality.js/FormatValTplEsp_TXT','Format the value tuples especially?') + "</td>"
				+"<td>"
					+"<p>"
						+"<label>"
							+"<input type='radio' dojoType='dijit.form.RadioButton' "
								+"name='application.admin.manageAttributes.svFormatActivated' "
								+"disabled='${isInherited}' "
								+"dojoAttachPoint='rB_svFormatActivated_yes' "
								+"dojoAttachEvent='onfocus:showEditHints' "
								+"value='true' />"
								+ T('FUT_Yes','Yes') + "<span class='small'>, " + T('attrConfiguration_cardinality.js/EgWith_TXT','e.g. with')  + " <code>&lt;ul&gt;</code> " + T('FUT_or','or') + " <code>&lt;ol&gt;</code></span> "
						+"</label>"
						+"<label>"
							+"<input type='radio' dojoType='dijit.form.RadioButton' "
								+"disabled='${isInherited}' "
								+"name='application.admin.manageAttributes.svFormatActivated' "
								+"dojoAttachEvent='onfocus:showEditHints' "
								+"dojoAttachPoint='rB_svFormatActivated_no' "
								+"value='false' />"
								+ T('FUT_No','No') + ' '
						+"</label>"
					+"</p>"
					+"<div dojoAttachPoint='svFormatArea'>"
						+"<table class='small fullWidth'>"
						+"<colgroup>"
							+"<col width='1*'>"
							+"<col width='1*'>"
						+"</colgroup>"
						+"<tbody>"
							
							// OLD
							// +"<tr><td colspan='2'><h4>Depreceated configuration options</h4></td></tr>"
							// +"<tr><td>HTML before the value tuples</td><td>"
								// +"<input type='text' style='width:10em;' "
								// +"dojoAttachPoint='svHtmlBefore_i' "
								// +"dojoAttachEvent='onChange:svHtmlBefore_changed' "
								// +"onfocus='application.admin.manageAttributes.showEditHints();' "
								// +"value='${svHtmlBefore}' dojoType='dijit.form.TextBox' />"
							// +"</td></tr>"
							// +"<tr><td>HTML between the value tuples</td><td>"
								// +"<input type='text' style='width:10em;' "
								// +"dojoAttachPoint='svHtmlBetween_i' "
								// +"dojoAttachEvent='onChange:svHtmlBetween_changed' "
								// +"onfocus='application.admin.manageAttributes.showEditHints();' "
								// +"value='${svHtmlBetween}' dojoType='dijit.form.TextBox' />"
							// +"</td></tr>"
							// +"<tr><td>HTML after the value tuples</td><td>"
								// +"<input type='text' style='width:10em;' "
								// +"dojoAttachPoint='svHtmlAfter_i' "
								// +"dojoAttachEvent='onChange:svHtmlAfter_changed' "
								// +"onfocus='application.admin.manageAttributes.showEditHints();' "
								// +"value='${svHtmlAfter}' dojoType='dijit.form.TextBox' />"
							// +"</td></tr>"

							// NEW
							// +"<tr><td colspan='2'><h4>New configuration options</h4></td></tr>"
							+"<tr><td colspan='2'><p>" + T('attrConfiguration_cardinality.js/PlsEnterHTMLTags_HTM','Please enter HTML tags for <i>all</i> of the following options') + "</p></td></tr>"
							+"<tr><td>" + T('attrConfiguration_cardinality.js/HTMLBeforeBeginningOfValTplSet_HTM','HTML <i>before the beginning</i> of the value tuple set') + "</td><td>"
								+"<input type='text' style='width:10em;' "
									+"disabled='${isInherited}' "
									+"dojoAttachPoint='svHtmlTagBeforeValueTupleSet_i' "
									+"dojoAttachEvent='onfocus:showEditHints' "
									+"intermediateChanges='true' required='false' "
									+"value='${svHtmlTagBeforeValueTupleSet}' dojoType='dijit.form.ValidationTextBox' />"
								+" " + T('FUT_e.g.','e.g.') + " <code>&lt;ol&gt;</code>"
							+"</td></tr>"
							+"<tr><td>" + T('attrConfiguration_cardinality.js/HTMLAfterEndOfValSet_HTM','HTML <i>after end</i> of the value tuple set') + "</td><td>"
								+"<input type='text' style='width:10em;' "
									+"disabled='${isInherited}' "
									+"dojoAttachPoint='svHtmlTagAfterValueTupleSet_i' "
									+"dojoAttachEvent='onfocus:showEditHints' "
									+"intermediateChanges='true' required='false' "
									+"value='${svHtmlTagAfterValueTupleSet}' dojoType='dijit.form.ValidationTextBox' />"
								+" " + T('FUT_e.g.','e.g.') + " <code>&lt;/ol&gt;</code>"
							+"</td></tr>"
							+"<tr><td>" + T('attrConfiguration_cardinality.js/HTMLBevoreEachValTpl_HTM','HTML <i>before</i> each value tuple') + "</td><td>"
								+"<input type='text' style='width:10em;' "
									+"disabled='${isInherited}' "
									+"dojoAttachPoint='svHtmlTagBeforeValueTuple_i' "
									+"dojoAttachEvent='onfocus:showEditHints' "
									+"intermediateChanges='true' required='false' "
									+"value='${svHtmlTagBeforeValueTuple}' dojoType='dijit.form.ValidationTextBox' />"
								+" " + T('FUT_e.g.','e.g.') + " <code>&lt;li&gt;</code>"
							+"</td></tr>"
							+"<tr><td>" + T('attrConfiguration_cardinality.js/HTMLAfterEachValTpl_HTM','HTML <i>after</i> each value tuple') + "</td><td>"
								+"<input type='text' style='width:10em;' "
									+"disabled='${isInherited}' "
									+"dojoAttachPoint='svHtmlTagAfterValueTuple_i' "
									+"dojoAttachEvent='onfocus:showEditHints' "
									+"intermediateChanges='true' required='false' "
									+"value='${svHtmlTagAfterValueTuple}' dojoType='dijit.form.ValidationTextBox' />"
								+" " + T('FUT_e.g.','e.g.') + " <code>&lt;/li&gt;</code>"
							+"</td></tr>"
							
						+"</tbody></table>"
					+"</div>"
				+"</td>"
			+"</tr>"
		);
				
		// generate the template string
		this.generateTemplateString();
				
	} // end of method postMixInProperties
	,
	'postCreate'	: function() {
		// This is typically the workhorse of a custom widget. The widget has 
		// been rendered (but note that sub-widgets in the containerNode have not!). 
		// The widget though may not be attached to the DOM yet so you shouldn't 
		// do any sizing calculations in this method.
		this.inherited(arguments);
		
		// set the cardinality
		if (this.cardinality==0) {
			// any cardinality
			this.rB_cardinalityType_any.attr('checked',true);
			this.cardinality_nS.attr('value',1);
			this.cardinality_nS.attr('disabled',true);
		} else {
			// restricted cardinality
			this.rB_cardinalityType_special.attr('checked',true);
			this.cardinality_nS.attr('value',this.cardinality);				
		} // end if
		
		// set the special HTML format options
		if (this.svFormatActivated) {
			this.rB_svFormatActivated_yes.attr('checked',true);
			dojo.style(this.svFormatArea,'display','block');
		} else {
			this.rB_svFormatActivated_no.attr('checked',true);
			dojo.style(this.svFormatArea,'display','none');
		} // end if
		
		// set valueTupleReordering_permitted
		if(this.valueTupleReordering_permitted) {
			this.rB_valueTupleReordering_permitted_yes.attr('value',true);
		} else {
			this.rB_valueTupleReordering_permitted_no.attr('value',true);
		} // end if
		
		if(this.hideValueTupleRepordering_configOption){
			dojo.style(this._valueTupleReordering_row_domNode,'display','none');
		} // end if
		
		if(!this.isInherited && (this.cardinality==1)) {
			this.rB_valueTupleReordering_permitted_yes.attr('disabled',true);
			this.rB_valueTupleReordering_permitted_no.attr('disabled',true);
		} // end if
		
		// assign some regexp attributes
		var HTML_open 		= '<[^>]{1,250}>',
			HTML_close		= '</[^>]{1,250}>',
			invalidMessage_open	='<p>Format: <code>&lt;abc&gt;</code></p>',
			invalidMessage_close	='<p>Format: <code>&lt;/abc&gt;</code></p>';

		this.svHtmlTagBeforeValueTupleSet_i	.attr('regExp', HTML_open	);
		this.svHtmlTagAfterValueTupleSet_i	.attr('regExp', HTML_close	);
		this.svHtmlTagBeforeValueTuple_i	.attr('regExp', HTML_open	);
		this.svHtmlTagAfterValueTuple_i		.attr('regExp', HTML_close	);
	
		this.svHtmlTagBeforeValueTupleSet_i	.attr('invalidMessage', invalidMessage_open		);
		this.svHtmlTagAfterValueTupleSet_i	.attr('invalidMessage', invalidMessage_close	);
		this.svHtmlTagBeforeValueTuple_i	.attr('invalidMessage', invalidMessage_open		);
		this.svHtmlTagAfterValueTuple_i		.attr('invalidMessage', invalidMessage_close	);
		
		// connect the onChange events
		if (!this.isInherited) {
			this.connect( this.rB_cardinalityType_any,					'onChange', 'rB_cardinalityType_any_changed' );
			this.connect( this.cardinality_nS,							'onChange', 'cardinality_changed' );
			this.connect( this.rB_valueTupleReordering_permitted_yes,	'onChange', 'rB_valueTupleReordering_permitted_yes_changed' );
			this.connect( this.rB_svFormatActivated_yes,				'onChange', 'rB_svFormatActivated_changed' );
			
			this.connect( this.svHtmlTagBeforeValueTupleSet_i,			'onChange', 'svHtmlTagBeforeValueTupleSet_changed' );
			this.connect( this.svHtmlTagAfterValueTupleSet_i,			'onChange', 'svHtmlTagAfterValueTupleSet_changed' );
			this.connect( this.svHtmlTagBeforeValueTuple_i,				'onChange', 'svHtmlTagBeforeValueTuple_changed' );
			this.connect( this.svHtmlTagAfterValueTuple_i,				'onChange', 'svHtmlTagAfterValueTuple_changed' );
		
		} // end if connect the onChange events
		
	} // end of method postCreate
	,
	
	'rB_valueTupleReordering_permitted_yes_changed' : function(e){
		this.propertyHasChanged( 'valueTupleReordering_permitted', this.rB_valueTupleReordering_permitted_yes.attr('checked'));
	} // end of method rB_valueTupleReordering_permitted_yes_changed
	,
	'rB_svFormatActivated_changed' : function(e) {
		this.propertyHasChanged( 'svFormatActivated', this.rB_svFormatActivated_yes.attr('checked'));
		dojo.style(this.svFormatArea,'display', ((this.svFormatActivated)?'block':'none'));
	} // end of method rB_svFormatActivated_changed
	,
	'rB_cardinalityType_any_changed' : function (e) {
		if(this.rB_cardinalityType_any.attr('value')) {
			this.cardinality=0;
			this.cardinality_nS.attr('disabled',true);
			//this.cardinality_nS.attr('value',1);
		} else {
			if(this.cardinality==0) this.cardinality=1;
			this.cardinality_nS.attr('value',this.cardinality);
			this.cardinality_nS.attr('disabled',false);
			this.cardinality=this.cardinality_nS.attr('value');
		} // end if

		this.rB_valueTupleReordering_permitted_yes.attr('disabled',(this.cardinality==1));
		this.rB_valueTupleReordering_permitted_no.attr('disabled', (this.cardinality==1));

		this.propertyHasChanged('cardinality');
	} // end of method rB_cardinalityType_any_changed
	,
	'cardinality_changed' : function (e) {
		this.propertyHasChanged('cardinality', this.cardinality_nS.attr('value'));
				
		this.rB_valueTupleReordering_permitted_yes.attr('disabled',(this.cardinality==1));
		this.rB_valueTupleReordering_permitted_no.attr('disabled', (this.cardinality==1));

	} // end of method cardinality_changed
	,



	/*
	'svHtmlBefore_changed' : function(e) {
		this.svHtmlBefore = this.svHtmlBefore_i.attr('value');
		application.admin.manageAttributes.changeAttribute(this.UUID,this.svHtmlBefore,'svHtmlBefore');		
	} // end of method svFormatHtmlBefore_changed
	,
	'svHtmlBetween_changed' : function(e) {
		this.svHtmlBetween = this.svHtmlBetween_i.attr('value');
		application.admin.manageAttributes.changeAttribute(this.UUID,this.svHtmlBetween,'svHtmlBetween');		
	} // end of method svFormatHtmlBetween_changed
	,
	'svHtmlAfter_changed' : function(e) {
		this.svHtmlAfter = this.svHtmlAfter_i.attr('value');
		application.admin.manageAttributes.changeAttribute(this.UUID,this.svHtmlAfter,'svHtmlAfter');		
	} // end of method svHtmlAfter_changed
	,
	*/
	
	
	
	'svHtmlTagBeforeValueTupleSet_changed' : function(e) {
		this.propertyHasChanged( 'svHtmlTagBeforeValueTupleSet',	this.svHtmlTagBeforeValueTupleSet_i.attr('value'));
	} // end of method svHtmlTagBeforeValueTupleSet_changed
	,
	'svHtmlTagAfterValueTupleSet_changed' : function(e) {
		this.propertyHasChanged( 'svHtmlTagAfterValueTupleSet', 	this.svHtmlTagAfterValueTupleSet_i.attr('value'));
	} // end of method svHtmlTagAfterValueTupleSet_changed
	,
	'svHtmlTagBeforeValueTuple_changed' : function(e) {
		this.propertyHasChanged( 'svHtmlTagBeforeValueTuple', 		this.svHtmlTagBeforeValueTuple_i.attr('value'));
	} // end of method svHtmlTagBeforeValueTuple_changed
	,
	'svHtmlTagAfterValueTuple_changed' : function(e) {
		this.propertyHasChanged( 'svHtmlTagAfterValueTuple', 		this.svHtmlTagAfterValueTuple_i.attr('value'));
	} // end of method svHtmlTagAfterValueTuple_changed
	,
});

