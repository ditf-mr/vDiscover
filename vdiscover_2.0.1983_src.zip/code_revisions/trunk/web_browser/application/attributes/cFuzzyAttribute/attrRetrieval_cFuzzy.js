﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare(
	'application.widgets.retrieveAttributes.cFuzzyAttribute',
	[application.widgets.retrieveAttributes.genericAttribute],
	{
		'values_changed': function() {
			/**
			 * Entry point for all changes done in the retrieval form of this attribute.
			 * - calls function to adapt (correct) the inputs in the form
			 * - calls parent retrieval modul to inform it about the changes
			 */
			this._adaptInputForm();
			this._informRetrievalModul();
		}, // end-of-method values_changed
		
		
		'_adaptInputForm': function() {
			/**
			 * Check the inputs of the retrieval form of this attributes and adapts (corrects)
			 * them if necessaray.
			 * Method is called from method 'values_changed'.
			 */
			{ // Collect all values
				var searchMode = this.searchMode_S.get('value');
				var not = this.not_cB.checked;
				var value1 = this.horizontalSlider1.get('value');
				var value2 = this.horizontalSlider2.get('value');
			}
			this.horizontalSlider1.set('disabled', false);
			this.horizontalSlider2.set('disabled', false);
			this.not_cB.set('disabled', false);
			switch (searchMode) {
				case 'exists': {
					this.not_cB.set('disabled', true);
					this.not_cB.set('checked', false);
					this.horizontalSlider1.set('disabled', true);
					this.horizontalSlider2.set('disabled', true);
					break;
				}
				case 'fromTo':
				default: {
					if ( value1 && !value2 ){
						this.horizontalSlider2.set('value',value1);
					} else if ( ! value1 && value2 ) {
						this.horizontalSlider1.set('value',value2);
					} else if ( value1 > value2 ) {
						this.horizontalSlider2.set('value',value1);
					} else {
						this.propertyHasChanged('value1',value1);
						this.propertyHasChanged('value2',value2);	
					}
					this.propertyHasChanged('searchMode',this.searchMode_S.get('value'));
					break;
				}
			} // end-of-switch
		}, // end-of-method _adaptInputForm
		

		'_informRetrievalModul': function() {
			/**
			 * Calls the parent retrieval modul to inform it about the changes in this
			 * attribute.
			 */
			{ // Collect all values
				var searchMode = this.searchMode_S.get('value');
				var not = this.not_cB.checked;
				var value1 = this.horizontalSlider1.get('value');
				var value2 = this.horizontalSlider2.get('value');
				var parsedQuery = this._parseQuery();
			}
			if (isNaN(value1)) {
				value1 = 0;
			}
			if (isNaN(value2)) {
				value2 = 0;
			}
			if (parsedQuery != '') {
				application.OT.retrieve.changeRetrievalAttribute(
					this.UUID,
					{
						'searchMode': searchMode,
						'not': not,
						'value1': value1,
						'value2': value2,
						'parsedQuery': parsedQuery,
						'ok': true
					}
				);
			}
			else {
				application.OT.retrieve.changeRetrievalAttribute(
					this.UUID,
					{
						'searchMode': '',
						'not': false,
						'value1': 0,
						'value2': 0,
						'parsedQuery': '',
						'ok': false
					}
				);
			}
		}, // end-of-method _informRetrievalModul
		
		
		'_parseQuery': function() {
			/**
			 * Generates a text form of the query, that can be displayed.
			 * @return string.
			 */
			var returnValue = '';
			{ // Get current values
				var searchMode = this.searchMode_S.get('value');
				var not = this.not_cB.checked;
				var value1 = this.horizontalSlider1.get('value');
				var value2 = this.horizontalSlider2.get('value');
			}
			{ // Generate return value 
				switch (searchMode) {
					case 'exists': {
						returnValue = T('attrRetrieval_cFuzzy.js/hasAValue_TXT','$[0] has a value', [this.name]);
						break;
					}
					case 'fromTo':
					default: {
						if (value1 && value2) {
							var linguisticVariableForValue1 = application.attributeKinds.attributeKindList['cFuzzyAttribute'].getLinguisticVariable(value1, this.set_elementNames);
							var linguisticVariableForValue2 = application.attributeKinds.attributeKindList['cFuzzyAttribute'].getLinguisticVariable(value2, this.set_elementNames);
							if (linguisticVariableForValue1 == linguisticVariableForValue2){
								if (not) {
									returnValue = T('attrRetrieval_cFuzzy.js/isNot_TXT','$[0] is not $[1]', [this.name, linguisticVariableForValue1]);
								}
								else {
									returnValue = T('attrRetrieval_cFuzzy.js/is_TXT','$[0] is not $[1]', [this.name, linguisticVariableForValue1]);
								}
							} else {
								if (not) {
									returnValue = T('attrRetrieval_cFuzzy.js/isNotBetween_TXT','$[0] is not between "$[1]" and "$[2]"', [this.name, linguisticVariableForValue1, linguisticVariableForValue2]);
								}
								else {
									returnValue = T('attrRetrieval_cFuzzy.js/isBetween_TXT','$[0] is between "$[1]" and "$[2]"', [this.name, linguisticVariableForValue1, linguisticVariableForValue2]);
								}
							}
							break;
						}
					}
				} // end-of-switch	
			}
			return (returnValue);
		}, // end-of-method _parseQuery
		
		
		'postMixInProperties': function() {
			// If you provide a postMixInProperties method for your widget, 
			// it will be invoked before rendering occurs, and before 
			// any dom nodes are created. If you need to add or change the 
			// instance's properties before the widget is rendered 
			// - this is the place to do it.
			this.inherited(arguments);

			// localise the necessary variables
			this.locateProperties(['searchMode', 'not', 'value1', 'value2', 'name', 'set_elementNames']);		
			
			// check variable and initialise them, if necessary
			if (!this.searchMode) {
				this.searchMode = 'fromto';
			}		
			if (!this.not) {
				this.not = false;
			}		
			if (!this.value1) {
				this.value1 = '';
			}
			if (!this.value2) {
				this.value2 = '';
			}
			
			// prepare output
			var checked = "";
			if (this.not == true) {
				checked = " checked='checked'";
			}

			this.title = T('attrRetrieval_cFuzzy.js/SearchParas_TIT','Search parameters');
			
			// expand the template string
			this.addTemplateSection(""
				+"<tr>"
					+"<td class='textRight' width='30%'>"+T('attrRetrieval_cFuzzy.js/ChSearchMode_LBL', 'Choose search mode:')+"</td>"
					+"<td width='70%'>"
						+"<select style='width:100%'"
							+"value='${searchMode}'" 
							+"dojoAttachEvent='onChange:values_changed'"
							+"dojoAttachPoint='searchMode_S'"
							+"dojoType='dijit.form.Select'"
						+">"
							+"<option value='fromTo'>"+T('attrRetrieval_cFuzzy.js/searchMode_isBetween_TXT', '${name} is between value1 and value2')+"</option>"
							+"<option type='separator'></option>"
							+"<option value='exists'>"+T('attrRetrieval_cFuzzy.js/hasAValue_TXT', '${name} has a value')+"</option>"
						+"</select>"
					+"</td>"
				+"</tr>"	
				+"<tr>"
					+"<td class='textRight' width='30%'> </td>"
					+"<td width='70%'>"
						+"<input type='checkbox'"
							+" value='1'"
							+checked
							+" dojoAttachEvent='onChange:values_changed'"
							+" dojoAttachPoint='not_cB'"
							+" dojoType='dijit.form.CheckBox'"
						+"/>"
						+" "
						+T('attrRetrieval_cFuzzy.js/Not_LBL', 'Negate condition of search mode')
					+"</td>"
				+"</tr>"
				+"<tr>"
					+"<td class='textRight' width='30%'>"+T('attrRetrieval_cFuzzy.js/value1_LBL', 'value<sub>1</sub> (from):')+"</td>"
					+"<td width='70%'>"
						+"<div dojoAttachPoint='attrRetrieve_outer1'>"
						+"</div>"
					+"</td>"
				+"</tr>"	
				+"<tr>"
					+"<td class='textRight' width='30%'>"+T('attrRetrieval_cFuzzy.js/value2_LBL', 'value<sub>2</sub> (to):')+"</td>"
					+"<td width='70%'>"
						+"<div dojoAttachPoint='attrRetrieve_outer2'>"
						+"</div>"
					+"</td>"
				+"</tr>"			
				+"<tr>"
					+"<td class='textRight' width='30%'>"
						+T('attrRetrieval/SearchRemarks_TXT','Remarks:')
					+"</td>"				
					+"<td width='70%'>"
							+"<ul>"
								+"<li>"
									+T('attrRetrieval_cFuzzy.js/SelSrchModeFor_HTM', 'You can select one of the following search modes:')
									+"<ul>"
										+"<li>" + T('attrRetrieval_cFuzzy.js/SrchTips_P1_HTM','<strong>«${name} lies between <i>value<sub>1</sub></i> and <i>value<sub>2</sub></i>»</strong> finds all objects where «${name}» is between <code>value<sub>1</sub> (from)</code> and <code>value<sub>2</sub> (to)</code>.')
										+"</li>"
										+"<li>" + T('attrRetrieval_cFuzzy.js/SrchTips_P2_HTM','<strong>«${name} is set»</strong> finds all objects where a value in «${name}» exists.') + "</li>"
									+"</ul>"
								+"</li>"
								+"<li>"
									+T('attrRetrieval_cFuzzy.js/SelNot_HTM', 'Negating the condition of the search mode results in a logical not in the query condition.')
								+"</li>"
							+"</ul>"
					+"</td>"
				+"</tr>"	
			);
			
			// generate the template string
			this.generateTemplateString();
			
		}, // end-of-method postMixInProperties
		

		postCreate : function () {
			this.inherited(arguments);
			
			if(!this.set_elementNames || ( this.set_elementNames.length < 1 )) {
				 dojo.create(	
					'div',
					{'innerHTML': T('attrRetrieval_cFuzzy.js/NoFuzzySetElemDef_TXT','There are no fuzzy set elements defined. Configure this attribute.') },
					this.attrRetrieve_outer1
				);
				dojo.create(	
					'div',
					{'innerHTML': T('attrRetrieval_cFuzzy.js/NoFuzzySetElemDef_TXT','There are no fuzzy set elements defined. Configure this attribute.') },
					this.attrRetrieve_outer2
				);
				return;
			} // end if there are no set elements

			dojo.require("dijit.form.Slider");
			dojo.require("dijit.form.HorizontalRule");
			dojo.require("dijit.form.HorizontalRuleLabels");

			fuzzyValueWidget = this;
			
			{ // create slider for value 1
				// create the slider for the fuzzified value
				this.sliderContainer1 = dojo.create('div',{},this.attrRetrieve_outer1);
				this.horizontalSlider1 = new dijit.form.HorizontalSlider({
					attrEditor : this,
					//name: "horizontalslider",
					clickSelect : true,
					value: this.value1,
					minimum: 0,
					maximum: 1,
					intermediateChanges: false,
					//discreteValues: this.config.numSet_elementNames,
					onChange : function(value) {
						fuzzyValueWidget.values_changed();
					}
				}, this.sliderContainer1);	

				// create the horizontal rules (just a division for the vertical dashes)
				this.sliderRules1 = new dijit.form.HorizontalRule({
					count:this.set_elementNames.length,
					style: { height: ".5ex" }
				});
				this.horizontalSlider1.addChild(this.sliderRules1);

				// create the labels for the elements in the fuzzy set
				this.sliderLabelsNode1 = dojo.create('div',{'height':'1.5em'});
				this.sliderLabels1 = new dijit.form.HorizontalRuleLabels({
					count : this.set_elementNames.length,
					container: "bottomDecoration",
					labels: this.set_elementNames
					,
					style: 'height:1.5em;'
				}, this.sliderLabelsNode1);
				//sliderLabels.srcNodeRef = sliderLabels.domNode; // horribly dangerous, but is avoids a bug ...
				this.horizontalSlider1.addChild(this.sliderLabels1);
			}
			
			{ // create slider for value 2
				// create the slider for the fuzzified value
				this.sliderContainer2 = dojo.create('div',{},this.attrRetrieve_outer2);
				this.horizontalSlider2 = new dijit.form.HorizontalSlider({
					attrEditor : this,
					//name: "horizontalslider",
					clickSelect : true,
					value: this.value2,
					minimum: 0,
					maximum: 1,
					intermediateChanges: false,
					//discreteValues: this.config.numSet_elementNames,
					onChange : function(value) {
						fuzzyValueWidget.values_changed();
					}
				}, this.sliderContainer2);	
			
				// create the horizontal rules (just a division for the vertical dashes)
				this.sliderRules2 = new dijit.form.HorizontalRule({
					count:this.set_elementNames.length,
					style: { height: ".5ex" }
				});
				this.horizontalSlider2.addChild(this.sliderRules2);

				// create the labels for the elements in the fuzzy set
				this.sliderLabelsNode2 = dojo.create('div',{'height':'1.5em'});
				this.sliderLabels2 = new dijit.form.HorizontalRuleLabels({
					count : this.set_elementNames.length,
					container: "bottomDecoration",
					labels: this.set_elementNames
					,
					style: 'height:1.5em;'
				}, this.sliderLabelsNode2);
				//sliderLabels.srcNodeRef = sliderLabels.domNode; // horribly dangerous, but is avoids a bug ...
				this.horizontalSlider2.addChild(this.sliderLabels2);
			}
		} // end-of-method postCreate
		
	}
);
	