﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare("application.widgets.valueTupleEditor_cFuzzyAttribute",[application.widgets.valueTupleEditor_generic],{
	'buildTemplateContainer' : function() {
		this.templateContainer = '';
	} // end of method postMixInProperties
	,
	'postCreate' : function () {
		this.inherited(arguments);
		
		if(!this.config.numSet_elementNames) {
			 dojo.create(	
				'div',
				{'innerHTML': T('attrValueTupleEditor_cFuzzy.js/NoFuzzySetElemDef_TXT','There are no fuzzy set elements defined. Configure this attribute.') },
				this.containerNode
			);
			 return;
		} // end if there are no set elements
		
		dojo.require("dijit.form.Slider");
		dojo.require("dijit.form.HorizontalRule");
		dojo.require("dijit.form.HorizontalRuleLabels");
		
		// set the default value if possible
		if((this.valueTuple.value_fuzzified==='') && this.config.defaultValue && (''+this.config.defaultValue+'').length)
			this.valueTuple.value_fuzzified = this.config.defaultValue/(this.config.numSet_elementNames-1);
		
		// create the slider for the fuzzified value
		this.sliderContainer = dojo.create('div',{},this.containerNode);
		this.horizontalSlider = new dijit.form.HorizontalSlider({
			'attrEditor' 		: this,
			//name: "horizontalslider",
			'clickSelect' 		: true,
			'value': this.valueTuple.value_fuzzified,
			'minimum'			: 0,
			'maximum'			: 1,
			'intermediateChanges': false,
			//discreteValues: this.config.numSet_elementNames,
		}, this.sliderContainer);
		// the following line is for unknown reasons no good idea
		this.connect(this.horizontalSlider, 'onChange', 'notifyAttributeOfChangedValue');
		// this._supportingWidgets.push(this.horizontalSlider);
		
		// create the horizontal rules (just a division for the vertical dashes)
		this.sliderRules = new dijit.form.HorizontalRule({
			count:this.config.numSet_elementNames,
			style: { height: ".5ex" }
		});
		this.horizontalSlider.addChild(this.sliderRules);
		
		// create the labels for the elements in the fuzzy set
		this.sliderLabelsNode = dojo.create('div',{'height':'1.5em'});
		this.sliderLabels = new dijit.form.HorizontalRuleLabels({
			'class' 	: 'small',
			'count' 	: this.config.numSet_elementNames,
			'container'	: "bottomDecoration",
			'labels'	: this.attrWidget.getFormattedSliderLabels()//this.config.set_elementNames
			,
			'style'		: 'height:1.25em;'
		}, this.sliderLabelsNode);
		//sliderLabels.srcNodeRef = sliderLabels.domNode; // horribly dangerous, but is avoids a bug ...
		this.horizontalSlider.addChild(this.sliderLabels);
		
	} // end of method postCreate
	,
	'getValueTuple' : function () {
		// This method returns the current value tuple without having it validated.
	
		var vT = {
			'value_fuzzified'		: 	this.horizontalSlider.attr('value'),
			'AV_UUID' 			: 	this.valueTuple.AV_UUID,
			'UUID'				:	this.valueTuple.UUID,
			'positionOfValue' 	: 	this.valueTuple.positionOfValue
		};
		
		// get membership to linguistic variables
		var attributeKind 	= application.attributeKinds.attributeKindList[this.config.kind];
		var membershipArray = attributeKind.getMembershipToElements(vT.value_fuzzified, this.config.numSet_elementNames); 
		
		dojo.mixin(vT, membershipArray);
		
		return vT;
	} // end of method getValueTuple
	,
	'setValueTuple' : function (vT) {
		// this method updates the value tuple and sets the input slider, accordingly
		
		this.horizontalSlider.attr('value', vT.value_fuzzified)
		
		this.notifyAttributeOfChangedValue();
	} // end of method setValueTuple
	,
	'notifyAttributeOfChangedValue' : function () {
	
		this.attrWidget.valueTupleHasChanged(this.valueTupleUUID, this.getValueTuple() );		
	
	} // end of method valueHasChanged
	,
	'isValid' : function () {
		return true;
	} // end of method isValid
	/* -- the following method is for unknown reasons no good idea ...
	,
	'destroy' : function () {
		
		var subWidgets = dijit.findWidgets(this.containerNode);
		dojo.forEach(subWidgets,function(w){
			if (w.destroyRecursive) w.destroyRecursive();
		},this);
		delete subWidgets;
		
		this.inherited(arguments);
	} // end of method destroy
	*/
});

