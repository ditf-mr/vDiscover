﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare("application.widgets.cFuzzyAttribute",[application.widgets.standardAttribute],{
	'_emptyValueTuple': { 
		'value_fuzzified' 		: '',  
		'degreeOfMembership_0'	: '',
		'degreeOfMembership_1'	: '',
		'degreeOfMembership_2'	: '',
		'degreeOfMembership_3'	: '',
		'degreeOfMembership_4'	: '',
		'degreeOfMembership_5'	: '',
		'degreeOfMembership_6'	: ''
	}
	,
	'valueTupleEditor_name': 'application.widgets.valueTupleEditor_cFuzzyAttribute'
	,
	'tuple_isEmpty' : function (tuple) {
		
		if (!tuple) return true;
		
		var isEmpty = false;
		if(dojo.isString(tuple.value_fuzzified) && (tuple.value_fuzzified=='')) isEmpty=true;
		
		return isEmpty;
	} // end of method tuple_isEmpty
	,
	'htmlFormatValueTuple_readMode' : function (valueTuple) {
		if(!this.config.numSet_elementNames)
			return '<p>' + T('attr_cFuzzy.js/NoFuzzyElements_TXT','There are no fuzzy set elements defined. You need to configure this attribute.') + '</p>';
		
		if(typeof valueTuple.AV_UUID=='undefined') return this._noValueSet;
		
		return ''; // all rendering will be carried out in postCreate
	} // end of method htmlFormatValueTuple_ReadMode
	,
	'postCreate' : function () {// 'startup' : function () {
		this.inherited(arguments);
		if(!this.config.numSet_elementNames || !this.valueTuples) return;
	
		if(this.outputMode!='read') return; // the following code is for the read mode, only!
	
		dojo.require("dijit.form.Slider");
		dojo.require("dijit.form.HorizontalRule");
		dojo.require("dijit.form.HorizontalRuleLabels");
		
		// iterate over all value tuples
		for(var i in this.valueTuples){
			var valueTuple =this.valueTuples[i];
			
			// Note: valueTuple.AV_UUID is the DOM node where the fuzzy value needs to be rendered
			// create the slider for the fuzzified value
			var sliderContainer = dojo.create('div',{},this.containerNode);
			var horizontalSlider = new dijit.form.HorizontalSlider({
				attrEditor : this,
				//name: "horizontalslider",
				value: valueTuple.value_fuzzified,
				minimum: 0,
				maximum: 1,
				readOnly : true
			}, sliderContainer);
			// the following line is for unknown reasons no good idea
			//this._supportingWidgets.push(horizontalSlider);
			
			// create the horizontal rules (just a division for the vertical dashes)
			var sliderRules = new dijit.form.HorizontalRule({
				count:this.config.numSet_elementNames,
				style: { height: ".5ex" }
			});
			horizontalSlider.addChild(sliderRules);

			// create the labels for the elements in the fuzzy set
			var sliderLabelsNode = dojo.create('div',{'height':'1.25em'},this.containerNode);
			var sliderLabels = new dijit.form.HorizontalRuleLabels({
				'class' 	: 'small',
				'count'		: this.config.numSet_elementNames,
				'container'	: 'bottomDecoration',
				'labels'	: this.getFormattedSliderLabels()
				,
				'style'		: 'height:1.25em;'
			}, sliderLabelsNode);
			horizontalSlider.addChild(sliderLabels);
			
		} // end for .. in
		
		this.showHide_noValueTuplesMessage();
		
	} // end of method startup
	,
	'getFormattedSliderLabels' : function () {
		var preparedlabelSet = [];
		dojo.forEach(this.config.set_elementNames,function(n){
			preparedlabelSet.push(n.replace(/\s+/,'&nbsp;'));
		},this);
		return preparedlabelSet;
	} // end of method getFormattedSliderLabels
	,
	'destroy' : function () {
		
		if (this.containerNode) {
			var subWidgets = dijit.findWidgets(this.containerNode);
			dojo.forEach(subWidgets,function(w){
				if (w.destroyRecursive) w.destroyRecursive();
			},this);
			delete subWidgets;
		} // end if
		
		this.inherited(arguments);
	} // end of method destroy
}); // end of declaration
