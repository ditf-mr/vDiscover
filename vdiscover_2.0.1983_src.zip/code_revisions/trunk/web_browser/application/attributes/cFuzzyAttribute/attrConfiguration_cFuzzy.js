﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare('application.widgets.configureSpecialAttribute.cFuzzyAttribute',[application.widgets.configureAttribute.genericConfigurationWidget],{

	'maxElementsInSet' : 7
	,
	'postMixInProperties': function() {
		this.inherited(arguments);
		
		//localise the necessary variables
		this.locateProperties(['set_elementNamesAsString','defaultValue', 'parentDefaultValue']);
		
		// expand the template string
		dojo.require('dijit.form.SimpleTextarea');
		for (var index=0;index<this.maxElementsInSet;index++) this.addTemplateSection(""
			+"<tr>"
				+((index==0)?"<td style='width:30%;' class='textRight' rowspan='"+this.maxElementsInSet+"'>" + T('attrConfiguration_cFuzzy.js/ElementNames_TXT','Element names:') + "</td>":"")
				+"<td style='width:40%;' >"
					+"<input type='text' class='fullWidth' "
					+"value='${element_"+index+"}' "
					+"dojoAttachEvent='onChange:elementChanged,onFocus:showFuzzyValueEditHints' "
					+"dojoAttachPoint='element_"+index+"_tB' "
					+"dojoType='dijit.form.TextBox' "
					+"/>"
				+"</td>"
				+"<td style='width:30%;' >"
					+"<label>"
						+"<input type='radio' "
							+"name='application.widgets.configureAttributes.cFuzzyAttribute.defaultValue' "
							+"value='"+index+"' "
							+"checked="+((this.defaultValue==index)?"'true'":"'false'")
							+"dojoType='dijit.form.RadioButton' "
							+"dojoAttachEvent='onChange:defaultValue_changed' "
							+"dojoAttachPoint='defaultValue_rB"+index+"' "
						+"/>"
						+"&nbsp;" + T('attrConfiguration_cFuzzy.js/DefVal_TXT','default value')
					+"</label>"					
				+"</td>"
			+"</tr>"
		);
		
		this.addCommentTemplateSection( ""
			+"<p dojoAttachPoint='resetToInheritedDefaultValue_node' style='display:none'>"
				+ T('attrConfiguration_cFuzzy.js/InheritedDefValComment_HTM',
					'The inherited default value is « <code>${parentDefaultValue_asText}</code>» .<br/> To reset the current default value to the inherited one, click <a dojoAttachEvent="onclick:resetDefaultValue_clicked">here</a>.'
					)
			+"</p>"
		);

		// break the set element names down into individual ones
		this.parentDefaultValue_asText = '';
		
		for(var index=0;index<this.maxElementsInSet;index++) this['element_'+index]='';
		if (this.set_elementNamesAsString) {
			var elements=this.set_elementNamesAsString.split('\n');
			dojo.forEach(elements,function(set_element,index) {
				var option = dojo.trim(set_element);
				this['element_'+index]=option;
				if (this.parentDefaultValue==index) this.parentDefaultValue_asText=option;
			}, this);
		} // end if
		
		// generate the template string
		this.generateTemplateString();
		
	} // end of method postMixInProperties
	,
	'resetDefaultValue_clicked' : function (e) {
		alert(this.parentDefaultValue);
		
		this['defaultValue_rB'+this.parentDefaultValue].attr('checked', true);
		
		dojo.stopEvent(e);
	} // end of method resetDefaultValue_clicked
	,
	'elementChanged' : function(e) {
		
		this.set_elementNamesAsString='';
		
		// iterate over all set elements and extract their names
		var setElements=[];		
		for(var index=0; index<this.maxElementsInSet;index++) setElements.push(this['element_'+index+'_tB'].attr('value'));
		
		// join the set element names and remove unnecessary line breaks, afterwards
		this.set_elementNamesAsString=setElements.join('\n').replace(/\n{2,}/g, '\n').replace(/\n+$/g,'');
		
		this.propertyHasChanged('set_elementNamesAsString');
		
	} // end of method elementChanged
	,
	'defaultValue_changed' : function(e) {
		
		// e is either true of false
		if(!e) return; // it does not make sense to carry out this method, twice for both e=true and e=false
		
		// iterate over all radio buttons and extract the default value
		for (var index=0;index<this.maxElementsInSet;index++) 
			if (this['defaultValue_rB'+index].attr('checked')) {
				this.defaultValue=index;
				break;
			} // end if
		
		this.propertyHasChanged('defaultValue');

		if(this.isInherited && this.parentDefaultValue) {
			dojo.style( this.resetToInheritedDefaultValue_node, 'display', 
				((this.parentDefaultValue != this.defaultValue)?'block':'none') );
		} // end if
		
	} // end of method defaultValue_changed
	,
	'postCreate' : function () {
		this.inherited(arguments);
	
		for (var index=0;index<this.maxElementsInSet;index++) {
			this["element_"+index+"_tB"].attr('disabled', this.isInherited);
		} // end for .. in 
		
		if(this.isInherited && this.parentDefaultValue) {
			dojo.style( this.resetToInheritedDefaultValue_node, 'display', 
				((this.parentDefaultValue != this.defaultValue)?'block':'none') );
		} // end if
		
	} // end of method postCreate
});
