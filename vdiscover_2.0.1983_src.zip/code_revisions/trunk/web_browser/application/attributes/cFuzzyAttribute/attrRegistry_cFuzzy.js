﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

application.attributeKinds.register({kind: "cFuzzyAttribute", 
	defaultConfiguration : { 
		cardinality: 		1, 

		svFormatActivated:	false,
		svHtmlBefore: 		'',
		svHtmlBetween: 		'',
		svHtmlAfter: 		'',

		set_elementNamesAsString :	''
	}
	,
	fixedCardinality : 		true
	,
	defaultRetrievalValues:['searchMode', 'not', 'value1', 'value2']
	,
	widgetClass: 			'application.widgets.cFuzzyAttribute'
	,
	configurationWidgetClass : 'application.widgets.configureAttributes.cFuzzyAttribute'
	,
	getMembershipToElements: function (value /* slider value */, numberOfLinguisticVariables) {
		
		var membershipArray = {};
				
		// estimate the degrees of membership
		var halfElementDistance= 1/(numberOfLinguisticVariables-1);
		for (var index=0;index<numberOfLinguisticVariables;index++) {
			var elementPosition=index/(numberOfLinguisticVariables-1);
			var ePo_mhDist=elementPosition-halfElementDistance;
			var ePo_phDist=elementPosition+halfElementDistance;
			membershipArray['degreesOfMembership_'+index]= 0
				+((ePo_mhDist<=value && value<=elementPosition)?((numberOfLinguisticVariables-1)*(value-ePo_mhDist)):0)
				+((elementPosition<value && value<=ePo_phDist)?( -(numberOfLinguisticVariables-1)*(value-elementPosition)+1):0)
			;
		} // end for
		
		return membershipArray;
	}
	,
	getLinguisticVariable: function ( value /* slider value */, linguisticVariablesArray){

		// get membership of value to linguistic variables	
		var membershipArrayValue = this.getMembershipToElements(
											value,
											linguisticVariablesArray.length); 

		// find linguistic variable for value1
		var linguisticVariable = '';
		var i = 0;
		while(!linguisticVariable && (i < linguisticVariablesArray.length)){
			if ( membershipArrayValue['degreesOfMembership_'+i] >= 0.5 ) {
				linguisticVariable = linguisticVariablesArray[i];
			} else {
				i++;
			}
		}
											
		return 	linguisticVariable;	
	}
	,
	'getRqWidgetAttributeStore': function() {
		return (rqWidget.attributeStore);
	}
	,
	
	// Analytical expression configuration -------------------------------------------
	'useValueTupleAsExpressionInput'	: true
	,
	'expressionsPermitted'				: true
	,
	'defExprValTasJSON'					: "{\n  \"value_fuzzified\": .5, // required float ∈ [0..1]\n}"
	,
});

