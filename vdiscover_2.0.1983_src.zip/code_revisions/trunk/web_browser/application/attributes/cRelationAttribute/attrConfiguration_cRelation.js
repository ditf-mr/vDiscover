﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare(
	'application.widgets.configureSpecialAttribute.cRelationAttribute',
	[application.widgets.configureAttribute.genericConfigurationWidget], {

	'postMixInProperties': function() {
		this.inherited(arguments);
		
		// expand the template string
		this.addTemplateSection(""
			+"<tr>"
				+"<td class='textRight'>"
					+T('attrConfiguration_cRelation.js/RelationType_TXT', 'Relation type:')
				+"</td>"
				+"<td>"
					+"<div dojoAttachPoint='RT_dDList_DOMNode'/>"
				+"</td>"
			+"</tr>"
			
			+"<tr>"
				+"<td class='textRight'>"
					+T('attrConfiguration_cRelation.js/Display_TXT', 'Display …')
				+"</td> "
				+"<td>"
					+"<label>"
						+"<input type='radio' dojoType='dijit.form.RadioButton' "
							+"name='configureAttributes.cRelationAttribute.showWhat' "
							+"dojoAttachEvent='onFocus:showEditHints, onChange:showWhat_changed' "
							+"dojoAttachPoint='showWhat_N_rB'"
							+"value='false' />"
						+T('attrConfiguration_cRelation.js/DisplayName_LBL', 'the name')
					+"</label>"
					+"<br />"
					+"<label>"
						+"<input type='radio' dojoType='dijit.form.RadioButton' "
							+"name='configureAttributes.cRelationAttribute.showWhat' "
							+"dojoAttachEvent='onFocus:showEditHints, onChange:showWhat_changed' "
							+"dojoAttachPoint='showWhat_A_rB' dojoAttachEvent='onChange:showWhat_changed' "
							+"value='false' />"
						+T('attrConfiguration_cRelation.js/Display_attribute_LBL', 'value tuples of an attribute (the attribute configuration will be set to « read only» , automatically)')
					+"</label>"
					+"<br />"
					+"<label>"
						+"<input type='radio' dojoType='dijit.form.RadioButton' "
							+"name='configureAttributes.cRelationAttribute.showWhat' "
							+"dojoAttachEvent='onFocus:showEditHints, onChange:showWhat_changed' "
							+"dojoAttachPoint='showWhat_V_rB' dojoAttachEvent='onChange:showWhat_changed' "
							+"value='true' />"
						+T('attrConfiguration_cRelation.js/Display_view_LBL', 'a view')
					+"</label>"
					+"<br/>"
					+T('attrConfiguration_cRelation.js/Display_relatedObject_TXT', '… of the related object(s).')
				+"</td>"
			+"</tr>"
			
			+"<tr>"
				+"<td class='textRight'>" + T('attrConfiguration_cRelation.js/PlsSelect_TXT', 'Please select:') + "</td> "
				+"<td>"
					+"<div dojoAttachPoint='AV_dDList_DOMNode'/>"
				+"</td>"
			+"</tr>"
			
			+"<tr>"
				+"<td class='textRight'>"
					+T('attrConfiguration_cRelation.js/EnableEditing_TXT', 'Enable editing of the related object?')
				+"</td> "
				+"<td>"
					+"<label>"
						+"<input type='radio' dojoType='dijit.form.RadioButton' "
							+"name='configureAttributes.cRelationAttribute.editRelatedObject' "
							+"dojoAttachPoint='editRelatedObject_Yes_rB' dojoAttachEvent='onChange:editRelatedObject_changed,onFocus:showEditHints' "
							+"value='true' />"
						+T('FUT_Yes','Yes')
					+"</label>"
					+"&nbsp;"
					+"<label>"
						+"<input type='radio' dojoType='dijit.form.RadioButton' "
							+"name='configureAttributes.cRelationAttribute.editRelatedObject' "
							+"dojoAttachPoint='editRelatedObject_No_rB' dojoAttachEvent='onChange:editRelatedObject_changed,onFocus:showEditHints' "
							+"value='false' />"
						+T('FUT_No','No')
					+"</label>"
					+"<br/>"
					+T('attrConfiguration_cRelation.js/EnableEditing_Explanation_TXT', 'Enable editing only, if the target object forms part of the current object.')
				+"</td>"
			+"</tr>"

			+"<tr>"
				+"<td class='textRight'>"
					+T('attrConfiguration_cRelation.js/HideRelationAttributes_TXT', 'Hide relation attributes of this relation type?')
				+"</td> "
				+"<td>"
					+"<label>"
						+"<input type='radio' dojoType='dijit.form.RadioButton' "
							+"name='configureAttributes.cRelationAttribute.hideAttributes' "
							+"dojoAttachPoint='hideAttributes_yes_rB' dojoAttachEvent='onChange:hideAttributes_changed,onFocus:showEditHints' "
							+"value='false' />"
						+T('FUT_Yes','Yes')
					+"</label>"
					+"&nbsp;"
					+"<label>"
						+"<input type='radio' dojoType='dijit.form.RadioButton' "
							+"name='configureAttributes.cRelationAttribute.hideAttributes' "
							+"dojoAttachPoint='hideAttributes_no_rB' dojoAttachEvent='onChange:hideAttributes_changed,onFocus:showEditHints' "
							+"value='false' />"
						+T('FUT_No','No')
					+"</label>"
					+"<br/>"
					+T('attrConfiguration_cRelation.js/HideRelationAttributes_Explanation_TXT', 
						'Set this option to « Yes» , if you don\'t want to display the relation attributes and their values in this attribute. In this case this attribute is set to « read only» , automatically. This avoids problems by only editing a relationship, partially. <br/>You need this option only, if the selected relationship type has attributes. ')
				+"</td>"
			+"</tr>"
			
			+"<tr>"
				+"<td class='textRight'>"
					+T('attrConfiguration_cRelation.js/PermitMultipleRelations_TXT', 'Permit multiple relations to the same target object?')
				+"</td> "
				+"<td>"
					+"<label>"
						+"<input type='radio' dojoType='dijit.form.RadioButton' "
							+"name='configureAttributes.cRelationAttribute.multipleRelations' "
							+"dojoAttachPoint='multipleRelationsToTheSameTarget_permitted_yes_rB' dojoAttachEvent='onChange:multRels_changed,onFocus:showEditHints' "
							+"value='false' />"
						+T('FUT_Yes','Yes')
					+"</label>"
					+"&nbsp;"
					+"<label>"
						+"<input type='radio' dojoType='dijit.form.RadioButton' "
							+"name='configureAttributes.cRelationAttribute.multipleRelations' "
							+"dojoAttachPoint='multipleRelationsToTheSameTarget_permitted_no_rB' dojoAttachEvent='onChange:multRels_changed,onFocus:showEditHints' "
							+"value='false' />"
						+T('FUT_No','No')
					+"</label>"
					+"<br/>"
					+T('attrConfiguration_cRelation.js/PermitMultipleRelations_Explanation_TXT', 
						'Set this option to « Yes» , if you want to document e.g. bills of materials (recipes) where an ingredient may appear multiple times. You need this option only, if cardinality is bigger than <code>1</code> and if the selected relationship type has attributes. ')
				+"</td>"
			+"</tr>"
			

			+"<tr>"
				+"<td class='textRight'>"
					+T('attrConfiguration_cRelation.js/CreateMulti_TXT', 'Create multiple relations at once?')
				+"</td> "
				+"<td>"
					+"<label>"
						+"<input type='radio' dojoType='dijit.form.RadioButton' "
							+"name='configureAttributes.cRelationAttribute.multipleRelationsAtOnce' "
							+"dojoAttachPoint='multipleRelationsAtOnce_permitted_yes_rB' dojoAttachEvent='onChange:multRelsAtOnce_changed,onFocus:showEditHints' "
							+"value='false' />"
						+T('FUT_Yes','Yes')
					+"</label>"
					+"&nbsp;"
					+"<label>"	
						+"<input type='radio' dojoType='dijit.form.RadioButton' "
							+"name='configureAttributes.cRelationAttribute.multipleRelationsAtOnce' "
							+"dojoAttachPoint='multipleRelationsAtOnce_permitted_no_rB' dojoAttachEvent='onChange:multRelsAtOnce_changed,onFocus:showEditHints' "
							+"value='false' />"
						+T('FUT_No','No')
					+"</label>"
					+"<br/>" + T('attrConfiguration_cRelation.js/SetOptToYes_HTM', 'Set this option to « Yes»  to be able to select many target objects to which relations shall be created.') + " "
				+"</td>"
			+"</tr>"
			
			+"<tr>"
				+"<td class='textRight'>"
					+T('attrConfiguration_cRelation.js/PermitToCreateDuplicate_HTM', 'Permit to create relations to a <em>duplicate</em> of the target object?')
				+"</td> "
				+"<td>"
					+"<label>"
						+"<input type='radio' dojoType='dijit.form.RadioButton' "
							+"name='configureAttributes.cRelationAttribute.duplicateTargetBeforeCreating' "
							+"dojoAttachPoint='duplicateTargetBeforeCreating_yes_rB' dojoAttachEvent='onChange:duplicateTargetBeforeCreating_changed,onFocus:showEditHints' "
							+"value='false' />"
						+T('FUT_Yes','Yes')
					+"</label>"
					+"&nbsp;"
					+"<label>"
						+"<input type='radio' dojoType='dijit.form.RadioButton' "
							+"name='configureAttributes.cRelationAttribute.duplicateTargetBeforeCreating' "
							+"dojoAttachPoint='duplicateTargetBeforeCreating_no_rB' dojoAttachEvent='onChange:duplicateTargetBeforeCreating_changed,onFocus:showEditHints' "
							+"value='false' />"
						+T('FUT_No','No')
					+"</label>"
					+"<br />"
					+T('attrConfiguration_cRelation.js/PermitToCreateDuplicate_Explanation_TXT', 'This option adds a button that permits to create a new target object as a duplicate of an existing one, instead of selecting an existing one.')
				+"</td>"
			+"</tr>"
			
			+"<tr>"
				+"<td class='textRight'>"
					+T('attrConfiguration_cRelation.js/PermitToCreateNew_HTM', 'Permit to create relations to a <em>new</em> target object?')
				+"</td> "
				+"<td>"
					+"<label>"
						+"<input type='radio' dojoType='dijit.form.RadioButton' "
							+"name='configureAttributes.cRelationAttribute.creatingTargetObject_permitted' "
							+"dojoAttachPoint='creatingTargetObject_permitted_yes_rB' dojoAttachEvent='onChange:creatingTargetObject_permitted_changed,onFocus:showEditHints' "
							+"value='false' />"
						+T('FUT_Yes','Yes')
					+"</label>"
					+"&nbsp;"
					+"<label>"
						+"<input type='radio' dojoType='dijit.form.RadioButton' "
							+"name='configureAttributes.cRelationAttribute.creatingTargetObject_permitted' "
							+"dojoAttachPoint='creatingTargetObject_permitted_no_rB' dojoAttachEvent='onChange:creatingTargetObject_permitted_changed,onFocus:showEditHints' "
							+"value='false' />"
						+T('FUT_No','No')
					+"</label>"
					+"<br/>"
					+T('attrConfiguration_cRelation.js/PermitToCreateNew_Explanation_TXT', 'This option adds a button that permits to create a new target object instead of selecting an existing one.')
				+"</td>"
			+"</tr>"
		);
		
		//localise the necessary variables
		this.locateProperties([	'selected_RT_UUID', 'showWhat', 'show_UUID', 'hideAttributes', 'multipleRelationsToTheSameTarget_permitted',
								'multipleRelationsAtOnce', 'duplicateTargetBeforeCreating', 'creatingTargetObject_permitted', 'editRelatedObject'
								/*,'OT_UUID'*/]);
		this.OT_UUID 		= this.dialog.OT_UUID;
		
		// generate the template string
		this.generateTemplateString();
		
	} // end of method postMixInProperties
	,
	'showWhat_changed' : function(e) {
		this.showWhat = (this.showWhat_N_rB.attr('checked')?'N':(this.showWhat_A_rB.attr('checked')?'A':'V'));
		this.propertyHasChanged('showWhat');
		this.loadAttributeOrViewList();
	} // end of method displayWhat_changed
	,
	'editRelatedObject_changed' : function(e) {
		this.editRelatedObject = (this.editRelatedObject_Yes_rB.attr('checked'));
		this.propertyHasChanged('editRelatedObject');
	} // end of method displayWhat_changed
	,
	'hideAttributes_changed' : function (e) {
		this.hideAttributes = 
			this.hideAttributes_yes_rB.attr('checked');
		this.propertyHasChanged('hideAttributes');
	}
	,
	'multRels_changed' : function(e) {
		this.multipleRelationsToTheSameTarget_permitted = 
			this.multipleRelationsToTheSameTarget_permitted_yes_rB.attr('checked');
		this.propertyHasChanged('multipleRelationsToTheSameTarget_permitted');
	} // end of method multRels_changed
	,
	'multRelsAtOnce_changed' : function (e) {
		this.multipleRelationsAtOnce = 
			this.multipleRelationsAtOnce_permitted_yes_rB.attr('checked');
		this.propertyHasChanged('multipleRelationsAtOnce');
	}
	,
	'duplicateTargetBeforeCreating_changed' : function (e) {
		this.duplicateTargetBeforeCreating = 
			this.duplicateTargetBeforeCreating_yes_rB.attr('checked');
		this.propertyHasChanged('duplicateTargetBeforeCreating');
	}
	,
	'creatingTargetObject_permitted_changed' : function (e) {
		this.creatingTargetObject_permitted = 
			this.creatingTargetObject_permitted_yes_rB.attr('checked');
		this.propertyHasChanged('creatingTargetObject_permitted');
	}
	,
	'postCreate': function() {
		this.inherited(arguments);
		
		this.showWhat_N_rB.attr('checked',(this.showWhat=='N'));
		this.showWhat_A_rB.attr('checked',(this.showWhat=='A'));
		this.showWhat_V_rB.attr('checked',(this.showWhat=='V'));

		this.hideAttributes_yes_rB.attr('checked',(this.hideAttributes==true));
		this.hideAttributes_no_rB.attr( 'checked',(this.hideAttributes!=true));
		
		this.multipleRelationsToTheSameTarget_permitted_yes_rB.attr('checked',(this.multipleRelationsToTheSameTarget_permitted==true));
		this.multipleRelationsToTheSameTarget_permitted_no_rB.attr( 'checked',(this.multipleRelationsToTheSameTarget_permitted!=true));
		
		this.multipleRelationsAtOnce_permitted_yes_rB.attr('checked',(this.multipleRelationsAtOnce==true));
		this.multipleRelationsAtOnce_permitted_no_rB.attr( 'checked',(this.multipleRelationsAtOnce!=true));
		
		this.duplicateTargetBeforeCreating_yes_rB.attr('checked',(this.duplicateTargetBeforeCreating==true));
		this.duplicateTargetBeforeCreating_no_rB.attr('checked',(this.duplicateTargetBeforeCreating!=true));
		
		this.creatingTargetObject_permitted_yes_rB.attr('checked',(this.creatingTargetObject_permitted==true));
		this.creatingTargetObject_permitted_no_rB.attr( 'checked',(this.creatingTargetObject_permitted!=true));
		
		this.editRelatedObject_Yes_rB.attr('checked',(this.editRelatedObject==true));
		this.editRelatedObject_No_rB.attr( 'checked',(this.editRelatedObject!=true));
		
		application.OT_AJAX_query(
			{ 
				"task"	: 'get_OT_relationTypes_asStart', 
				"UUID"	: this.OT_UUID,
				'callerWidget' : this.id // leave this in, here!!!
			}, 
			this.get_RT_onSuccess,
			true // synchronous query
			);	// end AJAX query
		
		if (this.selected_RT_UUID) {
			this.loadAttributeOrViewList();
		} else {
			dojo.create('p',{innerHTML:'&mdash;'},this.AV_dDList_DOMNode);
		} // end if
				
		// inheriance-related issues
		if (this.isInherited) {
			var subWidgets = dijit.findWidgets(this.domNode);
			dojo.forEach(subWidgets, function(w){ w.attr('disabled', true )});
		} // end if

	} // end of method postCreate
	,
	'get_RT_onSuccess' : function(r,a){
	
		var callerWidget = dijit.byId(a.args.content.callerWidget);
	
		dojo.require("dijit.form.FilteringSelect");
		callerWidget.RT_dDList = new dijit.form.FilteringSelect({
			rCWidget: 		callerWidget,
			value: 			"",
			store: 			new dojo.data.ItemFileReadStore({data:r}),
			searchAttr: 	"label",
			'class':		"fullWidth",
			name:			'name',
			value:			callerWidget.selected_RT_UUID,
			searchAttr:		'label',
			highlightMatch:	'all',
			queryExpr:		'*${0}*',
			ignoreCase:		true,
			missingMessage:	T('attrConfiguration_cRelation.js/PlChARelType_TXT','Please choose a relation type.'),
			onChange:		function(selected_RT_UUID){
				this.rCWidget.propertyHasChanged('selected_RT_UUID',this.value);
				this.rCWidget.update_selected_RT_UUID(selected_RT_UUID);
			} // end method onChange
		}, callerWidget.RT_dDList_DOMNode);
	} // end of method get_RT_onSuccess
	,
	'update_selected_RT_UUID' : function(selected_RT_UUID) {
		this.selected_RT_UUID=selected_RT_UUID;
		if (this.selected_RT_UUID) {
			this.showWhat_N_rB.attr('disabled',false);
			this.showWhat_A_rB.attr('disabled',false);
			this.showWhat_V_rB.attr('disabled',false);
			this.loadAttributeOrViewList();
		} else {
			this.showWhat_N_rB.attr('disabled',true);
			this.showWhat_A_rB.attr('disabled',true);
			this.showWhat_V_rB.attr('disabled',true);
			if(this.AV_dDList) {
				this.AV_dDList.attr('value','');
				this.AV_dDList.attr('disabled',true);
				//application.admin.manageAttributes.changeAttribute(rCWidget.UUID,this.value,'');
				this.rCWidget.propertyHasChanged('show_UUID','');
			} // end if
		} // end if
	} // end of method update_selected_RT_UUID
	,
	'loadAttributeOrViewList' : function () {
		if(!this.selected_RT_UUID) return;
		if(this.showWhat == 'N') {
			if(this.AV_dDList) {
				this.AV_dDList.attr('value','');
				this.AV_dDList.attr('disabled',true);
			} // end if
			return;
		}
		application.OT_AJAX_query(
			{ 
				"task"	: ((this.showWhat == 'V')?'get_OT_viewTypes_of_OT_at_RT_end':'get_OT_attributes_of_OT_at_RT_end'), 
				"RT_UUID"	: this.selected_RT_UUID,
				"OT_UUID"	: this.OT_UUID,
				'callerWidget' : this.id // leave this in, here !!!
			}, 
			this.loadAttributeOrViewTypeList_onSuccess,
			true);	// end AJAX query
	} // end of method loadAttributeList
	,
	'loadAttributeOrViewTypeList_onSuccess' : function(r,a) {
	
		var callerWidget = dijit.byId(a.args.content.callerWidget);
	
		dojo.require("dijit.form.FilteringSelect");
		
		// locate and destroy an already existing dropDown list
		var AV_dDList = callerWidget.AV_dDList;
		if(AV_dDList) AV_dDList.destroyRecursive(false);
		
		callerWidget.AV_dDList = new dijit.form.FilteringSelect({
			'rCWidget' 		: callerWidget,
			'store'			: new dojo.data.ItemFileReadStore({data:r}),
			'searchAttr'	: "name",
			'class'			: "fullWidth",
			'name'			: 'name',
			'value'			: callerWidget.show_UUID,
			'searchAttr'	: 'name',
			'highlightMatch': 'all',
			'queryExpr'		: '*${0}*',
			'ignoreCase'	: true,
			'emptyLabel'	: T('attrConfiguration_cRelation.js/loadAttributeOrViewTypeList_onSuccess_empty_TXT', 'The related object type has no attributes, yet. ;-('),
			'missingMessage': T('attrConfiguration_cRelation.js/loadAttributeOrViewTypeList_onSuccess_missing_TXT','Please choose an attribute.'),
			'onChange'		: function(show_UUID){
				this.rCWidget.propertyHasChanged('show_UUID',this.value);
			} // end method onChange
			,
			'disabled'		: callerWidget.isInherited
		}, dojo.create('div',{},callerWidget.AV_dDList_DOMNode,'only'));
			
	} // end of method loadAttributeList_onSuccess
	
});
