<?php if (!defined('APPLICATION_started')) {header('Location: .');exit;} 
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/
?>
 
<script type="text/javascript">
    dojo.require("dijit.form.MultiSelect");
</script>
 
<div dojoType="dijit.Dialog" id="application.Dialogues.addRelations" 
	title="Add new &laquo;???&raquo;" style=""
	execute="application.attributes.cRelationAttribute.addRelations.DialogExecute();">
	
	<div dojoType="dijit.layout.BorderContainer" gutters="false" style="width:600px;height:600px;">
		
		<!-- the main user interface of the dialog -->
		<div dojoType="dijit.layout.TabContainer" class="dijitDialogPaneContentArea" region="center" id="application.Dialogues.addRelations.TabContainer">
			
			<div dojoType="dijit.layout.BorderContainer" title="Find &laquo;???&raquo;" id="application.Dialogues.addRelations.FindContainer" gutters="false">
				<div dojoType="dijit.layout.ContentPane" region="top" style="padding-left:.5ex;">
					<h3><?php echo T('addRelations.php/EnterSrchTerm_TXT', 'Enter your search term:'); ?></h3>
					<p class="small"><?php echo T('addRelations.php/SrchDescr_HTM', 'Wildcard char: <code>*</code>, e.g. <code>*ber*</code> finds &laquo;Straw<em>ber</em>ry&raquo; and &laquo;Blue<em>ber</em>ry&raquo;'); ?></p>
					<table class="fullWidth"><tbody><tr>
						<td width="85%">
							<input type="text" id="application.Dialogues.addRelations.findInputBox" 
								value="" dojoType="dijit.form.ValidationTextBox" class="fullWidth"
								regExp=".*" required="true" intermediateChanges="true"
								invalidMessage="<?php echo T('addRelations.php/InvMsg_TXT', 'Please enter a search term.'); ?>" >					
						</td>
						<td>
							<button dojoType="dijit.form.Button" type="button" 
								onClick="application.attributes.cRelationAttribute.addRelations.searchTermHasChanged();">
									<img width="12" src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/system-search.png"/> <?php echo T('BTN_Search', 'Search'); ?>!
							</button>
						</td>
					</tr></tbody></table>
					<p id="application.Dialogues.addRelations.searchResultsNode">&nbsp;</p>
					<div><p>&nbsp;</p></div>
					<h3><?php echo T('addRelations.php/MarkTheObjToAddRel_HTM', 'Mark the $[0] to which you want to add relations:', array ('<span id="application.Dialogues.addRelations.markMessage_OTName">???</span>')); ?></h3>
				</div>
				<select dojoType="dijit.form.MultiSelect" id="application.Dialogues.addRelations.resultList" onChange="application.attributes.cRelationAttribute.addRelations.selectedTargetObjectsHaveChanged();" 
					region="center" style="border-right:0;border-bottom:0;border-left:0;padding-left:.5ex;" class="fullWidth dijitTextArea"
					title="<?php echo T('addRelations.php/MarkingTip_TTP', 'You may mark several objects by holding down the SHIFT key or mark more objects by pressing the CONTROL key when clicking on the object names.'); ?>" 
					>
				</select>
				<div dojoType="dijit.layout.ContentPane" region="bottom" style="padding-left: .5ex;padding-right:.5ex;padding-bottom:1ex;">
					<div><p>&nbsp;</p></div>
					<!--<p class="textRight small">
						You may mark several objects by pressing the <code>SHIFT</code> key or 
						mark more objects by pressing the <code>CONTROL</code> key when clicking on the object names.
					</p>-->
					<div class="textRight">
						<button dojoType="dijit.form.Button" type="button" 
							id="application.Dialogues.addRelations.duplicateButton" title=""
							onclick="application.attributes.cRelationAttribute.addRelations.DialogExecute('duplicate');">
							<img src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/edit-copy-6.png"/>
							<img src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/insert-link-2.png"/>
							<?php echo T('addRelations.php/CrDupl_TXT', 'Create duplicates and add relations to them'); ?>
						</button>
						&nbsp;
						<button dojoType="dijit.form.Button" type="submit" id="application.Dialogues.addRelations.execButton" title="">
							<img src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/insert-link-2.png"/>
							<?php echo T('addRelations.php/AddRel_BTN', 'Add relations'); ?>
						</button>
					</div>
				</div>
			</div>
			
			<div dojoType="dijit.layout.BorderContainer" title="Create a new target object" id="application.Dialogues.addRelations.NewObjectContainer" gutters="false">
				<div dojoType="dijit.layout.ContentPane" region="top" style="padding-left:.5ex;">
					<h3><?php echo T('addRelations.php/SelTypeOfObj_TXT', 'Please select the type of the new object:'); ?></h3>
					<p>&nbsp;</p>
				</div>
				<div dojoType="dijit.layout.ContentPane" region="center" style="border-right:0;border-bottom:0;border-left:0;padding-left:.5ex;" class="fullWidth">
					<div id="application.Dialogues.addRelations.NewObjectTypeTree" ></div>
				</div>
				<div dojoType="dijit.layout.ContentPane" region="bottom" style="padding-left: .5ex;padding-right:.5ex;padding-bottom:1ex;">
					<div><p>&nbsp;</p></div>
					<div class="textRight">
						<button dojoType="dijit.form.Button" type="button" 
							id="application.Dialogues.addRelations.newButton"
							onclick="application.attributes.cRelationAttribute.addRelations.DialogExecute('new');">
							<img src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/document-new-5.png"/>
							<img src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/insert-link-2.png"/>
							<?php echo T('addRelations.php/CreateNewObjAddRel_BTN', 'Create a new object and add a relation to it'); ?>
						</button>
					</div>
				</div>
			</div>
			
			
		</div>
		
		<!-- the button row -->
        <div dojoType="dijit.layout.ContentPane" class="dijitDialogPaneActionBar textRight" style="padding-top:0.5em;" region="bottom">
			<button dojoType="dijit.form.Button" type="button" onClick="application.attributes.cRelationAttribute.addRelations.DialogCancel();">
				<img width="12" src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/dialog-cancel-4.png"/>
				<?php echo T('BTN_Cancel', 'Cancel'); ?>
			</button>
		</div>
	</div>
</div>
