﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

application.attributeKinds.register({kind: "cRelationAttribute", 
	defaultConfiguration : { 
		selected_RT_UUID : 	'', 	/* Relation Type UUID in string */
		showWhat : 			'A', 	/* either 'A' (value tuples of an attribute) or 'V' (view) */
		show_UUID : 		'',		/* the UUID of the concept that is shown as a string */
		cardinality: 		1, 
		svFormatActivated: 	false,
		svHtmlBefore: 		'',
		svHtmlBetween: 		'',
		svHtmlAfter: 		'',
		multipleRelationsToTheSameTarget_permitted : false,
		multipleRelationsAtOnce : false,
		duplicateTargetBeforeCreating : false,
		creatingTargetObject_permitted : false,
	}
	,
	// defaultValues:{
	// }
	// ,
	defaultRetrievalValues:	['search_text','searchPattern','search_O_v_UUID']
	,
	getDefaultRetrievalValues : function ( attrInfo ) {
		// needs elaboration on show_what decision
		if ( attrInfo.showWhat[0] == "A" ) {
			// get attribute of connected OT by A_UUID from this.show_UUID
			var connectedAttribute = null;
			var showUUID = null;
			if (Array.isArray(attrInfo.show_UUID)) {
				showUUID = attrInfo.show_UUID[0];
			}
			else {
				showUUID = attrInfo.show_UUID;
			}
			dojo.xhrPost({
				'url'		: '?'
				,
				'content'	: {
					'v'		: 'JSON_Attribute',
					'task'	: 'get_A', 
					'UUID'	: showUUID
				}
				,
				'error'		: function(r,a) {
					try{
						if (typeof (r.responseText)!='undefined') {
							var e=dojo.fromJson(r.responseText);
							application.showErrorMessage(
								'<p><strong>Server error:</strong></p>'+
								'<table><tbody>'+
									'<tr><th>Type</th><td>'+e.type+'</td></tr>'+
									'<tr><th>Message</th><td>'+e.message+'</td></tr>'+
									'<tr><th>Code</th><td>'+e.code+'</td></tr>'+
									'<tr><th>File</th><td>'+e.file+'</td></tr>'+
									'<tr><th>Line</th><td>'+e.line+'</td></tr>'+
									'<tr><th>Trace</th><td><pre>'+e.trace+'</pre></td></tr>'+								
								'<tbody></table>'
								);
						} else {
							application.showErrorMessage('<pre class="small">'+dojo.toJson(r,true)+'</pre>');
						} // end if
					} catch (exception) {
						var errorMessage = '';
						if(r.responsetext) {
							errorMessage = '<p><strong>Server error:</strong></p><pre>'+r.responseText+'</pre>';
						} else {
							errorMessage = '<p><strong>Error:</strong></p><pre>'+exception+'</pre>';
						} // end if
					
						application.showErrorMessage(errorMessage);
					} // end try ... catch
				}, // end of error method
				'handleAs'	: 'json',
				'load'		: function(response,request){ /* onSuccess */
					
					connectedAttribute = response; 
											
				}, // end of onSuccess method
				//preventCache:true,
				//failOk	: true,
				'sync'		: true,
				'timeout'	: 	application.configuration.global.AJAX_default_timeout
			});

			var defaultRetrievalValues = application.attributeKinds.attributeKindList[connectedAttribute.kind].getDefaultRetrievalValues( connectedAttribute );
			if ("connectedAttribute" in defaultRetrievalValues) {
				return(defaultRetrievalValues);
			}
			else {
				return (
					{
						'connectedAttributeDefaultRetrievalValues': defaultRetrievalValues,
						'connectedAttribute': connectedAttribute
					}
				);
			}
		} else {
			return this.defaultRetrievalValues;	
		}
	} // end of method getDefaultRetrievalValues
	,
	widgetClass: 			'application.widgets.cRelationAttribute'
	,
	configurationWidgetClass : 'application.widgets.configureAttributes.cRelationAttribute'
	,
	'useValueTupleAsExpressionInput'	: false
	,
	'expressionsPermitted'				: false
	,

});
