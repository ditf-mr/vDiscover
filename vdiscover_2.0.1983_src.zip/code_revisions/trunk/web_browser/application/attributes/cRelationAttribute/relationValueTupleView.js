﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

if(!dojo._hasResource["application.widgets.attributes.relationValueTupleView"]){

dojo._hasResource["application.widgets.attributes.relationValueTupleView"]=true;
dojo.provide("application.widgets.attributes.relationValueTupleView");

(function (){

dojo.declare('application.widgets.attributes.relationValueTupleView', [dijit._Widget, dijit._Templated], {
	'relationAttributes': null
	,
	'attributesWithValueSets': null
	,
	'readmode': true
	,
	'templateString' : "" // the template string is built in postMixInProperties
	,
	'widgetsInTemplate' : true
	,
	'postMixInProperties' : function () {
	
		// this.id=Math.uuid();
		this.attributeWidgetList={};
		this.changed_VTs={};
		
		this.templateString = "<table class='fullWidth compact'>";
	
		for (var A_UUID in this.relationAttributes) {
			var attrConfig = this.relationAttributes[A_UUID];
			if(!application.attributeKinds.attributeKindList[attrConfig.kind]) 
				throw 'There is no registration for the attribute kind "'+attrConfig.kind+'".';
			var dojoType=application.attributeKinds.attributeKindList[attrConfig.kind].widgetClass;
			this.templateString+= ""
				+"<tr>"
					+"<td>"
						+'<div '
							+'dojoAttachPoint="attrWidget_'+attrConfig.A_UUID+'" '
						+'"></div>'
				+"</td></tr>"
		} // end for .. in

		this.templateString+="</table>";

	} // end of method postMixInProperties
	,
	'postCreate' : function() {
		// This widget does not have solver functionality.
		// Hence, it is not necessary to "remember" the current widget
		// this.connect(this,'onMouseOut','markAllAttributes_normal');
		
		for (var A_UUID in this.relationAttributes) {
			var attrConfig = this.relationAttributes[A_UUID];
			var attrType			= (application.attributeKinds.attributeKindList[attrConfig.kind].widgetClass).replace('application.widgets.',''),
				A_widget	= new application.widgets[attrType]({
					'A_UUID': 		A_UUID,
					'O_UUID': 		attrConfig.ORT_UUID,
					'title'			: attrConfig.name,
					'isEmbedded':	true,
					'readOnly':		attrConfig.readOnly,
					'edit':			((this.readmode)?false:true),
					'valueTuples':	this.attributesWithValueSets[A_UUID].values, //  attrObj.values,
					'config':		attrConfig,// attrObj.attribute, // config
					'V_widgetId'	: this.id,
				}).placeAt(this['attrWidget_'+attrConfig.A_UUID]);
			this._supportingWidgets.push(A_widget);
			this.attributeWidgetList[A_UUID]=A_widget;
		
		} // end for .. in
		
		
	} // end of method postCreate
	,
	// the following methods appear as well at application.widgets.genericView, but these ones here are more generic
	'addToAttributeWidgetList' : function (A_UUID, A_widget) {
		this.attributeWidgetList[A_UUID]=A_widget;
	} // end of method addToAttributeWidgetList
	,
	/*
	'markAllAttributes_normal' : function() {

		// display all attributes in normal style
		for (var A_UUID in this.attributeWidgetList)
			this.attributeWidgetList[A_UUID].markAsNormal();

	} // end of method displayAllAttributes_normal
	,
	*/
	'setCurrentAttr_widget' : function (w) {
		this.currentAttr_widget=w;
	} // end of method setCurrentAttr_widget
	,
	'hasEstimationFunctionality' : false
	,
	'changed_VTs' : null // gets {} after initialisation
	,
	'attrValueTuple_hasChanged' : function (A_UUID, VT_UUID, tupleObj) {
		if(!this.changed_VTs[A_UUID]) this.changed_VTs[A_UUID]={};
		this.changed_VTs[A_UUID][VT_UUID]=tupleObj;
		
		// continue only, if the view is an embedded one
		if(		!this.parentVTEditor 
			|| 	!this.parentVTEditor.attrWidget 
			|| 	!this.parentVTEditor.attrWidget.changeRelAVSet
			) return;
		
		// tell the parent widget that one of the end object's / view's value tuples has changed
		this.parentVTEditor.attrWidget.changeRelAVSet (this.parentVTEditor.valueTupleUUID, A_UUID, VT_UUID, tupleObj);
		
	} // end of method attrValueTuple_hasChanged
	,
	'isValid' : function () {
		var isValid = true;
		
		for (var A_UUID in this.attributeWidgetList) {
			
			var w = this.attributeWidgetList[A_UUID];
			isValid == isValid && w.isValid();
			
		} // end for .. in
		
		return isValid;
	} // end of method isValid
});

})();

} // end if provide module
