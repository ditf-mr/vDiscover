<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

$r->register_dialogHTML('application/attributes/cRelationAttribute/addRelationsDialog.dojoHTML.php');

$r->register_JavaScriptFile('application/attributes/cRelationAttribute/relationValueTupleView.js');
$r->register_JavaScriptFile('application/attributes/cRelationAttribute/addRelationsDialog.js');

// register all attribute components
$attrName = 'cRelation';

$mainPath = 'application/attributes/cRelationAttribute/';

$attrComponentPaths = array (
	'attr',
	// 'attrConfiguration', // --- admin only
	'attrRegistry',
	'attrRetrieval',
	'attrValueTupleEditor',
);

reset($attrComponentPaths);
while(list($k, $cP)=each($attrComponentPaths)) 
	$r->register_JavaScriptFile($mainPath.$cP.'_'.$attrName.'.js');

// attribute configuration
global /*$r, */$backend;
if($backend->isAdmin()){
	$r->register_JavaScriptFile($mainPath.'attrConfiguration'.'_'.$attrName.'.js');
} // end if user is admin
?>