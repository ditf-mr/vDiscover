﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare("application.widgets.cRelationAttribute",[application.widgets.standardAttribute],{

	'_valueTupleSeparator':''
	,
	'_emptyValueTuple': { /*value_text : ''*/ }
	,
	'valueTupleEditors' : null // will be later set to Object
	,
	'addEmptyValueSet_inEditMode':false
	,
	'valueTupleEditor_name': 'application.widgets.valueTupleEditor_relation'
	,
	'createNewValueTuple_whenAddButtonClicked' : false
	,
	'decideOutputMode' : function () {
		// This function decides, how relations will be displayed.

		// In case of incomplete configuration, permit the read mode, only
		if(		(this.config.showWhat != 'N')
			&& 	(!this.config.show_UUID) 		) return 'read';

		// some preparations
		this.addValueTupleIcon_title = T('attr_cRelation.js/SelRelOT_TIT', 'Select related « $[0]» .', [this.config.End_OT_name]);

		var outputMode = this.inherited(arguments);
		return outputMode;
	} // end of method decideOutputMode
	,
	'tuple_isEmpty' : function (tuple) {
		return false; // value tuples of this attribute kind have a value, always
	} // end of method tuple_isEmpty
	,
	'isObjAlreadyInList' : function (O_UUID) {
		// this methods looks up whether an object is already listed and returns its value tuple UUID

		// iterate over all already connected value tuples
		if(Object.keys(this.valueTuples).length)
			for (var i in this.valueTuples) {
				var t=this.valueTuples[i];
				// the object is already listed if its UUID is known AND the corresponding tuple is not deleted, yet
				if(('atEndObject' in t) && (t.atEndObject.object.O_UUID==O_UUID) && !(i in this.valueTuples_deleted)) {
					return i /* t.UUID */;
				} // end if
		} // end for .. in && if

		// iterate over all already added (new) value tuples
		if(Object.keys(this.valueTuples_changed).length)
			for (var i in this.valueTuples_changed) {
				var t=this.valueTuples_changed[i];
				// the object is already listed if its UUID is known AND the corresponding tuple is not deleted, yet
				if(t.End_O_UUID == O_UUID && !(i in this.valueTuples_deleted)) {
					return i /* t.UUID */;
				} // end if
		} // end for .. in && if

		return false;
	} // end of method isObjAlreadyInList
	,
	'getChangedTupleSet' : function () {
	
		// let's assume that the attribute's value tuples are editable
		
		// get the changed value tuple set from the parent method
		var changedTupleSet = this.inherited(arguments),
		// set up a variable for the cleaned value tuple set to be returned for sending to the server
			cleaned_cTS		= {};
		
		
		// iterate over the attribute's tuples that shall be saved and compile the necessary information
		for (var rel_vTuple_UUID in changedTupleSet) {
			var vT = {}; // the new value tuple to be returned

			// copy the current relation value tuple
			var changed_VT = changedTupleSet[rel_vTuple_UUID];
			// get the editor of the current relation value tuple
			var vTEditor = this.valueTupleEditors[rel_vTuple_UUID];
			
						
			// OPTION A - the value tuples to be returned need to contain the following information, ALWAYS:
			/*
			valueTuple = {
				'value_UUID' : string, // for new relations, only
				'positionOfValue' : int, multiple of 10,
				
				'End_O_UUID' : string,
			}
			*/
			// so let's set that information by copying it
			vT.value_UUID       = changed_VT.value_UUID;
			vT.positionOfValue  = changed_VT.positionOfValue;
			
			if (changed_VT.End_O_UUID) 
				vT.End_O_UUID= changed_VT.End_O_UUID; // this slot seems necessary for new relations, only
			// end OPTION A
			
			
			// OPTION B - the value tuples CAN contain, if the relation itself has attributes whose value sets are being edited:
			/*
			valueTuple = {
				'relationAttributeValueSets' : {...}
			}
			*/
			if (    // relation has attributes
					( Object.keys(this.config.relationAttributes).length > 0)
					// and they are not hidden
				&&	(!this.config.hideAttributes) 
					// the value sets of these attributes are currently being edited
				&&	(vTEditor && ('relationAttributeValueSets' in changed_VT) && ('relAVSetView' in vTEditor))
			) {
				// prepare the corresponding slot in the output variable vT
				vT.relationAttributeValueSets = {};
				
				// iterate over all attributes of the relation
				for (var relAttr_A_UUID in changed_VT.relationAttributeValueSets) {

					// locate the corresponding attribute widget
					var related_attrWidget =  vTEditor.relAVSetView.attributeWidgetList[relAttr_A_UUID];

					// set the attribute widget's values at vT.relationAttributeValueSets
					vT.relationAttributeValueSets[relAttr_A_UUID] = {
						'values'           : related_attrWidget.getChangedTupleSet(),
					};

				} // end for all attributes of the relation
			
			} // end if OPTION B
			
			
			// OPTION C - if the related object is being edited, the following ADDITIONAL information needs to be present in the value tuples:
			/*
			valueTuple.atEndObject = {
				'object'                    : { 'O_v_UUID': string },
				'viewType'                  : { 'VT_UUID':string },
				'attributesWithValueSets'   : { ... }
			}
			*/
			if (    // is the related object being edited?
					(this.config.editRelatedObject)
					// the value tuple edior needs to have an end object widget
				&&	(vTEditor.endObjWidget)
					// the end object view is in edit mode
				&&  (vTEditor.endObjWidget.edit)
			) {
			
				// let's write the changes to the current value tuple
				vT.atEndObject = {
					'object'                    : { 'O_v_UUID'  : changed_VT.atEndObject.object.O_v_UUID },
					'viewType'                  : { 'VT_UUID'   : changed_VT.atEndObject.viewType.VT_UUID  },
					'attributesWithValueSets'   : vTEditor.endObjWidget.getChanges() /*eO_vTSet*/,
				};
			
			} // end if OPTION C
			
		
			// write the relation value tuple to the list of value tuples to be returned
			cleaned_cTS[rel_vTuple_UUID] = vT;
			
		} // end for .. in

		return cleaned_cTS;
	} // end of method getChangedTupleSet
	,
	'changeRelAVSet'	 : function (vT_UUID, A_UUID, VT_UUID, tupleObj) {
		// this method changes the attribute-value set of the relation with the value tuple ID vT_UUID

		// get the value tuple of the selected relation
		var vT = this.getValueTuple(vT_UUID);

		// insert the relation's attribute slot, if necessary
		if (! ('relationAttributeValueSets' in vT)) {
				vT.relationAttributeValueSets = {};
		} // end if

		// insert the new attribute-value set into the value tuple
		if(!vT.relationAttributeValueSets[A_UUID]) vT.relationAttributeValueSets[A_UUID]={'values':{}};

		if (tupleObj.status!='deleted') {
			// update the value tuple
			vT.relationAttributeValueSets[A_UUID].values[VT_UUID]=tupleObj;
		} else {
			// delete the value tuple
			delete vT.relationAttributeValueSets[A_UUID].values[VT_UUID];
		} // end if

		// store the modified value tuple
		this.valueTupleHasChanged(vT_UUID, vT);

	} // end of method changeRelAVSet
	,
	'change_VTatEndObject'	 : function (vT_UUID, A_UUID, VT_UUID, tupleObj) {
		// this method changes the attribute-value set of the relation with the value tuple ID vT_UUID

		// get the value tuple of the selected relation
		var vT = this.getValueTuple(vT_UUID);

		if(!vT.atEndObject.attributesWithValueSets[A_UUID])
			vT.atEndObject.attributesWithValueSets[A_UUID]={'values':{} };
		if(!vT.atEndObject.attributesWithValueSets[A_UUID].values)
			vT.atEndObject.attributesWithValueSets[A_UUID].values={};

		if (tupleObj.status!='deleted') {
			// update the value tuple
			vT.atEndObject.attributesWithValueSets[A_UUID].values[VT_UUID]=tupleObj;
		} else {
			// delete the value tuple
			delete vT.atEndObject.attributesWithValueSets[A_UUID].values[VT_UUID];
		} // end if

		// store the modified value tuple
		this.valueTupleHasChanged(vT_UUID, vT);

	} // end of method change_VTatEndObject
	,
	'askServerForRelationTemplates' : function (O_UUID, name, specialCommand, newType_UUID) {

		// verify that only permitted special commands are used
		var permittedSpecialCommands=['new','duplicate'];
		if(		!specialCommand
			||
				(specialCommand.length && (dojo.indexOf(permittedSpecialCommands, specialCommand) == -1))
			) specialCommand='';

		// the "new" command needs a typeUUID, always --- in case of problems, set it to ""
		if (specialCommand=='new' && !newType_UUID) specialCommand='';

		// add the new relation only, if cardinality !=0 or not reached, yet
		if((this.config.cardinality!=0)&&(this.valueTuples_edit_count>=this.config.cardinality)) return false;

		// ask the server for a temporary value tuple to the end object and display it
		dojo.xhrPost({
			'content': {
				"task"			: 'get_relationValueTuple_for_temporaryRelation',
				"O_v_UUID"		: this.O_UUID,
				"A_UUID"		: this.A_UUID,
				"ORT_kind"		: this.config.ORT_kind,
				"endObj_O_UUID"	: O_UUID,
				"attrObj"		: this,
				'specialCommand': specialCommand,
				'new_typeUUID'	: newType_UUID
			}
			,
			'error': function(r,a){
				try{
					if (typeof (r.responseText)!='undefined') {
						var e=dojo.fromJson(r.responseText);
//TG: QUESTION: Translate this error messages with T() calls?
						application.showErrorMessage(
							'<p><strong>Server error:</strong></p>'+
							'<table><tbody>'+
								//'<tr><th>Query</th><td class="code small">'+dojo.toJson(a,true)+'</td></tr>'+
								'<tr><th>Type</th><td>'+e.type+'</td></tr>'+
								'<tr><th>Message</th><td>'+e.message+'</td></tr>'+
								'<tr><th>Code</th><td>'+e.code+'</td></tr>'+
								'<tr><th>File</th><td>'+e.file+'</td></tr>'+
								'<tr><th>Line</th><td>'+e.line+'</td></tr>'+
								'<tr><th>Trace</th><td><pre>'+e.trace+'</pre></td></tr>'+
							'<tbody></table>'
							);
					} else {
						application.showErrorMessage('<pre class="small">'+dojo.toJson(r,true)+'</pre>');
					} // end if
				} catch (exception) {
					var errorMessage = '';
					if(r.responsetext) {
						errorMessage = '<p><strong>Server error:</strong></p><pre>'+r.responseText+'</pre>';
					} else {
						errorMessage = '<p><strong>Error:</strong></p><pre>'+exception+'</pre>';
					} // end if

					application.showErrorMessage(errorMessage);
				} // end try ... catch
			} // end of error method
			,
			'handleAs': 'json',
			'load': function(r,a){ /* onSuccess */

				var attributeWidgetList = this.content.attrObj.viewWidget.attributeWidgetList;

				// r contains one or more attributes with new imaginary relation value tuples
				for (var A_UUID in r) {

					// locate the corresponding attribute object
					var attrObj = attributeWidgetList[A_UUID];

					if (attrObj) {

						// iterate over all new value tuples and add them
						var new_valueTuples = r[A_UUID];

						for (var vT_UUID in new_valueTuples) {
							attrObj.addRelationTemplate(new_valueTuples[vT_UUID]);
						} // end for .. in

					} // end if

				} // end for .. in

			} // end of onSuccess method
			,
			//preventCache:true,
			//failOk: true,
			'url':'?v=' + 'JSON_Attribute',
			'sync': true
		});

		return true; // means: everything ok
	} // end of method askServerForRelationTemplates
	,
	'addRelationTemplate' : function (vT) {

		var vT_UUID = vT.AV_UUID;

		// read or edit mode?
		if (this.outputMode=='read') { // read mode

			// add the received value tuple to the existing ones
			this.valueTuples[vT_UUID] = vT;

			// build the output string and place it in this.containerNode
			var outputString = this.outputInReadMode();
			dojo.attr(this.containerNode,'innerHTML',outputString);

			// render the related object attributes/ views
			var vT_widget = new application.widgets.valueTuple_relation({
				'attrWidget' 					: this,
				'valueTuple'	 				: this.getValueTuple(vT_UUID),
			}).placeAt(this.containerNode);
			this._supportingWidgets.push(vT_widget);
			this.valueTupleEditors[vT_UUID] = vT_widget;

			this.showHide_noValueTuplesMessage();

		} else { // edit mode
			// add a special slot for automatically creating the relation when storing
			vT.End_O_UUID = vT.atEndObject.object.O_UUID;

			// add the received value tuple to the existing ones
			this.valueTuples[vT_UUID] = vT;
			this.valueTupleHasChanged(vT_UUID, vT);

			// create and display the value tuple widget
			var vTEditor = new application.widgets.valueTupleEditor_relation({
				'attrWidget' 					: this,
				'valueTupleUUID' 				: vT_UUID,
				'valueTuple'	 				: vT, //this.getValueTuple(vT_UUID),
			}).placeAt(this.valueTupleEditors_domNode);

			this._supportingWidgets.push(vTEditor);
			this.valueTupleEditors[vT_UUID] = vTEditor;

			this.valueTuples_edit_count++;

			this.updateNumberOfValueTuples();
		} // end if read or edit

	} // end of method addRelationTemplate
	,
	'findTupleWith_value_UUID' : function (value_UUID) {
		// the value_UUID is a key for relations
		for (var AV_UUID in this.valueTuples) {
			var vT = this.valueTuples[AV_UUID];
			if (vT.value_UUID==value_UUID) return AV_UUID;
		} // end for .. in

		return '';
	} // end of method findTupleWith_value_UUID
	,
	'setValueTuple_deleted' : function(valueTupleUUID, calledFromAnotherAttribute) {

		// hide the value tuple that is being deleted
		if (valueTupleUUID in this.valueTupleEditors) dojo.style(this.valueTupleEditors[valueTupleUUID].domNode,'display','none');

		// carry out the main deleting tasks
		this.inherited(arguments);

		// beware of recursions ...
		if(calledFromAnotherAttribute) return;

		// inform all other relation attributes that display the same relation type that the current relation got deleted
		var value_UUID =this.valueTuples[valueTupleUUID].value_UUID;
		for (var a in this.viewWidget.attributeWidgetList) {
			var attrWidget = this.viewWidget.attributeWidgetList[a];
			if( 	(attrWidget.declaredClass==this.declaredClass)						// the other attribute needs to be a cRelationAttribute
				&&	(attrWidget.A_UUID!=this.A_UUID)									// but not the current one
				&&	(attrWidget.config.selected_RT_UUID==this.config.selected_RT_UUID)	// with the same relation type
				) {
					// locate the corresponding value tuple UUID
					var valueTuple_UUID_at_attrWidget = attrWidget.findTupleWith_value_UUID(value_UUID);
					// Is there a value tuple UUID? -> If yes, mark the value tuple as "deleted".
					if (valueTuple_UUID_at_attrWidget) attrWidget.setValueTuple_deleted(valueTuple_UUID_at_attrWidget, T('attr_cRelation.js/CalledFromOtherAttr_TXT','Called from another attribute') );

			} // end if
		} // end for .. in

	} // end of method setValueTuple_deleted
	,
	'htmlFormatTupleSet_readMode' : function (valueTuples/*array*/){
		// this method overwrites the parent method
		return '';
	} // end of method
	,
	'htmlFormatValueTuple_readMode' : function (valueTuple) {

		if(typeof valueTuple.AV_UUID=='undefined') return this._noValueSet;

		return '';
	} // end of method htmlFormatValueTuple_ReadMode
	,
	'postMixInProperties' : function() {
		// If you provide a postMixInProperties method for your widget,
		// it will be invoked before rendering occurs, and before
		// any dom nodes are created. If you need to add or change the
		// instance's properties before the widget is rendered
		// - this is the place to do it.
		this.inherited(arguments);

		this.valueTupleEditors = {};
		this.valueTuples_edit_count	= 0;

	} // end of method postMixInProperties
	,
	'postCreate' : function() {
		// If you need to be sure parsing and creation of any child widgets has
		// completed, use startup. This is often used for layout widgets like
		// BorderContainer. If the widget does JS sizing, then startup() should
		// call resize(), which does the sizing.

		// this.inherited(arguments);
		this.showToolTips();

		// output a warning if the configuration is incomplete
		if((this.config.showWhat != 'N') && (!this.config.show_UUID)) {
			dojo.create(
				'DIV',
				{
					'innerHTML':''
						+'<p class="strong deleted" style="text-decoration:none !important;">'
							+ T('attr_cRelation.js/RelAttrNoTargetAttr_P1_TXT', 'This relation attribute has no target attribute/ view assigned, yet!')
							+'<br />'
							+ T('attr_cRelation.js/RelAttrNoTargetAttr_P2_TXT','You need to set the target attribute/ view in the configuration of the relation attribute.')
						+'</p>'
				},
				this.containerNode, 'only'
			);
			return;
		} // end if

		// iterate over all existing value tuples
		// it is necessary to distinguish read and edit mode!
		for (var vT_UUID in this.valueTuples)
			if (this.outputMode=='read') {
				// read mode
				var vT_widget = new application.widgets.valueTuple_relation({
					'attrWidget' 					: this,
					'valueTuple'	 				: this.getValueTuple(vT_UUID),
				}).placeAt(this.containerNode);
				this._supportingWidgets.push(vT_widget);
				this.valueTupleEditors[vT_UUID] = vT_widget;

			} else {
				// edit mode
				var vTEditor = new application.widgets.valueTupleEditor_relation({
					'attrWidget' 					: this,
					'valueTupleUUID' 				: vT_UUID,
					'valueTuple'	 				: this.getValueTuple(vT_UUID),
					// 'initial_pos'					: ++this.valueTuples_edit_count,
				}).placeAt(this.valueTupleEditors_domNode);

				this._supportingWidgets.push(vTEditor);
				this.valueTupleEditors[vT_UUID] = vTEditor;

				this.valueTuples_edit_count++;
				// this.updateNumberOfValueTuples();

		}; // end if + end for .. in

		if (this.outputMode=='edit') {
			this.updateNumberOfValueTuples();

		} else {
			this.showHide_noValueTuplesMessage();
			
		} // end if

	} // end of method postCreate
	,
	'createValueTupleEditor' : function () {
		application.attributes.cRelationAttribute.addRelations.showDialog(this);
	} // end of method showAddRelationsDialog
	,
	'generateNewTupleIfLastGotDeleted':false
	,
	'isValid' : function () {
		// this method substitutes the parent method, completely

		var isValid 	= true,
			vTEditors	= 0;

		if (this.config.editRelatedObject ) {
			for (var VT_UUID in this.valueTupleEditors) {
				var vTEditor = this.valueTupleEditors[VT_UUID];
				if (
							!('status' in vTEditor)
						||	(('status' in vTEditor) && (vTEditor.status!='deleted'))
					) {
						isValid = isValid && vTEditor.isValid();
						vTEditors++;
				} // end if
			} // end for .. in

			// there needs to be one or more value tuple editor
			if (this.config.mustBeSet && !vTEditors) isValid=false;
		} // end if

		return isValid;
	} // end of method isValid
	,


	'getCurrentUnit' : function() {
		return this._getValueTupleSlotOfRelatedAttribute('unit');
	} // end of method getCurrentUnit
	,
	'getCurrentValue' : function () {
		return this._getValueTupleSlotOfRelatedAttribute('value');
	} // end of method getCurrentValue
	,
	'_getValueTupleSlotOfRelatedAttribute' : function (slotName) {
		var vTSlot='';

		// return the current vTSlot only if there is a related attribute
		if (!this.valueTupleEditors)	return vTSlot;

		// the related attribute is read-only

		// ask the related attribute for its vTSlot
		for (A_UUID in this.valueTupleEditors) {
			var subWidget = this.valueTupleEditors[A_UUID];
			for (VT_UUID in subWidget.valueTuples) {
				var vT=subWidget.valueTuples[VT_UUID];
				vTSlot = vT[slotName];
			} // end for .. in
		} // end for .. in

		return vTSlot;
	} // end of method _getValueTupleSlotOfRelatedAttribute
	,
	'getFormat' : function () {
		return this._getConfigValueOfRelatedAttribute('format');
	} // end of method getFormat
	,
	'getMinValue' : function () {
		return this._getConfigValueOfRelatedAttribute('minValue');
	} // end of method minValue
	,
	'getMaxValue' : function () {
		return this._getConfigValueOfRelatedAttribute('maxValue');
	} // end of method maxValue
	,
	'_getConfigValueOfRelatedAttribute' : function (configSlotName) {
		var configValue='';

		// return the current value only if there is a related attribute
		if (!this.valueTupleEditors)	return configValue;

		// the related attribute is read-only

		// ask the related attribute for its configValue
		for (A_UUID in this.valueTupleEditors) {
			var vTEditor = this.valueTupleEditors[A_UUID];
			configValue=vTEditor.config[configSlotName];
		} // end for .. in

		return configValue;
	} // end of method _getConfigValueOfRelatedAttribute

}); // end of declaration
