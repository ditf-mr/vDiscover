﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare(
	'application.widgets.retrieveAttributes.cRelationAttribute',
	[application.widgets.retrieveAttributes.genericAttribute],
	{
	
		'searchTimeOut': null, // JavaScript TimeOut

		'searchTimeOutWaitForMSeconds': 250, // wait xx msec before starting to search
		
		'searchPattern': '', // string, stores the entered search pattern
		
		'search_text': '',	// string, stores either the search pattern (if searchMode="searchName")
							// or the list of object names (if searchMode="searchUUIDs")
		
		'search_O_v_UUID': null, // array, stores the list of object UUIDs (if searchMode="searchUUIDs").
		
		'searchResultStore': null, // dojo.data.ItemFileWriteStore
		
		'connectedA': null, // object, the connected attribute (if searchWhat="A") 
		
		'innerAttributeWidget': null, // widget of the connected attribute
		
		
		'searchString_changed': function() {
			/**
			 * Reacts on any change made in the search pattern string field by changing the 
			 * search_text of the retrieval and by getting the list of objects that match the 
			 * search pattern.
			 */
			// Store the search pattern
			this.searchPattern = this.searchString_tB.get('value');
			this.search_text = this.searchPattern;
			this.search_O_v_UUID = null;
			
			{ // Reset searchObject_mS and the corresponding slot in the store
				application.OT.retrieve.changeRetrievalAttribute(
					this.UUID,
					{
						'search_O_v_UUID': '',
						'ok': true
					}
				);
				// Deselect alle items in the multiselect object list
				this.searchObject_mS.reset();
				this.searchObject_mS.attr('_lastValue',[]);
				this.searchObject_mS.attr('_lastValueReported',[]);
			}
			
			if ( this.searchPattern ) {
				// If there is already a timeout: delete it
				if (this.searchTimeOut) {
					clearTimeout(this.searchTimeOut);
					this.searchTimeOut = null;
				}
				
				// Store the search pattern
				var parsedQuery = this._parseQuery();
				application.OT.retrieve.changeRetrievalAttribute(
					this.UUID,
					{
						'search_text': this.search_text,
						'searchPattern': this.searchPattern,
						'searchMode': 'searchName',
						'parsedQuery': parsedQuery,
						'ok': true
					}
				);
			} else {
				this.deleteCriterium();
			}
			{ // Update the list of objects
				var searchRelationWidget = this;
				// Set the new timeout
				this.searchTimeOut = setTimeout(
					function() {
						searchRelationWidget.searchForObjects();
					},
					this.searchTimeOutWaitForMSeconds
				);
			}
			
		}, // end-of-method searchString_changed
		
		
		'searchForObjects': function(){
			/**
			 * Performs the search for objects that match the given search pattern and generates 
			 * the lst of objects of them.
			 */
			// execute search the given pattern
			application.OT_AJAX_query({ 
					"task"			: 'get_Os_by_name', 
					"pattern"		: this.searchPattern,
					"OT_UUID"		: this.End_OT_UUID,
					"widgetID"		: this.id
				}, 
				function(r,a){ /* onSuccess */
					// Locate the search result list
					var sR_widget=dijit.byId(a.args.content.widgetID);
					if (typeof(sR_widget) == "undefined") {
						return;
					}
					var sR_list=sR_widget.searchObject_mS;
					
					// Empty the search result list
					dojo.empty(sR_list.domNode);
					
					// Set up the store for the search results
					sR_widget.searchResultStore = new dojo.data.ItemFileWriteStore({
						data: r, 
						clearOnClose: true
					});
					
					var searchResults = 0 ;
					
					// Iterate over the search results and decide what to do with them
					sR_widget.searchResultStore.fetch({
						sort: [{ attribute: "name", descending: false}],
						onItem : function (item) {with(sR_widget.searchResultStore){
							searchResults++;
							var O_v_UUID=getValue(item,'UUID');
							
							// Output the item in the search result list
							var c = dojo.doc.createElement('option');
							c.innerHTML = getValue(item,'name');
							c.id		= 'sr_'+O_v_UUID;
							c.value 	= O_v_UUID;
							
							// Preselect the stored retrieval options
							if ( sR_widget.search_O_v_UUID && sR_widget.search_O_v_UUID.match(O_v_UUID) )	
								c.selected = true;
							
							dojo.style(c,'cursor','pointer');
							sR_list.domNode.appendChild(c);						
						}} // end-of-method onItem
					});
					
					// Output a message with the number of search results
					var srMessage = ''; 
					if (searchResults) {
						srMessage= T('attrRetrieval_cRelation.js/X_SearchRes_TXT', '$[0] search results.', [searchResults.toString()]) + ' ';
					} else {
						srMessage= T('attrRetrieval_cRelation.js/NoSearchRes_TXT', 'Sorry &ndash; there are no search results.');
					}
					sR_widget.searchResultMessage.innerHTML = srMessage;
				}, // end of onSuccess method
				true /* syncronous */
			); // end AJAX query
		}, // end-of-method searchForObjects
		
		
		'searchObject_changed': function(e){
			/**
			 * Reacts on any change made in the list of objects. Changes may be the selection or 
			 * deselection of one or many objects.
			 */
			{ // Get list of selected objects. If there is only one objects selected, it is 
			  // retruned as string and must be converted to an array.
				this.search_O_v_UUID = this.searchObject_mS.attr('value');
				if (this.search_O_v_UUID instanceof String) {
					this.search_O_v_UUID = [this.search_O_v_UUID];
				}
			}
			{ // Collect the names of all selected objects
				var search_text = [];
				var relationWidget = this;
				dojo.forEach( this.search_O_v_UUID, function(s_O_UUID) {
					relationWidget.searchResultStore.fetchItemByIdentity(	{
							identity: s_O_UUID,
							onItem: function (item){
								if (item) {
									search_text.push(this.searchResultStore.getValue(item, 'name'));
								}
							},
							scope: relationWidget
						});		
				}) // end foreach
				this.search_text = search_text;
			}
			{ // Save changes in the attribute store
				if (this.search_O_v_UUID.length == 0) {
					this.searchString_changed();
				}
				else {
					// store the search pattern
					var parsedQuery = this._parseQuery();
					application.OT.retrieve.changeRetrievalAttribute(
						this.UUID,
						{
							'search_O_v_UUID': this.search_O_v_UUID.join('\n'),
							'searchMode': 'searchUUID',
							'parsedQuery': parsedQuery,
							'ok': true
						}
					);
				}
			}
		}, // end-of-method searchObject_changed
		
		
		'postMixInProperties': function() {
			// If you provide a postMixInProperties method for your widget, 
			// it will be invoked before rendering occurs, and before 
			// any dom nodes are created. If you need to add or change the 
			// instance's properties before the widget is rendered 
			// - this is the place to do it.
			this.inherited(arguments);
					
			// localise the necessary variables
			this.locateProperties(['showWhat', 'End_OT_UUID', 'name']);

			{ // interim solution for recursion in relation attributes
				if (this.parentWidget) {
					this.showWhat = this.parentWidget.connectedA.showWhat;
					this.End_OT_UUID = this.parentWidget.connectedA.End_OT_UUID;
				}
			}	
			
			switch (this.showWhat){
				case 'N':
				case 'V': { // search for show view of related object
					//localise special variables
					this.locateProperties(['search_text', 'search_O_v_UUID', 'searchPattern']);
					
					this.title = T('attrRetrieval_cRelation.js/SearchParas_TIT','Search parameters');
					
					// expand the template string
					this.addTemplateSection(""
						+"<tr>"
							+"<td class='textRight' width='30%'>" + T('attrRetrieval_cRelation.js/searchPattern_LBL', 'Search pattern:') + "</td>"
							+"<td width='70%'>"
								+"<table class='fullWidth'><tbody><tr>"
									+"<td width='85%'>"
									+"<input type='text' class='fullWidth'"
										+"value='${searchPattern}'" 
										+"dojoAttachEvent='onChange:searchString_changed' "
										+"dojoAttachPoint='searchString_tB' "
										+"dojoType='dijit.form.ValidationTextBox'"
										+"regExp='.*' intermediateChanges='true'"
										+"invalidMessage='" + T('attrRetrieval_cRelation.js/SearchTermInvMsg_TXT', 'Please enter a search term with at least 3 chars.') +"'"
										+"/>"
									+"</td>"
									+"<td>"
										+"<button dojoType='dijit.form.Button' type='button'" 
											+"dojoAttachEvent='onClick:searchString_changed'>"
												+"<img width='12' src='third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/system-search.png'/>" + T('BTN_Search', 'Search') + "!"
										+"</button>"
									+"</td>"
								+"</tr></tbody></table>"
							+"</td>"
						+"</tr>"	
						+"<tr>"
							+"<td class='textRight' width='30%'>" + T('attrRetrieval_cRelation.js/Objects_LBL', 'Objects:') + "</td>"
							+"<td width='70%'>"
								+"<div><p dojoAttachPoint='searchResultMessage' >&nbsp;</p>"
								+"</div>"
								+"<div>"
									+"<select style='border-right:0;border-bottom:0;border-left:0;padding-left:.5ex;' "
										+"dojoAttachEvent='onChange:searchObject_changed' "
										+"dojoAttachPoint='searchObject_mS' "
										+"dojoType='dijit.form.MultiSelect'"
										+"class='fullWidth dijitTextArea'>"
									+"</select>"
								+"</div>"
							+"</td>"
						+"</tr>"	
						+"<tr>"
							+"<td class='textRight' width='30%'>"
								+T('attrRetrieval/SearchRemarks_TXT','Remarks:')
							+"</td>"				
							+"<td width='70%'>"
								+"<ul>"
									+"<li>"
										+T('attrRetrieval_cRelation.js/description1_HTM', 'Please enter a text pattern first. Then a search for objects, whose name match the pattern, will be performed. These objects will be listed below.')
									+"</li>"
									+"<li>"
										+T('attrRetrieval_cRelation.js/description2_HTM', 'You may then select one by clicking on it or several of them by pressing the <code>SHIFT</code> key or mark more objects by pressing the <code>CONTROL</code> key when clicking on the object names. <b>BUT</b> keep in mind that all selected objects will be linked with a logical <code>AND</code>.')
									+"</li>"
								+"</ul>"
							+"</td>"
						+"</tr>"	
					);
					if (!this.search_O_v_UUID) {
						this.search_O_v_UUID = '';
					}
					if (!this.searchPattern) {
						this.searchPattern = '';
					}
					if (!this.search_text) {
						this.search_text = '';
					}			
					break;
				}
				case 'A': { // search for show attribute of related object
					// localise special variables
					this.locateProperties(['show_UUID']);
					
					{ // add special fields to the store
						var defaultRetrievalValues = application.attributeKinds.attributeKindList[this.attrInfo.kind].getDefaultRetrievalValues( this.attrInfo );
						this.connectedA = defaultRetrievalValues.connectedAttribute;
						dojo.forEach(
							defaultRetrievalValues.connectedAttributeDefaultRetrievalValues, 
							function (type){
								if (! this.rqWidget.attributeStore.hasAttribute(/* item */ this.attrInfo, /* string */ type)) {
									this.rqWidget.attributeStore.setValue( 
										this.attrInfo, /* item */ 
										type, /* string */ 
										((defaultRetrievalValues.connectedAttribute[type])? defaultRetrievalValues.connectedAttribute[type]:'')
									);
								}
							},
							this // scope
						);
					}
					
					{ // output attribute specific retrieval configuration
						this.innerAttributeWidget = new application.widgets.retrieveAttributes[defaultRetrievalValues.connectedAttribute.kind]({
								attrInfo 	: this.attrInfo,
								rqWidget 	: this.rqWidget,
								parentWidget: this	
							});
					}

					// expand the template string
					this.addTemplateSection("<div dojoAttachPoint='innerAttribute_widget'></div>");
					break;
				}
				default: {
					// expand the template string
					this.addTemplateSection	(""
/* currently not in use	
						+"<div><h2>Search for * in « ${name}»  </h2></div>"
						+"<div>"
							+"<input type='text' style='width:100%'"
								+"value='${search_text}'" 
								+"dojoAttachEvent='onChange:searchString_changed' "
								+"dojoAttachPoint='searchString_tB' "
								+"dojoType='dijit.form.ValidationTextBox'"
							+"/>"
						+"</div>"
						+"<div><p>You can use wildcards to improve the results:</p>"
									+"<ul>"
										+"<li><code>*</code> finds any char sequence, "
											+"e.g.<br/>« <code>black*</code>»  finds <code>black<i>bear</i></code>,"
											+"<code>black<i>bird</i></code> and just <code>black</code>. Otherwise"
											+"<br/>« <code>*berry</code>»  finds <code><i>black</i>berry</code>,"
											+"<code><i>straw</i>berry</code> and of course <code>berry</code>."
										+"</li>"
									+"</ul>"
						+"</div>"
*/
					);
				}
			} // end-of-switch (this.showWhat)

			// generate the template string
			this.generateTemplateString();
			
		}, // end-of-method postMixInProperties
		
		
		'postCreate': function() {
			switch (this.showWhat) {
				case 'N':
				case 'V': { // search for show view of related object				
					if ( this.searchPattern ) {
						// store the search pattern
						this.searchForObjects();				
					}
					break;
				}
				case 'A': { // search for show attribute of related object
					this.innerAttributeWidget.placeAt(this.innerAttribute_widget);
					
					if ( "showWhat" in this.innerAttributeWidget) {
						if (this.innerAttributeWidget.showWhat == "V") {
							this.showWhat = "V";
						}
					}					

					break;
				}
				default: {
					break;
				}
			} // end-of-switch (this.showWhat)
		}, // end-of-method postCreate
		
		
		'_parseQuery': function() {
			var showWhat = this.getValue('showWhat');
			
			switch (showWhat){
				case 'N':
				case 'V': { // search for show view of related object				
					if (this.search_text){
						if (this.search_O_v_UUID != null){
							return T('attrRegistry_cRelation.js/X_is_Y_TXT', '$[0] is "$[1]"', [this.name, this.search_text.join('" OR "')]); 
						} else {
							return T('attrRegistry_cRelation.js/X_matches_Y_TXT', '$[0] matches "$[1]"', [this.name, this.search_text]);
						}
					}
					break;
				}
				case 'A': { // search for show attribute of related object
/*
					if ( typeof actualAttr != 'undefined' ) {
						var show_UUID = actualAttr.show_UUID;
					} else {
						var show_UUID = rqWidget.attributeStore.getValue(item,'show_UUID');		
					}
				
					var connectedA = {};
					// get attribute of connected OT by A_UUID from this.show_UUID
					dojo.xhrPost({
						'url'		: '?'
						,
						'content'	: {
							'v'		: 'JSON_Attribute',
							'task'	: 'get_A', 
							'UUID'	: show_UUID
						}
						,
						'error'		: function(r,a) {
							try{
								if (typeof (r.responseText)!='undefined') {
									var e=dojo.fromJson(r.responseText);
									application.showErrorMessage(
										'<p><strong>Server error:</strong></p>'+
										'<table><tbody>'+
											'<tr><th>Type</th><td>'+e.type+'</td></tr>'+
											'<tr><th>Message</th><td>'+e.message+'</td></tr>'+
											'<tr><th>Code</th><td>'+e.code+'</td></tr>'+
											'<tr><th>File</th><td>'+e.file+'</td></tr>'+
											'<tr><th>Line</th><td>'+e.line+'</td></tr>'+
											'<tr><th>Trace</th><td><pre>'+e.trace+'</pre></td></tr>'+								
										'<tbody></table>'
										);
								} else {
									application.showErrorMessage('<pre class="small">'+dojo.toJson(r,true)+'</pre>');
								} // end if
							} catch (exception) {
								var errorMessage = '';
								if(r.responsetext) {
									errorMessage = '<p><strong>Server error:</strong></p><pre>'+r.responseText+'</pre>';
								} else {
									errorMessage = '<p><strong>Error:</strong></p><pre>'+exception+'</pre>';
								} // end if
							
								application.showErrorMessage(errorMessage);
							} // end try ... catch
						}, // end of error method
						'handleAs'	: 'json',
						'scope'		: this,
						'load'		: function(response,request){ // onSuccess 
							
							connectedA = response; 
													
						}, // end of onSuccess method
						//preventCache:true,
						//failOk	: true,
						'sync'		: true,
						'timeout'	: 	application.configuration.global.AJAX_default_timeout
					});

					return 	application.attributeKinds.attributeKindList[connectedA.kind].getParsedQuery(item,rqWidget,connectedA);

					break;
*/
				}
				default: {
					break;
				}
			} // end-of-switch (showWhat)

		}, // end-of-method getParsedQuery
		
		
		'_end_': null
		
	}
);
