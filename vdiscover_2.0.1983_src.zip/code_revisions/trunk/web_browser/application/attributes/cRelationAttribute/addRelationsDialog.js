﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// extend the application functionality with relation management for objects

application.attributes.cRelationAttribute={};

application.attributes.cRelationAttribute.addRelations = {
	dialogId: 'application.Dialogues.addRelations'
	,
	dialogWidget : null // dijit.Dialog
	,
	attrWidget : null // a relation attribute widget
	,
	searchBoxId : 'application.Dialogues.addRelations.findInputBox'
	,
	searchBoxWidget : null // dijit.form.ValidationTextbox
	,
	resultListId : 'application.Dialogues.addRelations.resultList'
	,
	resultListWidget : null // dijit.form.MultiSelect
	,
	showDialog : function (attrWidget) {
	
		// set the relation attribute widget
		this.attrWidget = attrWidget;
	
		// identify the dialog
		if(!this.dialogWidget) {
			this.dialogWidget = dijit.byId(this.dialogId);
			this.searchBoxWidget = dijit.byId(this.searchBoxId);
			this.resultListWidget = dijit.byId(this.resultListId);
			dojo.connect(this.searchBoxWidget,'onChange',this,this.searchTermHasChanged);
		} // end if
	
		// set some titles and carry out some other preparations
		this.dialogWidget.attr('title', T('addRelationsDialog.js/CreateRelTo_TIT', 'Create relations to « $[0]» ', [this.attrWidget.config.End_OT_name]) );
		dijit.byId('application.Dialogues.addRelations.FindContainer').attr('title', T('addRelationsDialog.js/FindEndOTName_TXT', 'Find $[0]', [this.attrWidget.config.End_OT_name]) );
		dojo.attr('application.Dialogues.addRelations.searchResultsNode','innerHTML', '&nbsp;');
		dojo.attr('application.Dialogues.addRelations.markMessage_OTName','innerHTML', this.attrWidget.config.End_OT_name);
		
		dijit.byId('application.Dialogues.addRelations.duplicateButton').attr('style', 'display:'+(this.attrWidget.config.duplicateTargetBeforeCreating?'block':'none'));
		
		// locate the tab for creating new objects
		var newObjectTab = dijit.byId('application.Dialogues.addRelations.NewObjectContainer'),
			tabContainer = dijit.byId("application.Dialogues.addRelations.TabContainer");
		if(this.attrWidget.config.creatingTargetObject_permitted) {
			if (tabContainer.getIndexOfChild(newObjectTab)==-1) {
				tabContainer.addChild(newObjectTab);
			} // end if
			this.buildTypeTree();
			this.selectedType_UUID='';
		} else {
			if (tabContainer.getIndexOfChild(newObjectTab)!=-1) {
				tabContainer.removeChild(newObjectTab);
			} // end if
		} // end if
		
		dijit.byId('application.Dialogues.addRelations.newButton').attr('disabled',true);
		
		// empty the search result list
		dojo.empty(this.resultListWidget.domNode);
		// ... and fill it with initial search results
		this.searchBoxWidget.attr('value', '*');
				
		// show the dialog	
		this.dialogWidget.show();
	} // end of method show
	,
	selectedType_UUID : ''
	,
	buildTypeTree : function () {
		
		// delete a possibly existing old type tree
		if(this.typeTree) {
			if (this.typeTree.destroyRecursive) this.typeTree.destroyRecursive(false);
			delete this.typeTree;
		} // end if
		
		// build the type tree

		try {
		
			this.navigationModel = new dijit.tree.ForestStoreModel({
				store: application.OT.navigationStore,
				// query: {'type': 'navigation_node'},
				query: {'UUID': this.attrWidget.config.End_OT_UUID},
				childrenAttrs : ['children']
			});
			
			var tree_DOMNode = dojo.create('DIV',{},'application.Dialogues.addRelations.NewObjectTypeTree');
			// this is necessary because this node will be destroyed by the deletion routine, above
		
			this.typeTree = new dijit.Tree ({
					model: this.navigationModel,
					openOnClick: false,
					showRoot: false,
					persist: true,
					onClick:function(item, node) {
						dijit.byId('application.Dialogues.addRelations.newButton').attr('disabled',false);
						application.attributes.cRelationAttribute.addRelations.selectedType_UUID = 
							application.OT.navigationStore.getValue(item, 'UUID');
						// with (application.OT.navigationStore) {
								// application.OT.currentObjectType = item;
								// if(item && (getValue(item, 'type')=='OT')) {
									// application.OT.show(getValue(item, 'UUID'));
								// }// end if
						// } // end with
					} // end of method onClick
					,
					getIconClass : function(item, isOpened) {
						// get item type
						var type='', has_children=false;
						try{ 
							type=(application.OT.navigationStore.hasAttribute(item,'type')?application.OT.navigationStore.getValue(item,'type'):'');
						} catch(e){}
						if(type=='OT') try{ 
							has_children=(application.OT.navigationStore.hasAttribute(item,'children') && application.OT.navigationStore.getValue(item,'children'));
						} catch(e){}
						var iconClass='';
						switch(type){
							case 'navigation_node':
								iconClass='RS_icon_navigation_node';
								break;
							case 'OT':
								iconClass=(has_children?'RS_icon_OT_with_children':'RS_icon_OT');
								break;
							default:
								iconClass='';
						} // end switch
						
						return iconClass;
					} // end of method getIconClass
				}, 
				tree_DOMNode
			);
						
		} catch(e) {
			console.log('Error when creating type tree for the add relations dialog.', e);
		} // end-of try...catch

	} // end of method 
	,
	searchTimeOut : null // JavaScript TimeOut
	,
	searchTimeOutWaitForMSeconds : 250 // wait xx msec before starting to search
	,
	searchPattern : '' // string
	,
	selectedTargetObjectsHaveChanged : function () {
	
		if (!this.attrWidget.config.multipleRelationsAtOnce) return;
	
		// iterate over all options and leave just the first selected
		var options = this.resultListWidget.domNode.childNodes,
			selectedOptions = 0;
		
		if (options.length) dojo.forEach(options,function(o,i){
			if(o.selected) {
				if(selectedOptions) {
					dojo.attr(o, 'selected', false);
				} // end if
				selectedOptions++;
			} // end if
		},this);
	
	} // end of method selectedTargetObjectsHaveChanged
	,
	searchTermHasChanged : function () {
		// check if the search box contents are valid
		if(!this.searchBoxWidget.isValid()) return;
		
		// get the search term
		var searchTerm = dojo.trim(this.searchBoxWidget.attr('value'));
		
		// prepare the search execution
		
		// if there is already a timeout: delete it
		if (this.searchTimeOut) {clearTimeout(this.searchTimeOut);this.searchTimeOut=null;}
		
		// store the search pattern
		this.searchPattern=searchTerm;
		
		// set the new timeout
		this.searchTimeOut=setTimeout(function(){
				application.attributes.cRelationAttribute.addRelations.searchForObjects();
			}, this.searchTimeOutWaitForMSeconds);
		
	} // end of method searchTermHasChanged
	,
	searchResultStore : null // dojo.data.ItemFileWriteStore
	,
	searchForObjects : function () {
		// send a search query to the server and display the results
		// console.log(this.searchPattern);
		// console.log(this.attrWidget.config);


		// execute search the given pattern
		application.OT_AJAX_query({ 
				"task"		: 'get_Os_by_name', 
				"pattern"	: this.searchPattern,
				"OT_UUID"	: this.attrWidget.config.End_OT_UUID
			}, 
			function(r,a){ /* onSuccess */
				
				// locate the search result list
				var sR_list=dijit.byId('application.Dialogues.addRelations.resultList');
				
				// empty the search result list
				dojo.empty(sR_list.domNode);
				
				// set up the store for the search results
				application.attributes.cRelationAttribute.addRelations.searchResultStore = new dojo.data.ItemFileWriteStore({
					data: r, 
					clearOnClose : true
				});
				
				var searchResults			=	0,
					alreadyLinkedResults	=	0;
				
				// iterate over the search results and decide what to do with them
				application.attributes.cRelationAttribute.addRelations.searchResultStore.fetch({
					'scope' : this,
					sort: [{ attribute: "name", descending: false}],
					onItem : function (item) {with(application.attributes.cRelationAttribute.addRelations.searchResultStore){
						searchResults++;
						var O_UUID=getValue(item,'O_UUID');
					
						// is the item already in the relation list?
						var relAlreadyExists=application.attributes.cRelationAttribute.addRelations.attrWidget.isObjAlreadyInList(O_UUID);
												
						if(relAlreadyExists) alreadyLinkedResults++;
						
						// output the item in the search result list
						var multRels_permitted = application.attributes.cRelationAttribute.addRelations.attrWidget.config.multipleRelationsToTheSameTarget_permitted;
						if( multRels_permitted || !relAlreadyExists) {
							sR_list.domNode.appendChild( dojo.create('option', {
								'innerHTML'	:	getValue(item,'name'),
								'id'		:	'sr_'+O_UUID,
								'value'		:	O_UUID,
								'style'		:	'cursor:pointer'
							}) );
						} // end if relAlreadyExists
						
					}} // end of method onItem
				});
				
				// output a message with the number of search results
				var srMessage 					= '', 
					addRelationsButtonWidget	= dijit.byId('application.Dialogues.addRelations.execButton');
				if (searchResults &&(searchResults == alreadyLinkedResults)) {
					//srMessage=searchResults.toString()+' search results, but there are relations to all of them, already.';
					srMessage= T('addRelationsDialog.js/SearchResMsg_1_TXT', '$[0] search results, but there are relations to all of them, already.', [searchResults.toString()]);
					// disable the add relations button
					addRelationsButtonWidget.attr('disabled',true);
				} else if (searchResults && alreadyLinkedResults) {
					// enable the add relations button
					addRelationsButtonWidget.attr('disabled',false);
					srMessage= T('addRelationsDialog.js/SearchResMsg_2_TXT', '$[0] search results (there are already relations to $[1] results).', [searchResults.toString(), alreadyLinkedResults.toString()]);
				} else if (searchResults) {
					// enable the add relations button
					addRelationsButtonWidget.attr('disabled',false);
					//srMessage=searchResults.toString()+' search results.';
					srMessage= T('addRelationsDialog.js/SearchResMsg_3_TXT', '$[0] search results.', [searchResults.toString()]);
				} else {
					srMessage= T('addRelationsDialog.js/SearchResMsg_4_TXT', 'Sorry &ndash; there are no search results.');
					// disable the add relations button
					addRelationsButtonWidget.attr('disabled',true);
				} // end if there are search results
				
				dojo.attr('application.Dialogues.addRelations.searchResultsNode','innerHTML', srMessage);
				
			} // end of onSuccess method
			, true /* syncronous */
		); // end AJAX query

	} // end of method searchForObjects
	,
	DialogCancel : function(){
		// destroy the edit widgets
		
		// clear the temp variable
		
		// hide the dialogue
		this.dialogWidget.hide();
	}
	,
	DialogExecute : function(specialCommand) {
	
		// get the selected relations
		var selectedEndObjs = this.resultListWidget.attr('value');
		
		if(specialCommand=='new' && this.selectedType_UUID) { // Create a relation to a new object
			this.attrWidget.askServerForRelationTemplates('', '', specialCommand, this.selectedType_UUID);
			
		} else { // Create a relation to a (duplicate) of an existing object
			dojo.forEach(selectedEndObjs,function(O_UUID){
				
				// get the item name			
				var name='';
				this.searchResultStore.fetch({
					query:{'O_UUID':O_UUID},
					onItem: function(item) {
						name=application.attributes.cRelationAttribute.addRelations.searchResultStore.getValue(item,'name');
					} // end onItem
				});
				
				// pass the selected relation to the attribute widget
				this.attrWidget.askServerForRelationTemplates(O_UUID, name, specialCommand);
			},this);
			
		} // end if
		
		// hide the dialogue
		this.dialogWidget.hide();
		
	} // end of method execute
	
}; // end extension of the application functionality
