/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare("application.widgets.valueTuple_relation", [dijit._Widget,dijit._Templated],{
	'widgetsInTemplate' : true,
	'valueTuple'	: null, // needs to be passed
	'attrWidget'	: null, // needs to be passed
	'postMixInProperties' : function () {
		this.inherited(arguments);
	
		this.config = this.attrWidget.config;
		
		var output = '<div dojoAttachPoint="vTdomNode"></div>';
		if(!this.config.hideAttributes && ('relationAttributeValueSets' in this.valueTuple) && Object.keys(this.valueTuple.relationAttributeValueSets).length) {
			output = ""
				// +"<table class='compact fullWidth'><tr>"
					// +"<td width='50%'><div dojoAttachPoint='relAVSets_domNode'></div></td>"
					// +"<td width='50%'>"+output+"</td>"
				// +"</tr></table>"
				+"<table class='compact'><tr>"
					+"<td width=''><div dojoAttachPoint='relAVSets_domNode'></div></td>"
					+"<td width=''>"+output+"</td>"
				+"</tr></table>"
				;
		} // end if
	
		// wrap the template string if necessary
		if (this.config.svFormatActivated) {
			this.templateString = 		this.config.svHtmlTagBeforeValueTuple
									+	output
									+	this.config.svHtmlTagAfterValueTuple;
		} else {
			this.templateString = output;
		} // end if
	
	
	} // end of method postMixInProperties
	,
	'postCreate' : function () {
	
		// if given: show the relationship's attributes
		if(!this.config.hideAttributes && ('relationAttributeValueSets' in this.valueTuple) && Object.keys(this.valueTuple.relationAttributeValueSets).length) {
			dojo.require('application.widgets.attributes.relationValueTupleView');
			this.relAVSetView = new application.widgets.attributes.relationValueTupleView({
				'relationAttributes'		: this.config.relationAttributes,
				'attributesWithValueSets' 	: this.valueTuple.relationAttributeValueSets,
				'readmode'					: true,
				'parentVTEditor'			: this
			}).placeAt(this.relAVSets_domNode);
			this._supportingWidgets.push(this.relAVSetView);
		} // end if
	
		// show an attribute or view of the target object
		switch (this.config.showWhat) {
			case 'A': {// show an attribute of the related object
				var aV=this.valueTuple.atEndObject.attributesWithValueSets,
					A_UUID = Object.keys(aV)[0],
					attrObj= aV[A_UUID],
					attrType=(application.attributeKinds.attributeKindList[attrObj.attribute.kind].widgetClass).replace('application.widgets.',''),
					targetObj_widget = new application.widgets[attrType]({
							'A_UUID'		: A_UUID,
							'O_UUID'		: this.valueTuple.atEndObject.object.O_v_UUID,
							'isEmbedded'	: true,
							'edit'			: false, // read mode
							'valueTuples'	: attrObj.values,
							'config'		: attrObj.attribute // config
						}).placeAt(this.vTdomNode);
				this._supportingWidgets.push(targetObj_widget);
				break;}
			case 'V': {// show a view of the related object
				var targetObject_name = this.valueTuple.atEndObject.object.name;
				with (this.valueTuple.atEndObject.viewType) {
					var targetObj_widget = application.viewKinds.viewKindList[kind].createWidget({
						'O_UUID'				: ORT_UUID,
						'O_name'				: targetObject_name,
						'viewName'				: name,
						'VT_UUID'				: VT_UUID,
						'edit'					: false,
						'displayEmbedded'		: true,
						'rA_parentWidget'		: this,
						'rA_valueTuple'			: this.valueTuple,
						// 'AV_UUID_of_valueTuple': AV_UUID,
						'refreshFromServer'		: false, // means: attribute values are passed, directly
						'attributesWithValueSets': this.valueTuple.atEndObject.attributesWithValueSets//values.attributeValueSets
					}).placeAt(this.vTdomNode);
					targetObj_widget.refreshContents('actualise');
					this._supportingWidgets.push(targetObj_widget);
				} // end with
				break;}
			case 'N': 
			default: { // show a link to the related object
					var targetObj_widget = new application.widgets.internalLink({
						'O_v_UUID'				: this.valueTuple.atEndObject.object.O_v_UUID,
						'linkName'				: this.valueTuple.atEndObject.object.name,
					}).placeAt(this.vTdomNode);
					this._supportingWidgets.push(targetObj_widget);
				} // end of switch - default
		} // end switch
	
	} // end of method postCreate
	,
});

dojo.declare("application.widgets.valueTupleEditor_relation",[application.widgets.valueTupleEditor_generic],{
	
	'textBox' : null, // dijit.form.ValidationTextBox
	
	'buildTemplateContainer' : function() {
		
		var targetObjectAnchorHTML = '';
		if (this.valueTuple.atEndObject) { // is the relation already created?
			// the relation does already exist
			targetObjectAnchorHTML = '<div dojoAttachPoint="textBoxOuter">'
					+'<div dojoAttachPoint="relObjContent_domNode"></div>'
				+'</div>';
		} else {
			// the relation does not exist yet --> render the name of the linked object
			targetObjectAnchorHTML = '<div dojoAttachPoint="textBoxOuter">'
					+'<div dojoType="application.widgets.internalLink" O_v_UUID="'
						+this.valueTuple.End_O_UUID
					+'">'
						+this.valueTuple.End_O_name
					+'</div>'
				+'</div>';
		} // end if
		
		// Does the relation type have attributes?
		if (!this.config.hideAttributes && Object.keys(this.config.relationAttributes).length) {
			// the relation has editable attributes
			this.templateContainer = ""
				// +"<table class='compact fullWidth'><tr>"
					// +"<td dojoAttachPoint='relAVSets_domNode' width='50%'>"
					// +"</td><td width='50%'>"
						// +targetObjectAnchorHTML
					// +"</td>"
				// +"</tr></table>"
				+"<table class='compact'><tr>"
					+"<td dojoAttachPoint='relAVSets_domNode' width=''>"
					+"</td><td width=''>"
						+targetObjectAnchorHTML
					+"</td>"
				+"</tr></table>"
				;
		} else {
			// the relation has no attributes
			this.templateContainer = targetObjectAnchorHTML;
		} // end if
		
	} // end of method postMixInProperties
	,
	'postCreate' : function () {
		this.inherited(arguments);
		
		// create a view for the attribute-value sets of the relation
		if(!this.config.hideAttributes && Object.keys(this.config.relationAttributes).length) {
			dojo.require('application.widgets.attributes.relationValueTupleView');
			this.relAVSetView = new application.widgets.attributes.relationValueTupleView({
				'relationAttributes'		: this.config.relationAttributes,
				'attributesWithValueSets' 	: this.valueTuple.relationAttributeValueSets,
				'readmode'					: false,
				'parentVTEditor'			: this
			}).placeAt(this.relAVSets_domNode);
			this._supportingWidgets.push(this.relAVSetView);
		} // end if
		
		// render the contents of the related object at this.relObjContent_domNode
		var editRelatedObject 	= ((this.attrWidget.outputMode=='edit') && this.attrWidget.config.editRelatedObject),
			AV_UUID				= this.valueTuple.AV_UUID;
		switch (this.attrWidget.config.showWhat) {
			case 'A': {// show an attribute of the related object
				var aV					= this.valueTuple.atEndObject.attributesWithValueSets,
					A_UUID 				= Object.keys(aV)[0],
					attrObj				= aV[A_UUID],
					attrType			= (application.attributeKinds.attributeKindList[attrObj.attribute.kind].widgetClass).replace('application.widgets.','');
					
				this.endObjWidget		= new application.widgets[attrType]({
					'A_UUID': 		A_UUID,
					'O_UUID': 		this.valueTuple.atEndObject.object.O_v_UUID,
					'isEmbedded':	true,
					'edit':			editRelatedObject,
					'valueTuples':	attrObj.values,
					'config':		attrObj.attribute // config
				}).placeAt(this.relObjContent_domNode);
				this._supportingWidgets.push(this.endObjWidget);
				break;}
			case 'V': {// show a view of the related object
				var targetObject_name 	= this.valueTuple.atEndObject.object.name,
					viewType 			= this.valueTuple.atEndObject.viewType;
					
				this.endObjWidget		= application.viewKinds.viewKindList[viewType.kind].createWidget({
					'O_UUID':			viewType.ORT_UUID,
					'O_name':			targetObject_name,
					'viewName':			viewType.name,
					'VT_UUID':			viewType.VT_UUID,
					'edit':				editRelatedObject,
					'displayEmbedded':	true,
					'rA_parentWidget': this.attrWidget,
					'rA_valueTuple': this.valueTuple,
					'refreshFromServer': false, // means: attribute values are passed, directly
					'attributesWithValueSets' : this.valueTuple.atEndObject.attributesWithValueSets
				}).placeAt(this.relObjContent_domNode);
				this.endObjWidget.refreshContents(editRelatedObject?'activateEditMode':'actualise');
				this._supportingWidgets.push(this.endObjWidget);
				break;}
			case 'N': 
			default: { // show a link to the related object
				this.endObjWidget = new application.widgets.internalLink({
					'O_v_UUID'				: this.valueTuple.atEndObject.object.O_v_UUID,
					'linkName'				: this.valueTuple.atEndObject.object.name,
				}).placeAt(this.relObjContent_domNode);
				this._supportingWidgets.push(this.endObjWidget);
				} // end of switch - default
		} // end switch
		
	} // end of method postCreate
	,
	'isValid' : function () {
		// valid means here: 
		// 	- all attribute value tuples of the relation are valid 		AND 
		//	- all attribute value tuples of the relation's end object view in edit mode are valid
		var isValid = true;
		if((this.attrWidget.outputMode=='edit') && this.attrWidget.config.editRelatedObject) isValid = isValid && this.endObjWidget.isValid();
		if (Object.keys(this.config.relationAttributes).length) isValid = isValid && this.relAVSetView.isValid();
		// if (this.valueTuple.atEndObject) 						isValid = isValid && 1;
		
		return isValid; // the value tuple editor contains a valid value tuple, always 
	} // end of method
	,
	'notifyAttributeOfChangedValue' : function () {

		// it is necessary to tell the attribute that the slot this.valueTuple.positionOfValue was modified
		
	} // end of method notifyAttributeOfChangedValue
});
