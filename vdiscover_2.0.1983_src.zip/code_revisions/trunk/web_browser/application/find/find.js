/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare('application.widgets.SearchResultWidget', [dijit.layout.ContentPane], {

	// Slots to be set on instantiation
	'title'		         	    : null, // string
	'OT_UUID'		        	: null, // string
	'pattern'		        	: null, // string
	'searchDomain'        	    : null, // string
	'parentTabContainer_id'     : null, // string


	// settings of dijit.layout.ContentPane
	'closable'          : true,
	'widgetsInTemplate' : true,	
	'refreshOnShow' 	: true,

	
    'constructor' : function(params, srcNodeRef) {
        // Your constructor method will be called before the parameters are mixed into the widget, 
		// and can be used to initialize arrays, etc.
	   
	   this.inherited(arguments);
	},
    /*parameters are mixed into the widget instance

        This is when attributes in the markup (ex: <button iconClass=...>) are mixed in or, 
		if you are instantiating directly, the properties object you passed into the constructor 
		(ex: new dijit.form.Button({label: "hi"})). This step itself is not overridable, but you 
		can play with the result in...
	*/
    'postMixInProperties' : function () {

       // If you provide a postMixInProperties method for your widget, 
	   // it will be invoked before rendering occurs, and before any dom 
	   // nodes are created. If you need to add or change the instance's 
	   // properties before the widget is rendered - this is the place to do it.
	   
		this.inherited(arguments);
	   
		// test if everything necessary is available
		if(! this.OT_UUID ) throw ('Cannot initialise application.widgets.SearchResultWidget without OT_UUID. Aborting.');
		if(! this.pattern ) throw ('Cannot initialise application.widgets.SearchResultWidget without a search term. Aborting.');
		if(! this.searchDomain ) throw ('Cannot initialise application.widgets.SearchResultWidget without searchDomain. Aborting.');
	   
		// set some attributes
	
		if ( this.searchDomain == 'all'){
			var param_OT_UUID = '';
		} else {
			var param_OT_UUID = '&OT_UUID='+this.OT_UUID;
		}
		
		// get search results
		this._searchResultStore = new dojo.data.ItemFileWriteStore({
								url: "?v=JSON_ObjectType&task=searchObjectsBy_nameOrDescription&pattern="+this.pattern+param_OT_UUID,
								clearOnClose: true
							});
			
		// clear existing _objectTypesStore by closing
		if ( this._objectTypesStore ) this._objectTypesStore.close();
		
		// create store object for object types
		this._objectTypesStore = new dojo.data.ItemFileWriteStore({
									data: { identifier : 'UUID',
											label : 'name',
											items:[]
										},
									clearOnClose: true
								});
		
		var resultWidget = this;
					
		// add items to _objectTypesStore
		this._searchResultStore.fetch({
			'onItem': function(item){ 
					var objectType={
							name : resultWidget._searchResultStore.getValue(item,'OT_name'),
							UUID : resultWidget._searchResultStore.getValue(item,'OT_UUID')
						};

					var newItem = true;

					resultWidget._objectTypesStore.fetchItemByIdentity (
						{ 	identity: objectType.UUID,
							onItem: function(res){
								if (res) newItem = false;
							}
						}
					);
					// add item to _objectTypesStore
					if ( newItem == true  ){
						resultWidget._objectTypesStore.newItem(objectType);
					}
					
				},
			'onComplete': function (items) {
					resultWidget._objectTypesStore.save();
				}
		});

	}
	,
    /*buildRendering : function () {

        // dijit._Templated provides an implementation of buildRendering that most 
		// times will do what you need. The template is fetched/read, 
		// nodes created and events hooked up during buildRendering. 
		// The end result is assigned to this.domNode. If you don't mixin dijit._Templated 
		// (and most OOTB dijits do) and want to handle rendering yourself 
		// (e.g. to really streamline a simple widget, or even use a different templating system) 
		// this is where you'd do it.
	}
	,*/
    /*setters are called

        All attributes listed in attributeMap are applied to the DOM, 
		and attributes for which there are custom setters (see attributes, those custom setters are called
	*/
    'postCreate' : function () {

        // This is typically the workhorse of a custom widget. The widget has been rendered 
		// (but note that sub-widgets in the containerNode have not!). 
		// The widget though may not be attached to the DOM yet so you shouldn't do any sizing calculations in this method.
	   this.inherited(arguments);

	} 
	,
	'grid_headerStructure' : [
				{
					field: 'quality',
					name: T('FUT_Quality', 'Quality'),
					width: '3em'
				},
				{
					field: 'isTagged',
					name:	'<div style="text-align:center;">' + T('FUT_Tagged', 'Tagged') + '</div>',
					width:	'3em',
					formatter : function(isTagged,rowIndex,cellObj){
						// var grid=cellObj.grid, 
							// store=grid.store, 
							// item=grid.getItem(rowIndex),
							// O_v_UUID=store.getValue(item,'O_v_UUID');
						
						return (isTagged?'<div style="text-align:center;"><img src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/others/tag-orange.png" /></div>':'');
					} // end of formatter function
				},
				{
					field: 'name',
					name: '<b>' + T('FUT_Name', 'Name') + '</b>',
					width: '10em',
					formatter: function(name,rowIndex,cellObj){						
						var grid=cellObj.grid, 
							store=grid.store, 
							item=grid.getItem(rowIndex),
							isTagged=store.getValue(item,'isTagged'),
							O_v_UUID=store.getValue(item,'O_v_UUID');
						return new application.widgets.internalLink({
							"O_v_UUID" : O_v_UUID,
							"linkName" : (isTagged?'<b>'+name+'</b>':name)
						});
					} // end of formatter function
				},
				{
					field: 'OT_name',
					name: T('FUT_Type','Type'),
					width: '7.5em',
				},
				{
					field: 'description',
					name: T('FUT_Description','Description'),
					width: 'auto',
					'formatter' :function(value, rowIndex, cellObj){
						return '<div class="small">'+value+'</div>';
					},
				},	
				{
					field: 'changedAt',
					name: '<div style="text-align:right">' + T('FUT_LastChange','Last change') + '</div>',
					width: 'auto',
					formatter: function(value,rowIndex,cellObj){
						var d=new Date(value.replace(' ','T')), now=new Date(), r='';
						// pretty-format the date
						if (dojo.date.difference(d,now,'hour')<1)			r= T('find.js/XminAgo_TXT','$[0] min ago', [dojo.date.difference(d,now,'minute')]);
							else if (dojo.date.difference(d,now,'day')<1) 	r=dojo.date.locale.format(d,{selector:'time'});
							else 								 			r=dojo.date.locale.format(d);
						return '<div style="text-align:right;">'+r+'</div>'
					} // end of formatter function
				},
				{
					field: 'changedByP_name',
					// name: '<span class="small">Changed by</span>',
					name: T('FUT_ChangedBy','Changed by'),
					width: 'auto',
					formatter: function(name,rowIndex,cellObj){
						var grid=cellObj.grid, 
							store=grid.store, 
							item=grid.getItem(rowIndex),
							changedByP_O_v_UUID=store.getValue(item,'changedByP_O_v_UUID');
						return new application.widgets.internalLink({
							"O_v_UUID" : changedByP_O_v_UUID,
							"linkName" : name
						});
					} // end of formatter function
				}
			]	// end of grid_headerStructure
	,	
	'_createContent' : function () {
	
		// create BorderContainer
		var bC = new dijit.layout.BorderContainer({
			gutters : false
		});
		
		// create MenuBar
		this._menuBar = new dijit.MenuBar ({
			region : "top",
			style  : "height:1.95em;margin-bottom:1ex;border-top:0;border-right:0;border-left:0;"
			});
		
		bC.addChild(this._menuBar);			
		
		// add items to _objectTypesStore
		var resultWidget = this;
		this._searchResultStore.fetch({
			onItem: function(item){ 				
					// find tagged items
					var O_v_UUID = resultWidget._searchResultStore.getValue(item,'O_v_UUID');
					var isTagged = application.O.readList.isTagged(O_v_UUID);
					resultWidget._searchResultStore.setValue( item, 'isTagged', isTagged);	
				},
			onComplete: function (items) {
					resultWidget._searchResultStore.save();
				}
		});
		
		// create DataGrid
		dojo.require("dojox.grid.DataGrid");
		
		this.searchResultGrid = new dojox.grid.DataGrid ({
					'store'             : this._searchResultStore,
					'query'             : { UUID: '*' },
					'clientSort'        : true,
					'style'             : "width: 100%; height: 100%;",
					'structure'         : this.grid_headerStructure,
					'formatterScope'    : this,
					'noDataMessage'     : T('find.js/NoDataMsg_TXT','Sorry, no matches to your find query.'),
					'escapeHTMLInData'  : false,
					'onRowDblClick'     : function(evt){
						var items = this.selection.getSelected();
						var grid = this;
						dojo.forEach(items,function(i){
							application.O.show(grid.store.getValue(i,'UUID'));
						});
					}
				});
		
		// create ContentPane
		var cP = new dijit.layout.ContentPane({
			style 	: "width: 100%;",
			region 	: "center",
			content	: this.searchResultGrid
		});
		bC.addChild(cP);		

		// add content to pane
		this.attr('content',bC);
		
		// ?? startup of grid???
		this.searchResultGrid.startup();
	
	} // end of internal method _createObjectWidget
	,
	'_addMenuBarItems' : function() {
	
		{	// add filtering select if no type is selected or objects of 
			// more than one type are in the result list
			var numberOfTypes = 0;
			this._objectTypesStore.fetch({
					onBegin: function(count){
						numberOfTypes = count;
						}
				});
			if (this.OT_UUID =='none' || numberOfTypes > 1 ){
				var pattern = this.pattern;
				var typeSelect = new dijit.form.FilteringSelect({
							value: '',
							store: this._objectTypesStore,
							searchAttr: 'name',
							name: 'OT_UUID',
							placeHolder: T('find.js/FilterObjTp_TXT','Filter Object Types'),
							required: false,
							onChange: function (newValue){
									application.OT.findInfObjs( pattern ,newValue)
								}
						});
				
				this._menuBar.addChild(typeSelect);
			}	
		}	
		
		{	// add menu bar item for build query
			if ( this.OT_UUID !='none' ) { 
				var OT_UUID = this.OT_UUID;
				var queryButton = new dijit.MenuBarItem({
							label: 'Query',
							tooltip: T('find.js/SrchTip_TTP','Click here to improve your search.'),
							onClick: function(){
										application.OT.buildRetrievalQuery(OT_UUID);
									}
						});
				
				this._menuBar.addChild(queryButton);
			}
		}
	 
	} // end of internal method _addMenuBarItems
	,
    'startup' : function () {

        // If you need to be sure parsing and creation of any child widgets has completed, use startup. 
		// This is often used for layout widgets like BorderContainer. If the widget does JS sizing, 
		// then startup() should call resize(), which does the sizing.
		
		// If you need to be sure parsing and creation of any child widgets has completed, use startup. 
		this.inherited(arguments);
	   
		dojo.connect(this,'onShow',this,function(){
		
			// create the top pane for the name and menu bar, create the views container

			// dynamically refresh the store's contents
			this._createContent();

			// create menuBarItems
			this._addMenuBarItems();

			
		});		
		
	}
	,
    /*destroy : function () {

        //Implement destroy if you have special tear-down work to do (the superclasses will take care of most of it for you.
		
	}*/
});
