/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// widget declaration for internal link
dojo.declare("application.widgets.internalLink", [dijit._Widget, dijit._Templated],{

		// these slots need to be passed on instantiation:
		'linkName' : '', // not necessary for declarative instantion
		'O_v_UUID' : 'this_O_v_UUID',
		
		
		'templateString': ''
			+'<a href="${url}" dojoAttachPoint="containerNode" dojoAttachEvent="onclick:_myOnClick" title="${title}">'
				+'<img class="internalLink_image" src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/page-white_link.png"/>'
				+'${linkName}'
			+'</a>',
		'_myOnClick':function(e){
			application.O.show(this.O_v_UUID);
			dojo.stopEvent(e);
		},
		'title' : '',
		'class': 'internalLink',
		'postMixInProperties':function(){
			this.url='?'+dojo.objectToQuery({jumpTo:'O','O_v_UUID':this.O_v_UUID});
			this.title = T('application.widgets.internalLink.js/title_TXT','Click here to follow this link, drag it to another application (e.g. e-mail, word processor) or to your bookmark bar.');
		} // end of method postMixInProperties
});

// widget declaration for internal link
dojo.declare("application.widgets.internalLink_objectType", [dijit._Widget, dijit._Templated],{
		'templateString': ''
			+'<a href="${url}" dojoAttachPoint="containerNode" dojoAttachEvent="onclick:_myOnClick" title="${title}">'
				+'<img class="internalLink_image" style="vertical-align:text-top;" src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/edit-copy-6.png"/>'
				+'${linkName}'
			+'</a>',
		'_myOnClick':function(e){
		
			application.OT.navigationStore.fetchItemByIdentity({
				'identity'	: this.OT_UUID,
				'scope'		: this,
				'onItem'	: function (item) {
					var store = application.OT.navigationStore;
					if(item && (store.getValue(item, 'type')=='OT')) {
						application.OT.show(	store.getValue(item, 'UUID')/*,
												store.getValue(item, 'name'),
												dojo.fromJson(store.getValue(item, 'menuBarOT'))*/
											);
					}// end if
				}, // end if method inItem
			});

			dojo.stopEvent(e);
		},
		'title' 	: null,
		'linkName'	: '',
		'OT_UUID'	: 'this_OT_UUID',
		'class': 'internalLink',
		'postMixInProperties':function(){
			this.url='?'+dojo.objectToQuery({'jumpTo':'OT','OT_UUID':this.OT_UUID});
			this.title = T('application.widgets.internalLink.js/objectType_TIT','Click here to follow this link to «$[0]», drag it to another application (e.g. e-mail, word processor) or to your bookmark bar.',[this.linkName]);
		} // end of method postMixInProperties
});
