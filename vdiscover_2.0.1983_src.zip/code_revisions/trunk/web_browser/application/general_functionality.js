/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

application.general_functionality = {
		
		'tab_show' : function ( tab_id, tabContainer_id ) {
			// this method brings the tab tab_id in the tab container tabContainer_id to the foreground if both exist
			try { dijit.byId(tabContainer_id).selectChild(tab_id); }
			catch(e){throw("Cannot show the tab with id:'"+tab_id+"' in tab container with id:'"+tabContainer_id+"'.");}
		} // end of method tab_show
		,
		'tab_create' : function (  tabWidget_id, tabWidget_type, tabWidget_config, autoRefresh ) {
			// this method creates a tab widget and returns it
			var tab=null;
			tabWidget_config.id=tabWidget_id;
			if(autoRefresh) tabWidget_config.onShow=function(){if(this.isLoaded) this.refresh();};
			switch (tabWidget_type){
				case 'dijit.layout.ContentPane': {
					tab = new dijit.layout.ContentPane(tabWidget_config);
					break;}
				case 'dijit.layout.BorderContainer':{
					tab = new dijit.layout.BorderContainer(tabWidget_config);
					break;}
				//case '':{
				//	break;}
				//default:
			} // end switch
			return tab;
		} // end of method tab_create
		,
		'display_tab' : function (tabContainer_id, tabWidget_type, tabWidget_id, tabWidget_config, autoRefresh) {
		
			var tab = null;
			
			// Test, if tab already exists. If not, create and place it.
			if (!(tab=dijit.byId(tabWidget_id))) {
				tab=this.tab_create( tabWidget_id, tabWidget_type, tabWidget_config, autoRefresh );
				dijit.byId(tabContainer_id).addChild(tab);
			} // end if
			
			// display the tab
			this.tab_show(tabWidget_id, tabContainer_id);
		
			return tab;
		} // end of method display_tab
		,
		// open or create a tab in a specified tab container
		'show_tab' : function ( tab_id, tab_title, tab_container_widget, URI_encoded_href, autoRefresh ) {
			// some day, this method should be replaced with the method, above.			
			return this.display_tab(
					tab_container_widget.id, 'dijit.layout.ContentPane', tab_id, 
					{title:tab_title, href:URI_encoded_href,closable:true,style:'padding:0'}, 
					autoRefresh
				);
		} // end-of-method show_tab
	} // end-og-object general_functionality
	
	// class declaration for an attribute kind of an information object type
dojo.declare("application.classes.menubar_itemKind_class",null,{
	UUID : "Unique universal Identifier"
	,
	name : "no name, yet"
	,
	JS_command : "alert" // a string with the javascript function to be called in global context
	,
	description : "" // string with html entities
	,
	addWhenCreating : false // boolean
	,
	constructor : function(args) {dojo./*safeMixin*/mixin(this, args);}
	// ,
	// createAttribute : function () {application.admin.manageAttributes.createAttribute(this);}
}); // end of class declaration



// initialisation of the application part that is responsible for the attribute kind management
application.O_menubar_itemKinds = {
	itemKind_List : [],
	itemKinds_asSlots : {},
	register : function(confObj){
		/* The structure of confObj:
			UUID : the UUID of the menu bar item kind,
			name : the name of the menu bar item kind,
			JS_command : a string with the javascript function name that shall be called when clicking on the menu item,
			description : OPTIONAL string with html entities 
		*/
		
		// some checks
		if (!confObj.UUID) throw "No UUID passed in configuration for \""+dojo.toJson(confObj)+"\". Aborting.";
		if (!confObj.name) throw "No name passed in configuration for \""+dojo.toJson(confObj)+"\". Aborting.";
		if (!confObj.JS_command) throw "No JS_command passed in configuration for \""+dojo.toJson(confObj)+"\". Aborting.";
		if (dojo.isObject(this.itemKind_List[confObj.UUID])) throw "An item kind with the passed UUID \""+UUID+"\" does already exist. Aborting.";
		
		var k=new application.classes.menubar_itemKind_class(confObj);
		this.itemKind_List.push(k);
		this.itemKinds_asSlots[confObj.UUID]=k;
	} // end of method register
	,
	getMenuItemsForInitialisation : function () {
		var initialiseItems = []; // Array
		var position =0;
		dojo.forEach(this.itemKind_List,function(i){
			if(i.addWhenCreating) {
				initialiseItems.push({
					label				:	i.name,
					mB_itemKind_UUID	: 	i.UUID,
					UUID				: 	Math.uuid(),
					position			: 	position++,
					type				:	'dijit.MenuBarItem',
					openByDefault 		: 	(i.openByDefault?true:false)
				});
			} // end if
		}); // end for each
		return initialiseItems;
	} // end of method getMenuItemsForInitialisation
}; // end of object definition O_menubar_itemKinds

application.OT_menubar_itemKinds = {
	itemKind_List : [],
	itemKinds_asSlots : {},
	register : function(confObj){
		/* The structure of confObj:
			UUID : the UUID of the menu bar item kind,
			name : the name of the menu bar item kind,
			JS_command : a string with the javascript function name that shall be called when clicking on the menu item,
			description : OPTIONAL string with html entities 
		*/
		
		// some checks
		if (!confObj.UUID) throw "No UUID passed in configuration for \""+dojo.toJson(confObj)+"\". Aborting.";
		if (!confObj.name) throw "No name passed in configuration for \""+dojo.toJson(confObj)+"\". Aborting.";
		if (!confObj.JS_command) throw "No JS_command passed in configuration for \""+dojo.toJson(confObj)+"\". Aborting.";
		if (dojo.isObject(this.itemKind_List[confObj.UUID])) throw "An item kind with the passed UUID \""+UUID+"\" does already exist. Aborting.";
		
		var k=new application.classes.menubar_itemKind_class(confObj);
		this.itemKind_List.push(k);
		this.itemKinds_asSlots[confObj.UUID]=k;
	} // end of method new
	,
	'getMenuItemsForInitialisation' : function () {
		var initialiseItems = []; // Array
		var position =0;
		dojo.forEach(this.itemKind_List,function(i){
			if(i.addWhenCreating) {
				initialiseItems.push({
					label				:	i.name,
					mB_itemKind_UUID	: 	i.UUID,
					UUID				: 	Math.uuid(),
					position			:	position++,
					type				:	'dijit.MenuBarItem',
					openByDefault 		: 	(i.openByDefault?true:false)
				});
			} // end if
		}); // end for each
		return initialiseItems;
	} // end of method getMenuItemsForInitialisation
	,
	'executeCommand' : function (MI_UUID, OT_UUID, OT_TC_id, optionalExecParameters) {
	
		// locate the menu item description
		var mIObj = this.itemKinds_asSlots[MI_UUID];
		
		// test if an executable function is available
		if (typeof mIObj.JS_command != 'function') throw ''
			+'application.OT_menubar_itemKinds'
			+' :: executeCommand("'+MI_UUID+'", "'+OT_UUID+'", "'+OT_TC_id+'", ) :\n'
			+'There is no executable JS_command for the given parameters available. Aborting.'
			;
			
		mIObj.JS_command(OT_UUID, OT_TC_id, optionalExecParameters);
	} // end of method executeCommand
	,
	
}; // end of object definition OT_menubar_itemKinds

