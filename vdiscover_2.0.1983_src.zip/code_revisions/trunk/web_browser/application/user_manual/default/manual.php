﻿<?php if (!defined('APPLICATION_started')) {header('Location: .');exit;}
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// global $repository_config;
// global $r, $backend;

?>
<h2>Executive Summary</h2>
<p>vDiscover is an application for</p>
<ul>
	<li>structuring,</li>
	<li>capturing,</li>
	<li>retaining,</li>
	<li>unveiling,</li>
	<li>developing &hellip;</li>
</ul>
<p>knowledge in teams.</p>
<p>
	The main market are small and medium-sized enterprises with batch production processes.
	vDiscover provides structures for maintaining knowledge about these processes, input and output products and related assets.
</p>
<p>This manual is dedicated to the end user and gives an introduction on how to use vDiscover for everyday tasks.</p>

<h2>Overview of the application window</h2>

<p>The user interface of the main application is structured in the following components:-</p>
<ul>
	<li>the main menu bar,</li>
	<li>the navigation and the</li>
	<li>history pane,</li>
	<li>the type tabs,</li>
	<li>the object tabs and</li>
	<li>this user manual.</li>
</ul>

<div class='RS_A_cFA_outer RS_A_cFA_outerImage' title='The structure of the main application window.'>
	<div class='RS_A_cFA_imageOuter textCenter'>
		<img class='' src='./application/user_manual/default/overview_of_the_application_window.png'
			 style='max-width:85%;'/>
	</div>
	<div class='RS_A_cFA_imageTitle strong textCenter'>
		The structure of the main application window.
	</div>
</div>

<p>Further, there is a right-click menu available. In addition to the main application, vDiscover provides a print preview pane.</p>

<p>The following sections will explain you the functionality of these components.<p>



<h3>Main menu bar</h3>

<p>The main menu bar provides general &mdash; non-content-specific &mdash; application functionality.</p>

<div class='RS_A_cFA_outer RS_A_cFA_outerImage' title='The main menu bar.'>
	<div class='RS_A_cFA_imageOuter textCenter'>
		<img class='' src='./application/user_manual/default/main_menu_bar.png'
			 style='max-width:85%;'/>
	</div>
	<div class='RS_A_cFA_imageTitle strong textCenter'>
		The main menu bar.
	</div>
</div>

<p>
	There is a menu item for showing/ hiding this user manual, another item for switching to the print queue, an item for opening the dialog for user-specific settings (not implemented, yet). Further, there is a menu item for switching to the print preview pane and finally an item for logging out.
</p>

<p>
	Below the main menu bar, there are the navigation pane and the history &laquo;I have seen &hellip;&raquo; pane located.
</p>



<h3>Navigation pane</h3>

<p>The &laquo;I want to navigate to &hellip;&raquo; pane provides a</p>
<ul>
	<li>search & find form and</li>
	<li>a tree with all (accessible) types.</li>
</ul>

<p>Types form at the same time both <i>sets of objects with the same structure</i> and <i>object categories</i>.</p>

<p>Clicking on a type opens a tab with the corresponding objects. You may show or hide sub types by clicking on the +/- box in front of the type name.</p>

<p>
	In case that you want to find a specific object, enter it's name in the box for the search term. You may use wildcards. E.g. searching for <code>*bird*</code> will find <code>black<i>bird</i></code>, <code>humming<i>bird</i></code>, but as well <code><i>bird</i> watching</code> or <code><i>bird</i>ie</code>. The search & find functionality covers currently only the object name. You may restrict findings by selecting a type in the type tree.
</p>



<h3>History &laquo;I have seen &hellip;&raquo; pane</h3>

<p>
	This pane contains a list of all objects that
<p>
<ul>
	<li>you have accesses since logging in and</li>
	<li>that you have tagged for remembering between log-ins.</li>
</ul>

<div class='RS_A_cFA_outer RS_A_cFA_outerImage' title='The history &laquo;I have seen &hellip;&raquo; pane.'>
	<div class='RS_A_cFA_imageOuter textCenter'>
		<img class='' src='./application/user_manual/default/history_pane.png'
			 style='max-width:85%;'/>
	</div>
	<div class='RS_A_cFA_imageTitle strong textCenter'>
		The history &laquo;I have seen &hellip;&raquo; pane.
	</div>
</div>

<p>
	If you click on an object, it will open in the corresponding type tab, doubleclicking on an object tags or untags it for remembering. Tagged objects appear in bold type face and have a tag <img style="vertical-align:middle;" src="./third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/others/tag-orange.png"> symbol.
</p>



<h3>Type tabs</h3>

<p>
	Type tabs provide a menu bar with type-specific actions and host itself tabs for type-specific content and objects.
</p>

<div class='RS_A_cFA_outer RS_A_cFA_outerImage' title='The main structure of type tabs.'>
	<div class='RS_A_cFA_imageOuter textCenter'>
		<img class='' src='./application/user_manual/default/type_tabs.png'
			 style='max-width:85%;'/>
	</div>
	<div class='RS_A_cFA_imageTitle strong textCenter'>
		The main structure of type tabs.
	</div>
</div>

<p>
	The items in the menu bar are configurable and they appear only, if you have the corresponding permissions.
</p>

<p>
	There are tabs that may display an object, others provide navigation functionality like listing all objects or executing retrieval queries. Some tabs will open automatically when accessing the type, others need to be opened, manually.
</p>

<p>
	You may close a tab by clicking on the <img style="vertical-align:text-bottom;" src="./application/user_manual/default/close_tab.gif"> symbol next to the type name.
</p>



<h3>Object tabs</h3>

<p>
	Object tabs appear always in their corresponding type tab. They have a menu bar and distinct views. The views display values of the object.
</p>

<div class='RS_A_cFA_outer RS_A_cFA_outerImage' title='The main structure of an object tab.'>
	<div class='RS_A_cFA_imageOuter textCenter'>
		<img class='' src='./application/user_manual/default/object_tab.png'
			 style='max-width:85%;'/>
	</div>
	<div class='RS_A_cFA_imageTitle strong textCenter'>
		The main structure of an object tab.
	</div>
</div>

<p>
	The object name is a hyperlink. You may drag it e.g. to your browser's favourite bar, to somewhere in the file system or to another application like your e-mail program. When you follow such a hyperlink, your web browser will open vDiscover and display the corresponding object.
</p>

<p>
	The menu bar of an object tab contains on its left hand side available menu items. These menu items do mainly provide options that have to do with the object's life cycle, like renaming, duplicating or deleting it. When clicking on the menu item on the right hand side of an object's menu bar, all shown views of the object are sent to the print queue. This may take a while, as the corresponding content needs to be loaded from the server.
</p>

<p>
	Below the menu bar, there are the views of an object. In general, there are several views. Not all of them may be editable, some are for displaying values or for printing, only. The view name is &mdash; alike the object name &mdash; a hyperlink and may be dragged to the file system, etc. On the top-right corner of a view, there are menu items for editing the view contents and there is an item for sending the view's contents to the print queue.
</p>



<h3>Right-click menu</h3>

<p>
	When you click with the right mouse button anywhere on the application, a menu with general options opens.
</p>

<div class='RS_A_cFA_outer RS_A_cFA_outerImage' title='The right-click menu.'>
	<div class='RS_A_cFA_imageOuter textCenter'>
		<img class='' src='./application/user_manual/default/right_click_menu.png'
			 style='max-width:85%;'/>
	</div>
	<div class='RS_A_cFA_imageTitle strong textCenter'>
		The right-click menu.
	</div>
</div>

<p>
	The right-click menu has the following options:-
</p>
<ul>
	<li>Print queue &mdash; switch between the main application and the print preview pane</li>
	<li>Facts about me &mdash; jump to the object the describes &laquo;you&raquo;<br />(this is not implemented, yet)</li>
	<li>Switch to fullcreen mode</li>
	<li>Log out</li>
</ul>






<h2>Object life cycle</h2>

<p>
	The term &laquo;life cycle&raquo; refers here to the course of stages that an object (entity) passes. Its life cycle covers all main phases &mdash; from its creation until its deletion.
</p>

<p>Currently, vDiscover supports the following object life cycle stage transitions:-</p>
<ul>
	<li>creating,</li>
	<li>modifying,</li>
	<li>duplicating and</li>
	<li>deleting.</li>
</ul>

<p>DITF plans to provide later on more transistions like locking, work flow transitions and recovery of deleted objects.</p>

<p>The following sections explain how the currently implemented life cycle stage transitions may be carried out.</p>




<h3>Creating</h3>

<p>
	To create a new object, go to the corresponding type tab and click on the item &laquo;New object&raquo; (it may have a different name) in the type's menu bar.
</p>

<p>
	A dialog that is asking you for the object name may appear now. This happens only, if the object name is not created automatically from a template (a pattern from which the object name is being derived by using the object's individual values).
</p>

<p>Then, a new object tab will open. You may edit the object, now.</p>


<h3>Modifying</h3>

<p>
	To start modifying an object, just click on the &laquo;<img style="vertical-align:middle;" src="./third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/edit-3.png"> Edit&raquo; menu item on the top-right of the corresponding view. This option is not available, always. This depends on roles and the permissions that you have.
<p>

<p>
	You should see now a couple of edit boxes. Keep in mind that there are values of an object property that are assigned automatically; you cannot edit them.
</p>

<p>
	Object values are organised as &laquo;value tuples&raquo;. These value tuples bundle all (necessary) values that belong together. E.g. a file has besides the file itself a file name, a title and a description. The value tuple for a file contains further the file size and the file type. Sometimes, an object may have more than one value tuple.
</p>

<div class='RS_A_cFA_outer RS_A_cFA_outerImage' title='Buttons for modifying value tuples of an object.'>
	<div class='RS_A_cFA_imageOuter textCenter'>
		<img class='' src='./application/user_manual/default/object_life_cycle_modifying.png'
			 style='max-width:85%;'/>
	</div>
	<div class='RS_A_cFA_imageTitle strong textCenter'>
		Buttons for modifying value tuples of an object.
	</div>
</div>

<p>
	To delete a value tuple, just click on the delete symbol <img style="vertical-align:middle;" src="./third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/bullet-delete.png"> on the right hand side of the value tuple's edit box.
</p>

<p>
	Sometimes, an object property may have more than one value. If this is permitted, you find an add <img style="vertical-align:middle;" src="./third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/bullet-add.png"> symbol for adding a new value tuple. Click on it to create a new value tuple.
</p>

<p>To discard your changes, click in the menu bar item &laquo;<img style="vertical-align:middle;" src="./third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/dialog-cancel-4.png"> Cancel&raquo; of the view.</p>

<p>
	To store your changes, click on the menu bar item &laquo;<img style="vertical-align:middle;" src="./third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/dialog-ok-apply-4.png"> Ok&raquo; of the view. Before storing, vDiscover checks if all necessary values are entered. If not, an error message will appear.
</p>

<p>
	You may only edit values in one view of an object at the same time.
</p>



<h3>Duplicating</h3>

<p>
	Duplicating means to create an identical copy. To generate a duplicate of an object, click on the item &laquo;duplicate&raquo; in the object's menu bar. This item is not available, always.
</p>

<p>
	After duplicating, change the object name, instantly, to avoid problems.
</p>

<h3>Deleting</h3>

<p>
	To delete an object, click on the corresponding item in the menu bar of the object. The object will be deleted <em>without further inquiries</em>.
</p>




<h2>Print preview pane</h2>

<p>
	The print preview pane is basically a list of all information that shall be sent to the printer. You may add information to the print preview pane by clicking on the corresponding <img style="vertical-align:middle;" src="./third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/devices/printer_add.png"> icon.
</p>

<p>
	In order to go to the print preview pane, click on the menu bar item &laquo;<img style="vertical-align:middle;" src="./third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/devices/printer-8.png"> Print Queue&raquo; in the main menu bar or use the same option of the right-click menu.
</p>

<p>
	The display width of the documents in the print queue is the one of a DIN&nbsp;A4 page in portrait orientiation (<code>21</code>&nbsp;cm); the document borders are set to the default printing borders of the Firefox web browser, <code>0.5</code>&nbsp;", which equals <code>1,27</code>&nbsp;cm. For each document, a new page will be started when sending the documents to the printer. Hence, what you see in the print preview pane is roughly what you will get on paper, later on.
</p>

<div class='RS_A_cFA_outer RS_A_cFA_outerImage' title='The main options of the print preview pane.'>
	<div class='RS_A_cFA_imageOuter textCenter'>
		<img class='' src='./application/user_manual/default/print_preview_pane.png'
			 style='max-width:85%;'/>
	</div>
	<div class='RS_A_cFA_imageTitle strong textCenter'>
		The main options of the print preview pane.
	</div>
</div>

<p>The menu bar of the print preview pane contains the following items:-</p>
<ul>
	<li>Send documents to printer &mdash; click here to call the main print dialog of your web browser.</li>
	<li>Empty print queue &mdash; click here to delete all documents in the print queue. This will not affect the corresponding objects.</li>
	<li>Back to the main application &mdash; click here when you have finished.</li>
</ul>

<p>
	There is as well a <img style="vertical-align:middle;" src="./third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/dialog-cancel-4.png"> delete button for each document in the print queue. Click on this button, if you want to remove one document, only.
</p>

<p>
	There is further a special right-click menu for the print preview pane. It covers options that correspond to the ones in the menu bar of the print preview pane.
</p>










<h2>Information retrieval</h2>

<!-- ### HEIKO ### -->

Identification of interesting objects via 
mandatory and 
optional property sets (similarity rating is planned)

<h3>
	The retrieval query tab 
</h3>
<p>
	The retrieval query tab gives you the opportunity to define very specific queries. Within these queries you can search for all objects of a certain type which have a special attribute value or combination of several attributes. The tab itself consists of a list of all relevant attribute on the left, an editing area on the right and several buttons for saving, loading and executing the retrieval queries. 
</p>
<div class='RS_A_cFA_outer RS_A_cFA_outerImage' title='Starting screen of the retrival query pane.'>
	<div class='RS_A_cFA_imageOuter textCenter'>
		<img class='' src='./application/user_manual/default/retrieval_tab.png'
			 style='max-width:85%;'/>
	</div>
	<div class='RS_A_cFA_imageTitle strong textCenter'>
		Starting screen of the retrival query pane.
	</div>
</div>

<h3>
	Query definition
</h3>

<p>
	For the definition of retrieval query please select an attribute from the list on the left by double clicking on the specific row. The editing area on the right shows now an input space for general options where you can decide if this criteria is mandatory (must) or optional (can). For optional criteria it is possible to define their importance by inserting CanPoints. The second space shows an edit area for the definition of the query. This part of the editing dialog is individual for every attribute, so there are attribute specific forms for the query definition.
</p>

<div class='RS_A_cFA_outer RS_A_cFA_outerImage' title='Starting screen of the retrival query pane.'>
	<div class='RS_A_cFA_imageOuter textCenter'>
		<img class='' src='./application/user_manual/default/query_editing.png'
			 style='max-width:85%;'/>
	</div>
	<div class='RS_A_cFA_imageTitle strong textCenter'>
		Definition of a query criteria for a <i>single line</i> attribute. 
	</div>
</div>

<h3>
	Query results
</h3>
<p>
	By clicking on the <i>Results</i> tab or the <i>Retrieve</i> button, the retrieval starts and the system brings you to the results list.
</p>

<div class='RS_A_cFA_outer RS_A_cFA_outerImage' title='Starting screen of the retrival query pane.'>
	<div class='RS_A_cFA_imageOuter textCenter'>
		<img class='' src='./application/user_manual/default/results_tab.png'
			 style='max-width:85%;'/>
	</div>
	<div class='RS_A_cFA_imageTitle strong textCenter'>
		Result list for a retrieval query.
	</div>
</div>
<p>
	By ticking the checkboxes in the <i>Mark</i> collumn you can select the results for the comparison or for further activities that could be defined by plugins.
</p>
<div class='RS_A_cFA_outer RS_A_cFA_outerImage' title='Starting screen of the retrival query pane.'>
	<div class='RS_A_cFA_imageOuter textCenter'>
		<img class='' src='./application/user_manual/default/results_tab_2.png'
			 style='max-width:85%;'/>
	</div>
	<div class='RS_A_cFA_imageTitle strong textCenter'>
		Selecting results for further actions.
	</div>
</div>

<h3>
	Comparison of results
</h3>
<p>
	The <i>Compare results</i> tab allows you to compare several objects, selected in the results list. Therefore each object were displayed in one column, so that each attribute is stated in one row.
</p>

<div class='RS_A_cFA_outer RS_A_cFA_outerImage' title='Starting screen of the retrival query pane.'>
	<div class='RS_A_cFA_imageOuter textCenter'>
		<img class='' src='./application/user_manual/default/results_comparison.png'
			 style='max-width:85%;'/>
	</div>
	<div class='RS_A_cFA_imageTitle strong textCenter'>
		Comparison of two selected objects.
	</div>
</div>
<h3>
	Load and Save Queries
</h3>
<p>
	All defined retrieval queries can be saved by clicking at the <i>Save</i> button of the query tab. The dialog that opens contains a preformated version of the query and an input field where you shoud enter a distinct name for the query to simplify identification.
</p>
<div class='RS_A_cFA_outer RS_A_cFA_outerImage' title='Starting screen of the retrival query pane.'>
	<div class='RS_A_cFA_imageOuter textCenter'>
		<img class='' src='./application/user_manual/default/query_save.png'
			 style='max-width:85%;'/>
	</div>
	<div class='RS_A_cFA_imageTitle strong textCenter'>
		Dialog for saving a retrieval query.
	</div>
</div>
<p>
	Within the load query dialog you can select a query from a list of all stored queries for that specific type. When you selected a query the dialog shows you some information on the query to verify if you selected the right query before you complete the realoading.
</p>
<div class='RS_A_cFA_outer RS_A_cFA_outerImage' title='Starting screen of the retrival query pane.'>
	<div class='RS_A_cFA_imageOuter textCenter'>
		<img class='' src='./application/user_manual/default/query_load.png'
			 style='max-width:85%;'/>
	</div>
	<div class='RS_A_cFA_imageTitle strong textCenter'>
		Dialog for loading a retrieval query.
	</div>
</div>
 
