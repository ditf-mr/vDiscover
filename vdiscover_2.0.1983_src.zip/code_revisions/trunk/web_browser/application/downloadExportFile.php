<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # check if application is started correctly
		if ( ! defined('APPLICATION_started') or ! $repository_config ) {
			header('Location: ../../../..');
			exit;
		}
	}

	try { 

		# user permission are validated either in each task or in the backend functions 

		{ # get parameter
			$fileAccessCode = sanitize_string($_POST, 'fileAccessCode', $_GET); 
			if (empty($fileAccessCode)) {
				throw new incorrectInputDataException('"fileAccessCode" is missing.');
			}
		}
		{ # get and check file extension and determine file mime type 
			$temp = explode('.', $fileAccessCode);
			$fileExtension = strtolower($temp[count($temp)-1]);
			switch($fileExtension) {
				case 'csv':
					$fileMimeType = 'application/vnd.ms-excel';
					break;
				case 'xslx':
					$fileMimeType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
					break;
				default:
					throw new Exception('Unknown file extension "'.$fileExtension.'"');
			}
		}
		{ # create filename and check if it exists
			$fileName = $repository_config['path_temp'].DIRECTORY_SEPARATOR.$fileAccessCode;
			if (!file_exists($fileName)) {
				throw new Exception('File does not exist.');
			}
		}
		{ # get filesize
			$fileSize = filesize($fileName);
		}
		{ # send header and return file content
			{ # see http://de2.php.net/manual/de/function.header.php#102175
				header("Pragma: public"); // required
				header("Expires: 0");
				header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
				header("Cache-Control: private", false); // required for certain browsers
				header("Content-Transfer-Encoding: binary");
			}
			{ # mime type
				header('Content-type: '.$fileMimeType);
			}
			{ # do not send file as attachment.
				header('Content-Disposition: attachment; filename="'.$fileAccessCode.'"');
			}
			{ # file must be downloaded and not opend with an application
				# header("Content-Type: application/force-download");
			}
			{ # file size
				header("Content-Length: ".$fileSize);
			}
			{ # file itself
				readfile($fileName);
			}
		}
	} catch (Exception $e) {
		header('HTTP/1.1 500 Internal Server Error');
		header('Content-type: text/text');
		echo '<textarea>' 
				.
			json_encode(
				array(
					'type'		=> 'Exception',
					'message'	=> $e->getMessage(),
					'code'		=> $e->getCode(),
					'file'		=> $e->getFile(),
					'line'		=> $e->getLine(),
					'trace'		=> $e->getTraceAsString()
				)
				 
			).'</textarea>';
	} # end-of-try ... catch
?>