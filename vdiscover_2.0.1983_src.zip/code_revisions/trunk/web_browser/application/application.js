/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// enhance older browsers with a necessary method
if(typeof Object == 'undefined') Object = {};
// see https://developer.mozilla.org/en/JavaScript/Reference/Global_Objects/Object/keys
if(!Object.keys) Object.keys = function(o){
	// return the keys of an object as an array
	//if (o !== Object(o)) throw new TypeError('Object.keys called on non-object');
	var ret=[],p;
	for(p in o) if(Object.prototype.hasOwnProperty.call(o,p)) ret.push(p);
	return ret;
} // end if

dojo.safeMixin( application, {

	'webClientHasLocalStorage' : function () { // see http://diveintohtml5.info/storage.html
		try {
			return 'localStorage' in window && window['localStorage'] !== null;
		} catch (e) {
			return false;
		} // end try .. catch
	} // end of method webClientHasLocalStorage
	,

	'showErrorMessage' : function ( message ) {
		dijit.byId('application.Dialog.error.message').attr('content', message);
		dijit.byId('application.Dialog.error').show();
	} // end-of-method showErrorMessage
	,

	'showMessage' : function ( title, message ) {
		var d = dijit.byId('application.Dialog.message');
		d.attr('title', title);
		dijit.byId('application.Dialog.message.message').attr('content', message);
		d.show();
	} // end-of-method showErrorMessage
	,

	'AJAX_query' : function ( type,		// type may be OT, RT, O, R
							message,
							onSuccess,
							sync,
                            scope ){
		switch (type) {
			case 'OT':
				application.OT_AJAX_query(message, onSuccess, sync, scope);
				break;
			case 'RT':
				application.RT_AJAX_query(message, onSuccess, sync, scope);
				break;
			case 'O':
				application.O_AJAX_query(message, onSuccess, sync, scope);
				break;
			default:
				application.General_AJAX_query(message, onSuccess, sync, scope);
				break;
		}
	} // end-of-function AJAX_query
	,

	General_AJAX_query : function (message, onSuccess, sync, scope) {
		application.AJAX_query_aux('JSON_General', message, onSuccess, sync, scope);
	} // end-of-function General_AJAX_query
	,

	OT_AJAX_query : function (message, onSuccess, sync, scope) {
		application.AJAX_query_aux('JSON_ObjectType', message, onSuccess, sync, scope);
	} // end-of-function OT_AJAX_query
	,

	RT_AJAX_query : function (message, onSuccess, sync, scope) {
		application.AJAX_query_aux('JSON_RelationType', message, onSuccess, sync, scope);
	} // end-of-function RT_AJAX_query
	,

	A_AJAX_query : function (message, onSuccess, sync, scope) {
		application.AJAX_query_aux('JSON_Attribute', message, onSuccess, sync, scope);
	} // end-of-function A_AJAX_query
	,

	O_AJAX_query : function (message, onSuccess, sync, scope) {
		application.AJAX_query_aux('JSON_Object', message, onSuccess, sync, scope);
	} // end-of-function O_AJAX_query
	,
	'AJAX_errorMessage' : function (error,ioargs){
		// this method outputs errors that occur in the context of an AJAX client-server communication

		var errorMessage = ''
			+'<h2>Client-Server communication error</h2>'

			+'<h3>Query details</h3>'

			+'<p>The URL:</p>'
			+'<pre class="small">'+ioargs.url+'</pre>'

			+'<p>handleAs:</p>'
			+'<pre class="small">'+ioargs.args.handleAs+'</pre>'

			+'<p>sync:</p>'
			+'<pre class="small">'+ioargs.args.sync.toString()+'</pre>'

			+'<p>timeout:</p>'
			+'<pre class="small">'+ioargs.args.timeout+'</pre>'

		try {
			dojo.require("dojox.html.entities");
			errorMessage+= ''
				+'<p>The content:</p>'
				+'<pre class="small">'+dojox.html.entities.encode(dojo.toJson(ioargs.args.content,true))+'</pre>';

		} catch(e) {
			console.log(ioargs.args.content);
			errorMessage+='<p>Could not convert the query content to JSON.</p>'
							+'<p>The conversion error message:'
							+'<pre class="small">'+e+'</pre>'
							+'<p>The query content:</p>'
							+'<pre class="small">'+ioargs.args.content+'</pre>';
		} // end try .. catch

		/*if(ioargs.xhr) {*/
			errorMessage += '<h3>The server\'s response</h3>'

							+'<p>HTTP Status:</p>'
							+'<pre class="small">'+ioargs.xhr.status+' ('+ioargs.xhr.statusText+')</pre>'

							+'<p>The response content:</p>'
							+'<div class="small code">'+dojox.html.entities.encode(ioargs.xhr.response.replace(/^<br \/>\n/m, ''),true)+'</div>';

			/*
			try {
				dojo.require("dojox.html.entities");
				errorMessage+='<pre class="small">'+dojox.html.entities.encode(dojo.toJson(error,true))+'</pre>';
			} catch(e) {
				console.log(ioargs);
				errorMessage+='<p>Could not convert the returned error to JSON.</p>'
								+'<p>The conversion error message:</p>'
								+'<pre class="small">'+e+'</pre>'
								+'<p>The returned error:</p>'
								+'<pre class="small">'+error+'</pre>';
			} // end try ... catch
			*/
		/*} else {
			errorMessage += ''
				+'<h3>Response</h3>'
				+'<p>The error method function received no response.</p>';
		} // end if
		*/
		errorMessage += '<h3>The errror message</h3>'
						+'<div class="small code">'+dojox.html.entities.encode(dojo.toJson(error,true))+'</div>';
		
		// show the error message
		application.showErrorMessage(errorMessage);

		console.error(""
				+"Could not execute the client-server communication correctly.\n"
				+"Response from the server:\n\n"
				+ioargs.xhr.response.replace(/^<br \/>\n/m, '')
				+"\n\n"
				+"Error message:\n\n"
				+dojo.toJson(error,true)
			);
		// console.error(error);
	} // end of method AJAX_errorMessage
	,
	'AJAX_query_aux' : function (	script,		// ?v=script
								message,	// object
								onSuccess,	// function to be executed if everything went well
								sync,		// true, if processing waits for query result
								scope		// scope defines 'this.scope' in the onSuccess function
							) {

		if (sync == null) sync = false;
		if (scope == null) scope = this;

		// send the changes in message to the server and save them, there
		dojo.xhrPost({
			'content'	: 	message,
			'error'		: 	application.AJAX_errorMessage, // function
			'handleAs'	: 'json',
			'load'		: 	onSuccess,
			//preventCache:true,
			//failOk: true,
			'url'		:	'?v=' + script,
			'sync'		: 	sync,
			'scope'		:	scope,
			'timeout'	: 	application.configuration.global.AJAX_default_timeout
		});
	} // end-of-method AJAX_query_aux
	,
	printPreviewPane : {
		show : function () {
			dojo.style('masterBc','display','none');
			dojo.style('application_printPreviewPane','display','block');
			dijit.byId('application_printPreviewPane').resize();
		} // end of method showPrintPreviewPane
		,
		hide : function () {
			dojo.style('application_printPreviewPane','display','none');
			dojo.style('masterBc','display','block');
		} // end of method
		,
		documents : []
		,
		addDocument : function (document,header,footer) {
			var doc = new application.widgets.printableDocument({
				'header'	: header,
				'document'	: document,
				'footer'	: footer
			});
			doc.placeAt('application_printPreviewPane_documentPane');
			this.documents.push(doc);
		} // end of method addDocument
		,
		emptyPrintQueue : function () {
			for (var i in this.documents) {
					try {
						if (this.documents[i]) {
							var d = this.documents[i];
							d.destroyRecursive(false); // eliminate DOM, as well
						} // end if
					} catch (e) {
						// do nothing
					} // end try .. catch
					delete this.documents[i];
			}; // end for ... in

			dojo.empty('application_printPreviewPane_documentPane');
		} // end of method emptyPrintQueue

	} // end of frame printPreviewPane
	,
	sendToPrintQueuePane : {
		pane : null // domNode
		,
		fadeInAnimation : null
		,
		fadeOutAnimation : null
		,
		fadeIn_duration : 1000 // msec
		,
		fadeOut_duration : 500 // msec
		,
		wait_duration : 500 // msec
		,
		animating : false // boolean
		,
		fadeIn : function () {
			// some initialisations
			if(!this.pane) this.pane=dojo.byId('application_sendingToPrintQueuePane');
			if(!this.fadeInAnimation) this.fadeInAnimation=dojo.fadeIn({
				duration : this.fadeIn_duration,
				node: this.pane,
				animatedPane: this,
				beforeBegin : function () {
					this.animatedPane.animating = true;
					dojo.style(this.node, "opacity", 0);
					dojo.style(this.node, "display", "block");
				} // end of method onBegin
				,
				onEnd : function () {
					this.animatedPane.animating = false;
					this.animatedPane.startNextAnimation();
				} // end of method onEnd
			});

			this.fadeInAnimation.play();
		} // end of method fadeIn
		,
		fadeOut : function () {
			// some initialisations
			if(!this.fadeOutAnimation) this.fadeOutAnimation=dojo.fadeOut({
				duration : this.fadeOut_duration,
				node: this.pane,
				animatedPane: this,
				beforeBegin : function () {
					this.animatedPane.animating = true;
					dojo.style(this.node, "opacity", 1);
					dojo.style(this.node, "display", "block");
				} // end of method onBegin
				,
				onEnd : function () {
					dojo.style(this.node, "display", "none");
					this.animatedPane.animating = false;
					this.animatedPane.startNextAnimation();
				} // end of method onBegin
			});

			application.sendToPrintQueuePane.fadeOutAnimation.play();
		} // end of method fadeOut
		,
		waitTimeOut : null
		,
		wait : function() {
			this.animating = true;

			this.waitTimeOut = setTimeout(dojo.hitch(this,function() {
				this.animating = false;
				this.startNextAnimation();
			}), this.wait_duration);

		} // end of method wait
		,
		queue : []
		,
		addToQueue : function (f) {
			this.queue.push(f);
			if(!this.animating) this.startNextAnimation();
		} // end of method addToQueue
		,
		startNextAnimation : function () {
			if(this.queue.length) {
				dojo.hitch(application.sendToPrintQueuePane, this.queue.shift())();
			} // end if there are queued animations
		} // end of method startNextAnimation
		,
		show : function() {
			this.addToQueue(this.fadeIn);
			this.addToQueue(this.wait);
		} // end of method show
		,
		hide : function () {
			this.addToQueue(this.fadeOut);
		} // end of method hide
	} // end of slot declaration sendToPrintQueuePane
	,
	'generalOptions' : {
		'logout' : function () {
			dijit.byId('application.Dialogue.logout').show();
		} // end of method logout
		,
		'aboutMe' : function () {
			alert('Facts about me');
		} // end of method aboutMe
		,
		'userManualPane_widget' : null // dijit.layout.BorderContainer
		,
		'manual_title_widget'	: null // dijit.layout.ContentPane
		,
		'manual_widget'	: null // dijit.layout.ContentPane
		,
		'userManual' : function () {

			if(!this.userManualPane_widget) {
				this.userManualPane_widget = new dijit.layout.BorderContainer({
					'region' 	: 'right',
					'splitter' 	: true,
					'gutters' 	: false,
					'class' 	: 'dijitContentPane dijitBorderContainer-child dijitBorderContainer-dijitContentPane',
					'style' 	: 'width:30em;padding:0;margin:0;'
				});

				this.manual_title_widget = new dijit.layout.ContentPane({
						'region' 	: 'top',
						'content' 	: '<h1>'+T('application.js_UserManual_TIT','User Manual')+'<img src="./third_party_libraries/open-icon-library-standard-0.10/icons/png/32x32/others/books.png" style="float:right;"></h1>',
						// 'class' : 'small',
						'title' 	: T('application.js_HideMan_TXT','Double-click here to hide this manual.'),
						'style' 	: 'margin-bottom:.5ex;padding-left:.5ex;padding-right:.5ex;'
					});

				this.userManualPane_widget.addChild(this.manual_title_widget);

				dojo.connect(this.manual_title_widget, 'onDblClick', this, function(e){
					dojo.stopEvent(e);
					application.generalOptions.userManual();
				});

				this.manual_widget= new dijit.layout.ContentPane({
						'region' : 'center',
						'href' : '?v=manual',
						'preventCache' : true,
						// 'class' : 'small',
						'style' : 'padding-left:.5ex;padding-right:.5ex;'
					});

				dojo.connect(this.manual_widget, 'onDblClick', this.manual_widget, function(e){
					dojo.stopEvent(e);
					this.refresh();
				});

				this.userManualPane_widget.addChild(this.manual_widget);

			} // end if

			var appWidget = dijit.byId('masterBc');

			if(!this.userManualPane_widget.isBeingDisplayed) {

				appWidget.addChild(this.userManualPane_widget);
				this.userManualPane_widget.isBeingDisplayed = true;

			} else {
				appWidget.removeChild(this.userManualPane_widget);
				this.userManualPane_widget.isBeingDisplayed = false;
			} // end if


		} // end of method userManual
		,
		'requestFullScreen' : function () {

			// see http://hacks.mozilla.org/2012/01/using-the-fullscreen-api-in-web-browsers/

			var docElm = document.documentElement;
			if (docElm.requestFullscreen) {
				docElm.requestFullscreen();
			}
			else if (docElm.mozRequestFullScreen) {
				docElm.mozRequestFullScreen();
			}
			else if (docElm.webkitRequestFullScreen) {
				docElm.webkitRequestFullScreen();
			}

			// switch the menu item options
			dojo.style(dijit.byId('navMenu.switchToFullScreen').domNode,'display','none');
			dojo.style(dijit.byId('navMenu.cancelFullScreen').domNode,'display','block');

			var mainRightClickMenu = dijit.byId('mainRightClickMenu');
			mainRightClickMenu.removeChild(dijit.byId('mainRightClickMenu.requestFullScreen'));
			mainRightClickMenu.addChild(dijit.byId('mainRightClickMenu.cancelFullScreen'));

			var pPPaneRightClickMenu = dijit.byId('pPPaneRightClickMenu');
			pPPaneRightClickMenu.removeChild(dijit.byId('pPPaneRightClickMenu.requestFullScreen'));
			pPPaneRightClickMenu.addChild(dijit.byId('pPPaneRightClickMenu.cancelFullScreen'));

		} // end of method requestFullScreen
		,
		'cancelFullScreen' : function () {

			// see http://hacks.mozilla.org/2012/01/using-the-fullscreen-api-in-web-browsers/

			if (document.exitFullscreen) {
				document.exitFullscreen();
			}
			else if (document.mozCancelFullScreen) {
				document.mozCancelFullScreen();
			}
			else if (document.webkitCancelFullScreen) {
				document.webkitCancelFullScreen();
			}

			// switch the menu item options
			dojo.style(dijit.byId('navMenu.switchToFullScreen').domNode,'display','block');
			dojo.style(dijit.byId('navMenu.cancelFullScreen').domNode,'display','none');

			var mainRightClickMenu = dijit.byId('mainRightClickMenu');
			mainRightClickMenu.removeChild(dijit.byId('mainRightClickMenu.cancelFullScreen'));
			mainRightClickMenu.addChild(dijit.byId('mainRightClickMenu.requestFullScreen'));

			var pPPaneRightClickMenu = dijit.byId('pPPaneRightClickMenu');
			pPPaneRightClickMenu.removeChild(dijit.byId('pPPaneRightClickMenu.cancelFullScreen'));
			pPPaneRightClickMenu.addChild(dijit.byId('pPPaneRightClickMenu.requestFullScreen'));

		} // end of method cancelFullScreen
		,
		'hideFullScreenOptionsIfNecessary' : function () {
			var docElm = document.documentElement,
				isFSCapable =(docElm.requestFullscreen || docElm.mozRequestFullScreen || docElm.webkitRequestFullScreen)?true:false;
			if (!isFSCapable) {
				dojo.style(dijit.byId('navMenu.switchToFullScreen').domNode,'display','none');
				dojo.style(dijit.byId('navMenu.cancelFullScreen').domNode,'display','none');

				dojo.style(dijit.byId('mainRightClickMenu.requestFullScreen').domNode,'display','none');
				dojo.style(dijit.byId('mainRightClickMenu.cancelFullScreen').domNode,'display','none');

			var mainRightClickMenu = dijit.byId('mainRightClickMenu');
			mainRightClickMenu.removeChild(dijit.byId('mainRightClickMenu.requestFullScreen'));
			mainRightClickMenu.removeChild(dijit.byId('mainRightClickMenu.cancelFullScreen'));

			var pPPaneRightClickMenu = dijit.byId('pPPaneRightClickMenu');
			pPPaneRightClickMenu.removeChild(dijit.byId('pPPaneRightClickMenu.requestFullScreen'));
			pPPaneRightClickMenu.removeChild(dijit.byId('pPPaneRightClickMenu.cancelFullScreen'));

			}// end if
		} // end of method hideFullScreenOptionsIfNecessary
		,
		'fullScreen_setUp' : function () {
			// full screen mode display tweaks
			application.generalOptions.hideFullScreenOptionsIfNecessary();
			var mainRightClickMenu = dijit.byId('mainRightClickMenu');
			mainRightClickMenu.removeChild(dijit.byId('mainRightClickMenu.cancelFullScreen'));
			var pPPaneRightClickMenu = dijit.byId('pPPaneRightClickMenu');
			pPPaneRightClickMenu.removeChild(dijit.byId('pPPaneRightClickMenu.cancelFullScreen'));
		} // end of method fullScreen_setUp
	} // end of slot generalOptions
}); // end-of-application object extension

dojo.addOnLoad(function(){
	application.generalOptions.fullScreen_setUp();
});

