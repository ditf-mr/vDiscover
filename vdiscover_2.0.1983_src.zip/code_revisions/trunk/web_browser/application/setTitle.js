/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.addOnLoad(function(){ // set the title pane
	var titlePane = '?v=application_title'; // to be loaded via http
	if (application.configuration.global['appTitle_HTTP_path']) { titlePane = application.configuration.global['appTitle_HTTP_path']; }
	dijit.byId('app_titlePane').attr('href', titlePane);
});
