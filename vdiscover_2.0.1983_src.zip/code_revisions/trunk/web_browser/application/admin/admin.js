/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

application.admin = {
	// some variables
	navigationStore : null,
	navigationModel : null,
	navigationTree : null,
	currentNavigationItem : null,
	
	adminPane_rightClickMenu : {
		options : [],
		addOption : function (title, onClickCallThisJsFunction, iconCSSClass, enableOrDisableFunc) {
			this.options.push({
				'label': title,
				'iconClass': iconCSSClass,
				'onClick': onClickCallThisJsFunction,
				'enableOrDisableFunc': enableOrDisableFunc
			});
		} // end of method addOption
	} // end of rightClickMenu option slot
	,

	initialise_adminPane : function () {
		with (application.admin) {
			try {
				navigationStore = new dojo.data.ItemFileReadStore({
						url: '?v=JSON_General&task=get_NavigationTree4Admin',
						urlPreventCache : true,
						clearOnClose : true,
						failOk : true
					});
			} catch(e) {
				application.showErrorMessage(dojo.fromJson (e));
			} // end-of try ... catch

			navigationModel = new dijit.tree.ForestStoreModel({
					store: navigationStore,
					query: {'topLevelItem': true},
					childrenAttrs : ['children']
				}
			);
			
			if (navigationTree) navigationTree.destroyRecursive();
			dijit.byId('application.adminPane').destroyDescendants(false);
			dojo.empty('application.adminPane');
			
			dijit.byId('application.adminPane').attr('content', '<div id="OT_admin_tree"></div>');
			
			try {
				navigationTree = new dijit.Tree ({
						model: navigationModel,
						openOnClick: false,
						showRoot: false,
						persist: true,
						getIconClass : function(item, isOpened) {
							// get item type
							var type='', has_OTChildren=false;
							try{ 
								type=(navigationStore.hasAttribute(item,'type')?navigationStore.getValue(item,'type'):'');
							} catch(e){}
							if(type=='OT') try{ 
								has_OTChildren=(navigationStore.hasAttribute(item,'has_OTChildren') && navigationStore.getValue(item,'has_OTChildren'));
							} catch(e){}
							var iconClass='';
							switch(type){
								case 'navigation_node_withoutRightClickFunctionality':
								case 'navigation_node':
									iconClass='RS_icon_navigation_node';
									break;
								case 'RT':
									iconClass='RS_icon_RT';
									break;
								case 'OT':
									iconClass=(has_OTChildren?'RS_icon_OT_with_children':'RS_icon_OT');//((isOpened)?'dijitFolderOpened':'dijitFolderClosed');
									break;
								default:
									iconClass='';
							} // end switch
							
							return iconClass;
						},
						getTooltip : function(item){return((navigationStore.getValue(item,'type')=='OT')? T('admin.js/ClickToAccMnuOpt_TTP','Click with the right mouse button on this item to access the menu options.') : '' );}
					}, 
					'OT_admin_tree'
				);
			} catch(e) {
				console.log('Admin pane: tree error.', e);
			} // end-of try...catch

			// create the right click menu
			var rightClickMenu = new dijit.Menu({});
			
			dojo.forEach(adminPane_rightClickMenu.options, function (o,i) {
				rightClickMenu.addChild(new dijit.MenuItem(o));
			}); // end forEach menu option
			
			// connect the menu to the tree
			rightClickMenu.bindDomNode(navigationTree.domNode);
			
			// before opening, prepare the right click menu
			dojo.connect(rightClickMenu, '_openMyself', navigationTree, function(e) {
				// This connection with dojo.connect implies that the following code will be executed before the right click menu will open.
				// The following code is executed in the context of navigationTree.
		
				currentNavigationItem = dijit.getEnclosingWidget(e.target).item, // this corresponds to currentTreeNode.item
					mIType = (	currentNavigationItem	?	navigationStore.getValue(currentNavigationItem,'type')
										:	T('admin.js/NoNavItm_TXT','no navigation item') ),
					menuItemWidgets = rightClickMenu.getChildren();
				
				dojo.forEach(menuItemWidgets,function(menuItemWidget,index){
					var disable_menuItem = application.admin.adminPane_rightClickMenu.options[index].enableOrDisableFunc(mIType);
					menuItemWidget.attr('disabled', disable_menuItem);
				});			

			});
		} // end with application.admin
	} // end-of-method initialise_adminPane
} // end-of-section admin
