<?php if (!defined('APPLICATION_started')) {header('Location: .');exit;} 
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

global /*$r, */$backend;

if(!$backend->isAdmin()) return;

$r->register_JavaScriptFile('application/admin/admin.js');

// register components for admins
cApplicationRegistry::registerModuleComponents(PLUGIN_REGISTRY_parseAllSubDirs, __DIR__ );

?>