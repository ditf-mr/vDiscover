/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare('application.widgets.renameOTDialog',[common.widgets.fixedSizeDialog],{
	
	// these slots have values need to be passed when creating the widget
	'name'			: null, // mandantory STRING --- the object type name
	'OT_UUID'		: null, // mandantory STRING --- the object type's UUID
	
	
	// the following slots form internal variables / containers
	
	
	
	// settings of the parent class common.widgets.fixedSizeDialog
	'innerWidth'	: 400
	,
	'innerHeight'	: 100
	,
	
	
	
	// widget life cycle
	'constructor' : function () {
	
		// some initialisations
		this.name 			= '';
		this.OT_UUID 		= '';
	
		this.widgets 		= {};
		
	} // end of method constructor
	,
	'postMixInProperties' : function () {
		this.inherited(arguments);
	
		this.title = T(	'renameOT.js/ChangeNameOfOT_TIT',
						'Change the Name of the Object Type «$[0]»',
						[this.name]);
	
	} // end of method postMixInProperties
	,
	'buildRendering' : function () {
		this.inherited(arguments);

		this.widgets.form = new dijit.form.Form({
			'onSubmit'	: function () {
				return false;
			}, // end of method onSubmit
		}).placeAt(this.containerNode);
	
		dojo.create('P',{
			'innerHTML' : T( 	'renameOT.js/PleaseChNameOfOT_TXT',
								'Please enter the new name of the object type, here:' ),
		}, this.widgets.form.containerNode);
	
		this.widgets.newNameIB = new dijit.form.ValidationTextBox ({
			'regExp'			: ".{2,}",
			'selectOnClick'		: true,
			'value'				: this.name,
			'required'			: true,
			'invalidMessage'	: T(	'renameOT.js/OTNameIsInvalidMSG_TXT',
										"The type name should have a least 2 chars."),
			'class'				: "fullWidth",
			'tooltipPosition'	: "below",
			'trim'				: true, 
			'intermediateChanges':true,
			'maxlength'			: 256,
		}).placeAt(this.widgets.form.containerNode);
	
		dojo.create('P',{
			'innerHTML' : '&nbsp;',
		}, this.widgets.form.containerNode);
	
		var bRow = dojo.create('DIV',{
			'innerHTML' : '',
			'style' : 'position:absolute;bottom:0;right:0;padding:.25em;',
		}, this.widgets.form.containerNode);
	
		this.widgets.OkButton = new dijit.form.Button({
			'label' 	: '<img src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/dialog-ok-apply-4.png"/> '
				+T('BTN_OK','OK'),
			'type'		: 'submit',
			'disabled'	: 'true',
			// 'style'		: 'float:right;',
		}).placeAt(bRow);
		
		this.widgets.CancelButton = new dijit.form.Button({
			'label' 	: '<img width="12" src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/dialog-cancel-4.png"/> '
				+T('BTN_Cancel','Cancel'),
			// 'type'		: 'button',
			// 'style'		: 'float:right;',
		}).placeAt(bRow);
		
	} // end of method buildRendering
	,
	'startup' : function () {
		this.inherited(arguments);
	
		// it's time now for the connects ...
		this.connect( this.widgets.newNameIB, 	'onChange', '_newNameChanged'	);
		// this.connect( this.widgets.OkButton,	'onClick',	'_execute'			);
		this.connect( this.widgets.form,		'onSubmit', '_execute'			);
		this.connect( this.widgets.CancelButton,'onClick',  'hide'				);
		
		// set the focus to the validation text box
		this.widgets.newNameIB.focus();
		
		// enable/ disable the Ok button
		this._newNameChanged();
	
	} // end of method startup
	,
	'destroy' : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		
		for (var i in this.widgets) {
			if (this.widgets[i].destroyRecursive) this.widgets[i].destroyRecursive(false);
			delete this.widgets[i];
		} // end for .. in
		
		// this.inherited(arguments);
	} // end of method destroy
	,
	
	// internal methods
	'_newNameChanged' : function () {
	
		// enable or disable the OB Button
		this.widgets.OkButton.attr('disabled', !this.widgets.newNameIB.isValid() );
		
	} // end of method _newNameChanged
	,
	'_execute' : function (e) {
		this.onExecute( this.OT_UUID, this.widgets.newNameIB.attr('value') );
		this.hide();
	} // end of method _execute
	,
	
	
	
	// events
	'onExecute' : function (OT_UUID, newName) {},
	
});	
	
	
	

// extend the admin functionality
application.admin.renameOT = { // Dialogue for changing the name of an object type
	'dialogWidget' 	: null
	,
	'dialogConnects' : null
	,
	'OT_UUID'		: null
	,
	'OT_name'		: null
	,
	'showDialog' : function() {
	
		if (this.dialogWidget) this.deleteDialog(); // destroy a potentially existing dialog widget
		
		// get the necessary information
		this.OT_name = application.admin.navigationStore.getValue(application.admin.currentNavigationItem,'name');
		this.OT_UUID = application.admin.navigationStore.getValue(application.admin.currentNavigationItem,'UUID');
		
		this.dialogWidget = new application.widgets.renameOTDialog({
			'OT_UUID'	: this.OT_UUID,
			'name'		: this.OT_name,
		});
		
		// carry out the necessary connects
		this.dialogConnects = [
			dojo.connect( this.dialogWidget, 'onExecute', this, '_onExecute' 	),
		];
		
		this.dialogWidget.startup();
		this.dialogWidget.show();
				
	} // end-of-method showDialog
	,
	'closeDialog' : function() {
	
		this.dialogWidget.hide();
		
	} // end of method closeDialog
	,
	'_onExecute' : function( OT_UUID, newName ) {

		loader.show();
	
		// save the new OT name to the server
		application.OT_AJAX_query(
			{
				"task"	: 'set_OT_name',
				"UUID"	: OT_UUID,
				"name"	: newName,
			}, 
			function(response,details) {
				// refresh the admin pane
				application.admin.initialise_adminPane();
			} // end of onSuccess function
			,
			true /*synchronously*/
		);
		
		loader.hide();
		
	} // end-of-method execute
	,
	'deleteDialog' : function () {
	
		dojo.forEach( this.dialogConnects, function (c) {
			dojo.disconnect(c);
		}, this);
		
		this.dialogWidget.destroyRecursive(false);
		this.dialogWidget.destroy();
		this.dialogWidget=null;
		
		this.OT_UUID = null;
		this.OT_name = null;
			
	} // end of method deleteDialog
	,
	
}; // end extension change_OTName of the admin functionality

// register the right click menu option
application.admin.adminPane_rightClickMenu.addOption(
	T('renameOT.js/RenOT_MNU','<strong>Rename</strong> object type'), 
	function () {application.admin.renameOT.showDialog();}, 
	'rsIcon_rename', 
	function(item_type) { 
		return ( (item_type=='OT')?false:true); 
	}
);
