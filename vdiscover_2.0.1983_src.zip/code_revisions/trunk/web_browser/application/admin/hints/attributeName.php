<!--
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
-->

<h4>Hints for the attribute name</h4>

<p>The attribute name may contain special unicode chars and HTML tags.</p>

<h5>HTML Tags</h5>

<p>Here are some suggestions for using HTML tags:</p>
<ul>
	<li>
		<code>&lt;variable&gt;</code> &mdash; variable formatting, 
			e.g. <variable>Force</variable> 
			or <variable>y</variable>
			<br/>
	</li>
	<li>
		<code>&lt;sub&gt;</code> &mdash; subscript,
		e.g. normal<sub>subscript</sub>
	</li>
	<li>
		<code>&lt;sup&gt;</code> &mdash; super script,
		e.g. normal<sup>superscript</sup>
	</li>
</ul>

<p><strong>Example</strong></p>
<pre>Max Tear Force
&lt;variable&gt;F&lt;sub&gt;max&lt;/sub&gt;&lt;/variable&gt;
</pre>
<p>
	will be displayed as 
	<code>Max Tear Force<variable>F<sub>max</sub></variable></code>
</p>

<!--<h5>Unicode chars</h5>-->

