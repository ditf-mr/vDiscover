<!--
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
-->
<div dojoType="dijit.TitlePane" title="Regular expression tester" open="true">
	<p>Here, you can enter a regular expression and test whether it matches a given subject:</p>
	<table class="fullWidth">
		<tbody>
			<tr>
				<td>Regular expression:</td>
				<td><input class="regexPatternTest_regex" type="text" value=".*" dojoType="dijit.form.TextBox" trim="true" style="width:100%;" 
					onBlur="dijit.byNode(dojo.query('.regexPatternTest_subject')[0]).value=this.value;dijit.byNode(dojo.query('.regexPatternTest_subject')[0]).regExp=this.value;"
					/><br />
				</td>
			</tr>
			<tr>
				<td>Subject:</td>
				<td><input class="regexPatternTest_subject" type="text"  style="width:100%;"
					regExp="[\w]+" promptMessage="Please enter here a subject to test the regex." intermediateChanges="true"
					required="false" invalidMessage="The entered subject does not match the specified regular expression."
				value="" dojoType="dijit.form.ValidationTextBox" trim="false" /><br/>
					<p>The test is carried out when the focus leaves the text subject input box.</p>
				</td>
			</tr>
		</tbody>
	</table>
</div>

<h4>A brief introduction on how to build regular expressions</h4>

<p>Regular expressions are patterns of segments and operators that describe a set of valid strings. 
	Regular expressions are used, here, to test if user input is valid.</p>
<p>Please note that it is &ndash; in contrast to normal regular expressions in JavaScript &ndash; not necessary 
	to start the regular expression with a <code>^</code> for the line beginning and to finish it with a <code>$</code> for the line end. 
	There is further no need for slashes <code>/</code> at the regex start or end.</p>
<p>&nbsp;</p>
<div dojoType="dijit.TitlePane" title="Segments and Operators in regular expressions" open="false">
	<table class="fullWidth listWithAlternatingRowColour">
		<thead>
			<tr>
				<th class="textCenter">
					Segment/ Operator
				</th>
				<th>
					Meaning
				</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td class="textCenter">
					A string of characters, e.g. <code>Händel</code>
				</td>
				<td>
					match exactly the given string <code>Händel</code>
				</td>
			</tr>
			<tr>
				<td class="textCenter">
					<pre>.</pre>
				</td>
				<td>
					Match any single character.<br/>
					E.g. <code>a.c</code> matches <code>abc</code>, <code>azc</code> and <code>acc</code> &ndash; but not <code>acb</code>.
				</td>
			</tr>
			<tr>
				<td class="textCenter">
					<pre>[&nbsp;&nbsp;]</pre>
				</td>
				<td>
					A bracket expression. Matches a single character that is contained within the brackets.<br/>
					E.g. <code>[abc]</code> matches <code>a</code> or <code>b</code> or <code>c</code> &ndash; but not <code>d</code>.
				</td>
			</tr>
			<tr>
				<td class="textCenter">
					<pre>[^&nbsp;&nbsp;]</pre>
				</td>
				<td>
					An excluding bracket expression. Matches any single character that is <strong>not</strong> contained within the brackets.<br/>
					E.g. <code>[^abc]</code> matches <code>z</code> or <code>y</code> or <code>f</code> &ndash; but not <code>a</code>.
				</td>
			</tr>
			<tr>
				<td class="textCenter">
					<pre>|</pre>
				</td>
				<td>
					The choice operator<br/>
					E.g. <code>delightful|wonderful</code> matches <code>delightful</code> or <code>wonderful</code>.
				</td>
			</tr>
			<tr>
				<td class="textCenter">
					<pre>(&nbsp;&nbsp;)</pre>
				</td>
				<td>
					Subexpression<br/>
					E.g. <code>(delight|wonder)ful</code> matches  <code>delightful</code> or <code>wonderful</code> but neither  <code>jollyful</code> nor <code>delighted</code>.
				</td>
			</tr>
			<tr>
				<td class="textCenter">
					<pre>{&nbsp;&nbsp;,&nbsp;&nbsp;}</pre>
				</td>
				<td>
					Quantifier<br/>
					The optional quantifier behind a char, bracket expression or subexpression tells how often the preceding element is allowed to occur.
					E.g. <code>ab{0,2}c</code> matches  <code>ac</code> or <code>abc</code> but neither  <code>abx</code> nor <code>abbbc</code>. 
					The first number denotes the minimum number of repeatings, the last number the maximum number of repeatings. Leaving the first number empty means e.g. zero to .. repeatings, 
					leaving the last number blank means .. to infinite repeatings.<br />
					To match an exact number of repeatings, you may use as well e.g. 
					<code>a{3}</code> to match <code>aaa</code>, but neiter <code>aa</code> nor <code>aaaa</code>.<br />
					There are some abbreviations: <code>{0,1}</code> may be abbreviated as <code>?</code>,  
					<code>{0,}</code> as <code>*</code> (any number permitted),  and finally <code>{1,*}</code> 
					may be abbreviated as <code>+</code> (one or more times permitted).
				</td>
			</tr>
			<tr>
				<td class="textCenter">
					<pre>\</pre>
				</td>
				<td>
					Escape character<br/>
					The backslash permits to treat every meta character described above as literal character.
					E.g. <code>\[.\]</code> matches any single character in brackets, e.g. <code>[a]</code>. 
					Or <code>[\*\+/]</code> matches <code>*</code> or <code>/</code>, but not <code>[1]</code>.
				</td>
			</tr>
			<tr>
				<td class="textCenter">
					<pre>\b</pre>
				</td>
				<td>
					Word boundary<br/>
					Matches the beginning or end of a word. Hence <code>\bton\b</code> will match <code>ton</code> or <code>ton,</code>, but not <code>Pinkerton.</code>.
				</td>
			</tr>
			<tr>
				<td class="textCenter">
					<pre>\B</pre>
				</td>
				<td>
					Not word boundary<br/>
					Matches any position with a word. Hence <code>\Bton</code> will match <code>Pinkterton</code> or <code>Taunton</code>, but not <code>ton</code>.
				</td>
			</tr>
		</tbody>
	</table>
</div>
<p>&nbsp;</p>
<div dojoType="dijit.TitlePane" title="Permitted character classes within bracket expressions" open="false">
	<table class="fullWidth listWithAlternatingRowColour">
		<thead>
			<tr>
				<th class="textCenter">
					Character Class
				</th>
				<th>
					Meaning
				</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td class="textCenter">
					<pre>[[:alnum:]]</pre>
					or
					<pre>[A-Za-z0-9]</pre>
				</td>
				<td>
					Alphanumeric characters
				</td>
			</tr>
			<tr>
				<td class="textCenter">
					<pre>[[:word:]]</pre>
					or
					<pre>[[:alnum:]_]</pre>
					or
					<pre>[A-Za-z0-9_]</pre>
					or
					<pre>[\w]</pre>
				</td>
				<td>
					Alphanumeric characters plus <code>_</code>
				</td>
			</tr>
			<tr>
				<td class="textCenter">
					<pre>[\W]</pre>
					or
					<pre>[^A-Za-z0-9_]</pre>
					or
					<pre>[^\w]</pre>
				</td>
				<td>
					Non-word characters
				</td>
			</tr>
			<tr>
				<td class="textCenter">
					<pre>[[:alpha:]]</pre>
					or
					<pre>[A-Za-z]</pre>
				</td>
				<td>
					Alphabetic characters
				</td>
			</tr>
			<tr>
				<td class="textCenter">
					<pre>[[:blank:]]</pre>
					or
					<pre>[ \t]</pre>
				</td>
				<td>
					<code>Space or tab</code>
				</td>
			</tr>
			<tr>
				<td class="textCenter">
					<pre>[[:cntrl:]]</pre>
					or
					<pre>[\x00-\x1F\x7F]</pre>
				</td>
				<td>
					Control characters
				</td>
			</tr>
			<tr>
				<td class="textCenter">
					<pre>[[:digit:]]</pre>
					or
					<pre>[0-9]</pre>
					or
					<pre>[\d]</pre>
				</td>
				<td>
					Digits
				</td>
			</tr>
			<tr>
				<td class="textCenter">
					<pre>[\D]</pre>
					or
					<pre>[^0-9]</pre>
				</td>
				<td>
					Non-digits
				</td>
			</tr>
			<tr>
				<td class="textCenter">
					<pre>[[:graph:]]</pre>
					or
					<pre>[\x21-\x7E]</pre>
				</td>
				<td>
					Visible characters
				</td>
			</tr>
			<tr>
				<td class="textCenter">
					<pre>[[:print:]]</pre>
					or
					<pre>[\x20-\x7E]</pre>
				</td>
				<td>
					Visible characters and spaces
				</td>
			</tr>
			<tr>
				<td class="textCenter">
					<pre>[[:lower:]]</pre>
					or
					<pre>[a-z]</pre>
				</td>
				<td>
					Lowercase letters
				</td>
			</tr>
			<tr>
				<td class="textCenter">
					<pre>[[:upper:]]</pre>
					or
					<pre>[A-Z]</pre>
				</td>
				<td>
					Uppercase letters
				</td>
			</tr>
			<tr>
				<td class="textCenter">
					<pre>[[:punct:]]</pre>
					or
					<pre>[-!"#$%&'()*+,./:;<=>?@[\\\]^_`{|}~]</pre>
				</td>
				<td>
					Punctuation characters
				</td>
			</tr>
			<tr>
				<td class="textCenter">
					<pre>[[:space:]]</pre>
					or
					<pre>[\s]</pre>
					or
					<pre>[ \t\r\n\v\f]</pre>
				</td>
				<td>
					Whitespace characters
				</td>
			</tr>
			<tr>
				<td class="textCenter">
					<pre>[[\S]]</pre>
					or
					<pre>[^ \t\r\n\v\f]</pre>
				</td>
				<td>
					Non-whitespace characters
				</td>
			</tr>
			<tr>
				<td class="textCenter">
					<pre>[[:xdigit:]]</pre>
					or
					<pre>[A-Fa-f0-9]</pre>
				</td>
				<td>
					Hexadecimal digits
				</td>
			</tr>
		</tbody>
	</table>
</div>
<p>&nbsp;</p>
<div dojoType="dijit.TitlePane" title="A brief collection of regular expression examples" open="false">
	<table class="fullWidth listWithAlternatingRowColour">
		<thead>
			<tr>
				<th class="textCenter">
					String type
				</th>
				<th>
					Regular expression
				</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td class="textCenter">
					Number
				</td>
				<td>
					<pre>(-?\d+)|(-?\d+\.\d+)</pre>
				</td>
			</tr>
			<tr>
				<td class="textCenter">
					HTML Tag
				</td>
				<td>
					<pre><[^>]*></pre>
				</td>
			</tr>
			<tr>
				<td class="textCenter">
					Email Address
				</td>
				<td>
					<pre>[\w-\.]+@[\w-\.]+\.{1}[\w]+</pre>
				</td>
			</tr>
			<tr>
				<td class="textCenter">
					URL
				</td>
				<td>
					<pre>(http://|ftp://)([\w-\.)(\.)([a-zA-Z]+)</pre>
				</td>
			</tr>
			<tr>
				<td class="textCenter">
					User name with a length between 4 and 15 chars
				</td>
				<td>
					<pre>[a-zA-Z][a-zA-Z0-9_]{3,14}</pre>
				</td>
			</tr>
			<!-- <tr>
				<td class="textCenter">
					Dates formatted like yyyy-mm-dd or yyyy/mm/dd
				</td>
				<td>
					<pre>(19|20)\d\d([- /.])(0[1-9]|1[012])\2(0[1-9]|[12][0-9]|3[01])</pre>
				</td>
			</tr>
			<tr>
				<td class="textCenter">
					Dates formatted like mm-dd-yyyy or mm/dd/yyyy
				</td>
				<td>
					<pre>(0[1-9]|1[012])[- /.](0[1-9]|[12][0-9]|3[01])[- /.](19|20)\d\d</pre>
				</td>
			</tr> -->
		</tbody>
	</table>
</div>
<p>&nbsp;</p>
<hr/>
<p>For more information, see the</p>
<ul>
	<li>
		<a href="http://de.selfhtml.org/javascript/objekte/regexp.htm" target="hint">SELFHTML regex documentation (in German, only)</a>,
	</li>
	<li>
		<a href="https://developer.mozilla.org/en/JavaScript/Guide/Regular_Expressions" target="hint">Mozilla Guide to Regular Expressions</a>,
	</li>
	<li>
		<a href="http://en.wikipedia.org/wiki/Regular_expression" target="hint">Regular Expressions in Wikipedia</a>
		or the
	</li>
	<li>
		<a href="http://www.regular-expressions.info/javascriptexample.html" target="hints">Regular Expression Tester</a>
		.
	</li>
</ul>
