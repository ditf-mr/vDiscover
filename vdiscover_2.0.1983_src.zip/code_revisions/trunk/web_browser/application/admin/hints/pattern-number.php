<!--
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
-->
<h4>How vDiscover handles numbers</h4>

<p>vDiscover stores all numbers internally in 
decimal fixed-point format with 15 digits before and 15 digits after the decimal separator (@Guido: is this correct?). 
The system-internal decimal separator is a <code>.</code> dot.</p>
<p>The implied precision should be more than sufficient as in industry, a precision of 
3 or 4 digits is often more than enough and floating point handling problems are avoided when storing.</p>

<h4>What are number patterns?</h4>

<p>The number pattern describes how a number shall be displayed to the user. 
The formatting is always locale-specific. Hence the internal number <code>9756987.458</code> is displayed e.g. as 
<code>9.756.987,5</code>
in the German locale using the number pattern 
&laquo;<code>###,###,##0.0</code>&raquo;.
</p>

<h4>Permitted characters in number patterns</h4>

<table class="fullWidth listWithAlternatingRowColour">
	<thead>
		<tr>
			<th class="textCenter">
				Symbol
			</th>
			<th>
				Meaning
			</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td class="textCenter">
				0
			</td>
			<td>
				Digit
			</td>
		</tr>
		<tr>
			<td class="textCenter">
				#
			</td>
			<td>
				Digit, zero shows as absent
			</td>
		</tr>
		<tr>
			<td class="textCenter">
				.
			</td>
			<td>
				Decimal separator
			</td>
		</tr>
		<tr>
			<td class="textCenter">
				,
			</td>
			<td>
				Digit grouping separator
			</td>
		</tr>
		<tr>
			<td class="textCenter">
				;
			</td>
			<td>
				Separated positive and negative subpatterns
			</td>
		</tr>
	</tbody>
</table>
<p class="small">Please note that there should be always a <code>0</code> before the decimal separator in the number pattern, especially if user input is required.</p>

<h4>Examples</h4>

<p>Here are some examples for the number <code>1234.567</code> with the French locale:</p>

<table class="fullWidth listWithAlternatingRowColour">
	<thead>
		<tr>
			<th>
				Pattern
			</th>
			<th>
				Text
			</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td>
				#,##0.##
			</td>
			<td>
				1 234,57
			</td>
		</tr>
		<tr>
			<td>
				#,##0.###
			</td>
			<td>
				1 234,567
			</td>
		</tr>
		<tr>
			<td>
				###0.#####
			</td>
			<td>
				1234,567
			</td>
		</tr>
		<tr>
			<td>
				###0.0000#
			</td>
			<td>
				1234,5670
			</td>
		</tr>
		<tr>
			<td>
				00000.0000
			</td>
			<td>
				01234,5670
			</td>
		</tr>
	</tbody>
</table>

<h4>For further reading ...</h4>

<p>For more information, see the
	<a href="http://www.dojotoolkit.com/reference-guide/quickstart/numbersDates.html#quickstart-numbersdates" target="hint">DOJO toolkit documentation</a>
	or the
	<a href="http://www.unicode.org/reports/tr35/#Number_Format_Patterns" target="hints">Unicode specification for number format patterns</a>
	.
</p>