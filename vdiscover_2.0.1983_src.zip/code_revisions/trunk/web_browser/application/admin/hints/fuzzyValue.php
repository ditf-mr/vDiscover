<!--
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
-->

<h4>Hints for fuzzy values</h4>
<p>A fuzzy set contains in general two or more set elements, e.g. &laquo;cold&raquo; and &laquo;cold&raquo;.</p>
<p>Currently, up to 7 set elements are permitted, this should be sufficient for most use cases.</p>
<p>Enter the set element names in the text area called &laquo;Names of the fuzzy set elements&raquo;, one name per line.</p>
<p>Here are some examples for names of fuzzy set elements:</p>
<ul>

	<li><p>Ratings</p>
		<textarea dojoType="dijit.form.Textarea" style="width:100%;" class="code">excellent
good
satisfying
acceptable
insufficient, fail</textarea>
	</li>

	<li><p>Strength</p>
		<textarea dojoType="dijit.form.Textarea" style="width:100%;" class="code">not perceptible
perceptible
weak
strong
very strong</textarea>
	</li>

	<li><p>Influence</p>
		<textarea dojoType="dijit.form.Textarea" style="width:100%;" class="code">strongly reducing
reducing
non influence
reinforcing
strongly reinforcing</textarea>
	</li>

	<li><p>Thermal comfort</p>
		<textarea dojoType="dijit.form.Textarea" style="width:100%;" class="code">too cold
cold
comfortable
warm
too warm</textarea>
	</li>

</ul>