<!--
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
-->

<p>The following characters are permitted in <strong>time patterns</strong>.</p>

<p>Be aware that a symbol may be used several times, e.g. <code>yy</code> might produce <code>99</code>, whereas <code>yyyy</code> might produce <code>1999</code>.</p>

<table class="fullWidth listWithAlternatingRowColour">
	<thead>
		<tr>
			<th class="textCenter">
				Symbol
			</th>
			<th>
				Meaning
			</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td class="textCenter">
				G
			</td>
			<td>
				Era designator, e.g. <code>BC, AD</code>
			</td>
		</tr>
		<tr>
			<td class="textCenter">
				y
			</td>
			<td>
				Year
				<br /><code>yy</code>&rarr;<code>12</code>
				<br /><code>yyyy</code>&rarr;<code>2012</code>
			</td>
		</tr>
		<tr>
			<td class="textCenter">
				Q
			</td>
			<td>
				Quarter in year, e.g. <code>1, 2</code>
			</td>
		</tr>
		<tr>
			<td class="textCenter">
				M
			</td>
			<td>
				Month in year
				<br /><code>MM</code>&rarr;<code>09</code>
				<br /><code>MMM</code>&rarr;<code>Sept</code>
				<br /><code>MMMM</code>&rarr;<code>September</code>
			</td>
		</tr>
		<tr>
			<td class="textCenter">
				w
			</td>
			<td>
				Week in year, e.g. <code>27</code>
			</td>
		</tr>
		<tr>
			<td class="textCenter">
				d
			</td>
			<td>
				Day in month
				<br /><code>d</code>&rarr;<code>9</code>
				<br /><code>dd</code>&rarr;<code>09</code>
			</td>
		</tr>
		<tr>
			<td class="textCenter">
				D
			</td>
			<td>
				Day in year, e.g. <code>189</code>
			</td>
		</tr>
		<tr>
			<td class="textCenter">
				E / F
			</td>
			<td>
				Day in week
				<br /><code>F</code>&rarr;<code>2</code>
				<br /><code>EE</code>&rarr;<code>Tues</code>
				<br /><code>EEEE</code>&rarr;<code>Tuesday</code>
			</td>
		</tr>
		<tr>
			<td class="textCenter">
				a
			</td>
			<td>
				AM/PM marker, e.g. <code>PM</code>
			</td>
		</tr>
		<tr>
			<td class="textCenter">
				HH
			</td>
			<td>
				Hour in day (00..23)
			</td>
		</tr>
		<tr>
			<td class="textCenter">
				h
			</td>
			<td>
				Hour in AM/PM (1..12)
				<br /><code>h</code>&rarr;<code>9</code>
				<br /><code>hh</code>&rarr;<code>09</code>
			</td>
		</tr>
		<tr>
			<td class="textCenter">
				mm
			</td>
			<td>
				Minute in hour, e.g. <code>04, 30</code>
			</td>
		</tr>
		<tr>
			<td class="textCenter">
				ss
			</td>
			<td>
				Second in minute, e.g. <code>06, 55</code>
			</td>
		</tr>
		<tr>
			<td class="textCenter">
				SSS
			</td>
			<td>
				Millisecond, e.g. <code>978</code>
			</td>
		</tr>
		<tr>
			<td class="textCenter">
				z / Z
			</td>
			<td>
				Time zone
				<br /><code>z</code>&rarr;<code>CEST/CEDT +02:00</code>
				<br /><code>Z</code>&rarr;<code>+0200</code>
			</td>
		</tr>
	</tbody>
</table>

<p>Here are some examples for <code>2001-07-04 12:08:56</code> local time in the Middle Europe time zone (in summer):</p>

<table class="fullWidth listWithAlternatingRowColour">
	<thead>
		<tr>
			<th>
				Pattern
			</th>
			<th>
				Text
			</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td>
				<code>yyyy.MM.dd G ‘at’ HH:mm:ss</code>
			</td>
			<td>
				<code>2001.07.04 AD at 12:08:56</code>
			</td>
		</tr>
		<tr>
			<td>
				<code>EEE, MMM d, ‘’y</code>
			</td>
			<td>
				<code>Wed, Jul 4, ‘01</code>
			</td>
		</tr>
		<tr>
			<td>
				<code>h:mm a</code>
			</td>
			<td>
				<code>12:08 PM</code>
			</td>
		</tr>
		<tr>
			<td>
				<code>hh ‘o’‘clock’ a, z</code>
			</td>
			<td>
				<code>12 o’clock PM, CEST +02:00</code>
			</td>
		</tr>
		<tr>
			<td>
				<code>yyyy.MMMMM.dd G hh:mm a</code>
			</td>
			<td>
				<code>2001.July.04 AD 12:08 PM</code>
			</td>
		</tr>
		<tr>
			<td>
				<code>EEE, d MMM yyyy HH:mm:ss Z</code>
			</td>
			<td>
				<code>Wed, 4 Jul 2001 12:08:56 -0700</code>
			</td>
		</tr>
		<tr>
			<td>
				<code>yyMMddHHmmss</code>
			</td>
			<td>
				<code>010704120856</code>
			</td>
		</tr>
		<tr>
			<td>
				<code>yyyy-MM-dd’T’HH:mm:ss.SSS</code>
			</td>
			<td>
				<code>2001-07-04T12:08:56.235-0700</code>
			</td>
		</tr>
	</tbody>
</table>

<p>For more information, see the
	<a href="http://www.dojotoolkit.com/reference-guide/quickstart/numbersDates.html#quickstart-numbersdates" target="hint">DOJO toolkit documentation</a>
	or the
	<a href="http://www.unicode.org/reports/tr35/#Date_Format_Patterns" target="hint">Unicode specification for date format patterns</a>
	.
</p>