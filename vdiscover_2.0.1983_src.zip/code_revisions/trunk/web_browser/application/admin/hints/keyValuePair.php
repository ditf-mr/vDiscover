<!--
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
-->

<h4>Hints for definition of key-value pairs</h4>
<ul>
	<li>Use one line for each key-value pair.</li>
	<li>Key-value pairs consist of an invisible key and a visible value.
		E.g.: <code>b|bunnies</code> means: <code>b</code> is the key, whereas <code>bunny</code> is the value.
	</li>
	<li>Keep the key strings as short as possible (max length about 36 chars).</li>
	<li>Value strings need to be as long as necessary and as short as reasonable.</li>
	<li>The key-value separator is the pipe char <code>|</code>.<br/>
		In case that you do not find it on your keyboard, copy it from here.</li>
	<li>System users will not see the keys, they only see the value.
		<ul>
			<li>Use therefore keys as they are used in databases with which you are synchronising</li>
			<li>and values as the user needs to understand them.</li>
		</ul>
	</li>
</ul>

<h4>Here is an example key-value pair definition</h4>

<textarea dojoType="dijit.form.SimpleTextarea" rows="9" style="width:100%;" class="code">s|Sun &#x263f;
Me|Mercury &#x2640;
V|Venus &#x2295;
E|Earth &#x2641;
Ma|Mars &#x2642;
J|Jupiter &#x2643;
S|Saturn &#x2644;
U|Uranus &#x2645;
N|Neptune &#x2646;</textarea>
<p class="small textRight">The planet symbols are Unicode symbols, for more information see the <a href="http://en.wikipedia.org/wiki/Astronomical_symbols" target="_someWhere">astronomical symbols in Wikipedia</a>.</p>

<h4>Preparing large amounts of data</h4>
<p>Perhaps, you do already have a list of values with their corresponding keys but without having them concatenated with the pipe char <code>|</code>.</p>
<p>Just paste your data in Excel and create a cell with the concatenated value with the cell formula 
<code>=A1&amp;"|"&amp;B1</code>. 
In this example, the cell <code>A1</code> contains the key, whereas the cell <code>B1</code> contains the value.</p>
<p>You can copy and paste your prepared key-value list into the input box, then.</p>

<h4>A list of country names with their corresponding ISO ALPHA3-Code</h4>
<textarea dojoType="dijit.form.SimpleTextarea" rows="10" style="width:100%;" class="code">AFG|Afghanistan
ALA|Åland Islands
ALB|Albania
DZA|Algeria
ASM|American Samoa
AND|Andorra
AGO|Angola
AIA|Anguilla
ATG|Antigua and Barbuda
ARG|Argentina
ARM|Armenia
ABW|Aruba
AUS|Australia
AUT|Austria
AZE|Azerbaijan
BHS|Bahamas
BHR|Bahrain
BGD|Bangladesh
BRB|Barbados
BLR|Belarus
BEL|Belgium
BLZ|Belize
BEN|Benin
BMU|Bermuda
BTN|Bhutan
BOL|Bolivia (Plurinational State of)
BES|Bonaire, Saint Eustatius and Saba
BIH|Bosnia and Herzegovina
BWA|Botswana
BRA|Brazil
VGB|British Virgin Islands
BRN|Brunei Darussalam
BGR|Bulgaria
BFA|Burkina Faso
BDI|Burundi
KHM|Cambodia
CMR|Cameroon
CAN|Canada
CPV|Cape Verde
CYM|Cayman Islands
CAF|Central African Republic
TCD|Chad
Channel Islands|Channel Islands
CHL|Chile
CHN|China
HKG|China, Hong Kong Special Administrative Region
MAC|China, Macao Special Administrative Region
COL|Colombia
COM|Comoros
COG|Congo
COK|Cook Islands
CRI|Costa Rica
CIV|Côte d'Ivoire
HRV|Croatia
CUB|Cuba
CUW|Curaçao
CYP|Cyprus
CZE|Czech Republic
PRK|Democratic People's Republic of Korea
COD|Democratic Republic of the Congo
DNK|Denmark
DJI|Djibouti
DMA|Dominica
DOM|Dominican Republic
ECU|Ecuador
EGY|Egypt
SLV|El Salvador
GNQ|Equatorial Guinea
ERI|Eritrea
EST|Estonia
ETH|Ethiopia
FRO|Faeroe Islands
FLK|Falkland Islands (Malvinas)
FJI|Fiji
FIN|Finland
FRA|France
GUF|French Guiana
PYF|French Polynesia
GAB|Gabon
GMB|Gambia
GEO|Georgia
DEU|Germany
GHA|Ghana
GIB|Gibraltar
GRC|Greece
GRL|Greenland
GRD|Grenada
GLP|Guadeloupe
GUM|Guam
GTM|Guatemala
GGY|Guernsey
GIN|Guinea
GNB|Guinea-Bissau
GUY|Guyana
HTI|Haiti
VAT|Holy See
HND|Honduras
HUN|Hungary
ISL|Iceland
IND|India
IDN|Indonesia
IRN|Iran (Islamic Republic of)
IRQ|Iraq
IRL|Ireland
IMN|Isle of Man
ISR|Israel
ITA|Italy
JAM|Jamaica
JPN|Japan
JEY|Jersey
JOR|Jordan
KAZ|Kazakhstan
KEN|Kenya
KIR|Kiribati
KWT|Kuwait
KGZ|Kyrgyzstan
LAO|Lao People's Democratic Republic
LVA|Latvia
LBN|Lebanon
LSO|Lesotho
LBR|Liberia
LBY|Libya
LIE|Liechtenstein
LTU|Lithuania
LUX|Luxembourg
MDG|Madagascar
MWI|Malawi
MYS|Malaysia
MDV|Maldives
MLI|Mali
MLT|Malta
MHL|Marshall Islands
MTQ|Martinique
MRT|Mauritania
MUS|Mauritius
MYT|Mayotte
MEX|Mexico
FSM|Micronesia (Federated States of)
MCO|Monaco
MNG|Mongolia
MNE|Montenegro
MSR|Montserrat
MAR|Morocco
MOZ|Mozambique
MMR|Myanmar
NAM|Namibia
NRU|Nauru
NPL|Nepal
NLD|Netherlands
NCL|New Caledonia
NZL|New Zealand
NIC|Nicaragua
NER|Niger
NGA|Nigeria
NIU|Niue
NFK|Norfolk Island
MNP|Northern Mariana Islands
NOR|Norway
PSE|Occupied Palestinian Territory
OMN|Oman
PAK|Pakistan
PLW|Palau
PAN|Panama
PNG|Papua New Guinea
PRY|Paraguay
PER|Peru
PHL|Philippines
PCN|Pitcairn
POL|Poland
PRT|Portugal
PRI|Puerto Rico
QAT|Qatar
KOR|Republic of Korea
MDA|Republic of Moldova
REU|Réunion
ROU|Romania
RUS|Russian Federation
RWA|Rwanda
BLM|Saint-Barthélemy
SHN|Saint Helena
KNA|Saint Kitts and Nevis
LCA|Saint Lucia
MAF|Saint-Martin (French part)
SPM|Saint Pierre and Miquelon
VCT|Saint Vincent and the Grenadines
WSM|Samoa
SMR|San Marino
STP|Sao Tome and Principe
Sark|Sark
SAU|Saudi Arabia
SEN|Senegal
SRB|Serbia
SYC|Seychelles
SLE|Sierra Leone
SGP|Singapore
SXM|Sint Maarten (Dutch part)
SVK|Slovakia
SVN|Slovenia
SLB|Solomon Islands
SOM|Somalia
ZAF|South Africa
SSD|South Sudan
ESP|Spain
LKA|Sri Lanka
SDN|Sudan
SUR|Suriname
SJM|Svalbard and Jan Mayen Islands
SWZ|Swaziland
SWE|Sweden
CHE|Switzerland
SYR|Syrian Arab Republic
TJK|Tajikistan
THA|Thailand
MKD|The former Yugoslav Republic of Macedonia
TLS|Timor-Leste
TGO|Togo
TKL|Tokelau
TON|Tonga
TTO|Trinidad and Tobago
TUN|Tunisia
TUR|Turkey
TKM|Turkmenistan
TCA|Turks and Caicos Islands
TUV|Tuvalu
UGA|Uganda
UKR|Ukraine
ARE|United Arab Emirates
GBR|United Kingdom of Great Britain and Northern Ireland
TZA|United Republic of Tanzania
USA|United States of America
VIR|United States Virgin Islands
URY|Uruguay
UZB|Uzbekistan
VUT|Vanuatu
VEN|Venezuela (Bolivarian Republic of)
VNM|Viet Nam
WLF|Wallis and Futuna Islands
ESH|Western Sahara
YEM|Yemen
ZMB|Zambia
ZWE|Zimbabwe</textarea>
<p class="small textRight">Source: 
	<a href="http://unstats.un.org/unsd/methods/m49/m49alpha.htm" target="_someWhere">United Nations Statistics Division: Countries or areas, codes and abbreviations</a>
	(Sept 20<sup>th</sup>, 2011;non-existing country codes were replaced with the country name).
</p>