<!--
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
-->

<h4>Hints for MIME types</h4>

<p>Originally called &laquo;Multipurpose Internet Mail Extensions&raquo;, <strong>internet media types</strong>
 or <strong> content types</strong> form identifiers for file formats on the internet.
 The registry of MIME types is maintained by 
 <a href="http://www.iana.org/assignments/media-types/index.html" target="_new"><strong>iana</strong></a> 
 (Internet assigned numbers authority).</p>
 <p>Example for permitted MIME types:</p>
<textarea dojoType="dijit.form.Textarea" style="width:100%;" class="code">image/jpeg
image/png</textarea>
 
 <h4>Incomplete list of popular MIME types</h4>
 
 <table class="arrangement5050 captionOnTop listWithAlternatingRowColour fullWidth">
	<caption>MIME types for multipurpose files</caption>
	<thead>
		<tr>
			<th>File name ending</th>
			<th>MIME type</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td class="code">*.*</td>
			<td class="code"><textarea dojoType="dijit.form.Textarea" style="width:100%;" class="code">application/octet-stream</textarea></td>
		</tr>
		<tr>
			<td class="code">*.zip</td>
			<td class="code"><textarea dojoType="dijit.form.Textarea" style="width:100%;" class="code">application/x-compressed
application/x-zip-compressed
application/zip
multipart/x-zip</textarea></td>
		</tr>
	</tbody>
 </table>
 
<p>&nbsp;</p>
 
<table class="arrangement5050 captionOnTop listWithAlternatingRowColour fullWidth">
	<caption>MIME types for audio files</caption>
	<thead>
		<tr>
			<th>File name ending</th>
			<th>MIME type</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td class="code">*.wav</td>
			<td class="code"><textarea dojoType="dijit.form.Textarea" style="width:100%;" class="code">audio/wav
audio/x-wav</textarea></td>
		</tr>
		<tr>
			<td class="code">*.mp3</td>
			<td class="code"><textarea dojoType="dijit.form.Textarea" style="width:100%;" class="code">audio/mpeg3
audio/x-mpeg-3</textarea></td>
		</tr>
	</tbody>
 </table>
 
<p>&nbsp;</p>

 <table class="arrangement5050 captionOnTop listWithAlternatingRowColour fullWidth">
	<caption>MIME types for video files</caption>
	<thead>
		<tr>
			<th>File name ending</th>
			<th>MIME type</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td class="code">*.avi</td>
			<td class="code"><textarea dojoType="dijit.form.Textarea" style="width:100%;" class="code">application/x-troff-msvideo
video/avi
video/msvideo
video/x-msvideo</textarea></td>
		</tr>
	</tbody>
 </table>
 
 <p>&nbsp;</p>
 
 <table class="arrangement5050 captionOnTop listWithAlternatingRowColour fullWidth">
	<caption>MIME types for image files</caption>
	<thead>
		<tr>
			<th>File name ending</th>
			<th>MIME type</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td class="code">*.bmp</td>
			<td class="code"><textarea dojoType="dijit.form.Textarea" style="width:100%;" class="code">image/bmp
image/x-windows-bmp</textarea></td>
		</tr>
		<tr>
			<td class="code">*.gif, *.jpeg, *.png</td>
			<td class="code"><textarea dojoType="dijit.form.Textarea" style="width:100%;" class="code">image/gif
image/jpeg
image/png</textarea></td>
		</tr>
		<tr>
			<td class="code">*.gif</td>
			<td class="code"><textarea dojoType="dijit.form.Textarea" style="width:100%;" class="code">image/gif</textarea></td>
		</tr>
		<tr>
			<td class="code">*.jpeg<br/>*.jpg<br/>*.jpe</td>
			<td class="code"><textarea dojoType="dijit.form.Textarea" style="width:100%;" class="code">image/jpeg</textarea></td>
		</tr>
		<tr>
			<td class="code">*.png</td>
			<td class="code"><textarea dojoType="dijit.form.Textarea" style="width:100%;" class="code">image/png</textarea></td>
		</tr>
		<tr>
			<td class="code">*.tiff<br/>*.tif</td>
			<td class="code"><textarea dojoType="dijit.form.Textarea" style="width:100%;" class="code">image/tiff</textarea></td>
		</tr>
		<tr>
			<td class="code">*.avi</td>
			<td class="code"><textarea dojoType="dijit.form.Textarea" style="width:100%;" class="code">image/bmp</textarea></td>
		</tr>
	</tbody>
 </table>
 
 <p>&nbsp;</p>
 
 <table class="arrangement5050 captionOnTop listWithAlternatingRowColour fullWidth">
	<caption>MIME types for office files</caption>
	<thead>
		<tr>
			<th>File name ending</th>
			<th>MIME type</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td class="code">*.xla<br/>*.xls</td>
			<td class="code"><textarea dojoType="dijit.form.Textarea" style="width:100%;" class="code">application/msexcel</textarea></td>
		</tr>
		<tr>
			<td class="code">*.ppt<br/>*.pps<br/>*.pot</td>
			<td class="code"><textarea dojoType="dijit.form.Textarea" style="width:100%;" class="code">application/mspowerpoint
application/powerpoint
application/vnd.ms-powerpoint</textarea></td>
		</tr>
		<tr>
			<td class="code">*.doc<br/>*.dot</td>
			<td class="code"><textarea dojoType="dijit.form.Textarea" style="width:100%;" class="code">application/msword
application/word
application/vnd.ms-word</textarea></td>
		</tr>
		<tr>
			<td class="code">*.rtf</td>
			<td class="code"><textarea dojoType="dijit.form.Textarea" style="width:100%;" class="code">text/rtf
application/rtf
application/x-rtf
text/richtext</textarea></td>
		</tr>
		<tr>
			<td class="code">*.pdf</td>
			<td class="code"><textarea dojoType="dijit.form.Textarea" style="width:100%;" class="code">application/pdf</textarea></td>
		</tr>
		<tr>
			<td class="code">*.csv</td>
			<td class="code"><textarea dojoType="dijit.form.Textarea" style="width:100%;" class="code">text/comma-separated-values</textarea></td>
		</tr>
		<tr>
			<td class="code">*.tsv</td>
			<td class="code"><textarea dojoType="dijit.form.Textarea" style="width:100%;" class="code">text/tab-separated-values</textarea></td>
		</tr>
		<tr>
			<td class="code">*.asc<br/>*.txt</td>
			<td class="code"><textarea dojoType="dijit.form.Textarea" style="width:100%;" class="code">text/plain</textarea></td>
		</tr>
	</tbody>
 </table>
 
 <p>&nbsp;</p>
 
 <table class="arrangement5050 captionOnTop listWithAlternatingRowColour fullWidth">
	<caption>MIME types for HTML and related files</caption>
	<thead>
		<tr>
			<th>File name ending</th>
			<th>MIME type</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td class="code">*.css</td>
			<td class="code"><textarea dojoType="dijit.form.Textarea" style="width:100%;" class="code">text/css</textarea></td>
		</tr>
		<tr>
			<td class="code">*.htm<br/>*.html<br/>*.shtml</td>
			<td class="code"><textarea dojoType="dijit.form.Textarea" style="width:100%;" class="code">text/html</textarea></td>
		</tr>
		<tr>
			<td class="code">*.js</td>
			<td class="code"><textarea dojoType="dijit.form.Textarea" style="width:100%;" class="code">text/javascript</textarea></td>
		</tr>
	</tbody>
 </table>

