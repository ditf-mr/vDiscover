/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// parentWidget._supportingWidgets

dojo.declare('application.widgets.manageAccessPermissionsDialog',[dijit.Dialog],{
	constructor : function() {
		// Your constructor method will be called before the parameters are mixed into the widget, and can be used to initialize arrays, etc.
		this.inherited(arguments);
		
		// some initialisations
		this.widgets 		= {};
		this.selectedViews	= [];
		
	} // end of method constructor
	,
	'OT_UUID'				: null
	,
	'OT_name'				: null
	,
	'rolesStore'			: null
	,
	'objectAccessPermissionStore'	: null // dojo.data.itemFileWriteStore
	,
	'viewAccessPermissionStore'		: null // dojo.data.itemFileWriteStore
	,
	'attributeAccessPermissionStore': null // dojo.data.itemFileWriteStore
	,
	'inheritedChar'			: '&#x21FD;' // see http://www.utf8-chartable.de/unicode-utf8-table.pl?start=8592&number=1024&unicodeinhtml=hex
	,
	'postMixInProperties' : function() {
		// If you provide a postMixInProperties method for your widget, 
		// it will be invoked before rendering occurs, and before 
		// any dom nodes are created. If you need to add or change the 
		// instance's properties before the widget is rendered 
		// - this is the place to do it.
		this.inherited(arguments);
		
		this.title = T('manageAccessPermissions.js/DialogTitle_TIT','Manage the access permissions of « $[0]» ',[this.OT_name]);

		this.viewPortHeight = dojo.doc.body.clientHeight - dojo.doc.body.clientTop;
		this.viewPortWidth  = dojo.doc.body.clientWidth - dojo.doc.body.clientLeft;
		
		this.contentBoxHeight= Math.min( this.viewPortHeight-25, Math.floor(this.viewPortHeight * .9), 800 );
		this.contentBoxWidth = Math.min( this.viewPortWidth-25, Math.floor(this.viewPortWidth 	* .9), 1000);

	} // end of method postMixInProperties
	,
	/*buildRendering : function() {
		// dijit._Templated provides an implementation of buildRendering 
		// that most times will do what you need. The template is fetched/read, 
		// nodes created and events hooked up during buildRendering. The end 
		// result is assigned to this.domNode. If you don't mixin dijit._Templated 
		// (and most OOTB dijits do) and want to handle rendering yourself 
		// (e.g. to really streamline a simple widget, or even use a different 
		// templating system) this is where you'd do it.
		this.inherited(arguments);
	} // end of method buildRendering
	,*/
	'postCreate' : function() {
		// This is typically the workhorse of a custom widget. The widget has 
		// been rendered (but note that sub-widgets in the containerNode have not!). 
		// The widget though may not be attached to the DOM yet so you shouldn't 
		// do any sizing calculations in this method.
		this.inherited(arguments);
			
		// resize the inner part of this dialog
		dojo.style( this.containerNode, 'height',	''+this.contentBoxHeight+'px' );
		dojo.style( this.containerNode, 'width',	''+this.contentBoxWidth +'px' );

		// build the main structure of the dialog
		this.widgets.borderContainer = new dijit.layout.BorderContainer({
			'style' 	: 'width:100%;height:100%;',
			'gutters'	: false
		});
		this.widgets.borderContainer.placeAt(this.containerNode);
		
		// create the action bar at the bottom of the dialog
		this.widgets.actionBar = new dijit.layout.ContentPane({
			'region'	: 'bottom',
			'class'		: 'dijitDialogPaneActionBar textRight',
			'style'		: 'padding-top:1em;'
		});
		this.widgets.borderContainer.addChild(this.widgets.actionBar);

		this.widgets.OkButton = new dijit.form.Button({
			'label' 	: '<img src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/dialog-ok-apply-4.png"/> '
				+T('BTN_OK','OK'),
			'type'		: 'button'
		}).placeAt(this.widgets.actionBar.containerNode);

		dojo.connect(this.widgets.OkButton,'onClick',application.admin.manageAccessPermissions,'execute');
		
		this.widgets.CancelButton = new dijit.form.Button({
			'label' 	: '<img width="12" src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/dialog-cancel-4.png"/> '
				+T('BTN_Cancel','Cancel'),
			'type'		: 'button',
			'style'		: 'margin-right:0;'
		}).placeAt(this.widgets.actionBar.containerNode);
		
		dojo.connect( this.widgets.CancelButton,	'onClick', application.admin.manageAccessPermissions, 'closeDialog');
		dojo.connect( this.closeButtonNode,			'onClick', application.admin.manageAccessPermissions, 'closeDialog');
		
		// create the main edit pane for the view configuration
		this.widgets.viewEditBorderContainer = new dijit.layout.BorderContainer({
			'region'	: 'center',
			'style'		: 'margin-left:.5ex;',
			'gutters'	: false
		});
		this.widgets.borderContainer.addChild(this.widgets.viewEditBorderContainer);
				
		this.widgets.viewEditor = new dijit.layout.ContentPane({
			'region'	: 'center',
			'class'		: 'dijitMenuBar',
			'content'	: '<div dojoType="dijit.form.Button">test</div>',
			'style'		: 'padding:.5ex;padding-top:1.25em;'
		});
		this.widgets.viewEditBorderContainer.addChild(this.widgets.viewEditor);
		
		// build store for handling of access permissions of objects
		this.objectAccessPermissionStore = new dojo.data.ItemFileWriteStore({
					'data' : {"identifier":"UUID","label":"UUID","items":[]},
					'clearOnClose' 	: true
				});	
		
		this.loadRolesListFromServer();
		
		this.displayDialog();

	} // end of method postCreate
	,
	'loadRolesListFromServer' : function () { // ############################
	
		// create the rolesStore
		dojo.xhrPost({
			'url'		: '?'
			,
			'content'	: {
				'v'		: 'JSON_General',
				'task'	: 'get_roles', 
				'UUID'	: '10000000-1000-1000-1000-00000000000e'
			}
			,
			'error'		: function(r,a) {
				try{
					if (typeof (r.responseText)!='undefined') {
						var e=dojo.fromJson(r.responseText);
						application.showErrorMessage(
							'<p><strong>Server error:</strong></p>'+
							'<table><tbody>'+
								'<tr><th>Type</th><td>'+e.type+'</td></tr>'+
								'<tr><th>Message</th><td>'+e.message+'</td></tr>'+
								'<tr><th>Code</th><td>'+e.code+'</td></tr>'+
								'<tr><th>File</th><td>'+e.file+'</td></tr>'+
								'<tr><th>Line</th><td>'+e.line+'</td></tr>'+
								'<tr><th>Trace</th><td><pre>'+e.trace+'</pre></td></tr>'+								
							'<tbody></table>'
							);
					} else {
						application.showErrorMessage('<pre class="small">'+dojo.toJson(r,true)+'</pre>');
					} // end if
				} catch (exception) {
					var errorMessage = '';
					if(r.responsetext) {
						errorMessage = '<p><strong>Server error:</strong></p><pre>'+r.responseText+'</pre>';
					} else {
						errorMessage = '<p><strong>Error:</strong></p><pre>'+exception+'</pre>';
					} // end if
				
					application.showErrorMessage(errorMessage);
				} // end try ... catch
			}, // end of error method
			'handleAs'	: 'json',
			'scope'		: this,
			'load'		: function(response,request){ /* onSuccess */
				
				request.args.scope.rolesStore = new dojo.data.ItemFileReadStore({
						'data'			: response, 
						'clearOnClose' 	: true,
						'hierarchical'	: true
					});
				
				// request.args.scope.renumberViewPositions();
				// request.args.scope.outputViewList();
				
			}, // end of onSuccess method
			//preventCache:true,
			//failOk	: true,
			'sync'		: true,
			'timeout'	: 	application.configuration.global.AJAX_default_timeout
		});
			
	} // end of method loadRolesListFromServer
	,
	'displayDialog' : function () {
		// this method displays the edit dialog components for view with UUID
		
		var inherited, 
			name 			= '', 
			V_UUID 			= '',
			kind 			= '',
			viewTypeString	= '',
			editStatus 		= '';
			
		// get the corresponding view
		// this.viewStore.fetchItemByIdentity({
			// 'identity' 	: UUID,
			// 'scope'		: this,
			// 'onItem' 	: function (item) {
				// // is the the view inherited?
				// inherited 	= 	(		(this.viewStore.getValue(item, 'editStatus')		!='inserted') 
									// && 	(this.viewStore.getValue(item, 'VT_origin_UUID')	!=''		)
								// );
				// name				= this.viewStore.getValue(item, 'name');
				// V_UUID				= this.viewStore.getValue(item, 'UUID');
				// kind 				= this.viewStore.getValue(item, 'kind');
				// viewTypeString		= application.viewKinds.viewKindList[kind].name;
				// if (this.viewStore.hasAttribute(item, 'editStatus')) 
					// editStatus 		= this.viewStore.getValue(item, 'editStatus');				
			// } // end of function onItem
		// }); // end get the item
		
		
		// set the name pane
		// this.setViewName(V_UUID);
		
		// set the edit pane
		
		// var c = this.getViewConfigurationEditor_config(V_UUID);
		
		this.widgets.accessPermissionsEditorTabContainer = new dijit.layout.TabContainer({});
		this.widgets.viewEditor.set('content', this.widgets.accessPermissionsEditorTabContainer);
		
		this.widgets.accessPermissionsEditor_objectsPane = new application.widgets.manageAccessPermissions_permissionEditor_objectsPane({
													'title': T('manageAccessPermissions.js/ObjPermissions_TAB','Object permissions'),
													'dialogWidget' : this
												});
		this.widgets.accessPermissionsEditorTabContainer.addChild(this.widgets.accessPermissionsEditor_objectsPane);

		this.widgets.accessPermissionsEditor_viewsPane = new application.widgets.manageAccessPermissions_permissionEditor_viewsPane({
													'title': T('manageAccessPermissions.js/ViewPermissions_TAB','View permissions'),
													'dialogWidget' : this													
												});
		this.widgets.accessPermissionsEditorTabContainer.addChild(this.widgets.accessPermissionsEditor_viewsPane);

		this.widgets.accessPermissionsEditor_attributesPane = new application.widgets.manageAccessPermissions_permissionEditor_attributesPane({
													'title': T('manageAccessPermissions.js/AttrPermissions_TAB','Attribute permissions'),
													'dialogWidget' : this
												});
		this.widgets.accessPermissionsEditorTabContainer.addChild(this.widgets.accessPermissionsEditor_attributesPane);			
		
	} // end of method displayView
	,
	'startup' : function() {
		// If you need to be sure parsing and creation of any child widgets has 
		// completed, use startup. This is often used for layout widgets like 
		// BorderContainer. If the widget does JS sizing, then startup() should 
		// call resize(), which does the sizing.
		this.inherited(arguments);
		
		this.widgets.borderContainer.startup();
		this.widgets.borderContainer.resize();
	} // end of method startup
	,
    /*resize : function() {
		// All widgets that do JS sizing should have a method called resize(), that lays 
		// out the widget. Resize() should be called from startup() and will also be 
		// called by parent widgets like dijit.layout.ContentPane.
	}
	,*/
	'destroy' : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		
		for (var i in this.widgets) {
			this.widgets[i].destroyRecursive();
			delete this.widgets[i];
		} // end for .. in
		
		this.inherited(arguments);
	} // end of method destroy
	,
	'onCancel' : function(){
		return false;
	} // end of method
	
});

// extend the admin functionality with access permission management
application.admin.manageAccessPermissions = {
	'dialogWidget' 	: null
	,
	'OT_UUID'	: null
	,
	'OT_name'	: null
	,
	'showDialog'	: function(){
	
		if(this.dialogWidget) this.closeDialog(); // carry out some cleanUp
	
		// make the object type UUID and name local
		this.OT_UUID =  application.admin.navigationStore.getValue(application.admin.currentNavigationItem,'UUID');
		this.OT_name =  application.admin.navigationStore.getValue(application.admin.currentNavigationItem,'name');
		
		this.dialogWidget = new application.widgets.manageAccessPermissionsDialog({
			'OT_UUID'	: this.OT_UUID,
			'OT_name'	: this.OT_name
		});
		
		this.dialogWidget.startup();
		this.dialogWidget.show();
	} // end of method showDialog
	,
	'execute' : function () {
	
		// delete the roles store
		this.dialogWidget.rolesStore.close ();
		
		
		alert( T('manageAccessPermissions.js/ChangesNotStored_MSG','The changes will not be stored.') );
		// remove all deleted items from the store
		// this.dialogWidget.viewStore.fetch ({
			// 'query'	: { 'editStatus': 'deleted'},
			// 'scope'	: this,
			// 'onItem': function ( item, request ) {
				// this.dialogWidget.viewStore.deleteItem( item );
			// } // end of method onItem
		// });
		
		// apply all changes to the store
		// this.dialogWidget.viewStore.save();					

		// send all changes to the server
		// application.OT_AJAX_query({
				// 'task'		: 'set_OT_viewTypes',
				// 'UUID'		: this.OT_UUID,
				// 'viewTypes'	: this.dialogWidget.viewStore._getNewFileContentString()
			// },
			// function(r,a){ // onSuccess
			// }, // end of onSuccess function
			// true // synchronously
		// ); 
	
		return this.closeDialog();
	} // end of method execute
	,
	'closeDialog' : function() {
		this.dialogWidget.hide();
		this.dialogWidget.destroyRecursive(false);
		this.dialogWidget.destroy();
		this.dialogWidget=null;
		this.OT_UUID = null;
		this.OT_name = null;
		
	} // end of method closeDialog
}; // end extension of the admin functionality

// the template widget for configuring access permissions
dojo.declare('application.widgets.manageAccessPermissions_permissionEditor_template', [dijit.layout.ContentPane],{
	constructor : function() {
		// Your constructor method will be called before the parameters are mixed into the widget, and can be used to initialize arrays, etc.
		// this.inherited(arguments);
		
		// some initialisations
		this.widgets 		= {};
		this.selectedViews	= [];
		
	}	// end of method constructor
	,
	'dialogWidget'		: null // needs to be passed
	,
	'widgetsInTemplate'	: true
	,
	'templateString' 	: ''
	,
	'destroy' : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		
		for (var i in this.widgets) {
			this.widgets[i].destroyRecursive();
			delete this.widgets[i];
		} // end for .. in
		
		this.inherited(arguments);
	} // end of method destroy
});

// the widget for editing object access permission properties form
dojo.declare('application.widgets.manageAccessPermissions_permissionEditor_objectsPane', [application.widgets.manageAccessPermissions_permissionEditor_template],{
	/*constructor : function() {
		// Your constructor method will be called before the parameters are mixed into the widget, and can be used to initialize arrays, etc.
		this.inherited(arguments);
	} // end of method constructor
	,*/
	'postMixInProperties' : function () {
		this.inherited(arguments);
		
		// var output = '';
		
		// this.dialogWidget.rolesStore.fetch({
			// 'scope'		: this.dialogWidget,
			// 'onItem' 	: function (item) {
				// name	= this.rolesStore.getValue(item, 'name');
				// O_UUID	= this.rolesStore.getValue(item, 'UUID');
				// output +='<tr><td rowspan="5">'+name+'</td><td>Reading</td><td></td><td>Hint reading</td></tr>';
				// output +='<tr>								<td>Edit</td><td></td><td>Hint reading</td></tr>';
				// output +='<tr>								<td>Create</td><td></td><td>Hint reading</td></tr>';
				// output +='<tr>								<td>Delete</td><td></td><td>Hint reading</td></tr>';
				// output +='<tr>								<td>Admin</td><td></td><td>Hint reading</td></tr>';
			// } // end of function onItem
		// });
		
		// get object access permissions from DB
		this.loadObjectAccessPermissionsFromServer();
		
		this.templateString = '<div>' // this template is invalid without this DIV tag
						
			+'</div>'

		
	} // end of method postMixInProperties
	,
	'postCreate' : function() {
		// This is typically the workhorse of a custom widget. The widget has 
		// been rendered (but note that sub-widgets in the containerNode have not!). 
		// The widget though may not be attached to the DOM yet so you shouldn't 
		// do any sizing calculations in this method.
		this.inherited(arguments);
			
		// build the main structure of the dialog
		this.widgets.borderContainer = new dijit.layout.BorderContainer({
			'style' 	: 'width:100%;height:100%;',
			'gutters'	: false
		});
		this.widgets.borderContainer.placeAt(this.containerNode);
			
		// create the action bar at the bottom of the dialog
		// this.widgets.actionBar = new dijit.layout.ContentPane({
			// 'region'	: 'bottom',
			// 'class'		: 'dijitDialogPaneActionBar textRight',
			// 'style'		: 'padding-top:1em;'
		// });
		// this.widgets.borderContainer.addChild(this.widgets.actionBar);

		// this.widgets.OkButton = new dijit.form.Button({
			// 'label' 	: '<img src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/dialog-ok-apply-4.png"/> '
				// +T('BTN_OK','OK'),
			// 'type'		: 'button'
		// }).placeAt(this.widgets.actionBar.containerNode);

		// dojo.connect(this.widgets.OkButton,'onClick',application.admin.manageAccessPermissions,'execute');
		
		// this.widgets.CancelButton = new dijit.form.Button({
			// 'label' 	: '<img width="12" src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/dialog-cancel-4.png"/> '
				// +T('BTN_Cancel','Cancel'),
			// 'type'		: 'button',
			// 'style'		: 'margin-right:0;'
		// }).placeAt(this.widgets.actionBar.containerNode);
		
		// dojo.connect( this.widgets.CancelButton,	'onClick', application.admin.manageAccessPermissions, 'closeDialog');
		// dojo.connect( this.closeButtonNode,			'onClick', application.admin.manageAccessPermissions, 'closeDialog');
		
		// create the main edit pane for the view configuration
		this.widgets.viewEditorTop = new dijit.layout.ContentPane({
			'region'	: 'top',
			'class'		: 'dijitMenuBar',
			'style'		: 'height:35%;'
		});
		this.widgets.borderContainer.addChild(this.widgets.viewEditorTop);

		this.widgets.viewEditorLeft = new dijit.layout.ContentPane({
			'region'	: 'left',
			'class'		: 'dijitMenuBar',
			'content'	: 'left',
			'style'		: 'padding:.5ex;padding-top:1.25em; width:25%;'
		});
		this.widgets.borderContainer.addChild(this.widgets.viewEditorLeft);
				
		this.widgets.viewEditorCenter = new dijit.layout.ContentPane({
			'region'	: 'center',
			'class'		: 'dijitMenuBar',
			'content'	: 'center',
			'style'		: 'padding:.5ex;padding-top:1.25em;'
		});
		this.widgets.borderContainer.addChild(this.widgets.viewEditorCenter);
		
		this.rebuildObjectAccessPermissionGrid();
		
		// insert roles list
		this.buildRoleSelectBlock();
		
	} // end of method postCreate
	,
	'loadObjectAccessPermissionsFromServer' : function () { // ############################
	
		// create the rolesStore
		dojo.xhrPost({
			'url'		: '?'
			,
			'content'	: {
				'v'		: 'JSON_ObjectType',
				'task'	: 'get_OT_objectAccessPermissions', 
				'UUID'	: this.dialogWidget.OT_UUID
			}
			,
			'error'		: function(r,a) {
				try{
					if (typeof (r.responseText)!='undefined') {
						var e=dojo.fromJson(r.responseText);
						application.showErrorMessage(
							'<p><strong>Server error:</strong></p>'+
							'<table><tbody>'+
								'<tr><th>Type</th><td>'+e.type+'</td></tr>'+
								'<tr><th>Message</th><td>'+e.message+'</td></tr>'+
								'<tr><th>Code</th><td>'+e.code+'</td></tr>'+
								'<tr><th>File</th><td>'+e.file+'</td></tr>'+
								'<tr><th>Line</th><td>'+e.line+'</td></tr>'+
								'<tr><th>Trace</th><td><pre>'+e.trace+'</pre></td></tr>'+								
							'<tbody></table>'
							);
					} else {
						application.showErrorMessage('<pre class="small">'+dojo.toJson(r,true)+'</pre>');
					} // end if
				} catch (exception) {
					var errorMessage = '';
					if(r.responsetext) {
						errorMessage = '<p><strong>Server error:</strong></p><pre>'+r.responseText+'</pre>';
					} else {
						errorMessage = '<p><strong>Error:</strong></p><pre>'+exception+'</pre>';
					} // end if
				
					application.showErrorMessage(errorMessage);
				} // end try ... catch
			}, // end of error method
			'handleAs'	: 'json',
			'scope'		: this,
			'load'		: function(response,request){ /* onSuccess */
				
				request.args.scope.dialogWidget.objectAccessPermissionStore = new dojo.data.ItemFileWriteStore({
						'data'			: response, 
						'clearOnClose' 	: true,
						'hierarchical'	: true
					});
				
				// request.args.scope.renumberViewPositions();
				// request.args.scope.outputViewList();
				
			}, // end of onSuccess method
			//preventCache:true,
			//failOk	: true,
			'sync'		: true,
			'timeout'	: 	application.configuration.global.AJAX_default_timeout
		});
			
	} // end of method loadRolesListFromServer
	,
	'rebuildObjectAccessPermissionGrid' : function () {
		if(this.grid_widget) {
			// remove the grid 
			this.removeChild(this.grid_widget);
			
			// delete the grid
			this.grid_widget.destroyRecursive(false);
			delete this.grid_widget;
		} // end if there is tear-down work
			
		var structure =[
						{
							'field': 'UUID',
							'name':	'UUID',
							'width': '300px'
						},
						{
							'field': 'name',
							'name':	T('manageAccessPermissions.js/name_TXT','name'),
							'width': '200px'
						},
						{
							field: 	'readPermission',
							name:	T('manageAccessPermissions.js/readPerm_TXT','Read Permission:'),
							width:	'auto',
							formatter : function(read,rowIndex,cellObj){
								var grid=cellObj.grid, 
									store=grid.store, 
									item=grid.getItem(rowIndex),
									accessPermisionNumber=store.getValue(item,'readPermission');
								
								switch (accessPermisionNumber){
									case -1: accessPermisionString = T('FUT_No','No');
											break;
									case 1: accessPermisionString = T('FUT_Yes','Yes');
											break;
									default : accessPermisionString = '-';
								}
								
								return accessPermisionString;
							} // end of formatter function
						},
						{
							'field': 'writePermission',
							'name':	T('manageAccessPermissions.js/WritePerm_TXT','Write Permission:'),
							'width': 'auto',
							formatter : function(write,rowIndex,cellObj){
								var grid=cellObj.grid, 
									store=grid.store, 
									item=grid.getItem(rowIndex),
									accessPermisionNumber=store.getValue(item,'writePermission');
								
								switch (accessPermisionNumber){
									case -1: accessPermisionString = T('FUT_No','No');
											break;
									case 1: accessPermisionString = T('FUT_Yes','Yes');
											break;
									default : accessPermisionString ='-';
								}
								
								return accessPermisionString;
							} // end of formatter function
						},
						{
							'field': 'deletePermission',
							'name':	T('manageAccessPermissions.js/DeletePerm_TXT','Delete Permission:'),
							'width': 'auto',
							formatter : function(deletePermission,rowIndex,cellObj){
								var grid=cellObj.grid, 
									store=grid.store, 
									item=grid.getItem(rowIndex),
									accessPermisionNumber=store.getValue(item,'deletePermission');
								
								switch (accessPermisionNumber){
									case -1: accessPermisionString = T('FUT_No','No');
											break;
									case 1: accessPermisionString = T('FUT_Yes','Yes');
											break;
									default : accessPermisionString = '-';
								}
								
								return accessPermisionString;
							} // end of formatter function
						},
						{
							'field': 'createPermission',
							'name':	T('manageAccessPermissions.js/CreatePerm_TXT','Create Permission:'),
							'width': 'auto',
							formatter : function(create,rowIndex,cellObj){
								var grid=cellObj.grid, 
									store=grid.store, 
									item=grid.getItem(rowIndex),
									accessPermisionNumber=store.getValue(item,'createPermission');
								
								switch (accessPermisionNumber){
									case -1: accessPermisionString = T('FUT_No','No');
											break;
									case 1: accessPermisionString = T('FUT_Yes','Yes');
											break;
									default : accessPermisionString = '-';
								}
								
								return accessPermisionString;
							} // end of formatter function
						}						
						];
			
		// build the grid
		dojo.require("dojox.grid.EnhancedGrid"); // -- see http://livedocs.dojotoolkit.org/dojox/grid/EnhancedGrid
		// dojo.require("dojox.grid.enhanced.plugins.Pagination"); // -- see http://livedocs.dojotoolkit.org/dojox/grid/EnhancedGrid/plugins/Pagination
		// dojo.require("dojox.grid.enhanced.plugins.Filter"); // -- see http://livedocs.dojotoolkit.org/dojox/grid/EnhancedGrid/plugins/Filter
		// dojo.require("dojox.grid.enhanced.plugins.Menu"); // -- http://livedocs.dojotoolkit.org/dojox/grid/EnhancedGrid/plugins/Menus
		this.widgets.grid_widget = new dojox.grid.EnhancedGrid({
		// this.grid_widget = new dojox.grid.DataGrid({
			'clientSort' 	: true,
			'region' 		: "center",
			'noDataMessage' : T('manageAccessPermissions.js/SorryNoObjAvail_MSG','Sorry, there are no objects available.'),
			'columnReordering' : true,
			'structure'		: structure,
			'query'			: { 'UUID': '*' },
			'store'			: this.dialogWidget.objectAccessPermissionStore,
			'formatterScope': this,
			'title'			: T('manageAccessPermissions.js/ClickOnObjLnk_TXT','Click on an object\'s link to open it. You may sort the columns asc- or descendingly.')
/*                       ,
			'plugins'		: {
				'pagination'	: {
					'description'	: true,
					'sizeSwitch'	: true,
					'pageStepper'	: true,
					'gotoButton'	: true,
					'pageSizes'		: ["25", "50", "100", "All"],
					'maxPageStep'	: 4, 
					'defaultPageSize': 25,
					'defaultPage'	: 1,
					'position'		: 'top' // 'bottom' 
				}, // end pagination plugin defs
				// 'filter'		: {
				// 'closeFilterbarButton': true,// Show the closeFilterbarButton at the filter bar
				// 'ruleCount'			: 5,// Set the maximum rule count to 5
				// 'itemsName'			: "objects"// Set the name of the items
				// }, // end filter plugin defs	
				'menus': {
					// 'headerMenu'		: new dijit.Menu(),
					'rowMenu'			: this.rowMenu,
					// 'cellMenu'			: new dijit.Menu(),
					// 'selectedRegionMenu': new dijit.Menu()
				}, // end menus plugin defs
			} // end plugin defs
*/		});
		
		// add the grid
		this.widgets.GridContainer = new dijit.layout.BorderContainer();
		this.widgets.GridContainer.addChild(this.widgets.grid_widget);
		this.widgets.viewEditorTop.set('content',this.widgets.GridContainer)
		
		// connect the grid events
		dojo.connect(this.widgets.grid_widget,'onRowClick',this,function(e){
			var items = this.widgets.grid_widget.selection.getSelected();
			dojo.forEach(items,function(i){
				this.roleSelected(i);
			},this );
			dojo.stopEvent(e);
		});
		
	} // end of method rebuildGrid
	,
	'buildRoleSelectBlock' : function() {
		
		// this.widgets.fromBorderContainer = new dijit.layout.BorderContainer();
		
		// create roles select block
		this.widgets.rolesFilteringSelect = new dijit.form.FilteringSelect({
					'store' : this.dialogWidget.rolesStore,
					'style' : 'width:95%;'
				});
				
		// this.widgets.fromBorderContainer.addChild(this.widgets.rolesFilteringSelect);
		this.widgets.viewEditorLeft.set('content', this.widgets.rolesFilteringSelect );
		
		// connect the select events
		dojo.connect(this.widgets.rolesFilteringSelect,'onChange',this,function(){
				this.roleSelected(this.widgets.rolesFilteringSelect.item);
			});

		// create button 
		// this.widgets.selectRoleButton = new dijit.form.Button({
						// label: "hello world", 
						// onClick: function(){
								
						// }
				// });
		// this.widgets.fromBorderContainer.addChild(this.widgets.selectRoleButton);
		// this.widgets.viewEditorLeft.set('content', this.widgets.selectRoleButton );
		
		// this.widgets.viewEditorLeft.set('content', this.widgets.fromBorderContainer );
		
		
	} // end of method loadRolesListFromServer
	,
	'roleSelected' : function (item) {
		if (this.dialogWidget.rolesStore.isItem(item))  {

			var O_UUID = this.dialogWidget.rolesStore.getValue(item,'O_UUID');
			var name = this.dialogWidget.rolesStore.getValue(item,'name');

			this.dialogWidget.objectAccessPermissionStore.fetchItemByIdentity({
				'identity'	: O_UUID,
				'scope'		: this,
				'onItem'	: function (i) {
					item = i;
				} // end of function onItem
			});		

			// select the corresponding object in the grid
			var rowIndex = this.widgets.grid_widget.getItemIndex(item);
			if ( rowIndex >= 0 ) { 
				this.widgets.grid_widget.selection.select(rowIndex);
			};
		} 

		// select the corresponding object in the select
		if ( !rowIndex ) {
			this.widgets.rolesFilteringSelect.set('value', this.dialogWidget.objectAccessPermissionStore.getValue(item, 'UUID') );
		}
		
		// get item for editing of access permissions from this.dialogWidget.objectAccessPermissionStore
		var c = {};
                if ( this.dialogWidget.objectAccessPermissionStore.isItem(item) ) {
			 c = {
						'UUID'				: this.dialogWidget.objectAccessPermissionStore.getValue(item,'UUID'), /*UUID is the O_UUID of the role object*/
						'name'				: this.dialogWidget.objectAccessPermissionStore.getValue(item,'name'),
						'readPermission'	: this.dialogWidget.objectAccessPermissionStore.getValue(item,'readPermission'),
						'writePermission'	: this.dialogWidget.objectAccessPermissionStore.getValue(item,'writePermission'),
						'deletePermission'	: this.dialogWidget.objectAccessPermissionStore.getValue(item,'deletePermission'),
						'createPermission'	: this.dialogWidget.objectAccessPermissionStore.getValue(item,'createPermission'),
						'parentWidget'		: this,
						'type'				: 'objectsPane'
					};
		} else { // new role
			 c = {
						'UUID'				: O_UUID, /*UUID is the O_UUID of the role object*/
						'name'				: name,
						'parentWidget'		: this,
						'type'				: 'objectsPane'
					};
		}
		
		this.setContentToEditArea(c);
		
	} // end of method roleSelected
	,
	'setContentToEditArea' : function (config) {
		
		if (this.widgets.objectPermisionEditArea) this.widgets.objectPermisionEditArea.destroyRecursive();
		
		if(config){
			this.widgets.objectPermisionEditArea = new application.widgets.manageAccessPermissions_permissionEditor_editArea(config);
		} else {
			this.widgets.objectPermisionEditArea = new dijit.layout.ContentPane({
				'content' : '<p>' + T('manageAccessPermissions.js/PleaseSelectRole_TXT','Please select role for editing the access permissions.') + '</p>'
			});
			
			// deselect the items in the grid and the filtering select
			this.widgets.grid_widget.selection.deselectAll();
			this.widgets.rolesFilteringSelect.reset();

		}
		
		this.widgets.viewEditorCenter.set('content', this.widgets.objectPermisionEditArea);

	} // end of method setEditArea
	,
	'changeRolePermissions' : function (l) {
		this.editingLevel = l;
		this.valueHasChanged('editingLevel');
	} // end of method changeRolePermissions
	,
	'saveChanges' : function (newItem) {
		var item = {};
		this.dialogWidget.objectAccessPermissionStore.fetchItemByIdentity({
			'identity'	: newItem.UUID,
			'scope'		: this,
			'onItem'	: function (i) {
				item = i;				
			} // end of function onItem
		}); // end get the item

		if (this.dialogWidget.objectAccessPermissionStore.isItem(item)){
			// set the values to the store
			this.dialogWidget.objectAccessPermissionStore.setValue(item,'readPermission', newItem.readPermission); 
			this.dialogWidget.objectAccessPermissionStore.setValue(item,'writePermission', newItem.writePermission); 
			this.dialogWidget.objectAccessPermissionStore.setValue(item,'deletePermission', newItem.deletePermission); 
			this.dialogWidget.objectAccessPermissionStore.setValue(item,'createPermission', newItem.createPermission); 
		} else { // add new item to the store
			this.dialogWidget.objectAccessPermissionStore.newItem(newItem);
		}

		// save the changes in the store
		this.dialogWidget.objectAccessPermissionStore.save();
		
		//clear edit area
		this.setContentToEditArea();
		
	} // end of method deleteRole
	,
	'deleteRole' : function (UUID) {
		this.dialogWidget.objectAccessPermissionStore.fetchItemByIdentity({
			'identity'	: UUID,
			'scope'		: this,
			'onItem'	: function (item) {
				this.dialogWidget.objectAccessPermissionStore.deleteItem(item);				
			} // end of function onItem
		}); // end get the item
		
		// save the changes in the store
		this.dialogWidget.objectAccessPermissionStore.save();
		
		//clear edit area
		this.setContentToEditArea();
		
	} // end of method deleteRole
	
});

// the widget for editing view access permission properties
dojo.declare('application.widgets.manageAccessPermissions_permissionEditor_viewsPane', [application.widgets.manageAccessPermissions_permissionEditor_template],{
	/*constructor : function() {
		// Your constructor method will be called before the parameters are mixed into the widget, and can be used to initialize arrays, etc.
		this.inherited(arguments);
	} // end of method constructor
	,*/
	'postMixInProperties' : function () {
		this.inherited(arguments);
		
		this.templateString = '<div>' // this template is invalid without this DIV tag
			
			+'<table class="fullWidth listWithRows arrangement3070">'
						
			+'</table>'
			
			+'</div>'
			
	} // end of method postMixInProperties
	,
	'name_changed' : function () {
		if(this.nameInput_widget.isValid()) {
			this.name = this.nameInput_widget.attr('value');
			this.valueHasChanged('name');
		} // end if
	} // end of method name_changed
	,
	'description_changed' : function () {
		this.descriptionOfThisView = this.descriptionOfThisView_widget.attr('value');
		this.valueHasChanged('descriptionOfThisView');
	} // end of method name_changed
	,
	'replaceDescrWithParentDescr' : function (){
		this.descriptionOfThisView=this.descriptionOfParentView;
		this.descriptionOfThisView_widget.attr('value', this.descriptionOfThisView);
		
		// tell the dialog that the description has changed
		this.valueHasChanged('descriptionOfThisView');
		
	} // end of method replaceDescrWithParentDescr
	,
	'editingLevel_changed' : function (l) {
		this.editingLevel = l;
		this.valueHasChanged('editingLevel');
	} // end of method editingLevel_changed
	,
	'searchPoints_changed' : function () {
		if(this.searchPoints_widget.isValid()) {
			this.searchPoints = this.searchPoints_widget.attr('value');
			this.valueHasChanged('searchPoints');
		} // end if
	} // end of method searchPoints_changed
	
});

// the widget for editing attribute access permission properties
dojo.declare('application.widgets.manageAccessPermissions_permissionEditor_attributesPane', [application.widgets.manageAccessPermissions_permissionEditor_template],{
	/*constructor : function() {
		// Your constructor method will be called before the parameters are mixed into the widget, and can be used to initialize arrays, etc.
		this.inherited(arguments);
	} // end of method constructor
	,*/
	'postMixInProperties' : function () {
		this.inherited(arguments);

		// editing level
		this.editingLevel_0_checked	= 'false';
		this.editingLevel_1_checked	= 'false';
		this.editingLevel_2_checked	= 'false';
		switch (this.editingLevel) {
			case 1: // read only
				this.editingLevel_1_checked='true';
				break;
			case 2: // invisible
				this.editingLevel_2_checked='true';
				break;
			case 0: // visible and editable
			default:
				this.editingLevel_0_checked='true'; 
		} // end switch editing level
		
		this.templateString = '<div>' // this template is invalid without this DIV tag
					
			+(this.isInherited?''
					+'<p>'
						+ T('manageAccessPermissions.js/InheritedView_HTM','This view is <i>inherited</i>. It is defined at the object type « ${viewDefinedAt}» . Hence, certain properties need to be modified, there.')
					+'</p>'
					+'<p>&nbsp;</p>'
				:'')
			
			+'<table class="fullWidth listWithRows arrangement3070">'
			
				+'<tr>'
					+'<th>'
						+ T('FUT_Property','Property')
					+'</th>'
					+'<th>'
						+ T('FUT_Value','Value')
					+'</th>'
				+'</tr>'

				// Name
				+'<tr>'
					+'<th>'
						+ T('FUT_Name','Name')
					+'</th>'
					+'<td>'
						+'<input type="text" name="name" value="${name}"'
							+'dojoType="dijit.form.ValidationTextBox" '
							+'class="fullWidth" '
							+'regExp=".{3,}" '
							+'required="true" '
							+'selectOnClick="true" '
							+'intermediateChanges="true" '
							+'dojoAttachEvent="onChange:name_changed" '
							+'dojoAttachPoint="nameInput_widget" '
							+'invalidMessage="' + T('manageAccessPermissions.js/ViewNameInput_MSG','The view name needs to have a length of at least 3 chars.') +'" '
							+'disabled="${isInherited}" '
							+'/>'
					+'</td>'
				+'</tr>'
				
			+(this.isInherited?''
					+'<tr>'
						+'<th>'
							+ T('manageAccessPermissions.js/InheritChain_TXT','Inheritance chain')
						+'</th>'
						+'<td>'
							+this.inheritanceChain.join(' '+this.dialogWidget.inheritedChar+' ')
						+'</td>'
					+'</tr>'
				
					+'<tr>'
						+'<th>'
							+ T('manageAccessPermissions.js/DescrParentView_HTM','Description of the <i>parent</i> view')
						+'</th>'
						+'<td>'
							+'<textarea name="description" '
								+'dojoType="dijit.form.Textarea" '
								+'class="fullWidth" '
								+'disabled="true" '
								+'>${descriptionOfParentView}</textarea>'
						+'</td>'
					+'</tr>'
				:'')
				
				// Description
				+'<tr>'
					+'<th>'
						+ T('FUT_Description','Description')
			+(this.isInherited?''
						+ ' ' + T('manageAccessPermissions.js/OfThisView_HTM','of <i>this</i> view')
				:'')
					+'</th>'
					+'<td>'
						+'<textarea name="description" '
							+'dojoType="dijit.form.Textarea" '
							+'class="fullWidth" '
							+'disabled="false" '
							+'dojoAttachPoint="descriptionOfThisView_widget" '
							+'intermediateChanges="true" '
							+'dojoAttachEvent="onChange:description_changed" '
							+'>${descriptionOfThisView}</textarea>'
							
			+(this.isInherited?''
						+'<p class="small">'
							+'<a style="cursor:pointer;" dojoAttachEvent="onclick:replaceDescrWithParentDescr">' + T('manageAccessPermissions.js/ClickToReplDescrWParentV_TXT','Click here to replace this description with the parent view\'s description.') + '</a>'
						+'</p>'
				:'')
						
					+'</td>'
				+'</tr>'
				
				+'<tr>'
					+'<th>'
						+'View UUID'
					+'</th>'
					+'<td>'
						+'<input type="text" value="${V_UUID}"'
							+'dojoType="dijit.form.ValidationTextBox" '
							+'class="fullWidth code" '
							+'selectOnClick="true" '
							+'readOnly="true" '
							+'/>'
					+'</td>'
				+'</tr>'
				
				// Read & Edit
				+'<tr>'
					+'<th>'
						+ T('manageAccessPermissions.js/ReadEdit_TXT','Read & Edit')
					+'</th>'
					+'<td>'
						+'<div dojoType="dijit.form.Form">'
							+'<p><label>'
								+'<input type="radio" dojoType="dijit.form.RadioButton" '
									+'name="editingLevel" '
									+'value="0" '
									+'checked="${editingLevel_0_checked}"  '
									+'disabled="${isInherited}" '
									+'dojoAttachEvent="onChange:editingLevel_changed" '
								+'/> '
								+ T('manageAccessPermissions.js/VisAndEditable_TXT','visible and editable')
							+'</label></p>'

							+'<p><label>'
								+'<input type="radio" dojoType="dijit.form.RadioButton" '
									+'name="editingLevel" '
									+'value="1" '
									+'checked="${editingLevel_1_checked}"  '
									+'disabled="${isInherited}" '
								+'/> '
								+ T('manageAccessPermissions.js/VisAndReadOnly_TXT','visible and read-only (e.g. for forms or reports to be printed)')
							+'</label></p>'

							+'<p><label>'
								+'<input type="radio" dojoType="dijit.form.RadioButton" '
									+'name="editingLevel" '
									+'value="2" '
									+'checked="${editingLevel_2_checked}"  '
									+'disabled="${isInherited}" '
								+'/> '
								+ T('manageAccessPermissions.js/Invis_TXT','invisible (e.g. for name views)')
							+'</label></p>'
						+'</div>'
					+'</td>'
				+'</tr>'
				
				+'<tr>'
					+'<th>'
						+ T('manageAccessPermissions.js/SearchResPts_TXT','Search result points')
					+'</th>'
					+'<td>'
						+'<input dojoType="dijit.form.NumberSpinner" '
							+'value="${searchPoints}" '
							+'smallDelta="1" '
							+'constraints="{min:0,max:100,places:0}" '
							+'intermediateChanges="true" '
							+'dojoAttachEvent="onChange:searchPoints_changed" '
							+'dojoAttachPoint="searchPoints_widget" '
							+'class="fullWidth" '
							+'disabled="${isInherited}" '
						+'/>'
					+'</td>'
				+'</tr>'
				
			+'</table>'
			
			+'</div>'
			
	} // end of method postMixInProperties
	,
	'name_changed' : function () {
		if(this.nameInput_widget.isValid()) {
			this.name = this.nameInput_widget.attr('value');
			this.valueHasChanged('name');
		} // end if
	} // end of method name_changed
	,
	'description_changed' : function () {
		this.descriptionOfThisView = this.descriptionOfThisView_widget.attr('value');
		this.valueHasChanged('descriptionOfThisView');
	} // end of method name_changed
	,
	'replaceDescrWithParentDescr' : function (){
		this.descriptionOfThisView=this.descriptionOfParentView;
		this.descriptionOfThisView_widget.attr('value', this.descriptionOfThisView);
		
		// tell the dialog that the description has changed
		this.valueHasChanged('descriptionOfThisView');
		
	} // end of method replaceDescrWithParentDescr
	,
	'editingLevel_changed' : function (l) {
		this.editingLevel = l;
		this.valueHasChanged('editingLevel');
	} // end of method editingLevel_changed
	,
	'searchPoints_changed' : function () {
		if(this.searchPoints_widget.isValid()) {
			this.searchPoints = this.searchPoints_widget.attr('value');
			this.valueHasChanged('searchPoints');
		} // end if
	} // end of method searchPoints_changed
	
});

// the widget build the editing area
dojo.declare('application.widgets.manageAccessPermissions_permissionEditor_editArea',[dijit._Widget,dijit._Templated],{
	widgetsInTemplate: true
	,
	// this variables need to be set on initialisation
	UUID				: '', // UUID is the O_UUID of the role object
	name				: '',
	readPermission		: 0,
	writePermission		: 0,
	deletePermission	: 0,
	createPermission	: 0,
	parentWidget			: '', // need to be set by declaration
	type				: '', // possible options could be "objectsPane", "viewsPane", "attributesPane"
	
	'templateString' : ""
			+"<div class='RS_attributeConfig_section'>"
				+"<h3>${title}</h3>"
				+"<table class='fullWidth arrangement3070 listWithRows'><tbody>"
							
					+"<tr>"
						+"<td class='textRight' style='vertical-align:top;'>Read Permission</td>"
						+"<td>"
							+"<label>"
								+"<input type='radio' dojoType='dijit.form.RadioButton' "
									+"name='application.admin.manageAccessPermissions.dialog.readPermission' "
									+"onfocus='application.admin.manageAttributes.showEditHints();' "
									+"dojoAttachEvent='onClick:rB_readPermission_changed' "
									+"value='false' "
									+" dojoAttachPoint='radioButton_readPermission_yes'/>"
									+ T('FUT_Yes','Yes')
							+"</label>"
							+"&nbsp;&nbsp;"
							+"<label>"
								+"<input type='radio' dojoType='dijit.form.RadioButton' "
									+"name='application.admin.manageAccessPermissions.dialog.readPermission' "
									+"onfocus='application.admin.manageAttributes.showEditHints();' "
									+"dojoAttachEvent='onClick:rB_readPermission_changed' "
									+"value='true'  dojoAttachPoint='radioButton_readPermission_notSet' />"
									+ T('FUT_NotSet','not set')
							+"</label>"	
							+"&nbsp;&nbsp;"
							+"<label>"
								+"<input type='radio' dojoType='dijit.form.RadioButton' "
									+"name='application.admin.manageAccessPermissions.dialog.readPermission' "
									+"onfocus='application.admin.manageAttributes.showEditHints();' "
									+"dojoAttachEvent='onClick:rB_readPermission_changed' "
									+"value='false'  dojoAttachPoint='radioButton_readPermission_no' />"
									+ T('FUT_No','No')
							+"</label>"
						+"</td>"
					+"</tr>"
				
					+"<tr>"
						+"<td class='textRight'>" + T('manageAccessPermissions.js/WritePerm_TXT','Write Permission:') + "</td>"
						+"<td>"
							+"<label>"
								+"<input type='radio' dojoType='dijit.form.RadioButton' "
									+"name='application.admin.manageAccessPermissions.dialog.writePermission' "
									+"onfocus='application.admin.manageAttributes.showEditHints();' "
									+"dojoAttachEvent='onClick:rB_writePermission_changed' "
									+"value='true' "
									+" dojoAttachPoint='radioButton_writePermission_yes'/>"
									+ T('FUT_Yes','Yes')
							+"</label>"
							+"&nbsp;&nbsp;"
							+"<label>"
								+"<input type='radio' dojoType='dijit.form.RadioButton' "
									+"name='application.admin.manageAccessPermissions.dialog.writePermission' "
									+"onfocus='application.admin.manageAttributes.showEditHints();' "
									+"dojoAttachEvent='onClick:rB_writePermission_changed' "
									+"value='false'  dojoAttachPoint='radioButton_writePermission_notSet' />"
									+ T('FUT_NotSet','not set')
							+"</label>"	
							+"&nbsp;&nbsp;"
							+"<label>"
								+"<input type='radio' dojoType='dijit.form.RadioButton' "
									+"name='application.admin.manageAccessPermissions.dialog.writePermission' "
									+"onfocus='application.admin.manageAttributes.showEditHints();' "
									+"dojoAttachEvent='onClick:rB_writePermission_changed' "
									+"value='false'  dojoAttachPoint='radioButton_writePermission_no' />"
									+ T('FUT_No','No')
							+"</label>"
						+"</td>"
					+"</tr>"
					
					+"<tr> "
						+"<td class='textRight'>" + T('manageAccessPermissions.js/DeletePerm_TXT','Delete Permission:') + "</td>"
						+"<td>"
							+"<label>"
								+"<input type='radio' dojoType='dijit.form.RadioButton' "
									+"name='application.admin.manageAccessPermissions.dialog.deletePermission' "
									+"onfocus='application.admin.manageAttributes.showEditHints();' "
									+"dojoAttachEvent='onClick:rB_deletePermission_changed' "
									+"value='true' "
									+" dojoAttachPoint='radioButton_deletePermission_yes'/>"
									+ T('FUT_Yes','Yes')
							+"</label>"
							+"&nbsp;&nbsp;"
							+"<label>"
								+"<input type='radio' dojoType='dijit.form.RadioButton' "
									+"name='application.admin.manageAccessPermissions.dialog.deletePermission' "
									+"onfocus='application.admin.manageAttributes.showEditHints();' "
									+"dojoAttachEvent='onClick:rB_deletePermission_changed' "
									+"value='false'  dojoAttachPoint='radioButton_deletePermission_notSet' />"
									+ T('FUT_NotSet','not set')
							+"</label>"	
							+"&nbsp;&nbsp;"
							+"<label>"
								+"<input type='radio' dojoType='dijit.form.RadioButton' "
									+"name='application.admin.manageAccessPermissions.dialog.deletePermission' "
									+"onfocus='application.admin.manageAttributes.showEditHints();' "
									+"dojoAttachEvent='onClick:rB_deletePermission_changed' "
									+"value='false'  dojoAttachPoint='radioButton_deletePermission_no' />"
									+ T('FUT_No','No')
							+"</label>"
						+"</td>"
					+"</tr>"
					
					+"<tr>"
						+"<td class='textRight'>" + T('manageAccessPermissions.js/CreatePerm_TXT','Create Permission:') + "</td>"
						+"<td>"
							+"<label>"
								+"<input type='radio' dojoType='dijit.form.RadioButton' "
									+"name='application.admin.manageAccessPermissions.dialog.createPermission' "
									+"onfocus='application.admin.manageAttributes.showEditHints();' "
									+"dojoAttachEvent='onClick:rB_createPermission_changed' "
									+"value='true' "
									+" dojoAttachPoint='radioButton_createPermission_yes'/>"
									+ T('FUT_Yes','Yes')
							+"</label>"
							+"&nbsp;&nbsp;"
							+"<label>"
								+"<input type='radio' dojoType='dijit.form.RadioButton' "
									+"name='application.admin.manageAccessPermissions.dialog.createPermission' "
									+"onfocus='application.admin.manageAttributes.showEditHints();' "
									+"dojoAttachEvent='onClick:rB_createPermission_changed' "
									+"value='false'  dojoAttachPoint='radioButton_createPermission_notSet' />"
									+ T('FUT_NotSet','not set')
							+"</label>"	
							+"&nbsp;&nbsp;"
							+"<label>"
								+"<input type='radio' dojoType='dijit.form.RadioButton' "
									+"name='application.admin.manageAccessPermissions.dialog.createPermission' "
									+"onfocus='application.admin.manageAttributes.showEditHints();' "
									+"dojoAttachEvent='onClick:rB_createPermission_changed' "
									+"value='false'  dojoAttachPoint='radioButton_createPermission_no' />"
									+ T('FUT_No','No')
							+"</label>"
						+"</td>"
					+"</tr>"
					
				+"</tbody></table>"
				+"<table class='fullWidth arrangement3070 listWithRows'><tbody>"
							
					+"<tr>"
						+"<td class='textRight' style='vertical-align:top;'>"
							+"<button dojoType='dijit.form.Button' "
								+"dojoAttachEvent='onClick:b_savePermissions' "
								+">Save \"${name}\"</button>"
						+"</td>"
						+"<td>"
							+"<button dojoType='dijit.form.Button' "
								+"dojoAttachEvent='onClick:b_deleteRole' "
								+">Delete \"${name}\" from List</button>"
						+"</td>"
					+"</tr>"
				+"</tbody></table>"
			+"</div>"
	,
	postMixInProperties: function () {
		this.inherited(arguments);
		
		if ( this.name !='') this.title = T('manageAccessPermissions.js/DefAccPermFor_TIT','Defining access permissions for "$[0]" ',[this.name]);
		
	} // end of method postMixInProperties
	,
	postCreate : function() {
		// This is typically the workhorse of a custom widget. The widget has 
		// been rendered (but note that sub-widgets in the containerNode have not!). 
		// The widget though may not be attached to the DOM yet so you shouldn't 
		// do any sizing calculations in this method.
		this.inherited(arguments);
		
		// set the radio button check options, correctly
		// read permission
		if( this.readPermission == 1 ) {
			this.radioButton_readPermission_yes.attr('checked',true);
			this.radioButton_readPermission_notSet.attr('checked',false);
			this.radioButton_readPermission_no.attr('checked',false);
		} else if (this.readPermission == -1 ) {
			this.radioButton_readPermission_yes.attr('checked',false);
			this.radioButton_readPermission_notSet.attr('checked',false);
			this.radioButton_readPermission_no.attr('checked',true);
		} else {
			this.radioButton_readPermission_yes.attr('checked',false);
			this.radioButton_readPermission_notSet.attr('checked',true);
			this.radioButton_readPermission_no.attr('checked',false);
		}// end if 

		// write permission		
		if( this.writePermission == 1 ) {
			this.radioButton_writePermission_yes.attr('checked',true);
			this.radioButton_writePermission_notSet.attr('checked',false);
			this.radioButton_writePermission_no.attr('checked',false);
		} else if (this.writePermission == -1 ) {
			this.radioButton_writePermission_yes.attr('checked',false);
			this.radioButton_writePermission_notSet.attr('checked',false);
			this.radioButton_writePermission_no.attr('checked',true);
		} else {
			this.radioButton_writePermission_yes.attr('checked',false);
			this.radioButton_writePermission_notSet.attr('checked',true);
			this.radioButton_writePermission_no.attr('checked',false);
		}// end if 
		
		// delete permission
		if( this.deletePermission == 1 ) {
			this.radioButton_deletePermission_yes.attr('checked',true);
			this.radioButton_deletePermission_notSet.attr('checked',false);
			this.radioButton_deletePermission_no.attr('checked',false);
		} else if (this.deletePermission == -1 ) {
			this.radioButton_deletePermission_yes.attr('checked',false);
			this.radioButton_deletePermission_notSet.attr('checked',false);
			this.radioButton_deletePermission_no.attr('checked',true);
		} else {
			this.radioButton_deletePermission_yes.attr('checked',false);
			this.radioButton_deletePermission_notSet.attr('checked',true);
			this.radioButton_deletePermission_no.attr('checked',false);
		}// end if 
		
		// create permission
		if( this.createPermission == 1 ) {
			this.radioButton_createPermission_yes.attr('checked',true);
			this.radioButton_createPermission_notSet.attr('checked',false);
			this.radioButton_createPermission_no.attr('checked',false);
		} else if (this.createPermission == -1 ) {
			this.radioButton_createPermission_yes.attr('checked',false);
			this.radioButton_createPermission_notSet.attr('checked',false);
			this.radioButton_createPermission_no.attr('checked',true);
		} else {
			this.radioButton_createPermission_yes.attr('checked',false);
			this.radioButton_createPermission_notSet.attr('checked',true);
			this.radioButton_createPermission_no.attr('checked',false);
		}// end if 
			
	} // end of method postCreate
	,
	rB_readPermission_changed: function (){
		if ( this.radioButton_readPermission_yes.get('value') ){
			this.readPermission = 1;
		} else if (this.radioButton_readPermission_no.get('value')) {
			this.readPermission = -1;
		} else {
			this.readPermission = 0;
		}
	}
	,
	rB_writePermission_changed: function (){
		if ( this.radioButton_writePermission_yes.get('value') ){
			this.writePermission = 1;
		} else if (this.radioButton_writePermission_no.get('value')) {
			this.writePermission = -1;
		} else {
			this.writePermission = 0;
		}
	}
	,
	rB_deletePermission_changed: function (){
		if ( this.radioButton_deletePermission_yes.get('value') ){
			this.deletePermission = 1;
		} else if (this.radioButton_deletePermission_no.get('value')) {
			this.deletePermission = -1;
		} else {
			this.deletePermission = 0;
		}
	}
	,
	rB_createPermission_changed: function (){
		if ( this.radioButton_createPermission_yes.get('value') ){
			this.createPermission = 1;
		} else if (this.radioButton_createPermission_no.get('value')) {
			this.createPermission = -1;
		} else {
			this.createPermission = 0;
		}
	}
	,
	b_savePermissions: function (){
		var newItem = {
						'UUID' 				: this.UUID,
						'name' 				: this.name,
						'readPermission' 	: this.readPermission,
						'writePermission' 	: this.writePermission,
						'deletePermission' 	: this.deletePermission,
						'createPermission' 	: this.createPermission
					};
		this.parentWidget.saveChanges(newItem);
	}
	,
	b_deleteRole: function (){
		this.parentWidget.deleteRole(this.UUID);
	}
});

// register the right click menu option
// application.admin.adminPane_rightClickMenu.addOption(
	// 'Manage <strong>access permissions (NEW)</strong>', 
	// function(){application.admin.manageAccessPermissions.showDialog();},
	// 'rsIcon_manageAccessPermissions', 
	// function ( item_type ) {return (item_type!='OT'?true:false);}
// );

