/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare('application.widgets.menuItemEditor', [dijit.layout.ContentPane], {
	
	// these slots need to be passed on instantiation #############################################
	'menuItem'			: null, // {}
	'completeMenuBar'	: null, // []

	// internal slots #############################################################################
	'_widgets'	: null, // {}

	// widget life cycle ##########################################################################
	'constructor' : function () {
	
		// initialisations
		this._widgets = {};
	
	} // end of method constructor
	,
	'content' : ''
		+'<p>&nbsp;</p>'
		+'<table class="compact" style="mind-width:30em;max-width:50em;">'
			+'<tr>'
				+'<td style="width:30%;" class="textRight">'
					+T(	'configureMenuBars.js/menuItemLabel_TXT',
						'Menu item label:'
						)
				+'</td>'
				+'<td>'
					+'<div class="_label_domNode"></div>'
				+'</td>'
			+'</tr>'
			+'<tr>'
				+'<td style="width:30%;" class="textRight">'
				+'</td>'
				+'<td>'
				+'</td>'
			+'</tr>'
			+'<tr>'
				+'<td style="width:30%;" class="textRight">'
					+T(	'configureMenuBars.js/menuItemconfigOptions_TXT',
						'Configuration options:'
						)
				+'</td>'
				+'<td>'
					+'<p class="_execCommandCB_domNode">'
						+T(	'configureMenuBars.js/execCommand_TXT',
							'When opening the type, execute the command that is assigned to this menu item kind'
							)
					+'</p>'
				+'</td>'
			+'</tr>'
			+'<tr>'
				+'<td style="width:30%;" class="textRight">'
					+T(	'configureMenuBars.js/actions_TXT',
						'Actions:'
						)
				+'</td>'
				+'<td>'
					+'<p>'
						+'<img '
								+'class="_moveUp_domNode" '
								+'style="cursor:pointer" '
								+'title="'
									+T(	'configureMenuBars.js/menuItemUp_TXT',
										'Move this menu item up.'
										)
									+'" '
								+'src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/go-up-7.png"'
							+'/>'
						+'<img '
								+'class="_moveDown_domNode" '
								+'style="cursor:pointer" '
								+'title="'
									+T(	'configureMenuBars.js/menuItemDown_TXT',
										'Move this menu item down.'
										)
									+'" '
								+'src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/go-down-7.png"'
							+'/>'
						+'<img '
								+'class="_moveLeft_domNode" '
								+'style="cursor:pointer" '
								+'title="'
									+T(	'configureMenuBars.js/menuItemLeft_TXT',
										'Move this menu item to the left.'
										)
									+'" '
								+'src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/go-previous-7.png"'
							+'/>'
						+'<img '
								+'class="_moveRight_domNode" '
								+'style="cursor:pointer" '
								+'title="'
									+T(	'configureMenuBars.js/menuItemRight_TXT',
										'Move this menu item to the right.'
										)
									+'" '
								+'src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/go-next-7.png"'
							+'/>'
						+'&nbsp;'
						+'&nbsp;'
						+'&nbsp;'
						+'<img '
								+'class="_delIMG_domNode" '
								+'style="cursor:pointer" '
								+'title="'
									+T(	'configureMenuBars.js/menuItemDelete_TXT',
										'Delete this menu item.'
										)
									+'" '
								+'src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/dialog-cancel-4.png"'
							+'/>'
					+'</p>'
					+'<p>'
						+'<span class="_includeInDDMenu_domNode"></span>'
					+'</p>'
				+'</td>'
			+'</tr>'
			+'<tr>'
				+'<td style="width:30%;" class="textRight">'
					+T(	'configureMenuBars.js/description_TXT',
						'Description:'
						)
				+'</td>'
				+'<td>'
					+'<div class="_description_domNode"></div>'
				+'</td>'
			+'</tr>'
			+'<tr>'
				+'<td style="width:30%;" class="textRight">'
					+T(	'configureMenuBars.js/specialOptions_TXT',
						'Specific options:'
						)
				+'</td>'
				+'<td class="_specificOptions_domNode">'
				+'</td>'
			+'</tr>'
		+'</table>'
	,
	'postCreate' : function () {
		this.inherited(arguments);
	
		// localise all important DOM nodes
		dojo.forEach([
			'_label_domNode',
			'_execCommandCB_domNode',
			'_delIMG_domNode',
			'_moveUp_domNode',
			'_moveDown_domNode',
			'_moveLeft_domNode',
			'_moveRight_domNode',
			'_includeInDDMenu_domNode',
			'_description_domNode',
			'_specificOptions_domNode',
		], function (s) {
			if(!s) return; // Internet explorer bug fix
			this[s]=dojo.query('.'+s, this.containerNode).pop();
		}, this); // end dojo.forEach
	
		// set up the text box for the label
		this._widgets.labelVTB = new dijit.form.ValidationTextBox({
			'class'				: 'fullWidth',
			'regexp'			: '.{2,}',
			'value'				: this.menuItem.label,
			'selectOnClick'		: true,
			'intermediateChanges': true,
		}).placeAt(this._label_domNode);
		this.connect( this._widgets.labelVTB, 'onChange', '_configChanged' );
		
		// set up the check box for the command execution when creating the type widget
		this._widgets.commandExecB = new dijit.form.CheckBox({
			'style'				: 'margin-right:.5ex',
			'value'				: true,
			'checked'			: this.menuItem.label.openByDefault,
		}).placeAt(this._execCommandCB_domNode, 'first');
		this.connect( this._widgets.commandExecB, 'onChange', '_configChanged' );
		
		// set up the widget for including the current menu item in a popup/drop-down menu
		this._widgets.dropDownB = new dijit.form.DropDownButton({
            'label'		: ''
				+T(	'configureMenuBars.js/includeInDDMenu_BTN',
						'Include in drop.down menu …'
						),
            'dropDown'	: new dijit.Menu,
        });
		
		// iterate over all menu bar items and add drop down menus to the drop down button
		dojo.forEach( this.completeMenuBar, function (mi) {
			if (!mi) return; // internet explorer bug fix
		
			if (mi.type=='dijit.PopupMenuBarItem') {
				this._widgets.mi['dDI_'+mi.label] = new dijit.MenuItem({
					'label'		: mi.label,
					'menuItem'	: mi,
					'onClick'	: function (e) {
						dojo.stopEvent(e)
						
						this.includeInPopupMenu(this.mi);
						
					} // end of method onClick
					,
					
					// Event definitions
					'includeInPopupMenu' : function (menuItem) {},
					
				}).placeAt( this._widgets.dropDownB.dropDown );
				this.connect( this._widgets.mi['dDI_'+mi.label], 'includeInPopupMenu', '_includeInPopupMenu' );
			
			} // end if
		
		}, this); // end dojo.forEach
		
		// connect the clickable images to internal events
		this.connect( this._delIMG_domNode, 	'onclick', '_deleteMenuItem_clicked');
		this.connect( this._moveUp_domNode, 	'onclick', '_moveMenuItemUp_clicked');
		this.connect( this._moveDown_domNode, 	'onclick', '_moveMenuItemDown_clicked');
		this.connect( this._moveLeft_domNode, 	'onclick', '_moveMenuItemLeft_clicked');
		this.connect( this._moveRight_domNode,	'onclick', '_moveMenuItemRight_clicked');
		
		// locate the description
		
		
		
		
		
		
		
		
		
		
		// offer specific options
	
	
		dojo.attr(this._specificOptions_domNode, 'innerHTML', ''
			+'<pre style="overflow:auto;">'
				+dojo.toJson(this.menuItem, true)
			+'</pre>'
		);
	
	} // end of method postCreate
	,
	'destroy' : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		
		for (var i in this._widgets) {
			if (this.widgets[i].destroyRecursive) this._widgets[i].destroyRecursive(false);
			delete this._widgets[i];
		} // end for .. in
		
		this.inherited(arguments);
	} // end of method destroy
	,
	
	
	// internal methods ##########################################################################
	'_configChanged' : function () {
	
		// update the configuration ...
		if( this._widgets.labelVTB.isValid() ) this.menuItem.label = this._widgets.labelVTBget('value');
		this.menuItem.label.openByDefault = this._widgets.commandExecB.get('checked');
		
		// ... and send a notification event 
		this.menuConfig_changed( this.menuItem );
		
	} // end of method _configChanged
	,
	'_includeInPopupMenu' 		: function (targetPopup) {
		// call the corresponding event
		this.includeMenuItemInDD(targetPopup, this.menuItem);
	} // end of method _includeInPopupMenu
	,
	'_deleteMenuItem_clicked'	: function (e) {
		dojo.stopEvent(e);
		this.deleteMenuItem(this.menuItem);
	} // end of method _deleteMenuItem_clicked
	,
	'_moveMenuItemUp_clicked'	: function (e) {
		dojo.stopEvent(e);
		this.moveMenuItem_up(this.menuItem);
	} // end of method _moveMenuItemUp_clicked
	,
	'_moveMenuItemDown_clicked'	: function (e) {
		dojo.stopEvent(e);
		this.moveMenuItem_down(this.menuItem);
	} // end of method _moveMenuItemDown_clicked
	,
	'_moveMenuItemLeft_clicked'	: function (e) {
		dojo.stopEvent(e);
		this.moveMenuItem_left(this.menuItem);
	} // end of method _moveMenuItemLeft_clicked
	,
	'_moveMenuItemRight_clicked': function (e) {
		dojo.stopEvent(e);
		this.moveMenuItem_right(this.menuItem);
	} // end of method _moveMenuItemRight_clicked
	,
	
	// Events ####################################################################################
	'menuConfig_changed'	: function (menuItem) {},
	'deleteMenuItem'		: function (menuItem) {},
	'moveMenuItem_left'		: function (menuItem) {},
	'moveMenuItem_up'		: function (menuItem) {},
	'moveMenuItem_down'		: function (menuItem) {},
	'moveMenuItem_right'	: function (menuItem) {},
	'includeMenuItemInDD'	: function (menuItem) {},
	
	// Options for dijit.layout.ContentPane ######################################################
	'style'	: 'margin:.5ex;',
});

dojo.declare('application.widgets.menuBarEditor', [dijit.layout.BorderContainer], {
	
	// these slots need to be passed on instantiation
	'availableMenuItemKinds'	: null, // []
	'menuBar'					: null, // []
	
	// internal slots
	'_currentMenuItemWidget'	: null,

	
	// widget life cycle ##########################################################################
	'constructor' : function () {
	
		// some initialisations
		this.OT_UUID 				= '';
		this.availableMenuItemKinds = [];
		this.menuBar 				= [];
		
		this.widgets 				= {};
		
	} // end of method constructor
	,
	'postCreate' : function () {
		this.inherited(arguments);
		
		// add a comment pane
		this.widgets.tP = new dijit.layout.ContentPane({
			'region'	: 'top',
			'style'		: 'margin:.5ex;',
			'content'	: ''
				+'<p>'
					+T(	'configureMenuBars.js/editInstructions_TXT',
						'Click on a menu item to edit it. You may as well add a new menu item.'
						)
				+'</p>'
		}).placeAt(this);
		
		// add a border container for the main editor
		this.widgets.editorBC = new dijit.layout.BorderContainer({
			'region'	: 'center',
			'gutters'	: false,
			'design'	: 'sidebar',
			'style'		: 'padding-bottom:.5ex;',
		}).placeAt(this);
		
		// add a title pane
		this.widgets.tP = new dijit.layout.ContentPane({
			'region'	: 'top',
			'style'		: 'margin:.5ex;',
			'content'	: ''
				+'<h4>'
					+T(	'configureMenuBars.js/theMenuBar_TXT',
						'The menu bar will appear as follows:-'
						)
				+'</h4>'
		}).placeAt(this.widgets.editorBC);
		
		// add the menu bar pane
		this.widgets.menuBar = new dijit.MenuBar({
			'style'		: 'margin:.5ex;',
			'region'	: 'top',
		}).placeAt(this.widgets.editorBC);
		
		// add a pane with new menu items
		this.widgets.newItemSection = new dijit.layout.BorderContainer({
			'gutters'	: false,
			'region'	: 'right',
			'splitter'	: true,
			'style'		: 'width:20em;margin:.5ex;',
		}).placeAt(this);
		
		this.widgets.newItemPane = new dijit.layout.ContentPane({
			'style'		: '',
			'content'	: ''
				+'<h4>'
					+T(	'configureMenuBars.js/availableItems_TXT',
						'Available menu item kinds:-'
						)
				+'</h4>'
				+'<p>&nbsp;</p>'
				,
		}).placeAt(this.widgets.newItemSection);
		
		this.widgets.newItemPane = new dijit.layout.ContentPane({
			'region'	: 'center',
			'style'		: 'margin-top:.5ex;',
			'content'	: ''
				+'<p>&nbsp;</p>'
				,
		}).placeAt(this.widgets.newItemSection);
		
		this.widgets.newSubMenu = new dijit.form.Button({
			'label'	: '« ',
			'title'	: ''
				+T(	'configureMenuBars.js/clickHereToAdd_TXT',
					'Click here to add a new item of this kind to the menu bar.'
					)
					,
		}).placeAt(
			dojo.create('P', {
				'class'		: 'textLeft',
				'innerHTML'	: ''
					+T(	'configureMenuBars.js/newSubMenu_BTN',
						'New submenu'
						)
			}, this.widgets.newItemPane.containerNode), 
			'first' );
		dojo.style(this.widgets.newSubMenu.domNode.firstChild, 'padding', '0px');
		
		dojo.create( 'HR', {}, this.widgets.newItemPane.containerNode);
		
		for (var mIK_UUID in this.availableMenuItemKinds) {
			var iK = this.availableMenuItemKinds[mIK_UUID];
		
			this.widgets['iK_'+iK.UUID] = new dijit.form.Button({
				'label'	: '« ',
				'title'	: ''
					+T(	'configureMenuBars.js/clickHereToAdd_TXT',
						'Click here to add a new item of this kind to the menu bar.'
						)
						,
				'itemKind'	: iK,
				'scope'		: this,
			}).placeAt( 
				dojo.create('P', {
						'innerHTML'	: iK.name
					}, this.widgets.newItemPane.containerNode), 
				'first' 
				);
			dojo.style(this.widgets['iK_'+iK.UUID].domNode.firstChild, 'padding', '0px');

		} // end for .. in this.availableMenuItemKinds
		
		// output the menu bar
		this._outputMenuBar();
		
	} // end of method postCreate
	,
	'destroy' : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		
		for (var i in this.widgets) {
			if (this.widgets[i].destroyRecursive) this.widgets[i].destroyRecursive(false);
			delete this.widgets[i];
		} // end for .. in
		
		this.inherited(arguments);
	} // end of method destroy
	,
	
	
	
	// internal methods #############################################################################
	'_outputMenuBar' : function () {
	
		// sort this.menuBar (array) by its position slots
		this.menuBar = this.menuBar.sort(function(i,j){return i.position - j.position;});	
	
		// iterate over all menu items and create menu  items for them
		dojo.forEach( this.menuBar, function (menuItem) {
			if(!menuItem) return; // Internet explorer bugfix
			
			switch (menuItem.type) {
				case 'dijit.MenuBarItem'		: this._createMenuBarItem(menuItem);break;
				case 'dijit.PopupMenuBarItem'	: this._createPopupMenu(menuItem);	break;
				default: // do nothing
			} // end switch
		
		}, this); // end dojo.forEach
	
	} // end of method _outputMenuBar
	,
	'_createMenuBarItem' : function (menuItem) {
		this._createMenuItem(menuItem, 'MenuBarItem', this.widgets.menuBar);
	} // end of method _createMenuBarItem
	,
	'_createPopupMenu' : function (menuItem) {
		var MI_UUID	= Math.uuid();

		// create and place the popup menu
		var pMBIWidget = new dijit.PopupMenuBarItem({
				'label'	: menuItem.label,
				'popup'	: new dijit.Menu({}),
				
				// necessary parameters for editing
				'MI_UUID'	: MI_UUID,
		}).placeAt(this.widgets.menuBar);

		// create and add a menu item for editing the popup menu configuration
		this._createMenuItem (menuItem, 'MenuItem', pMBIWidget.popup, ''
			+T(	'configureMenuBars.js/EditPropsOf_TXT',
				'Edit the properties of « $[0]» ',
				[menuItem.label])
		);
		
		// create and add a separator
		this._createMenuItem ({}, 'MenuSeparator', pMBIWidget.popup );
		
		// iterate over all corresponding menu items and add them as sub menu entries
		dojo.forEach(this.menuBar, function(mi){
			if (typeof mi == 'undefined') return; // internet explorer bugfix
			
			// if the sub menu item belongs to the current PopupMenuItem --> create a menu item
			if (mi.parent_UUID && (mi.parent_UUID==menuItem.UUID)) {							
				this._createMenuItem(mi, 'MenuItem', pMBIWidget.popup);
			} // end if
		}, this); // end dojo.forEach
		
		// register the popup menu item widget locally
		this.widgets[MI_UUID] = pMBIWidget;
	
	} // end of method _createPopupMenu
	,
	'_createMenuItem' : function (menuItem, type, location, overwriteLabel) {
		
		// create and place the menu bar item
		var MI_UUID	= Math.uuid();
		this.widgets[MI_UUID] = new dijit[type]({
				'label'		: (overwriteLabel?overwriteLabel:menuItem.label),
				
				// necessary parameters for editing
				'MI_UUID'	: MI_UUID,
				'menuItem'	: menuItem,
				'scope'		: this,
				
				// the onClick event
				'onClick'	: function (e) {
					if (e) dojo.stopEvent(e);
					
					// Attention: context is here: dijit.MenuBarItem!
					
					// fire a showMenuItemEditor event
					this.showMenuItemEditor( this );
					
				}, // end of method onClick

				
				// getters and setters
				'_setMenuItemAttr' : function (mI) {
					this.menuItem = mI;
					this.set('label', mI.label);
				} // end of method _setMenuItemAttr
				,
				'_getMenuItemAttr' : function () {
					return this.menuItem;
				} // end of method _getMenuItemAttr
				,

				
				// events
				'showMenuItemEditor' : function (menuItem, widget) {},
				
			}).placeAt(location);
			
			// connect the events
			this.connect( this.widgets[MI_UUID], 'showMenuItemEditor', '_showMenuItemEditor');
			
	} // end of method _createMenuItem
	,
	'_showMenuItemEditor' : function (menuItemWidget) {
		
		// remove and destroy the current menu item editor
		if (this.widgets.menuItemEditor) {
			this.widgets.menuItemEditor.destroy(false);
			this.widgets.menuItemEditor = null;
		} // end if
		
		// store the information about the current menu item locally
		this._currentMenuItemWidget = menuItemWidget;
		
		// create and show a new menu item editor
		this.widgets.menuItemEditor = new application.widgets.menuItemEditor({
			'menuItem'			: this._currentMenuItemWidget.get('menuItem'),
			'region'			: 'center',
			'completeMenuBar'	: this.menuBar,
		}).placeAt(this.widgets.editorBC);
	
	} // end of method _showMenuItemEditor
	,
	
	// settings of dijit.layout.BorderContainer #####################################################
	'gutters'	: false,
	'style'		: 'margin-bottom:.5ex',
});
	
dojo.declare('application.widgets.configureMenuBars', [common.widgets.fixedSizeDialog], {
	
	// these slots have values need to be passed when creating the widget
	'name'			: null, // mandantory STRING --- the object type name
	'OT_UUID'		: null, // mandantory STRING --- the object type's UUID
	
	
	// the following slots form internal variables / containers
	'_O_menuBar'	: null, // []
	'_OT_menuBar'	: null, // []
	
	// settings of the parent class common.widgets.fixedSizeDialog
	'innerWidth'	: 1000
	,
	'innerHeight'	: 680
	,
	
	
	
	// widget life cycle
	'constructor' : function () {
	
		// some initialisations
		this.name 			= '';
		this.OT_UUID 		= '';
	
		this._O_menuBar		= [];
		this._OT_menuBar	= [];
	
		this.widgets 		= {};
		
	} // end of method constructor
	,
	'postMixInProperties' : function () {
		this.inherited(arguments);
	
		this.title = T(	'configureMenuBars.js/adminMenuLabel_TIT',
						'Configure the menu bars for the type «$[0]» and its objects',
						[this.name] );
			
		// load the menu bar information from the server
		dojo.xhrGet({
			'scope'			: this,
			'url'			: '?',
			'content' 		: {
				'v'			: 'JSON_ObjectType',
				'task'		: 'get_OT_menuBars',
				'OT_UUID'	: this.OT_UUID,
			},
			'sync' 			: true,
			'handleAs' 		: 'json',
			'load' 			: function (r,a) {				
				a.args.scope._O_menuBar	= r.O_menuBar;
				a.args.scope._OT_menuBar= r.OT_menuBar;
			} // end of method load
		});

	} // end of method postMixInProperties
	,
	'buildRendering' : function () {
		this.inherited(arguments);

		this.widgets.BC = new dijit.layout.BorderContainer ({
			'style'		: 'width:100%;height:100%',
			'gutters'	: false,
		}).placeAt( this.containerNode);
	
		this.widgets.titlePane = new dijit.layout.ContentPane ({
			'region'	: 'top',
			'style'		: 'margin:.5ex;',
			'content'	: ''
				+'<h3>'
					+this.attr('title')
				+'</h3>'
		});
		this.widgets.BC.addChild(this.widgets.titlePane);

		
		// Create the accordion panes for editing the menu bars ----------------------
		
		this.widgets.AC = dijit.layout.AccordionContainer ({
			'region'	: 'center',
		}).placeAt(this.widgets.BC);
		
		this.widgets.OTMenuBarEditor = new application.widgets.menuBarEditor/*dijit.layout.ContentPane*/({
			'title'		: T(	'configureMenuBars.js/OTMenuBarEditor_TIT',
								'Type menu bar' ),
			'availableMenuItemKinds'	: application.OT_menubar_itemKinds.itemKinds_asSlots,
			'menuBar'	: this._OT_menuBar,
		}).placeAt(this.widgets.AC);
		
		this.widgets.OMenuBarEditor = new application.widgets.menuBarEditor/*dijit.layout.ContentPane*/({
			'title'		: T(	'configureMenuBars.js/OMenuBarEditor_TIT',
								'Object menu bar' ),
			'availableMenuItemKinds'	: application.O_menubar_itemKinds.itemKinds_asSlots,
			'menuBar'	: this._O_menuBar,
		}).placeAt(this.widgets.AC);
		
		
		// create the buttons ... -----------------------------------------------
		this.widgets.buttonPane = new dijit.layout.ContentPane ({
			'region'	: 'bottom',
			'style'		: 'margin:.5ex;margin-top:.25em;text-align:right;',
		});
		this.widgets.BC.addChild(this.widgets.buttonPane);
		
		this.widgets.OkButton = new dijit.form.Button({
			'label' 	: '<img src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/dialog-ok-apply-4.png"/> '
				+T('BTN_Ok','Ok'),
			'type'		: 'button',
		}).placeAt(this.widgets.buttonPane.containerNode);
		
		this.widgets.CancelButton = new dijit.form.Button({
			'label' 	: '<img width="12" src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/dialog-cancel-4.png"/> '
				+T('BTN_Cancel','Cancel'),
		}).placeAt(this.widgets.buttonPane.containerNode);
		
		// initialise the tree for selecting the second object type
		//this._initialise_tree();
		
	} // end of method buildRendering
	,
	'startup' : function () { 
		this.inherited(arguments);
	
		// start the child widgets
		this.widgets.BC.startup();
	
		// it's time now for the connects ...
		this.connect( this.widgets.OkButton,	'onClick',  '_execute'				);
		this.connect( this.widgets.CancelButton,'onClick',  'hide'					);
		
	} // end of method startup
	,
	'destroy' : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		
		for (var i in this.widgets) {
			if (this.widgets[i].destroyRecursive) this.widgets[i].destroyRecursive(false);
			delete this.widgets[i];
		} // end for .. in
		
		this.inherited(arguments);
	} // end of method destroy
	,
	
	// internal methods
	'_execute' : function (e) {
		
		// call the event
		this.onExecute();
		
		// hide the dialog
		this.hide();
	} // end of method _execute
	,
	
	// events
	'onExecute' : function () {},
	
});	
	


// extend the admin functionality with an object for managing the OT menu bars
application.admin.configureMenuBars = {
	'showDialog' : function () {
		loader.show();
		if (this.dialogWidget) this.deleteDialog(); // destroy a potentially existing dialog widget
		
		// get the necessary information
		this.OT_name = application.admin.navigationStore.getValue(application.admin.currentNavigationItem,'name');
		this.OT_UUID = application.admin.navigationStore.getValue(application.admin.currentNavigationItem,'UUID');
		
		this.dialogWidget = new application.widgets.configureMenuBars({
			'OT_UUID'	: this.OT_UUID,
			'name'		: this.OT_name,
		});
		
		// carry out the necessary connects
		this.dialogConnects = [
			dojo.connect( this.dialogWidget, 'onExecute', this, '_onExecute' 	),
		];
		
		this.dialogWidget.startup();
		this.dialogWidget.show();
		loader.hide();
	} // end of method showDialog
	,
	'closeDialog' : function() {
	
		this.dialogWidget.hide();
		
	} // end of method closeDialog
	,
	'_onExecute' : function() {

		loader.show();
	
		// save the new OT name to the server
		/*application.RT_AJAX_query(
			{
				"task"				: 		"add_RT",
				"start_OT_UUID"		: 		start_OT_UUID,
				"end_OT_UUID"		: 		end_OT_UUID,
				"RT_name"			: 		relName_startEnd,
				"RT_nameOfInverse"	: 		relName_endStart,
				'createAttributeAtStartOT'	: createAttrAtStartOT,
				'createAttributeAtEndOT' 	: createAttrAtEndOT,
			}, 
			function(response,details) {
				// refresh the admin pane
				application.admin.initialise_adminPane();
			} // end of onSuccess function
			,
			true // synchronously
		);
		*/
		loader.hide();
		
	} // end-of-method execute
	,
	'deleteDialog' : function () {
	
		dojo.forEach( this.dialogConnects, function (c) {
			dojo.disconnect(c);
		}, this);
		
		this.dialogWidget.destroyRecursive(false);
		this.dialogWidget.destroy();
		this.dialogWidget=null;
		
		this.OT_UUID = null;
		this.OT_name = null;
			
	} // end of method deleteDialog
	,
}; // end extension of the admin functionality

// register the option for the right click menu
application.admin.adminPane_rightClickMenu.addOption( T( 'configureMenuBars.js/adminMenuLabel_txt',
	'Configure the <strong>menu bars</strong> for this type and its objects'), 
	function () {application.admin.configureMenuBars.showDialog();}, 
	'rsIcon_configureOT_menubar', 
	function(item_type){return(item_type!='OT'?true:false);}
);
