<?php if (!defined('APPLICATION_started')) {header('Location: .');exit;} 
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/
?>
 
<div dojoType="dijit.Dialog" id="application.admin.Dialogues.manageMenuBars" 
	title="Manage the object type menu bar ## This title will be replaced automagically!! ##" 
		style="width:750px;"
	execute="application.admin.manageMenuBars.execute();">
	
	<div dojoType="dijit.layout.BorderContainer" gutters="false" style="width:100%;height:400px;">
		<!-- the main user interface of the dialog -->
		<div dojoType="dijit.layout.ContentPane" class="dijitDialogPaneContentArea" style="padding-bottom:1.25em;" region="top">
			<h3><?php echo T('manageMenBars.php/TheMenBarLooks_TXT', 'The menu bar will look like this:'); ?></h3>
			<p style="padding-bottom:.25em;"> <?php echo T('manageMenBars.php/ChooseAMenItm_TXT', 'Choose a menu item to edit its configuration or create a new menu item:'); ?></p>
			<div dojoType="dijit.MenuBar" id="application.admin.Dialogues.manageMenuBars.menuBar" >
				<div dojoType="dijit.PopupMenuBarItem" style="float:right;" id="application.admin.Dialogues.manageMenuBars.newMenuItem_dropDown">
					<span>
						<?php echo T('manageMenBars.php/CrNewMenItm_BTN', 'Create new menu item&nbsp;&hellip;') ?>
					</span>
					<div dojoType="dijit.Menu" id="application.admin.Dialogues.manageMenuBars.newMenuItemList" >
						<div dojoType="dijit.MenuItem" onClick="alert('DropDownMenu')">
							<?php echo T('manageMenBars.php/DDMenu_TXT', 'Drop Down Menu'); ?>
						</div>
						<div dojoType="dijit.MenuItem" onClick="void(e)">
							&nbsp;&mdash;&mdash;&mdash;&mdash;&mdash;&mdash;&mdash;&mdash;&mdash;&mdash;
						</div>
						<div dojoType="dijit.MenuItem" onClick="alert('type 1')">
							<?php echo T('manageMenBars.php/Type1_TXT', 'Type 1'); ?>
						</div>
						<div dojoType="dijit.MenuItem" onClick="alert('type 2')">
							<?php echo T('manageMenBars.php/Type2_TXT', 'Type 2'); ?>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div dojoType="dijit.layout.ContentPane" class="dijitDialogPaneContentArea" id="application.admin.Dialogues.manageMenuBars.itemContent" style="" region="center">
			<div id="application.admin.Dialogues.manageMenuBars.showHideConfigOptions">
				<div  class="inputList2_3"  id="application.admin.Dialogues.manageMenuBars.labelInput">
					<div><?php echo T('FUT_Label', 'Label'); ?>:</div>
					<div >
						<input id="application.admin.Dialogues.manageMenuBars.label" type="text" 
							dojoType="dijit.form.ValidationTextBox" name="label" style="width:98%;" 
							value="3242343243" regExp="[^\r\n]{3,}" selectOnClick="true" trim="true" intermediateChanges="true" 
							onBlur="if(this.isValid()) application.admin.manageMenuBars.renameItem(this.value);"
							/>
					</div>
				</div>
				<div  class="inputList2_3"  id="application.admin.Dialogues.manageMenuBars.OpenByDefaultSection">
					<div><?php echo T('manageMenBars.php/WhenOpeningOTT_LBL', 'When opening the object type tab:'); ?></div>
					<div >
						<input id="application.admin.Dialogues.manageMenuBars.OpenByDefault" dojoType="dijit.form.CheckBox" value="1"
						checked onClick="application.admin.manageMenuBars.toggle_openByDefault(this.checked);">
						<label for="application.admin.Dialogues.manageMenuBars.OpenByDefault">
							<?php echo T('manageMenBars.php/ExecCommand_TXT', 'Execute the command assigned this menu item'); ?>
						</label>						
					</div>
				</div>

				<div  class="inputList2_3">
					<div >&nbsp;</div>
					<div >
						<span id="application.admin.Dialogues.manageMenuBars.moveOptions_menuBarItem">
							<button dojoType="dijit.form.Button" label="&larr;" onClick="application.admin.manageMenuBars.moveMenuBarItem_LEFT();"></button>
							<button dojoType="dijit.form.Button" label="&rarr;" onClick="application.admin.manageMenuBars.moveMenuBarItem_RIGHT();"></button>
						</span>
						<span  id="application.admin.Dialogues.manageMenuBars.moveOptions_menuBarItem_mbi">
							<button dojoType="dijit.form.DropDownButton" label="<?php echo T('manageMenBars.php/IncInDDMen_TXT', 'Include in drop down menu'); ?>">
								<div dojotype="dijit.Menu" id="application.admin.Dialogues.manageMenuBars.dropDownMenuList"></div>
							</button>
						</span>
						<span id="application.admin.Dialogues.manageMenuBars.moveOptions_dropDownMenu">
							<button dojoType="dijit.form.Button" label="&uarr;" onClick="application.admin.manageMenuBars.moveDropDownMenuItem_UP();"></button>
							<button dojoType="dijit.form.Button" label="&darr;" onClick="application.admin.manageMenuBars.moveDropDownMenuItem_DOWN();"></button>
							<button dojoType="dijit.form.Button" label="<?php echo T('manageMenBars.php/MakeItmOwnMen_TXT', 'Make this item a menu item on its own'); ?>" onClick="application.admin.manageMenuBars.convertTo_mbItem();"></button>
						</span>
					</div>
				</div>

				<div class="inputList2_3" id="application.admin.Dialogues.manageMenuBars.delete">
					<div ><?php echo T('FUT_Delete', 'Delete'); ?>:</div>
					<div >
						<button dojoType="dijit.form.Button" onClick="application.admin.manageMenuBars.delete_item();"><?php echo T('FUT_Delete', 'Delete'); ?></button>
					</div>
				</div>

				<div class="inputList2_3" id="application.admin.Dialogues.manageMenuBars.deleted">
					<div >&nbsp;</div>
					<div >
						<?php echo T('manageMenBars.php/ItemDeletedUndo_LNK', 'This item was deleted. Click <a href="javascript:application.admin.manageMenuBars.undelete_item();" onclick="">here</a> to undo this.'); ?>
					</div>
				</div>

				<div class="inputList2_3" id="application.admin.Dialogues.manageMenuBars.changed"><!-- turned off in application.admin.manageMenuBars.selectItem(??);-->
					<div >&nbsp;</div>
					<div >
						<?php echo T('manageMenBars.php/ItmChangedUndo_LNK', 'This item was changed. Click <a href="javascript:void(e);" onclick="alert(\'undo\');">here</a> to undo all changes.'); ?>
					</div>
				</div>
			</div>
		</div>
		
		<!-- the button row -->
        <div dojoType="dijit.layout.ContentPane" class="dijitDialogPaneActionBar textRight" style="padding-top:0.5em;" region="bottom">
			<button dojoType="dijit.form.Button" type="submit"><?php echo T('BTN_OK', 'OK'); ?></button>
			<button dojoType="dijit.form.Button" type="button" onClick="dijit.byId('application.admin.Dialogues.manageMenuBars').hide();"><?php echo T('BTN_Cancel', 'Cancel'); ?></button>
		</div>
	</div>
</div>
