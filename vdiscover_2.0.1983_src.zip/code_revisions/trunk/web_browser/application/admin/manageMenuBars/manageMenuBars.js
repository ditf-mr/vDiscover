/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// extend the admin functionality with an object for managing the OT menu bars
application.admin.call_manage_OT_menuBar = function() {
	application.admin.manageMenuBars.customise('Object type');
	application.admin.manageMenuBars.showDialogue();
};

application.admin.call_manage_O_menuBar = function() {
	application.admin.manageMenuBars.customise('Object');
	application.admin.manageMenuBars.showDialogue();
};

application.admin.manageMenuBars = {
	customise : function (OT_or_O) {
		if (OT_or_O == 'Object type') {
			this.retrieve_task='get_OT_menuBarOT';
			this.title = function (name) {return T('manageMenuBars.js/MMBTypeTab_TIT','Manage the menu bar of the « $[0]»  type tab',[name]) ;}
			this.itemKinds=application.OT_menubar_itemKinds;
			this.store_task='set_OT_menuBarOT';
			dojo.style('application.admin.Dialogues.manageMenuBars.OpenByDefaultSection','display','block');
		} else {
			this.retrieve_task='get_OT_menuBarO';
			this.title = function (name) {return T('manageMenuBars.js/MMBObjOfType_TIT','Manage the menu bar of objects of the type « $[0]» ',[name]) ;}
			this.itemKinds=application.O_menubar_itemKinds;
			this.store_task='set_OT_menuBarO';
			dojo.style('application.admin.Dialogues.manageMenuBars.OpenByDefaultSection','display','none');
		} // end of what to do
	}
	,
	retrieve_task: 'get_OT_menuItems'
	,
	title: function(name) {return T('manageMenuBars.js/MMBTypeTab_TIT','Manage the menu bar of the « $[0]»  type tab',[name]) ;}
	,
	itemKinds : null//application.OT_menubar_itemKinds.itemKind_List
	,
	showDialogue : function () {
	
		loader.show();
	
		// get the necessary information
		var name = application.admin.navigationStore.getValue(application.admin.currentNavigationItem,'name');
		var UUID = application.admin.navigationStore.getValue(application.admin.currentNavigationItem,'UUID');
		
		// reset and load the menuItem store
		this.menuItemStore=null; //close();
		
		// create the menuItem store
		application.OT_AJAX_query( 
			{ task: this.retrieve_task/*'get_OT_menuItems'*/, UUID: UUID }, 
			function(r,a){ // onSuccess method
				// create the attributeStore
				application.admin.manageMenuBars.menuItemStore = 
					new dojo.data.ItemFileWriteStore({
						data: r, 
						clearOnClose : true
					});
									
				// rebuild the attribute list
				application.admin.manageMenuBars.rebuild_menuBar();
				
				// show the dialog
				dijit.byId('application.admin.Dialogues.manageMenuBars').show();
				
				loader.hide();
				
			} // end of onSuccess method
		); // end AJAX query

		// configure the dialogue
		dijit.byId('application.admin.Dialogues.manageMenuBars').attr('title', this.title(name)/*'Manage the menu bar of the « '+name+'»  type tab'*/);
		application.admin.manageMenuBars.rebuild_newMenuItemList();
		// hide the config options
		dojo.byId('application.admin.Dialogues.manageMenuBars.showHideConfigOptions').style['display']='none';

	} // end of method show
	,
	store_task: 'set_OT_menuItems'
	,
	rebuild_newMenuItemList : function () {
		var newMenuItemList = dijit.byId('application.admin.Dialogues.manageMenuBars.newMenuItemList');
		// empty the newMenuItemList
		newMenuItemList.destroyDescendants();

		// add a menuItem to edit the dropdown menu properties
		var insert_widget = new dijit.MenuItem({
			label: T('manageMenuBars.js/InsNewDDMen_MNU','Insert a new drop down menu'),
			onClick : function(n){application.admin.manageMenuBars.create_ddMenu();}
		});
		newMenuItemList.addChild(insert_widget);
		
		// add a horizontal bar to the  dropdown menu
		var horiz_bar_widget = new dijit.MenuSeparator({});
		newMenuItemList.addChild(horiz_bar_widget);
		
		// iterate over all item kinds and create for each entry a new dijit.MenuItem
		dojo.forEach (this.itemKinds.itemKind_List, function(o,i){
			var menuItem = new  dijit.MenuItem({
				label : o.name,
				onClick : function(n){application.admin.manageMenuBars.create_menuItem(o.UUID);}
			});
			newMenuItemList.addChild(menuItem);
		}); // end for each itemKind
		
	} // end of method rebuild_newMenuItemList
	,
	menuItemStore : null // // dojo.data.ItemFileWriteStore
	,
	rebuild_menuBar : function () {
		// iterate over all children of the menu bar and delete them
		var menuBar = dijit.byId('application.admin.Dialogues.manageMenuBars.menuBar');
		var mB_children = menuBar.getChildren();
		dojo.forEach(mB_children,function(c,i){
			if(c.id!='application.admin.Dialogues.manageMenuBars.newMenuItem_dropDown') {
				c.destroyRecursive();
			} // end if
		});
	
		// iterate over all items in the store menuItemStore and display them as menuItems
		menuItemCollector={};
		application.admin.manageMenuBars.menuItemStore.fetch({
			// see file:///Y:/Gespiegelte%20Webseiten/Dojo%20Toolkit%20Documentation/DOJOTOOL/REFERENC/DOJO/DATA/API/READ.HTM#fetch
			sort: [{attribute: "position", descending: false}],
			onItem : function (item, request) {
				//dojo.forEach(items, function( item, index ){
					with (application.admin.manageMenuBars.menuItemStore) {
					var iWidget=null;
					// determine CSS class as one of modified, inserted, deleted
					var deleted  = (hasAttribute(item,'deleted') && getValue(item, 'deleted'));
					var modified = (hasAttribute(item,'modified') && getValue(item, 'modified'));
					var inserted = (hasAttribute(item,'inserted') && getValue(item, 'inserted'));
					var css_class = 'not_specified';
					// the secuence of the following lines is crucial as a later one beats the earlier ones
					if(modified) css_class='modified';
					if(inserted) css_class='inserted';
					if(deleted)  css_class='deleted';
					
					switch (getValue(item, 'type')) {
						case 'dijit.MenuBarItem':{
							// create a menu bar item and insert it
							iWidget = new dijit.MenuBarItem({
								'label'	: getValue(item, 'label'),
								"class" : css_class,
								'store'	: application.admin.manageMenuBars.menuItemStore,
								'item' 	: item,
								'onClick': function(n){
									application.admin.manageMenuBars.selectItem(
										this.store.getValue(this.item, 'UUID')
									);
									dojo.stopEvent(n);
								} // end of method onClick
							});
							iWidget.placeAt('application.admin.Dialogues.manageMenuBars.menuBar');
							break;}
						case 'dijit.PopupMenuBarItem':{	// create popup menubar item and insert it
							// let's create the menu inside the popup menu bar item, first
							var sm_widget = new dijit.Menu({
								id:getValue(item, 'UUID')+'_menu'
							});
							// add a menuItem to edit the dropdown menu properties
							var edit_sm_properties_widget = new dijit.MenuItem({
								label: T('manageMenuBars.js/EditPropOf_TXT','Edit the properties of') + ' « '+getValue(item, 'label')+'» ',
								onClick:function(n){application.admin.manageMenuBars.selectItem(getValue(item, 'UUID'));}
							});
							sm_widget.addChild(edit_sm_properties_widget);
							// add a horizontal bar to the  dropdown menu
							var horiz_bar_widget = new dijit.MenuSeparator({});
							sm_widget.addChild(horiz_bar_widget);
							// let's create the popup menu bar item
							iWidget = new dijit.PopupMenuBarItem({
								label:getValue(item, 'label')+'&nbsp;…',
								"class" : css_class,
								popup: sm_widget
							});
							iWidget.placeAt('application.admin.Dialogues.manageMenuBars.menuBar');
							break;}
						//case 'dijit.MenuItem':{
						//	break;}
						default: // do nothing
					} // end switch
					
					} // end with
				//}); // end forEach
			} // end onItem
		}); // end fetch all menuItems
		
		application.admin.manageMenuBars.menuItemStore.fetch({
			query: {type:'dijit.MenuItem'},
			sort: [	{attribute: "position", descending: false}],
			onItem : function (item, request) {
				// all items here are dijit.MenuItems, only!
				with (application.admin.manageMenuBars.menuItemStore) {
					// determine CSS class as one of modified, inserted, deleted
					var deleted =  (hasAttribute(item,'deleted') && getValue(item, 'deleted'));
					var modified = (hasAttribute(item,'modified') && getValue(item, 'modified'));
					var inserted = (hasAttribute(item,'inserted') && getValue(item, 'inserted'));
					var css_class = 'not_specified';
					// the secuence of the following lines is crucial as a later one beats the earlier ones
					if(modified) css_class='modified';
					if(inserted) css_class='inserted';
					if(deleted)  css_class='deleted';
				
					var mi_widget = new dijit.MenuItem({
						label:getValue(item, 'label'),
						"class": css_class,
						onClick:function(n){application.admin.manageMenuBars.selectItem(getValue(item, 'UUID'));}
					});
					dijit.byId(getValue(item, 'parent_UUID')+'_menu').addChild(mi_widget);
				
				} // end with
			} // end onItem
		}); // end fetch all menuItems
	} // end of method outputMenuList
	,
	selected_UUID: null // string
	,
	selected_Item : null
	,
	selectItem : function(UUID) {
		// set some internal variables
		application.admin.manageMenuBars.selected_UUID=UUID;
		application.admin.manageMenuBars.menuItemStore.fetchItemByIdentity({
			identity : UUID,
			onItem : function (item) {
				application.admin.manageMenuBars.selected_Item=item;
			} // end onItem
		}); // end fetchItemByIdentity
		
		with(application.admin.manageMenuBars.menuItemStore) {
		
			var item=this.selected_Item;
			var deleted =  (hasAttribute(item,'deleted') && getValue(item, 'deleted'));
			var modified = (hasAttribute(item,'modified') && getValue(item, 'modified'));
			var inserted = (hasAttribute(item,'inserted') && getValue(item, 'inserted'));
			
			var openByDefault = (hasAttribute(item,'openByDefault') && getValue(item, 'openByDefault'));
			
			var domId="application.admin.Dialogues.manageMenuBars.";
			
			if(!deleted) {
				// set the label
				dijit.byId(domId+'label').attr('value',getValue(item, 'label'));

				// set some general options
				dojo.style(domId+"labelInput",'display','block');
				dojo.style(domId+"delete",'display','block');
				dojo.style(domId+"deleted",'display','none');

				// the following option is not implemented, yet
				//dojo.style(domId+"changed",'display',((modified)?'block':'none'));
				dojo.style(domId+"changed",'display','none');
				
				// set the openByDefault option
				dijit.byId('application.admin.Dialogues.manageMenuBars.OpenByDefault').attr('checked',openByDefault);
				
				// set specific options
				switch(getValue(item, 'type')) {
					case 'dijit.MenuBarItem':{
						if(this.store_task=='set_OT_menuBarOT') dojo.style(domId+'OpenByDefaultSection','display','block');
						dojo.style(domId+"moveOptions_menuBarItem",'display','block');
						application.admin.manageMenuBars.buildDropDownMenuList();
						dojo.style(domId+"moveOptions_dropDownMenu",'display','none');
						dojo.style(domId+"moveOptions_menuBarItem_mbi",'display','block');
						break;}
					case 'dijit.PopupMenuBarItem':{
						dojo.style(domId+'OpenByDefaultSection','display','none');
						dojo.style(domId+"moveOptions_menuBarItem",'display','block');
						dojo.style(domId+"moveOptions_dropDownMenu",'display','none');
						dojo.style(domId+"moveOptions_menuBarItem_mbi",'display','none');
						break;}
					case 'dijit.MenuItem':{
						if(this.store_task=='set_OT_menuBarOT')dojo.style(domId+'OpenByDefaultSection','display','block');
						dojo.style(domId+"moveOptions_menuBarItem",'display','none');
						dojo.style(domId+"moveOptions_dropDownMenu",'display','block');
						dojo.style(domId+"moveOptions_menuBarItem_mbi",'display','none');
						break;}
					default: // do nothing
				} // end switch by type
			} else { // item is deleted : hide everything except the deleted message
				dojo.style(domId+'OpenByDefaultSection','display','none');
				dojo.style(domId+"labelInput",'display','none');
				dojo.style(domId+"delete",'display','none');
				dojo.style(domId+"deleted",'display','block');
				dojo.style(domId+"moveOptions_menuBarItem",'display','none');
				dojo.style(domId+"moveOptions_dropDownMenu",'display','none');
				dojo.style(domId+"moveOptions_menuBarItem_mbi",'display','none');
			} // end if deleted
			
			
			// show the config options
			dojo.byId(domId+'showHideConfigOptions').style['display']='block';
			
		} // end with
	} // end of method selectItem
	,
	buildDropDownMenuList : function () {
	
		var m_widget = dijit.byId('application.admin.Dialogues.manageMenuBars.dropDownMenuList');
		
		// empty the existing menu item list
		m_widget.destroyDescendants();
	
		// insert all popup menus as a widget
		application.admin.manageMenuBars.menuItemStore.fetch({
			query: {type:'dijit.PopupMenuBarItem'},
			sort: [	{attribute: "position", descending: false}],
			onItem : function (item, request) {
				with (application.admin.manageMenuBars.menuItemStore) {
					var mi_widget = new dijit.MenuItem({
						label:getValue(item, 'label')+'&nbsp;…',
						onClick:function(n){application.admin.manageMenuBars.includeInDDMenu(getValue(item, 'UUID'));}
					});
					m_widget.addChild(mi_widget);
				} // end with
			} // end onItem
		}); // end fetch all menuItems
	
	} // end of method buildDropDownMenuList
	,
	renumber_menuBarItems : function (multiplyBy, ddMenu_UUID) {
		if(!multiplyBy) multiplyBy=10;
		var pos=1;
		var fetchInfo = {
			sort: [	{attribute: "position", descending: false}],
			onItem : function (item, request) {
				with (application.admin.manageMenuBars.menuItemStore) {
					var type  = getValue(item, 'type');
					var newPos=  multiplyBy*pos++;
					// two cases: 
					//	1) renumber all menu bar items and ignore all dijit.MenuItem (no ddMenu_UUID given) 
					//	2) renumber all items in the drop down menu with ddMenu_UUID
					if (!ddMenu_UUID) { // case 1)
						if (type!='dijit.MenuItem') // ignore all dijit.MenuItem
							if(getValue(item, 'position')!=newPos) setValue(item, 'position', newPos);
					} else { // case 2)
						if (type=='dijit.MenuItem') // ignore everything except dijit.MenuItem
							if(getValue(item, 'position')!=newPos) setValue(item, 'position', newPos);
					} // end if
				} // end with
			} // end onItem
		};
		if(ddMenu_UUID) fetchInfo.query={'parent_UUID':ddMenu_UUID};
		application.admin.manageMenuBars.menuItemStore.fetch(fetchInfo); // end fetch
	} // end of method renumber_menuBarItems
	,
	create_ddMenu : function () {
		var now = new Date();
		var UUID = 'mi_'+now.getTime();
		var item = application.admin.manageMenuBars.menuItemStore.newItem({
			UUID : UUID,
			mB_itemKind_UUID : '',
			label : T('manageMenuBars.js/NewDDMenu_TXT','New DropDown Menu'),
			position : 99999,
			type : 'dijit.PopupMenuBarItem',
			inserted : true
		});	// end newItem
		
		this.renumber_menuBarItems(10);
		this.rebuild_menuBar();
		this.selectItem(UUID);
	} // end of method create_ddMenu
	,
	create_menuItem : function (kind_UUID) {
		var now = new Date();
		var UUID = 'mi_'+now.getTime();
		var itemKind = this.itemKinds.itemKinds_asSlots[kind_UUID];
		var item = application.admin.manageMenuBars.menuItemStore.newItem({
			UUID : UUID,
			mB_itemKind_UUID : kind_UUID,
			label : itemKind.name,
			position : 99999,
			type : 'dijit.MenuBarItem',
			inserted : true,
			modified : true,
			openByDefault : false
		});	// end newItem
		
		this.renumber_menuBarItems();
		this.rebuild_menuBar();
		this.selectItem(UUID);
	} // end of method create_menuItem
	,
	toggle_openByDefault : function (newValue/* boolean */) {
		var item = application.admin.manageMenuBars.selected_Item;
		with (application.admin.manageMenuBars.menuItemStore) {
			setValue(item, 'openByDefault',(newValue!=false));
			setValue(item, 'modified', true);
		} // end with
	} // end of method moveMenuBarItemUp
	,
	moveMenuBarItem_LEFT : function () {
		var item = application.admin.manageMenuBars.selected_Item;
		// set the position of the selected menu bar item to position - 15
		with (application.admin.manageMenuBars.menuItemStore) {
			setValue(item, 'position', getValue(item, 'position')-15);
			setValue(item, 'modified', true);
		} // end with
		// renumber all items  with multiplier 10
		this.renumber_menuBarItems();
		// redisplay the menu bar
		this.rebuild_menuBar();
	} // end of method moveMenuBarItemUp
	,
	moveMenuBarItem_RIGHT : function () {
		var item = application.admin.manageMenuBars.selected_Item;
		// set the position of the selected menu bar item to position + 15
		with (application.admin.manageMenuBars.menuItemStore) {
			setValue(item, 'position', getValue(item, 'position')+15);
			setValue(item, 'modified', true);
		} // end with
		// renumber all items  with multiplier 10
		this.renumber_menuBarItems();
		// redisplay the menu bar
		this.rebuild_menuBar();
	} // end of method moveMenuBarItemUp
	,
	'renameItem' : function(newName) {
		var item = application.admin.manageMenuBars.selected_Item;
		application.admin.manageMenuBars.menuItemStore.setValue(item, 'label', newName);		
		application.admin.manageMenuBars.menuItemStore.setValue(item, 'modified', true);		
		// redisplay the menu bar
		this.rebuild_menuBar();
	} // end of method renameItem
	,
	includeInDDMenu : function(ddMenu_UUID){
		var item = application.admin.manageMenuBars.selected_Item;
		with (application.admin.manageMenuBars.menuItemStore) {
			setValue(item, 'type', 'dijit.MenuItem');
			setValue(item, 'parent_UUID', ddMenu_UUID);
			setValue(item, 'position', 99999);
			setValue(item, 'modified', true);
		} // end with
		this.renumber_menuBarItems();
		this.renumber_menuBarItems(10, ddMenu_UUID);
		this.rebuild_menuBar();
		this.selectItem(this.selected_UUID);
	} // end of method includeInDDMenu
	,
	convertTo_mbItem : function (){
		var item = application.admin.manageMenuBars.selected_Item;
		with (application.admin.manageMenuBars.menuItemStore) {
			setValue(item, 'type', 'dijit.MenuBarItem');
			setValue(item, 'parent_UUID', '');
			setValue(item, 'position', 99999);
			setValue(item, 'modified', true);
		} // end with
		this.renumber_menuBarItems();
		this.rebuild_menuBar();
		this.selectItem(this.selected_UUID);
	} // end of method convertTo_mbItem
	,
	moveDropDownMenuItem_UP : function () {
		var item = application.admin.manageMenuBars.selected_Item;
		// set the position of the selected menu bar item to position - 15
		with (application.admin.manageMenuBars.menuItemStore) {
			var current_pos = getValue(item, 'position');
			setValue(item, 'position', current_pos-15);
			setValue(item, 'modified', true);
			// renumber all items  with multiplier 10
			this.renumber_menuBarItems(10, getValue(item, 'parent_UUID'));
		} // end with
		// redisplay the menu bar
		this.rebuild_menuBar();
	} // end of method moveMenuBarItemUp
	,
	moveDropDownMenuItem_DOWN : function () {
		var item = application.admin.manageMenuBars.selected_Item;
		// set the position of the selected menu bar item to position - 15
		with (application.admin.manageMenuBars.menuItemStore) {
			var current_pos = getValue(item, 'position');
			setValue(item, 'position', current_pos+15);
			// renumber all items  with multiplier 10
			this.renumber_menuBarItems(10, getValue(item, 'parent_UUID'));
			setValue(item, 'modified', true);
		} // end with
		// redisplay the menu bar
		this.rebuild_menuBar();
	} // end of method moveMenuBarItemUp
	,
	delete_item : function () {
		var item = application.admin.manageMenuBars.selected_Item;
		with (application.admin.manageMenuBars.menuItemStore) {
			setValue(item, 'deleted', true);
		} // end with
		this.rebuild_menuBar();
		this.selectItem(this.selected_UUID);
	} // end of method delete_item
	,
	undelete_item : function () {
		var item = application.admin.manageMenuBars.selected_Item;
		with (application.admin.manageMenuBars.menuItemStore) {
			setValue(item, 'deleted', false);
		} // end with
		this.rebuild_menuBar();
		this.selectItem(this.selected_UUID);
	} // end of method undelete_item
	,
	undoChanges : function () {
		// not implemented yet because there are more important things to be solved, first
	} // end of method undoChanges
	,
	execute : function () {
		// hide the dialogue
		dijit.byId('application.admin.Dialogues.manageMenuBars').hide();
		
		var new_items = [], change_items = [], delete_items=[];
		
		// iterate over the store and build a flat representation of the new data structure
		with (application.admin.manageMenuBars.menuItemStore) {
			fetch({
				sort: [{attribute: "position", descending: false}],
				onItem : function (item, request) {
					// get the status of the item
					var modified = isDirty(item);
					var deleted = hasAttribute(item,'deleted') && getValue(item, 'deleted');
					// is the item a popup menu bar item?
					if(getValue(item, 'type')=='dijit.MenuItem') {
						// check if the parent item got deleted
						var parent_UUID=getValue(item, 'parent_UUID');
						fetchItemByIdentity({
							identity: parent_UUID,
							onItem:function(parent_item){ if(hasAttribute(parent_item,'deleted') && getValue(parent_item, 'deleted')) {deleted=true;} }
						});// end fetch
					} // end if is popup menu bar item
					// list the item in the correct variable
					if(deleted){
						delete_items.push({UUID:getValue(item, 'UUID')});
					} else if(modified) {
						var m = {
							UUID:				getValue(item, 'UUID'),
							mB_itemKind_UUID:	getValue(item, 'mB_itemKind_UUID'),
							label:				getValue(item, 'label'),
							position:			getValue(item, 'position'),
							type:				getValue(item, 'type'),
							openByDefault:		hasAttribute(item,'openByDefault')&&getValue(item, 'openByDefault')
						};
						if (m.type=='dijit.MenuItem') m.parent_UUID=getValue(item, 'parent_UUID');
						// inserted or changed?
						if(hasAttribute(item,'inserted') && getValue(item, 'inserted')){
							new_items.push(m);
						} else {
							change_items.push(m);
						} // end if inserted or changed?
					} // end if create/modify or delete
				} // end onItem
			}); // end fetch all menuItems
		} // end with
		
		// send the new data structure to the server
		var task = {task:this.store_task,UUID:application.admin.navigationStore.getValue(application.admin.currentNavigationItem,'UUID')};
		if (new_items) 		task.new_items		= dojo.toJson(new_items);
		if (change_items) 	task.change_items	= dojo.toJson(change_items);
		if (delete_items) 	task.delete_items	= dojo.toJson(delete_items);
		application.OT_AJAX_query(
			task,
			function(r,a){
				// close the navigationStore
				//navigationStore.close(); // this forces the store to be cleared - the contents will be reloaded later on
			}, // end of onSuccess function
			true
		); 	
		// hide the dialog
		
	} // end of method execute

}; // end extension of the admin functionality

// register the option for the right click menu
application.admin.adminPane_rightClickMenu.addOption('' + T('manageMenuBars.js/ConfOTMenBar_HTM','Configure the <strong>object type menu bar</strong>'), application.admin.call_manage_OT_menuBar, 'rsIcon_configureOT_menubar', function(item_type){return(item_type!='OT'?true:false);});
application.admin.adminPane_rightClickMenu.addOption('' + T('manageMenuBars.js/ConfOMenBar_HTM','Configure the <strong>object menu bar</strong>'), application.admin.call_manage_O_menuBar, 'rsIcon_configureO_menubar', function(item_type){return(item_type!='OT'?true:false);});
