<?php if (!defined('APPLICATION_started')) {header('Location: .');exit;} 
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

$p='application/admin/manageMenuBars/';
$r->register_dialogHTML($p.'manageMenuBars.dojoHTML.php');
$r->register_JavaScriptFile($p.'manageMenuBars.js');
$r->register_JavaScriptFile($p.'application.widgets.configureMenuBars.js');

?>