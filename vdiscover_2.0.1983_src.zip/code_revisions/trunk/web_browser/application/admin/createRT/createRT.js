﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare('application.widgets.createRT_Dialog',[common.widgets.fixedSizeDialog],{
	
	// these slots have values that need to be passed when creating the widget
	'name'			: null, // mandantory STRING --- the object type name
	'OT_UUID'		: null, // mandantory STRING --- the object type's UUID
	
	
	// the following slots form internal variables / containers
	'_navigationStore' 		: null, // {}
	'_navigationModel' 		: null, // {}
	'_currentNavigationItem': null, // {}
	'_end_OT_UUID'			: null, // string
	
	// settings of the parent class common.widgets.fixedSizeDialog
	'innerWidth'	: 800
	,
	'innerHeight'	: 1000
	,
	
	
	
	// widget life cycle
	'constructor' : function () {
	
		// some initialisations
		this.name 			= '';
		this.OT_UUID 		= '';
	
		this.widgets 		= {};
		
	} // end of method constructor
	,
	'postMixInProperties' : function () {
		this.inherited(arguments);
	
		this.title = T(	'createRT.js/CreateRT_TIT',
						'Create a relation type starting at «$[0]»',
						[this.name] );
	
	} // end of method postMixInProperties
	,
	'buildRendering' : function () {
		this.inherited(arguments);

		this.widgets.BC = new dijit.layout.BorderContainer ({
			'style'		: 'width:100%;height:100%',
			'gutters'	: false,
		}).placeAt( this.containerNode);
	
		this.widgets.titlePane = new dijit.layout.ContentPane ({
			'region'	: 'top',
			'content'	: ''
				+'<h3>'
					+T( 'createRT.php/CreateRT_TIT',
						'Create a new relationship type' )
				+'</h3>'
		});
		this.widgets.BC.addChild(this.widgets.titlePane);
		
		this.widgets.buttonPane = new dijit.layout.ContentPane ({
			'region'	: 'bottom',
			'style'		: 'margin-top:.25em;text-align:right;',
		});
		this.widgets.BC.addChild(this.widgets.buttonPane);
		
		this.widgets.stepsBC = new dijit.layout.BorderContainer ({
			'region'	: 'center',
			'gutters'	: false,
		});
		this.widgets.BC.addChild(this.widgets.stepsBC);
	
		this.widgets.step1Pane = new dijit.layout.BorderContainer ({
			'region'	: 'left',
			'style'		: 'width:50%;margin-right:.25em;',
			'splitter'	: true,
			'gutters'	: false,
		});
		this.widgets.stepsBC.addChild(this.widgets.step1Pane);
		
		this.widgets.step1TP = new dijit.layout.ContentPane({
			'region'	: 'top',
			'content'	: ''
				+'<h4>'
					+T( 'createRT.php/Step1_TXT', 
						'Step 1: Select the target object type' )
				+'</h4>',
		});
		this.widgets.step1Pane.addChild(this.widgets.step1TP);
	
		this.widgets.step2Pane = new dijit.layout.ContentPane ({
			'region'	: 'center',
			'gutters'	: false,
			'style'		: 'margin-left:.25em;',
			'content'	: ''
				+'<h4>'
					+T( 'createRT.php/Step2_TXT', 
						'Step 2: Naming & Relation attributes' )
				+'</h4>'
				+'<p>'
					+T( 'createRT.php/EnterNameOfRT_TXT', 
						'Please enter the names of the relationship type.' )
				+'</p>'
				
				+'<table><tbody>'

					+'<tr>'
						+'<td colspan="2"class="code textCenter">'+this.name+'</td>'
					+'</tr>'
					+'<tr>'
						+'<td class="textCenter code">&darr;</td>'
						+'<td class="textCenter code">&uarr;</td>'
					+'</tr>'
					+'<tr>'
						+'<td class="textCenter _RT_name_12_domNode" width="50%">'
						+'</td>'
						+'<td class="textCenter _RT_name_21_domNode" width="50%">'
						+'</td>'
					+'</tr>'
					+'<tr>'
						+'<td class="textCenter code">&darr;</td>'
						+'<td class="textCenter code">&uarr;</td>'
					+'</tr>'
					+'<tr>'
						+'<td colspan="2" class="code textCenter _endOT_name_2_domNode"></td>'
					+'</tr>'

				+'</tbody></table>'
				
				+'<p>&nbsp;</p>'
				
				+'<p>'
					+T( 'createRT.php/PlChkWhereToCrRelAttr_TXT', 
						'Please check where you want to create relation attributes:-' )
				+'</p>'
				
				+'<p>'
					+'<span class="_createAttrAt_1_domNode"></span> '
					+T( 'createRT.php/AtStartOT_TXT', 
						'at the start object type «<span class="code">$[0]</span>»', 
						[this.name] )
					
				+'</p>'
				
				+'<p>'
					+'<span class="_createAttrAt_2_domNode"></span> '
					+T( 'createRT.php/AtEndOT_TXT', 
						'at the end object type «$[0]»', 
						['<span class="_createAttrAt_2ndName_domNode code"></span>'] )
					
				+'</p>',
		});
	
		// locate DOM nodes
		dojo.forEach([ 
			'_RT_name_12_domNode', 
			'_RT_name_21_domNode', 
			'_endOT_name_2_domNode',
			'_createAttrAt_1_domNode',
			'_createAttrAt_2_domNode',
			'_createAttrAt_2ndName_domNode',
		], function(slot) {
			this[slot] = dojo.query ('.'+slot, this.widgets.step2Pane.containerNode).pop();
		}, this);
	
		// instantiate input boxes
	
		this.widgets.RT_name_12 = new dijit.form.ValidationTextBox ({
			'value'			: T('createRT.js/isRelatedWith_TXT', 'is related with'),
			'regExp' 		: ".{2,}",
			'required'		: true, 
			'class'			: "textCenter",
			'invalidMessage': T('createRT.js/relationName_invalidMessage_TXT', 'Please enter a relation name with at least two chars, here.'),
			'style' 		: "width:10em;",
			'selectOnClick' : true,		
			'intermediateChanges' : true,		
		}).placeAt(this._RT_name_12_domNode);
	
		this.widgets.RT_name_21 = new dijit.form.ValidationTextBox ({
			'value'			: T('createRT.js/isRelatedWith_TXT', 'is related with'),
			'regExp' 		: ".{2,}",
			'required'		: true, 
			'class'			: "textCenter",
			'invalidMessage': T('createRT.js/relationName_invalidMessage_TXT', 'Please enter a relation name with at least two chars, here.'),
			'style' 		: "width:10em;",
			'selectOnClick' : true,		
			'intermediateChanges' : true,		
		}).placeAt(this._RT_name_21_domNode);
		
		this.widgets.createAttrAt_1 = new dijit.form.CheckBox ({
			'checked' : true,
		}).placeAt( this._createAttrAt_1_domNode );
		
		this.widgets.createAttrAt_2 = new dijit.form.CheckBox ({
			'checked' : true,
		}).placeAt( this._createAttrAt_2_domNode );
		
		// create the buttons ...
		
		this.widgets.OkButton = new dijit.form.Button({
			'label' 	: '<img src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/dialog-ok-apply-4.png"/> '
				+T( 'createRT.php/CreateRT_BTN', 'Create the relationship type' ),
			'type'		: 'button',
		}).placeAt(this.widgets.buttonPane.containerNode);
		
		this.widgets.CancelButton = new dijit.form.Button({
			'label' 	: '<img width="12" src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/dialog-cancel-4.png"/> '
				+T('BTN_Cancel','Cancel'),
		}).placeAt(this.widgets.buttonPane.containerNode);
		
		// initialise the tree for selecting the second object type
		this._initialise_tree();
		
	} // end of method buildRendering
	,
	// #######################################################
	'startup' : function () { 
		this.inherited(arguments);
	
		// start the child widgets
		this.widgets.BC.startup();
	
		// it's time now for the connects ...
		this.connect( this.widgets.RT_name_12,	'onChange', '_checkIfSubmitPermitted' );
		this.connect( this.widgets.RT_name_21,	'onChange', '_checkIfSubmitPermitted' );
		
		this.connect( this.widgets.OkButton,	'onClick',  '_execute'				);
		this.connect( this.widgets.CancelButton,'onClick',  'hide'					);
		
		// enable/ disable the OK button
		this._checkIfSubmitPermitted();
		
	} // end of method startup
	,
	'destroy' : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		
		for (var i in this.widgets) {
			if (this.widgets[i].destroyRecursive) this.widgets[i].destroyRecursive(false);
			delete this.widgets[i];
		} // end for .. in
		
		// this.inherited(arguments);
	} // end of method destroy
	,
	
	// internal methods
	'_execute' : function (e) {
		if (!this._checkIfSubmitPermitted() ) return;
	
		// get everything necessary
		var start_OT_UUID		= this.OT_UUID, 
			end_OT_UUID 		= this._end_OT_UUID, 
			relName_startEnd 	= this.widgets.RT_name_12.attr('value'), 
			relName_endStart 	= this.widgets.RT_name_21.attr('value'),
			createAttrAtStartOT	= this.widgets.createAttrAt_1.attr('checked'),
			createAttrAtEndOT	= this.widgets.createAttrAt_2.attr('checked');
		
		// call the event
		this.onExecute(start_OT_UUID, end_OT_UUID, relName_startEnd, relName_endStart, createAttrAtStartOT, createAttrAtEndOT);
		
		// hide the dialog
		this.hide();
	} // end of method _execute
	,
	'_initialise_tree' : function () {
		try {
			this._navigationStore = new dojo.data.ItemFileReadStore({
					'url'				: '?v=JSON_General&task=get_NavigationTree4Admin&onlyOT=1',
					'urlPreventCache'	: true,
					'clearOnClose'		: true,
					'failOk'			: true
				});
		} catch(e) {
			application.showErrorMessage(dojo.fromJson (e));
			throw e;
		} // end-of try ... catch

		this._navigationModel = new dijit.tree.ForestStoreModel({
				'store'			: this._navigationStore,
				'query'			: {'type': 'navigation_node'},
				'childrenAttrs' : ['children']
			});
					
		try {
			this.widgets._navigationTree = new dijit.Tree ({
					'style'			: 'margin-top:.25em;',
					'region'		: 'center',
					'model'			: this._navigationModel,
					'openOnClick'	: false,
					'showRoot'		: false,
					'persist'		: true,
					'getIconClass' 	: function(item, isOpened) {return ((isOpened)?'dijitFolderOpened':'dijitFolderClosed');},
			});
			this.widgets.step1Pane.addChild( this.widgets._navigationTree );
			this.connect( this.widgets._navigationTree, 'onClick', '_targetOTSelected' );
		} catch(e) {
			console.log('tree initialisation error', e);
		} // end-of try...catch
	} // end of method _initialise_tree
	,
	'_targetOTSelected' : function (item,node,e){
		
		if(this._navigationStore.getValue(item,'type')!='OT') return;
		this._currentNavigationItem=item;
		this._end_OT_UUID=this._navigationStore.getValue(item,'UUID');
		var name = this._navigationStore.getValue(item,'name');
		// dojo.byId('application.admin.Dialogues.createRT.toDoMessage').innerHTML=
			// '<p>' + T('createOT.js/YouHaveSelected_HTM','You have selected the <i>end</i> object type') +' « <span class="code">'+name+'</span>» .</p>';
		dojo.attr( this._endOT_name_2_domNode, 'innerHTML', name);
		dojo.attr( this._createAttrAt_2ndName_domNode, 'innerHTML', name);
		
		// display step 2, if not done so, yet
		if (this.widgets.stepsBC.getIndexOfChild(this.widgets.step2Pane)==-1) {
			this.widgets.stepsBC.addChild(this.widgets.step2Pane);
		} // end if
		
		// check if submitting is permitted
		this._checkIfSubmitPermitted();
		
	} // end of function onClick
	,
	'_checkIfSubmitPermitted' : function () {
		var submitPermitted = true;
	
		submitPermitted = 		submitPermitted 
							&&	(this._end_OT_UUID != null)
							&&	this.widgets.RT_name_12.isValid()
							&&	this.widgets.RT_name_21.isValid()
						;
	
		this.widgets.OkButton.attr('disabled', !submitPermitted);
		
		return submitPermitted;
	} // end of method _checkIfSubmitPermitted
	,
	
	
	
	// events
	'onExecute' : function (start_OT_UUID, end_OT_UUID, relName_startEnd, relName_endStart, createAttrAtStartOT, createAttrAtEndOT) {},
	
});	
	


application.admin.createRT = {
	'showDialog' : function() {
	
		loader.show();
		if (this.dialogWidget) this.deleteDialog(); // destroy a potentially existing dialog widget
		
		// get the necessary information
		this.OT_name = application.admin.navigationStore.getValue(application.admin.currentNavigationItem,'name');
		this.OT_UUID = application.admin.navigationStore.getValue(application.admin.currentNavigationItem,'UUID');
		
		this.dialogWidget = new application.widgets.createRT_Dialog({
			'OT_UUID'	: this.OT_UUID,
			'name'		: this.OT_name,
		});
		
		// carry out the necessary connects
		this.dialogConnects = [
			dojo.connect( this.dialogWidget, 'onExecute', this, '_onExecute' 	),
		];
		
		this.dialogWidget.startup();
		this.dialogWidget.show();
		loader.hide();
				
	} // end-of-method showDialog
	,
	'closeDialog' : function() {
	
		this.dialogWidget.hide();
		
	} // end of method closeDialog
	,
	'_onExecute' : function(	start_OT_UUID, 
								end_OT_UUID, 
								relName_startEnd, 
								relName_endStart, 
								createAttrAtStartOT, 
								createAttrAtEndOT
							) {

		loader.show();
	
		// some preparations
		createAttrAtStartOT	= (createAttrAtStartOT?1:0);
		createAttrAtEndOT	= (createAttrAtStartOT?1:0);	
	
		// save the new OT name to the server
		application.RT_AJAX_query(
			{
				"task"				: 		"add_RT",
				"start_OT_UUID"		: 		start_OT_UUID,
				"end_OT_UUID"		: 		end_OT_UUID,
				"RT_name"			: 		relName_startEnd,
				"RT_nameOfInverse"	: 		relName_endStart,
				'createAttributeAtStartOT'	: createAttrAtStartOT,
				'createAttributeAtEndOT' 	: createAttrAtEndOT,
			}, 
			function(response,details) {
				// refresh the admin pane
				application.admin.initialise_adminPane();
			} // end of onSuccess function
			,
			true /*synchronously*/
		);
		
		loader.hide();
		
	} // end-of-method execute
	,
	'deleteDialog' : function () {
	
		dojo.forEach( this.dialogConnects, function (c) {
			dojo.disconnect(c);
		}, this);
		
		this.dialogWidget.destroyRecursive(false);
		this.dialogWidget.destroy();
		this.dialogWidget=null;
		
		this.OT_UUID = null;
		this.OT_name = null;
			
	} // end of method deleteDialog
	,

} // end of createRT

application.admin.adminPane_rightClickMenu.addOption( 
	T(	'createRT.js/CreateRT_MNU',
		'<strong>Create</strong> relation type'	), 
	function(){application.admin.createRT.showDialog();},
	'rsIcon_createRelationType', 
	function(item_type){return(item_type!='OT'?true:false);});
