<?php if (!defined('APPLICATION_started')) {header('Location: .');exit;}
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/
?>
 
<div dojoType="dijit.Dialog" id="application.admin.Dialogues.duplicateOT" title="Create a duplicate of the of &laquo;XX&raquo;" execute="void(false);">
	<div dojoType="dijit.form.Form" onSubmit="application.admin.duplicateOT.execute(); return false;" action="javascript:void(false);">
		<input dojoType="dijit.form.TextBox" id="application.admin.Dialogues.duplicateOT.OT_UUID" type="hidden" value="" />		
		<table style="min-width:400px; max-width: 800px;">
			<tbody>
				<tr>
					<td colspan="2">
						<p>
						    <?php echo T('duplicateOT.php/YouAreAboutTo_TXT', 'You are about to create a duplicate of &laquo;$[0]&raquo;.', array('<strong id="application.admin.Dialogues.duplicateOT.currentTypeName">XXX</strong>')); ?>
						    
						</p>
						<p> <?php  echo T('duplicateOT.php/DuplOTIncl_P0_TXT', 'This includes:'); ?>
						</p>
						<ul>
							<li> <?php echo T('duplicateOT.php/DuplOTIncl_P1_TXT', 'All attributes and view types of the object type.'); ?></li>
							<li>  <?php echo T('duplicateOT.php/DuplOTIncl_P2_TXT', 'All relation types starting at this object type.'); ?></li>
							<li>  <?php echo T('duplicateOT.php/DuplOTIncl_P3_TXT', 'The template views for name and description (if specified).'); ?></li>
						</ul>
					</td>
				</tr>
				<tr>
					<td>
						<p>  <?php echo T('duplicateOT.php/NameOfDupl_TXT', 'Please enter the new name for the duplicate, here:'); ?></p>
					</td>
				</tr>
				<tr>
					<td>
						<input dojoType="dijit.form.ValidationTextBox" 
							id="application.admin.Dialogues.duplicateOT.newName" 
							regExp=".{2,}" 
							selectOnClick="true"
							type="text" 
							value="xxx" 
							required="true" 
							invalidMessage="<?php echo T('duplicateOT.php/NameInvMsg_TXT', 'The type name should have a least 2 chars.'); ?>" 
							style="width:100%;"
							tooltipPosition="below" 
							trim="true" 
							selectOnClick="true" 
							maxlength="256"/>
					</td>
				</tr>
				<tr>
					<td colspan="2">&nbsp;</td>
				</tr>
				<tr>
					<td colspan="2" id="application.admin.Dialogues.duplicateOT.errorMessage"></td>
				</tr>
				<tr>
					<td valign="top" colspan="2" style="text-align:right;">
						<button dojoType="dijit.form.Button" type="submit" >
							<?php echo T('BTN_OK', 'OK') ?>
						</button>
						<button dojoType="dijit.form.Button" type="button" onClick="dijit.byId('application.admin.Dialogues.duplicateOT').hide();">
							<?php echo T('BTN_Cancel', 'Cancel') ?>
						</button>
					</td>
				</tr>
			</tbody>
		</table>
	</div>
</div>	
	
