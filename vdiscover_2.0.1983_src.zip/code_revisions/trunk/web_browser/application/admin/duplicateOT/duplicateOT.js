/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// extend the admin functionality 
application.admin.duplicateOT = { // Dialog for creating a duplicate of an object type
		
			showDialogue : function() {
				// get the necessary information
				var OT_UUID = application.admin.navigationStore.getValue(application.admin.currentNavigationItem,'UUID');
				var name = application.admin.navigationStore.getValue(application.admin.currentNavigationItem,'name');
				
				// set some fields in the dialogue as necessary
				dijit.byId('application.admin.Dialogues.duplicateOT').attr('title', T('duplicateOT.js/CreateDupl_TIT','Create a duplicate of « $[0]» ',[name]) );
				dojo.byId('application.admin.Dialogues.duplicateOT.currentTypeName').innerHTML = name;
				dojo.byId('application.admin.Dialogues.duplicateOT.OT_UUID').value = OT_UUID;
				dojo.byId('application.admin.Dialogues.duplicateOT.newName').value = name;
		
				// show the dialogue
				dijit.byId('application.admin.Dialogues.duplicateOT').show();
				
			} // end-of-method showDialogue
			,
			lastExecuteTimePoint:0 // integer
			,
			execute : function() {
				dijit.byId('application.admin.Dialogues.duplicateOT').hide();
				
				/*// prevent that two sub types are created within 1 sec
				var d=new Date();
				var now = Date.UTC(
							d.getFullYear(),
							d.getMonth(),
							d.getDay(),
							d.getHours(),
							d.getMinutes(),
							d.getSeconds()
						)*1000
						+ d.getMilliseconds();
				
				// if two calls within 1 sec: abort
				if((now-this.lastExecuteTimePoint)<=5000) return;
				
				this.lastExecuteTimePoint = now;*/
				
				// extract the necessary information
				var OT_UUID = dojo.byId('application.admin.Dialogues.duplicateOT.OT_UUID').value;
				
				// get the input value
				var newName = dojo.byId('application.admin.Dialogues.duplicateOT.newName').value;
			
			
				// tell the server to create the new sub type
				application.OT_AJAX_query({
						"task"	: "duplicate_OT",
						"UUID"	: OT_UUID,
						"name"	: newName
					}, 
					application.admin.duplicateOT.onSuccess,
					true/*synchronously*/
				);
			} // end-of-method execute
			,
			
			onSuccess : function(response,details){			
				// close the navigationStore
				// navigationStore.close(); // this forces the store to be cleared - the contents will be reloaded later on
				// hide the dialogue and refresh the admin pane
				application.admin.initialise_adminPane();
			} // end-of-method onSuccess
			
}; // end extension of the admin functionality with newOTSubType

// register the right click menu option
application.admin.adminPane_rightClickMenu.addOption(
	 '<strong>' + T('FUT_Duplicate','Duplicate') + '</strong>', 
	application.admin.duplicateOT.showDialogue, 
	'rsIcon_duplicate', 
	function(item_type) { return( item_type=='OT'?false:true ); }
);
