/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/


dojo.declare('application.widgets.renameRTDialog',[common.widgets.fixedSizeDialog],{
	
	// these slots have values need to be passed when creating the widget
	'RT_UUID'		: null, // mandantory STRING --- the object type's UUID
	'OTname1'		: null, // mandantory STRING --- the start object type name
	'OTname2'		: null, // mandantory STRING --- the end object type name
	'RTname12'		: null, // mandantory STRING --- the relationship name in start->end direction
	'RTname21'		: null, // mandantory STRING --- the relationship name in end->start direction
	
	
	// the following slots form internal variables / containers
	
	
	
	// settings of the parent class common.widgets.fixedSizeDialog
	'innerWidth'	: 400
	,
	'innerHeight'	: 200
	,
	
	
	
	// widget life cycle
	'constructor' : function () {
	
		// some initialisations
		this.OTname1 		= '';
		this.OTname2 		= '';
		this.RTname12 		= '';
		this.RTname21 		= '';
		this.RT_UUID 		= '';
	
		this.widgets 		= {};
		
	} // end of method constructor
	,
	'postMixInProperties' : function () {
		this.inherited(arguments);
	
		this.title = T('renameRT.js/ChNameOfRT_TIT', 'Change a Relation Type\'s names' );
	
	} // end of method postMixInProperties
	,
	'buildRendering' : function () {
		this.inherited(arguments);

		this.widgets.form = new dijit.form.Form({
			'onSubmit'	: function () {
				return false;
			}, // end of method onSubmit
		}).placeAt(this.containerNode);
	
		dojo.create('P',{
			'innerHTML' : T( 'renameRT.js/EnterNewNameOfRT_TXT',
							 'Please enter the new name of the relation type, here:'
				),
		}, this.widgets.form.containerNode);
	
		var t = dojo.create('TABLE',{
			'innerHTML' : ''
				+'<tbody>'

					+'<tr>'
						+'<td colspan="2"class="code textCenter">'+ this.OTname1+'</td>'
					+'</tr>'
					+'<tr>'
						+'<td class="textCenter code">&darr;</td>'
						+'<td class="textCenter code">&uarr;</td>'
					+'</tr>'
					+'<tr>'
						+'<td class="textCenter _RT_name_12_domNode" width="50%">'
						+'</td>'
						+'<td class="textCenter _RT_name_21_domNode" width="50%">'
						+'</td>'
					+'</tr>'
					+'<tr>'
						+'<td class="textCenter code">&darr;</td>'
						+'<td class="textCenter code">&uarr;</td>'
					+'</tr>'
					+'<tr>'
						+'<td colspan="2" class="code textCenter">'+this.OTname2+'</td>'
					+'</tr>'

				+'</tbody>',
		}, this.widgets.form.containerNode);
	
		// locate DOM nodes
		dojo.forEach([ 
			'_RT_name_12_domNode', 
			'_RT_name_21_domNode', 
		], function(slot) {
			this[slot] = dojo.query ('.'+slot, t).pop();
		}, this);
	
		// create and place the input boxes
	
		this.widgets.RT_name_12_vTB = new dijit.form.ValidationTextBox ({
			'regExp'			: ".{2,}",
			'selectOnClick'		: true,
			'value'				: this.RTname12,
			'required'			: true,
			'invalidMessage'	: T(	'renameOT.js/OTNameIsInvalidMSG_TXT',
										"The type name should have a least 2 chars."),
			'class'				: "fullWidth",
			'tooltipPosition'	: "below",
			'trim'				: true, 
			'intermediateChanges':true,
			'maxlength'			: 256,
		}).placeAt(this._RT_name_12_domNode);
	
		this.widgets.RT_name_21_vTB = new dijit.form.ValidationTextBox ({
			'regExp'			: ".{2,}",
			'selectOnClick'		: true,
			'value'				: this.RTname21,
			'required'			: true,
			'invalidMessage'	: T(	'renameOT.js/OTNameIsInvalidMSG_TXT',
										"The type name should have a least 2 chars."),
			'class'				: "fullWidth",
			'tooltipPosition'	: "below",
			'trim'				: true, 
			'intermediateChanges':true,
			'maxlength'			: 256,
		}).placeAt(this._RT_name_21_domNode);
	
		dojo.create('P',{
			'innerHTML' : '&nbsp;',
		}, this.widgets.form.containerNode);
	
		var bRow = dojo.create('DIV',{
			'innerHTML' : '',
			'style' : 'position:absolute;bottom:0;right:0;padding:.25em;',
		}, this.widgets.form.containerNode);
	
		this.widgets.OkButton = new dijit.form.Button({
			'label' 	: '<img src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/dialog-ok-apply-4.png"/> '
				+T('BTN_OK','OK'),
			'type'		: 'submit',
			'disabled'	: 'true',
		}).placeAt(bRow);
		
		this.widgets.CancelButton = new dijit.form.Button({
			'label' 	: '<img width="12" src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/dialog-cancel-4.png"/> '
				+T('BTN_Cancel','Cancel'),
		}).placeAt(bRow);
		
	} // end of method buildRendering
	,
	'startup' : function () {
		this.inherited(arguments);
	
		// it's time now for the connects ...
		this.connect( this.widgets.RT_name_12_vTB, 	'onChange', '_RTNamesChanged'	);
		this.connect( this.widgets.RT_name_21_vTB, 	'onChange', '_RTNamesChanged'	);

		this.connect( this.widgets.form,			'onSubmit', '_execute'			);
		this.connect( this.widgets.CancelButton,	'onClick',  'hide'				);
		
		// enable/ disable the Ok button
		this._RTNamesChanged();
	
	} // end of method startup
	,
	'destroy' : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		
		for (var i in this.widgets) {
			if (this.widgets[i].destroyRecursive) this.widgets[i].destroyRecursive(false);
			delete this.widgets[i];
		} // end for .. in
		
		// this.inherited(arguments);
	} // end of method destroy
	,
	
	// internal methods
	'_RTNamesChanged' : function () {
	
		var everythingOk = true
				&& this.widgets.RT_name_12_vTB.isValid()
				&& this.widgets.RT_name_21_vTB.isValid();
	
		// enable or disable the OB Button
		this.widgets.OkButton.attr('disabled', !everythingOk );
		
		return everythingOk;
	} // end of method _newNameChanged
	,
	'_execute' : function (e) {
		if (!this._RTNamesChanged() ) return;
	
		// get all necessary inputs and execute the event 
		var RT_UUID		= this.RT_UUID,
			RTName_12	= this.widgets.RT_name_12_vTB.attr('value'), 
			RTName_21	= this.widgets.RT_name_21_vTB.attr('value');
			
		this.onExecute( RT_UUID, RTName_12, RTName_21 );
		
		this.hide();
	} // end of method _execute
	,
	
	
	
	// events
	'onExecute' : function ( RT_UUID, RTName_12, RTName_21 ) {},
	
});	
	



// extend the admin functionality
application.admin.renameRT = { // Dialogue for changing the name of an relation type
	'dialogWidget' 	: null
	,
	'dialogConnects' : null
	,
	'RT_UUID'		: null,
	
	'OTname1'		: null, 
	'OTname2'		: null, 
	'RTname12'		: null, 
	'RTname21'		: null, 
	
	'showDialog' : function() {
	
		loader.show();
	
		if (this.dialogWidget) this.deleteDialog(); // destroy a potentially existing dialog widget
		
		// get the necessary information
		
		this.RT_UUID = application.admin.navigationStore.getValue(application.admin.currentNavigationItem,'UUID');
		
		application.RT_AJAX_query({	
				"task"		: 'get4_renameRT',
				"RT_UUID"	: this.RT_UUID,
			},
			function(r,a){
				a.args.scope.OTname1	= r.Start_OT_name;
				a.args.scope.OTname2 	= r.End_OT_name;
				a.args.scope.RTname12	= r.name;
				a.args.scope.RTname21	= r.nameOfInverse;
			} // end of onLoad
			,
			true /* sync */
			,
			this /* scope */
		);
		
		this.dialogWidget = new application.widgets.renameRTDialog({
			'RT_UUID'		: this.RT_UUID,
			'OTname1'		: this.OTname1,
			'OTname2'		: this.OTname2,
			'RTname12'		: this.RTname12,
			'RTname21'		: this.RTname21,
		});
		
		// carry out the necessary connects
		this.dialogConnects = [
			dojo.connect( this.dialogWidget, 'onExecute', this, '_onExecute' 	),
		];
		
		this.dialogWidget.startup();
		this.dialogWidget.show();
		
		loader.hide();
		
	} // end-of-method showDialog
	,
	'closeDialog' : function() {
	
		this.dialogWidget.hide();
		this.deleteDialog();
		
	} // end of method closeDialog
	,
	'_onExecute' : function( RT_UUID, RTName_12, RTName_21 ) {

		loader.show();
	
		// save the new OT name to the server
		application.RT_AJAX_query({
				"task"			: 'set_RT_names',
				"RT_UUID"		: RT_UUID,
				"name"			: RTName_12,
				"nameOfInverse"	: RTName_21
			}, 
			function(response,details) {
				// refresh the admin pane
				application.admin.initialise_adminPane();
			} // end of onSuccess function
			,
			true /*synchronously*/
		);
		
		loader.hide();
		
	} // end-of-method execute
	,
	'deleteDialog' : function () {
	
		dojo.forEach( this.dialogConnects, function (c) {
			dojo.disconnect(c);
		}, this);
		
		this.dialogWidget.destroyRecursive(false);
		this.dialogWidget.destroy();
		this.dialogWidget=null;
		
		this.OT_UUID = null;
		this.OT_name = null;
			
	} // end of method deleteDialog
	,
	
}; // end extension change_RTName of the admin functionality

// register the right click menu option
application.admin.adminPane_rightClickMenu.addOption(
	 T('renameRT.js/RenameRT_MNU','<strong>Rename</strong> relation type'), 
	function (){application.admin.renameRT.showDialog();}, 
	'rsIcon_rename', 
	function(item_type) { 
		return ( (item_type=='RT')?false:true); 
	}
);