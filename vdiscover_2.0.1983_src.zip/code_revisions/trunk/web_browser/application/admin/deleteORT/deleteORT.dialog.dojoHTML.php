<?php if (!defined('APPLICATION_started')) {header('Location: .');exit;}
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/
?>
 
<div dojoType="dijit.Dialog" id="application.admin.Dialogues.deleteORT" title="Confirm to delete a type" execute="void(false);">
	<div dojoType="dijit.form.Form" onSubmit="application.admin.deleteORT.execute(); return false;" action="javascript:void(false);">
		<table style="min-width:400px; max-width: 800px;">
			<tbody>
				<tr>
					<td id="application.admin.Dialogues.deleteORT.bodyText"></td>
				</tr>
				<tr  id="application.admin.Dialogues.deleteORT.deleteSubTypesSection">
					<td>
					    <p><?php echo T('deleteORT.php/WhatDoWSubOT_TXT', 'What shall be done with sub object types?'); ?></p>
					<p>
						<input id="application.admin.Dialogues.deleteORT.deleteSubType" name="application.admin.Dialogues.deleteORT.deleteSubType" dojoType="dijit.form.CheckBox" value="1"
						>
						<label for="application.admin.Dialogues.deleteORT.deleteSubType">
							<?php echo T('deleteORT.php/DelSubTypes_LBL', 'Sub types shall be deleted, as well. I am aware of the implied risks.'); ?>
						</label>
					</p>
					<p> <?php echo T('deleteORT.php/OtherwiseAllST_TXT', 'Otherwise, all sub types will be relocated to the current level.'); ?></p>
					</td>
				</tr>
				<tr>
					<td id="application.admin.Dialogues.deleteORT.errorMessage"></td>
				</tr>
				<tr>
					<td valign="top"style="text-align:right;">
						<button dojoType="dijit.form.Button" type="submit">
							<?php echo T('BTN_OK', 'OK') ?>
						</button>
						<button dojoType="dijit.form.Button" type="button" onClick="dijit.byId('application.admin.Dialogues.deleteORT').hide();">
							<?php echo T('BTN_Cancel', 'Cancel') ?>
						</button>
					</td>
				</tr>
			</tbody>
		</table>
	</div>
</div>	

