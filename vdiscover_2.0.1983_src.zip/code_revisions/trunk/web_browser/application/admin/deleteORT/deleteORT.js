/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// extend the admin functionality 
application.admin.deleteORT = { // Dialogue for deleting an information object type

	showDialogue : function() {
	
		// get the necessary information
		var name = application.admin.navigationStore.getValue(application.admin.currentNavigationItem,'name');
		var UUID = application.admin.navigationStore.getValue(application.admin.currentNavigationItem,'UUID');
		var type = application.admin.navigationStore.getValue(application.admin.currentNavigationItem,'type');
		
		// check if the OT or RT may be deleted
		application.AJAX_query(
			type,
			{
				"task"		: "may_delete"+type,
				"UUID"		: UUID
			}, 
			function(r, a) {
				if (! r) {
					// instance may not be deleted
					switch(type) {
						case 'OT':
							alert( T('deleteORT.js/NotAllowedToDelOT_TXT','You are not allowed to delete the object type "$[0]".',[name]) );
							break;
						case 'RT':
							alert( T('deleteORT.js/NotAllowedToDelRT_TXT','You are not allowed to delete the relation type "$[0]".',[name]) );
							break;
					}
				}
				else {
					// distinguish between OT and RT
					var dialogueTitle='', dialogueBodyText='';
					switch (type) {
						case 'OT':
							dialogueTitle = T('deleteORT.js/DelOT_TIT','Delete the Object Type « $[0]» ',[name]);
							dialogueBodyText = '<p>' + T('deleteORT.js/ReallyDeleteOT_HTM','Do you really want to delete the object type « <strong>$[0]</strong>» ?',[name]) + '</p>'
								+ '<p>&nbsp;</p>'
								+ '<p>' + T('deleteORT.js/DelDescrOT_P1_TXT','If you click on "OK", the following things will happen:') + '</p>'
								+ '<ul>'
								+ '<li>' + T('deleteORT.js/DelDescrOT_P2_HTM','All <strong>attributes</strong> and <strong>view types</strong> belonging to this object type will deleted.') + '</li>'
								+ '<li>' + T('deleteORT.js/DelDescrOT_P3_HTM','All <strong>objects</strong> of this type will deleted.') + '</li>'
								+ '<li>' + T('deleteORT.js/DelDescrOT_P4_HTM','All <strong>relation types</strong> starting or ending in this object type will be deleted.') + '</li>'
								//+ '<li>All <strong>sub object types</strong> below this object type will be moved up to the upper level.</li>'
								+ '<li>' + T('deleteORT.js/DelDescrOT_P5_HTM','The <strong>object type</strong> itself will be deleted.') + '</li>'
								+ '</ul>'
								+ '<p>' + T('deleteORT.js/ChooseWisely_TXT','Choose wisely ;-)') + '</p>'
								+ '<p>&nbsp;</p>';
							dojo.style('application.admin.Dialogues.deleteORT.deleteSubTypesSection','display','block');
							dijit.byId('application.admin.Dialogues.deleteORT.deleteSubType').attr('checked', false);				
							break;
						case 'RT':
							dialogueTitle = T('deleteORT.js/DelRT_TIT','Delete the Relation Type « $[0]» ',[name]);
							dialogueBodyText = '<p>' + T('deleteORT.js/ReallyDeleteRT_HTM','Do you really want to delete the relation type « <strong>$[0]</strong>» ?',[name]) + '</p>'
								+ '<p>&nbsp;</p>'
								+ '<p>' + T('deleteORT.js/DelDescrRT_P1_TXT','If you click on "OK", the following things will happen:') 
								+ '<ul>'
								+ '<li>' + T('deleteORT.js/DelDescrRT_P2_HTM','All <strong>attributes</strong> and <strong>view types</strong> belonging to this relation type will deleted.') + '</li>'
								+ '<li>' + T('deleteORT.js/DelDescrRT_P3_HTM','All <strong>relations</strong> of this type will deleted.') + '</li>'
								+ '<li>' + T('deleteORT.js/DelDescrRT_P4_HTM','All <strong>attributes</strong>, that make use of this type (e.g. relation attributes), will be deleted.') + '</li>'
								+ '<li>' + T('deleteORT.js/DelDescrRT_P5_HTM','The <strong>relation type</strong> itself will be deleted.') + '</li>'
								+ '</ul>'
								+ '<p>' + T('deleteORT.js/ChooseWisely_TXT','Choose wisely ;-)') + '</p>';
							dojo.style('application.admin.Dialogues.deleteORT.deleteSubTypesSection','display','none');
							break;
							break;
						default:
							application.showErrorMessage('Unknown type.');
					}

					// set some fields in the dialogue as necessary
					dijit.byId('application.admin.Dialogues.deleteORT').attr('title', dialogueTitle);
					dojo.byId('application.admin.Dialogues.deleteORT.bodyText').innerHTML = dialogueBodyText;
					
					// show the dialogue
					dijit.byId('application.admin.Dialogues.deleteORT').show();
				}
			},
			true
		);
		
	} // end-of-method showDialogue
	,
	
	execute : function() {
		
		// get the necessary information
		var UUID = application.admin.navigationStore.getValue(application.admin.currentNavigationItem,'UUID');
		var type = application.admin.navigationStore.getValue(application.admin.currentNavigationItem,'type');
		var deleteSubType = dijit.byId('application.admin.Dialogues.deleteORT.deleteSubType').attr('checked');

		// distinguish between OT and RT
		switch (type) {
			case 'OT':
				taskName_delete = 'delete_OT';
				break;
			case 'RT':
				taskName_delete = 'delete_RT';
				break;
			default:
				application.showErrorMessage('Unknown type.');
		}

		// tell the server to delete object or relation type
		application.AJAX_query(
			type,
			{
				"task"		: taskName_delete,
				"UUID"		: UUID,
				"withSubs"	: deleteSubType
			}, 
			application.admin.deleteORT.onSuccess,
			true
		);
	} // end-of-method execute
	,
	
	onSuccess :function(response,details){

		// refresh the admin pane
		application.admin.initialise_adminPane();
		
		// delete the type and all corresponding objects from the "I have seen ..." list
		application.O.readList.deleteType(details.args.content.UUID);
		
		// close the object type tab, if open
		var OT_tab_ID = application.OT.OT_tab_prepend + details.args.content.UUID;
		var OT_tab = dijit.byId(OT_tab_ID);
		if(OT_tab) OT_tab_container.closeChild(OT_tab);
		
		// hide the dialog
		dijit.byId('application.admin.Dialogues.deleteORT').hide();
		
	} // end-of-method onSuccess
	
}; // end admin section extension delete_OT

// register the right click menu option
application.admin.adminPane_rightClickMenu.addOption(
	'<strong>' + T('FUT_Delete','Delete') + '</strong>', 
	application.admin.deleteORT.showDialogue, 
	'rsIcon_delete', 
	function(item_type) { return( (item_type=='OT')||(item_type=='RT')?false:true); }
);
