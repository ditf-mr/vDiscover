/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare('application.widgets.manageAttributesDialog.attrMarkedDeleted',[dijit._Widget,dijit._Templated],{
	'dialog'		: null // needs to be set when initialising
	,
	'undoDelete'	: function (e) {
		dojo.stopEvent(e);
		this.dialog.undoDelete();
	} // end of method undoDelete
	,
	'templateString' : 	''
						+'<div>'
							+'<p>&nbsp;</p>'
							+'<p>' + T('attrMarkedDeleted.js/MarkedToDelete_TXT','You have marked that this attribute shall be deleted.') + '</p>'
							+'<p>' 
								+ T('attrMarkedDeleted.js/InCaseOfMistake_P1_TXT','In case this was a mistake,') 
								+ ' ' 
								+ '<a href="javascript:void(null);" dojoAttachEvent="onclick:undoDelete">' 
								+ T('attrMarkedDeleted.js/InCaseOfMistake_P2_TXT','click here to undo this.') 
							+'</a>' 
							+'</p>'
						+'</div>'
});
