﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare('application.widgets.configureAttributes.cbrConfiguration',[/*dijit.layout.ContentPane*/dijit._Widget,dijit._Templated],{

	attrInfo : null // item
	,
	widgetsInTemplate : true
	,
	// see http://dojotoolkit.org/reference-guide/dijit/_Widget.html
	// see as well http://dojotoolkit.org/reference-guide/quickstart/writingWidgets.html#quickstart-writingwidgets
	/*constructor : function() {
		// Your constructor method will be called before the parameters are mixed into the widget, and can be used to initialize arrays, etc.
		this.inherited(arguments);
	} // end of method constructor
	,*/
	
	postMixInProperties : function() {
		// If you provide a postMixInProperties method for your widget, 
		// it will be invoked before rendering occurs, and before 
		// any dom nodes are created. If you need to add or change the 
		// instance's properties before the widget is rendered 
		// - this is the place to do it.
		this.inherited(arguments);
		
		if(!((typeof this.attrInfo) == 'object')) throw ''+this.declaredClass+'.postMixInProperties() : no  attrInfo (attribute information item) passed. Aborting.';
		
		with (application.admin.manageAttributes.attributeStore) {
			this.UUID 				= getValue(this.attrInfo, 'UUID');
			this.weight				= getValue(this.attrInfo, 'CBRWeight');
			this.resolution			= getValue(this.attrInfo, 'CBRResolution');
			this.mustBeSet			= getValue(this.attrInfo, 'CBRMustBeSet')==0?"checked='checked'":"";
		} // end with 
		
		var obj = new Object ();
		obj.uuid = this.UUID;
		application.admin.manageAttributes.CBRattr.push(obj);
		
	} // end of method postMixInProperties
	,
	showEditHints_name : function () {
		application.admin.manageAttributes.showEditHints('attributeName');
	} // end of method showEditHints_name
	,
	'title' : 'General Options'
	,
	'templateString' : ""
		+"<div class='RS_attributeConfig_main'>"
			// +"<h3>CBR</h3>"
			+"<table class='fullWidth arrangement3070 listWithRows'><tbody>"
			
				+"<tr>"
					+"<td class='textRight'>"
							+"<input type='checkbox' "
								+"dojoType='dijit.form.CheckBox' "
								+"name='application.admin.manageAttributes.mustBeSet' "
								+"dojoAttachPoint='CBRMustBeSet_Ta' "
								+"dojoAttachEvent='onChange:CBR_enable_values' "
								+"${mustBeSet} "
								+"/>"
					+"</td>"
					+"<td class='textLeft' style='vertical-align:baseline;'>" + T('cbrConfiguration.js/IgnoreAttrCBR_TXT','Ignore this attribute for CBR:') + "</td>"
				+"</tr>"
				
				+"<tr>"
					+"<td class='textRight' style='vertical-align:baseline;'>" + T('cbrConfiguration.js/Resolution_TXT','Resolution:') + "</td>"
					+"<td>"
							+"<input type='text' "
								+"dojoType='dijit.form.TextBox' "
								+"name='application.admin.manageAttributes.resolution' "
								+"onfocus='application.admin.manageAttributes.showEditHints();' "
								+"dojoAttachPoint='CBRResolution_Ta' "
								+"dojoAttachEvent='onChange:CBRResolution_changed' "
								+"value='${resolution}' "
								+"/>"
					+"</td>"
				+"</tr>"
				
				+"<tr>"
					+"<td class='textRight' style='vertical-align:baseline;'>" + T('cbrConfiguration.js/Weight_TXT','Weight:') + "</td>"
					+"<td>"
							+"<input type='text' "
								+"dojoType='dijit.form.TextBox' "
								+"name='application.admin.manageAttributes.weight' "
								+"onfocus='application.admin.manageAttributes.showEditHints();' "
								+"dojoAttachPoint='CBRWeight_Ta' "
								+"dojoAttachEvent='onChange:CBRWeight_changed' "
								+"value='${weight}' "
								+"/>"
					+"</td>"
				+"</tr>"
				
			+"</tbody></table>"
		+"</div>"	
	,
	'CBR_enable_values' : function (e) {
		var obj = application.admin.manageAttributes.CBRattr.reverse().shift();
		if (e == true){
			obj.weight = 1.0;
			obj.resolution = 0.1;
		}else{
			obj.weight =  this.CBRWeight_Ta.attr('value');
			obj.resolution = this.CBRResolution_Ta.attr('value');
		}
		this.CBRWeight_Ta.attr('disabled',e);
		this.CBRResolution_Ta.attr('disabled',e);
		obj.mustbeset = !this.CBRMustBeSet_Ta.attr('checked');
		application.admin.manageAttributes.CBRattr.push(obj);
	} // end of method cbr_enable_values
	,
	/*buildRendering : function() {
		// dijit._Templated provides an implementation of buildRendering 
		// that most times will do what you need. The template is fetched/read, 
		// nodes created and events hooked up during buildRendering. The end 
		// result is assigned to this.domNode. If you don't mixin dijit._Templated 
		// (and most OOTB dijits do) and want to handle rendering yourself 
		// (e.g. to really streamline a simple widget, or even use a different 
		// templating system) this is where you'd do it.
		this.inherited(arguments);
	} // end of method buildRendering
	,*/
	CBRWeight_changed : function(e) {
		var obj = application.admin.manageAttributes.CBRattr.reverse().shift();
		obj.weight = this.CBRWeight_Ta.attr('value');
		application.admin.manageAttributes.CBRattr.push(obj);
	} // end of method
	,
	CBRResolution_changed : function(e) {
		var obj = application.admin.manageAttributes.CBRattr.reverse().shift();
		obj.resolution = this.CBRResolution_Ta.attr('value');
		application.admin.manageAttributes.CBRattr.push(obj);

	} // end of method
	,
	postCreate : function() {
		// This is typically the workhorse of a custom widget. The widget has 
		// been rendered (but note that sub-widgets in the containerNode have not!). 
		// The widget though may not be attached to the DOM yet so you shouldn't 
		// do any sizing calculations in this method.
		this.inherited(arguments);
		var selected = true;
		if(this.mustBeSet == ""){
			selected = false;
		}
		this.CBR_enable_values(selected);
		/*if(this.displayInFullWidth) {
			this.rB_displayInFullWidth_yes.attr('checked',true);
		} else {
			this.rB_displayInFullWidth_no.attr('checked',true);
		} */// end if
		
	} // end of method postCreate
	
	// name_changed : function(e) {
		// if(this.name_VTB.validate()) application.admin.manageAttributes.renameAttribute(this.UUID, this.name_VTB.attr('value'));
	// } // end of method
	// ,
	/*startup : function() {
		// If you need to be sure parsing and creation of any child widgets has 
		// completed, use startup. This is often used for layout widgets like 
		// BorderContainer. If the widget does JS sizing, then startup() should 
		// call resize(), which does the sizing.
		this.inherited(arguments);
	} // end of method startup
	,*/
	/*destroy : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you.
		this.inherited(arguments);
	} // end of method destroy
	*/
});