<?php if (!defined('APPLICATION_started')) {header('Location: .');exit;} 
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

$r->register_JavaScriptFile('application/admin/manageAttributes/manageAttributes.js');
$r->register_JavaScriptFile('application/admin/manageAttributes/attrMarkedDeleted.js');

// this belongs to UPC-INTEXTER functionality that is maintained by vfernanzez
$r->register_JavaScriptFile('application/admin/manageAttributes/cbrConfiguration.js');

?>