/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare('application.widgets.manageAttributesDialog',[common.widgets.fixedSizeDialog],{
	'innerWidth'	: 1200
	,
	'innerHeight'	: 800
	,
	
	// these slots have values need to be passed when creating the widget
	
	'OT_UUID'		: null // string -- needs to be overwritten upon instantiation
	,
	'OT_name'		: null // string -- needs to be overwritten upon instantiation
	,
	'OT_type'		: null // string -- either 'OT' or 'RT'
	,
	
	
	
	// the following slots form internal variables / containers
	
	'attrStore'		: null // dojo.data.itemFileWriteStore
	,
	'selectedAttributes'	: null // array
	,
	'currentUUID'	: null // UUID string
	,
	// the char that shows that a view is inherited is a UTF8 DOWNWARDS ARROW WITH TIP RIGHTWARDS
	// because this arrow is similar to the corresponding UML 2.0 relation
	'inheritedChar'		: '&#x21FD;' // see http://www.utf8-chartable.de/unicode-utf8-table.pl?start=8592&number=1024&unicodeinhtml=hex
	,
	'editHintList': { // needed for the 'format' option of the attribute configuration
		'attributeName' :	'hint_attributeName',
		'number' 		:	'hint_patternNumber',
		'regex' 		:	'hint_regex',
		'time' 			:	'hint_patternTime',
		'keyValuePair' 	: 	'hint_keyValuePair',
		'fuzzyValue' 	: 	'hint_fuzzyValue',
		'mimeTypes' 	: 	'hint_mimeTypes'
	}
	,
	'lastEditHint':''
	,
	
	
	'constructor' : function() {
		// Your constructor method will be called before the parameters are mixed into the widget, and can be used to initialize arrays, etc.
		// this.inherited(arguments);
		
		// some initialisations
		this.widgets 		= {};
		
		this.tagsWithAttributes = { // object - the tag names are the keys, arrays of attribute UUIDs form the slot values
			/*
			'TagUUID'	: {
				'name'		: 'Test 1',
				'A_UUIDs'	: ['A_UUID1', 'A_UUID2'],
			},*/
		}; 
		
	} // end of method constructor
	,
	'postMixInProperties' : function () {
		this.inherited(arguments);
	
		// set the dialog title
		this.title = (	this.OT_type=='OT' ? 
					T('manageAttributes.js/ManageAttrOT_HTM','Manage the Attributes of the Object Type « $[0]» ',[this.OT_name]) 
				: 	T('manageAttributes.js/ManageAttrRT_HTM','Manage the Attributes of the Relation Type « $[0]» ',[this.OT_name]) 
			);
	
	} // end of method postMixInProperties
	,
	'postCreate' : function () {
		// This is typically the workhorse of a custom widget. The widget has 
		// been rendered (but note that sub-widgets in the containerNode have not!). 
		// The widget though may not be attached to the DOM yet so you shouldn't 
		// do any sizing calculations in this method.
		this.inherited(arguments);
			
			// build the main structure of the dialog
		this.widgets.borderContainer = new dijit.layout.BorderContainer({
			'style' 	: 'width:100%;height:100%;',
			'gutters'	: false
		}).placeAt(this.containerNode);
		
		// create the action bar at the bottom of the dialog
		this.widgets.actionBar = new dijit.layout.ContentPane({
			'region'	: 'bottom',
			'class'		: 'dijitDialogPaneActionBar textRight',
			'style'		: 'padding-top:1em;'
		});
		this.widgets.borderContainer.addChild(this.widgets.actionBar);

		this.widgets.OkButton = new dijit.form.Button({
			'label' 	: '<img src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/dialog-ok-apply-4.png"/> '
				+T('BTN_OK','OK'),
			'type'		: 'button'
		}).placeAt(this.widgets.actionBar.containerNode);

		this.connect(this.widgets.OkButton,'onClick','execute');
		
		this.widgets.CancelButton = new dijit.form.Button({
			'label' 	: '<img width="12" src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/dialog-cancel-4.png"/> '
				+T('BTN_Cancel','Cancel'),
			'type'		: 'button',
			'style'		: 'margin-right:0;'
		}).placeAt(this.widgets.actionBar.containerNode);
		
		this._connects.push(dojo.connect( this.widgets.CancelButton,	'onClick', application.admin.manageAttributes, 'closeDialog'));
		this._connects.push(dojo.connect( this.widgets.closeButtonNode,	'onClick', application.admin.manageAttributes, 'closeDialog'));

		// create the main input regions of the dialog
		
		this.widgets.mainTabContainer = new dijit.layout.TabContainer({
			'region'	: 'center'		
		});
		this.widgets.borderContainer.addChild(this.widgets.mainTabContainer);
		
		// tag editor
		if (this.OT_type=='OT') {
			// tags for attributes
			this.widgets.tagEditorOuter = new dijit.layout.BorderContainer({
				'title' 	: T('manageAttributes.js/TagsForAttr_TXT','Tags for Attributes'),
				'gutters'	: false,
				'style'		: 'padding:.5ex;'
			});
			this.widgets.mainTabContainer.addChild(this.widgets.tagEditorOuter);
			
			this.widgets.tagEditorHeader = new dijit.layout.ContentPane({
				'region' 	: 'top',
				'content'	: ''
					+'<h2>' + T('manageAttributes.js/TagsForAttr_TXT','Tags for Attributes') + '</h2>'
					+'<p>' + T('manageAttributes.js/TaggingAttr_TXT','Tagging attributes permits to organise and to handle them in groups.') + '<p>'
			});
			this.widgets.tagEditorOuter.addChild(this.widgets.tagEditorHeader);
			
			this.widgets.tagEditorForm = new dijit.layout.BorderContainer({
				'region' 	: 'center',	
				'gutters'	: false,
			});
			this.widgets.tagEditorOuter.addChild(this.widgets.tagEditorForm);
			
			this.widgets.availableTagsBC = new dijit.layout.BorderContainer({
				'region' 	: 'left',	
				'gutters'	: false,
				'style'		: 'width: 15em;',
				'splitter'	: true,
			});
			this.widgets.tagEditorForm.addChild(this.widgets.availableTagsBC);
			
			this.widgets.availableTagsHeader = new dijit.layout.ContentPane({
				'region' 	: 'top',
				'content'	: ''
					+'<h3>' + T('manageAttributes.js/AvailTags_TXT','Available Tags') + '</h3>'
				,
			});
			this.widgets.availableTagsBC.addChild(this.widgets.availableTagsHeader);
			
			
			// Available tags -- multiSelect Widget
			this.widgets.tagListMultiSelect = new dijit.form.MultiSelect({
				'region'	: 'center',
				'class'		: 'fullWidth dijitMenuBar',
			});
			this.widgets.availableTagsBC.addChild(this.widgets.tagListMultiSelect);

			// set the multiSelect to singleSelect
			dojo.attr(this.widgets.tagListMultiSelect.containerNode, 'multiple', false);	
			
			
			
			this.widgets.availableTagsNewTagRegion = new dijit.layout.ContentPane({
				'region' 	: 'bottom',
				'content'	: ''
					+'<h3>' + T('manageAttributes.js/CreateNewTag_TXT','Create a new tag') + '</h3>'
					+'<table class="fullWidth compact">'
						+'<tr>'
							+'<td style="width:auto;">'
								+'<div class="createNewTagTextBox"></div>'
							+'</td>'
							+'<td style="">'
								+'<img class="createNewTagButton" title="' + T('manageAttributes.js/ClickCreateNewTag_LNK','Click here to create the new tag.') + '" style="vertical-align:middle;cursor:pointer;" src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/edit-add.png"/>'
							+'</td>'
						+'</tr>'
					+'</table>'
				,
			});
			this.widgets.availableTagsBC.addChild(this.widgets.availableTagsNewTagRegion);
			
			
			
			
			this.widgets.tagEditorBC = new dijit.layout.BorderContainer({
				'region' 	: 'center',	
				'gutters'	: false,
				'style'		: 'margin-left:.5ex;',
			});
			this.widgets.tagEditorForm.addChild(this.widgets.tagEditorBC);

			this.widgets.tagEditorHeader = new dijit.layout.ContentPane({
				'region' 	: 'top',
				'content'	: ''
					+'<h3>' + T('manageAttributes.js/CurrTag_TXT','Current tag') + '</h3>'
					+'<table class="fullWidth compact">'
						+'<tr>'
							+'<td style="width:auto;">'
								+'<div class="selectedTagTextBox"></div>'
							+'</td>'
							+'<td style="width:2.5em;">'
								+'<img class="deleteSelectedTagButton" title="' + T('manageAttributes.js/ClikcRemoveTag_LNK','Click here to remove this tag.') + '" style="vertical-align:middle;cursor:pointer;" src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/dialog-cancel-4.png"/>'
							+'</td>'
						+'</tr>'
					+'</table>'
				,
			});
			this.widgets.tagEditorBC.addChild(this.widgets.tagEditorHeader);

			
			// create the content pane for the attribute list and place the attribute list in it
			this.widgets.tagEditorCP = new dijit.layout.ContentPane({
				'region' 	: 'center',
				'content'	: ''
					+'<h3>' + T('manageAttributes.js/HereAttrList_TXT','Here goes the attribute list') + '</h3>'
				,
				'style'		: 'padding:.25em;'
			});
			this.widgets.tagEditorBC.addChild(this.widgets.tagEditorCP);
			
			this.tags_attrListNode = dojo.create('DIV');
			this.widgets.tagEditorCP.attr('content', this.tags_attrListNode);
			
			// New tags -- text box & clickable image
			this.createNewTagTextBox_domNode			= dojo.query('.createNewTagTextBox', 		this.widgets.availableTagsNewTagRegion.containerNode).shift();
			this.widgets.createNewTagTextBox = new dijit.form.ValidationTextBox({
				'class'			: 'fullWidth h4',
				'required'		: false,
				'regExp'		: '.{3,}',
				'selectOnClick'	: true,
			}, this.createNewTagTextBox_domNode);
			
			this.connect(	dojo.query('.createNewTagButton', this.widgets.availableTagsNewTagRegion.containerNode).shift(), 
							'onclick', 'createNewTag');

			// Current tag -- textbox
			
			this.selectedTagTextBox_domNode				= dojo.query('.selectedTagTextBox', 		this.widgets.tagEditorHeader.containerNode).shift();
			this.widgets.selectedTagTextBox = new dijit.form.ValidationTextBox({
				'class'					: 'fullWidth h4',
				'required'				: true,
				'regExp'				: '.{3,}',
				'selectOnClick'			: true,
				'intermediateChanges'	: true,
			}, this.selectedTagTextBox_domNode);
			this.connect(this.widgets.selectedTagTextBox, 'onChange', 'renameTag');
			
			this.deleteSelectedTagNode = dojo.query('.deleteSelectedTagButton',	this.widgets.tagEditorHeader.containerNode).shift();
			this.connect( this.deleteSelectedTagNode,
							'onclick', 'deleteTag');

			// reset all input fields
			this.tagListMultiSelect_onChange([]);
			
			// fill the list with the available tags
			for (var tagUUID in this.tagsWithAttributes) {
				var tagName = this.tagsWithAttributes[tagUUID].name;
				dojo.create('OPTION', {
					'value'			: tagUUID,
					'innerHTML'		: tagName,
				}, this.widgets.tagListMultiSelect.containerNode);
			
			} // end for .. in
			
			this.connect( this.widgets.tagListMultiSelect, 'onChange', 'tagListMultiSelect_onChange');
		} // end if show attribute editor
		
		
		
		
		
		this.widgets.attrEditor = new dijit.layout.BorderContainer({
			'title' 	: 'Attributes',
			'gutters'	: false,
			'style'		: 'padding:.5ex;'
		});
		this.widgets.mainTabContainer.addChild(this.widgets.attrEditor);
		
		// the attribute editor consists of ...
		
		// * a menu bar for creating, duplicating and deleting attributes
		// * a menu bar for moving attributes up and down
		// * a list of all currently defined attributes
		// * a title pane for the attribute name
		// * an edit pane with sections and a hint pane
		
		this.widgets.attrListBorderContainer = new dijit.layout.BorderContainer({
			'style' 	: 'width:30ex;margin:0;padding:0;', // margin-right:.5ex;
			'gutters'	: false,
			'region' 	: 'left',
			'splitter' 	: true,
			'minSize' 	: 100
		});
		this.widgets.attrEditor.addChild(this.widgets.attrListBorderContainer);
		
		// here comes the menu bar with the attribute life cycle
		
		this.widgets.attrListLifeCycleMenuBar = new dijit.MenuBar({
			'class' 	: 'small',
			'region' 	: 'top',
			'style'		: 'border:0'
		});
		this.widgets.attrListBorderContainer.addChild(this.widgets.attrListLifeCycleMenuBar);
		
		this.widgets.attrListNewAttrDropDown = new dijit.PopupMenuBarItem ({
			'label' 	: T('FUT_NewFromMenu','New …'),
			'popup' 	: new dijit.Menu({})
		});
		this.widgets.attrListLifeCycleMenuBar.addChild(this.widgets.attrListNewAttrDropDown);
		
		this.widgets.attrListDuplicateMenuItem = new dijit.MenuBarItem ({
			'label' 	: T('FUT_Duplicate','Duplicate'),
		});
		this.widgets.attrListLifeCycleMenuBar.addChild(this.widgets.attrListDuplicateMenuItem);
		this.connect( this.widgets.attrListDuplicateMenuItem, 'onClick', 'duplicateAttrs' );

		this.widgets.attrListUndoMenuItem = new dijit.MenuBarItem ({
			'label' 	: T('FUT_Undo','Undo'),
		});
		this.widgets.attrListLifeCycleMenuBar.addChild(this.widgets.attrListUndoMenuItem);
		this.connect( this.widgets.attrListUndoMenuItem, 'onClick', 'undoChanges' );

		this.widgets.attrListDeleteMenuItem = new dijit.MenuBarItem ({
			'label' 	: T('FUT_Delete','Delete'),
		});
		this.widgets.attrListLifeCycleMenuBar.addChild(this.widgets.attrListDeleteMenuItem);
		this.connect( this.widgets.attrListDeleteMenuItem, 'onClick', 'deleteAttrs' );
		
		// create the attribute list
		this.widgets.attrList = new dijit.form.MultiSelect({
			'region' 	: 'center',
			'class'		: 'dijitMenuBar',
			'style'		: 'width:100%;border-right:0;border-left:0;padding-left:.5ex;',
			// 'scope'		: this // this is important for the scope in the connector function, below
		});
		this.widgets.attrListBorderContainer.addChild(this.widgets.attrList);
		
		this.connect( this.widgets.attrList, 'onChange', function(c){
			this/*.scope*/.selectedAttributesHaveChanged(c);
		});
				
		// create the buttons for moving the attributes up and down in the list
		this.widgets.attrPositionMenuBar = new dijit.layout.ContentPane({
			'region' 	: 'bottom',
			'class'		: 'small',
			'style'		: 'padding:.5ex;'
		});
		this.widgets.attrListBorderContainer.addChild(this.widgets.attrPositionMenuBar);
		
		this.widgets.moveAttrUp = new dijit.form.ComboButton({
			'label' 	: '&uarr;',
			'dropDown' 	: new dijit.Menu({}),
			'style'		: 'margin-right:1ex;',
			'scope'		: this,
			'posOffset'	: -15
		}).placeAt(this.widgets.attrPositionMenuBar.containerNode);
		this._connects.push(
			dojo.connect(this.widgets.moveAttrUp,'onClick',this.widgets.moveAttrUp,function(){
				this.scope.moveAttributes(this.posOffset);
			})
		);
		
		this.widgets.moveAttrTenUp = new dijit.MenuItem({
			'label' 	: '&uArr;',
			'scope'		: this,
			'posOffset'	: -65
		});
		this.widgets.moveAttrUp.dropDown.addChild(this.widgets.moveAttrTenUp);
		this._connects.push(		
			dojo.connect(this.widgets.moveAttrTenUp,'onClick',this.widgets.moveAttrTenUp,function(){
				this.scope.moveAttributes(this.posOffset);
			})
		);
		
		this.widgets.moveAttrTop = new dijit.MenuItem({
			'label' 	: T('FUT_top','top'),
			'scope'		: this,
			'posOffset'	: -500000
		});
		this.widgets.moveAttrUp.dropDown.addChild(this.widgets.moveAttrTop);
		this._connects.push(
			dojo.connect(this.widgets.moveAttrTop,'onClick',this.widgets.moveAttrTop,function(){
				this.scope.moveAttributes(this.posOffset);
			})
		);
		
		this.widgets.moveAttrDown = new dijit.form.ComboButton({
			'label' 	: '&darr;',
			'dropDown' 	: new dijit.Menu({}),
			'scope'		: this,
			'posOffset'	: +15
		}).placeAt(this.widgets.attrPositionMenuBar.containerNode);
		this._connects.push(
			dojo.connect(this.widgets.moveAttrDown,'onClick',this.widgets.moveAttrDown,function(){
				this.scope.moveAttributes(this.posOffset);
			})
		);
		
		this.widgets.moveAttrTenDown = new dijit.MenuItem({
			'label' 	: '&dArr;',
			'scope'		: this,
			'posOffset'	: +65
		});
		this.widgets.moveAttrDown.dropDown.addChild(this.widgets.moveAttrTenDown);
		this._connects.push(
			dojo.connect(this.widgets.moveAttrTenDown,'onClick',this.widgets.moveAttrTenDown,function(){
				this.scope.moveAttributes(this.posOffset);
			})
		);
		
		this.widgets.moveAttrBottom = new dijit.MenuItem({
			'label' 	: T('FUT_bottom','bottom'),
			'scope'		: this,
			'posOffset'	: +500000
		});
		this.widgets.moveAttrDown.dropDown.addChild(this.widgets.moveAttrBottom);
		this._connects.push(
			dojo.connect(this.widgets.moveAttrBottom,'onClick',this.widgets.moveAttrBottom,function(){
				this.scope.moveAttributes(this.posOffset);
			})
		);
		
		// create and fill the container for the attribute editor
		
		this.widgets.attrEditorBC = new dijit.layout.BorderContainer({
			'gutters'	: false,
			'region' 	: 'center',
			'style'		: 'margin-left:.5ex;'
		});
		this.widgets.attrEditor.addChild(this.widgets.attrEditorBC);
		
		this.widgets.attrEditorAttrNameInput = new dijit.form.ValidationTextBox({
			'region'				: 'top',
			'class'					: 'h2',
			'value'					: 'Attribute name',
			'intermediateChanges' 	: true,
			'selectOnClick' 		: true,
			'style'					: 'padding-left:.5ex;padding-bottom:.5ex;margin--bottom:.5ex;',
		});
		this.widgets.attrEditorBC.addChild(this.widgets.attrEditorAttrNameInput);
		
		this.widgets.alternativeTitlePane = new dijit.layout.ContentPane({
			'region' : 'top',
		});
		
		this.widgets.attrEditorAttrEditPane = new dijit.layout.ContentPane({
			'region'	: 'center',
			'content'	: '<p>' + T('manageAttributes.js/TheEditingPanes_TXT','The editing panes go in, here') + '</p>',
			'style'		: 'padding-right:.5ex;margin:.5ex;',
		});
		this.widgets.attrEditorBC.addChild(this.widgets.attrEditorAttrEditPane);
		
		this.widgets.attrEditorHintPane = new dijit.layout.ContentPane({
			'region'	: 'right',
			'style'		: 'width:300px;margin:.5ex;margin-left:1ex;padding:.5ex;overflow-y:auto;border-top:0;border-bottom:0;border-right:0;',
			'class'		: 'dijitMenuBar small',
		});
		
		
		/*
		//
		//THIS IS PART OF MODSIMTEX
		//
		// CBR
		application.admin.manageAttributes.CBRattr = new Array();
		//END MODSIMTEX
		//
		*/
		
		// load the configuration data from the server
		this.buildNewAttrMenu();
		this.loadConfigFromServer();
		
		// some preparations and initialisations
		this.renumberAttrPositions();
		this.outputAttributeList();
		this.buildTagList();
		
		// show the attribute editor
		this.widgets.mainTabContainer.selectChild(this.widgets.attrEditor);
		
	} // end of method postCreate
	,
	'loadConfigFromServer' : function () {
		
		// load the attribute list from the server and create a store for them
		dojo.xhrPost({
			'url'		: '?'
			,
			'content'	: {
				'v'		: (this.OT_type=='OT'?'JSON_ObjectType':'JSON_RelationType'),
				"task"	: (this.OT_type=='OT'?'get_OT_attributes':'get_RT_attributes'), 
				"relationConfig": 'withoutEndObjAndAttributeInfo', 
				"UUID"	: this.OT_UUID 
			}
			,
			'error'		: 	application.AJAX_errorMessage, // function
			'handleAs'	: 'json',
			'scope'		: this,
			'load'		: function(response,request){ /* onSuccess */
				
				// set up the attribute store
				request.args.scope.attrStore = new dojo.data.ItemFileWriteStore({
						'data'			: response, 
						'clearOnClose' 	: true,
						// 'hierarchical'	: true
					});
				
				// build the tag list @ request.args.scope.tagsWithAttributes
				request.args.scope.tagsWithAttributes = {};
				if (request.args.scope.OT_type!='OT') return;
				dojo.forEach(response.items, function(i){
					var tags = dojo.fromJson(i.tags),
						A_UUID = i.UUID;
					
					for (var T_UUID in tags) {
						var T_name = tags[T_UUID];
					
						if ( !(T_UUID in this.tagsWithAttributes) ) {
							this.tagsWithAttributes[T_UUID] = {
								'name'			: T_name,
								'A_UUIDs'		: {},
								'editStatus'	: 'untouched' // || 'inserted' || 'changed' || 'deleted'
								// 'isInherited'	: false,
							};
						} // end if
					
						this.tagsWithAttributes[T_UUID].A_UUIDs[A_UUID] = {
							'editStatus' :'untouched'
						};
					} // end for .. in
					
				}, request.args.scope /* this */);
				
			}, // end of onSuccess method
			//preventCache:true,
			//failOk	: true,
			'sync'		: true,
			'timeout'	: 	application.configuration.global.AJAX_default_timeout
		});
		
	} // end of method loadConfigFromServer
	,
	'outputAttributeList' : function (selectedAttributes) {

		var numAttributes =0;
	
		this.selectedAttributes=((typeof selectedAttributes=='object') ? selectedAttributes : []);
	
		// empty the attribute list
		dojo.empty(this.widgets.attrList.containerNode);
					
		// query for all views and add all views to the view list
		this.attrStore.fetch({
			'query'	: { 'UUID'	: '*'},
			'scope'	: this,
			'onItem': function (item,request) {
				var UUID 	= this.attrStore.getValue(item, 'UUID');
				var selected= ((		(this.selectedAttributes)
								&&	(this.selectedAttributes.length>0)
								&&	(dojo.indexOf(this.selectedAttributes,UUID)>=0)
								)?true:false);
				this.createItemInAttributeList(item, selected);
				numAttributes++;
			}, // end onItem
			'sort' 	:  [	{	'attribute'	: 'positionOfAttribute' 	/*, descending: true*/}, 
							{ 	'attribute'	: 'name'					/*, descending: true*/}
						]
		}); // end fetch
		
		// display the attributes
		if (numAttributes) 	this.selectedAttributesHaveChanged(this.selectedAttributes);
			else			this.showNoAttributesYetMessage();
			
	} // end of method outputAttributeList		
	,
	'displayAttribute' : function (UUID) {
		// this method displays the edit dialog components for view with UUID
		
		var inherited, 
			name 			= '', 
			kind 			= '',
			editStatus 		= '',
			cssClass		= '',
			attrItem			= null;
			
		// get the corresponding view
		this.attrStore.fetchItemByIdentity({
			'identity' 	: UUID,
			'scope'		: this,
			'onItem' 	: function (item) {
				// is the the view inherited?
				inherited 			= this.attrStore.getValue(item, 'isInherited') || false;
				name				= this.attrStore.getValue(item, 'name');
				this.currentUUID	= this.attrStore.getValue(item, 'UUID');
				kind 				= this.attrStore.getValue(item, 'kind');
				// attrTypeString		= application.viewKinds.viewKindList[kind].name;
				if (this.attrStore.hasAttribute(item, 'editStatus')) 
					editStatus 		= this.attrStore.getValue(item, 'editStatus');				
					cssClass		= this.getCSSClassForEditStatus(editStatus);
					attrItem		= item;
			} // end of function onItem
		}); // end get the item
		
		// set the name pane
		this.widgets.attrEditorBC.removeChild(this.widgets.alternativeTitlePane);
		this.widgets.attrEditorBC.removeChild(this.widgets.attrEditorAttrNameInput);
		if (this._renameAttribute_connect) this.disconnect(this._renameAttribute_connect);
		
		// is the attribute inherited?
		this.widgets.attrEditorAttrNameInput.attr('value', (inherited?'⇽'+' ':'')+name);
		if(inherited) { // the attribute is inherited
			this.widgets.attrEditorAttrNameInput.set('title', T('manageAttributes.js/AttrIsInherited_TXT','This attribute is inherited, hence its name cannot be changed.') );
		} else { // the attribute is defined, locally 
			this.widgets.attrEditorAttrNameInput.set('title', T('manageAttributes.js/ClickToEditAttrName_LNK','Click here to edit the attribute&apos;s name.') );
			if (editStatus!='deleted') this._renameAttribute_connect = this.connect(this.widgets.attrEditorAttrNameInput, 'onChange', 'renameAttribute');
		} // end if
		this.widgets.attrEditorAttrNameInput.set('disabled', inherited || (editStatus=='deleted') );
		dojo.toggleClass( this.widgets.attrEditorAttrNameInput.focusNode, 'inserted', false);
		dojo.toggleClass( this.widgets.attrEditorAttrNameInput.focusNode, 'modified', false);
		dojo.toggleClass( this.widgets.attrEditorAttrNameInput.focusNode, 'deleted' , false);
		dojo.toggleClass( this.widgets.attrEditorAttrNameInput.focusNode, cssClass,   true);
		this.widgets.attrEditorBC.addChild(this.widgets.attrEditorAttrNameInput);
		
		// clear the edit pane
		var eCW = this.widgets.attrEditorAttrEditPane.getChildren();
		dojo.forEach(eCW,function(w){
			if (w.destroyRecursive) w.destroyRecursive(false);
			if (w.destroy)			w.destroy();
			delete w;
		}, this);
		delete eCW;
		this.widgets.attrEditorAttrEditPane.attr('content', '');
				
		if(editStatus=='deleted') { // view is marked to be deleted
		
			this.widgets.attrEditorAttrEditPane.attr('content', 
				new application.widgets.manageAttributesDialog.attrMarkedDeleted({
					'dialog': this,
				})
			);
					
		} else { // output the edit widgets
		
			// a spacer
			dojo.create('P', {'innerHTML':'&nbsp;'}, this.widgets.attrEditorAttrEditPane.containerNode);
			
			// a hint that with inherited attributes, not everything is possible
			if (inherited) {
				var inheritanceChain = dojo.fromJson(this.attrStore.getValue(attrItem, 'inheritanceChain'));
				inheritanceChain.push(this.OT_name);
				dojo.create('DIV', {'class':'small','innerHTML': ''
						+'<p>' + T('manageAttributes.js/ThisAttrInher_TXT','This attribute is an interited <$[0]> one.',[this.inheritedChar]) 		+ '</p>'
						+'<p>' + T('manageAttributes.js/InherChain_TXT','Inheritance chain:') + ' <code>'+inheritanceChain.join(this.inheritedChar)	+'</code></p>'
						+'<p>' + T('manageAttributes.js/OnlyModSomeSpecProp_TXT','Hence, you may only modify some special properties.') 			+ '</p>'
					}, this.widgets.attrEditorAttrEditPane.containerNode );
				dojo.create('P', {'innerHTML':'&nbsp;'}, this.widgets.attrEditorAttrEditPane.containerNode);
			} // end if
			
			// include the hint pane
			this.widgets.attrEditorBC.addChild(this.widgets.attrEditorHintPane);
			this.widgets.attrEditorHintPane.attr('content','');
			
			// attribute-specific properties
			if (application.widgets.configureSpecialAttribute[kind]) {
			
				var tP = new dijit.TitlePane({
					'title'		: 'Attribute-specific properties',
					'content' 	: new application.widgets.configureSpecialAttribute[kind]({'dialog' : this, 'attrItem' : attrItem }),
					'open'		: true,
				});
				tP.placeAt(this.widgets.attrEditorAttrEditPane.containerNode);
				tP.startup();
					
			} // end if

			// add an empty line to the edit pane
			dojo.create('P',{'innerHTML':'&nbsp;'},this.widgets.attrEditorAttrEditPane.containerNode);
			
			// cardinality-related options
			if(application.attributeKinds.attributeKindList[kind].fixedCardinality) {
				// fixed cardinality
				dojo.create('P', {
						'class'		: 'small',
						'innerHTML'	: ''
							+ T('manageAttributes.js/ThisAttrFixedCardinality_HTM','This attribute has a <em>fixed</em> cardinality of <code>1</code>. This means that only one value tuple is permitted.')
					}, this.widgets.attrEditorAttrEditPane.containerNode);
					
			} else { // configurable cardinality
				// create and place cardinality editor
				var tP = new dijit.TitlePane({
					'title'		: T('manageAttributes.js/Cardinality_TIT','Cardinality') ,
					'content' 	: new application.widgets.configureAttribute.cardinalityConfiguration({'dialog' : this, 'attrItem' : attrItem }),
					'open'		: false,
				});
				tP.placeAt(this.widgets.attrEditorAttrEditPane.containerNode);
				tP.startup();				
			} // end if
			
			// add an empty line to the edit pane
			dojo.create('P',{'innerHTML':'&nbsp;'},this.widgets.attrEditorAttrEditPane.containerNode);
			
			// editing contraints
			if(application.attributeKinds.attributeKindList[kind].fixedReadOnly) {
				// fixed readOnly, mustBeSet, mustBeUnique
				dojo.create('p', {
					'class'			: 'small',
					'innerHTML' 	: ''
						+ T('manageAttributes.js/ThisAttAutoGenVal_TXT','This attribute has automatically generated values.')
						// +'This means that the attribute is <code>read only</code>, '
						// +'it <code>must be set</code> and the <code>values need to be unique</code>.'
					},
					this.widgets.attrEditorAttrEditPane.containerNode);
			} else { // configurable readOnly, mustBeSet, mustBeUnique
			
				// create and place the readOnly editor	
				var tP = new dijit.TitlePane({
					'title'		: T('manageAttributes.js/EditConstr_TIT','Editing constraints') ,
					'content' 	: new application.widgets.configureAttribute.readOnlyConfiguration({'dialog' : this, 'attrItem' : attrItem }),
					'open'		: false,
				});
				tP.placeAt(this.widgets.attrEditorAttrEditPane.containerNode);
				tP.startup();
					
			} // end if

			// add an empty line to the edit pane
			dojo.create('P',{'innerHTML':'&nbsp;'},this.widgets.attrEditorAttrEditPane.containerNode);
			
			// general options
			var tP = new dijit.TitlePane({
				'title'		: T('manageAttributes.js/GeneralOpt_TIT','General options'),
				'content' 	: new application.widgets.configureAttribute.generalConfiguration({'dialog' : this, 'attrItem' : attrItem }),
				'open'		: false,
			});
			tP.placeAt(this.widgets.attrEditorAttrEditPane.containerNode);
			tP.startup();				
			
			// add an empty line to the edit pane
			dojo.create('P',{'innerHTML':'&nbsp;'},this.widgets.attrEditorAttrEditPane.containerNode);
			
			// Analytical expression
			if(application.attributeKinds.kindPermitsAnalyticalExpressions(kind)) {
				
				// Analytical expression are supported for this attribute kind
			
				var aP = new dijit.TitlePane({
					'title'		: T('manageAttributes.js/AnalyticalExpressions_TIT','Analytical expression'),
					'content' 	: new application.widgets.configureAttribute.analyticalExpressionConfiguration({'dialog' : this, 'attrItem' : attrItem }),
					'open'		: true,
				});
				aP.placeAt(this.widgets.attrEditorAttrEditPane.containerNode);
				aP.startup();
				
			} else {

				// Analytical expression are not supported
			
				dojo.create('P', { 'class':'small', 'innerHTML': ''
						+T('manageAttributes.js/AnalyticalExpressions_notSupported','The kind of this attribute does not support analytical expressions.')
					}, this.widgets.attrEditorAttrEditPane.containerNode);
			
			
			} // end if
			
			/*
			//
			//THIS IS PART OF MODSIMTEX
			//
			// CBR
			var store = this.attrStore;		
			var este = this;					
			var xhrArgs = {
				url: "?PHP_dojoHTML_file=json/Attribute.json/modsimtex_installed.php",
				handleAs: "json",
				sync: true,
				content: {
					uuid: store.getValue(attrItem, 'UUID')
				},
				load: function(jsonData) {
					if (jsonData != '{"done":"ko"}'){
						var items = (dojo.clone(jsonData));
						 
						store.setValue(attrItem, 'CBRWeight', items.weight);
						store.setValue(attrItem, 'CBRResolution', items.resolution);
						store.setValue(attrItem, 'CBRMustBeSet', items.mustbeset);
						
						var tP = new dijit.TitlePane({
							'title'		: 'CBR options',
							'content' 	: new application.widgets.configureAttribute.cbrConfiguration({'dialog' : este, 'attrItem' : attrItem })
						});
						tP.placeAt(este.widgets.attrEditorAttrEditPane.containerNode);
						tP.startup();
					}
				},
				error: function(error) 
				{
					var dialog = new dijit.Dialog({ title: 'Error', content: error, style: "width: 500px" });
					dialog.show();
				}
			};
			dojo.xhrGet(xhrArgs);
			*/
			
			
			// plug-ins
			/*
			if (application.attributeKinds.configurationExtensions[kind]) {
				// add an empty line to the edit pane
				dojo.create('P',{'class':'small','innerHTML':'&nbsp;'},this.widgets.attrEditorAttrEditPane.containerNode);
				
				// instantiate and add the plugin widget
				var tP = new dijit.TitlePane({
					'title'		: application.attributeKinds.configurationExtensions[kind].configurationWidgetTitle,
					'content' 	: new application.attributeKinds.configurationExtensions[kind]['configurationWidgetName']({'dialog' : this, 'attrItem' : attrItem })
				});
				tP.placeAt(this.widgets.attrEditorAttrEditPane.containerNode);
				tP.startup();				

			} // end if 
			*/
			
			//dojo.create('P',{'innerHTML':'&nbsp;'},this.widgets.attrEditorAttrEditPane.containerNode);
		}; // end if
		
	} // end of method displayView
	,
	'renameAttribute' : function (newName) {
	
		// build a unique attribute name
		var n = this.buildUniqueNameForAttribute(newName,this.currentUUID);
		this.changeAttribute('name', n);
	
		// actualise the name in the attribute list
		var node = dojo.byId('application.admin.mA.a_'+this.currentUUID);
		if (node) dojo.attr( node, 'innerHTML', n );
		
		// actualise correct name in textBox
		this.widgets.attrEditorAttrNameInput.attr('value', n);

	} // end of method renameView
	,
	'changeAttribute': function( propertyName, propertyValue ) {
		
		//console.log ('changeAttribute', propertyName, propertyValue );
		
		this.attrStore.fetchItemByIdentity({
			'scope'		: this,
			'identity' 	: this.currentUUID,
			'onItem' 	: function (item) {
			
					// get the current attribute value
					var currentValue = this.attrStore.getValue(item, propertyName);

					if(propertyValue!=currentValue) {
					
						// console.log(propertyValue, '!=', currentValue);
					
						this.attrStore.setValue(item, propertyName, propertyValue);
						
						// attribute needs to be marked as 'modified'?
						if (this.attrStore.getValue(item, 'editStatus') != 'inserted'){
						
							this.attrStore.setValue(item, 'action', 	'change');
							this.attrStore.setValue(item, 'editStatus', 'changed');
						
							// toggle the class of the corresponding option in the select list
							var oNode = dojo.byId('application.admin.mA.a_'+this.currentUUID);
							dojo.attr(oNode, 'class', 'modified');							
							
						} // end if attribute needs to be marked as 'modified'
						
					} // end if
					
			} // end of function onItem
		}); // end get the item
		
	} // end of method changeAttribute
	,
	'selectedAttributesHaveChanged' : function (selectedAttributes) {
		// this method decides what needs to be displayed in the edit area
		
		this.selectedAttributes=((typeof selectedAttributes=='object') ? selectedAttributes : []);
		
		// clear the edit area
		// this.widgets.viewNamePane.destroyDescendants();
		// this.widgets.viewEditor.destroyDescendants();

		this.widgets.attrEditorBC.removeChild(this.widgets.alternativeTitlePane);
		this.widgets.attrEditorBC.removeChild(this.widgets.attrEditorAttrNameInput);
		this.widgets.attrEditorBC.removeChild(this.widgets.attrEditorHintPane);
		
		switch(this.selectedAttributes.length){
			case 1: // one attribute selected -- load the edit dialog into the edit area
				this.displayAttribute(this.selectedAttributes[0]);
				break;
				
			case 0: // nothing selected

				this.widgets.alternativeTitlePane.set('content', ''
					+'<h2>'
						+ T('manageAttributes.js/SelCreaAttr_TIT','Select or create an attribute')
					+'</h2>'
					);
				this.widgets.attrEditorBC.addChild(this.widgets.alternativeTitlePane);
				this.widgets.attrEditorAttrEditPane.set('content', ''
						+ '<ul>'
						+T('manageAttributes.js/SelCreateNewAttr_HTM','<li>Please select a attribute on the left hand side or</li><li>create a new one.</li>') 
						+'</ul>'
					);
				break;
				
			default: // many attributes -- list the attributes
			
				// get the names of all selected attributes
				var names=[];
				
				dojo.forEach(this.selectedAttributes, function(UUID, nr) {
					// get the corresponding item
					this.attrStore.fetchItemByIdentity({
						'identity' 	: UUID,
						'scope'		: this,
						'onItem' 	: function (item, request) {
							var name 		= this.attrStore.getValue(item, 'name'		),
								editStatus 	= this.attrStore.getValue(item, 'editStatus');
							
							names.push('<li class="'+this.getCSSClassForEditStatus(editStatus)+'">'+name+'</li>');		
						} // end of function onItem
					}); // end fetch
				},this); // end for each UUID
			
				// output a nice view list
				this.widgets.alternativeTitlePane.set('content', ''
					+ '<h2>'
							+ T('manageAttributes.js/YouSelectedXAttr_TXT','You have selected $[0] attributes:',[this.selectedAttributes.length]),
					+ '</h2>'
				);
				this.widgets.attrEditorBC.addChild(this.widgets.alternativeTitlePane);
				this.widgets.attrEditorAttrEditPane.set('content', ''
					+ '<ul>'
						+names.join('')
					+ '</ul>'
					+ '<p>&nbsp;</p>'
					+ '<p>'
						+ T('manageAttributes.js/AttrModifyTip_P1_HTM','Click on a single attribute to edit its properties.')
					+ '</p>'
					+ '<p>'
						+ T('manageAttributes.js/AttrModifyTip_P2_HTM','You may as well duplicate, move or delete the selected attributes or undo all changes to them.')
					+ '</p>'
				);
				
		} // end switch	
	} // end of method selectedAttributesHaveChanged
	,
	'showNoAttributesYetMessage' : function () {
		
		// clear the edit area
		this.widgets.attrEditorBC.removeChild(this.widgets.alternativeTitlePane);
		this.widgets.attrEditorBC.removeChild(this.widgets.attrEditorAttrNameInput);

		// set the attribute name pane		
		this.widgets.alternativeTitlePane.set('content', ''
			+'<h2>'
				+ T('manageAttributes.js/OTHasNoAttr_TXT','« $[0]»  has no attributes, yet',[this.OT_name])
			+'</h2>'
			);
		this.widgets.attrEditorBC.addChild(this.widgets.alternativeTitlePane);
		
		// set the view editor
		this.widgets.attrEditorAttrEditPane.set('content', ''
				+ '<p>'
				+ T('manageAttributes.js/YouShldCreateAttr_TXT','You should create some attributes for « $[0]» .',[this.OT_name]) 
					// +'<p>.</p>'
					// +'<ul><li>RS II will use the default name view as a name template for the objects of this type. '
					// +'This permits to generate the object names automatically from attribute values of the objects.</li>'
					// +'<li>The default description view is displayed in the list of all objects.</li></ul>'
				+ '</p>'
			);
		
	} // end of method showNoViewsYetMessage
	,
	'createItemInAttributeList' : function (item, selected) {

		var UUID 		= this.attrStore.getValue(item, 'UUID'		);
		var name 		= this.attrStore.getValue(item, 'name'		);
		var editStatus 	= this.attrStore.getValue(item, 'editStatus');
		var inherited	= this.attrStore.getValue(item, 'isInherited');
		
		// prepare the attributes of the new DOM node
		var o = {
			'id'		: 'application.admin.mA.a_'+UUID,
			'innerHTML'	: (inherited?this.inheritedChar+' ':'')+name,
			'value'		: UUID,
			'class'		: this.getCSSClassForEditStatus(editStatus)
		};
				
		if (selected) o['selected'] = 'selected';
				
		// create the option DOM node
		dojo.create( 'option', o, this.widgets.attrList.containerNode /* where to place the newly created node as a child */ );
		
	} // end of method createItemInViewList
	,
	'getCSSClassForEditStatus' : function (editStatus) {
		switch (editStatus) {
			case 'inserted'	:	return 'inserted';
			case 'changed'	:	return 'modified';
			case 'deleted'	:	return 'deleted';
			default			: 	return '';
		} // end switch edit status
	} // end of method getCSSClassForEditStatus
	,
	'execute' : function () {
		
		// delete all attributes that are marked to be deleted
		this.attrStore.fetch ({
			'scope'		: this,
			'query'		: { 'editStatus': 'deleted' }, 
			'onItem'	: function ( item, request ) {
				this.attrStore.deleteItem( item );
			} // end of method onItem
		});		
		
		// integrate the tag list into the store contents
		var tagsByAttribute = {};
		
		for (var tUUID in this.tagsWithAttributes) {
			if (this.tagsWithAttributes[tUUID].editStatus!='deleted') {
			
				var tName = this.tagsWithAttributes[tUUID].name;
				
				for (var A_UUID in this.tagsWithAttributes[tUUID].A_UUIDs) {
					if(!(typeof tagsByAttribute[A_UUID]=='object')) tagsByAttribute[A_UUID]={};
					tagsByAttribute[A_UUID][tUUID]=tName;
				} // end for .. in
				
			} // end if not deleted
		} // end for .. in
		
		// assign to each attribute the tags
		this.attrStore.fetch ({
			'scope'		: this,
			//'query'		: { 'editStatus': 'deleted' }, 
			'onItem'	: function ( item, request ) {
				var	A_UUID 		= this.attrStore.getValue( item, 'A_UUID' ),
					tagsAsJSON	= ((A_UUID in tagsByAttribute)?dojo.toJson(tagsByAttribute[A_UUID]):'{}');
				this.attrStore.setValue( item, 'tags', tagsAsJSON );
			} // end of method onItem
		});
		
		// consolidate the store contents
		this.attrStore.save();		
		
		// send the attribute configuration to the server
		dojo.xhrPost({
			'url'		: '?',
			'content'	: {
				'v'				: (this.OT_type=='OT'?'JSON_ObjectType':'JSON_RelationType'),
				"task"			: (this.OT_type=='OT'?'set_OT_attributes':'set_RT_attributes'), 
				"UUID"			: this.OT_UUID ,
				"attributes"	: this.attrStore._getNewFileContentString()
			},
			'error'		: 	application.AJAX_errorMessage, // function
			'handleAs'	: 'json',
			// 'scope'		: this,
			//preventCache:true,
			//failOk	: true,
			'sync'		: true,
			'timeout'	: 	application.configuration.global.AJAX_default_timeout
		});
		
		// close the dialog
		application.admin.manageAttributes.closeDialog();
		
		/*
		//
		//THIS IS PART OF MODSIMTEX
		//
		// CBR
		var xhrArgs = {
						url: "?PHP_dojoHTML_file=json/Attribute.json/modsimtex_installed.php",
						handleAs: "json",
						sync: true,
						content: {
							uuid: -9
						},
						load: function(jsonData) {
							if (jsonData != '{"done":"ko"}'){
								//MODSIMTEX IS LOADED
								var xhrArgs = {
									url: "?PHP_dojoHTML_file=../common_plugins/MODSIMTex/saveAttributes.php",
									handleAs: "json",
									sync: true,
									content: {
										datos : dojo.toJson(application.admin.manageAttributes.CBRattr)
									},
									error: function(error) 
									{
										application.admin.manageAttributes.CBRattr = new Array();
										var dialog = new dijit.Dialog({ title: 'Error', content: error, style: "width: 500px" });
										dialog.show();
									}
								};
								dojo.xhrPost(xhrArgs);
							}
						},
						error: function(error) 
						{
							application.admin.manageAttributes.CBRattr = new Array();
							var dialog = new dijit.Dialog({ title: 'Error', content: error, style: "width: 500px" });
							dialog.show();
						}
					};
		dojo.xhrGet(xhrArgs);
		//END OF MODSIMTEX
		*/
		
		
	} // end of method
	,
	'destroy' : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		
		for (var i in this.widgets) {
			if (this.widgets[i].destroyRecursive) this.widgets[i].destroyRecursive(false);
			delete this.widgets[i];
		} // end for .. in
		
		//this.inherited(arguments);
	} // end of method destroy
	,
	'moveAttributes' : function (positionOffset /* a negative offset means to move the attribute up*/) {
		
		// get a list of all selected views
		var selected_UUIDs = this.widgets.attrList.attr('value');
		
		if (!selected_UUIDs.length) return;
	
		dojo.forEach(selected_UUIDs, function(UUID, nr) {		
			// get the corresponding item
			this.attrStore.fetchItemByIdentity({
				'identity' 	: UUID,
				'scope'		: this,
				'onItem' 	: function (item) {
					// modify the attribute's position
					var p=positionOffset+this.attrStore.getValue(item, 'positionOfAttribute');
					this.attrStore.setValue(item, 'positionOfAttribute', p);
				} // end of function onItem
			});
		},this); // end for each UUID
		
		// iterate over all attributes and reset their positions to a multiple of 10
		this.renumberAttrPositions();
		
		// rebuild the view list
		this.outputAttributeList(selected_UUIDs);
			
	} // end of method moveAttributes
	,
	'buildNewAttrMenu' : function () {
		// this method builds the menu for new attributes
		// parameter 'type' (either 'OT' or 'RT') is needed to identifiy the allowed attribute
		// kinds.
		if (this.widgets.attrListNewAttrDropDown.popup.hasChildren()) this.widgets.attrListNewAttrDropDown.popup.destroyDescendants(false);

		// create new list of attribute kinds
		
		dojo.xhrGet({
			'url'		: '?'
			,
			'content'	: {
				'v'		: 'JSON_General',
				'task'	: 'get_attributeKinds',
				'type'	: this.OT_type
			}
			,
			'error'		: 	application.AJAX_errorMessage, // function
			'handleAs'	: 'json',
			'scope'		: this,
			'load'		: function(r,a){ /* onSuccess */
				
				/*a.args.scope.attrStore = new dojo.data.ItemFileWriteStore({
						'data'			: r, 
						'clearOnClose' 	: true,
						// 'hierarchical'	: true
					});
					*/
				for(var aKind in application.attributeKinds.attributeKindList) {
					var attributeKind = application.attributeKinds.attributeKindList[aKind];
					if (r[aKind]) {
						attributeKind.name = r[aKind];
						var menuItem = new dijit.MenuItem({
										'label'			: attributeKind.name,
										'dialogWidget'  : a.args.scope,
										'aKind'			: aKind,
										'onClick' 		: function(e) {
											this.dialogWidget.addNewAttribute(this.aKind),
											dojo.stopEvent(e);
										} // end of method onClick
							});
						a.args.scope.widgets.attrListNewAttrDropDown.popup.addChild(menuItem);
					} else {
						console.warn("Sorry, the attribute kind \""+aKind+"\" is not specified in the backend!");
					} // end if attribute kind exists in backend
				} // end for each new item	
				
			}, // end of onSuccess method
			//preventCache:true,
			//failOk	: true,
			'sync'		: true,
			'timeout'	: 	application.configuration.global.AJAX_default_timeout
		});
		
	} // end of method buildTypeMenu	
	,
	'addNewAttribute' : function (attrKind) {
			
		// create a "UUID"
		var A_UUID='a_'+Math.uuid();
	
		// build unique name
		var kind							= application.attributeKinds.attributeKindList[attrKind],
			attrName 						= this.buildUniqueNameForAttribute(kind.name, A_UUID);
		
		// get the last position of the currently marked attributes or use otherwise the default attribute position
		this.renumberAttrPositions();
		var attrPos							= kind.positionOfAttribute;
		var UUIDofLastSelectedAttr			= this.widgets.attrList.get('value').pop();
		if(UUIDofLastSelectedAttr) attrPos	= this.getAttrPos(UUIDofLastSelectedAttr)+5;

		
		// build the object for the new item
		var newItem = dojo.mixin({
				'UUID': 				A_UUID,
				'displayedUUID':		'---',
				'ORT_UUID': 			this.OT_UUID,
				'A_UUID':				A_UUID,
				'A_origin_UUID':		'',
				'ORT_kind':				'O',
				'name': 				attrName,
				'description': 			kind.defaultDescription,
				'readModeHint'			: '',
				'editModeHint'			: '',
				'displayInFullWidth': 	false,
				'positionOfAttribute': 	attrPos,
				'kind': 				kind.kind,
				'readOnly': 			false,
				'mustBeSet': 			false,
				'mustBeUnique': 		false,
				'changedAt': 			'',
				'changedByP_UUID': 		null,
				'editStatus': 			'inserted',
				'action': 				'create',
			}, kind.defaultConfiguration);
	
		// we will display a new attribute, so we have to delete all existing selections
		this.unselectItemsOnAttrList(); // This leaves the attribute editor untouched!

		// create the new attribute in this.attrStore
		var item = this.attrStore.newItem(newItem);		
		
		// reorder all views
		this.renumberAttrPositions();
		
		// display the new item
		this.outputAttributeList([A_UUID]);
		
	} // end of method addNewView
	,
	'getAttrPos' : function (UUID) {
		var p;
		this.attrStore.fetch({
			'query'		: {'UUID'	: UUID},
			'scope'		: this,
			'onItem'	: function (item,request) {
				p	= this.attrStore.getValue(item,'positionOfAttribute');
			} // end onItem
		}); // end fetch
		return p;
	} // end of method getAttrPos
	,
	'renumberAttrPositions' : function () {
	
		var reorderingCounter	=0;
	
		this.attrStore.fetch({
			'query'		: {'UUID'	: '*'},
			'scope'		: this,
			'onItem'	: function (item,request) {
				var pos = (	/*	(this.attrStore.getValue(item,'editStatus')!='deleted')
							?	*/++reorderingCounter * 10
							/*:	reorderingCounter * 10*/);
				this.attrStore.setValue(item, 'positionOfAttribute', pos);
				if (this.attrStore.getValue(item, 'editStatus') != 'inserted'){
					this.attrStore.setValue(item, 'action', 'change');
				} // end if attribute is new
			} // end onItem
			,
			sort :  [{attribute: "positionOfAttribute" /*, descending: true*/}, { attribute: "name"/*, descending: true*/}]
		}); // end fetch	
	} // end of method renumberAttrPositions
	,
	'buildUniqueNameForAttribute' : function( nameOfAttr, currentUUID ){
	
		var templateName = nameOfAttr,
			connectChar = ' ',
			suffix = 0;
		
		// validate new name within the store
		this.attrStore.fetch({
			'scope'		: this,
			'onComplete': function(items, request) {
				dojo.forEach( items, function(item, index, array){
					if (		( this.attrStore.getValue(item, "UUID") != currentUUID ) 
							&& 	( templateName == this.attrStore.getValue(item,"name") )
						)	suffix++;
				}, this); // end dojo.forEach
			} // end onComplete
		}); // end fetch
		
		if (suffix) templateName = nameOfAttr+connectChar+suffix;
		return templateName;

	} // end of method buildUniqueNameForAttribute
	,
	'unselectItemsOnAttrList' : function () {
		dojo.forEach(this.widgets.attrList.containerNode.options, function(node){
			if ((node.nodeName=='OPTION') && (dojo.attr(node, 'selected'))) {dojo.attr(node, 'selected', false);}
		}); // end forEach node
	} // end of method unselectItemsOnAttrList
	,
	'duplicateAttrs' : function () {
	
		// get a list of all selected views
		var selected_UUIDs = this.widgets.attrList.attr('value'),
		// the UUIDs of the new attributes go here
			new_UUIDs = [];
		
		if (!selected_UUIDs.length) return;
	
		// we will display a new attribute, so we have to delete all existing selections
		this.unselectItemsOnAttrList();
		
		// let's renumber all attribute positions
		this.renumberAttrPositions();
		
		// duplicate all selected attributes
		dojo.forEach(selected_UUIDs, function(UUID) {
			this.attrStore.fetchItemByIdentity({
				'identity'	: UUID,
				'scope'		: this,
				'onItem'	: function (item) {
					
					var kindInfo = application.attributeKinds.attributeKindList[
									this.attrStore.getValue(item,'kind')
								];
					
					// build a unique name for the duplicate
					var attrName 	= this.buildUniqueAttrName(
											/*'(D) '+*/''+this.attrStore.getValue(item, 'name')+'', 
											''
										),
						pos			= this.attrStore.getValue(item, 'positionOfAttribute')+5;
						
					// create a new item, copy all values from the current one and adapt it, as necessary
					var newItem = dojo.mixin({}, item, {
							'UUID'					:  Math.uuid(),
							'editStatus'			: 'inserted',
							'isInherited'			: false,
							'inheritanceChain'		: [],
							'viewDefinedAt'			: '',
							'descriptionOfParentView':'',
							'action'				: 'create',
							'displayedUUID'			: '---',
							'A_UUID'				: '',	
							'A_origin_UUID'			: '',	
							'name'					: attrName,
							'positionOfAttribute'	: pos,
							'changedAt'				: '',
							'changedByP_UUID'		: null,
						});
					
					// remove store information from the object
					delete newItem._0;
					delete newItem._S;
					delete newItem._RI;
					
					// create new item
					this.attrStore.newItem(newItem);		
					
					new_UUIDs.push(newItem.UUID);
					
				} // end of function onItem
			}); // end fetch
		},this); // end for each UUID

		// renumber the attribute list ...
		this.renumberAttrPositions();
		
		// ... and output it
		this.outputAttributeList(new_UUIDs);

	} // end of method duplicateAttrs
	,
	'buildUniqueAttrName': function( nameOfAttr, currentUUID ){
	
		var cleanedName 	= nameOfAttr.replace( /\s\d{1,}$/, '' ),
			templateName	= cleanedName,
			connectChar 	= ' ',
			suffix 			= 0;
		
		// validate new name within the store
		this.attrStore.fetch({
			'scope'		: this,
			'onItem': function(item) {
					if ( 		( this.attrStore.getValue(item, "UUID") != currentUUID )
							&& 	( templateName == this.attrStore.getValue(item,"name") )
						) {
						suffix++;
						templateName = cleanedName+connectChar+suffix;
					} // end if
			} // end onComplete
		});
		
		return templateName;

	} // end of method buildUniqueAttrName
	,
	'undoChanges' : function() {
		
		/*the following code reverts the changes of the selected Items*/
		
		// get a list of all selected attributes
		var selected_UUIDs = this.widgets.attrList.attr('value');
		
		if (!selected_UUIDs.length) return;
	
		for(var identity in this.attrStore._pending._modifiedItems){
			if ( dojo.indexOf(selected_UUIDs, identity) >= 0 ) {
				// find the original item and the modified item that replaced it
				var copyOfItemState = this.attrStore._pending._modifiedItems[identity];
				var modifiedItem = null;
				if(this.attrStore._itemsByIdentity){
					modifiedItem = this.attrStore._itemsByIdentity[identity];
				}else{
					modifiedItem = this.attrStore._arrayOfAllItems[identity];
				} // end if
		
				// Restore the original item into a full-fledged item again, we want to try to
				// keep the same object instance as if we don't it, causes bugs like #9022.
				copyOfItemState[this.attrStore._storeRefPropName] = this.attrStore;
				for(var key in modifiedItem){ delete modifiedItem[key]; }
				
				dojo.mixin(modifiedItem, copyOfItemState);
				
				delete this.attrStore._pending._modifiedItems[identity];
				
			} //end if selected item
		} // end for .. in
		
		// rebuild the view list
		this.outputAttributeList(selected_UUIDs);
		
		/*
		//
		//THIS IS PART OF MODSIMTEX
		//
		// CBR
		application.admin.manageAttributes.CBRattr = new Array();
		//END MODSIMTEX
		//
		*/
		
	} // end of method undoChanges
	,
	'undoDelete' : function () {
	
		var parsedUUIDs=[];
		
		// get the corresponding item
		this.attrStore.fetchItemByIdentity({
			'identity'	: this.currentUUID,
			'scope'		: this,
			'onItem'	: function (item) {

				this.attrStore.setValue(item, 'action', 		'change');
				this.attrStore.setValue(item, 'editStatus', 	'changed');
				
				parsedUUIDs.push(this.attrStore.getValue(item, 	'UUID'));
				
			} // end of function onItem
		}); // end get the item
		
		// rebuild the view list
		this.outputAttributeList(parsedUUIDs);
		
	} // end of method addNewView
	,
	'deleteAttrs' : function () {
		// get a list of all selected views
		var selected_UUIDs = this.widgets.attrList.attr('value');
		
		if (!selected_UUIDs.length) return;
	
		var deleted_UUIDs=[];
		
		dojo.forEach(selected_UUIDs, function(UUID) {		
			this.attrStore.fetchItemByIdentity({
				'identity'	: UUID,
				'scope'		: this,
				'onItem'	: function (item) {
					// is the the view inherited?
					var inherited = this.attrStore.getValue(item, 'isInherited');
									/*(		(this.attrStore.getValue(item, 'editStatus')!='inserted') 
										&& 	(this.attrStore.getValue(item, 'VT_origin_UUID')!='')
									);*/
					if (inherited) {
						// do nothing
						deleted_UUIDs.push(UUID);
					} 
					// is the item a newly created one?
					else if(this.attrStore.getValue(item, 'editStatus')=='inserted') {
						// the view was just created --> delete it from the store
						this.attrStore.deleteItem(item);
					} else {
						// the item was already saved --> mark the item as deleted
						this.attrStore.setValue(item, 'editStatus', 'deleted');
						this.attrStore.setValue(item, 'action', 	'delete');
						deleted_UUIDs.push(UUID);
					} // end if 
				} // end of function onItem
			});
		},this); // end for each UUID

		// renumber the attribute list ...
		//this.renumberAttrPositions();
		
		// rebuild the view list
		this.outputAttributeList(deleted_UUIDs);

	} // end method deleteView
	,	
	'showEditHints' : function (hintType){
		if ( hintType && this.editHintList[hintType] ) {
			// refresh only, if there is something new to show
			var newHref = "?v="+this.editHintList[hintType];
			if (newHref!=this.lastEditHint) {
				// change only, if necessary
				this.widgets.attrEditorHintPane.attr('href',newHref);
				this.lastEditHint=newHref;
			}
		} else {
			this.widgets.attrEditorHintPane.destroyDescendants(false);
			this.widgets.attrEditorHintPane.attr('content','');
			this.lastEditHint='';
		} // end if hintType selected 

	} // end of method showEditHints
	,
	
	// ############################# Tag-related methods
	'buildTagList' : function () {
	
		// iterate over this.tagsWithAttributes and 
		for (var T_UUID in this.tagsWithAttributes) {
			var T_name = this.tagsWithAttributes[T_UUID].name,
				newTag_option = {
					'value'		: T_UUID,
					'innerHTML'	: T_name,
					'class'		: 'h4',
					// 'selected'	: true,
				};
		dojo.create('OPTION', newTag_option, this.widgets.tagListMultiSelect.containerNode);
		
		} // end for .. in 
	
	} // end of method buildTagList
	,
	'tagListMultiSelect_onChange' : function (selectedTags) {
	
		var selectedTagUUID = ((selectedTags.length)?selectedTags[0]:'');
		
		// clear up all input fields and lists ...
		delete this.currentTag_UUID;
		this.widgets.selectedTagTextBox.attr('value', '');
		if (this.widgets.tagAttrList) {
			this.widgets.tagAttrList.destroy();
			delete this.widgets.tagAttrList;
			if(this.tagAttrList_onChange) dojo.disconnect(this.tagAttrList_onChange);
		} // end if 
	
		// nothing selected -> finish
		if (!selectedTagUUID.length) {
			this.widgets.selectedTagTextBox.attr( 'disabled', 	true);
			this.widgets.selectedTagTextBox.attr( 'value', 		'');
			dojo.style( this.deleteSelectedTagNode, 'display', 'none' );
			return;
		} // end if nothing selected

		
		var selectedTag = this.tagsWithAttributes[selectedTagUUID];
		console.log('tagListMultiSelect_onChange', selectedTag);
	
		// store the current tag UUID
		this.currentTag_UUID = selectedTagUUID;
		
		// put the current tag name in the tag name widget
		this.widgets.selectedTagTextBox.attr('disabled', false);
		dojo.style( this.deleteSelectedTagNode, 'display', 'block' );
		this.widgets.selectedTagTextBox.attr('value', selectedTag.name);
		
		// assign the attributes
		this.availableAttributes = {};
		this.selectedAttributes = []
		
		this.attrStore.fetch({
			'scope' : this,
			'onItem' : function (item) {
				
				var A_UUID	= this.attrStore.getValue(item, 'A_UUID'),
					name	= this.attrStore.getValue(item, 'name');
				
				this.availableAttributes[A_UUID] = name;
				if (A_UUID in selectedTag.A_UUIDs) this.selectedAttributes.push(A_UUID);
				
			} // end of method onItem
		});
	
		this.widgets.tagAttrList = new common.widgets.sortableCheckList({
			'itemList'			: this.availableAttributes,
			'checkedItems'		: this.selectedAttributes,
			'checkedItemsLabel'	: '<h4>' + T('manageAttributes.js/SelAttr_LBL','Selected attributes') + '</h4>',
			'uncheckedItemsLabel': '<h4>' + T('manageAttributes.js/AvailAttr_LBL','Available attributes') + '</h4>',
			'style'				: 'min-width:20em;	',
		}).placeAt(this.tags_attrListNode);
		this.tagAttrList_onChange = dojo.connect(this.widgets.tagAttrList, 'onChange', this, 'changedTaggedAttributes');
		this.widgets.tagAttrList.startup();
		
	} // end of method tagListMultiSelect_onChange
	,
	'createNewTag'	: function (e) {
	
		dojo.stopEvent(e);
	
		// do nothing if there is no valid tag name, yet
		if (!this.widgets.createNewTagTextBox.isValid()) return;
	
		var newTagName	= this.widgets.createNewTagTextBox.attr('value'),
			newTagUUID	= Math.uuid(),
			newTagObj	= {
					'name'			: newTagName,
					'A_UUIDs'		: {},
					// 'isInherited'	: false,
				'editStatus': 'inserted', // || 'changed' || 'deleted'
				},
			newTag_option	= {
				'value'		: newTagUUID,
				'innerHTML'	: newTagName,
				'selected'	: true,
				'class'		: 'h4',
				};
		
		// stop if the new tag name is already existing
		var tagNameAlreadyExists = false;
		for (var T_UUID in this.tagsWithAttributes) {
			if (this.tagsWithAttributes[T_UUID].name == newTagName) tagNameAlreadyExists=true;
		} // end for .. in
		if (tagNameAlreadyExists) return;
		
		// add the new tag
		this.tagsWithAttributes[newTagUUID] = newTagObj;
		this.unselectTags();
		dojo.create('OPTION', newTag_option, this.widgets.tagListMultiSelect.containerNode);
	
		// ... and select it
		this.tagListMultiSelect_onChange([newTagUUID]);
	
		this.widgets.createNewTagTextBox.attr('value', '')
		
	} // end of method createNewTag
	,
	'unselectTags'	: function () {	
		dojo.forEach(this.widgets.tagListMultiSelect.containerNode.options, function(node){
			if ((node.nodeName=='OPTION') && (dojo.attr(node, 'selected'))) {dojo.attr(node, 'selected', false);}
		}); // end forEach node
	} // end of method unselectTags
	,
	'changedTaggedAttributes' : function(taggedAttrUUIDs) {
	
		// iterate over all attributes and set the editStatus, accordingly
		for (var A_UUID in this.availableAttributes) {
			switch (true) {
			
				// inserted
				case (		(dojo.indexOf(taggedAttrUUIDs, A_UUID)>=0) // the current A_UUID appears in the list of selected attributes
						&& 	(!this.tagsWithAttributes[this.currentTag_UUID].A_UUIDs[A_UUID]) // and does not form part of the list of tagged attributes, yet
					): { 
						// insert the attribute into the tag configuration
						this.tagsWithAttributes[this.currentTag_UUID].A_UUIDs[A_UUID] = {
							'editStatus'	: 'inserted',
						};
						
						// mark the tag as changed
						// if (this.tagsWithAttributes[this.currentTag_UUID].editStatus!='deleted') 
							// this.tagsWithAttributes[this.currentTag_UUID].editStatus = 'changed';
							
					} break;
				
				// deleted
				case (		(dojo.indexOf(taggedAttrUUIDs, A_UUID)<0) // the current A_UUID does not appear in the list of selected attributes
						&& 	(A_UUID in this.tagsWithAttributes[this.currentTag_UUID].A_UUIDs) // but forms part of of the list of tagged attributes
					): { 
						// delete the attribute from the tag configuration
						delete this.tagsWithAttributes[this.currentTag_UUID].A_UUIDs[A_UUID];
						
						// mark the tag as changed
						if (this.tagsWithAttributes[this.currentTag_UUID].editStatus!='inserted' || this.tagsWithAttributes[this.currentTag_UUID].editStatus!='deleted') 
							this.tagsWithAttributes[this.currentTag_UUID].editStatus = 'changed';
							
					} break;
				default:
			} // end switch
		
		} // end of for ... in 
			
	} // end of method changedTaggedAttributes
	,
	/*'addAttributesToTag' : function (e) {
		dojo.stopEvent(e);
		
		var selected_A_UUIDs = this.widgets.availableAttributesMultiSelect.attr('value');
		if(!selected_A_UUIDs.length) return;
		
		this.widgets.taggedAttributesMultiSelect.addSelected(
				this.widgets.availableAttributesMultiSelect
			);

		dojo.forEach(selected_A_UUIDs, function(A_UUID){
			this.tagsWithAttributes[this.currentTag_UUID].A_UUIDs[A_UUID] = {
				'editStatus'	: 'inserted',
			};
		},this);
		
		if(this.tagsWithAttributes[this.currentTag_UUID].editStatus!='deleted') 
			this.tagsWithAttributes[this.currentTag_UUID].editStatus = 'changed';
			
	} // end of method addAttributesToTag
	,
	'removeAttributesFromTag' : function (e) {
		dojo.stopEvent(e);
	
		var selected_A_UUIDs = this.widgets.taggedAttributesMultiSelect.attr('value');
		if(!selected_A_UUIDs.length) return;
		
		this.widgets.availableAttributesMultiSelect.addSelected(
				this.widgets.taggedAttributesMultiSelect
			);

		dojo.forEach(selected_A_UUIDs, function(A_UUID) {
			delete this.tagsWithAttributes[this.currentTag_UUID].A_UUIDs[A_UUID];
		},this);
			
		if(this.tagsWithAttributes[this.currentTag_UUID].editStatus!='deleted') 
			this.tagsWithAttributes[this.currentTag_UUID].editStatus = 'changed';
	
	} // end of method removeAttributesFromTag
	,*/
	'deleteTag'	: function (e) {
		dojo.stopEvent(e);

		if (!this.currentTag_UUID) return;
		
		// remove the OPTION from the tag list
		dojo.forEach(this.widgets.tagListMultiSelect.containerNode.options, function(node){
			if ((node.value==this.currentTag_UUID)) {node.parentNode.removeChild(node);}
		},this); // end forEach node
		
		// delete the current tag
		//delete this.tagsWithAttributes[this.currentTag_UUID];
		this.tagsWithAttributes[this.currentTag_UUID].editStatus = 'deleted';
		delete this.currentTag_UUID;
			
		// deselect everything
		this.tagListMultiSelect_onChange([]);
		
	} // end of method deleteTag
	,
	'renameTag' : function (v) {
	
		if(!this.widgets.selectedTagTextBox.isValid()) return;
		
		// store the new tag name
		this.tagsWithAttributes[this.currentTag_UUID].name = v;
		
		// rename the DOM noew in the list of available tags
		dojo.forEach(this.widgets.tagListMultiSelect.containerNode.options, function(node){
			if ((node.value==this.currentTag_UUID)) {dojo.attr(node, 'innerHTML', v);}
		},this); // end forEach node
		
		if(this.tagsWithAttributes[this.currentTag_UUID].editStatus!='deleted') 
			this.tagsWithAttributes[this.currentTag_UUID].editStatus = 'changed';
		
	} // end of method renameTag
});

// extend the admin functionality with attribute management
application.admin.manageAttributes = {
	'dialogWidget' 	: null
	,
	'OT_UUID'		: null
	,
	'OT_name'		: null
	,
	'showDialog' : function () {
	
		if (this.dialogWidget) this.closeDialog(); // destroy a potentially existing dialog widget
	
		// get the necessary information
		this.OT_name = application.admin.navigationStore.getValue(application.admin.currentNavigationItem,'name');
		this.OT_UUID = application.admin.navigationStore.getValue(application.admin.currentNavigationItem,'UUID');
		
		var type = application.admin.navigationStore.getValue(application.admin.currentNavigationItem,'type');
		
		this.dialogWidget = new application.widgets.manageAttributesDialog({
			'OT_UUID'	: this.OT_UUID,
			'OT_name'	: this.OT_name,
			'OT_type'	: type
		});
		
		this.dialogWidget.startup();
		this.dialogWidget.show();
	} // end of method show
	,
	'closeDialog' : function() {
		this.dialogWidget.hide();
		this.dialogWidget.destroyRecursive(false);
		this.dialogWidget.destroy();
		this.dialogWidget=null;
		this.OT_UUID = null;
		this.OT_name = null;
		
	} // end of method closeDialog
	,
}; // end extension of the admin functionality

// register the option for the right click menu
application.admin.adminPane_rightClickMenu.addOption(
        T('manageAttributes.js/ManageAttr_MNU','Manage <strong>attributes</strong>'),
	
	function (e){
		application.admin.manageAttributes.showDialog();
		dojo.stopEvent(e);
	}, 
	'rsIcon_manageAttributes', 
	function(item_type) {return !((item_type=='OT')||(item_type=='RT'));}
);