/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

application.admin.moveOT = {
	navigationStore : null,
	navigationModel : null,
	navigationTree : null,
	currentNavigationItem : null,
	move_OT_UUID : null,
	new_parent_OT_UUID : null,
	
	initialise_tree : function () {
		with (application.admin.moveOT) {
			try {
				navigationStore = new dojo.data.ItemFileWriteStore({
						url: '?v=JSON_General&task=get_NavigationTree4Admin&onlyOT=1&excludeSubTypesOf_OT_UUID='+move_OT_UUID,
						urlPreventCache : true,
						clearOnClose : true,
						failOk : true
					});
					
			} catch(e) {
				application.showErrorMessage(dojo.fromJson (e));
			} // end-of try ... catch

			navigationModel = new dijit.tree.ForestStoreModel({
					store: navigationStore,
					query: {'type': 'navigation_node'},
					childrenAttrs : ['children']
				});
			
			if (navigationTree) navigationTree.destroyRecursive();
			
			dijit.byId('application.admin.Dialogues.moveOT.treeRegion').attr('content', 
				'<div id="application.admin.Dialogues.moveOT.treeDiv"></div>');
			
			try {
				var navigationTree = new dijit.Tree ({
						model: navigationModel,
						openOnClick: false,
						showRoot: false,
						persist: true,
						getIconClass : function(item, isOpened) {return ((isOpened)?'dijitFolderOpened':'dijitFolderClosed');},
						getLabel : function(item) {
							if(!application.admin.moveOT.navigationStore._arrayOfAllItems.length) return '?';
							if(!application.admin.moveOT.navigationStore.hasAttribute(item,'UUID')) return T('moveOT.js/OT_TXT','Object Types');
							var current_UUID = application.admin.moveOT.navigationStore.getValue(item,'UUID');
							var name = application.admin.moveOT.navigationStore.getValue(item,'name');
							var excludedSubTypes = application.admin.moveOT.navigationStore.getValue(item,'excludedSubTypes');
							var isSelected = (current_UUID==application.admin.moveOT.move_OT_UUID);
							return name
								+(isSelected?(
										'(' + T('moveOT.js/IsSelected_P1_TXT', 'selected')
											+( (excludedSubTypes==1) ?', ' + T('moveOT.js/IsSelected_P2_TXT','sub types are hidden') : '')
										+')'
									):'')
								;
						} // end of method getLabel
						,
						onClick : function(item,node,e){
							if(application.admin.moveOT.navigationStore.getValue(item,'type')!='OT') return;
							application.admin.moveOT.new_parent_OT_UUID=application.admin.moveOT.navigationStore.getValue(item,'UUID');
							if(application.admin.moveOT.move_OT_UUID==application.admin.moveOT.new_parent_OT_UUID) {
								dojo.byId('application.admin.Dialogues.moveOT.message').innerHTML=
									'<p>' + T('moveOT.js/CannotSelCurrOTAsParent_TXT','You cannot select the current object type as its own parent.') + '</p>';
								application.admin.moveOT.new_parent_OT_UUID='';	
								dijit.byId('application.admin.Dialogues.moveOT.okButton').attr('disabled',true);
								return;
							} // end if
							application.admin.moveOT.currentNavigationItem=item;
							var name = application.admin.moveOT.navigationStore.getValue(item,'name');
							dojo.byId('application.admin.Dialogues.moveOT.message').innerHTML= ''
								'<p>'
									+T( 'moveOT.js/CannotSelParentOT_HTM',
										'You have selected the <i>parent</i> object type «<span class="code">$[0]</span>».',
										[name])
								+'</p>';
							dijit.byId('application.admin.Dialogues.moveOT.okButton').attr('disabled',false);
							
						} // end of function onClick
					}, 
					'application.admin.Dialogues.moveOT.treeDiv'
				);
								
			} catch(e) {
				console.log('tree initialisation error', e);
			} // end-of try...catch
		} // end with
	} // end of method initialise_tree
	,
	showDialog : function () {
		// get the necessary information
		var name = application.admin.navigationStore.getValue(application.admin.currentNavigationItem,'name');
		application.admin.moveOT.move_OT_UUID = application.admin.navigationStore.getValue(application.admin.currentNavigationItem,'UUID');
		
		// set some fields in the dialogue as necessary
		dijit.byId('application.admin.Dialogues.moveOT').attr('title', T('moveOT.js/MoveOT_TIT','Move the object type «[0]» ',[name]) );
		dojo.byId('application.admin.Dialogues.moveOT.OT_name').innerHTML=name;
		dijit.byId('application.admin.Dialogues.moveOT.okButton').attr('disabled',true);
		
		// initialise the tree
		application.admin.moveOT.initialise_tree();
		
		// show the dialogue
		dijit.byId('application.admin.Dialogues.moveOT').show();	
	} // end of method showDialog
	,
	execute : function () {
		if(!application.admin.moveOT.end_OT_UUID) return;
		dijit.byId('application.admin.Dialogues.moveOT').hide();
				
		// send "move object type" message to the server
		application.OT_AJAX_query(
			{
				"task"				: "move_OT",
				"move_OT_UUID"		: application.admin.moveOT.move_OT_UUID,
				"new_parent_OT_UUID": application.admin.moveOT.end_OT_UUID
			}, 
			function(response,details){ // onSuccess
				// close the navigationStore
				// application.admin.navigationStore.close(); // this forces the store to be cleared - the contents will be reloaded later on
				
				// hide the dialogue and refresh the admin pane
				application.admin.initialise_adminPane();
				
			} // end of onSuccess function
			,
			true /* means: synchronously */
		); // end of application.RT_AJAX_query
		
	} // end of method execute
} // end of moveOT

application.admin.adminPane_rightClickMenu.addOption('<span class="deleted">' + T('moveOT.js/MoveOT_MNU','<strong>Move</strong> object type</span> (does not work, yet) '), application.admin.moveOT.showDialog, 'rsIcon_moveObjectType', function(item_type){return(item_type!='OT'?true:false);});
