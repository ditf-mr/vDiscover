<?php if (!defined('APPLICATION_started')) {header('Location: .');exit;}
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/
?>
 
<div dojoType="dijit.Dialog" id="application.admin.Dialogues.moveOT" 
	title="Move an object type to another position in the object type tree" execute="application.admin.moveOT.execute();return false;"
	style="">
	
	<div dojoType="dijit.layout.BorderContainer" gutters="false" liveSplitters="true" style="width:600px;height:600px;">	
		<div dojoType="dijit.layout.ContentPane" region="top">
				<h3><?php echo T('moveOT.php/MoveOT_TIT', 'Move an object type to another position in the object type tree'); ?></h3>
				<p><?php echo T('moveOT.php/KeepInMind_P0_TXT', 'Keep in mind that moving an object type will:'); ?></p>
				<ul>
					<li><?php echo T('moveOT.php/KeepInMind_P1_TXT', 'relocate all its objects and subtypes.'); ?></li>
					<li><?php echo T('moveOT.php/KeepInMind_P2_TXT', 'remove all its currently inherited attributes, relation types, dependencies and views.'); ?></li>
					<li><?php echo T('moveOT.php/KeepInMind_P3_TXT', 'assign all newly inherited attributes, relation types, dependencies and views.'); ?></li>
				</ul>
				<p>
					<?php echo T('moveOT.php/YouHaveSel_TXT', 'You have selected the object type &laquo;$[0]&raquo;.', array('<span class="code" id="application.admin.Dialogues.moveOT.OT_name"></span>')); ?>
				</p>
				<p id="application.admin.Dialogues.moveOT.message"><?php echo T('moveOT.php/SelNewParentOT_TXT', 'Please select its new parent object type:'); ?></p>
		</div>
		<div dojoType="dijit.layout.ContentPane" region="center" id="application.admin.Dialogues.moveOT.treeRegion" 
			style="padding-top:1.25em;padding-bottom:1.25em;">
		</div>

		<div dojoType="dijit.layout.ContentPane" region="bottom" style="text-align:right;">
			<button dojoType="dijit.form.Button" type="submit" disabled="true" id="application.admin.Dialogues.moveOT.okButton">
				<?php echo T('moveOT.php/MoveSelOT_BTN', 'Move the selected object type to its new position'); ?>
			</button>
			<button dojoType="dijit.form.Button" type="button" onClick="dijit.byId('application.admin.Dialogues.moveOT').hide();">
				<?php echo T('BTN_Cancel', 'Cancel'); ?>
			</button>
		</div>
	</div>
</div>	
	
