/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// dojo.require("common.widgets.fixedSizeDialog");

dojo.declare('application.widgets.manageViewsDialog',[common.widgets.fixedSizeDialog],{
	'innerWidth'	: 2000
	,
	'innerHeight'	: 2000
	,
	'OT_UUID'			: null
	,
	'OT_name'			: null
	,
	'selectedViews'		: null
	,
	'viewStore'			: null
	,
	'parentNameTemplate' : null
	,
	'parentDescriptionTemplate' : null
	,
	
	// slots for internal use, only
	'_raw_attrStoreData'	: null,
	'_availableAttributeMap': null,
	
	
	// the char that shows that a view is inherited is a UTF8 DOWNWARDS ARROW WITH TIP RIGHTWARDS
	// because this arrow is similar to the corresponding UML 2.0 relation
	'inheritedChar'		: '&#x21FD;' // see http://www.utf8-chartable.de/unicode-utf8-table.pl?start=8592&number=1024&unicodeinhtml=hex
	,
	
	
	'constructor' : function() {
		// Your constructor method will be called before the parameters are mixed into the widget, and can be used to initialize arrays, etc.
		this.inherited(arguments);
		
		// initialisations
		this.widgets 				= {};
		this.selectedViews			= [];
		this._raw_attrStoreData 	= {};
		
	} // end of method constructor
	,
	'postMixInProperties' : function() {
		this.inherited(arguments);
		
		this.title = T('manageViews.js/ManageViewsOfOT_TIT','Manage the views of « $[0]» ',[this.OT_name]);
	} // end of method postMixInProperties
	,
	'postCreate' : function() {
		this.inherited(arguments);
			
			// build the main structure of the dialog
		this.widgets.borderContainer = new dijit.layout.BorderContainer({
			'style' 	: 'width:100%;height:100%;',
			'gutters'	: false
		});
		this.widgets.borderContainer.placeAt(this.containerNode);
		
		// create the action bar at the bottom of the dialog
		this.widgets.actionBar = new dijit.layout.ContentPane({
			'region'	: 'bottom',
			'class'		: 'dijitDialogPaneActionBar textRight',
			'style'		: 'padding-top:1em;'
		});
		this.widgets.borderContainer.addChild(this.widgets.actionBar);

		this.widgets.OkButton = new dijit.form.Button({
			'label' 	: '<img src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/dialog-ok-apply-4.png"/> '
				+T('BTN_OK','OK'),
			'type'		: 'button'
		}).placeAt(this.widgets.actionBar.containerNode);

		this.connect(this.widgets.OkButton,			'onClick', function(e){application.admin.manageViews.execute();});
		
		this.widgets.CancelButton = new dijit.form.Button({
			'label' 	: '<img width="12" src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/dialog-cancel-4.png"/> '
				+T('BTN_Cancel','Cancel'),
			'type'		: 'button',
			'style'		: 'margin-right:0;'
		}).placeAt(this.widgets.actionBar.containerNode);
		
		this.connect( this.widgets.CancelButton,	'onClick', function(e){
			application.admin.manageViews.closeDialog();
		});
		
		this.connect( this.closeButtonNode,			'onClick', function(e){
			application.admin.manageViews.closeDialog();
		});
		
		// create the main edit pane for the view configuration
		this.widgets.viewEditBorderContainer = new dijit.layout.BorderContainer({
			'region'	: 'center',
			'style'		: 'margin-left:.5ex;',
			'gutters'	: false
		});
		this.widgets.borderContainer.addChild(this.widgets.viewEditBorderContainer);

		this.widgets.viewNamePane = new dijit.layout.ContentPane({
			'region'	: 'top',
			// 'content'	: '<h2>Name of the selected view</h2>',
			'style'		: 'padding:1.25em;padding-left:1ex;'
		});
		
		this.widgets.viewNameEditor = new dijit.form.ValidationTextBox({
			'class' : 'h2 ',
			'value' : 'View Name',
			'region': 'top',
			'selectOnClick' : true,
			'style'	: 'padding-bottom:.25em;margin-bottom:1em;padding-left:.25ex;'
		});
		this.connect( this.widgets.viewNameEditor, 'onChange', 'name_changed');
		//this.widgets.viewEditBorderContainer.addChild(this.widgets.viewNameEditor);
				
		this.widgets.viewEditor = new dijit.layout.ContentPane({
			'region'	: 'center',
			// 'class'		: 'dijitMenuBar',
			'style'		: 'padding:.5ex;padding-top:1.25em;'
		});
		this.widgets.viewEditBorderContainer.addChild(this.widgets.viewEditor);
		
		// create the container for the view list
		this.widgets.viewListBorderContainer = new dijit.layout.BorderContainer({
			'style' 	: 'width:30ex;margin-right:.5ex;',
			// 'class'		: 'dijitMenuBar',
			'gutters'	: false,
			'region' 	: 'left',
			'splitter' 	: true,
			'minSize' 	: 100
		});
		this.widgets.borderContainer.addChild(this.widgets.viewListBorderContainer);
		
		// create the menu bar for the view list
		this.widgets.viewListMenuBar = new dijit.MenuBar({
			'class' 	: 'small',
			'region' 	: 'top',
			'style'		: 'border:0'
		});
		this.widgets.viewListBorderContainer.addChild(this.widgets.viewListMenuBar);
		
		this.widgets.viewListNewViewDropDown = new dijit.PopupMenuBarItem ({
			'label' 	: T('FUT_NewFromMenu','New …'),
			'popup' 	: new dijit.Menu({})
		});
		this.widgets.viewListMenuBar.addChild(this.widgets.viewListNewViewDropDown);
		
		this.buildNewViewMenuContents();
		
		this.widgets.viewListDuplicateMenuItem = new dijit.MenuBarItem ({
			'label' 	: T('FUT_Duplicate','Duplicate'),
		});
		this.widgets.viewListMenuBar.addChild(this.widgets.viewListDuplicateMenuItem);
		this.connect(this.widgets.viewListDuplicateMenuItem, 'onClick', 'duplicateViews')

			
		this.widgets.viewListUndoMenuItem = new dijit.MenuBarItem ({
			'label' 	: T('FUT_Undo','Undo'),
		});
		this.widgets.viewListMenuBar.addChild(this.widgets.viewListUndoMenuItem);
		this.connect(this.widgets.viewListUndoMenuItem, 'onClick', 'undoChanges');
		
		this.widgets.viewListDeleteMenuItem = new dijit.MenuBarItem ({
			'label' 	: T('FUT_Delete','Delete'),
		});
		this.widgets.viewListMenuBar.addChild(this.widgets.viewListDeleteMenuItem);
		this.connect(this.widgets.viewListDeleteMenuItem,'onClick','deleteViews');
		
		// create the view list
		this.widgets.viewList = new dijit.form.MultiSelect({
			'region' 	: 'center',
			'class'		: 'dijitMenuBar',
			'style'		: 'width:100%;border-right:0;border-left:0;padding-left:.5ex;',
			//'scope'		: this
		});
		this.widgets.viewListBorderContainer.addChild(this.widgets.viewList);

		this.loadViewListFromServer();
		
		this.connect( this.widgets.viewList, 'onChange', function(c){
			this/*.scope*/.selectedViewsHaveChanged(c);
		});
		
		// create the buttons for moving the views up and down in the list
		this.widgets.viewPositionMenuBar = new dijit.layout.ContentPane({
			'region' 	: 'bottom',
			'class'		: 'small',
			'style'		: 'padding:.5ex;'
		});
		this.widgets.viewListBorderContainer.addChild(this.widgets.viewPositionMenuBar);
		
		this.widgets.moveViewUp = new dijit.form.ComboButton({
			'label' 	: '&uarr;',
			'dropDown' 	: new dijit.Menu({}),
			'style'		: 'margin-right:1ex;',
			'scope'		: this,
			'posOffset'	: -15
		}).placeAt(this.widgets.viewPositionMenuBar.containerNode);
		this.widgets.moveViewUp.connect(this.widgets.moveViewUp,'onClick',function(){
			this.scope.moveViews(this.posOffset);
		});
		
		this.widgets.moveViewTenUp = new dijit.MenuItem({
			'label' 	: '&uArr;',
			'scope'		: this,
			'posOffset'	: -65
		});
		this.widgets.moveViewUp.dropDown.addChild(this.widgets.moveViewTenUp);
		this.widgets.moveViewTenUp.connect(this.widgets.moveViewTenUp,'onClick',function(){
			this.scope.moveViews(this.posOffset);
		});
		
		this.widgets.moveViewTop = new dijit.MenuItem({
			'label' 	: T('FUT_top','top'),
			'scope'		: this,
			'posOffset'	: -500000
		});
		this.widgets.moveViewUp.dropDown.addChild(this.widgets.moveViewTop);
		this.widgets.moveViewTop.connect(this.widgets.moveViewTop,'onClick',function(){
			this.scope.moveViews(this.posOffset);
		});
		
		this.widgets.moveViewDown = new dijit.form.ComboButton({
			'label' 	: '&darr;',
			'dropDown' 	: new dijit.Menu({}),
			'scope'		: this,
			'posOffset'	: +15
		}).placeAt(this.widgets.viewPositionMenuBar.containerNode);
		this.widgets.moveViewDown.connect(this.widgets.moveViewDown,'onClick',function(){
			this.scope.moveViews(this.posOffset);
		});
		
		this.widgets.moveViewTenDown = new dijit.MenuItem({
			'label' 	: '&dArr;',
			'scope'		: this,
			'posOffset'	: +65
		});
		this.widgets.moveViewDown.dropDown.addChild(this.widgets.moveViewTenDown);
		this.widgets.moveViewTenDown.connect(this.widgets.moveViewTenDown,'onClick',function(){
			this.scope.moveViews(this.posOffset);
		});
		
		this.widgets.moveViewBottom = new dijit.MenuItem({
			'label' 	: T('FUT_bottom','bottom'),
			'scope'		: this,
			'posOffset'	: +500000
		});
		this.widgets.moveViewDown.dropDown.addChild(this.widgets.moveViewBottom);
		this.widgets.moveViewBottom.connect(this.widgets.moveViewBottom,'onClick',function(){
			this.scope.moveViews(this.posOffset);
		});
		
	} // end of method postCreate
	,
	'duplicateViews' : function () {
	
		// get a list of all selected views
		var selected_UUIDs = this.widgets.viewList.attr('value');
		
		if (!selected_UUIDs.length) return;
	
		// we will display a new attribute, so we have to delete all existing selections
		this.unselectItemsOnViewList();

		var new_UUIDs = new Array();
		
		dojo.forEach(selected_UUIDs, function(UUID) {
			this.viewStore.fetchItemByIdentity({
				'identity'	: UUID,
				'scope'		: this,
				'onItem'	: function (item) {
										
					// include the kind specific configuration
					var newItem = dojo.mixin({},item,{
							'editStatus'			: 'inserted',
							'isInherited'			: false,
							'inheritanceChain'		: [],
							'viewDefinedAt'			: '',
							'descriptionOfParentView': '',
							'action'				: 'create'
						});
					newItem.name = '(D) '+this.viewStore.getValue(item,'name');
					newItem.positionOfView = this.viewStore.getValue(item,'positionOfView') +5;
					new_UUIDs.push(newItem.UUID = Math.uuid());
					
					// remove store information from the object
					delete newItem._0;
					delete newItem._S;
					delete newItem._RI;
					
					// create new item
					this.viewStore.newItem(newItem);		
					
				} // end of function onItem
			});
		},this); // end for each UUID
		
		this.renumberViewPositions();
		
		// rebuild the view list
		this.outputViewList(new_UUIDs);

	} // end of method duplicateViews
	,
	'buildNewViewMenuContents' : function () {
		// this method builds the menu for new views
		var menu = this.widgets.viewListNewViewDropDown.popup;
		if (!menu.hasChildren()) for(var VT_UUID in application.viewKinds.viewKindList) {
			var viewType = application.viewKinds.viewKindList[VT_UUID];
			var menuItem = new dijit.MenuItem({
				'label'		: viewType.name, 
				'scope'		: this,
				'viewType'	: viewType
			});
			menu.addChild( menuItem	);
			menuItem.connect( menuItem, 'onClick', function(){
				this.scope.addNewView(this.viewType);
			});
		} // end if menu initialisation necessary and for each new item
	} // end of method buildNewViewMenuContents	
	,
	'addNewView' : function (viewType) {
			
		// we will display a new view, so we have to delete all existing selections
		this.unselectItemsOnViewList();

		// create a "UUID"
		var V_UUID='v_'+Math.uuid();
	
		// build the object for the new item
		var newItem = dojo.mixin({
				'UUID'					: V_UUID,
				'OT_UUID'				: this.OT_UUID,
				'name'					: viewType.name,
				'description'			: viewType.defaultDescription,
				'positionOfView'		: viewType.positionOfView,
				'kind'					: viewType.kind,
				'content'				: viewType.content,
				'mayBeUsedAsNameTemplate'		: viewType.mayBeUsedAsNameTemplate,
				'isTemplateName'				: viewType.isTemplateName,
				'templateNameInherited'			: viewType.templateNameInherited,
				'mayBeUsedAsDescriptionTemplate': viewType.mayBeUsedAsDescriptionTemplate,
				'isTemplateDescription'			: viewType.isTemplateDescription,
				'templateDescriptionInherited'	: viewType.templateDescriptionInherited,
				'editingLevel'			: 0,
				'searchPoints'			: viewType.searchPoints,
				'isInherited'			: false,
				'inheritanceChain'		: [],
				'viewDefinedAt'			: '',
				'descriptionOfParentView':'',
				'changedAt'				: '',
				'changedByP_UUID'		: null,
				'editStatus' 			: 'inserted',
				'create'				: 'create'			
			}, viewType.defaultConfiguration);
	
		// create the new view in the viewStore
		var item = this.viewStore.newItem(newItem);		
		
		// reorder all views
		this.renumberViewPositions();
		
		// display the new item
		this.outputViewList([V_UUID]);
		
	} // end of method addNewView
	,
	'deleteViews' : function () {
		// get a list of all selected views
		var selected_UUIDs = this.widgets.viewList.attr('value');
		
		if (!selected_UUIDs.length) return;
	
		var deleted_UUIDs=[];
		
		dojo.forEach(selected_UUIDs, function(UUID) {		
			this.viewStore.fetchItemByIdentity({
				'identity'	: UUID,
				'scope'		: this,
				'onItem'	: function (item) {
					// is the the view inherited?
					var inherited = (		(this.viewStore.getValue(item, 'editStatus')!='inserted') 
										&& 	(this.viewStore.getValue(item, 'VT_origin_UUID')!='')
									);
					if (inherited) {
						// do nothing
						deleted_UUIDs.push(UUID);
					} 
					// is the item a newly created one?
					else if(this.viewStore.getValue(item, 'editStatus')=='inserted') {
						// the view was just created --> delete it from the store
						this.viewStore.deleteItem(item);
					} else {
						// the item was already saved --> mark the item as deleted
						this.viewStore.setValue(item, 'editStatus', 'deleted');
						this.viewStore.setValue(item, 'action', 'delete');
						deleted_UUIDs.push(UUID);
					} // end if 
				} // end of function onItem
			});
		},this); // end for each UUID

		this.renumberViewPositions();
		
		// rebuild the view list
		this.outputViewList(deleted_UUIDs);

	} // end method deleteView
	,	
	'renumberViewPositions' : function () {
	
		var reorderingCounter=0;
	
		this.viewStore.fetch({
			'query'		: {'UUID'	: '*'},
			'scope'		: this,
			'onItem'	: function (item,request) {
				this.viewStore.setValue(item, 'positionOfView', ++reorderingCounter * 10);
				if (this.viewStore.getValue(item, 'editStatus') != 'inserted'){
					this.viewStore.setValue(item, 'action', 'change');
				} // end if attribute is new
			} // end onItem
			,
			sort :  [{attribute: "positionOfView" /*, descending: true*/}, { attribute: "name"/*, descending: true*/}]
		}); // end fetch	
	} // end of method renumberViewPositions
	,
	'unselectItemsOnViewList' : function () {
		dojo.forEach(this.widgets.viewList.containerNode.childNodes, function(node){
			if ((node.nodeName=='OPTION') && (dojo.attr(node, 'selected'))) {dojo.attr(node, 'selected', false);}
		}); // end forEach node
	} // end of method unselectItemsOnViewList
	,
	'undoDelete' : function (UUID) {
	
		var parsedUUIDs=[];
		
		// get the corresponding item
		this.viewStore.fetchItemByIdentity({
			'identity'	: UUID,
			'scope'		: this,
			'onItem'	: function (item) {

				this.viewStore.setValue(item, 'action', 		'change');
				this.viewStore.setValue(item, 'editStatus', 	'changed');
				
				parsedUUIDs.push(this.viewStore.getValue(item, 	'UUID'));
				
			} // end of function onItem
		}); // end get the item
		
		// rebuild the view list
		this.outputViewList(parsedUUIDs);
		
	} // end of method addNewView
	,
	'undoChanges' : function() {
		
		/*the following code reverts the changes of the selected Items*/
		
		// get a list of all selected views
		var selected_UUIDs = this.widgets.viewList.attr('value');
		
		if (!selected_UUIDs.length) return;
	
		for(var identity in this.viewStore._pending._modifiedItems){
			if ( dojo.indexOf(selected_UUIDs, identity) >= 0 ) {
				// find the original item and the modified item that replaced it
				var copyOfItemState = this.viewStore._pending._modifiedItems[identity];
				var modifiedItem = null;
				if(this.viewStore._itemsByIdentity){
					modifiedItem = this.viewStore._itemsByIdentity[identity];
				}else{
					modifiedItem = this.viewStore._arrayOfAllItems[identity];
				} // end if
		
				// Restore the original item into a full-fledged item again, we want to try to
				// keep the same object instance as if we don't it, causes bugs like #9022.
				copyOfItemState[this.viewStore._storeRefPropName] = this.viewStore;
				for(var key in modifiedItem){ delete modifiedItem[key]; }
				
				dojo.mixin(modifiedItem, copyOfItemState);
				
				delete this.viewStore._pending._modifiedItems[identity];
				
			} //end if selected item
		} // end for .. in
		
		// rebuild the view list
		this.outputViewList(selected_UUIDs);
		
	} // end of method undoChanges
	,
	'getViewConfigurationEditor_config' : function (V_UUID) {
		// this method returns an object that can be used for initialising view configuration editors
		var c = {
			'dialogWidget'	: this,
			'V_UUID'		: V_UUID
		};
		
		this.viewStore.fetchItemByIdentity({
			'identity' 	: V_UUID,
			'scope'		: this,
			'onItem' 	: function (item) {
				c['V_UUID'] 				= V_UUID;
				c['name']					= this.viewStore.getValue(item, 'name'					);
				c['kind']					= this.viewStore.getValue(item, 'kind'			);
				c['isInherited']			= this.viewStore.getValue(item, 'isInherited'			);
				c['inheritanceChain']		= dojo.fromJson(
												this.viewStore.getValue(item,
																			'inheritanceChain'		));
				c['viewDefinedAt']			= this.viewStore.getValue(item, 'viewDefinedAt'			);
				c['name']					= this.viewStore.getValue(item, 'name'					);
				c['descriptionOfParentView']= this.viewStore.getValue(item, 'descriptionOfParentView');
				c['description']			= this.viewStore.getValue(item, 'description'			);
				c['editingLevel']			= this.viewStore.getValue(item, 'editingLevel'			);
				c['searchPoints']			= this.viewStore.getValue(item, 'searchPoints'			);
			} // end of function onItem
		}); // end get the item with V_UUID
		
		return c;
	} // end of method getViewConfigurationEditor_config
	,
	'getPropertyValue' : function (V_UUID, slot) {
		if (typeof slot == 'undefined') return null;
		var v;
		this.viewStore.fetchItemByIdentity({
			'identity' 	: V_UUID,
			'scope'		: this,
			'onItem' 	: function (item) {
				if (typeof item == 'undefined') return; /* Internet Explorer bugfix */
				v=this.viewStore.getValue(item, slot);
			} // end of function onItem
		}); // end get the item with V_UUID
		return v;
	} // end of method getPropertyValue
	,
	'valueHasChanged' : function (V_UUID, slot, newValue) {
		var status = false;
		this.viewStore.fetchItemByIdentity({
			'identity' 	: V_UUID,
			'scope'		: this,
			'onItem' 	: function (item) {
			
				// nothing to do?
				var currentValue = this.viewStore.getValue(item, slot);
				if (currentValue==newValue) return;
			
				// store the changed slot value
				this.viewStore.setValue(item, slot, newValue);				
				// console.log('manageViews:valueHasChanged', slot, newValue);

				// change the edit status - if applicable
				if (this.viewStore.getValue(item, 'editStatus') != 'inserted'){
				
					this.viewStore.setValue(item, 'action', 	'change');
					this.viewStore.setValue(item, 'editStatus', 'changed');
				
					// toggle the class of the corresponding option in the select list
					var oNode = dojo.byId('application.admin.mV.v_'+V_UUID);
					dojo.attr(oNode, 'class', 'modified');			
					
				} // end if view is new
				
				status = true;
			} // end of function onItem
		}); // end get the item with V_UUID
		
		if(slot=='name') this.setViewName(V_UUID);
		
		return status;
	} // end of method valueHasChanged
	,
	'resetConfigurationValue'	: function (slotName, value) {
		// This method iterates over all views and resets slotName to value.
	
		this.viewStore.fetch({
			'scope'		: this,
			'onItem'	: function (item ) {
				this.viewStore.setValue(item, slotName, value);				
			} // end onItem
		}); // end fetch	

	} // end of method resetConfigurationValue	
	,
	'moveViews' : function (positionOffset /*a negative offset means to move the view up */) {

		// get a list of all selected views
		var selected_UUIDs = this.widgets.viewList.attr('value');
		
		if (!selected_UUIDs.length) return;
	
		dojo.forEach(selected_UUIDs, function(V_UUID, nr) {		
			// get the corresponding item
			this.viewStore.fetchItemByIdentity({
				'identity' 	: V_UUID,
				'scope'		: this,
				'onItem' 	: function (item) {
					// modify the view's position
					var p=positionOffset+this.viewStore.getValue(item, 'positionOfView');
					this.viewStore.setValue(item, 'positionOfView', p);
				} // end of function onItem
			});
		},this); // end for each UUID
		
		// iterate over all views and reset their positions to a multiple of 1
		this.renumberViewPositions();
		
		// rebuild the view list
		this.outputViewList(selected_UUIDs);
		
	}// end of method moveViewUp
	,	
	'loadViewListFromServer' : function () { // ############################
	
		// create the viewStore
		dojo.xhrPost({
			'url'		: '?'
			,
			'content'	: {
				'v'		: 'JSON_ObjectType',
				'task'	: 'get_OT_viewTypes', 
				'UUID'	: this.OT_UUID
			}
			,
			'error'		: application.AJAX_errorMessage,
			'handleAs'	: 'json',
			'scope'		: this,
			'load'		: function(response,request){ /* onSuccess */
				
				request.args.scope.viewStore = new dojo.data.ItemFileWriteStore({
						'data'			: response.viewTypes, 
						'clearOnClose' 	: true,
						'hierarchical'	: true
					});
				request.args.scope.parentNameTemplate 		= response.parentTemplateName;
				request.args.scope.parentDescriptionTemplate= response.parentTemplateDescription;
				request.args.scope._raw_attrStoreData		= response.attrListForStore;
	
			}, // end of onSuccess method
			//preventCache:true,
			//failOk	: true,
			'sync'		: true,
			'timeout'	: 	application.configuration.global.AJAX_default_timeout
		});
		
		this.renumberViewPositions();
		this.outputViewList();
		
	} // end of method loadViews
	,
	'getCSSClassForEditStatus' : function (editStatus) {
		switch (editStatus) {
			case 'inserted'	:	return 'inserted';
			case 'changed'	:	return 'modified';
			case 'deleted'	:	return 'deleted';
			default			: 	return '';
		} // end switch edit status
	} // end of method getCSSClassForEditStatus
	,
	'outputViewList' : function (selectedViews) {

		var numViews =0;
	
		this.selectedViews=((typeof selectedViews=='object') ? selectedViews : []);
	
		// empty the view list
		dojo.empty(this.widgets.viewList.containerNode);
					
		// query for all views and add all views to the view list
		this.viewStore.fetch({
			'query'	: { 'UUID'	: '*'},
			'scope'	: this,
			'onItem': function (item,request) {
				var UUID 	= this.viewStore.getValue(item, 'UUID');
				var selected= ((		(this.selectedViews)
								&&	(this.selectedViews.length>0)
								&&	(dojo.indexOf(this.selectedViews,UUID)>=0)
								)?true:false);
				this.createItemInViewList(item, selected);
				numViews++;
			}, // end onItem
			'sort' 	:  [	{	'attribute'	: 'positionOfView' 	/*, descending: true*/}, 
							{ 	'attribute'	: 'name'			/*, descending: true*/}
						]
		}); // end fetch
		
		// display the views
		if (numViews) 	this.selectedViewsHaveChanged(selectedViews);
			else		this.showNoViewsYetMessage();
	} // end of method outputViewList	
	,
	'showNoViewsYetMessage' : function () {
		
		// clear the edit area
		this.widgets.viewNamePane.destroyDescendants();
		this.widgets.viewEditor.destroyDescendants();

		this.widgets.viewEditBorderContainer.removeChild(this.widgets.viewNamePane);
		this.widgets.viewEditBorderContainer.removeChild(this.widgets.viewNameEditor);

		// set the view name pane		
		this.widgets.viewNamePane.set('content', ''
			+'<h2>'
				+ T('manageViews.js/OTHasNoViews_HTM','« $[0]»  has no views, yet',[this.OT_name])
			+'</h2>'
			);
		this.widgets.viewEditBorderContainer.addChild(this.widgets.viewNamePane);
		
		// set the view editor
		
		this.widgets.viewEditor.set('content', ''
				+ T('manageViews.js/NoViewsYetHint_HTM','<p>You should create some views for « $[0]» .</p><p>You will probably need to set a <i>default name</i> and a <i>default description view</i>. You can set this on the tab « General Properties»  of the view.</p><ul><li>RS II will use the default name view as a name template for the objects of this type. This permits to generate the object names automatically from attribute values of the objects.</li><li>The default description view is displayed in the list of all objects.</li></ul>',[this.OT_name])
			 );
		
	} // end of method showNoViewsYetMessage
	,
	'createItemInViewList' : function (item, selected) {

		var view_UUID 	= this.viewStore.getValue(item, 'UUID'		);
		var name 		= this.viewStore.getValue(item, 'name'		);
		var editStatus 	= this.viewStore.getValue(item, 'editStatus');
		var inherited	= this.viewStore.getValue(item, 'isInherited');
		
		// prepare the attributes of the new DOM node
		var a = {
			'id'		: 'application.admin.mV.v_'+view_UUID,
			'innerHTML'	: (inherited?this.inheritedChar+' ':'')+name,
			'value'		: view_UUID,
			'class'		: this.getCSSClassForEditStatus(editStatus)
		};
				
		if (selected) a['selected'] = 'selected';
				
		// create the option DOM node
		dojo.create( 'option', a, this.widgets.viewList.containerNode /* where to place the newly created node as a child */ );
		
	} // end of method createItemInViewList
	,
	'selectedViewsHaveChanged' : function (selectedViews) {
		// this method decides what needs to be displayed in the edit area
		
		this.selectedViews=((typeof selectedViews=='object') ? selectedViews : []);
		
		// clear the edit area
		this.widgets.viewNamePane.destroyDescendants();
		this.widgets.viewEditor.destroyDescendants();

		this.widgets.viewEditBorderContainer.removeChild(this.widgets.viewNamePane);
		this.widgets.viewEditBorderContainer.removeChild(this.widgets.viewNameEditor);
		
		switch(this.selectedViews.length){
			case 1: // one view selected -- load the edit dialog into the edit area
				this.displayView(selectedViews[0]);
				break;
			case 0: // nothing selected

				this.widgets.viewNamePane.set('content', ''
					+'<h2>'
						+ T('manageViews.js/SelOrCreateView_TXT','Select or create a view')
					+'</h2>'
					);
				this.widgets.viewEditBorderContainer.addChild(this.widgets.viewNamePane);
				this.widgets.viewEditor.set('content', ''
						+ T('manageViews.js/NoViewSelected_HTM', '<ul><li>Please select a view on the left hand side or</li><li>create a new one.</li></ul>') 
					);
				break;
			default: // many views -- list the views
			
				// get the names of all selected views
				var names=[];
				
				dojo.forEach(this.selectedViews, function(UUID, nr) {
					// get the corresponding item
					this.viewStore.fetchItemByIdentity({
						'identity' 	: UUID,
						'scope'		: this,
						'onItem' 	: function (item, request) {
							var name 		= this.viewStore.getValue(item, 'name'		),
								editStatus 	= this.viewStore.getValue(item, 'editStatus');
							
							names.push('<li class="'+this.getCSSClassForEditStatus(editStatus)+'">'+name+'</li>');		
						} // end of function onItem
					}); // end fetch
				},this); // end for each UUID
			
				// output a nice view list
				this.widgets.viewNamePane.set('content', ''
					+'<h2>'
						+ T('manageViews.js/YouHaveSelXViews_TXT','You have selected $[0] views:',[this.selectedViews.length])
					+'</h2>'
				);
				this.widgets.viewEditBorderContainer.addChild(this.widgets.viewNamePane);
				this.widgets.viewEditor.set('content', ''
					+'<ul>'
						+names.join('')
					+'</ul>'
					+'<p>&nbsp;</p>'
					+ T('manageViews.js/Dialog_manyViewsSelected_hint_HTM','<p>Click on a single view to edit its properties.</p><p>You may as well duplicate, move or delete the selected views or undo all changes to them.</p>') 
				);
				
		} // end switch	
	} // end of method handleSelectionChange
	,
	'setViewName'	: function (V_UUID) {
	
		this.V_UUID_current = V_UUID;
	
		var editStatus='', name='', viewTypeString='', cssClass='', inherited=false, kind='';

		// get the corresponding view
		this.viewStore.fetchItemByIdentity({
			'identity' 	: V_UUID,
			'scope'		: this,
			'onItem' 	: function (item) {
				// is the the view inherited?
				inherited 			= 	this.viewStore.getValue(item, 'isInherited');
				name				= this.viewStore.getValue(item, 'name');
				// kind 				= this.viewStore.getValue(item, 'kind');
				// viewTypeString		= application.viewKinds.viewKindList[kind].name;
				if (this.viewStore.hasAttribute(item, 'editStatus')) 
					editStatus 		= this.viewStore.getValue(item, 'editStatus');
				cssClass			= this.getCSSClassForEditStatus(editStatus);
			} // end of function onItem
		}); // end get the item
		
		// set the name editor properties
		dojo.toggleClass( this.widgets.viewNameEditor.focusNode, 'inserted', false);
		dojo.toggleClass( this.widgets.viewNameEditor.focusNode, 'modified', false);
		dojo.toggleClass( this.widgets.viewNameEditor.focusNode, 'deleted' , false);
		dojo.toggleClass( this.widgets.viewNameEditor.focusNode, cssClass,   true);
		
		if(this.widgets.viewEditBorderContainer.getIndexOfChild(this.widgets.viewNameEditor)<0) {
			this.widgets.viewNameEditor.set('title', (inherited? T('manageViews.js/ViewIsInher_TXT','This view is inherited, hence its name cannot be changed.') : T('manageViews.js/ClickToEditVName_TXT','Click here to edit the view\'s name.') ));
			this.widgets.viewNameEditor.set('disabled', inherited );
			this.widgets.viewNameEditor.set('value',name);
			this.widgets.viewEditBorderContainer.addChild(this.widgets.viewNameEditor);
		} // end if
		
		// modify the option DOM node
		var o = dojo.byId('application.admin.mV.v_'+V_UUID);
		if(o) {
			dojo.attr(o, 'innerHTML',	(inherited?this.inheritedChar+' ':'')+name	);
			dojo.attr(o, 'class', 		cssClass									);
		} // end if
		
	} // end of method setViewName
	,
	'name_changed' : function () {
		if(this.widgets.viewNameEditor.isValid()) {
			this.valueHasChanged(this.V_UUID_current, 'name', 
				this.widgets.viewNameEditor.attr('value')
			);
		} // end if
	} // end of method name_changed
	,
	'displayView' : function (UUID) {
		// this method displays the edit dialog components for view with UUID
		
		var inherited, 
			name 			= '', 
			V_UUID 			= '',
			kind 			= '',
			viewTypeString	= '',
			editStatus 		= '';
			
		// get the corresponding view
		this.viewStore.fetchItemByIdentity({
			'identity' 	: UUID,
			'scope'		: this,
			'onItem' 	: function (item) {
				// is the the view inherited?
				inherited 			= this.viewStore.getValue(item, 'isInherited');
				name				= this.viewStore.getValue(item, 'name');
				V_UUID				= this.viewStore.getValue(item, 'UUID');
				kind 				= this.viewStore.getValue(item, 'kind');
				viewTypeString		= application.viewKinds.viewKindList[kind].name;
				if (this.viewStore.hasAttribute(item, 'editStatus')) 
					editStatus 		= this.viewStore.getValue(item, 'editStatus');				
			} // end of function onItem
		}); // end get the item
		
		
		// set the name pane
		this.setViewName(V_UUID);
		
		// set the edit pane
		
		var c = this.getViewConfigurationEditor_config(V_UUID);
		
		if(editStatus=='deleted') { // view is marked to be deleted
		
			this.widgets.viewEditor.set('content', new application.widgets.manageViews_viewMarkedDeleted(c)	);
			
		} else { // view is not deleted
			
			// create the tab container for the different view configuration panels
			this.widgets.viewEditorTabContainer = new dijit.layout.TabContainer({});
			this.widgets.viewEditor.set('content', this.widgets.viewEditorTabContainer);
			
			// the panel with general properties
			this.widgets.viewEditor_generalPane = new dijit.layout.ContentPane({'title': T('manageViews.js/GeneralProp_TIT','General Properties') });
			this.widgets.viewEditorTabContainer.addChild(this.widgets.viewEditor_generalPane);
			this.widgets.viewEditor_generalPane.set('content', 
				new application.widgets.manageViews_viewEditor_generalProperties(c) );
			
			// the panel with specific properties
			this.widgets.viewEditor_specificPane = new dijit.layout.ContentPane({'title': T('manageViews.js/SpecProp_TIT','Specific Properties') });
			this.widgets.viewEditorTabContainer.addChild(this.widgets.viewEditor_specificPane);
			var cWn		= application.viewKinds.viewKindList[kind].configurationWidgetClass;
			if(!(cWn in application.widgets.viewConfiguration)) 
				throw 'Cannot find the configuration widget class "'+cWn+'" of the view kind "'+kind+'" in application.widgets.viewConfiguration .';
			this.widgets.viewEditor_specificOptionsEditor = new application.widgets.viewConfiguration[cWn](c);
			this.widgets.viewEditor_specificPane.set('content', this.widgets.viewEditor_specificOptionsEditor);
			
			this.widgets.viewEditorTabContainer.selectChild(this.widgets.viewEditor_specificPane);
			
			// show the panel for the calculation facility configuration?
			if ( 	 	('hasCalculationFacilities' in application.viewKinds.viewKindList[kind]) 
					&& 	(application.viewKinds.viewKindList[kind].hasCalculationFacilities)
				) {
				this.widgets.calcPane = new application.widgets.manageViews_viewEditor_calculationProperties(c);
				this.widgets.viewEditorTabContainer.addChild(this.widgets.calcPane);
			} // end if show configuration for calculation facilities
			
			// show the panel for the CBR configuration?
			if ( 	 	('hasCBRFacilities' in application.viewKinds.viewKindList[kind]) 
					&& 	(application.viewKinds.viewKindList[kind].hasCBRFacilities)
				) {
				this.widgets.CBRPane = new application.widgets.manageViews_viewEditor_CBRProperties(c);
				this.widgets.viewEditorTabContainer.addChild(this.widgets.CBRPane);
			} // end if show configuration for calculation facilities
			
		}; // end if
		
	} // end of method displayView
	,
	'startup' : function() {
		// If you need to be sure parsing and creation of any child widgets has 
		// completed, use startup. This is often used for layout widgets like 
		// BorderContainer. If the widget does JS sizing, then startup() should 
		// call resize(), which does the sizing.
		this.inherited(arguments);
		
		this.widgets.borderContainer.startup();
		this.widgets.borderContainer.resize();
	} // end of method startup
	,
    /*resize : function() {
		// All widgets that do JS sizing should have a method called resize(), that lays 
		// out the widget. Resize() should be called from startup() and will also be 
		// called by parent widgets like dijit.layout.ContentPane.
	}
	,*/
	'destroy' : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		
		for (var i in this.widgets) {
			this.widgets[i].destroyRecursive();
			delete this.widgets[i];
		} // end for .. in
		
		this.inherited(arguments);
	} // end of method destroy
	,
	'onCancel' : function(){
		return false;
	} // end of method
	,
	
	
	
	
	'getListOfAttributesInCurrentView' : function (filterBy) {
		// This method returns an object list containing all attributes that are in use in the current view.
		// filterBy is an optional parameter. It is an {}, the slot name needs to be an attribute slot name, 
		// 	the value needs to be the one to which the attribute slot needs to correspond to.
		// 	value may be as well a function returning true or false. This function receives the attribute's slot value as first and the whole attribute object as second parameter.
	
		var attrsInView = this.widgets.viewEditor_specificOptionsEditor._getListOfUsedAttributes(),
			l = {};
		
		// build a list of available attributes if it does not exist, yet
		if(!this._availableAttributeMap) {
			this._availableAttributeMap = {};
			dojo.forEach(this._raw_attrStoreData.items, function (i) {
				this._availableAttributeMap[i.UUID]=i;
			}, this);
		} // end if

		// iterate over all attributes in the view and build an object list
		dojo.forEach( attrsInView, function (A_UUID) {
			if (!A_UUID || !(A_UUID in this._availableAttributeMap)) return;
			var item = this._availableAttributeMap[A_UUID];
		
			// ------------------------------------------------------------
			var filtersAreMet = function (filterBy, item) {
				// This local function tests if a passed item object with slots meets the slot values specified in the filterBy object.
				for (var slot in filterBy) {
					switch (typeof filterBy[slot]) {
						case 'function':
							if ( !filterBy[slot](item[slot], item) ) {
								return false;
							} // end if
							continue;
							break;
						default:
							if ( item[slot]!=filterBy[slot] ) {
								return false;
							} // end if
					} // end switch
				} // end for .. in
				return true;
			} // end of local function definition
			// ------------------------------------------------------------
			
			
			// ignore the current item if the passed filters are not met
			if ( 		( typeof filterBy == 'undefined' )
					||	(		( typeof filterBy == 'object' )
							&&	( filtersAreMet(filterBy, item) )
							)
					) {
				l[A_UUID] = item;
			} // end if
		}, this); // dojo.forEach
	
		return l;
	} // end of method getListOfAttributesInThisView
	,
	'getListOfAvailableAttributes' : function () {
		// this method returns a (cloned) list of all attributes that belong to the object type.
		return dojo.clone(this._raw_attrStoreData);
	} // end of method getListOfAvailableAttributes
	,
});




// extend the admin functionality with views management
application.admin.manageViews = {
	'dialogWidget' 	: null
	,
	'OT_UUID'		: null
	,
	'OT_name'		: null
	,
	'showDialog' : function(){
	
		if(this.dialogWidget) this.closeDialog(); // carry out some cleanUp
	
		// make the object type UUID and name local
		this.OT_UUID =  application.admin.navigationStore.getValue(application.admin.currentNavigationItem,'UUID');
		this.OT_name =  application.admin.navigationStore.getValue(application.admin.currentNavigationItem,'name');
		
		this.dialogWidget = new application.widgets.manageViewsDialog({
			'OT_UUID'	: this.OT_UUID,
			'OT_name'	: this.OT_name
		});
		
		this.dialogWidget.startup();
		this.dialogWidget.show();
	} // end of method showDialog
	,
	'execute' : function () {
	
		// remove all deleted items from the store
		this.dialogWidget.viewStore.fetch ({
			'query'	: { 'editStatus': 'deleted'},
			'scope'	: this,
			'onItem': function ( item, request ) {
				this.dialogWidget.viewStore.deleteItem( item );
			} // end of method onItem
		});
		
		// apply all changes to the store
		this.dialogWidget.viewStore.save();					

		// send all changes to the server
		application.OT_AJAX_query({
				'task'		: 'set_OT_viewTypes',
				'UUID'		: this.OT_UUID,
				'viewTypes'	: this.dialogWidget.viewStore._getNewFileContentString()
			},
			function(r,a){ // onSuccess
			}, // end of onSuccess function
			true // synchronously
		); 
	
		return this.closeDialog();
	} // end of method execute
	,
	'closeDialog' : function() {
		this.dialogWidget.hide();
		this.dialogWidget.destroyRecursive(false);
		this.dialogWidget.destroy();
		this.dialogWidget=null;
		this.OT_UUID = null;
		this.OT_name = null;
		
	} // end of method closeDialog
}; // end extension of the admin functionality

// register the right click menu option
application.admin.adminPane_rightClickMenu.addOption('' 
	+ T('manageViews.js/ManageViews_MNU','Manage <strong>views</strong>'), 
	function(){application.admin.manageViews.showDialog();},
	'rsIcon_manageViews', 
	function ( item_type ) {return (item_type!='OT'?true:false);}
);

// a widget that tells that the current widget is deleted
dojo.declare( 'application.widgets.manageViews_viewMarkedDeleted', [dijit._Widget,dijit._Templated],{
	'V_UUID'			:	'this needs to be replaced on instantiation',
	'name'				:	'this needs to be replaced on instantiation',
	'dialogWidget'		:	null, // needs to be passed
	'templateString' 	: 	'',
	'postMixInProperties' : function () {
		this.inherited(arguments);
		
		this.templateString = '<div>'
			+ T('manageViews.js/DeleteViewPane_HTM','<p>The view « $[0]»  will be <span class="deleted">deleted</span>.</p><p>In case this was a mistake, <a style="cursor:pointer;" dojoAttachEvent="onclick:undo_clicked">click here to undo this</a>.</p>',[this.name]) 
			+'</div>';
	}, // end of method postMixInProperties
	'undo_clicked'		: function(){
		this.dialogWidget.undoDelete(this.V_UUID);
	} // end of method undoClicked
});
