/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare('application.widgets.editOTDescription',[common.widgets.fixedSizeDialog],{
	
	// these slots have values need to be passed when creating the widget
	'name'			: null, // mandantory STRING --- the object type name
	'type'			: null, // mandantory STRING --- either 'OT' or 'RT'
	'T_UUID'		: null, // mandantory STRING --- the object or relation type's UUID
	'description'	: null, // mandantory STRING --- the object type description
	
	
	// the following slots form internal variables / containers
	
	
	
	// settings of the parent class common.widgets.fixedSizeDialog
	'innerWidth'	: 800
	,
	'innerHeight'	: 2000
	,
	
	
	
	// widget life cycle
	'constructor' : function () {
	
		// some initialisations
		this.name 			= '';
		this.T_UUID 		= '';
		this.description 	= '';
		this.type 			= '';
	
		this.widgets 		= {};
		
	} // end of method constructor
	,
	'postMixInProperties' : function () {
		this.inherited(arguments);
	
		switch (this.type) {
			case 'OT':
				this.title = T( 'editORTDescription.js/EditDescrOT_HTM', 'Edit the Description of the Object Type « $[0]» ', [this.name]);
				break;
			case 'RT':
				this.title = T( 'editORTDescription.js/EditDescrRT_HTM', 'Edit the Description of the Relation Type « $[0]» ', [this.name]);
				break;
			default:
				throw 'editORTDescription: cannot identify an object or relation type in the passed parameters';
		} // end switch this.type
		
	} // end of method postMixInProperties
	,
	'buildRendering' : function () {
		this.inherited(arguments);
		
		// set up a border container for the editor, etc.
		this.widgets.BC = new dijit.layout.BorderContainer ({
			'style'		: 'width:100%;height:100%',
			'gutters'	: false,
		}).placeAt( this.containerNode);
		
		this.widgets.buttonPane = new dijit.layout.ContentPane ({
			'region'	: 'bottom',
			'style'		: 'margin-top:.25em;text-align:right;',
		});
		this.widgets.BC.addChild(this.widgets.buttonPane);
		
		// create the editor
		this.widgets.editorContentPane = new dijit.layout.ContentPane({
			'region'	: 'center',
			'class'		: 'dijitMenuBar dijitMenuPassive'
		});
		this.widgets.BC.addChild(this.widgets.editorContentPane);
		
		try {
			this.widgets.editor = new application.widgets.HTMLEditor({
				'height'	: '100%',
			});
		} catch (e) {
			console.error(e);	
			var err = this.declaredClass+' :: '+'postCreate ():\n'
				+'Cannot create an object of the type "application.widgets.HTMLEditor".\n'
				+'Error message:\n'
				+e;
			throw e;
		} // end try ... catch
		this.widgets.editor.placeAt(this.widgets.editorContentPane.containerNode);
		this.widgets.editor.set('value',this.description);
		
		
		// create the buttons ...
		
		this.widgets.OkButton = new dijit.form.Button({
			'label' 	: '<img src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/dialog-ok-apply-4.png"/> '
				+T( 'BTN_OK', 'OK' ),
			'type'		: 'button',
		}).placeAt(this.widgets.buttonPane.containerNode);
		
		this.widgets.CancelButton = new dijit.form.Button({
			'label' 	: '<img width="12" src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/dialog-cancel-4.png"/> '
				+T('BTN_Cancel','Cancel'),
		}).placeAt(this.widgets.buttonPane.containerNode);
		
	} // end of method buildRendering
	,
	'startup' : function () {
		this.inherited(arguments);
	
		// start the child widgets
		this.widgets.BC.startup();
		
		// it's time now for the connects ...
		this.connect( this.widgets.OkButton,	'onClick', '_execute'			);
		this.connect( this.widgets.CancelButton,'onClick',  'hide'				);
		
	} // end of method startup
	,
	'destroy' : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		
		for (var i in this.widgets) {
			if (this.widgets[i].destroyRecursive) this.widgets[i].destroyRecursive(false);
			delete this.widgets[i];
		} // end for .. in
		
		// this.inherited(arguments);
	} // end of method destroy
	,
	
	// internal methods
	'_execute' : function (e) {
		this.onExecute( this.widgets.editor.get('value') );
		
		this.hide();
	} // end of method _execute
	,
	
	
	
	// events
	'onExecute' : function (newDescription) {},
	
});	// end of declaration application.widgets.editOTDescription
	




// extend the admin functionality
application.admin.editORTDescription = {
	'showDialog' : function() {
	
		loader.show();
		if (this.dialogWidget) this.deleteDialog(); // destroy a potentially existing dialog widget
		
		// get the necessary information
		var s 			= application.admin.navigationStore,
			i 			= application.admin.currentNavigationItem;
			
		this.name 		= s.getValue(i, 'name');
		this.UUID 		= s.getValue(i, 'UUID');
		this.type 		= s.getValue(i, 'type');
		this.description= '';
		
		// get the description and set it into the editor
		application.AJAX_query_aux(
			((this.type=='OT')?'JSON_ObjectType':'JSON_RelationType'),
			{	
				"task"	: (this.type?'get_OT_description':'get_RT_description'),
				"UUID"	: this.UUID
			},
			function(r,a){
				// set the description
				a.args.scope.description = r.description;
			},
			true, // synchronously
			this // scope
		);
		
		// instantiate the widget
		this.dialogWidget = new application.widgets.editOTDescription({
			'name'			: this.name, 
			'type'			: this.type, 
			'T_UUID'		: this.UUID, 
			'description'	: this.description,
		});
		
		// carry out the necessary connects
		this.dialogConnects = [
			dojo.connect( this.dialogWidget, 'onExecute', this, '_onExecute' 	),
		];
		
		this.dialogWidget.startup();
		this.dialogWidget.show();
		
		loader.hide();
				
	} // end-of-method showDialog
	,
	'closeDialog' : function() {
	
		this.dialogWidget.hide();
		
		// this.deleteDialog();
		
	} // end of method closeDialog
	,
	'_onExecute' : function( newDescription ) {

		loader.show();
	
		// save the description to the server
		application.AJAX_query(
			this.type,
			{
				"task"			: ((this.type=='OT')?'set_OT_description':'set_RT_description'),
				"UUID"			: this.UUID,
				"description"	: newDescription
			},
			function(){} // onSuccess
		);
		
		loader.hide();
		
	} // end-of-method execute
	,
	'deleteDialog' : function () {
	
		dojo.forEach( this.dialogConnects, function (c) {
			dojo.disconnect(c);
		}, this);
		
		this.dialogWidget.destroyRecursive(false);
		this.dialogWidget.destroy();
		this.dialogWidget=null;
		
		delete this.name;
		delete this.UUID;
		delete this.type;
		delete this.description;
		
	} // end of method deleteDialog
	,

}; // end extension of the admin functionality with editORTDescription

// register the right click menu option
application.admin.adminPane_rightClickMenu.addOption( T('editORTDescription.js/EditDescr_MNU','Edit <strong>description</strong>'), 
	function(){application.admin.editORTDescription.showDialog()}, 
	'rsIcon_editText', 
	function(item_type) { 
		return( (item_type=='OT')/*||(item_type=='RT')*/?false:true); 
	} // end of function
);
