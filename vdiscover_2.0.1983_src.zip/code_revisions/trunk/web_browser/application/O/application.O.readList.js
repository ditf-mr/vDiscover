﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

application.O.readList = {
	'store' : null // dojo.data.ItemFileWriteStore
	,
	'tree' : null // dijit.Tree
	,
	'showTimeOut' : null //timeOut
	,
	'initialise' : function () {
		
		delete this.store;
		this.store = new dojo.data.ItemFileWriteStore({
			'url'				: "?v=JSON_General&task=get_watchList",
			'clearOnClose'		: true,
			'urlPreventCache'	: true
		});
	
		if (this.tree) {
			this.tree.destroy();
			delete this.tree;
		} // end if
	
		this.tree = new dijit.Tree({
			id 				: 'application_readListTree',
			showRoot		: false,
			model			: new dijit.tree.ForestStoreModel({
									store: this.store,
									query: { type: 'OT' },
									rootId: 'OT_root',
									rootLabel: 'Object types',
									childrenAttrs: ['_objects']
								}),
			getLabelClass 	: function(item, isOpened) {
				var type='', isTagged=false;
				with(application.O.readList.store){
					// get item type
					try{ isTagged=(hasAttribute(item,'isTagged')?getValue(item,'isTagged'):false); } catch(e){}
					try{ type=(hasAttribute(item,'type')?getValue(item,'type'):''); } catch(e){}
				} // end with
				if(type=='OT') {
					return 'RS_readList_OT';
				} else { // type=='O'
					if (isTagged) {
						return 'RS_readList_O_nameTagged';
					} else {
						return '';
					} // end if isTagged
				} // end if OT or O
			} // end of method getLabelClass
			,
			getIconClass 	: function(item, isOpened) {
				// get item type
				var type='', has_children=false;
				try{ 
					type=(application.O.readList.store.hasAttribute(item,'type')?application.O.readList.store.getValue(item,'type'):'');
				} catch(e){}
				if(type=='OT') try{ 
					has_children=(application.O.readList.store.hasAttribute(item,'children') && application.O.readList.store.getValue(item,'children'));
				} catch(e){}
				var iconClass='';
				switch(type){
					/*case 'navigation_node':
						iconClass='RS_icon_navigation_node';
						break;*/
					/*case 'RT':
						iconClass='RS_icon_RT';
						break;*/
					case 'OT':
						iconClass=(has_children?'RS_icon_OT_with_children':'RS_icon_OT');
						break;
					default:
						iconClass='RS_icon_O';
				} // end switch
				
				return iconClass;
			}
		}); // end create tree
		dojo.connect(this.tree,'onClick', function(item,node,evt){
			// is there already a show timeout?
			if(this.showTimeOut) {
				clearTimeout(this.showTimeOut);
				this.showTimeOut=null;
			} // end if there is already a timeout
		
			// open object
			if(item&&(application.O.readList.store.getValue(item,'type')=='O')) {
				var O_v_UUID=application.O.readList.store.getValue(item,'UUID');
				// set timeout to show the object
				this.showTimeOut= setTimeout('application.O.show(\''+O_v_UUID+'\');', 250);
			} // end if

			// open object type
			if(item&&(application.O.readList.store.getValue(item,'type')=='OT')) {
				var OT_UUID		=application.O.readList.store.getValue(item,'UUID');
				var OT_name		=application.O.readList.store.getValue(item,'name');
				var OT_menuBar	=application.O.readList.store.getValue(item,'OT_menuBar');
				// set timeout to show the object
				// this.showTimeOut= setTimeout('application.OT.show(\''+OT_UUID+'\',\''+OT_name+'\',\''+OT_menuBar+'\');', 250);
				this.showTimeOut= setTimeout('application.OT.show(\''+OT_UUID+'\');', 250);
			} // end if

		}); // end onClick
		
		dojo.connect(this.tree,'onDblClick', function(item,node,evt){
			// is there already a show timeout?
			if(this.showTimeOut) {
				clearTimeout(this.showTimeOut);
				this.showTimeOut=null;
			} // end if there is already a timeout

			// do nothing if there was double click on an object type
			if(application.O.readList.store.getValue(item,'type')=='OT') return;
			
			// tag or untag the object
			application.O.readList.toggleTaggedStatus(application.O.readList.store.getValue(item,'UUID'));
		}); // end onDblClick
		
		var objListToolTip=  new common.widgets.Tooltip({
			connectId: [this.tree.domNode],
			//TG: T()
			label: T('app.O.readList.js/ClickOnObj_HTM',
				  '<p>Click on an object to show it.</p><p>Double click on an object to tag or untag it.</p>'),
			position: ['after']
		});
		
		// add a right-click menu
		this.tree.placeAt('application.historyPane');
		
		this.rightClickMenu = new dijit.Menu({});
		
		this.rightClickMenu.addChild(new dijit.MenuItem({
			label: T('app.O.readList.js/RemSeenObj_CON','Remove seen objects'),
			onClick : function(e) {
			
				// delete the objects that are not tagged
				application.O.readList.store.fetch({
					query : {'type' : 'O', 'isTagged': false},
					queryOptions: {deep:true},
					onItem:function(item){
						application.O.readList.store.deleteItem(item);
					} // end onItem
				}); // end fetch item
				
				// delete the object types without childs
				application.O.readList.store.fetch({
					query : {'type' : 'OT'},
					queryOptions: {deep:true},
					onItem:function(item){
						var children =item._objects; // that's ok, here, because objects is not a regular data slot
						if(!children.length) application.O.readList.store.deleteItem(item);
					} // end onItem
				}); // end fetch item
				
			} // end onClick
		}));
		
		 this.rightClickMenu.bindDomNode('application.historyPane');
		
		
	} // end of method initialise
	,
	'isTagged':function(O_v_UUID) {
		var isTagged=false;
		application.O.readList.store.fetchItemByIdentity({
			identity:O_v_UUID,
			onItem:function(item){if(item){				
				with(application.O.readList.store){
					try{ isTagged=(hasAttribute(item,'isTagged')?getValue(item,'isTagged'):false);} catch(e){}
				} // end with			
			}} // end onItem
		}); // end fetch item
		return isTagged;
	} // end of method isTagged
	,
	'tag' : function (O_v_UUID) {
		if (!this.isTagged(O_v_UUID)) this.toggleTaggedStatus(O_v_UUID);
	} // end of method tag
	,
	'removeTag' : function (O_v_UUID) {
		if (this.isTagged(O_v_UUID)) this.toggleTaggedStatus(O_v_UUID);
	} // end of method tag
	,
	'objIsListed':function(O_v_UUID) {
		var isListed=false;
		application.O.readList.store.fetchItemByIdentity({
			identity:O_v_UUID,
			onItem:function(item){if(item){				
				isListed=true;			
			}} // end onItem
		}); // end fetch item
		return isListed;
	} // end of method isTagged
	,
	'toggleTaggedStatus' : function(O_v_UUID) {
		var isTagged=false;
		// get the item
		application.O.readList.store.fetchItemByIdentity({
			identity:O_v_UUID,
			onItem:function(item){if(item){
				
				with(application.O.readList.store){
					try{ isTagged=(hasAttribute(item,'isTagged')?getValue(item,'isTagged'):false);} catch(e){}
					// toggle the tag
					isTagged=!isTagged;
					// set isTagged
					setValue(item,'isTagged',isTagged);
					
					// change the class of the obj name, if necessary
					var objName=dojo.byId(O_v_UUID + application.O.object_NameTag_id);
					if (objName) dojo.toggleClass(objName,'RS_objName_tagged',isTagged);
					
					application.O_AJAX_query( 
						{ 	
							"task"			: (isTagged?"addToWatchList":"deleteFromWatchList"), 
							"UUID"			: getValue(item,'UUID')
						}
						, 
						function(r,a){ // onSuccess method				
							// do nothing
						}, // end of onSuccess method
						true // sync
					); // end AJAX query
				} // end with			
				
			}} // end onItem
		}); // end fetch item
		
		return isTagged;
	} // end of method toggleTaggedStatus
	,
	add : function (O_v_UUID, name, OT_UUID, OT_name /* optional */, OT_menuBar /* optional */) {
		
		// some tests
		if (!O_v_UUID||!dojo.isString(O_v_UUID)) return;
	
		// is the item already on the list of read objects?
		var objectIsNotListedYet = !this.objIsListed(O_v_UUID);
	
		if (objectIsNotListedYet) {
			// detect whether the type is listed, already
			var OTisNotListedYet = true;
			var OT_item = null;
			this.store.fetchItemByIdentity({
				'identity'	: OT_UUID,
				onItem	: function (item, scope){
					if (item) {
						OTisNotListedYet = false;
						OT_item=item;
					} 
				} // end onItem
			});
			
			// list the object type
			if (OTisNotListedYet) {
			
				// were the OT_name and the OT_menuBar passed?
				if(!OT_name || !OT_menuBar) {
					var OT_store = application.OT.navigationStore;
					OT_store.fetchItemByIdentity({
						'identity'	: OT_UUID,
						'scope'		: this,
						'onItem'	: function (item, scope){
							if (item) {
								OT_name 	= OT_store.getValue(item, 'name');
								OT_menuBar 	= OT_store.getValue(item, 'menuBarOT');
							} // end if
						} // end onItem
					});	// end fet OT info
				} // end if
			
				OT_item=this.store.newItem({
					'UUID'		: OT_UUID,
					'name'		: OT_name,
					//'OT_UUID'	: OT_UUID,
					'type'		: 'OT',
					'_objects'	: [],
					'isTagged'	: false,
					'OT_menuBar': OT_menuBar
				});
			} // end if
		
			// list the object
			try {
				this.store.newItem(
					{
						'UUID'		: O_v_UUID,
						'O_v_UUID'	: O_v_UUID,
						'O_UUID'	: '???',
						'name'		: name,
						'OT_UUID'	: OT_UUID,
						'type'		: 'O',
						'isTagged'	: false
					},
					{
						parent: OT_item,
						attribute: '_objects'
					}
				);
			} catch (e) {
				console.error('application.O.readList.add: Cannot add item for O_v_UUID "'+O_v_UUID+'" to the store.\nError message:\n\n'+e);
				console.error(e);
			} // end try ... catch
		} // end if
		//application.O.readList.store.save();

	} // end of method add
	,
	'updateName' : function(O_v_UUID,newName){
		application.O.readList.store.fetchItemByIdentity({
			identity : O_v_UUID,
			onItem:function(item){if(item){
				application.O.readList.store.setValue(item, 'name', newName);
			}} // end onItem
		}); // end fetch item
	} // end of method updateName
	,
	'delete' : function(O_v_UUID){
		application.O.readList.store.fetchItemByIdentity({
			identity : O_v_UUID,
			onItem:function(item){if(item){
				application.O.readList.store.deleteItem(item);
			}} // end onItem
		}); // end fetch item
	} // end of method updateName
	,
	deleteType : function (OT_UUID) {
		
		// delete the object type with OT_UUID
		application.O.readList.store.fetch({
			query : {'UUID' : OT_UUID},
			onItem:function(item){
				application.O.readList.store.deleteItem(item);
			} // end onItem
		}); // end fetch item
		
	} // end of method deleteType
	
};  // end of object definition application.O.readList

dojo.addOnLoad(function(){application.O.readList.initialise();});
