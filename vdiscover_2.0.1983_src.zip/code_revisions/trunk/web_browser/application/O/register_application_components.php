<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

$r->register_JavaScriptFile('application/O/application.widgets.ViewPane.js');
$r->register_JavaScriptFile('application/O/application.widgets.ObjectWidget.js');
$r->register_JavaScriptFile('application/O/application.O.js');
$r->register_JavaScriptFile('application/O/application.O.readList.js');
$r->register_JavaScriptFile('application/O/registerMenuBarOptions.js');

$r->register_dialogHTML('application/O/duplicateObject/duplicateObject.dialog.dojoHTML.php');
$r->register_dialogHTML('application/O/renameObject/renameObject.dialog.dojoHTML.php');
$r->register_dialogHTML('application/O/close_objectNotPossible.dialog.dojoHTML.php');

$r->register_cssContent( '
/* CSS classes for the object read list*/
.RS_readList_OT {
	font-weight:bold !important;
}

.RS_readList_O_nameTagged {
	font-weight:bold !important;
	background:url(third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/others/tag-orange.png) no-repeat bottom right !important;
	padding-right: 20px;
}

.RS_objNamePane {
	background-color:white;
	cursor:pointer;
	padding: 0 .5ex .5ex .5ex !important; /* because gutters=false in the borderContainer*/
}

.RS_objName_tagged {
	padding-right: 20px;
	background:url(third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/others/tag-orange.png) no-repeat bottom right !important;
}

');
?>