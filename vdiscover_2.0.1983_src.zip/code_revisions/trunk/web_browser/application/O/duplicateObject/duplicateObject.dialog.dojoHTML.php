<?php if (!defined('APPLICATION_started')) {header('Location: .');exit;}
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/
?>
 
<div dojoType="dijit.Dialog" id="application.O.Dialogues.duplicate" title="<?php echo T('duplicateObj.php/DuplObj_TIT', 'Duplicate Object'); ?>" execute="void(false);">
	<div dojoType="dijit.form.Form" onSubmit="if(dijit.byId('application.O.Dialogues.duplicate.newName').validate()) {application.O_menubar_itemKinds.itemKinds_asSlots['O_menubar_itemKinds.general.duplicate'].execute();}; return false;" action="javascript:void(false);">
		<input dojoType="dijit.form.TextBox" id="application.O.Dialogues.duplicate.UUID" type="hidden" value=""/>		
		<table style="min-width:400px; max-width: 800px;">
		<tbody>
			<tr>
			  <td colspan="2"><?php echo T('duplicateObj.php/EnterNameOfDupl_TXT', 'Please enter the name of the duplicate, here:'); ?></td>
			</tr>
			<tr >
			  <td colspan="2">
				<input dojoType="dijit.form.ValidationTextBox" id="application.O.Dialogues.duplicate.newName" regExp=".{1,}" selectOnClick="true"
					type="text" value="" required="true" invalidMessage="<?php echo T('duplicateObj.php/InvMsg_TXT', 'The name should have a least 1 chars.'); ?>" style="width:100%;"
					tooltipPosition="below" trim="true" maxlength="256"/></td>
			</tr>
			<tr>
			  <td colspan="2"  id="application.O.Dialogues.duplicate.errorMessage"></td>
			</tr>
			<tr>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			</tr>
			<tr>
			  <td valign="top" colspan="2" style="text-align:right;">
				<button dojoType="dijit.form.Button" type="submit">
					<?php echo T('BTN_OK', 'OK'); ?>
				</button>
				<button dojoType="dijit.form.Button" type="button" onClick="dijit.byId('application.O.Dialogues.duplicate').hide();">
					<?php echo T('BTN_Cancel', 'Cancel'); ?>
				</button>
			</td>
			</tr>
		</tbody>
	  </table>
	</div>
</div>	

