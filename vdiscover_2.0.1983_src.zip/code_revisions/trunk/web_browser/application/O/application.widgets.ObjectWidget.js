﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

 dojo.declare('application.widgets.ObjectWidget', [dijit.layout.BorderContainer/*dijit._Widget, dijit._Templated*/], {
	
	// special attributes
	_OT_tabContainer_id 	: 'not yet set',
	_O_tab_id 				: 'not yet set',
	_O_tabContainer_id 		: 'not yet set',
	_O_name_id 				: 'not yet set',
	_O_nameTag_id			: 'not yet set',
	viewWidgetList 			: {},
	viewsContainerWidget 	: null,
	tabInEditMode 			: null,

	closable : true,
	widgetsInTemplate : true,
	
	// extensions of the standard widget methods
	/*constructor: function(params, srcNodeRef){
	}
	,*/
	'postMixInProperties' : function() {
		// If you provide a postMixInProperties method for your widget, it will be invoked before rendering occurs, and before any dom nodes are created. If you need to add or change the instance's properties before the widget is rendered - this is the place to do it.
	   this.inherited(arguments);
	   
	   // test if everything necessary is available
	   if(! this.O_UUID ) throw ('Cannot initialise application.widgets.ObjectWidget without O_UUID. Aborting.');
	   if(! this.OT_UUID ) throw ('Cannot initialise application.widgets.ObjectWidget without OT_UUID. Aborting.');
	   if(typeof(this.objName)=='undefined' ) throw ('Cannot initialise application.widgets.ObjectWidget without objName. Aborting.');
	   if(typeof(this.menuBarInfo)=='undefined' ) throw ('Cannot initialise application.widgets.ObjectWidget without menuBarInfo. Aborting.');
	   if(typeof(this.viewTypes)=='undefined' ) throw ('Cannot initialise application.widgets.ObjectWidget without viewTypes. Aborting.');
	   
	   // set some attributes
		this._OT_tabContainer_id 	= application.O.type_tabContainer_prepend 	+ this.OT_UUID;
		this._O_tab_id 				= application.O.object_widget_prepend 		+ this.O_UUID; /* this means O_v_UUID*/
		this._O_tabContainer_id 	= application.O.object_tabContainer_prepend + this.O_UUID; /* this means O_v_UUID*/
		this._O_name_id 			= application.O.object_name_prependInner	+ this.O_UUID;
		this._O_nameTag_id 			= this.O_UUID + application.O.object_NameTag_id;
		
		this.id 					= this._O_tab_id;
		//this.attr('title',this.objName);
		this.title					= this.objName;
	   
	} // end of method postMixInProperties
	,
	onClose : function () {
		if(this.tabInEditMode) {
			// focus the tab that is in edit mode
			this.viewsContainerWidget.selectChild(this.tabInEditMode);
			
			// show a warning message
			var d = dijit.byId('application.Dialogs.O.close_objectNotPossible');
			dojo.attr('application.Dialogs.O.close_objectNotPossible.O_name','innerHTML','« '+this.attr('title')+'» ');
			d.attr('title', 'WARNING - Cannot close « '+this.attr('title')+'» ');
			d.show();
			
			// do NOT close the tab
			return false;
		} // end if
		
		return true;
	} // end of method onClose
	,
	'postCreate' : function(){
		// The widget has been rendered (but note that sub-widgets in the containerNode have not!). The widget though may not be attached to the DOM yet so you shouldn't do any sizing calculations in this method.
	   this.inherited(arguments);
	
	   // create the top pane for the name and menu bar, create the views container
		this._createObjectWidget();
	   
	   // create the bottom pane for the view tabs
	   this._createViewPanes();
	   
	} // end of method postCreate
	,
	'_createObjectWidget' : function () {
		// create the top pane
		var topPane = new dijit.layout.BorderContainer({
			region:'top',
			gutters:false,
			style:'height:85px;'
		});
		this.addChild(topPane);
				
		var objName = dojo.create('A',{
			'id'		: this._O_name_id, 
			'innerHTML'	: this.objName, 
			'href'		: '?jumpTo=O&O_v_UUID='+this.O_UUID,
			'class'		: 'h1',
			'style'		: 'bottom:0.5ex;position:absolute;text-decoration:none;',
			'title'		: T('app.wid.ObjectWidgets.js/TagUntagObj','Click here to tag or untag this object. You may drag this link to another application or to your favorites bar.')
			});
		this.connect(objName, 'onclick', function(e){
			application.O.readList.toggleTaggedStatus(this.O_UUID);
			dojo.stopEvent(e);
			return false;
		});
		
		var objIsTagged=application.O.readList.isTagged(this.O_UUID);
		
		dojo.create('span', {
			id:this._O_nameTag_id,
			'class': (objIsTagged?'RS_objName_tagged':''),
			innerHTML:'&nbsp;'
		}, objName);
		
		var objNamePane = new dijit.layout.ContentPane({
			id: application.O.object_namePane_prepend+this.O_UUID,
			content: objName,
			region:'center',
			'class':'RS_objNamePane'
		});
		topPane.addChild(objNamePane);
	
		// create, add and fill the menu bar
		this.menuItems = [];
		this.menuBar = new dijit.MenuBar({region:'bottom', style:'border-bottom:0;border-left:0;border-right:0'});
		topPane.addChild(this.menuBar);
		
		var p = new dijit.MenuBarItem({
			'title'			: T('app.wid.ObjectWidgets.js/AddViewsToPrintQ','Add all views to the Print Queue'),
			'itemKindUUID'	: 'O_menubar_itemKinds.general.addToPrintQueue',
			'objectWidget' 	: this,
			'onClick'		:function(e){
				// show the animation
				application.sendToPrintQueuePane.show();
				
				// collect all necessary information
				var object_name = this.objectWidget.objName;
				
				var header = ''
					+"<span class='h1'>"
						+this.objectWidget.objName
					+"</span>";
					
				var footer=''
					+'<p class="small textCenter">'
						+window.document.title
						+'&nbsp;'
						+dojo.date.locale.format(
							new Date()
							//,formatOptions
							)
					+'</p>';

				var content = '';
			
				// iterate over all views of the object and send them to the print preview pane
				for (var view_UUID in this.objectWidget.viewWidgetList) {
					var view_widget=this.objectWidget.viewWidgetList[view_UUID];
					var viewTitle=view_widget.titleAsText;
					
					// refresh the view's contents
					view_widget.viewContentPane.refreshContents('actualise');
					var viewContent = dojo.clone(view_widget.viewContentPane.domNode.firstChild.innerHTML);
					
					content += '<div style="page-break-inside:avoid;">';
					content += '<h2>'+viewTitle+'</h2>';
					content += viewContent;
					content += '</div>';
				
				} // end for .. in
									
				application.printPreviewPane.addDocument(content,header,footer);
				
				// actualise the view, again
				view_widget.viewContentPane.refreshContents('actualise');
				
				// hide the animation
				application.sendToPrintQueuePane.hide();
				
			} // end of method onClick
			,
			style:"float:right;",
			'class':'RS_icon_SendToPrintQueue RS_MenuBarItem_withIcon'
		});
		
		this.menuBar.addChild(p);
		this.menuItems.push(p);
		
		// add all items to the object menu bar
		this.menuBarInfo=this.menuBarInfo.sort(function(a,b){return a.position-b.position;});
		dojo.forEach(this.menuBarInfo, function(menuItem){
			switch (menuItem.type) {
				case 'dijit.MenuBarItem': {
						var mIW = new dijit.MenuBarItem({label:menuItem.label,'itemKindUUID':menuItem.mB_itemKind_UUID});
						this.menuBar.addChild(mIW);
						dojo.connect(mIW,'onClick',this,function(e){
							application.O_menubar_itemKinds.itemKinds_asSlots[menuItem.mB_itemKind_UUID].JS_command(this.O_UUID,this._O_tabContainer_id);
						});
						this.menuItems.push(mIW);
					} break;
				case 'dijit.PopupMenuBarItem': {
						// iterate over all menu items and add the sub menu entries
						var menu = new dijit.Menu({});
						dojo.forEach(this.menuBarInfo, function(mi){
							if (mi.parent_UUID && (mi.parent_UUID==menuItem.UUID)) {
								var mIW = new dijit.menuItem({label:mi.label,'itemKindUUID':mi.mB_itemKind_UUID});
								menu.addChild(mIW);
								dojo.connect(mIW,'onClick',this,function(e){
									application.O_menubar_itemKinds.itemKinds_asSlots[menuItem.mB_itemKind_UUID].JS_command(this.O_UUID,this._O_tabContainer_id);
								});
								this.menuItems.push(mIW);
							} // end if
						}); // end for each
						this.menuBar.addChild(new dijit.PopupMenuBarItem({
							label:menuItem.label,
							menu:menu
						}));									
					} break;
				default: // do nothing, e.g. dijit.menuItem
			} // end switch
		},this); // end for each menu item
		
		// add the tab container for the views
		this.viewsContainerWidget = new dijit.layout.TabContainer({
			'region'	:'center',
			'id'		: this._O_tabContainer_id,
			'tabPosition':'right',
			'title'		:'',
			'label'		:''
		});
		this.addChild(this.viewsContainerWidget);
					
	} // end of internal method _createObjectWidget
	,
	'isInEditMode' : function () {
		var inEditMode = false;
		// iterate over all view panes and read isInEditMode
		for (VT_UUID in this.viewWidgetList) {
			inEditMode = inEditMode || this.viewWidgetList[VT_UUID].isInEditMode();
		} // end for ... in
		return(inEditMode);
	} // end-of-method isInEditMode
	,
	'disableOtherEditButtons' : function (viewPaneId) {
		
		// iterate over all view panes and disable their edit buttons
		for (VT_UUID in this.viewWidgetList) {
			this.viewWidgetList[VT_UUID].disableEditButton();
		} // end for ... in
		
		// block the delete button, if present
		dojo.forEach(this.menuItems,function(mIW){
			if (mIW.itemKindUUID=='O_menubar_itemKinds.general.delete') mIW.attr('disabled',true);
		},this); // end dojo.forEach
		
	} // end of method disableOtherEditButtons
	,
	'enableAllEditButtons' : function () {
		
		// iterate over all view panes and enable their edit buttons
		for (VT_UUID in this.viewWidgetList) {
			this.viewWidgetList[VT_UUID].enableEditButton();
		} // end for ... in
		
		// unblock the delete button, if present
		dojo.forEach(this.menuItems,function(mIW){
			if (mIW.itemKindUUID=='O_menubar_itemKinds.general.delete') mIW.attr('disabled',false);
		},this); // end dojo.forEach
		
	} // end of method enableAllEditButtons
	,
	'_createViewPanes' : function() {
	
		// add the views
		dojo.forEach( this.viewTypes, function(view) {
		
			// do nothing if view is invisible
			if (!view.visible) return;
			
			try {

				// let's add for each view a special pane
				this.viewWidgetList[view.UUID] = new application.widgets.ViewPane({
					'viewConfig'	: view,	
					'objectWidget'	: this,
				}).placeAt(this.viewsContainerWidget);
			
				this.connect( this.viewWidgetList[view.UUID], 'onSelect', '_viewSelected' );
			
			} catch(e) {
				console.error('application.widgets.ObjectWidget :: _createViewPanes');
				console.log('Error message', e);
				console.log(view);
				throw "Error in application.widgets.ObjectWidget :: _createViewPanes:\n\n"+e;
			
			} // end try .. catch
			
		}, this ); // end dojo.forEach view
	   	   
	} // end of internal method _createViewPanes
	,
	/*startup : function(){
	
		// If you need to be sure parsing and creation of any child widgets has completed, use startup. 
	   this.inherited(arguments);
	   
	} // end of method startup
	,*/
	'selectViewPane' : function (V_UUID) {
	
		if (V_UUID in this.viewWidgetList) try {
			var vP = this.viewWidgetList[V_UUID].widgets.viewContentPane;
			vP.refreshContents( 'actualise' );
			this.viewsContainerWidget.selectChild( this.viewWidgetList[V_UUID] );
		} catch(e) {
			console.log(e);
		} // end try ... catch
		
	} // end of method selectView
	,
	/*'destroy' : function() {
		//Implement destroy if you have special tear-down work to do (the superclasses will take care of most of it for you.
	   this.inherited(arguments);

	} // end of method destroy
	,*/
	'_toggleTag' : function (e){
		application.O.readList.toggleTaggedStatus(this.O_UUID);
		dojo.stopEvent(e);
	} // end of method _toggleTag
	,
	
	'_viewSelected' : function ( VT_UUID ) {

		// the following function needs to be defined locally to avoid bugs because of the changing scope
		var webClientHasLocalStorage= function () { // see http://diveintohtml5.info/storage.html
			try {
				return 'localStorage' in window && window['localStorage'] !== null;
			} catch (e) {
				return false;
			} // end try .. catch
		}; // end of local webClientHasLocalStorage
	
		if ( !application.webClientHasLocalStorage() ) return;
		
		// store the selected view type UUID
		localStorage.setItem( this.OT_UUID, dojo.toJson({
			'lastShownView' : VT_UUID,
		}) );
	
	} // end of method _viewSelected
	,
	
 }); // end widget declaration application.widgets.ObjectWidget
