<?php if (!defined('APPLICATION_started')) {header('Location: .');exit;}
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/
?>
 
<div dojoType="dijit.Dialog" id="application.Dialogs.O.close_objectNotPossible" title="Cannot close the current object - This will be overwritten, dynamically!" execute="void(false);">
	<div dojoType="dijit.form.Form" onSubmit="dijit.byId('application.Dialogs.O.close_objectNotPossible').hide();return false;" action="javascript:void(false);">
		<table style="min-width:400px; max-width: 800px;">
			<tbody>
				<tr>
					<td><img style="vertical-align:middle;" src="third_party_libraries/open-icon-library-standard-0.10/icons/png/64x64/status/dialog-warning-2.png"></td>
					<td>
						<p>
						<?php echo T('close_objectNP.dial.php/YouCannotClose_HTM', 'You cannot close $[0] because you are currently editing it.', array('<span id="application.Dialogs.O.close_objectNotPossible.O_name"></span>')); ?>
						 
						</p>
						<p><?php echo T('close_objectNP.dial.php/AccOrCncl_TXT', 'Accept or cancel your changes, first.'); ?></p>
					</td>
				</tr>
				<tr>
					<td valign="top" style="text-align:right;" colspan="2">
						<button dojoType="dijit.form.Button" type="submit">
							<?php echo T('BTN_OK', 'OK') ?>
						</button>
						<!-- <button dojoType="dijit.form.Button" type="button" onClick="dijit.byId('application.Dialogs.O.close_objectNotPossible').hide();">
							Cancel
						</button>-->
					</td>
				</tr>
			</tbody>
		</table>
	</div>
</div>	

