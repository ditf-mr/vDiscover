﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// register all available menu bar options and the corresponding code
dojo.addOnLoad(function(){

	with (application.O_menubar_itemKinds) { // here comes now the definition of the standard O_menubar_itemKinds
		/* TEMPLATE FOR NEW O_menubar_itemKinds 
		
		register({name: "",
			UUID: 		"",
			JS_command:	function (UUID, tabContainer) {
				application.general_functionality.show_tab( 
					'OT_descr'+UUID, 
					'Overview', 
					dijit.byId(tabContainer), 
					encodeURI('?v=OT_Overview&UUID='+UUID), 
					true // means to refresh on clicking on the tab title
				);
			} // end-of-method showOverview,
			description:""
		});
		
		*/

		register({	
			name			: T('FUT_Delete','Delete'),
			UUID			: "O_menubar_itemKinds.general.delete",
			addWhenCreating	: true,
			JS_command		: function ( UUID, O_tabContainer ) {
				// delete the object
				application.O_AJAX_query ( 
					{ 
						task: 'mDelete_O', UUID: UUID 
					}, 
					function(r,a) { // onSuccess
						var type_TabContainer = dijit.byId('OT_tC_' + r.OT_UUID);
						var objectWidget = dijit.byId(application.O.object_widget_prepend + r.O_v_UUID);
						if (type_TabContainer && objectWidget) 
							type_TabContainer.closeChild(objectWidget);
						// remove object Tab
						// var objectWidget = dijit.byId(application.O.object_widget_prepend + UUID);
						// objectWidget.destroyRecursive();
					} // end-of-function onSuccess 
				); // end-of-AJAX_query
			} // end-of-function "delete the object"
			,
			description		: "<p>" + T('registerMenuBarOptions.js/DelCurrInfObj_TXT','Delete the current information object.') + "</p>"
		}); // end-of-register "mDelete"
		
		register({
			name			: T('FUT_Duplicate','Duplicate'),
			UUID			: "O_menubar_itemKinds.general.duplicate",
			addWhenCreating : true,
			JS_command		: function ( UUID, O_tabContainer ) {
				// duplicate the object
				application.O_menubar_itemKinds.itemKinds_asSlots['O_menubar_itemKinds.general.duplicate'].start(UUID, O_tabContainer);
			}
			,
			description		: "<p>" + T('registerMenuBarOptions.js/MakeDuplicate','Makes a duplicate of the current object.') + "</p>",

			start : function ( UUID, O_tabContainer ) {
				// check if the name of the object is based on a template view
				application.O_AJAX_query( 
					{
						"task"	: "usesTemplateViewForName",
						"UUID"	: UUID
					},
					function(r,a) {
						if (! r) {
							// show edit dialogue
							dojo.byId('application.O.Dialogues.duplicate.UUID').value = UUID;
							
							application.O_AJAX_query( 
								{
									"task"	: "get_O_withOT",
									"UUID"	: UUID
								},
								function(r,a) {
									dojo.byId('application.O.Dialogues.duplicate.newName').value = r.object.name;
								}
							); // end-of OT_AJAX_query
							dijit.byId('application.O.Dialogues.duplicate').show();
						} else {
							// no need to show edit dialogue
							application.O_AJAX_query( 
								{ 
									"task"	: "duplicate_O", 
									"UUID"	: UUID 
								}, 
								application.O_menubar_itemKinds.itemKinds_asSlots['O_menubar_itemKinds.general.duplicate'].onSuccess
							);
						}
					}
				); // end-of OT_AJAX_query
			} // end-of-method start
			,
			execute : function () {
				dijit.byId('application.O.Dialogues.duplicate').hide();
				var UUID = dojo.byId('application.O.Dialogues.duplicate.UUID').value;
				var newName = dojo.byId('application.O.Dialogues.duplicate.newName').value;
				application.O_AJAX_query (
					{	
						"task"	: "duplicate_O",
						"UUID"	: UUID,
						"name"	: newName
					},
					application.O_menubar_itemKinds.itemKinds_asSlots['O_menubar_itemKinds.general.duplicate'].onSuccess
				);
			} // end-of-method execute
			,
			onSuccess : function (r, a) {
				// display new Object
				application.O.show(r.O_v_UUID);				
			} // end-of-method onSuccess
		}); // end-of-register "Duplicate"
		
		register({
			name			: T('FUT_Rename','Rename'),
			UUID			: "O_menubar_itemKinds.general.rename",
			addWhenCreating : true,
			JS_command		: function ( UUID, O_tabContainer ) {
				// rename the object
				application.O_menubar_itemKinds.itemKinds_asSlots['O_menubar_itemKinds.general.rename'].start(UUID, O_tabContainer);
			}
			,
			description:"<p>" + T('registerMenuBarOptions.js/RenameCurrObj_TXT','Renames the current object.') + "</p>",

			start : function ( UUID, O_tabContainer ) {
				// check if the name of the object is based on a template view
				application.O_AJAX_query( 
					{
						"task"	: "usesTemplateViewForName",
						"UUID"	: UUID
					},
					function(r,a) {
						if (! r) {
							// show edit dialogue
							dojo.byId('application.O.Dialogues.rename.UUID').value = UUID;
							
							application.O_AJAX_query( 
								{
									"task"	: "get_O_withOT",
									"UUID"	: UUID
								},
								function(r,a) {
									dojo.byId('application.O.Dialogues.rename.newName').value = r.object.name;
								}
							); // end-of OT_AJAX_query
							dijit.byId('application.O.Dialogues.rename').show();
						} else {
							// do nothing
							alert ( T('registerMenuBarOptions.js/ObjRenameAlert_TXT','Object cannot be renamed.') );
						}
					}
				); // end-of OT_AJAX_query
			} // end-of-method start
			,
			execute : function () {
				dijit.byId('application.O.Dialogues.rename').hide();
				var UUID = dojo.byId('application.O.Dialogues.rename.UUID').value;
				var newName = dojo.byId('application.O.Dialogues.rename.newName').value;
				application.O_AJAX_query (
					{	
						"task"	: "set_O_name",
						"UUID"	: UUID,
						"name"	: newName
					},
					application.O_menubar_itemKinds.itemKinds_asSlots['O_menubar_itemKinds.general.rename'].onSuccess
				);
			} // end-of-method execute
			,
			onSuccess : function (r, a) {
				// display new Object
				application.O.updateName(r.O_v_UUID, r.name);
			} // end-of-method onSuccess
		}); // end-of-register "Rename"
		
	}; // end-of-with
}); // end dojo.addOnLoad
