﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

application.O = {
	// all methods that have do do with a specific information object go here
	
	// objNameToolTipWidget :  new common.widgets.Tooltip({
		// label: "<p>Click here to tag or untag this object.</p><p>Drag this link to another application or to your favorites bar.</p>",
		// position: ['above']
	// }),
	object_widget_prepend : 'O_',
	object_tabContainer_prepend : 'O_tC_',
	type_tabContainer_prepend: 'OT_tC_',
	object_name_prepend : 'O_n_',
	object_name_prependInner : 'O_nI_',
	object_namePane_prepend : 'O_n_',
	object_NameTag_id :'_objNameTagPosition',
	
	'show' : function(O_v_UUID, viewPane_V_UUID) {

		if (! O_v_UUID || ! dojo.isString(O_v_UUID)) {
			application.showErrorMessage(
				"<p>Called application.O.show() without passing an Object UUID.</p>"+
				"<p>Received Object UUID: « <code>"+dojo.toJson(O_v_UUID)+"</code>» </p>"+
				"<p>Aborting.</p>"
			);
			return;
		} // end if

		if (!viewPane_V_UUID) viewPane_V_UUID='';
		
		// this method displays an object. If necessary, it opens the corresponding type tab, as well.
		application.O_AJAX_query(
			{
				"task"		: "get_O_withOT", 
				"O_v_UUID"	: O_v_UUID,
				'viewPane_V_UUID'	: viewPane_V_UUID
			}, 
			function(r,a){ // onSuccess method

				try {
					// show the object type tab
					application.OT.show(r.objectType.OT_UUID/*, r.objectType.name, r.objectType.menuBarOT*/);

					// show the object tab
					
					// these variables should be defined via tab.attr('')
					
					var OT_tabContainer_id = application.O.type_tabContainer_prepend + r.objectType.OT_UUID;
					var O_tab_id = application.O.object_widget_prepend + r.object.O_v_UUID; 
					var O_tabContainer_id = application.O.object_tabContainer_prepend + r.object.O_v_UUID; 
					var O_name_id = application.O.object_name_prepend + r.object.UUID;
					
					var tab = null;
					// test if the object tab does already exist -- if not, create it
					if (! (tab=dijit.byId(O_tab_id))) {
					
						// create a new tab
						tab = new application.widgets.ObjectWidget({
							'O_UUID':		r.object.O_v_UUID,
							'OT_UUID':		r.objectType.OT_UUID,
							'objName':		r.object.name,
							'menuBarInfo':	r.objectType.menuBarO,
							'viewTypes':	r.object.viewTypes,
							'eqSystem':		r.objectType.equationSystem
						});

						// add the tab to the object tab container
						dijit.byId(OT_tabContainer_id).addChild(tab);

					} // end if create new tab necessary
					
					// focus the specified view pane, if it was passed ... or choose the last locally stored one
					var focusOnViewPane = a.args.content.viewPane_V_UUID;
					
					// the following function needs to be defined locally to avoid bugs because of the changing scope
					var webClientHasLocalStorage= function () { // see http://diveintohtml5.info/storage.html
						try {
							return 'localStorage' in window && window['localStorage'] !== null;
						} catch (e) {
							return false;
						} // end try .. catch
					}; // end of local webClientHasLocalStorage
	
					if(!focusOnViewPane && webClientHasLocalStorage() ) {
						// try to recover the view type UUID to show from localStorage
						var OTinfo = localStorage.getItem( r.objectType.OT_UUID );
						if (typeof OTinfo == 'string') OTinfo = dojo.fromJson(OTinfo);
						if (OTinfo && OTinfo.lastShownView) focusOnViewPane = OTinfo.lastShownView;
					} // end if
					
					if(focusOnViewPane) tab.selectViewPane(focusOnViewPane);

					// add the object to the list of read objects
					var OT_menuBar = r.objectType.menuBarOT;
					if(!(typeof OT_menuBar=='string')) OT_menuBar=dojo.toJson(OT_menuBar);
					
					application.O.readList.add(O_v_UUID, r.object.name, r.objectType.OT_UUID, r.objectType.name, OT_menuBar);
					
					// show/ focus the object tab
					dijit.byId(OT_tabContainer_id).selectChild(O_tab_id); 				
				
				} catch(e) {
					console.error(e);
					dojo.require('dojox.html.entities');
					application.showErrorMessage( ''
						+'<h2>Application error</h2>'
						+'<p>Location: application.O.show(...) AFTER executing the server query</p>'
						+'<p>Error: <code>'+e+'</code>'
						+'<p>The response from the server:</p>'
						+'<pre class="small">'+dojox.html.entities.encode(dojo.toJson(r,true))+'</pre>'
					);
				} // end try ... catch
			} // end of onSuccess method
		); // end AJAX query
	} // end of method show
	,	
	'showView': function ( O_UUID, VT_UUID ) {
	
		var view_tab_id = 'VT_' + VT_UUID + '_of_' + O_UUID;	

		if( dijit.byId( view_tab_id ) ){
			application.O_AJAX_query( 
				{ task: 'get_O_view', UUID: O_UUID, VT_UUID:VT_UUID }, 
				function(r,a){ // onSuccess method
					// create O tab
					var view_tab_id = 'VT_' + r.viewType.UUID + '_of_' + O_UUID;	
					var widget = dijit.byId(view_tab_id);
					widget.destroyRecursive(false/*destroy DOM, as well*/);
					dojo.empty(widget.domNode);
					widget.set('content', application.viewKinds.viewKindList[r.viewType.kind].buildContent(O_UUID,r));
				} // end of onSuccess method
			); // end AJAX query

			// clear current editing status 
			application.O.manageAttributeValues.clearCache();
		}
	
	}	// end-of-method showView
	,
	updateName : function(O_UUID,newName){
	
		var o_widget = dijit.byId('O_'+O_UUID);
		
		// if the object widget exists: update the name
		if(o_widget) {
			// update the title of the object's content pane
			o_widget.attr('title', newName);
			
			// update the name in the top content pane of the object's widget
			var O_name_id = application.O.object_name_prependInner + O_UUID;
			dojo.attr(O_name_id,'innerHTML',newName);
		} // end if
		
		// if the object is on the readList, update its name
		application.O.readList.updateName(O_UUID,newName);
		
	}// end of method updateName
	
}; // end of object definition application.O

