﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare('application.widgets.ViewPane', [dijit.layout.BorderContainer], {

	// these parameters need to be passed on instantiation
	'viewConfig' 	: null,
	'objectWidget' 	: null,
	
	
	// dijit.layout.BorderContainer configuration
	'closable'			: false,
	'gutters'			: false,
	
	
	// widget life cycle ####################################################################
	'constructor' : function () {

		// initialisations
		this.widgets = {};
		this.menuBarItems = {};
		this.tagMenuItems = {};
		
	} // end of method constructor
	,
	'postMixInProperties' : function () {
		this.inherited(arguments);
	
		// validate if everything was passed, correctly, on instantiation
		if (	!typeof this.viewConfig == 'object') throw this.declaredClass+'::postMixInProperties()\nNo slot \'viewConfig\' of type object passed on instantiation. Aborting.';
		if (		!this.objectWidget 
				|| 	!('declaredClass' in this.objectWidget) 
				||	!(this.objectWidget.declaredClass == 'application.widgets.ObjectWidget')
			) throw this.declaredClass+'::postMixInProperties()\nNo slot \'objectWidget\' of type \'application.widgets.ObjectWidget\' passed on instantiation. Aborting.';
		
		// carry out all necessary settings
		this.titleAsText =this.viewConfig.name;
		this.title = '<span class="RS_TabLabel_withoutIcon">'+this.titleAsText+'</span>';
	
		this.O_UUID = this.objectWidget.O_UUID;
	
		if (this.viewConfig.eqSolverIsActive) {
			if (!this.viewConfig.eqSolverJSONConfig.length) this.viewConfig.eqSolverJSONConfig='{}';
			try {
				this.viewConfig.eqSolverConfig = dojo.fromJson(this.viewConfig.eqSolverJSONConfig);
			} catch (e) {
				console.error('Problems while unserialising JSON string \''+this.viewConfig.eqSolverJSONConfig+'\'');
				throw e;
			} // end try ... catch
		} // end if 
		
	} // end of method postMixInProperties
	,
	'postCreate' : function () {
		this.inherited(arguments);
	
		// create the menu bar for the view pane
		this.widgets.menuBar = new dijit.MenuBar({
			'region': 'top',
			'class'	: 'output_DIN_A4',
			'style'	: 'border-top:0;border-right:0;border-left:0;padding-left:.25em;'				
		});
		this.addChild(this.widgets.menuBar);
		
		// menu bar items for read and edit mode
		this.createMenuBarItems_forReadMode();
		
		// menu bar items for the edit mode, only
		if ( !this.viewConfig.readOnly ) this.createMenuBarItems_forEditMode();
		
		// set up the view content pane
		this.widgets.viewContentPane = application.viewKinds.viewKindList[this.viewConfig.kind].createWidget({
			'objectWidget'	: this.objectWidget,
			'viewPane'		: this,
		});
		this.addChild(this.widgets.viewContentPane);
		
	} // end of method postCreate
	,
	'startup' : function () {
		this.inherited(arguments);
		
		this.connect( this, 'onShow', 'refreshContents');
	} // end of method startup
	,
	'destroy' : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		
		for (var i in this.widgets) {
			if (this.widgets[i].destroyRecursive) try{
				this.widgets[i].destroyRecursive();
			} catch(e) {
				console.error('Problem in '+this.declaredClass+'::destroy():\nWhen trying to delete subwidget "'+i+'", the following error was thrown:');
				console.error(e);
				console.log('this', this);
				console.log('this.widgets[i]', this.widgets[i]);
				dijit.registry.remove(this.widgets[i].id);
			} // end if .. try
			delete this.widgets[i];
		} // end for .. in
		
		for (var i in this.menuBarItems) {
			if (this.menuBarItems[i].destroyRecursive) try{
				this.menuBarItems[i].destroyRecursive();
			} catch(e) {
				console.error('Problem in '+this.declaredClass+'::destroy():\nWhen trying to delete subwidget "'+i+'", the following error was thrown:');
				console.error(e);
				console.log('this', this);
				console.log('this.menuBarItems[i]', this.menuBarItems[i]);
				dijit.registry.remove(this.menuBarItems[i].id);
			} // end if .. try
			delete this.menuBarItems[i];
		} // end for .. in
		
		this.inherited(arguments);
	} // end of method destroy
	,
	
	
	// helper functions for setting up the menu bar #############################################
	'createMenuBarItems_forReadMode' : function () {
	
		// the Print menu item
		this.menuBarItems.printViewContents = new dijit.MenuBarItem({
			'title'			: T('app.wid.ViewPane.js/AddViewToPrintQ_TXT','Add this view to the print queue'),
			'style'			: "float:right;",
			'class'			: 'RS_icon_SendToPrintQueue RS_MenuBarItem_withIcon',
		});
		this.widgets.menuBar.addChild(this.menuBarItems.printViewContents);			
		this.connect(this.menuBarItems.printViewContents, 'onClick', 'sendContentsToPrintQueue');
	
		// the view name 
		this.viewName_domNode = dojo.create('A', {
			'innerHTML'	: this.viewConfig.name, 
			'href'		: '?jumpTo=O&O_v_UUID='+this.objectWidget.O_UUID+'&V_UUID='+this.viewConfig.UUID,
			'class'		: 'h2',
			'title'		: T('app.wid.ViewPane.js/DragLink_TXT','You may drag this link to another application or to your favorites bar.'),
			'style'		: 'text-decoration:none;',
			'onclick'	: function(e){ // do nothing
				dojo.stopEvent(e);
				return false;
			} // end of method onclick
		} ,this.widgets.menuBar.domNode);
		
		// the refresh button
		this.menuBarItems.refreshButton = dojo.create('SPAN',{
			'class'		: 'RS_clickableIcon RS_icon_refresh_small',
			'style'		: 'cursor:hand;margin-bottom:.5ex;margin-left:.33em;vertical-align:bottom;',
			    'title'		: T('app.wid.ViewPane.js/Refresh_TXT','Refresh from server'),
		}, this.widgets.menuBar.domNode);
		this.connect(this.menuBarItems.refreshButton, 'onclick', 'refreshContents');
				
	} // end of method createMenuBarItems_forReadMode
	,
	'createMenuBarItems_forEditMode' : function () {
	
		// add the Cancel menu item
		this.menuBarItems.editing_Cancel = new dijit.MenuBarItem({
			'label'	: T('MNU_Cancel','Cancel'),
			'title'	: T('app.wid.ViewPane.js/discardChanges_TTP','Click here to discard your changes.'),
			'style'	: 'float:right;display:none;',
			'class'	: 'RS_icon_Cancel RS_MenuBarItem_withIcon',
		});
		this.widgets.menuBar.addChild(this.menuBarItems.editing_Cancel);
		this.connect(this.menuBarItems.editing_Cancel, 'onClick', 'finishEditing');
				
		// add ok menu item
		this.menuBarItems.editing_Ok = new dijit.MenuBarItem({
			'label'	: T('MNU_OK','OK'),
			'title'	: T('app.wid.ViewPane.js/storeChangedVC_TTP','Click here to store the changed view contents.'),
			'style'	: 'float:right;display:none;',
			'class'	: 'RS_icon_OkApply RS_MenuBarItem_withIcon'
		});
		this.widgets.menuBar.addChild(this.menuBarItems.editing_Ok);
		this.connect( this.menuBarItems.editing_Ok, 'onClick', 'saveChanges' );
		
		// add an equation solver menu item (if necessary)
		if(		(this.viewConfig.eqSolverIsActive)
			&&	('eqSolverConfig' in this.viewConfig)
			&&	('attrVarTable' in this.viewConfig.eqSolverConfig)
			&&	(Object.keys(this.viewConfig.eqSolverConfig.attrVarTable).length)
			) {
			
			this.widgets.eQSolverMenu = new dijit.Menu({});
			
			for (var varGroupName in this.viewConfig.eqSolverConfig.varGroups) {
				var label = T('app.wid.ViewPane.js/SetGroupNameConst_HTM','Set « <strong>$[0]</strong>»  constant',[varGroupName]),
					n = '_eqSolver_varGroupPrepend'+varGroupName,
					w = this.widgets[n] =
							new dijit.MenuItem({
								'varGroup' 		: varGroupName,
								'label' 		: label,
								'viewPaneWidget': this,
								'onClick' 		: function (e) {
									this.viewPaneWidget.setAttrsInVarGroupConstant(this.varGroup);
									dojo.stopEvent(e);
								}, // end of method onClick
							});
				this.widgets.eQSolverMenu.addChild(w);	
			} // end for .. in
			
			// add a menu item for removing all constant checks
			this.widgets.removeConst = dijit.MenuItem({
				'label' 		: T('app.wid.ViewPane.js/setEveryAttrValVar_MNU','Set every attribute value <strong>variable</strong>'),
				'viewPaneWidget': this,
				'onClick' 		: function (e) {
					this.viewPaneWidget.setAttrsInVarGroupConstant('');
					dojo.stopEvent(e);
				}, // end of method onClick
			});
			this.widgets.eQSolverMenu.addChild(this.widgets.removeConst);
			
			// add a ################### line to the drop down menu
			this.widgets.MenuSeparator = new dijit.MenuSeparator({});
			this.widgets.eQSolverMenu.addChild(this.widgets.MenuSeparator);
			
			// add the "Solve" menu item
			this.widgets.solveMI = dijit.MenuItem({
				'label' 		: T('app.wid.ViewPane.js/SolveCalcDepVar_MNU','<strong>Solve</strong> &rarr; Calculate dependent values'),
				'class'			: 'RS_icon_EstimateDependencies RS_DropDownMenuItem_withIcon',
			});
			this.widgets.eQSolverMenu.addChild(this.widgets.solveMI);
			this.connect(this.widgets.solveMI, 'onClick', 'solve');
			
			// add the "Solve with debug output" menu item
			this.widgets.solveWithDebugOutputMI = dijit.MenuItem({
				'label' 		: T('app.wid.ViewPane.js/SolveShowDebug_MNU','<strong>Solve</strong> and show debug output'),
				'class'			: 'RS_icon_EstimateDependencies RS_DropDownMenuItem_withIcon',
			});
			this.widgets.eQSolverMenu.addChild(this.widgets.solveWithDebugOutputMI);
			this.connect(this.widgets.solveWithDebugOutputMI, 'onClick', 'solveWithDebugOutput');
			
			// set up the popup menu bar item
			this.menuBarItems.eqSolver = new dijit.PopupMenuBarItem({
				'label'	: '…',
				'title'	: T('app.wid.ViewPane.js/SetGroupsOfAttrConst_TTP','Set groups of attributes constant, execute the equation solver …'),
				'class'	: 'RS_icon_mathematics RS_MenuBarItem_withIcon',
				'style'	: 'float:right;display:none;',
				'popup'	: this.widgets.eQSolverMenu,
			}).placeAt(/*this.menuBarItems.eqSolver*/this.widgets.menuBar);

		} // end of if  eqSolverIsActive
		
		
		// add a CBR menu item (if necessary)
		if(		(this.viewConfig.CBRIsActive)
			&&	('CBRJSONConfig' in this.viewConfig)
			) {
				this.menuBarItems.CBR = new dijit.MenuBarItem({
					'label'	: T('app.wid.ViewPane.js/CBR_MNU','CBR'),
					'title'	: T('app.wid.ViewPane.js/CBR_TIT','Adapt unknown values by using values similar from similar objects with case-based reasoning (CBR).'),
					'style'	: 'float:right;display:none;',
					'class'	: 'RS_icon_EstimateDependencies RS_MenuBarItem_withIcon',
				}).placeAt(this.widgets.menuBar);
				this.connect( this.menuBarItems.CBR, 'onClick', 'callCBR' );
		} // end if CBR menu item necessary
		
		
		// add plug-ins to the view menu bar
		if(		application.plugins.view[this.viewConfig.UUID] 
			&& 	application.plugins.view[this.viewConfig.UUID].menuBar 
			&& 	application.plugins.view[this.viewConfig.UUID].menuBar.editMode	) {
			
			// create the menu bar item for the view plug-in
			var viewPlugin 	= application.plugins.view[this.viewConfig.UUID].menuBar.editMode,
				mBI_UUID 	= this.viewConfig.UUID+'_'+viewPlugin.title;
				
			this.menuBarItems[mBI_UUID] = new dijit.MenuBarItem({
				'viewPane'		: this,
				'label'			: viewPlugin.label,
				'title'			: viewPlugin.title,
				'objectWidget'	: this.objectWidget,
				'viewType_UUID' : this.viewConfig.UUID,
				'onClick'		: function(e){
					// call the plug-in and pass all necessary information to it
					application.plugins.view[this.viewType_UUID].menuBar.editMode.onClick(this.objectWidget,this.viewPane);
					dojo.stopEvent(e);
				},
				'style'			: "float:right;",
				'disabled'		: false
			});
			
			// add the menu item for the plug-in to the menu bar
			this.widgets.menuBar.addChild(this.menuBarItems[mBI_UUID]);
			
		} // end if 

		// add the "edit" menu item
		this.menuBarItems.editMenuItem = new dijit.MenuBarItem({
			'label'			: T('MNU_Edit','Edit'),
			'title'			: T('app.wid.ViewPane.js/ClickToEdit_TTP','Click here to edit the contents of this view.'),
			'style'			: 'float:right;',
			'class'			: 'RS_icon_Edit RS_MenuBarItem_withIcon',
		});
		this.widgets.menuBar.addChild(this.menuBarItems.editMenuItem);
		this.connect(this.menuBarItems.editMenuItem, 'onClick', 'startEditing' );

		// create the tag list
		this.menuBarItems.tagDropDown = new dijit.PopupMenuBarItem({
			'label'	: '<span class="RS_attribute_highlight RS_highlight_menuBarMarker dijitMenuBar"></span> …',
			'title'	: T('app.wid.ViewPane.js/ChooseATagTo_TTP','Choose a tag to HIGHLIGHT the corresponding attributes.'),
			'class'	: 'RS_icon_highlight RS_MenuBarItem_withIcon',
			'style'	: 'float:right;',
			'popup'	: new dijit.Menu({})
		});
		this.widgets.menuBar.addChild(this.menuBarItems.tagDropDown);
		
		this.widgets.highlightNone = new dijit.MenuItem({
			'label' 	: T('app.wid.ViewPane.js/RemHighL','Remove highlighting'),
			'viewPane'	: this,
			'onClick'	: function (e) {
				dojo.stopEvent(e);
				this.viewPane.highlight('');
			} // end of method onClick
		});
		this.menuBarItems.tagDropDown.popup.addChild(this.widgets.highlightNone);
		
	} // end of method createMenuBarItems_forEditMode
	,
	
	
	
	
	// the following methods handle events #############################################################
	'startEditing'		: function () {
	
		// show ok and cancel menu item
		dojo.style(this.menuBarItems.editing_Cancel.domNode,	'display', 'block');
		dojo.style(this.menuBarItems.editing_Ok.domNode,		'display', 'block');
		
		if (this.menuBarItems.eqSolver) 
			dojo.style(this.menuBarItems.eqSolver.domNode,		'display', 'block');
		if (this.menuBarItems.CBR) 
			dojo.style(this.menuBarItems.CBR.domNode,			'display', 'block');
		
		// hide the refresh button
		dojo.style(this.menuBarItems.refreshButton, 			'display', 'none');
		
		// hide this menu item
		dojo.style(this.menuBarItems.editMenuItem.domNode,		'display', 'none');
		
		// hide all other edit buttons
		this.objectWidget.tabInEditMode = this.viewPaneId;
		this.objectWidget.disableOtherEditButtons(this.viewPaneId);
		
		this.attr('title', '<span class="RS_icon_Edit RS_TabLabel_withIcon">'+this.titleAsText+'</span>');
		dojo.attr(this.domNode,'title',''); // display bug fix
		
		this.widgets.viewContentPane.refreshContents('activateEditMode');
		
	} // end of method startEditing
	,
	'finishEditing'		: function (e) {
		if (e) dojo.stopEvent(e);
	
		dojo.style( this.menuBarItems.editMenuItem.domNode,		'display', 'block');				
		dojo.style( this.menuBarItems.editing_Cancel.domNode,	'display', 'none');
		dojo.style( this.menuBarItems.editing_Ok.domNode,		'display', 'none');
		
		if (this.menuBarItems.eqSolver) 
			dojo.style(this.menuBarItems.eqSolver.domNode,		'display', 'none');
		if (this.menuBarItems.CBR) 
			dojo.style(this.menuBarItems.CBR.domNode,			'display', 'none');
		
		// show the refresh button
		dojo.style(this.menuBarItems.refreshButton, 			'display', 'inline-block');
		
		// enable all edit buttons of the other view tabs, again
		this.objectWidget.tabInEditMode = null;
		this.objectWidget.enableAllEditButtons();	
	
		this.attr('title', '<span class="RS_TabLabel_withoutIcon">'+this.titleAsText+'</span>');
		dojo.attr(this.domNode,'title',''); // display bug fix
		
		this.widgets.viewContentPane.refreshContents('switchToReadMode');
		
	} // end of method finishEditing
	,
	'isInEditMode' : function () {
		if (typeof this.widgets.viewContentPane == "undefined") {
			return(false);
		}
		return(this.widgets.viewContentPane.edit);
	} // end-of-method isInEditMode
	,
	'sendContentsToPrintQueue' : function (e) {
		dojo.stopEvent(e);
	
		// show the print queue animation
		application.sendToPrintQueuePane.show();
	
		// get the view content and send it to the print queue
		var doc = dojo.clone(this.widgets.viewContentPane.domNode.firstChild/*.innerHTML*/);
		var header=''
			+"<span class='h1'>"
				+this.objectWidget.objName
			+"</span>"
			+"&nbsp;<span class='h2'>"
				+'» &nbsp;'
				+this.titleAsText
			+'</span>';
		var footer=''
			+'<p class="small textCenter">'
				+window.document.title
				+'&nbsp;'
				+dojo.date.locale.format(new Date())
			+'</p>';
		application.printPreviewPane.addDocument( doc, header, footer );
		
		// actualise the view, again
		this.widgets.viewContentPane.refreshContents('actualise');
	
		// hide the print queue animation
		application.sendToPrintQueuePane.hide();
		
	} // end of method sendContentsToPrintQueue
	,
	'saveChanges' : function (e) {
	
		// save changes and leave the edit mode
		if( this.widgets.viewContentPane.saveChanges() ) this.finishEditing(e);
		
	} // end of method saveChanges
	,
	'refreshContents' : function (e) {
		if (e) dojo.stopEvent(e);
		this.widgets.viewContentPane.refreshContents('actualise');
		
		// trigger an event to tell the object widget that this view was selected
		this.onSelect( this.viewConfig.UUID );
		
	} // end of method refresh
	,
	'refreshTagList' : function (attrList) {
		
		// empty the existing tag list
		for (var t in this.tagMenuItems) {
			var mI = this.tagMenuItems[t];
			this.menuBarItems.tagDropDown.popup.removeChild(mI);
			mI.destroy();
			delete this.tagMenuItems[t];
		}; // end for ... in
		
		// create a menu item for each tag
		for (var A_UUID in attrList) {
			var tags = attrList[A_UUID].attribute.tags; // type: array
			if (tags.length) {
				dojo.forEach(tags, function (t) {				
					if(!(t in this.tagMenuItems)) {
						this.tagMenuItems[t] = new dijit.MenuItem({
							'label'		: t,
							'viewPane'	: this,
							'onClick' : function (e) {
								dojo.stopEvent(e);
								this.viewPane.highlight(this.attr('label'));
							} // end of method onClick
						});
						this.menuBarItems.tagDropDown.popup.addChild(this.tagMenuItems[t]);
					} // end if
				}, this); // end dojo.forEach
			} // end if
		}// end for .. in
		
		// no tags? hide the dropDown menu
		if ('tagDropDown' in this.menuBarItems) 
			dojo.style(this.menuBarItems.tagDropDown.domNode, 'display', 
				(Object.keys(this.tagMenuItems).length?'block':'none')
			);
		
	} // end of method refreshTagList
	,
	'highlight' : function (T_UUID) {
		this.widgets.viewContentPane.highlightTaggedAttributes(T_UUID);
	} // end of method highlight
	,
	'enableEditButton' : function () {
		if (this.menuBarItems.editMenuItem) this.menuBarItems.editMenuItem.attr('disabled', false);
	} // end of method enableEditButton
	,
	'disableEditButton' : function () {
		if (this.menuBarItems.editMenuItem) this.menuBarItems.editMenuItem.attr('disabled', true);
	} // end of method
	,
	'setAttrsInVarGroupConstant' : function (varGroupName) {
		this.widgets.viewContentPane.setAttrsInVarGroupConstant(varGroupName);
	} // end of method setAttrsInVarGroupConstant
	,
	'solve' : function (e) {
		this.widgets.viewContentPane.executeSolver();
		dojo.stopEvent(e);
	} // end of method solve
	,
	'solveWithDebugOutput' : function (e) {
		this.widgets.viewContentPane.executeSolver('debug');
		dojo.stopEvent(e);
	} // end of method solveWithDebugOutput
	,
	'callCBR' : function (e) {
		dojo.stopEvent(e);
		
		var CBRConfig	= dojo.fromJson(this.viewConfig.CBRJSONConfig),
			v			= this.widgets.viewContentPane;
		
		// prepare the CBR query
		var CBRQuery = {
			'OT_UUID'							: this.viewConfig.ORT_UUID,
			'O_v_UUID'							: this.O_UUID,
			'VT_UUID'							: this.viewConfig.VT_UUID,
			'CBRConfig'							: CBRConfig,
			'valsForIdentifyingSimilarCases'	: {},
			'valsForSimilarityAssessment'		: {},
		};
		
		var everythingValid = true;
		
		// identify values for identifying similar cases
		dojo.forEach(CBRConfig.attrsForIdentifyingSimilarCases, function (A_UUID) {
			var aW = v.attributeWidgetList[A_UUID];
			everythingValid = 		everythingValid 
								&&	aW.isValid();
			CBRQuery.valsForIdentifyingSimilarCases[A_UUID] = aW.getChangedTupleSet('cleaned');
		}, this); // end dojo.forEach
		
		// identify values for similarity assessment
		dojo.forEach(CBRConfig.influenceMatrix, function (IS) {
			var d = IS.dependencies;
			for (var A_UUID in d) {
				var aW = v.attributeWidgetList[A_UUID];
				everythingValid = 		everythingValid 
									&&	aW.isValid();
				var vTSet = aW.getChangedTupleSet('cleaned');
				CBRQuery.valsForSimilarityAssessment[A_UUID] = vTSet[ Object.keys(vTSet)[0] ];
			} // end for .. in
		}, this); // end dojo.forEach
		
		// verify if everything is complete
		if(!everythingValid) return;
		
		// alert ( 'Query #####################################\n'+dojo.toJson(CBRQuery, true));
		
		// send the query to the server
		loader.show();
		application.O_AJAX_query({
				'task'				: 'get_O_CBREstimations',
				'OT_UUID'			: this.viewConfig.ORT_UUID,
				'O_v_UUID'			: this.O_UUID,
				'VT_UUID'			: this.viewConfig.VT_UUID,
				'CBRQuery'			: dojo.toJson(CBRQuery),
				'scope'				: this,
			}, 
			function(qResult, q) {
				q.args.content.scope.adaptWithCBRResults(qResult);
			},  // end result function
			true /* synchronously */
		);
		loader.hide();
	} // end of method callCBR
	,
	'adaptWithCBRResults' : function (qResult) {
		// alert( 'Result of get_O_CBREstimations ######\n'+dojo.toJson(qResult,true));
		
		// iterate over the passed A_UUIDS and assign the values to the corresponding attribute widgets
		for (var A_UUID in qResult) {
			var vTSet 	= qResult[A_UUID],
				v		= this.widgets.viewContentPane,
				aW		= v.attributeWidgetList[A_UUID];
			
			// get the VT and assign it to the corresponding attribute widget
			var vT		= vTSet[ Object.keys(vTSet)[0] ];
			
			aW.setValueTuple(null, vT);
			
		} // end for ... in
		
		
	} // end of method adaptWithCBRResults
	,
	
	
	// Events ######################################################################
	'onSelect' : function ( VT_UUID ) {},
});
