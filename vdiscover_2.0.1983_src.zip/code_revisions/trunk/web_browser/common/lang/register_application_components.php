<?php if (!defined('APPLICATION_started')) {header('Location: .');exit;} 
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// this file registers all multilanguage components
global $backend;
$r->set_configOption('locale', $backend->currentLocale());
$r->register_JavaScriptFile('common/lang/lang.js');
?>