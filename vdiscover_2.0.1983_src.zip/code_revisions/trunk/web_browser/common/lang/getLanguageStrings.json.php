<?php 
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

{ # check if application is started correctly

    if ( ! defined('APPLICATION_started') or ! $repository_config ) {
        header('Location: ../../../..');
        exit;
    }
}

{ # start http output -- mimeType=application/json
    header('Content-type: application/json');
}

try { 
    //Object $translations from class cTranslations
   global $translations;
   
    {# get the Key=>Translation Array for the current language
	
		// was a language code passed? --> select the new lang code
		$newLangCode = sanitize_string($_POST, 'langCode', $_GET);	
		if($newLangCode) $translations->selectLanguage($newLangCode);
		$langStrings = $translations->getLanguageStrings();
		
    }
	
	
    $langJSONArray = array();
	{ # prepare the output
            # convert PHP-Array into JSON-Output
            if ($langStrings) {
				reset($langStrings);
				while( list($key, $value) = each($langStrings) ) {
				   $langJSONArray[] = array (
					   'key'   		=> $key,
					   'translation'=> $value
				   );
				}
			}
            $output = array(
                    // the structure is taken from http://livedocs.dojotoolkit.org/dojo/data/ItemFileReadStore and http://dojotoolkit.org/reference-guide/dojo/data/ItemFileWriteStore.html
                    'label'     => 'translation', // Optional attribute used to indicate which attribute on an item should act as a human-readable label for display purposes.
                    'identifier'=> 'key', // Optional attribute used to indicate which attribute on an item acts as a unique identifier for that item. If it is not defined, then the ItemFileReadStore will simply number the items and use that number as a unique index to the item.
                    'items'     => $langJSONArray
            );
		
	}
        # return the Array $output in JSON-notation to JavaScript
	echo json_encode($output);
} // end try {...}


# Error handling...
catch (Exception $e) {
	header('HTTP/1.1 500 Internal Server Error');
	$GLOBALS['logHandler']->log($e);
	echo json_encode(array(
		'type'		=> 'Exception',
		'message'	=> $e->getMessage(),
		'code'		=> $e->getCode(),
		'file'		=> $e->getFile(),
		'line'		=> $e->getLine(),
		'trace'		=> $e->getTraceAsString()
	));
} # end-of-trycatch

?>