/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.addOnLoad(function(){loader.hide();});
