/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.require("dijit.Tooltip");
dojo.declare("common.widgets.Tooltip", [dijit.Tooltip], {
  _onFocus: function(/*Event*/ e){
    this.inherited(arguments);
    this._focus = false;
  } // end of method _onFocus
});
// dojo.provide("common.widgets.Tooltip");
