/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare('common.widgets.printableContent', [dijit._Widget, dijit._Templated], {
	'templateString'	: ''
		+'<div class="output_DIN_A4" style="display:block;margin-left:auto;margin-right:auto;padding-right:0;padding-top:0;">'
			+'<div title="' + T('commWidPrintableCont.js/SendToPrintQueue_TXT', 'Click here to send this document to the print queue.') + '" dojoAttachEvent="onclick:_printButton_clicked" dojoAttachPoint="printIconNode" '
				+'style="border:0.1ex solid #E6E6E6;border-right:0;border-radius:1ex;border-top-right-radius:0;border-bottom-right-radius:0;display: inline-block;float: right;margin-bottom: 1ex;margin-left: 1ex;padding-bottom: 1ex;    padding-left: 1ex;" class="RS_icon_SendToPrintQueue RS_MenuBarItem_withIcon">'
			+'</div>'
			+'<div dojoAttachPoint="containerNode" style="padding-right:.5ex;padding-top:.5ex;">'
			+'</div>'
		+'</div>',
	'content'			: '',
	'add'		: function (c, position) {
		// valid values for position:
		//	* "before"	-- after this.containerNode
		//	* "after"	-- before this.containerNode
		//	* "replace"	-- replaces this.containerNode
		//	* "only"	-- as only content of this.containerNode
		//	* "first"	-- before the content of this.containerNode
		//	* "last"	-- after the content of this.containerNode (default value)
		if (typeof position=="undefined") position = 'last';
		dojo.place(c, this.containerNode, position);
	
	} // end of method addContent
	,
	'header' : ''
	,
	'footer' : ''
	,
	'_printButton_clicked' : function (e) {
		dojo.stopEvent(e);

		// show the animation
		application.sendToPrintQueuePane.show();
		
		try{
			// get the content
			var content = ''
				+'<div style="page-break-inside:avoid;">'
					// +dojo.clone(this.containerNode.innerHTML)
					+this.containerNode.innerHTML
				+'</div>';
			
			// send the content to the print queue
			application.printPreviewPane.addDocument( content, this.header, this.footer );
		} catch (e) {
			console.error(e);
		} // end try .. catch

		// hide the animation
		application.sendToPrintQueuePane.hide();
		
	} // end of method printButton_clicked
	,
});
