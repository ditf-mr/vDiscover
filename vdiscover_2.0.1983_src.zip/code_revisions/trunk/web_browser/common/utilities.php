<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

if (!defined('APPLICATION_started')) {header('Location: .');exit;}

// some function definitions
function RS_add_JS_slashes($s) {return addcslashes(html_entity_decode($s, ENT_QUOTES, 'UTF-8'),"'\t\0\r\n\f\v");}

// End of file --------------------------------
?>