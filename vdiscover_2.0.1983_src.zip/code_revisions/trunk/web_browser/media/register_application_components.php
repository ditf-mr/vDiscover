<?php if (!defined('APPLICATION_started')) {header('Location: .');exit;}
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// this file registers all application componentsa

{// the MASTER STYLE SHEET for proper text formatting
// this file needs to be separated later on in such manner that flexible style changes will be possible, e.g. font changes or color changes
$r->register_cssFile('media/master_stylesheet.css');
} // end register master style sheet

?>