<?php
	# do not delete this ü, it is needed to ensure that this file contains utf-8

	// loadTranslations.php
	if ((!defined('REPOSITORY_MANAGER_started')) AND (!defined('APPLICATION_started'))) {
		header('Location: ../../../..');
		exit;
	}
	
	{ # include all relevant classes
                
		require_once( __DIR__ . DIRECTORY_SEPARATOR . 'main' . DIRECTORY_SEPARATOR . 'cTranslations.php' );
		
	}
	
	{ # initialise global object for backend access
		global $translations;
		if ( is_null( $translations = new cTranslations ( ) ) ) {
			throw new Exception('Could not initialise global $translations object.');
		}
	}
	
	// if translations are loaded from the application, try to set the language
	
	if (defined('APPLICATION_started')) {
		// ask backend for current locale
		$langCode = $backend->currentLocale();

		// if locale in backend is default (user isn't logged in, or not locale not set)
		if ($langCode == 'default') {		
			if ( isset($_SESSION) AND array_key_exists('currentLangCode', $_SESSION) )
				$langCode = $_SESSION['currentLangCode'];
		}
		$translations->selectLanguage($langCode);
		// bind manual...
		global $modules;
		$modules['manual'] = 'application/user_manual/'. $langCode .'/manual.php';
	}		
			
	// global T() Function for php-files
	function T( $langStringCode, $referenceString, $params = false) {
		global $langCode;
		global $translations;
		if ($langCode) {
			$langStrings = $translations->getLanguageStrings();
			if ( $langStrings AND array_key_exists( $langStringCode, $langStrings) ) {
				$outputString = $langStrings[$langStringCode];
			}
			else {
				$outputString = $referenceString;
			}
		}
		else
			$outputString = $referenceString;
			
		# substitute $data in translation
		if (isset($params)) {
			# Array data exists -> replace...
			for ($i = 0; $i < count($params); $i++) {
				$outputString = str_replace('$['.$i.']', $params[$i], $outputString);
			} 
		}
		return $outputString;
	}
	
	// end of global T-Function
  
?>