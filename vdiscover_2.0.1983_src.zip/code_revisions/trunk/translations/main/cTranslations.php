<?php
	// do not delete this ü, it is needed to ensure that this file contains utf-8
	
	// cTranslation.php

	class cTranslations	 {
		
		private $_currentLangName;
		private $_currentLangCode = false;
		private $_currentLangModified = false;
		private $_languageStrings = array();		
		private $_languageReferenceStrings = array();
		
		// ==========================================================================================
		// Constructor / Descructor 
		// ==========================================================================================

		public function __construct ( ) {			
			$this->_readReferenceLanguageFile();			
		} // end-of-function __construct
				
		public function __destruct ( ) {
			// writes the current language file, if class is used in repository manager
			if (($this->_currentLangCode) && ($this->_currentLangModified) && defined('REPOSITORY_MANAGER_started')) {
				$this->_writeLanguageFile();
			}
		} // end-of-function __destruct
		
		// ==========================================================================================
		// Public Methods
		// ==========================================================================================
		
		public function getAvailableLanguages() {
			/** Returns a list of available languages.
			 * @return array. The list of available languages as key value pair.
			 * @return false. If there is none language available.
			 */
			$languageList = $this->_getAvailableLanguagesFromFilesystem();
			if (sizeof($languageList) > 0) 
				return $languageList;
			else
				return false;
		}
		
		public function selectLanguage($langCode) {
			/** Select a language by given language code.
			 * @params $langCode. The code of the language.
			 * @return true. If language with \c $langCode successfully selected.
			 * @return false. If selection of language failed.
			 */
			$availableLanguages = $this->getAvailableLanguages();
			
			// test if $langCode is an available language
			if (($availableLanguages) && array_key_exists($langCode, $availableLanguages)) {
				if (($this->_currentLangCode) && ($this->_currentLangModified)) {
					$this->_writeLanguageFile(); // Konrad ? output and storage should not go into the same method ...
				}
			} // end if
			
			$this->_currentLangCode 	= $langCode;
			$_SESSION['currentLangCode']= $langCode;
			
			return $this->_readLanguageFile();
		} // end of method selectLanguage
		
		public function addLanguage($langCode, $langName) {
			/** Add a new language by given language code and name.
			 * @params $langCode. The code of the language.
			 * @return true. If language successfull added
			 * @return false. If adding of language failed.
			 */
		
			// Is language allready existing?
			$availableLanguages = $this->getAvailableLanguages();
			if (($availableLanguages) && array_key_exists($langCode, $availableLanguages)) {
				return false;
			}
			else {
				// Setting new Language name and code
				$this->_currentLangCode = $langCode;
				$this->_currentLangName = $langName;
				
				// Writing Language File
				return $this->_writeLanguageFile();
			}
		}
		
		public function renameLanguage($langCode, $langName) {
			/** Rename a language by given language code and new name.
			 * @params $langCode. The code of the language.
			 * @params $langName. The new name of the language.
			 * @return true. If language successfull renamed.
			 * @return false. If renaming of language failed.
			 */
			 
			// Selecting language
			$this->selectLanguage($langCode);
			
			// Setting new Language name
			$this->_currentLangName = $langName;
			
			// Writing Language File
			return $this->_writeLanguageFile();
		}
		
		public function deleteLanguage($langCode) {
			/** Delete a language by given language code.
			 * @params $langCode. The code of the language.
			 * @return true. If language successfull renamed.
			 * @return false. If renaming of language failed.
			 */
			 
			// Selecting language
			$this->selectLanguage($langCode);
			
			// Deleting the selected language
			return $this->_deleteLanguageFile();
		}
				
		public function cleanupLanguage($langCode) {
			/** Cleanup a language by given language code and new name. Language string which are marked as delted and such that are not longer available in the reference language file are also removed from language file with given langCode.
			 * @params $langCode. The code of the language.
			 * @return true. If language successfull cleaned up.
			 * @return false. If cleaning up of language failed.
			 */
				
			// Selecting language
			$this->selectLanguage($langCode);
			
			// for every language translation string in translated language
			foreach ($this->_languageStrings as $key => $value) {
				// look if the language string is also there in the reference language			
				if (array_key_exists( $key, $this->_languageReferenceStrings )) {
					// if the language string has status deleted in the referene language
					if (array_key_exists("deleted", $this->_languageReferenceStrings[$key]) && $this->_languageReferenceStrings[$key]['deleted'] ) {
						unset($this->_languageStrings[$key]);
					}						
				} else {
					// if not remove the language string also from current language
					unset($this->_languageStrings[$key]);
				}
			}			
			
			// Writing Language File
			return $this->_writeLanguageFile();				
		}
		
		public function getLanguageStrings() {
		/** Get language strings for currentLanguage.
		 * @return array. The array of all language strings.
		 */
			if (isset($this->_currentLangCode)) {
				$languageStrings = array();
				
				reset($this->_languageStrings);
				while ( list($key, $value) = each($this->_languageStrings)) {
					if (array_key_exists ('langStringValue', $value) ) {
						$languageStrings[$key] = $value['langStringValue'];
					} else {
						// the language string is in the reference language file in another slot 
						// and needs to be cleaned of JavaScript line breaks
						reset($value);
						$cV = current($value);
						$languageStrings[$key] = preg_replace( '/\\s*\\\\\\n\\s*/s',' ', $cV['langStringValue']);						
					} // end if
				
				} // end while ...
			
				return $languageStrings;
			}
			else
				return false;
		}
		
		public function setLanguageStrings($langStringCode, $newTranslation) {		
		/** Set language strings for currentLanguage.
		 * @params string $langStringCode. The code of the language string.
		 * @params string $langStringCode. The new translation.
		 * @return true. If setting new translation was successfull.
		 * @return false. If setting new translation failed.
		 */
			if (isset($this->_currentLangCode)) {
				if (array_key_exists($langStringCode, $this->_languageReferenceStrings)) {
					$this->_languageStrings[$langStringCode] = array(
						"langStringValue"			=> $newTranslation,
						"langStringLastModified" 	=> time()
					);
					$this->_currentLangModified = true;
					return true;
				}	
				return false;
			}
		}

		public function getLanguageStringsToTranslate($filter = false) {
			/** Get language strings for currentLanguage for view in translation manager.
			 * @params string $filter. "changed", "deleted", "new" (default false).
			 * @return array. The array of all language strings.
			 */
			$languageStringsToTranslate = array();
			
			foreach ($this->_languageReferenceStrings as $key => $value) {
			
				$timestamp = 0;
				// search the oldest timestamp, important for the duplicates
				
				foreach ( $value as $element ) {
					if ( !isset($timestamp) || $element['langStringLastModified'] > $timestamp  )
						$timestamp = $element['langStringLastModified'];
				}
				
				// Take the first element of the array, the overs are duplicates
				$value = array_shift($value);
				
				// Generates output for this key
				$languageStringsToTranslate[$key] = array(
					"langStringRefValue" 		=> $value['langStringValue'],
					"langStringLastModified" 	=> $value['langStringLastModified'],					
				);
				
				// Is there allready a translation for theis language string
				if ( array_key_exists( $key, $this->_languageStrings ) ) {
					// translation for this translation string is allready available
					$languageStringsToTranslate[$key]['langStringValue'] = $this->_languageStrings[$key]['langStringValue'];
					
					// is the reference language string newer than the last translated
					if ( $timestamp > $this->_languageStrings[$key]['langStringLastModified'] ) {
					
						if ( array_key_exists('deleted', $value) && $value['deleted'] ) {
							// if language string was marked as deleted in reference file
							$languageStringsToTranslate[$key]['status'] = "deleted";
							
						}
						else {
							// if not deleted then changed
							if ( isset( $value['langStringOldValue'] ) ) {
								$languageStringsToTranslate[$key]['status'] 				= "changed";
								$languageStringsToTranslate[$key]['langStringRefOldValue'] 	= $value['langStringOldValue'];
							}
						}
					}
				}
				else {
					// no there is translation for this language string 
					$languageStringsToTranslate[$key]['status'] = "new";
				}
			}
			ksort($languageStringsToTranslate);
			
			// filter the output if neccessary
			if ($filter) {
				foreach ($languageStringsToTranslate as $key => $value) {
					if ( ( array_key_exists("status", $value ) && $value['status'] == $filter) ) {
						unset($value['status']);
						$languageStringsToTranslateFilter[$key] = $value;									
					}
				}
				return $languageStringsToTranslateFilter;
			}
			else {
				return $languageStringsToTranslate;
			}
		}

		public function getDuplicateLanguageStringsWithDifference() {
			/** Get language strings strings from which there are multiple versions for the reference language held in the source code.
			 * @return array. The array of all language strings with multiple versions.
			 */
			$duplicates = array();
			// search in the array for reference language
			foreach ( $this->_languageReferenceStrings as $key => $value ) {
				// if there are more than one entry for a translation string
				if ( sizeof( $value ) > 1 ) {
					// set the foundDuplicates array empty
					$foundDuplicates = array();
					// search in the array for a translation string for all different occurences
					foreach ($value as $innerKey => $innerValue) {
						// save the occurences in the foundDuplicates array if there is a new one which differs from the over
						if ( !in_array( $innerValue['langStringValue'], $foundDuplicates ) ) {
							$foundDuplicates[$innerKey] = $innerValue['langStringValue'];
						}
					}
					// if there more than one version of the the language string
					if ( sizeof( $foundDuplicates ) > 1 ) {
						$duplicates[$key] = $value;
					}
					unset($foundDuplicates);
				}
			}
			return $duplicates;
		}
		
		public function generateReferenceLanguageFile() {
		/** Generates the default reference file new.
		 * @return true. If reference language file successfully created.
		 * @return false. If reference language file failed.
		 */
			if ($this->_findTranslationStringsInFiles()) {
			
				if ($this->_writeReferenceLanguageFile()) {
					return true;			
				}
			}			
			return false;
		}
		
		public function cleanupReferenceLanguageFile() {
		/** Cleans up the reference file.
		 * @return true. If reference language file successfully cleaned up.
		 * @return false. If nothing is found to cleanup.
		 
		 */
				
			$foundToDelete = false;
			
			foreach ( $this->_languageReferenceStrings as $key => $value ) {
				foreach ($value as $innerKey => $innerValue) {
					if ( array_key_exists('deleted', $innerValue) &&  $innerValue['deleted'] ) {
						unset( $this->_languageReferenceStrings[$key][$innerKey] );
						$foundToDelete = true;
					}
				}
			}
			
			if ($foundToDelete) {
				$this->_writeReferenceLanguageFile();
				return true;
			}
			else {
				return false;
			}
		}
		
		// ==========================================================================================
		// Private / Protected Methods - Handle language files
		// ==========================================================================================
		
		private function _getReferenceLanguageFilePath() {
			/** Returns the language file path of the reference language.
			 * @return string. The absolute path to the file with the translations of the language.
			 *
			 */
			return $this->_getLanguagesFilePath() . DIRECTORY_SEPARATOR . "reference.lang.php";		
		}
		
		private function _getLanguageFilePath($langCode) {
			/** Returns the language file path to the given language.
			 * @params $langCode string. The code of the language.
			 * @return string. The absolute path to the file with the translations of the language.
			 *
			 */
			
			if ( empty($langCode) OR ($langCode=='default') ) $langCode='reference';
			
			return $this->_getLanguagesFilePath() . DIRECTORY_SEPARATOR . $langCode . ".lang.php";		
		}
		
		private function _getLanguagesFilePath() {
			/** Returns the file path to the translations files.
			 * @return string. The absolute path to the folder with the translations.
			 *
			 */
			return realpath( __DIR__ . DIRECTORY_SEPARATOR . ".." . DIRECTORY_SEPARATOR . "lang");		
		}
	
		private function _scanLanguagesFilePath() {
			/** Returns an array of file which are available in the path where the translation files.			
			 * @return array. The list of absolute paths to the found files in the folder with the translations.
			 *
			 */
			$filesInLanguagesFilePath = array();
			// checks if path for language packs exists
			$directory = $this->_getLanguagesFilePath();
			if (file_exists($directory)) {
				$handle = opendir($directory);
				if ($handle) {
					// scan filesystem entries
					while (false !== ($entry = readdir($handle))) {
						// ignore filesystem entries for current directory entry and higher level directory
						if ($entry == '.' || $entry == '..') 
							continue;
						$file = $directory . DIRECTORY_SEPARATOR . $entry;			
						if ( (!is_link($file)) && (!is_dir($file)) && ($entry != '.svn') && ($entry != '_svn') ) {
							$filesInLanguagesFilePath[] = $file;
						}
					}
				}
			}
			return $filesInLanguagesFilePath;
		}
		
		private function _getAvailableLanguagesFromFilesystem() {
			/** Returns an array of file which are available in the path where the translation files.			
			 * @return array. The list of available languages as key value pair.
			 */
			 
			$languageList = array();
			$filesInLanguagesFilePath = $this->_scanLanguagesFilePath();
			// Scan all files in $filesInLanguagesFilePath
			foreach ($filesInLanguagesFilePath as $languageFile) {
				if (file_exists($languageFile)) {
					include($languageFile);
					// checks if $langName and $langCode are set in languageFile
					if ((isset($langName)) && (isset($langCode))) {
						// checks if $languageFileName is correct
						if ( basename($languageFile) == baseName($this->_getLanguageFilePath($langCode))) {
							$languageList[$langCode] = $langName;
						}
						unset($langName);
						unset($langCode);
					}
				}
			}
			return $languageList;
		}
		
		private function _readLanguageFile() {
			/** Read the language strings that correspond to the internal language code into the class.
			 * @return true. If language was successfully read from file.
			 * @return false. If reading the language strings from file has failed.
			 *
			 */
			$languageFile = $this->_getLanguageFilePath($this->_currentLangCode);
			
			if (file_exists($languageFile)) {
				// $langName is a variable in $languageFile
				include($languageFile);
				
				global $langName;
				$this->_currentLangName = $langName ? $langName : 'Programmer\'s English';
				
				if (isset($langStrings)) {
					$this->_languageStrings = $langStrings; // Konrad: this copies the whole array ... not very efficient ???
					return true;
				} // end if
				
			} // end if
			return false;
		} // end of method _readLanguageFile
		
		private function _writeLanguageFile() {
		
			/** Save the language of current langCode from class to file.
			 * @return true. If language is successfull written to file.
			 * @return false. If writing the language to file is failed.
			 *
			 */
			$handle = fopen($this->_getLanguageFilePath($this->_currentLangCode), 'w');
			if ($handle) {
				// Start of file
				fwrite($handle, "<?php\n\n");
				fwrite($handle, "/* \n");
				fwrite($handle, "vDiscover (Retrieval System for Structured Information)\n");
				fwrite($handle, "\n");
				fwrite($handle, "-------------------------------------------------------\n");
				fwrite($handle, "For documentation, license conditions and warranty\n");
				fwrite($handle, "see Read.Me in root directory.\n");
				fwrite($handle, "*/\n");
	
				fwrite($handle, "\t// Do not edit this file by hand, because it's generated by the repository manager.\n\n");
				fwrite($handle, "\t// Language pack for language: " . $this->_currentLangName . "\n\n");
				
				// Basic information about the language
				fwrite($handle, "\t" . '$langName' ."    = '" . addslashes($this->_currentLangName) . "';\n");
				fwrite($handle, "\t" . '$langCode' ."    = '" . addslashes($this->_currentLangCode) . "';\n");
				
				// Sort Array
				ksort($this->_languageStrings);
				
				// Language strings
				if (sizeof($this->_languageStrings) > 0) {
					fwrite($handle, "\t" . '$langStrings' ." = array(");
					$firstLangStringKey = true;
					foreach ($this->_languageStrings as $langStringKey => $langStringValue) {
						if ($firstLangStringKey)
							$firstLangStringKey = false;
						else
							fwrite($handle, ",");
						fwrite($handle, "\n\n\t\t" . "'" . $langStringKey . "'" . " => array(");
						$firstParam = true;
						foreach ($langStringValue as $key => $value) {
							if ($firstParam)
								$firstParam = false;
							else
								fwrite($handle, ",");
							$value = str_replace("'", "\'", $value);
							$value = str_replace("\\\'", "\'", $value);
							fwrite($handle, "\n\t\t\t" . "'" . $key . "'" .  " => " . "'" . $value . "'");
						}
						fwrite($handle, "\n\t\t)");						
					}					
					fwrite($handle, "\n\t);\n");
				}
				
				// End of file
				fwrite($handle, "\n\t//End of language pack for language ". $this->_currentLangName."\n");
				fwrite($handle, "\n?>");
				fclose($handle);
			
				return true;
			}
			else {
				return false;
			}
		}
		
		private function _deleteLanguageFile() {
			/** Delete the language file of current langCode.
			 * @return true. If language file is successfully delted.
			 * @return false. If deleting of the language is failed.
			 *
			 */
			$languageFile = $this->_getLanguageFilePath($this->_currentLangCode);
			if ( file_exists( $languageFile ) ) {
				if ( unlink($this->_getLanguageFilePath($this->_currentLangCode)) ) {
					$this->_currentLangName = false;
					$this->_currentLangCode = false;
					$this->_currentlangStrings = false;
					
					return true;
				}
			}
			else
				return false;
		}
		
		private function _readReferenceLanguageFile() {
			/** Read the language of reference language from language file to class.
			 * @return true. If language is successfull read from file.
			 * @return false. If reading the language from file is failed.
			 *
			 */
			$languageFile = $this->_getReferenceLanguageFilePath();
			if (file_exists($languageFile)) {
				include($languageFile);
				if (isset($langStrings)) {
					$this->_languageReferenceStrings = $langStrings;
					return true;
				}
			}
			else {
				return false;
			}
		}
		
		private function _writeReferenceLanguageFile() {
			/** Save the reference language from class to file.
			 * @return true. If language is successfull written to file.
			 * @return false. If writing the language to file is failed.
			 *
			 */
			
			$handle = fopen($this->_getReferenceLanguageFilePath(), 'w');
			if ($handle) {
				// Start of file
				fwrite($handle, "<?php\n\n");
				fwrite($handle, "\t//Retrieval System for Structured Information\n\n");
				fwrite($handle, "\t//Do not edit this file by hand, because it's generated by the repository manager.\n\n");
				fwrite($handle, "\t//This file is the referenc language file.\n\n");
								
				// Sort Array
				ksort($this->_languageReferenceStrings);
				// Language strings
				if (sizeof($this->_languageReferenceStrings) > 0) {
					fwrite($handle, "\t" . '$langStrings' ." = array(");
					$firstLangStringKey = true;
					foreach ($this->_languageReferenceStrings as $langStringKey => $langStringValue) {
						if ($firstLangStringKey)
							$firstLangStringKey = false;
						else
							fwrite($handle, ",");
						fwrite($handle, "\n\n\t\t" . "'" . $langStringKey . "'" . " => array(");
						$firstParam = true;
						foreach ($langStringValue as $key => $value) {
							if ($firstParam)
								$firstParam = false;
							else
								fwrite($handle, ",");
							fwrite($handle, "\n\n\t\t\t'" . $key . "' => array(");
							$firstParamInner = true;
							foreach ($value as $innerKey => $innerValue) {
								if ($firstParamInner)
									$firstParamInner = false;
								else
									fwrite($handle, ",");
								$innerValue = str_replace("'", "\'", $innerValue);
								$innerValue = str_replace("\\\'", "\'", $innerValue);
								fwrite($handle, "\n\t\t\t\t" . "'" . $innerKey . "'" . " => " . "'"	. $innerValue . "'");
							}
							fwrite($handle, "\n\t\t\t)");						
						}
						fwrite($handle, "\n\t\t)");						
					}					
					fwrite($handle, "\n\t);\n");
				}
						
				// End of file
				fwrite($handle, "\n\t//End of language pack for reference language. \n");
				fwrite($handle, "\n?>");
				fclose($handle);
			
				return true;
			}
			else {
				return false;
			}
		
		
		}
		
		private function _getAllRelevantFilesForParsing($directory) {
			/** Find all relevant files for parsing.
			 * @return array. If language is successfull written to file.
			 * @return array $files. A list of files.
			 *
			 */
			
			// define array where found files are stored
			$files 				= array();
			
			// excluded directories for scanning
			$excludedDirs 		= array("third_party_libraries","json","media","lang");							
			
			// fileTypes to be scanned
			$allowedFileTypes 	= array("js", "php");
    
			// add trailing slashes
			if (substr($directory,-1) != DIRECTORY_SEPARATOR) {
				$directory .= DIRECTORY_SEPARATOR;
			}
    
			// try to open dir
  			if (file_exists($directory)) {
				$handle = opendir($directory);
				if ($handle) {
					// scan filesystem entries
					while (false !== ($entry = readdir($handle))) {
					
						// ignore filesystem entries for current directory entry and higher level directory
						if ($entry == '.' || $entry == '..') {
							continue;
						}
						// ignore excluded dir
						if (in_array($entry, $excludedDirs)) {
							continue;
						}
						
						$file = $directory . $entry;
						// ignore file isn't a symlink
						if (!is_link($file)) {
							if (is_dir($file)) {								
								// if entry is a directory, call function recursively
								$files = array_merge( $files, $this->_getAllRelevantFilesForParsing($file) );
							} 
							else {
								// if filesystem entry is a file and file has allowed fileType
								$parts = explode(".", $entry);                   
								if (in_array($parts[count($parts)-1], $allowedFileTypes)) {
									$files[] = $directory.$entry;                       
								}
							}
						}
					}					
					closedir($handle);
				}
            }
            
			return $files;
		}

		private function _findTranslationStringsInFiles() {
		/** Generates array from the found translation string match.
		 * @params $match string. The found match as string.
		 * @return 
		 *
		 */
	
			// Array with parsedTranslationStrings
			$parsedTranslationStrings = array();
		
			// Set directory to be scanned
			$directoryToScan 	= realpath( __DIR__ . DIRECTORY_SEPARATOR . ".." . DIRECTORY_SEPARATOR . ".." . DIRECTORY_SEPARATOR . "web_browser");		

			// Parse the directory recursivly
			$files = $this->_getAllRelevantFilesForParsing($directoryToScan);
			
			// Set regular expression for scanning				
			$innerPattern =   "(" . 
								"'(?:[^'\\\\]|\\\\'?)*'" 
							. "|" . 
								'"(?:[^"\\\\]|\\\\"?)*"' 
							. ")";
			$whitespaces = "\s*";

			$pattern = "/\bT".$whitespaces."\(".$whitespaces.$innerPattern.$whitespaces.",".$whitespaces.$innerPattern."/"; // überflüssig ist: .$whitespaces."\)/";

			if (sizeof($files) == 0)
				return false;
				
			// walk through the files
			foreach( $files as $file ) {
				$matches = array();
				// Scan the file
				
				$matches = array();
				preg_match_all($pattern, file_get_contents($file), $matches);
				
				// check if matches were found
				if ( sizeof($matches[1]) > 0  ) {		
					// walk through the matches
					for ($i=0; $i<sizeof($matches[1]); $i++) {
						$foundTranslationKey = substr($matches[1][$i],1,-1);
						$foundTranslationValue = substr($matches[2][$i],1,-1);
												
						$fileKey = str_replace(realpath($directoryToScan . DIRECTORY_SEPARATOR . ".." ) . DIRECTORY_SEPARATOR, '', $file);				
						
						if (array_key_exists($foundTranslationKey, $this->_languageReferenceStrings) 
						&& is_array($this->_languageReferenceStrings[$foundTranslationKey]) && (array_key_exists($fileKey, $this->_languageReferenceStrings[$foundTranslationKey])) ) {
							// translation key allready exists 

							$currentValue = str_replace("'", "\'", $this->_languageReferenceStrings[$foundTranslationKey][$fileKey]['langStringValue']);
							$currentValue = str_replace("\\\'", "\'", $currentValue);
							
							$newValue = str_replace("'", "\'", $foundTranslationValue);
							$newValue = str_replace("\\\'", "\'", $newValue);

							if ($currentValue != $newValue) {								// translation string value changed - update it
								$parsedTranslationStrings[$foundTranslationKey][$fileKey] = array (
									"langStringValue" => $foundTranslationValue,
									"langStringLastModified" => time(),
									"langStringOldValue" => $this->_languageReferenceStrings[$foundTranslationKey][$fileKey]['langStringValue']
								);
							}
							else {
								// if nothing changed, take over
								$parsedTranslationStrings[$foundTranslationKey][$fileKey] = $this->_languageReferenceStrings[$foundTranslationKey][$fileKey];
							}
							
						}
						else {
							// translation key is new - add it
							$parsedTranslationStrings[$foundTranslationKey][$fileKey] = array (
								"langStringValue" => $foundTranslationValue,
								"langStringLastModified" => time()
							);
						}
					}
				}
			}
			
			// look up deleted tags in code

			foreach ($this->_languageReferenceStrings as $oldReferenceStringKey => $oldReferenceStringValue) {
				if (array_key_exists($oldReferenceStringKey, $parsedTranslationStrings)) {
					// if there are still files with this key 
					if (is_array($oldReferenceStringValue)) {
						foreach ($oldReferenceStringValue as $key => $value) {
							$parsedTranslationStringsFiles = $parsedTranslationStrings[$oldReferenceStringKey];
							if (!array_key_exists($key, $parsedTranslationStringsFiles)) {
								// but not in the current check file
								$parsedTranslationStrings[$oldReferenceStringKey][$key] =  $this->_languageReferenceStrings[$oldReferenceStringKey][$key];
								$parsedTranslationStrings[$oldReferenceStringKey][$key]["deleted"] = true;
								$parsedTranslationStrings[$oldReferenceStringKey][$key]["langStringLastModified"] = time();
							}
						}
					}
				}
					
			}
			
			$this->_languageReferenceStrings = $parsedTranslationStrings;
			
			return true;
		}
	
	}	

?>