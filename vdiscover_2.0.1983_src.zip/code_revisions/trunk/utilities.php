<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

if ((!defined('REPOSITORY_MANAGER_started')) AND (!defined('APPLICATION_started'))) {header('Location: .');exit;}

// some common function definitions that we will need anywhere ...


// get, post and cookie input data comes sometimes already escaped. This needs to be undone by the following function:
function RS_strip_slashes ($s) {return ((get_magic_quotes_gpc())?stripslashes($s):$s);}

// the following functions sanitize input that was passed via GET, POST, etc.
// $var needs to have the key $key, where the value to be returned is found.
// if $altVar contains an array, so it is checked, if $var does not contain the 
// key $s.

function sanitize_HTMLstring($var, $key, $altVar=null) {
	if ( array_key_exists( $key, $var ) )
		$value = $var[$key];
	elseif ( (! is_null($altVar)) and (is_array($altVar)) and ( array_key_exists( $key, $altVar ) ) )
		$value = $altVar[$key];
	else {
		#throw new developerException('No "'.$key.'" passed. Aborting.');
		return null;
	}
	{ # replace html entities
		$value = html_entity_decode($value, ENT_NOQUOTES, 'UTF-8');
	}
	/* if FILTER_FLAG_STRIP_LOW is used, then all newlines will be erased. */
	# $value = filter_var(RS_strip_slashes($value), FILTER_UNSAFE_RAW, array('flags'=>FILTER_FLAG_STRIP_LOW));
	$value = filter_var(RS_strip_slashes($value), FILTER_UNSAFE_RAW);
	return ( $value );
} // end of function sanitize_string


function sanitize_string($var, $key, $altVar=null) {
	if ( array_key_exists( $key, $var ) )
		$value = $var[$key];
	elseif ( (! is_null($altVar)) and (is_array($altVar)) and ( array_key_exists( $key, $altVar ) ) )
		$value = $altVar[$key];
	else {
		#throw new developerException('No "'.$key.'" passed. Aborting.');
		return null;
	}
	/* this filter doesn't work for json objects. This Filter replaces e.g. '"' by '&#34;' therefore 
	the string can no longer be interpreted as json. */
	# return filter_var(RS_strip_slashes($value), FILTER_SANITIZE_STRING, array('flags'=>FILTER_FLAG_STRIP_LOW));
	return filter_var(RS_strip_slashes($value), FILTER_UNSAFE_RAW, array('flags'=>FILTER_FLAG_STRIP_LOW));
} // end of function sanitize_string


function sanitize_boolean($var, $key, $altVar=null) {
	if ( array_key_exists( $key, $var ) )
		$value = $var[$key];
	elseif ( (! is_null($altVar)) and (is_array($altVar)) and ( array_key_exists( $key, $altVar ) ) )
		$value = $altVar[$key];
	else {
		#throw new developerException('No "'.$key.'" passed. Aborting.');
		return null;
	}
	return (json_decode($value))?true:false;
} // end of function sanitize_string


function sanitize_integer($var,$s, $altVar=null) {
	if(!array_key_exists($s,$var))	throw new developerException('No "'.$s.'" passed. Aborting.');
	return (int)$var[$s];
} // end of function sanitize_integer


	# ----------------------------------------------------------------------------------------------
	# Conversion Date/Time
	# ----------------------------------------------------------------------------------------------
	
	
	function convertInternalDateTime2UnixTimestamp ( $anInternalDateTime='') {
		/** Converts the given date time value to Unix specific timestamp.
		 * @param $anInternalDateTime \ref Datetime-string.
		 * @return integer.
		 */
		{ # check sign
			if (strlen($anInternalDateTime) == 20) {
				if (substr($anInternalDateTime, 0, 1) == '-') {
					$negative = true;
					$anInternalDateTime = substr($anInternalDateTime, -19);
				}
				else {
					return ( null ); # error
				}
			}
			else {
				$negative = false;
			}
		}
		{ # extract parts
			$year = substr($anInternalDateTime, 0, 4);
			$month = substr($anInternalDateTime, 5, 2);
			$day = substr($anInternalDateTime, 8, 2);
			$hour = substr($anInternalDateTime, 11, 2);
			$minute = substr($anInternalDateTime, 14, 2);
			$second = substr($anInternalDateTime, 17, 2);
		}
		{ # return Unix timestamp
			return ( mktime($hour, $minute, $second, $month, $day, $year) );
		}
	} # end-of-function convertInternal2UnixTimestamp
	
	
// End of file --------------------------------
?>