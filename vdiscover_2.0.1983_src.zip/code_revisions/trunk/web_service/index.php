<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/


//Errors should not be displayed directly
function mySoapErrorHandler($errorCode, $errorText, $errorFile, $errorLine) {
	return true;
}

if(!$repository_config) {header('Location: ../..');exit;}
define('APPLICATION_started', true);

set_include_path(realpath(__DIR__.DIRECTORY_SEPARATOR.'..'));

{	// add absolute paths to $repository_config
	require_once(__DIR__.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'information_structure'.DIRECTORY_SEPARATOR.'utilities.php');
	$repository_config = expandPathsIn_repository_config($repository_config);	
}
{ # load configuration
	require_once($repository_config['application_path'].DIRECTORY_SEPARATOR.'config.php');
}

{ # load and initialise global log files handler 
	require_once(realpath($repository_config['application_path'].'/../../utilities/cLogHandler.php'));
	global $logHandler;
	if ( is_null( $logHandler = new cLogHandler ( $repository_config['path_logs'] ) ) ) 
		die('Could not initialise global $logHandler object.');
}

{ # load exceptions
	require_once(realpath($repository_config['application_path'].'/../../utilities/exceptions.php'));
}

{ # set log handler
	set_error_handler('mySoapErrorHandler');
}

// load Backend module and create cBackend instance
require($repository_config['application_path'].'/backend/loadBackend.php');

// Melde alle PHP Fehler (siehe Changelog)
error_reporting(E_ALL);

// TODO: wherefore is this code???
ini_set('soap.wsdl_cache_enabled', '0'); 

// Pull in the NuSOAP code
require_once('third_party_libraries/nusoap-0.9.5/lib/nusoap.php');

// Making the registry available
/*echo __DIR__;
exit;*/
require_once('../common/cPluginRegistry.php'); 

// the plugin registry can by accessed via the variable $r from now on
$r = new cWebserviceMethodRegistry();

// Wrapper Class for webservice
class Soap_wrapper extends soap_server{
	var $script_uri;
	public function __construct() {
		global $backend;
		$page = $_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
		$this->script_uri='http://'.$page; 
		
		parent::nusoap_server();  
		
		// Initialize WSDL support
		global $repository_config, $r;
		
		$this->configureWSDL('DITF_RS2_' . str_replace(' ','_',$repository_config['repository_name']) , 'urn:'.$this->script_uri);
		$this->soap_defencoding = 'UTF-8';

		try {		
				{ // Include general methods for Webservice
					$dir = realpath(__DIR__.DIRECTORY_SEPARATOR.'web_service_methods'.DIRECTORY_SEPARATOR);
					$d = dir ($dir);
					while (false !== ($file = $d->read())) {
						$file_parts = explode(".",$file);
						if ($file_parts[1] == "php")
							require_once($dir . DIRECTORY_SEPARATOR . $file);
					}
				}

				{ // Include Plugins 
	
					cWebserviceMethodRegistry::registerModuleComponents(PLUGIN_REGISTRY_parseAllSubDirs, $repository_config['path_common_plugins'] );

					cWebserviceMethodRegistry::registerModuleComponents(PLUGIN_REGISTRY_parseAllSubDirs, $repository_config['path_plugins'] );

					// Generate WSDL Complex Types
					$complexTypes = $backend->getStructForWsdlComplexTypesOfAllClasses();

					// Load and add Complex Types from Plugins
					if (is_array( $r->getWebServiceComplexTypes() ))
						$complexTypes = array_merge($complexTypes, $r->getWebServiceComplexTypes()); 
					
					foreach ( $complexTypes as $complexTypeKey =>  $complexTypeValue ) {
						$this->wsdl->addComplexType(
							$complexTypeKey,
							'complexType',	
							'struct',
							'all',
							'',
							$complexTypeValue
						);
						$this->wsdl->addComplexType(
							$complexTypeKey.'Array',
							'complexType',
							'array',
							'',
							'SOAP-ENC:Array',
							array(),
							array(
								array('ref'=> 'SOAP-ENC:arrayType', 'wsdl:arrayType' => 'tns:'.$complexTypeKey.'[]')
							),
							'tns:'.$complexTypeKey
						);
					}
										
					
					$webserviceMethods = $r->getWebServiceMethods();
										
					foreach ( $webserviceMethods as $webserviceMethod ) {
						require($webserviceMethod[0]);
						$this->register(
							$webserviceMethod[1], 
							$webserviceMethod[3], 
							$webserviceMethod[4],
							'urn:RS2',
							'urn:RS2#'.$webserviceMethod[1],
							'rpc',
							'literal',
							$webserviceMethod[2]
						);
					}
				}

		} catch ( Exception $e ) {
			throw new loggedException ($e->getMessage() .' at ' . $e->getFile() . '(' . $e->getLine() . '): ' . $e->getTraceAsString());
		}
	}
 
	public function service_start($data) {
		if ($data) {
			global $_SERVER;			
			$auth = array();
			
			if ( isset($_SERVER['PHP_AUTH_USER']) ) {
				$auth['username'] = $_SERVER['PHP_AUTH_USER'];
				$auth['password'] = $_SERVER['PHP_AUTH_PW'];
			}			
			if ( !$this->validateUser($auth) )  // function to validate the user	 		
				$this->fault('SOAP-ENV:Server','','Authentication failed!');
		}	
		$this->service($data);			
	}

	public function validateUser($auth) {
		if(!empty($auth[username])&& !empty($auth[password])) {
			global $backend;						
			if ( $backend->login($auth['username'],$auth['password']) === true ) {
				return true;
			}
		}
		return false;
	}

}
  
$server=new Soap_wrapper();
$HTTP_RAW_POST_DATA=isset($HTTP_RAW_POST_DATA)?$HTTP_RAW_POST_DATA:'';
$server->service_start($HTTP_RAW_POST_DATA);  
  
?>