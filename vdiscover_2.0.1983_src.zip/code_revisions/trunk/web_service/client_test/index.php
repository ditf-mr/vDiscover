<!DOCTYPE html><html>
	<head>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<!--<meta http-equiv="X-UA-Compatible" content="IE=8" />-->
		<title>Test Client for vDiscover Webservice</title>
		<link href="../../web_browser/media/master_stylesheet.css" rel="stylesheet" type="text/css" media="screen" />
		<style type="text/css">
			form input { border: 1px solid #ccc; }
			.code, pre { padding-left: 10px; width: 80%; margin: 10px; border: 1px dotted #000; background-color: #ddd; white-space: normal; font: courier; }
			pre{ white-space: pre; }
		</style>		
	</head>
	<body>
		
<?php

ini_set('soap.wsdl_cache_enabled', "0");

if ( isset ( $_POST['debug'] ) )
	$debug = TRUE;
else
	$debug = FALSE;
	
try {
    if (! isset($_POST['uri']) )  {
		?>
			<h1>Choose a webservice</h1>
			<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
				<p>Please enter the URL of the webservice (e.g. http://localhost/rs2/repositories/webservicetest.rpy/web_service/index.php?wsdl)</p>
				<label for="uri">URL</label>
				<input style="width: 300px;" name="uri">				
				<label for="username">Username</label>
				<input name="username" value="admin">
				<label for="password">Password</label>
				<input name="password" type="password" value="*****">
				<label for="debug">Debug?</label>
				<input name="debug" type="checkbox">
				<input type="submit">			
			</form>
		
		<?php
	}
	else {
	
		// Creaste new SoapClient Object
		
		
		$client = new SoapClient($_POST['uri'], array('login' => $_POST['username'], 'password' => $_POST['password'], 'trace' => 1));
													  
		// Ask for Web Service Functions
		{
			echo "<h1>Web-Service Functions</h1>";
			$result =  $client->__getFunctions();
			echo "<ul>";
			foreach ($result as $value) 
				echo "<li>" . $value . "</li>";
			echo "</ul>";			
			
		}
		
		// Ask for all object types
		{
			echo "<h1>All object types</h1>";
			
			$result = $client->getAllObjectTypes();
						
			if ( $debug ) {
				echo "<h2>Request</h2><p class='code'>" . htmlspecialchars($client->__getLastRequest()) . "</p>";
				echo "<h2>Response:</h2><p class='code'>" . htmlspecialchars($client->__getLastResponse()) . "</p>";
				echo "<h2>Data</h2><p><pre>";
				print_r($result);
				echo "</pre></p>";
			}
			if ($result){
				echo "<h2>Result</h2>";
				echo "<ul>";
				foreach ($result as $value) {				
					// Finde die ID des Objecttypes Person
					if ($value->name == "Persons") 	{
						$unterobject_super_uuid = $value->common->UUID;							
						echo "<li>Name: " . $value->name . " (UUID: " . $value->common->UUID .")</li>";					
					}
					else
						echo "<li>Name: " . $value->name . " (UUID: " . $value->common->UUID .")</li>";					
				}
				echo "</ul>";
			}
		}
		
		// Ask for all attribute types to object types
		{			
			echo "<h1>Attribute to object types</h1>";
			
			$objectTypes = $result;	
			echo "<ul>";			
			foreach ($objectTypes as $value) {
				echo "<li>Name: " . $value->name . "</li>";
				$result = $client->getAttributes($value->common->UUID);
				if ( $debug ) {
					echo '<h2>Request</h2>';
					echo "<h2>Request</h2><p class='code'>" . htmlspecialchars($client->__getLastRequest()) . "</p>";
					echo "<h2>Response:</h2><p class='code'>" . htmlspecialchars($client->__getLastResponse()) . "</p>";
					echo "<h2>Data</h2><p><pre>";
					print_r($result);
					echo "</pre></p>";
				}
				if ($result) {
					echo "<h2>Result</h2>";
					echo "<ul>";
					foreach ($result as $value) 
						//echo $value;
						//print_r($value);
						echo "<li>Name: " . $value->name . "</li>";
					echo "</ul>";
				}
				else
					echo "<p><strong>This object type has no attribute types</strong></p>";
				
				
			}
			echo "</ul>";			
		}
		
		// Ask for all relation types
		{
			echo "<h1>All relation types</h1>";
			
			$result = $client->getAllRelationTypes();
			
			if ( $debug ) {
				echo "<h2>Request</h2><p class='code'>" . htmlspecialchars($client->__getLastRequest()) . "</p>";
				echo "<h2>Response:</h2><p class='code'>" . htmlspecialchars($client->__getLastResponse()) . "</p>";
				echo "<h2>Data</h2><p><pre>";
				print_r($result);
				echo "</pre></p>";
			}
			if ($result) {
				echo "<h2>Result</h2>";
				echo "<ul>";
				foreach ($result as $value) {
					echo "<li>Name: " . $value->name . "</li>";				
				}
				echo "</ul>";
			}
		}
		
			
		// Search for "*Adm*"
		{
			echo "<h1>Search for Object *Adm*</h1>";
			
			$pattern = "*Adm*";
			$searchO = array();			
			$searchO['OT_UUIDs'] = false;
			$result = $client->searchObjectsByNameOrDescription($pattern,$searchO);
			
			if ( $debug ) {
				echo "<h2>Request</h2><p class='code'>" . htmlspecialchars($client->__getLastRequest()) . "</p>";
				echo "<h2>Response:</h2><p class='code'>" . htmlspecialchars($client->__getLastResponse()) . "</p>";
				echo "<h2>Data</h2><p><pre>";
				print_r($result);
				echo "</pre></p>";
			}
			
			if ($result) {
					echo "<h2>Result</h2>";
					echo "<ul>";
					foreach ($result as $value) 
						echo "<li>Name: " . $value->name . "</li>";
						echo "<li>UUID: " . $value->common->UUID . "</li>";
					echo "</ul>";
				}
				else
					echo "<p><strong>This search has no result.</strong></p>";
				
		}
		
		// Ask for a object
		{
			echo "<h1>Ask for a object with UUID: " . $value->common->UUID . "</h1>";
			
			$result = $client->getObject($value->common->UUID);
			
			if ( $debug ) {
				echo '<h2>Request</h2>';
				echo "<h2>Request</h2><p class='code'>" . htmlspecialchars($client->__getLastRequest()) . "</p>";
				echo "<h2>Response:</h2><p class='code'>" . htmlspecialchars($client->__getLastResponse()) . "</p>";
				echo "<h2>Data</h2><p><pre>";
				print_r($result);
				echo "</pre></p>";
			}
			
			if ($result) {
				echo "<h2>Result</h2>";
				//$value = current($result);
				$value = $result;
				echo "<ul>";
				echo "<li>Name: " . $value->name . "</li>";
				echo "</ul>";
			}
		}
		
		{ /* Adding Object Types	
		// Add a new object type on root level
		{
			echo "<h1>Add a new object type on root level</h1>";
			
			$newOT = array();
			$newOT['UUID'] = false;
			$newOT['name'] = "A new object type on root level";
			
			$result = $client->addObjectType($newOT);
			
			if ( $debug ) {
				echo "<h2>Request</h2><p>" . htmlspecialchars($client->__getLastRequest()) . "</p>";
				echo "<h2>Response:</h2><p>" . htmlspecialchars($client->__getLastResponse()) . "</p>";
				echo "<h2>Data</h2><p>";
				print_r($result);
				echo "</p>";
			}
			echo "<h2>Result</h2>";
			echo "<p>UUID of new object type: " . $result;		
		}
		
		// Add a new object type under object type persons
		{
			echo "<h1>Add a new object type under object type 'Persons'</h1>";			
			
			$newOT = array();
			$newOT['UUID'] = $unterobject_super_uuid;
			$newOT['name'] = "A new object type under Persons";
			
			$result = $client->addObjectType($newOT);
			
			if ( $debug ) {
				echo "<h2>Request</h2><p class='code'>" . htmlspecialchars($client->__getLastRequest()) . "</p>";
				echo "<h2>Response:</h2><p class='code'>" . htmlspecialchars($client->__getLastResponse()) . "</p>";
				echo "<h2>Data</h2><p><pre>";
				print_r($result);
				echo "</pre></p>";
			}
			echo "<h2>Result</h2>";
			echo "<p>UUID of new object type: " . $result;		
		}
		*/ }
		
		
		// Ask for all object types
		{
			echo "<h1>All object types</h1>";
			
			$result = $client->getAllObjectTypes();
			
			if ( $debug ) {
				echo "<h2>Request</h2><p class='code'>" . htmlspecialchars($client->__getLastRequest()) . "</p>";
				echo "<h2>Response:</h2><p class='code'>" . htmlspecialchars($client->__getLastResponse()) . "</p>";
				echo "<h2>Data</h2><p><pre>";
				print_r($result);
				echo "</pre></p>";
			}
			echo "<h2>Result</h2>";
			echo "<ul>";
			foreach ($result as $value) {
				echo "<li>Name: " . $value->name . "</li>";
				// Finde die ID des Objecttypes Person
				if ($value->name == "Persons") 	
					$unterobject_super_uuid = $value->common->UUID;							
			}
			echo "</ul>";
		}
				
			
	}
} catch (SoapFault $sf) {
    echo '<h2>Fault</h2><p class="code">';
    print_r($sf);
    echo '</p>';
}

?>
	<!-- end #footer -->
</body>
</html>