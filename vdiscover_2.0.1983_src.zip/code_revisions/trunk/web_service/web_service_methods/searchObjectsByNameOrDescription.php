<?php

	// Define the method as a PHP function
	//function searchObject($pattern, $OT_UUIDs) { 		
	function searchObjectsByNameOrDescription($pattern, $OT_UUIDs) {
		try {
			if (!$OT_UUIDs)
				$OT_UUIDs[] = '';
			foreach ($OT_UUIDs as $OT_UUID)
			{
				$values = cObject::retrieveBy_nameOrDescription( $OT_UUID, $pattern, 'name asc' );
				if ($values)
					foreach ( $values as $value )
						$result[] = $value['object']->toArray_WS();	
				else
					$result = false;
			}
				return $result;		
		} catch (Exception $e) {			
			return new nusoap_fault('SOAP-ENV:Server','',$e->getMessage(),$e->getFile() . '(' . $e->getLine() . '): ' . $e->getTraceAsString());
		}
	}
	// End of method definition
	
	// New Complex type for input to addObjectType function
	$this->wsdl->addComplexType(
		'searchObjectsByNameOrDescriptionOT_UUIDs',
		'complexType',	
		'struct',
		'all',
		'',
		array(	
			'OT_UUIDs' => array ('name' => 'OT_UUIDs', 'type' => 'xsd:string' )
		)		
	);
	
  	// Register the method to expose
	$this->register('searchObjectsByNameOrDescription', array('pattern' => 'xsd:string', 'OT_UUIDs' => 'tns:searchObjectsByNameOrDescriptionOT_UUIDs'), array( 'return' => 'SOAP-ENC:Array'),
		'urn:RS2',
		'urn:RS2#searchObjectsByNameOrDescription',
		'rpc', 'literal', 'With this mehtod you can search for Objects by namne or description. Additionally you can search only in one or more Object Types.');
?>
