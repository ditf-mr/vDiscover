<?php
		
	// Define the method as a PHP function
	function getObject($UUID) { 
		try {
			// get access to the backend
			global $backend;
			
			$object = $backend->get($UUID,'cObject');		
			
			if ($object)
				return $object->toArray_WS();
			else
				return new nusoap_fault('SOAP-ENV:Server','','Invalid UUID','');
		} catch (Exception $e) {
			return new nusoap_fault('SOAP-ENV:Server','',$e->getMessage(),$e->getFile() . '(' . $e->getLine() . '): ' . $e->getTraceAsString());
		}	
	}
	// End of method definition
	
  	// Register the method to expose
	$this->register('getObject', array('UUID' => 'xsd:string'), array( 'return' => 'tns:cObject'),
		'urn:RS2',
		'urn:RS2#getObject',
		'rpc', 'literal', 'With this webservice you get back an object.');
?>
