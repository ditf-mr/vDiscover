<?php
  
	// Define the method as a PHP function
	function getAttributes($ORT_UUID) {
		try {
			// get access to the backend
			global $backend;
						
			$ORT = $backend->get($ORT_UUID);		
			
			$ATs = $ORT->getAttributes();
			
			if ($ATs)
				foreach ( $ATs as $AT )
					$attributeTypes[] = $AT->toArray_WS();					
			else
				$attributeTypes = false;;
			return $attributeTypes;		
		} catch (Exception $e) {			
			return new nusoap_fault('SOAP-ENV:Server','',$e->getMessage(),$e->getFile() . '(' . $e->getLine() . '): ' . $e->getTraceAsString());
		}
	}
	// End of method definition
	
  	// Register the method to expose
	$this->register('getAttributes', array('ORT_UUID' => 'xsd:string'), array( 'return' => 'tns:cAttributeArray'),
		'urn:RS2',
		'urn:RS2#getAttributes',
		'rpc', 'literal', 'With this webservice you get back all attributes of an object type.');
?>
