<?php
  
	// Define the method as a PHP function
	function addObjectType($newObjectType) { 
		try {
			// get access to the backen		
			global $backend;	
			if ( !$newObjectType['UUID'] ) {
				$OT = cObjectType::addObjectType( $newObjectType['name'] );			
				$UUID = $OT->UUID();
			}
			else {
				$OT = $backend->getObjectType( $newObjectType['UUID'] );
				$OT->addSubObjectType( $newObjectType['name'] );
				$UUID = $OT->UUID();
			}
			if ($UUID)
				return $UUID;
			else
				return false;
		}
		catch (Exception $e) {
			return new nusoap_fault('SOAP-ENV:Server','',$e->getMessage(),$e->getFile() . '(' . $e->getLine() . '): ' . $e->getTraceAsString());
		}
	}
	// End of method definition
	
	// New Complex type for input to addObjectType function
	$this->wsdl->addComplexType(
		'addObjectType',
		'complexType',	
		'struct',
		'all',
		'',
		array(	
			'UUID' => array ('name' => 'UUID', 'type' => 'xsd:string'),
			'name' => array ('name' => 'name', 'type' => 'xsd:string')	
		)		
	);
	
  	// Register the method to expose
	$this->register('addObjectType', array('addObjectType' => 'tns:addObjectType'), array('UUID' => 'xsd:string'),
		'urn:RS2',
		'urn:RS2#addObjectType',
		'rpc', 'literal', 'With this mehtod you can add new Object Types. Set UUID to false, if you want to add ObjectType on root level.');
		
?>