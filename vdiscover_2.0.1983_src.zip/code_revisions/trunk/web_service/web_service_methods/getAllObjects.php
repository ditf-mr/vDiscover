<?php

	// Define the method as a PHP function
	function getAllObjects($OT_UUID) { 
		try {
			// get access to the backend
			global $backend;	
			$OT = $backend->getObjectType($OT_UUID);
			
			if ( $OT ) {
				$Os = $OT->getObjects();

				$result = array();
				
				foreach ($Os as $O) {
					$resultCommmon = array( 'UUID' => $O->UUID(), 
											'changedAt' => $O->changedAt(), 
											'changedByP_UUID' => $O->changedByP_UUID());
					$resultNew['name'] = $O->name();
					$resultNew['common'] = $resultCommmon;
					$result[] = $resultNew;
					
					global $logHandler;
					$logHandler->debug($O->name());
				}		
			} 
			else 
				$result = false;
			return ( $result );
		} catch (Exception $e) {
			return new nusoap_fault('SOAP-ENV:Server','',$e->getMessage(),$e->getFile() . '(' . $e->getLine() . '): ' . $e->getTraceAsString());
		}
	}
	// End of method definition
	
  	// Register the method to expose
	$this->register('getAllObjects', array('OT_UUID' => 'xsd:string'),
		array('return' => 'tns:cObjectArray'),
		'urn:RS2',
		'urn:RS2#getAllObjects',
		'rpc', 'literal', 'With this webservice you get back all objects by type id.');
		
?>
