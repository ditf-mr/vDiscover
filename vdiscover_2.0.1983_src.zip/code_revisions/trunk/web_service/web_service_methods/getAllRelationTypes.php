<?php

	// Define the method as a PHP function
	function getAllRelationTypes() { 
		try {
			// get access to the backend
			global $backend;
			
			$RTs = $backend->getAllRelationTypes();

			$result = array();
			
			foreach ($RTs as $RT) {
				$resultCommmon = array( 'UUID' => $RT->UUID(), 
										'changedAt' => $RT->changedAt(), 
										'changedByP_UUID' => $RT->changedByP_UUID());
				$resultNew['name'] = $RT->name();
				$resultNew['common'] = $resultCommmon;
				$result[] = $resultNew;
			}		
			return ( $result );
		} catch (Exception $e) {
			return new nusoap_fault('SOAP-ENV:Server','',$e->getMessage(),$e->getFile() . '(' . $e->getLine() . '): ' . $e->getTraceAsString());
		}
	}
	// End of method definition
	
  	// Register the method to expose
	$this->register('getAllRelationTypes', array(),
		array('return' => 'tns:cRelationTypeArray'),
		'urn:RS2',
		'urn:RS2#getAllRelationTypes',
		'rpc', 'literal', 'With this webservice you get back all relation types.');

?>
