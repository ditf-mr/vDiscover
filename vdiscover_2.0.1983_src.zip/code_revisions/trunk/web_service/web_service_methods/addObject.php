<?php
	
	// Define the method as a PHP function
	function addObject($newObject) { 
		try {
			// get access to the backen		
			global $backend;	
			if ( $newObject['OT_UUID'] ) {
				$OT = $backend->getObjectType($newObject['OT_UUID']);
				if ($OT) {
					if ($newObject['name'] != "")
						$O = $OT->addObject( $newObject['name'] );
						
					else
						$O = $OT->addObject();		
					$UUID = $O->UUID();
					if ($O)
						return $O->toArray_WS();
				}
			}
			
				return new nusoap_fault('SOAP-ENV:Server','','Invalid OT_UUID','');
		}
		catch (Exception $e) {
			return new nusoap_fault('SOAP-ENV:Server','',$e->getMessage(),$e->getFile() . '(' . $e->getLine() . '): ' . $e->getTraceAsString());
		}
	}
	// End of method definition
	
	// New Complex type for input to addObjectType function
	$this->wsdl->addComplexType(
		'addObject',
		'complexType',	
		'struct',
		'all',
		'',
		array(	
			'OT_UUID' => array ('name' => 'OT_UUID', 'type' => 'xsd:string'),
			'name' => array ('name' => 'name', 'type' => 'xsd:string')	
		)		
	);
	
  	// Register the method to expose
	$this->register('addObject', array('addObject' => 'tns:addObject'), array( 'return' => 'tns:cObject'),
		'urn:RS2',
		'urn:RS2#addObject',
		'rpc', 'literal', 'With this mehtod you can add new Objects.');
		
?>
