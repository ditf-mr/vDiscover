<?php

	// Define the method as a PHP function
	function getAllObjectTypes() { 
		try {
			// get access to the backend
			global $backend;	
			$OTs = $backend->getAllObjectTypes();

			$result = array();
			
			foreach ($OTs as $OT) {
				$resultCommmon = array( 'UUID' => $OT->UUID(), 
										'changedAt' => $OT->changedAt(), 
										'changedByP_UUID' => $OT->changedByP_UUID());
				$resultNew['name'] = $OT->name();
				$resultNew['common'] = $resultCommmon;
				$result[] = $resultNew;
				
				global $logHandler;
				$logHandler->debug($OT->name());
			}		
			return ( $result );
		} catch (Exception $e) {
			return new nusoap_fault('SOAP-ENV:Server','',$e->getMessage(),$e->getFile() . '(' . $e->getLine() . '): ' . $e->getTraceAsString());
		}
	}
	// End of method definition
	
  	// Register the method to expose
	$this->register('getAllObjectTypes', array(),
		array('return' => 'tns:cObjectTypeArray'),
		'urn:RS2',
		'urn:RS2#getAllObjectTypes',
		'rpc', 'literal', 'With this webservice you get back all object types.');
		
?>
