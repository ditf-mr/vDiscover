<?php
	# --------------------------------------------------------------------------------------------
	# |                 vDiscover (Retrieval System for Stuctured Information)                   |
	# |------------------------------------------------------------------------------------------|
	# | Copyright (C) 2008-2014  DITF Denkendorf * K�rschtalstr. 26 * 73770 Denkendorf * Germany |
	# --------------------------------------------------------------------------------------------
	#
	{ # Constants
		{ # Object Types
			$OT_UUID_Assets = '3f687691-3cd7-11e4-bb29-26d7c45353a6'; # Object Type "Assets"
			$OT_UUID_Domain_Entity = '4cdd6733-3cd7-11e4-bb29-26d7c45353a6'; # Object Type "Domain Entity"
			$OT_UUID_Facilitators = 'b97b350f-7b09-11e4-92ef-f0def1d5a32e'; # Object Type "Facilitators"
			$OT_UUID_Opportunities = '33a88ed2-7b06-11e4-92ef-f0def1d5a32e'; # Object Type "Opportunities"
			$OT_UUID_Persons = '10000000-1000-1000-1000-00000000e000'; # Object Type "Persons"
			$OT_UUID_Requirements = '7c6969b6-3cd7-11e4-bb29-26d7c45353a6'; # Object Type "Requirements"
			$OT_UUID_Roles = '10000000-1000-1000-1000-00000000000e'; # Object Type "Roles"
			$OT_UUID_Suppliers = '30c75346-3cd7-11e4-bb29-26d7c45353a6'; # Object Type "Suppliers"
		}
		{ # Attributes of Objects Types
			{ # Attributes of "Assets"
				$OA_UUID_Assets_Name = '1b85aca0-3cd8-11e4-bb29-26d7c45353a6'; # Attribute "Name" of "Assets"
				$OA_UUID_Assets_Supplier = '384cfcca-3cd8-11e4-bb29-26d7c45353a6'; # Attribute "Supplier" of "Assets"
				$OA_UUID_Assets_Created_date = '1b85d794-3cd8-11e4-bb29-26d7c45353a6'; # Attribute "Created date" of "Assets"
				$OA_UUID_Assets_Domain_Entities = 'f1623b79-3cda-11e4-bb29-26d7c45353a6'; # Attribute "Domain Entities" of "Assets"
				$OA_UUID_Assets_Capacity = 'eaa72233-7ba2-11e4-9fc0-f0def1d5a32e'; # Attribute "Capacity" of "Assets"
				$OA_UUID_Assets_Cost = 'd549463a-7ba4-11e4-9fc0-f0def1d5a32e'; # Attribute "Cost" of "Assets"
				$OA_UUID_Assets_Quality = 'e9ed8690-7ba4-11e4-9fc0-f0def1d5a32e'; # Attribute "Quality" of "Assets"
			}
			{ # Attributes of "Domain Entity"
				$OA_UUID_Domain_Entity_Name__Domain_Keyword_ = '4cf49e8b-3cd9-11e4-bb29-26d7c45353a6'; # Attribute "Name (Domain Keyword)" of "Domain Entity"
				$OA_UUID_Domain_Entity_Requirements = 'e54daa32-3cda-11e4-bb29-26d7c45353a6'; # Attribute "Requirements" of "Domain Entity"
				$OA_UUID_Domain_Entity_Consists_of = '6a75ff41-7b0e-11e4-92ef-f0def1d5a32e'; # Attribute "Consists of" of "Domain Entity"
				$OA_UUID_Domain_Entity_Part_of = '6a764582-7b0e-11e4-92ef-f0def1d5a32e'; # Attribute "Part of" of "Domain Entity"
			}
			{ # Attributes of "Facilitators"
				$OA_UUID_Facilitators_Name = 'f905800a-7b09-11e4-92ef-f0def1d5a32e'; # Attribute "Name" of "Facilitators"
				$OA_UUID_Facilitators_Expertise = 'f905a7e6-7b09-11e4-92ef-f0def1d5a32e'; # Attribute "Expertise" of "Facilitators"
				$OA_UUID_Facilitators_Suppliers = '0c32433b-7b0a-11e4-92ef-f0def1d5a32e'; # Attribute "Suppliers" of "Facilitators"
			}
			{ # Attributes of "Opportunities"
				$OA_UUID_Opportunities_Name = '4f366436-7b06-11e4-92ef-f0def1d5a32e'; # Attribute "Name" of "Opportunities"
				$OA_UUID_Opportunities_Description = '2f8565a9-7b08-11e4-92ef-f0def1d5a32e'; # Attribute "Description" of "Opportunities"
				$OA_UUID_Opportunities_Source = '9cf20b51-7b08-11e4-92ef-f0def1d5a32e'; # Attribute "Source" of "Opportunities"
				$OA_UUID_Opportunities_Start_Date = '9cf2338f-7b08-11e4-92ef-f0def1d5a32e'; # Attribute "Start Date" of "Opportunities"
				$OA_UUID_Opportunities_End_Date = '9cf258c0-7b08-11e4-92ef-f0def1d5a32e'; # Attribute "End Date" of "Opportunities"
				$OA_UUID_Opportunities_Status = '9cf27d11-7b08-11e4-92ef-f0def1d5a32e'; # Attribute "Status" of "Opportunities"
				$OA_UUID_Opportunities_Relation_to__Requirements = 'a8908d34-7b09-11e4-92ef-f0def1d5a32e'; # Attribute "Relation to: Requirements" of "Opportunities"
			}
			{ # Attributes of "Persons"
				$OA_UUID_Persons_Name = '10000000-1000-1000-1003-00000000e000'; # Attribute "Name" of "Persons"
				$OA_UUID_Persons_User_name = '10000000-1000-1000-1001-00000000e000'; # Attribute "User name" of "Persons"
				$OA_UUID_Persons_Password = '10000000-1000-1000-1002-00000000e000'; # Attribute "Password" of "Persons"
				$OA_UUID_Persons_Roles = '10000000-1000-1000-1004-00000000e000'; # Attribute "Roles" of "Persons"
				$OA_UUID_Persons_Language = '10000000-1000-1000-1005-00000000e000'; # Attribute "Language" of "Persons"
				$OA_UUID_Persons_Country = '10000000-1000-1000-1006-00000000e000'; # Attribute "Country" of "Persons"
			}
			{ # Attributes of "Requirements"
				$OA_UUID_Requirements_Name = '82e1ea58-3cda-11e4-bb29-26d7c45353a6'; # Attribute "Name" of "Requirements"
				$OA_UUID_Requirements_Notice_Type = 'ae3be727-5549-11e4-8e3a-02004e435049'; # Attribute "Notice Type" of "Requirements"
				$OA_UUID_Requirements_Date_created = '82e212af-3cda-11e4-bb29-26d7c45353a6'; # Attribute "Date created" of "Requirements"
				$OA_UUID_Requirements_Date_completed = '82e2988e-3cda-11e4-bb29-26d7c45353a6'; # Attribute "Date completed" of "Requirements"
				$OA_UUID_Requirements_Description = '82e27463-3cda-11e4-bb29-26d7c45353a6'; # Attribute "Description" of "Requirements"
				$OA_UUID_Requirements_Target = 'c17cff5a-7bb5-11e4-9fc0-f0def1d5a32e'; # Attribute "Target" of "Requirements"
				$OA_UUID_Requirements_Delivery_date = '82e2f4bf-3cda-11e4-bb29-26d7c45353a6'; # Attribute "Delivery date" of "Requirements"
				$OA_UUID_Requirements_Currency = 'f2a06351-3cef-11e4-bb29-26d7c45353a6'; # Attribute "Currency" of "Requirements"
				$OA_UUID_Requirements_Domain_Keyword = 'e54ca7c4-3cda-11e4-bb29-26d7c45353a6'; # Attribute "Domain Keyword" of "Requirements"
				$OA_UUID_Requirements_Relation_to__Opportunities = 'a89242ab-7b09-11e4-92ef-f0def1d5a32e'; # Attribute "Relation to: Opportunities" of "Requirements"
				$OA_UUID_Requirements_Cost = 'd2b25a91-7bb6-11e4-9fc0-f0def1d5a32e'; # Attribute "Cost" of "Requirements"
				$OA_UUID_Requirements_Capacity = '288968a0-7bb8-11e4-9fc0-f0def1d5a32e'; # Attribute "Capacity" of "Requirements"
				$OA_UUID_Requirements_Quality = '28898ce2-7bb8-11e4-9fc0-f0def1d5a32e'; # Attribute "Quality" of "Requirements"
			}
			{ # Attributes of "Roles"
				$OA_UUID_Roles_Name = '10000000-1000-1000-1001-00000000000e'; # Attribute "Name" of "Roles"
			}
			{ # Attributes of "Suppliers"
				$OA_UUID_Suppliers_Supplier_name = 'd6502268-3cd7-11e4-bb29-26d7c45353a6'; # Attribute "Supplier name" of "Suppliers"
				$OA_UUID_Suppliers_Description = '88a260f9-3cec-11e4-bb29-26d7c45353a6'; # Attribute "Description" of "Suppliers"
				$OA_UUID_Suppliers_Email = 'd65076e3-3cd7-11e4-bb29-26d7c45353a6'; # Attribute "Email" of "Suppliers"
				$OA_UUID_Suppliers_Website = '396574ec-3cff-11e4-bb29-26d7c45353a6'; # Attribute "Website" of "Suppliers"
				$OA_UUID_Suppliers_Telephone_number = 'd6504dda-3cd7-11e4-bb29-26d7c45353a6'; # Attribute "Telephone number" of "Suppliers"
				$OA_UUID_Suppliers_Legal_form = '88aa25bb-3cec-11e4-bb29-26d7c45353a6'; # Attribute "Legal form" of "Suppliers"
				$OA_UUID_Suppliers_Building_name_or_number = 'd650cfa9-3cd7-11e4-bb29-26d7c45353a6'; # Attribute "Building name or number" of "Suppliers"
				$OA_UUID_Suppliers_Street_name = 'ffcfff2f-3cd7-11e4-bb29-26d7c45353a6'; # Attribute "Street name" of "Suppliers"
				$OA_UUID_Suppliers_Town_or_city = 'ffd02eeb-3cd7-11e4-bb29-26d7c45353a6'; # Attribute "Town or city" of "Suppliers"
				$OA_UUID_Suppliers_Country = 'ffd05a9b-3cd7-11e4-bb29-26d7c45353a6'; # Attribute "Country" of "Suppliers"
				$OA_UUID_Suppliers_Post_code = 'ffd081be-3cd7-11e4-bb29-26d7c45353a6'; # Attribute "Post code" of "Suppliers"
				$OA_UUID_Suppliers_Facilitator = '0c32e119-7b0a-11e4-92ef-f0def1d5a32e'; # Attribute "Facilitator" of "Suppliers"
				$OA_UUID_Suppliers_Assets = '8c17fd69-7bba-11e4-9fc0-f0def1d5a32e'; # Attribute "Assets" of "Suppliers"
			}
		}
		{ # Relation Types
			$RT_UUID_act_as_from_Persons_to_Roles  = '10000000-1000-1000-1000-0000000ac0a0'; # Relation Type "act as" / "assigned to" ["Persons" -> "Roles"]
			$RT_UUID_consists_of_from_Opportunities_to_Requirements  = 'a8907440-7b09-11e4-92ef-f0def1d5a32e'; # Relation Type "consists of" / "is part of" ["Opportunities" -> "Requirements"]
			$RT_UUID_consists_of_from_Domain_Entity_to_Domain_Entity  = '6a75ea36-7b0e-11e4-92ef-f0def1d5a32e'; # Relation Type "consists of" / "part of" ["Domain Entity" -> "Domain Entity"]
			$RT_UUID_has_asset_from_Suppliers_to_Assets  = '384b7bb5-3cd8-11e4-bb29-26d7c45353a6'; # Relation Type "has asset" / "is asset of" ["Suppliers" -> "Assets"]
			$RT_UUID_has_keyword_from_Assets_to_Domain_Entity  = 'f161c0f1-3cda-11e4-bb29-26d7c45353a6'; # Relation Type "has keyword" / "is keyword of" ["Assets" -> "Domain Entity"]
			$RT_UUID_has_keyword_from_Requirements_to_Domain_Entity  = 'e54c526e-3cda-11e4-bb29-26d7c45353a6'; # Relation Type "has keyword" / "is keyword of" ["Requirements" -> "Domain Entity"]
			$RT_UUID_manages_from_Facilitators_to_Suppliers  = '0c322d6b-7b0a-11e4-92ef-f0def1d5a32e'; # Relation Type "manages" / "is related with" ["Facilitators" -> "Suppliers"]
		}
		{ # Attributes of Relation Types
			{# Attributes of Relation Type "act as" / "assigned to" ["Persons" -> "Roles"]
			}
			{# Attributes of Relation Type "consists of" / "is part of" ["Opportunities" -> "Requirements"]
			}
			{# Attributes of Relation Type "consists of" / "part of" ["Domain Entity" -> "Domain Entity"]
				$RA_UUID_Specifity_of_consists_of_from_Domain_Entity_to_Domain_Entity = 'dae96456-7ba6-11e4-9fc0-f0def1d5a32e'; # Attribute "Specifity"
				$RA_UUID_Type_of_consists_of_from_Domain_Entity_to_Domain_Entity = '2a702c79-7ba7-11e4-9fc0-f0def1d5a32e'; # Attribute "Type"
			}
			{# Attributes of Relation Type "has asset" / "is asset of" ["Suppliers" -> "Assets"]
			}
			{# Attributes of Relation Type "has keyword" / "is keyword of" ["Assets" -> "Domain Entity"]
			}
			{# Attributes of Relation Type "has keyword" / "is keyword of" ["Requirements" -> "Domain Entity"]
			}
			{# Attributes of Relation Type "manages" / "is related with" ["Facilitators" -> "Suppliers"]
			}
		}
	} # end-of Constants

	# ---------------------------------------------------------------------------------------
	# created 2014.12.04 15:55:33 by admin tool "uuidList_asPHP.php"
	# end-of-file
?>