<div style="text-align:center;line-height:150%; padding-top: 20px; background-color: #ffa500;">
	<img align="center" style="height:50px;" src="../plugins/mova/ci/fitman_logo_small.png"/><br/>
	<div style="padding-top: 15px; font-size: 150%; font-width:bold;">Fitman MoVA Demo</div>
	<div style="font-size: 75%;"><a href="http://www.vdiscover.de" target="_blank" style="text-decoration: none; color: #000;">FITMAN MoVA</a></div>
</div>
<div style="text-align:left;line-height:150%; padding-top: 40px;">
	<p>This service offers an anonymous login without password. If you only want to browse or
	search Fitman MoVA Demo - click here:
	<div style="padding-top: 20px; padding-left: 30px;">
		<a href="?a=loginA" 
			style="padding: 3px; color: #000; 
				text-decoration: none;
				text-align: center; vertical-align: center; 
				border: 1px solid #b9bbdd; background-color: #c3d3e5; 
				padding: 6px 10px;">
			<img src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/go-next-7.png" hspace="5">
			Anonymous Login
		</a>
	</div>
</div>
