<div style="text-align:center;line-height:150%; padding-top: 20px; background-color: #ccc;">
	<img align="center" style="height:50px;" src="../plugins/mova/ci/fitman_logo_small.png"/><br/>
	<div style="font-size: 75%;"><a href="http://www.vdiscover.de" target="_blank" style="text-decoration: none; color: #000;">FITMAN MoVA</a></div>
</div>
