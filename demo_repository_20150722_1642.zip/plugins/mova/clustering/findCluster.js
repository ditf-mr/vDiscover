/**
 * "Find Cluster"
 * MOVA - Plugin for Retrieval System for Structured Information   [RS_2]
 * 
 * @author konrad.pfleiderer@ditf-mr-denkendorf.de
 * @version 1.0
 */

 
// -------------------------------------------------------------------------------------------------
// Registration of the Menu Items
// -------------------------------------------------------------------------------------------------


	application.O_menubar_itemKinds.register({
		name: "[Find cluster]", 
		UUID: "O_menubar_itemKinds.plugin.Mova.findCluster",
		JS_command: function (O_v_UUID, tabContainer_widgetId) {
				plugins.mova.findCluster.startDialog(
					O_v_UUID, 
					tabContainer_widgetId
				);
			},
			description: '<p>Will open a dialog, that search the clusters.</p>'
	});

	
// -------------------------------------------------------------------------------------------------
// Declaration of the Dojo Classes
// -------------------------------------------------------------------------------------------------


	dojo.declare(
		'plugin_classes.mova.findCluster', 
		[], 
		{

			// Internal Slots ----------------------------------------------------------------------

			'O_v_UUID': null,				// The UUID of a piece.
			'tabContainer_widgetId': null,	// The widget id of the tab container, in which the 
											// piece is displayed.
										
			'_dialog': null,	// the dialog widget
			'_connects': null,	// list of dojo.connect
			
								
			// Constructor -------------------------------------------------------------------------
			
			'constructor' : function () {
				this._connects = [];
			}, // end-of-method constructor

			
			// Public Methods ----------------------------------------------------------------------
			
			'startDialog': function (O_v_UUID, tabContainer_widgetId) {
				/**
				 * Entrance point of the "analyseDefects" menu item.
				 *
				 * @param O_v_UUID string. The UUID of the fabric object currently displayed.
				 * @param tabContainer_widgetId integer. The widget id of the tab container.
				 */
				{ // Save parameters
					this.O_v_UUID = O_v_UUID;
					this.tabContainer_widgetId = tabContainer_widgetId;
				}
				{ // Check if object is in edit mode and show hint
					var tabContainer = dijit.byId(this.tabContainer_widgetId);
					var objectTab = tabContainer.getParent();
					if (objectTab.isInEditMode()) {
						alert('It\'s not possible to use this function during edit mode, because '
							+'this would lead to invalid results. '
							+'Please save or discard the changes you\'ve been made, first.');
					}
					else {
						{ // Delete dialog if ist exists
							if (this._dialog) {
								this.closeDialog();
							}
						}
						{ // Open dialog
							this._dialog = new plugin_classes.mova.findCluster.dialog(
								{
									'O_v_UUID': this.O_v_UUID,
								}
							)
							this._connects.push(dojo.connect(this._dialog, 'onClose', this, 'closeDialog'));
							this._dialog.show();		
							this._dialog.resize();
						}
						{ // step aufrufen
							this._dialog._step();
						}
					}
				}
			}, // end-of-method startDialog


			'closeDialog': function () {
				/**
				 * Close the dialog save in slot '_dialog' and destroys all elements and actualize
				 * the current pane.
				 */
				// Close dialog
				this._dialog.hide();
				this._dialog.destroyRecursive(false);
				delete this._dialog;
				
				// Update the current view in the tab container
				var currentView = dijit.byId(this.tabContainer_widgetId).selectedChildWidget;
				var viewContentPane = currentView.widgets.viewContentPane;
				viewContentPane.refreshContents('actualise');
			}, // end-of-method closeDialog
			
			
			'dummySlotToMarkEndOfClass': null
			
		}
	) // end-of-declare
	

	/** 
	 * Dialog that handles "findCluster"
	 */

	dojo.declare(
		'plugin_classes.mova.findCluster.dialog', 
		[common.widgets.fixedSizeDialog], 
		{
		
			'O_v_UUID': null,	// The UUID of the piece object currently displayed.
			// Memory for values from backend
			'_assetsWithBenchmark': [],		// list of assets with benchmark

			'_widgets': null,	// list of sub widgets of the dialog
			'innerHeight': 650,	// maximum and prefered (inner) height of the dialog
			'innerWidth': 1000,	// maximum and prefered (inner) width of the dialog

			
			// Constructor -------------------------------------------------------------------------
		
			'constructor': function () {
				this._widgets = {};
			}, // end-of-method constructor
			
			
			// Public Methods ----------------------------------------------------------------------
		
			'postMixInProperties' : function () {
				this.inherited(arguments);
				this.title = 'Searching for clusters...';
			}, // end-of-method postMixInProperties
						

			'buildRendering': function () {
				this.inherited(arguments);
				{ // Create a border container for all contents. Container will get 2 children at
				  // the positions center and bottom
					this._widgets.borderContainer = new dijit.layout.BorderContainer({
						'style': 'width: 100%; height: 95%;',
						'gutters': false
					});
					this._widgets.borderContainer.placeAt( 
						dojo.create( 
							'DIV', 
							{'style': 'width: 100%; height: 100%;'}, 
							this.containerNode
						) 
					);
				}				
				{ // Create button pane (bottom position)
					this._widgets.buttonPane = new dijit.layout.ContentPane({
						'region': 'bottom',
						'content': ''
							+'<div dojoType="dijit.form.Button" dojoAttachPoint="buttonClose" style="float:right;">Close</div>',
						'style': 'margin-top:1.0em;'
					});
					this._widgets.borderContainer.addChild(this._widgets.buttonPane);
					{ // Collect all relevant children of the button pane
						var buttonPaneChildren = this._widgets.buttonPane.getChildren();
						dojo.forEach(
							buttonPaneChildren, 
							function (child) {
								if (child.dojoAttachPoint) {
									this._widgets[child.dojoAttachPoint] = child;
								}
							}, 
							this
						);
					}
					{ // Disable not relevant buttons
						dojo.style( this._widgets.buttonClose.domNode, 'display', 'inline-block' );
					}
				}
				{ // Create a "waiting" pane to be shown occasionally
					this._widgets.waitingPane = new dijit.layout.ContentPane({
						'class' : 'loading',
						'region' : 'center',
						'content' : '<p>Communicating with server</p>',
					});
				}
			}, // end-of-method buildRendering
			
			
			'startup': function () {	
				this.inherited(arguments);				
				this._widgets.borderContainer.startup();
				this.connect(this._widgets.buttonClose, 'onClick', '_stepFinal');
			}, // end-of-method startup			
			
			'destroy': function () {
				for(var i in this._widgets) {
					this._widgets[i].destroy();
					delete this._widgets[i];
				}
				this.inherited(arguments);
			}, // end-of-method destroy
			
			
			// Private Methods ---------------------------------------------------------------------
			
			'_showWaitingPane': function (msg) {
				{ // Remove all children in the border container
					var cArr = this._widgets.borderContainer.getChildren();
					dojo.forEach(cArr, function (c) {
						this._widgets.borderContainer.removeChild(c);
					}, this);
				}
				{ // Add the waiting pane
					this._widgets.borderContainer.addChild(this._widgets.waitingPane);
				}
				{ // Set the message
					this._widgets.waitingPane.set('content', msg);
				}
			}, // end of method _showWaitingPane
			
			
			'_hideWaitingPane': function () {
				{ // Remove waitingPane
					this._widgets.borderContainer.removeChild(this._widgets.waitingPane);
				}
				{ // Show the button pane
					this._widgets.borderContainer.addChild(this._widgets.buttonPane);
				}
			}, // end-of-method _hideWaitingPane
			
			
			'_step': function() {
				{ // Call backend 					
					backendCallOk0 = this._callClusterLayer(0);
					backendCallOk1 = this._callClusterLayer(1);
					backendCallOk2 = this._callClusterLayer(2);
				}
				if ((!backendCallOk0) || (!backendCallOk1) || (!backendCallOk2)) {
					return;		
				}
				else {
					{ // Output amin action 
						if (this._assetsWithBenchmark != '') {							
							
							output0 = this._outputTree(this._assetsWithBenchmark[0]);
							output1 = this._outputTree(this._assetsWithBenchmark[1]);							
							output2 = this._outputTree(this._assetsWithBenchmark[2]);
							
							this._widgets.communicationPane = new dijit.layout.ContentPane({
								'region'	: 'top',
								'style'		: 'height: 95%; overflow: auto;',
								'content'	: ''
									+'<p margin: 10px 0;">'
									+'<h3>Level0</h3>'
									+'<h4>Found Assets</h4>'
									+output0
									+'<h3>Level1</h3>'
									+'<h4>Found Assets</h4>'
									+output1									
									+'<h3>Level2</h3>'
									+'<h4>Found Assets</h4>'
									+output2
									+'</p>',
							});
							this._widgets.borderContainer.addChild(this._widgets.communicationPane);
						}
					}
				}
			}, // end-of-method _step
					
			'_stepFinal': function(event) {
				dojo.stopEvent(event);
				this.onClose();
			}, // end-of-method _stepFinal
			
			'_outputTree': function(assetsWithBenchmark) {
				var output;
				domainName = assetsWithBenchmark.domainName;				
				{ // HTML
					var output = '';
					output += '<div style="height: auto;"><div style="border: 1px solid; width: 150px; margin-right: 50px; margin-bottom: 1px; float: left">' + domainName + '</div>';
					if (assetsWithBenchmark.assets) {
						output += '<div><ul>';
						assets = assetsWithBenchmark.assets;
						for (var i = 0, len = assets.length; i < len; i++) {
							output += '<li><strong><a onclick="application.O.show(\'' + assets[i]['asset']['O_v_UUID'] + '\')" href="#">' +	
							assets[i]['asset']['name'] + 
							'</a></strong>'	+ 
							' ' + 
							assets[i]['benchmark']['value'] + 
							' ' + 
							assets[i]['benchmark']['unit'] + 
							' ( ' + 
							assets[i]['benchmark']['parts'] + 
							' ) ' +
							'</li>';									
						}
						output += '</ul></div>\n';
					}				
					if (assetsWithBenchmark.subdomains) {
						output += '<div style="clear: both; padding-left: 50px;">';
						var subdomains = assetsWithBenchmark.subdomains;
						for (var i = 0, len = subdomains.length; i < len; i++) {							
							if (subdomains[i].consistsOf) {
								output += '<div style="width:50px; text-align: right; padding-right: 5px; float:left;">' + subdomains[i].consistsOf.value.toFixed(2) + ' ' + subdomains[i].consistsOf.unit + '</div>';
							}
							output += this._outputTree(subdomains[i].domain);
						}
						output += '&nbsp;</div>\n';
					}
					output += '&nbsp;</div>\n';
				}
				return output;
			}, //end-of-method _outputTree
			
			'_callClusterLayer': function (layer) {
				/**
				 * Asks the backend for the list of clusters on layer0
				 * @return true. On success.
				 * @return false. On failure. 
				 */
				var returnValue = true;
				dojo.xhrPost({
					"url": "../plugins/mova/clustering/index.php",
					"content": { 
						"layer": layer,
						"O_v_UUID": this.O_v_UUID
					},
					'scope' : this,
					"error": application.AJAX_errorMessage,
					"handleAs": "json",
					"load": function (reply, XHRObj) {
						if (reply.message) {
							alert('Error\n\n'+reply.message);
						}
						// if (reply.status != 'ok') {
							// returnValue = false;
						// }
						else {
							XHRObj.args.scope._assetsWithBenchmark[layer] = reply.assetsWithBenchmark;
						}
					}, // end-of-method load
					sync: true
				});
				
				
				//TODO return in case of error????
				return(returnValue); 
			}, // end-of-method _callClusterLayer0			
					
			'dummySlotToMarkEndOfClass': null
			
		}
	) // end-of-declare

	
// -------------------------------------------------------------------------------------------------
// Some Initialisations
// -------------------------------------------------------------------------------------------------

	// Ensure existance of plugin_classes.mova.findCluster
	if (typeof plugins != 'object') {
		plugins = {};
	}
	if (typeof plugins.mova != 'object') {
		plugins.mova = {};
	}
	
	plugins.mova.findCluster = new plugin_classes.mova.findCluster({});