<?php

	define('INTERFACE', 'plugin');
	{ # get repository information
		{ # get repository_config using relative path
			require_once(__DIR__.DIRECTORY_SEPARATOR
				.str_repeat('..'.DIRECTORY_SEPARATOR, 3)
				.'index.php');
		}
		define('APPLICATION_started', true);
		{ # get file, which contains function to expand paths in repository_config
			require_once(__DIR__.DIRECTORY_SEPARATOR
				.str_repeat('..'.DIRECTORY_SEPARATOR, 5)
				.'code_revisions'.DIRECTORY_SEPARATOR
				.$repository_config['code_version'].DIRECTORY_SEPARATOR
				.'information_structure'.DIRECTORY_SEPARATOR.
				'utilities.php'
			);
			$repository_config = expandPathsIn_repository_config($repository_config);	
		}
		{ # branch, if there is not repository_config
			if ( ! $repository_config ) {
				header('Location: ../../..');
				exit;
			}
		}
	}

	set_time_limit(200);
	{ # load configuration
		require_once($repository_config['application_path'].DIRECTORY_SEPARATOR.'config.php');
	}
	{ # load some useful functions, classes, methods ...
		require_once($repository_config['application_path'].DIRECTORY_SEPARATOR.'utilities.php');
	}
	{ # load and initialise global log files handler 
		require_once($repository_config['root_path'].DIRECTORY_SEPARATOR.'utilities'.DIRECTORY_SEPARATOR.'cLogHandler.php');
		$logHandler = new cLogHandler($repository_config['path_logs']);
	}
	{ # load exceptions
		require_once( realpath($repository_config['application_path'].DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'utilities'.DIRECTORY_SEPARATOR.'exceptions.php') );		
	}
	{ # load backend module and create cBackend instance
		require_once($repository_config['application_path'].DIRECTORY_SEPARATOR.'backend'.DIRECTORY_SEPARATOR.'loadBackend.php' );
	}
	{ # start session if via browser
		session_start();
		session_cache_expire(cSystem::sessionTimeout());
	}
	{ # load TANET specific scripts
		require_once('getClusters.json/clusteringFunctions.inc.php');	
	}
	try { 

		{ # check if user is logged in
			if (!$backend->isLoggedIn()) {
				throw new Exception('Access denied. Login in first.');
			}
		}
		{ # start http output 
			header('Content-type: application/json');
		}

		{ # get task parameter and select
			$O_v_UUID = sanitize_string($_POST, 'O_v_UUID', $_GET);
			$layer = sanitize_string($_POST, 'layer', $_GET);
			
			{ # Some preparation works		
				{ # Include uuidList
					include_once($plugInPath.DIRECTORY_SEPARATOR.'uuidList.php');
				}		
				{ # Load object				
					{ # Load Requirements Object
						if ( is_null($O_Requirements = $backend->getObject($O_v_UUID)) ) {
							throw new Exception('Object with O_UUID="'.$GLOBALS['O_v_UUID'].'" not found.');
						}
					}
				}
			}
			{ # Action
				$returnValue = getClusters($O_Requirements, $layer );
				echo json_encode( array ( "assetsWithBenchmark" => $returnValue ));
			}
		}
	}
	catch ( Exception $e ) {
		header('HTTP/1.1 500 Internal Server Error');
		$GLOBALS['logHandler']->debug($e);
		echo 
			json_encode( 
				array(
					'type'		=> 'Exception',
					'message'	=> $e->getMessage(),
					'code'		=> $e->getCode(),
					'file'		=> $e->getFile(),
					'line'		=> $e->getLine(),
					'trace'		=> $e->getTraceAsString()
				)
			);
	} # end-of-trycatch

?>