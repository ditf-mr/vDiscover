<?php
	$plugInPath = __DIR__.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR;
	
	/**
	 * Inputs for this function are:
	 * - the O_V_UUID of the requirement
	 * The script searches for all assets related to same domain as the requirement is related and do a benchmark
	 * Workflow:
	 * - Search for related Domains
	 */
	 
	function getAssetsWithBenchmark( $O_Domain, $requirements ) {
		global $logHandler;
		
		include('../uuidList.php');
		
		$returnValue = array();
		
		$O_DomainAttr = $O_Domain->getAttributeValueSets();	
					
		//$logHandler->debug("DomainAttr", $O_DomainAttr);

		#Searching for related Assets
		$Rs_from_Assests_to_Domain = $O_Domain->getRelations_asEnd( $RT_UUID_has_keyword_from_Assets_to_Domain_Entity );
		foreach ( $Rs_from_Assests_to_Domain as $R_from_Assests_to_Domain ) {
			// $logHandler->debug("Relation to asset", $R_from_Assests_to_Domain);
			$O_Asset = $R_from_Assests_to_Domain->Start_O();
			#Reading relevant attributes of the Assets
			$O_AssetAttributes = $O_Asset->getAttributeValueSets();
			// $logHandler->debug("Asset", $O_Asset);
			// $logHandler->debug("AssetAttr", $O_AssetAttributes);
			// $logHandler->debug("xxx", $O_AssetAttributes[$OA_UUID_Assets_Capacity]['values']);
			
			$O_AssetCapacityAsObject = array_shift($O_AssetAttributes[$OA_UUID_Assets_Capacity]['values']);					
			$O_AssetCapacity = $O_AssetCapacityAsObject->value_listKey();
			
			$O_AssetCostAsObject = array_shift($O_AssetAttributes[$OA_UUID_Assets_Cost]['values']);					
			$O_AssetCost = $O_AssetCostAsObject->value_listKey();
						
			$O_AssetQualityAsObject = array_shift($O_AssetAttributes[$OA_UUID_Assets_Quality]['values']);					
			$O_AssetQuality = $O_AssetQualityAsObject->value_listKey();
			
			$O_RequirementsAssetsBenchmark = $requirements['O_RequirementCapacity'] * $O_AssetCapacity + $requirements['O_RequirementCost'] * $O_AssetCost +$requirements['O_RequirementQuality'] * $O_AssetQuality;
			
			$foundAsset = array();
			$foundAsset['O_v_UUID'] = $O_Asset->O_v_UUID();
			$foundAsset['name'] = $O_Asset->name();
			
			$foundAssetGroup = array();
			$foundAssetGroup['asset'] = $foundAsset;
			
			$foundAssetGroup['benchmarkValue'] = $O_RequirementsAssetsBenchmark;
			$foundAssetGroup['benchmark']['value'] = $O_RequirementsAssetsBenchmark;
			$foundAssetGroup['benchmark']['unit'] = $requirements['O_RequirementsAssetsBenchmarkUnit'] ;
			$foundAssetGroup['benchmark']['parts'] = "Capacity: " . $O_AssetCapacity . " / Cost: " . $O_AssetCost . " / Quality: " . $O_AssetQuality;
			
			$returnValue[] = $foundAssetGroup;
		}
		return $returnValue;
	}
	
	function getLayer( $O_Domain, $layer, $requirements ) {
		include('../uuidList.php');
		
		$returnValue = array();
		
		$O_DomainAttributes = $O_Domain->getAttributeValueSets();
		$O_DomainNameAsObject = array_shift($O_DomainAttributes[$OA_UUID_Domain_Entity_Name__Domain_Keyword_]['values']);
		$returnValue['domainName'] = $O_DomainNameAsObject->value_text();
		
		if ( $layer > 0 ) { #decend to next deeper level			
			$returnValue['subdomains'] = array();
			$layer--;
			
			$Rs_from_Domain_Entity_to_Domain_Entity = $O_Domain->getRelations_asStart( $RT_UUID_consists_of_from_Domain_Entity_to_Domain_Entity );
			$subdomains = array();
			$consistsOfSum = 0;
			
			foreach ( $Rs_from_Domain_Entity_to_Domain_Entity as $R_from_Domain_Entity_to_Domain_Entity ) {
				$subdomain = array();
				$subdomain['domainObject'] = $R_from_Domain_Entity_to_Domain_Entity->End_O();
				
				$O_DomainRelationAttributes = $R_from_Domain_Entity_to_Domain_Entity->getAttributeValueSets();
				
				$O_DomainRelationConsitsOfAsObject = array_shift($O_DomainRelationAttributes[$RA_UUID_Specifity_of_consists_of_from_Domain_Entity_to_Domain_Entity]['values']);					
				$subdomain['consistsOf'] = $O_DomainRelationConsitsOfAsObject->value_number();
				$consistsOfSum += $subdomain['consistsOf'];
				$subdomains[] = $subdomain;
			}
			
			for ( $i=0; $i < count ($subdomains); $i++) { # consists of normalisieren
				$consitsOf = array();
				$consitsOf['calc'] = $subdomains[$i]['consistsOf'] / $consistsOfSum * 100;
				$consitsOf['value'] = round($subdomains[$i]['consistsOf'] / $consistsOfSum * 100, 2);
				$consitsOf['unit'] = "%";
				
				$subdomains[$i]['consistsOf'] = $consitsOf;
				$subdomains[$i]['consistsOfValue'] = $consitsOf['value'];
			}
			
			$consistsOfValue = array();
			foreach ($subdomains as $key => $row) {
				$consistsOfValue[$key] = $row['consistsOfValue'];
			}
			array_multisort($consistsOfValue, SORT_DESC, $subdomains);
			$returnRemoveConsistsOfValueFromTop = array();
			foreach ($subdomains as $subdomainsElement) {
				unset($subdomainsElement['consistsOfValue']);
				$returnRemoveConsistsOfValueFromTop[] =  $subdomainsElement;
			}
			$subdomains = $returnRemoveConsistsOfValueFromTop;
			
			foreach ($subdomains as $subdomain) {
				$subdomain['domain'] = getLayer( $subdomain['domainObject'], $layer, $requirements );				
				unset($subdomain['domainObject']);
				$returnValue['subdomains'][] = $subdomain;
			}
			  
			global $logHandler;
			
			$logHandler->debug("layer", $layer);
			$logHandler->debug("return", $returnValue);

			} else {
				$foundAssets = array();
				$foundAssets = getAssetsWithBenchmark( $O_Domain, $requirements );
				if (count($foundAssets) > 0) {
					foreach ($foundAssets as $key => $row) {
						$benchmarkValue[$key] = $row['benchmarkValue'];
					}
					array_multisort($benchmarkValue, SORT_DESC, $foundAssets);
					$returnRemoveBenchmarkValueFromTop = array();
					foreach ($foundAssets as $foundAssetsElement) {
						unset($foundAssetsElement['benchmarkValue']);
						$returnRemoveBenchmarkValueFromTop[] =  $foundAssetsElement;
					}
					$foundAssets = $returnRemoveBenchmarkValueFromTop;
					$returnValue['assets'] = $foundAssets;
				}
				else {
					$returnValue = getLayer( $O_Domain, 1, $requirements );				
				}
			}
		return $returnValue;
	}
	 
	function getClusters( $O_Requirement, $layer = 0, $recursive = false ) {
		global $logHandler;
		
		include('../uuidList.php');	 
	 
		$returnValue = array();
			
		$requirements = array();
				
		#Reading relevant attributes of the Requirements
		$O_RequirementsAttributes = $O_Requirement->getAttributeValueSets();	
		
		$O_RequirementCapacityAsObject = array_shift($O_RequirementsAttributes[$OA_UUID_Requirements_Capacity]['values']);					
		$requirements['O_RequirementCapacity'] = $O_RequirementCapacityAsObject->value_number();
		
		$requirements['O_RequirementsAssetsBenchmarkUnit']  = $O_RequirementCapacityAsObject->unit();
				
		$O_RequirementCostAsObject = array_shift($O_RequirementsAttributes[$OA_UUID_Requirements_Cost]['values']);					
		$requirements['O_RequirementCost'] = $O_RequirementCostAsObject->value_number();
		
		$O_RequirementQualityAsObject = array_shift($O_RequirementsAttributes[$OA_UUID_Requirements_Quality]['values']);					
		$requirements['O_RequirementQuality'] = $O_RequirementQualityAsObject->value_number();
							
		#Searching for related Domains			
		$Rs_from_Requirements_to_Domain = $O_Requirement->getRelations_asStart( $RT_UUID_has_keyword_from_Requirements_to_Domain_Entity );
		$O_Domains = array();			
		foreach ( $Rs_from_Requirements_to_Domain as $R_from_Requirements_to_Domain ) {
			$O_Domains[] = $R_from_Requirements_to_Domain->End_O();
		}
		
		foreach ($O_Domains as $O_Domain) {
			$returnValue = getLayer($O_Domain, $layer, $requirements );
		}

		
		#Return				
		return $returnValue;
	 }
?>