<?php if (!defined('APPLICATION_started')) {header('Location: .');exit;} 
 /*
Retrieval System for Structured Information

The retrieval system for structured information is a ontology-based expert system
with case-based reasoning functionality especially designed for small and medium enterprises.

Copyright (C) 2008  DITF Denkendorf * Körschtalstr. 26 * 73770 Denkendorf * Germany

This program is free software; you can redistribute it and/or modify it under the
terms of the GNU General Public License as published by the Free Software
Foundation; either version 3 of the License, or any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this
program; if not, see <http://www.gnu.org/licenses/>.
*/

$plugInPath = '../plugins/mova/';

{ # CI
	$subPlugInPath = $plugInPath.'ci/';
	{ # css file
		$r->register_cssFile( $subPlugInPath.'fitman.css' );
	}
	{ # welcome page
		$r->set_configOption( 'welcomePage_title', 	'Overview' );
		$r->set_configOption( 'welcomePage_URL', 	$subPlugInPath.'welcomePage.php' );
	}
	{ # title window in upper left corner, logo and favicon
		$r->set_configOption( 'appTitle_HTTP_path', $subPlugInPath.'applicationTitle.php' );
		$r->set_configOption( 'appTitle_height', 	'180px' );
		$r->set_configOption( 'appTitle_favIcon', 	$subPlugInPath.'favicon.ico' );
	}
}
{ # Additional Functions
	$subPlugInPath = $plugInPath.'clustering/';
	{ # 
		$r->register_JavaScriptFile($subPlugInPath.'findCluster.js');
	}
}

?>