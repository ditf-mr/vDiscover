<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	/** This tool deletes all objects of either some object types.
	 *
	 * @param OTs string. Either the name of an object type or a list of names (comma separated) of 
	 *	the object types, whose objects should be deleted. 
	 * @param delimiter string. The separator, if no comma should be used.
	 */ 
	
	{ # check for help
		if ($help) {
			_echo('deleteObjectsBy_OT_name');
			_echo('This tool deletes all objects of either some object types.');
			_echo('params: "OTs", "delimiter"');
			_echo('"OTs" (string): Either the name of an object type or a list of names (comma '
				.'separated) of the object types, whose objects should be deleted. ');
			_echo('"delimiter" (string): The separator, if no comma should be used.');
			exit;
		}
	}
	{ # get script parameter
		$OTs = isset($arguments['OTs'])?$arguments['OTs']:'';
		$delimiter = isset($arguments['delimiter'])?$delimiter:',';
	}
	{ # check if logged in user is admin
		if (!$backend->currentUser('isAdmin')) {
			throw new incorrectInputDataException('Insufficient privilege. You are not an admin.');
		}
	}
	{ # check if a object type is given
		if (empty($OTs)) {
			_die('Parameter "OTs" is empty. No work to do.');
		}
	}
	{ # elaborate list of object type names and process corresponding object type
		$OT_names = explode($delimiter, $OTs);
		$objectTypes = array();
		foreach($OT_names as $name) {
			if (substr($name, 0, 1) == '"') {
				$name = substr($name, 1, strlen($name)-2);
			}
			$message = 'Object type "'.$name.'": '.$br;
			$objectTypes = cObjectType::getBy_name($name);
			switch(count($objectTypes)) {
				case 0: {
					_echo($message.'not found.');
					break;
				}
				case 1: {
					$objectType = current($objectTypes);
					_echo($message.$objectType->deleteObjects().' objects deleted.');
					break;
			}
				default: {
					_echo($message.'found more than once.');
					break;
				}
			}
		}
	}
	_echo('Work done.');
	
?>