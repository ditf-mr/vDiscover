<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	/** This tool generates a list of UUIDs as php code fragment. You may use this code
	 * fragment to easily access the relevant UUIDs in input routines.
	 * 
	 * UUIDs of the following instances or supported:
	 * - object types
	 * - attributes of object types
	 * - relation types
	 * - attributes of relation types
	 *
	 * @param noRelationTypes. If set, no information (uuids) of relation types is printed.
	 * @param noAttributes. If set, no information (uuids) of attributes is printed.
	 */
	
	{ # check for help
		if ($help) {
			_echo('uuidList_asPHP');
			_echo('This tool generates a list of UUIDs as php code fragment. You may use this code '
				.'fragment to easily access the relevant UUIDs in input routines.'.$br
				.'UUIDs of the following instances or supported:'.$br
				. '- object types'.$br
				. '- attributes of object types'.$br
				. '- relation types'.$br
				. '- attributes of relation types');
			_echo('params: "noRelationTypes", "noAttributes", "load"');
			_echo('"noRelationTypes": if set, no information (uuids) of relation types is generated.');
			_echo('"noAttributes": if set, no information (uuids) of attributes is generated.');
			_echo('"load": if set, code for loading object and relation types is included.');
			exit;
		}
	}
	{ # get script parameter
		$noRelationTypes = isset($arguments['noRelationTypes']);
		$noAttributes = isset($arguments['noAttributes']);
	}
	{ # check if logged in user is admin
		if (!$backend->currentUser('isAdmin')) {
			throw new incorrectInputDataException('Insufficient privilege. You are not an admin.');
		}
	}
	{ # send header information
		header('Content-type: text/plain');
		header('Content-Disposition: attachment; filename="uuidList.php"');
	}
	{ # send introduction / header of file
		sendHeader();
	}
	{ # generate and output the content
		$indentLevel = 1;
		{ # get all object types
			$objectTypes = $backend->getAllObjectTypes();
		}
		{ # get all relation types
			$relationTypes = $backend->getAllRelationTypes();
		}
		{ # constant section
			{ # send header of constant section
				echo indent($indentLevel) . '{ # Constants' . $nl;
			}
			{ # object types
				echo outputObjectTypes($objectTypes, $indentLevel+1);
			}
			{ # attributes of object types
				if (!$noAttributes) {
					echo outputAttributesOfObjectTypes($objectTypes, $indentLevel+1);
				}
			}
			{ # relation types
				if (!$noRelationTypes) {
					echo outputRelationTypes($relationTypes, $indentLevel+1);
				}
			}
			{ # attributes of relation types
				if (!$noRelationTypes and !$noAttributes) {
					echo outputAttributesOfRelationTypes($relationTypes, $indentLevel+1);
				}
			}
			{ # send header of constant section
				echo indent($indentLevel) . '} # end-of Constants' . $nl;
			}
		}
	}
	{ # send footer of file
		sendFooter();
	}
	
	
	function phpConform($word) {
		/** Deletes all characters that are not allowed in php constants.
		 * For the regular expression see http://de3.php.net/manual/en/language.constants.php
		 */
		// return (substr(preg_replace('/[^a-zA-Z0-9_\x7f-\xff]/', '_', $word), 0, 30));
		return (substr(preg_replace('/[^a-zA-Z0-9]/', '_', $word), 0, 30));
	} # end-of-function phpConformWord
	

	function indent($level=0) {
		/** Creates string with tab characters for indentation.
		 * @return string
		 */
		return(str_repeat("\t", $level));
	} # end-of-function indent
	
	
	function sendHeader() {
		/** Sends/outputs the header of the file, containing title, copyright and information.
		 */
		echo<<<block
<?php
	# --------------------------------------------------------------------------------------------
	# |                 vDiscover (Retrieval System for Stuctured Information)                   |
	# |------------------------------------------------------------------------------------------|
	# | Copyright (C) 2008-2014  DITF Denkendorf * K�rschtalstr. 26 * 73770 Denkendorf * Germany |
	# --------------------------------------------------------------------------------------------
	#

block;
	} # end-of-function sendHeader
	
		
	function sendFooter() {
		/** Send/outputs the footer of the file, containing creation date.
		 */
		$now = date('Y.m.d H:i:s');
		echo<<<block

	# ---------------------------------------------------------------------------------------
	# created {$now} by admin tool "uuidList_asPHP.php"
	# end-of-file
?>
block;
	} # end-of-function sendFooter
	

	function outputObjectTypes($objectTypes, $indentLevel=0) {
		/** Create output for object types of the constant section.
		 * @return string
		 */
		global $nl;
		$rv = '';
		{ # output header
			$rv .= indent($indentLevel) . '{ # Object Types' . $nl;
		}
		foreach($objectTypes as $objectType) {
			$nameOfConstant = ''
				. 'OT_UUID_' 
				. phpConform($objectType->name());
			$rv .= indent($indentLevel+1) . '$' . $nameOfConstant . ' = \'' . $objectType->UUID() . '\'; # Object Type "' . $objectType->name() . '"' . $nl;
		}
		{ # output footer
			$rv .= indent($indentLevel) . '}' . $nl;
		}
		return($rv);
	} # end-of-function outputObjectTypes
	
	
	function outputRelationTypes($relationTypes, $indentLevel=0) {
		/** Create output for relation types of the constant section.
		 * @return string
		 */
		global $nl;
		$rv = '';
		{ # output header
			$rv .= indent($indentLevel) . '{ # Relation Types' . $nl;
		}
		foreach($relationTypes as $relationType) {
			$nameOfConstant = ''
				. 'RT_UUID_' 
				. phpConform($relationType->name())
				. '_from_'
				. phpConform($relationType->Start_OT()->name())
				. '_to_'
				. phpConform($relationType->End_OT()->name());
			$rv .= indent($indentLevel+1) . '$' . $nameOfConstant .'  = \'' . $relationType->UUID() 
				. '\'; # Relation Type "' . $relationType->name() . '" / "' . $relationType->nameOfInverse() . '" ["' . $relationType->Start_OT()->name() . '" -> "' . $relationType->End_OT()->name() . '"]' . $nl;
		}
		{ # output footer
			$rv .= indent($indentLevel) . '}' . $nl;
		}
		return($rv);
	} # end-of-function outputRelationTypes
	
	
	function outputAttributesOfObjectTypes($objectTypes, $indentLevel=0) {
		/** Create output for attributes of object types of the constant section.
		 * @return string
		 */
		global $nl;
		$rv = '';
		{ # output header for object types attributes
			$rv .= indent($indentLevel) . '{ # Attributes of Objects Types' . $nl;
		}
		foreach($objectTypes as $objectType) {
			{ # output header
				$rv .= indent($indentLevel+1) . '{ # Attributes of "' . $objectType->name(). '"' . $nl;
			}
			{ # get all attributes of the relation types
				$attributes = $objectType->getAttributes();
			}
			{ # walk through attributes and output content
				foreach($attributes as $attribute) {
					$nameOfConstant = ''
						. 'OA_UUID_' 
						. phpConform($objectType->name())
						. '_'
						. phpConform($attribute->name());
					$rv .= indent($indentLevel+2) . '$'. $nameOfConstant .' = \'' . $attribute->UUID() . '\'; # Attribute "' . $attribute->name() . '" of "' . $objectType->name() . '"' . $nl;
				}
			}
			{ # output footer
				$rv .= indent($indentLevel+1) . '}' . $nl;
			}
		}
		{ # output footer for object types attributes
			$rv .= indent($indentLevel) . '}' . $nl;
		}
		return($rv);
	} # end-of-function outputAttributesOfObjectTypes
	
	
	function outputAttributesOfRelationTypes($relationTypes, $indentLevel=0) {
		/** Create output for attributes of relation types of the constant section.
		 * @return string
		 */
		global $nl;
		$rv = '';
		{ # output header for relation types attributes
			$rv .= indent($indentLevel) . '{ # Attributes of Relation Types' . $nl;
		}
		foreach($relationTypes as $relationType) {
			{ # output header
				$rv .= indent($indentLevel+1) . '{# Attributes of Relation Type "' . $relationType->name() . '" / "' . $relationType->nameOfInverse() . '" ["' . $relationType->Start_OT()->name() . '" -> "' . $relationType->End_OT()->name() . '"]' . $nl;
			}
			{ # get all attributes of the relation types
				$attributes = $relationType->getAttributes();
			}
			{ # walk through attributes and output content
				foreach($attributes as $attribute) {
					$nameOfConstant = ''
						. 'RA_UUID_' 
						. phpConform($attribute->name())
						. '_of_'
						. phpConform($relationType->name())
						. '_from_'
						. phpConform($relationType->Start_OT()->name())
						. '_to_'
						. phpConform($relationType->End_OT()->name());
					$rv .= indent($indentLevel+2) . '$'. $nameOfConstant .' = \'' . $attribute->UUID() . '\'; # Attribute "' . $attribute->name() . '"' . $nl;
				}
			}
			{ # output footer
				$rv .= indent($indentLevel+1) . '}' . $nl;
			}
		}
		{ # output footer for relation types attributes
			$rv .= indent($indentLevel) . '}' . $nl;
		}
		return($rv);
	} # end-of-function outputAttributesOfRelationTypes
	
	
?>