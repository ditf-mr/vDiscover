<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	# This file contains a class definition, that might be used to facilitate the development of
	# e.g. import routines for company specific plugins.
	
	class cImportUtilities {
	
		# ==========================================================================================
		# Class Constants                                                            Class Constants
		# ==========================================================================================

		
		protected static $_constants = array(
			'viaBrowser_header' => '<html class="dj_gecko dj_contentbox">
<head>
	<meta content="text/html;charset=utf-8" http-equiv="content-type">
	<!--<meta content="IE=8" http-equiv="X-UA-Compatible">-->
	<title>{$module}</title>
</head>
<body>',
			'viaBrowser_footer' => '</body></html>',
			'viaShell_header' => '------------------------------------------------------------
{$module}
------------------------------------------------------------
',
			'viaShell_footer' => '------------------------------------------------------------',
			'viaBrowser_openTag' => '<p>',
			'viaBrowser_closeTag' => '</p>',
			'viaShell_openTag' => '',
			'viaShell_closeTag' => "\n",
			'viaBrowser_headlineOpenTag' => '<h3>',
			'viaBrowser_headlineCloseTag' => '</h3>',
			'viaShell_headlineOpenTag' => '',
			'viaShell_headlineCloseTag' => "\n",
			'viaBrowser_br' => '<br />',
			'viaShell_br' => "\n",
			'timestampFormat' => 'Y-m-d H:i:s'
		);
		
		
		# ==========================================================================================
		# Instance Properties                                                    Instance Properties
		# ==========================================================================================


			/**
			 * An object. The log handler object (see cLogHandler.php). This log handler object
			 * must offer a method named 'import'.
			 */
		protected $_logHandler;
		
		
			/** A boolean. The caching status before starting the import. If caching status is 
			 * modified, previous status can be resetted afterwards.
			 */
		protected $_cachingStatus;
		
		
			/**
			 * A boolean. Indicates whether outputs will only (false) be written into the import log 
			 * file or additionally onto the screen (true, default). Can be set using the script
			 * parameter 'verbose' (set to 1 or 0).
			 */
		protected $_verbose;
		
			  
			/**
			 * An array. Collects all parameters, that have been send either via browser (_GET or 
			 * _POST) or via shell $argv.
			 */
		public $arguments;
		
			 
			/**
			 * An array. Stores the timers, that help analysing/debugging the import routines.
			 * For each timer the following values will be saved:
			 * - 'start': start time as unix timestamp (set by startTimer)
			 * - 'startFormatted': start time as formatted string (set by startTimer)
			 * - 'end': end time as unix timestamp (set by endTimer)
			 * - 'endFormatted': end time as formatted string (set by endTimer)
			 * - 'duration': duration in seconds (set by endTimer)
			 * - 'durationFormatted': duration in days d hours h minutes m seconds s 
			 *		(set by endTimer)
			 * - 'laps': the number of lap (intermediate time points) (increased by lapTimer)
			 * - 'lap_1_time'...'lap_n_timeFormatted': lap times (set by lapTimer)
			 * - 'lap_1_duration'...'lap_n_durationFormatted': lap durations (set by lapTimer)
			 * - 'lap_1_durationTotal'...'lap_n_durationTotalFormatted': durations from start to end 
			 * 		of this lap (set by by lapTimer))
			 */
		protected $_timers;
	
	
			/**
			 * A boolean. Set to true, if script is called via browser and false, if it is called
			 * via shell.
			 */
		protected $_viaBrowser;
		
		
			/**
			 * A string. Output starts with $_header and ends with $_footer.
			 * This might be '<html><head>...' and '</body></html>' if script is called via browser 
			 * (see '$_viaBrowser').
			 */
		protected $_header;
		protected $_footer;
		
		
			/**
			 * A string. All outputs on screen will start with $_openTag and finish with $_closeTag.
			 * This might be '<p>' and '</p>' if script is called via browser (see '$_viaBrowser').
			 */
		protected $_openTag;
		protected $_closeTag;
		
		
			/**
			 * A string. Headline outputs on screen will start with $_headlineOpenTag and finish 
			 * with $_heaqdlineCloseTag. This might be '<h3>' and '</h3>' if script is called via 
			 * browser (see '$_viaBrowser').
			 */
		protected $_headlineOpenTag;
		protected $_headlineCloseTag;
		
		
			/**
			 * A string. The string that will be used when a new line (line feed) is done.
			 */
		protected $_br;
		
		
			/**
			 * A boolean. Indicates whether all objects of the target object type will be deleted 
			 * before insertion. 
			 * Default: false.
			 */
		public $delete;
		
		
			/**
			 * An integer. The number of the data sets, the import starts. Previous data sets will
			 * be skipped.
			 * Default: 1;
			 */
		public $fromNo;
		
			/**
			 * An integer. The number of the latest data sets that will be imported. 
			 * Default: 99999999.
			 */
		public $toNo;
		
		
		# ==========================================================================================
		# Instance Methods                                                          Instance Methods
		# ==========================================================================================

		
		public function __construct ( $logHandler ) {
			/** Initialises several properties. Checks if script is called via browser or via shell.
			 * @param $logHandler object. The log handler object.
			 */
			global $argv;
			global $backend;
			{ # save caching status
				$this->_cachingStatus = $backend->doCaching();
			}
			{ # logHandler
				if (is_object($logHandler)) {
					$this->_logHandler = $logHandler;
				}
			}
			{ # check if script is called via browser or shell
				$this->_viaBrowser = !isset($argv);
			}
			{ # set header, footer, open tag, close tag and br
				$this->_header = self::$_constants[$this->_viaBrowser?'viaBrowser_header':'viaShell_header'];
				$this->_footer = self::$_constants[$this->_viaBrowser?'viaBrowser_footer':'viaShell_footer'];
				$this->_openTag = self::$_constants[$this->_viaBrowser?'viaBrowser_openTag':'viaShell_openTag'];
				$this->_closeTag = self::$_constants[$this->_viaBrowser?'viaBrowser_closeTag':'viaShell_closeTag'];
				$this->_headlineOpenTag = self::$_constants[$this->_viaBrowser?'viaBrowser_headlineOpenTag':'viaShell_headlineOpenTag'];
				$this->_headlineCloseTag = self::$_constants[$this->_viaBrowser?'viaBrowser_headlineCloseTag':'viaShell_headlineCloseTag'];
				$this->_br = self::$_constants[$this->_viaBrowser?'viaBrowser_br':'viaShell_br'];
			}
			{ # read parameter
				$this->arguments = array();
				if ($this->_viaBrowser) {
					$this->arguments = array_merge($this->arguments, $_GET);
					$this->arguments = array_merge($this->arguments, $_POST);
				}
				else {
					array_shift($argv);
					while (! is_null($argumentAsString = array_shift($argv))) {
						$argumentAsArray = explode('=', $argumentAsString);
						if (count($argumentAsArray) == 2) {
							$this->arguments[$argumentAsArray[0]] = $argumentAsArray[1];
						}
					}
				}
			}
			{ # initialise timers
				$this->_timers = array();
			}
			{ # check script parameters
				if ($this->argument('clearLog')=='1') {
					$this->_logHandler->clearImport();
				}
				$this->_verbose = $this->argument('verbose');
				$this->delete = ($this->argument('delete') == '1');
				$this->fromNo = $this->argument('fromNo')?$this->argument('fromNo'):1;
				$this->toNo = ($this->argument('toNo') == '0')?0:($this->argument('toNo')?$this->argument('toNo'):999999);
			}
			{ # other parameters
				$this->_timestamp = true;
			}
			{ # change caching status if desired
				if ($this->argument('noCaching')) {
					$backend->doCaching(false);
				}
			}
		} # end-of-function __construct
		
		
		public function __destruct () {
			global $backend;
			if (is_object($backend)) {
				$backend->doCaching($this->_cachingStatus);
			}
		} # end-of-function __destruct
		
		public function header ( $module ){
			if (!$this->_verbose) {
				echo(str_replace('{$module}', $module, $this->_header));
			}
		} # end-of-function header
		
		
		public function footer ( ) {
			if (!$this->_verbose) {
				echo($this->_footer);
			}
		} # end-of-function footer
		
		
		public function argument ( $key ) {
			return (isset($this->arguments[$key])?$this->arguments[$key]:null);
		} # end-of-function argument
		
		
		public function headline ( $text, $noTimestamp=false ) {
			/** Writes a headline into the import log file (see _logHandler). Additionally it might 
			 * output on screen if not set to verbose (see $_verbose).
			 * @param $text string. The text of the headline.
			 * @param $noTimestamp boolean. False (default), then no timestamp will be printed.
			 * @return string. The text, that has benn written to the import log file.
			 */
			if (!empty($this->_logHandler)) {
				$this->_logHandler->import($text.'*****');
			}
			$timestamp = $this->_timestamp?'['.date(self::$_constants['timestampFormat']).'] ':'';
			$text = $this->_headlineOpenTag.($noTimestamp?'':$timestamp).$text.$this->_headlineCloseTag;
			if (!$this->_verbose) {
				echo $text;
			}
			return($text);
		} # end-of-function headline
		
		
		public function message ( $text=null, $noTimestamp=false ) {
			/** Writes into the import log file (see _logHandler). Additionally it might output
			 * on screen if not set to verbose (see $_verbose).
			 * Function accepts a dynamic list of parameters. Each paramter will be formatted as 
			 * string. All strings will be concatenated without any delimiter.
			 * @param $text string or array. The text or list of texts of the message.
			 * @param $noTimestamp boolean. False (default), then no timestamp will be printed.
			 * @return string. The text, that has benn written to the import log file.
			 */
			{ # check if $text is an array and build text
				$message = '';
				if (is_null($text)) {
				}
				elseif (is_array($text)) {
					foreach($text as $element) {
						$message .= $element;
					}
				}
				else {
					$message = $text;
				}
			}
			if (!empty($this->_logHandler)) {
				$this->_logHandler->import($message);
			}
			$timestamp = $this->_timestamp?'['.date(self::$_constants['timestampFormat']).'] ':'';
			$outText = $this->_openTag.($noTimestamp?'':$timestamp).$message.$this->_closeTag;
			if (!$this->_verbose) {
				echo $outText;
			}
			return($message);
		} # end-of-function echo
		
		
		public function error( $text='', $noTimestamp=false  ) {
			/** Writes the given error message into the import log file and, if verbose is not set
			 * (see $_verbose), onto the screen. The program execution is not stopped (see also
			 * method 'fatalError').
			 * @param $text string. The error message.
			 * @param $noTimestamp boolean. False (default), then no timestamp will be printed.
			 */
			$GLOBALS['logHandler']->import('Error: '.$text);
			$timestamp = $this->_timestamp?'['.date(self::$_constants['timestampFormat']).'] ':'';
			$outText = $this->_openTag.($noTimestamp?'':$timestamp).$text.$this->_closeTag;
			if (!$this->_verbose) {
				echo $outText;
			}
			return($text);
		} # end-of-function error
		
		
		public function fatalError( $text='', $noTimestamp=false  ) {
			/** Writes the given error message into the import log file and, if verbose is not set
			 * (see $_verbose), onto the screen. Then program execution is stopped.
			 */
			$GLOBALS['logHandler']->import('Fatal error: '.$text);
			$timestamp = $this->_timestamp?'['.date(self::$_constants['timestampFormat']).'] ':'';
			$outText = $this->_openTag.($noTimestamp?'':$timestamp).$text.$this->_closeTag;
			if (!$this->_verbose) {
				echo $outText;
			}
			exit();
		} # end-of-function fatalError
		
		
		public function startTimer ( $identifier ) {
			/** Starts a timer using the given name. If a timer with this name exists already, then
			 * it will be cleared.
			 * @param $identifier string. The name of the new timer.
			 * @return array. The whole timer array.
			 */
			if (isset($this->_timers[$identifier])) {
				unset($this->_timers[$identifier]);
			}
			$this->_timers[$identifier]['start'] = time();
			$this->_timers[$identifier]['startFormatted'] = date(self::$_constants['timestampFormat'], $this->_timers[$identifier]['start']);
			$this->_timers[$identifier]['end'] = 0;
			$this->_timers[$identifier]['endFormatted'] = '';
			$this->_timers[$identifier]['duration'] = 0;
			$this->_timers[$identifier]['durationFormatted'] = '';
			$this->_timers[$identifier]['laps'] = 0;
			return($this->_timers[$identifier]);
		} # end-of-function startTimer
		
		
		public function lapTimer ( $identifier ) {
			/** Reads timer and returns current situation. If a timer with the given name does not
			 * exists, then an empty array is return.
			 * @param $identifier status. The name of the timer. 
			 * @return array. The whole timer array.
			 */
			if (!isset($this->_timers[$identifier])) {
				return(array());
			}
			{ # add one lap
				$timers[$identifier]['laps']++;
				{ # add time
					$timers[$identifier]['lap_'.$timers[$identifier]['laps'].'_time'] = time();
					$timers[$identifier]['lap_'.$timers[$identifier]['laps'].'_timeFormatted'] = date(self::$_constants['timestampFormat'], $timers[$identifier]['lap_'.$timers[$identifier]['laps'].'_time']);
				}
				{ # add duration
					if ($timers[$identifier]['laps'] == 1) {
						$previousTime = $this->_timers[$identifier]['start'];
					}
					else {
						$previousTime = $timers[$identifier]['lap_'.($timers[$identifier]['laps']-1).'_time'];
					}
					$timers[$identifier]['lap_'.$timers[$identifier]['laps'].'_duration'] = $timers[$identifier]['lap_'.$timers[$identifier]['laps'].'_time']-$previousTime;
					$timers[$identifier]['lap_'.$timers[$identifier]['laps'].'_durationFormatted'] = self::formatDuration($timers[$identifier]['lap_'.$timers[$identifier]['laps'].'_duration']);
				}
				{ # add duration total
					$timers[$identifier]['lap_'.$timers[$identifier]['laps'].'_durationTotal'] = $timers[$identifier]['lap_'.$timers[$identifier]['laps'].'_time']-$this->_timers[$identifier]['start'];
					$timers[$identifier]['lap_'.$timers[$identifier]['laps'].'_durationTotalFormatted'] = self::formatDuration($timers[$identifier]['lap_'.$timers[$identifier]['laps'].'_durationTotal']);
				}
			}
			return($this->_timers[$identifier]);
		} # end-of-function lapTimer
		
		
		public function stopTimer ( $identifier ) {
			/** Stops timer and returns timer.
			 * @param $identifier status. The name of the timer. 
			 * @return array. The whole timer array.
			 */
			if (!isset($this->_timers[$identifier])) {
				return(array());
			}
			{ # add end time
				$this->_timers[$identifier]['end'] = time();
				$this->_timers[$identifier]['endFormatted'] = date(self::$_constants['timestampFormat'], $this->_timers[$identifier]['end']);
			}
			{ # add duration
				$this->_timers[$identifier]['duration'] = $this->_timers[$identifier]['end']-$this->_timers[$identifier]['start'];
				$this->_timers[$identifier]['durationFormatted'] = self::formatDuration($this->_timers[$identifier]['duration']);
			}
			return($this->_timers[$identifier]);
		} # end-of-function stopTimer
		

		public function logCommonParameter ( ) {
			global $backend;
			$this->message('Parameter "delete": '.($this->delete?'1':'0'));
			$this->message('Parameter "fromNo": '.$this->fromNo);
			$this->message('Parameter "toNo": '.$this->toNo);
			$this->message('Caching status: '.($backend->doCaching()?'on':'off'));
		} # end-of-function logCommonParameter
		
		
		public function viaBrowser ( ) {
			return($this->_viaBrowser);
		} # end-of-function viaBrowser
		
		
		public function login ( $paramUsername, $paramPassword ) {
			/** If at least the username (identified by the script parameter given by the function
			 * parameter 'paramUsername' is not empty, then a login into the backend is tried.
			 * @param $paramUsername string. The name of the script parameter, which should contain
			 *		the username for login. If not empty, then a login is tried.
			 * @param $paramPassword string. The name of the script parameter, which should contain
			 *		the password for login.
			 * @return boolean. True is ok, either logged in now or already logged in. False log in
			 *		not possible.
			 * 
			 * Hint: Function outputs a error message, if login not successful.
			 */ 
			global $backend;
			if (empty($paramUsername)) {
				if (!$backend->isLoggedIn()) {
					$this->error('Access denied. You must login first.');
					return(false);
				}
			}
			$username = $this->argument($paramUsername);
			$password = empty($paramPassword)?'':$this->argument($paramPassword);
			if (empty($username)) {
				if (!$backend->isLoggedIn()) {
					$this->error('Access denied. You must login first.');
					return(false);
				}
			}
			else {
				if (!($backend->login($username, $password) === true)) {
					$this->error('Access denied. Invalid user name or password.');
					return(false);
				}
			}
			return(true);
		} # end-of-function login
		
		
		# ==========================================================================================
		# Class Methods                                                                Class Methods
		# ==========================================================================================

		
		public static function formatDuration ( $seconds ) {
			/** Converts the given amount of seconds into days d hours h minutes m seconds s
			 * @param $seconds integer. 
			 * @return string. 
			 */
			$days = floor($seconds/86400);
			$seconds = $seconds % 86400;
			$hours = floor($seconds/3600);
			$seconds = $seconds % 3600;
			$minutes = floor($seconds/60);
			$seconds = $seconds % 60;
			return (
				($days?$days.'d':'').
				($hours?$hours.'h':'').
				($minutes?$minutes.'m':'').
				$seconds.'s'
			);
		} # end-of-function formatDuration
		
		
	} # end-of-class cImportUtilities
	
?>