<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	$nl = "\n";

	function _echo() {
		global $openTag;
		global $closeTag;
		global $verbose;
		$text = '';
		$text .= $openTag;
		$arrArgs = func_get_args();
		foreach($arrArgs as $arg) {
			$text .= $arg;
		}
		$text .= $closeTag;
		if (!$verbose) {
			echo $text;
		}
		return($text);
	} # end-of-function _echo
	
	
	function _die($text='') {
		global $openTag;
		global $closeTag;
		die($openTag.$text.$closeTag);
	} # end-of-function _die
	
	
	{ # check if script is called via browser or windows-shell and set open and close tag
		$viaBrowser = ! isset($argv);
		$openTag = ($viaBrowser?'<p>':'');
		$closeTag = ($viaBrowser?'</p>':'').$nl;
		$br = ($viaBrowser?'<br />':$nl);
	}
	{ # read parameter
		$arguments = array();
		if ($viaBrowser) {
			$arguments = array_merge($arguments, $_GET);
			$arguments = array_merge($arguments, $_POST);
		}
		else {
			array_shift($argv);
			while (! is_null($argumentAsString = array_shift($argv))) {
				$argumentAsArray = explode('=', $argumentAsString);
				if (count($argumentAsArray) == 2) {
					$arguments[$argumentAsArray[0]] = $argumentAsArray[1];
				}
			}
		}
	}
	{ # check if configuration is loaded
		if ( ! $repository_config ) {
			header('Location: ../..');
			exit;
		}
	}
	define('APPLICATION_started', true);
	
	{ # check for help and verbose
		$help = isset($arguments['help']) or isset($arguments['h']);
		$verbose = isset($arguments['verbose']) or isset($arguments['v']);
	}
	{ # specification of tools
	  # choose which application output shall be sent back
	  # these output options are available only, if the user is logged in.
		$tools = array (

			# tools for all users
			'hello'	=> 'user/hello.php',

			# tools for administrators
			'uuidList_asPHP'			=> 'admin/uuidList_asPHP.php',
			'deleteObjectsBy_OT_name'	=> 'admin/deleteObjectsBy_OT_name.php',
		); 
	}
	
	// add absolute paths to $repository_config
	require_once(__DIR__.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'information_structure'.DIRECTORY_SEPARATOR.'utilities.php');
	$repository_config = expandPathsIn_repository_config($repository_config);
	
	{ # load configuration
		require_once($repository_config['application_path'].DIRECTORY_SEPARATOR.'config.php');
	}
	{ # load some useful functions, classes, methods ...
		require_once($repository_config['application_path'].DIRECTORY_SEPARATOR.'utilities.php');
	}
	{ # load and initialise global log files handler 
		require_once( realpath($repository_config['application_path'].DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'utilities'.DIRECTORY_SEPARATOR.'cLogHandler.php') );
		global $logHandler;
		if ( is_null( $logHandler = new cLogHandler ( $repository_config['path_logs'] ) ) ) 
			_die('Could not initialise global $logHandler object.');
	}
	{ # load exceptions
		require_once( realpath($repository_config['application_path'].DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'utilities'.DIRECTORY_SEPARATOR.'exceptions.php') );		
	}
	{ # load backend module and create cBackend instance
		require_once( $repository_config['backend_path'].DIRECTORY_SEPARATOR.'loadBackend.php' );
	}
	{ # start session
		session_start();
		session_cache_expire(cSystem::sessionTimeout());
	}
	{ # try login using username and password, given in corresponding post or get parameter
		$username = isset($arguments['u'])?$arguments['u']:'';
		$password = isset($arguments['p'])?$arguments['p']:'';
		if (!empty($username) or !empty($password)) {
			if (empty($username) or empty($password)) {
				_die('Access denied. User name (parameter u) and password (parameter p) must not be empty.');
			}
			if (!($backend->login($username, $password) === true)) {
				_die('Access denied. Invalid user name or password.');
			}
		}
		elseif (!$backend->isLoggedIn()) {
			_die('Access denied. You must login first.');
		}
	}
	{ # carry out the action
		$t = isset($arguments['t'])?$arguments['t']:'';
		if (empty($t)) {
			_die('No tool (parameter t) specified.');
		}
		$tool = (isset($tools[$t])?$tools[$t]:'');
		if (empty($tool)) {
			_die('Tool "' . $t . '" not does not exist.');
		}
		require(__DIR__.DIRECTORY_SEPARATOR.$tool);
	}

	exit();				

?>