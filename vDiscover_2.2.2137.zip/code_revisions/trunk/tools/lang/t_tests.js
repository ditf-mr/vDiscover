text1 = "gfdg df df"
		+T('BTN_OK','OK-de')
		+"sdf dsfd"
		+"fdg dfg dfg" +T('BTN_CANCEL','Abbrechen')+ "sd ds sdff";
		
text2 = "as as as dsad asd" +T('GOOD_MORNING', 'Good morning to you, $[1] $[0]!', ['Edwards', 'John']) + "d sd fsd sdfsd";

text3 = T('manageViews.js/NoViewsYetHint_HTM',
					'<p>You should create some views for &laquo;$[0]&raquo;.</p>\
					<p>You will probably need to set a <i>default name</i> and a <i>default description view</i>. You can set this on the tab &laquo;General Properties&raquo; of the view.</p>\
					<ul><li>RS II will use the default name view as a name template for the objects of this type. \
					This permits to generate the object names automatically from attribute values of the objects.</li>\
					<li>The default description view is displayed in the list of all objects.</li></ul>'
					,[this.OT_name]);