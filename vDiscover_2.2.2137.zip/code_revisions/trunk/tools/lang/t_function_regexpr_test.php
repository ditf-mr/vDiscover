<?php
// searchpattern
//$pattern_alt = "/T\(('|\").+('|\")\s?,\s?('|\").+('|\")\)/";
//$pattern = "/T\(('|\").*(('|\")\)|(\]\)))/";

$file = 't_tests.js';

$innerPattern =   "(" . 
				"'(?:[^'\\\\]|\\\\'?)*'" 
				. "|" . 
				'"(?:[^"\\\\]|\\\\"?)*"' 
				. ")";
				
$whitespaces = "\s*";

$pattern = "/\bT".$whitespaces."\(".$whitespaces.$innerPattern.$whitespaces.",".$whitespaces.$innerPattern."/"; // überflüssig ist: .$whitespaces."\)/";


// subjects

# definierter Aufruf der Fkt. T()
$subject[] = "gfdg df df+T('BTN_OK','OK-de')+sdf dsfd+
    fdg dfg dfg +T('BTN_CANCEL','Abbrechen')+sd ds sdff";  

# mit Space nach dem '
$subject[] = "dfg +T('BTN_CANCEL', 'Abbrechen')+sd ds sdff";        

# mit " statt '
$subject[] = 'gfdg df df+T("BTN_OK","OK-de")+sdf dsfd';

# mit " und Space
$subject[] = 'fdg dfg dfg +T("BTN_CANCEL", "Abbrechen")+sd ds sdff';        

# mit \" in Value
$subject[] = 'fdg dfg dfg +T("BTN_CANCEL", "Abbrec\"hen")+sd ds sdff';        

$filename = 'testfile.js';
#$subject[] = htmlentities(file_get_contents($filename), 48, "UTF-8");

# mit Parameter: T('GOOD_MORNING', 'Good morning to you, $[1] $[0]!', ['Edwards', 'John'])
$subject[] = "as as as dsad asd +T('GOOD_MORNING', 'Good morning to you, $[1] $[0]!', ['Edwards', 'John'])+d sd fsd sdfsd";

# diese Version funktioniert
$subject[] = "((series.length==0)? T('FUT_none','none') : '<code>'+series.length+'</code>' )";

# FEHLER!!: wenn ich den letzten SPACE vor der ) weglasse, versagt der pattern.
$subject[] = "((series.length==0)? T('FUT_none','none') : '<code>'+series.length+'</code>')";

# FEHLER!!: Message wg. Übersichtlichkeit über mehrere Zeilen aufgeteilt. <-- sollte mit \ funktionieren!
$subject[] = htmlspecialchars(" T('manageViews.js/NoViewsYetHint_HTM',
					'<p>You should create some views for &laquo;$[0]&raquo;.</p>'
					<p>You will probably need to set a <i>default name</i> and a <i>default description view</i>. You can set this on the tab &laquo;General Properties&raquo; of the view.</p>\
					<ul><li>RS II will use the default name view as a name template for the objects of this type. \
					This permits to generate the object names automatically from attribute values of the objects.</li>\
					<li>The default description view is displayed in the list of all objects.</li></ul>'
					,[this.OT_name]) 
			");

			
$subject[] = htmlspecialchars("T('attrConf_cValueRange.js/InherDefVal_P2_LNK','Click <a dojoAttachEvent=\"onclick:useInheritedDefaultValue_clicked\">here</a> to use the inherited default value.')");			
			
			
echo '<h1>Pattern Test for T()-Function</h1>';


    
	$matches = array();
    preg_match_all($pattern, file_get_contents($file), $matches);
	echo "<pre>";
		print_r($matches);
    echo "</pre>";
    echo sizeof($matches[1]) . ' match(es) found:<br><hr>';
       
?>
