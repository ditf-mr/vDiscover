<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// register the common attribute components

//$r->register_JavaScriptFile('application/attributes/application.attributeKinds.js');
$r->register_JavaScriptFile('../common_plugins/DITF_Design_of_Experiments/designOfExperiments.js');

// register all special components in the sub dirs
//cApplicationRegistry::registerModuleComponents(PLUGIN_REGISTRY_parseAllSubDirs, __DIR__ );

?>