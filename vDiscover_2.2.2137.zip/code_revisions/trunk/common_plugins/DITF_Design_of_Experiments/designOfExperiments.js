﻿/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/


(function(){

// create the static object for the dialog
if(!application.commonPlugins) application.commonPlugins = {};
application.commonPlugins.designOfExperiments = {
	'dialogWidget' 	: null
	,
	'OT_UUID'		: null
	,
	'OTItem'		: null
	,
	'OT_name'		: null
	,
	'showDialog' : function (OT_UUID) {
	
		if (this.dialogWidget) this.closeDialog(); // destroy a potentially existing dialog widget
	
		// get the necessary information
		this.OT_UUID = OT_UUID;
		
		application.OT.navigationStore.fetchItemByIdentity({
			'identity'	: this.OT_UUID,
			'scope'		: this,
			'onItem'	: function (i) {
				this.OTItem = i;
			} // end of method onItem
		});
		
		this.OT_name = application.OT.navigationStore.getValue(this.OTItem, 'name');
		
		this.dialogWidget = new application.commonPlugins.designOfExperiments.dialog({
			'callerObj'	: this,
			'OT_UUID'	: this.OT_UUID,
			'OT_name'	: this.OT_name,
		});
		
		this.dialogWidget.startup();
		this.dialogWidget.show();
	} // end of method show
	,
	'closeDialog' : function() {
		this.dialogWidget.hide();
		this.dialogWidget.destroyRecursive(false);
		this.dialogWidget.destroy();
		this.dialogWidget=null;
		this.OT_UUID = null;
		this.OT_name = null;
		
	} // end of method closeDialog
	
}; // end static object declaration

dojo.require("common.widgets.fixedSizeDialog");

dojo.declare('application.commonPlugins.designOfExperiments.dialog',[common.widgets.fixedSizeDialog],{
	'innerWidth'	: 800
	,
	'innerHeight'	: 800
	,
	
	'constructor' : function() {
		// Your constructor method will be called before the parameters are mixed into the widget, and can be used to initialize arrays, etc.
		this.inherited(arguments);
		
		// some initialisations
		this.widgets 		= {};
		
		this.attrRows		= {};
		
	} // end of method constructor
	,
	'postMixInProperties' : function () {
		this.inherited(arguments);
	
		// set the dialog title
		this.title = 'Design of Experiments for &laquo;'+this.OT_name+'&raquo;';
	
	} // end of method postMixInProperties
	,
	'postCreate' : function () {
		// This is typically the workhorse of a custom widget. The widget has 
		// been rendered (but note that sub-widgets in the containerNode have not!). 
		// The widget though may not be attached to the DOM yet so you shouldn't 
		// do any sizing calculations in this method.
		this.inherited(arguments);
			
			// build the main structure of the dialog
		this.widgets.borderContainer = new dijit.layout.BorderContainer({
			'style' 	: 'width:100%;height:100%;',
			'gutters'	: false
		}).placeAt(this.containerNode);
		
		// create the action bar at the bottom of the dialog
		this.widgets.actionBar = new dijit.layout.ContentPane({
			'region'	: 'bottom',
			'class'		: 'dijitDialogPaneActionBar textRight',
			'style'		: 'padding-top:1em;'
		});
		this.widgets.borderContainer.addChild(this.widgets.actionBar);

		this.widgets.OkButton = new dijit.form.Button({
			'label' 	: '<img src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/dialog-ok-apply-4.png"/> '
				+T('BTN_OK', 'Ok'),
			'type'		: 'button',
			'disabled'	: true,
		}).placeAt(this.widgets.actionBar.containerNode);

		this.connect(this.widgets.OkButton,'onClick','execute');
		
		this.widgets.CancelButton = new dijit.form.Button({
			'label' 	: '<img width="12" src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/dialog-cancel-4.png"/> '
				+T('BTN_CANCEL', 'Cancel'),
			'type'		: 'button',
			'style'		: 'margin-right:0;'
		}).placeAt(this.widgets.actionBar.containerNode);
		
		this._connects.push(dojo.connect( this.widgets.CancelButton,	'onClick', this.callerObj, 'closeDialog'));
		this._connects.push(dojo.connect( this.widgets.closeButtonNode,	'onClick', this.callerObj, 'closeDialog'));

		// create the main input regions of the dialog
		
		this.widgets.titlePane = new dijit.layout.ContentPane({
			'region'	: 'top',
			'content'	: ''
				+'<h2>Design of Experiments</h2>'
				+'<p>This dialog creates a number of objects with a common name and varying values.</p>'
				+'<p>Use this functionality to generate e.g. objects with settings for a series of varying samples. The final sample properties may be used, then, to identify interdepencencies between preliminary product properties, settings and sample properties.</p>'
		});
		this.widgets.borderContainer.addChild(this.widgets.titlePane);
		
		this.widgets.settingsPane = new dijit.layout.ContentPane({
			'region'	: 'center',
			'style'		: 'overflow-y:auto;padding-right:.5ex;',
			'content'	: ''
		});
		this.widgets.borderContainer.addChild(this.widgets.settingsPane);
		
		dojo.create('H3', {
			'innerHTML'	: 'Common name for the objects'
		}, this.widgets.settingsPane.containerNode);
		
		dojo.create('P', {
			'innerHTML'	: 'Please choose the attribute that contains the object name and enter the object name (e.g. the sample series name):-'
		}, this.widgets.settingsPane.containerNode);
		
		this.attrNameTable_node = dojo.create('TABLE', {
			'class'		: 'compact fullWidth',
			'innerHTML'	: ''
				+'<tbody>'
					+'<tr>'
						+'<td style="width:50%;">'
							+'<div class="nameAttrSelector_node"></div>'
						+'</td>'
						+'<td style="width:50%;">'
							+'<div class="attrValues_node">&nbsp;</div>'
						+'</td>'
					+'</tr>'
				+'</tbody>'
		}, this.widgets.settingsPane.containerNode);
		
		this.nameAttrSelector_node	= dojo.query('.nameAttrSelector_node', this.attrNameTable_node).shift();
		this.attrValues_node 		= dojo.query('.attrValues_node', this.attrNameTable_node).shift();
		
		dojo.create('p', {
			'innerHTML'	: ''
				+'Objects should additionally have a unique identifier, '
				+'e.g. an automatically incrementing counter attribute. '
				+'The object name should include this unique identifier. '
		}, this.widgets.settingsPane.containerNode);
		
		dojo.create('p', {
			'innerHTML'	: '&nbsp;'
		}, this.widgets.settingsPane.containerNode);
		
		dojo.create('H3', {
			'innerHTML'	: 'Set the values'
		}, this.widgets.settingsPane.containerNode);
		
		dojo.create('P', {
			'innerHTML'	: 'Select the attributes that contain the settings and enter the possible values for each setting:-'
		}, this.widgets.settingsPane.containerNode);
		
		dojo.create('P', {
			'innerHTML'	: '(if you enter one value, all objects will get this value; if you enter more values, each object will get one of these)',
			'class'		: 'small'
		}, this.widgets.settingsPane.containerNode);
		
		this.settingsAttrsListTable_node = dojo.create('TABLE', {
			'class'		: 'fullWidth listWithRows',
			'innerHTML'	: ''
				+'<tbody class="settingsAttrList_node">'
					// --> new setting attributes and values will go, here <--
				+'</tbody>'
		}, this.widgets.settingsPane.containerNode);
		
		this.settingsAttrList_node 		= dojo.query('.settingsAttrList_node', 		this.settingsAttrsListTable_node).shift();
		
		this.settingsAttrInsertTable_node = dojo.create('TABLE', {
			'class'		: 'compact fullWidth',
			'innerHTML'	: ''
				+'<tbody>'
					+'<tr>'
						+'<td style="width:30%;">'
							+'<div class="settingsAttrSelector_node"></div>'
						+'</td>'
						+'<td style="width:70%;">'
							+'&nbsp;'
						+'</td>'
					+'</tr>'
				+'</tbody>'
		}, this.widgets.settingsPane.containerNode);
		
		this.settingsAttrSelector_node	= dojo.query('.settingsAttrSelector_node', 	this.settingsAttrInsertTable_node).shift();
		
		this.getOTAttrInfo();
		
		// create the dropDown menu for selecting the name attribute
		this.widgets.nameAttrSelector = new dijit.form.FilteringSelect({
			'style'				: 'width:10em;',
			'store'				: this.attrStore,
			'query'				: {'kind' : "cSingleLineAttribute"},
			'autoComplete' 		: true,
			'fetchProperties' 	: {'sort': [{'attribute':"position", 'descending': false}]},
			'highlightMatch' 	: "all",
			// 'ignoreCase'		: true,
			// 'queryExpr'			: '*{0}*',
			// 'required' 			: true,
		}/*).placeAt(*/, this.nameAttrSelector_node );
		
		this.connect(this.widgets.nameAttrSelector, 'onChange', 'showNameAttrInputBox');
		
		// create the dropDown menu for selecting the setting attributes
		this.widgets.newAttrSelector = new dijit.form.FilteringSelect({
			'style'				: 'width:10em;',
			'store'		: this.attrStore,
			'query'		: {'kind' : "cNumberAttribute", 'DOE_notChosen' : true},
			'autoComplete' 		: true,
			'fetchProperties' 	: {'sort': [{'attribute':"position", 'descending': false}]},
			'highlightMatch' 	: "all",
			// 'ignoreCase'		: true,
			// 'queryExpr'			: '*{0}*',
			// 'required' 			: true,
		}, dojo.create('DIV')).placeAt(this.settingsAttrSelector_node);
		
		this.connect(this.widgets.newAttrSelector, 'onChange', '_toggleDisabledStatusOfNewAttrButton');
		
		// create a button for adding the new settings attribute
		this.widgets.newAttrButton = new dijit.form.Button({
			'label' 	: '<img width="12" src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/edit-add.png"/> '
				+T('BTN_ADD', 'Add'),
			'disabled'	: true,
		}).placeAt(this.settingsAttrSelector_node);
		
		this.connect(this.widgets.newAttrButton, 'onClick', 'addSettingsAttr');
		
		// Options
		
		// Randomised order?
		dojo.create('H3', {
			'innerHTML'	: 'Options'
		}, this.widgets.settingsPane.containerNode);
		
		var pR = dojo.create('P', {
					// 'innerHTML'	: ''
				}, this.widgets.settingsPane.containerNode),
			lR = dojo.create('LABEL', {
					'innerHTML'	: 'Create the objects in a randomised order'
				}, pR);
		
		this.widgets.randomisedCheckBox = new dijit.form.CheckBox({
			'checked' : true,
			'style'		: 'margin-right:1em;',
		}).placeAt(lR, 'first');
		
		// Delete all existing objects, before?
		var pD = dojo.create('P', {
					// 'innerHTML'	: ''
				}, this.widgets.settingsPane.containerNode),
			lD = dojo.create('LABEL', {
					'innerHTML'	: 'Delete all existing objects before creating the objects'
				}, pD);
		
		this.widgets.deleteBeforeCheckBox = new dijit.form.CheckBox({
			'checked' : false,
			'style'		: 'margin-right:1em;',
		}).placeAt(lD, 'first');
				
	} // end of method postCreate
	,
	'_toggleDisabledStatusOfNewAttrButton' : function (v) {
		this.widgets.newAttrButton.attr('disabled', v=='');
	} // end of method _toggleDisabledStatusOfNewAttrButton
	,
	'_toggleDisabledStatusOrOkButton' : function () {
		var inputsAreOk = true;
	
		// there needs to be an attribute for the common name and a common name needs to be given
		var 	commonNameAttr_selected = (this.widgets.nameAttrSelector.attr('value') != ''),
				commonNameAttr_inputOk	= 		(typeof this.widgets.nameAttrWidget != 'undefined')
											&&	this.widgets.nameAttrWidget.isValid()
											&&	this.widgets.nameAttrWidget.getChangedTupleSet();
		
		inputsAreOk = 		inputsAreOk
						&&	commonNameAttr_selected
						&&	commonNameAttr_inputOk;
		
		// further, there needs to be at least one value that is varying
		var		settingAttrs_existing	= (Object.keys(this.attrRows).length>0);
		
		inputsAreOk = 		inputsAreOk
						&&	settingAttrs_existing;
		
		/*
		for (var A_UUID in this.attrRows) {
			var attrRow = this.attrRows[A_UUID];
			
			var isValid 			= attrRow.isValid(),
				hasAtLeastOneValue	= (Object.keys(attrRow.getChangedTupleSet()).length>0);
			
			inputsAreOk =		inputsAreOk
							&&	isValid
							&&	hasAtLeastOneValue;
		} // end for .. in
		*/
	
		this.widgets.OkButton.attr('disabled', !inputsAreOk);
	} // end of method _toggleDisabledStatusOrOkButton
	,
	'getOTAttrInfo' : function () {
	
		// load the dialog configuration from the server
		dojo.xhrPost({
			'url'		: '?'
			,
			'content'	: {
				'v'		: 'JSON_ObjectType',
				"task"	: 'dialogue_statisticData_get', 
				"UUID"	: this.OT_UUID 
			}
			,
			'error'		: 	application.AJAX_errorMessage, // function
			'handleAs'	: 'json',
			'scope'		: this,
			'load'		: function(response,request){ /* onSuccess */
			
				var scope = request.args.scope;
				
				scope.numberOfObjects 	= response.numberOfObjects;
				scope.attributes = response.attributes;
				
				var attrsAsArray = [];
				for (var A_UUID in scope.attributes) {
					var a = dojo.clone(scope.attributes[A_UUID]);
					a.DOE_notChosen = true;
					attrsAsArray.push(a);
				} // end for .. in
				
				scope.attrStore = new dojo.data.ItemFileWriteStore({
						'data'			: {
							'identifier'	: 'A_UUID',
							'label'			: 'name',
							'items'			: attrsAsArray
						}, 
						'clearOnClose' 	: true,
						// 'hierarchical'	: true
					});
				
			}, // end of onSuccess method
			//preventCache:true,
			//failOk	: true,
			'sync'		: true,
			'timeout'	: 	application.configuration.global.AJAX_default_timeout
		});
	
	} // end of method getOTAttrInfo
	,
	'showNameAttrInputBox' : function (A_UUID) {
	
		this.nameAttrUUID = A_UUID;
	
		// delete a possibly already existing widget
		if (this.widgets.nameAttrWidget) {
			this.widgets.nameAttrWidget.destroyRecursive();
			delete this.widgets.nameAttrWidget;
		} // end if
	
		// create the name attribute
		this.widgets.nameAttrWidget = new application.widgets.cSingleLineAttribute({
			'A_UUID'	: this.nameAttrUUID,
			// 'O_UUID'	: '',
			'edit'		: true,
			'config'	: this.attributes[A_UUID],
		}).placeAt(this.attrValues_node, 'only');
		
		this._toggleDisabledStatusOrOkButton();
	
	} // end of method showNameAttrInputBox
	,
	'addSettingsAttr' : function () {
	
		var A_UUID = this.widgets.newAttrSelector.attr('value');
	
		if (!A_UUID) return;
	
		// tell the store that the attribute is chosen, now
		this.attrStore.fetchItemByIdentity({
			'identity'	: A_UUID,
			'scope'		: this,
			'onItem'	: function (i) {
				this.attrStore.setValue(i, 'DOE_notChosen', false);
				this.widgets.newAttrSelector.reset();
			} // end of method onItem
		});
	
		// create and add the widget
		this.attrRows[A_UUID] = new application.commonPlugins.designOfExperiments.dialog.attrSettings({
			'config'		: this.attributes[A_UUID],
			'parentDialog'	: this,
		
		}).placeAt(this.settingsAttrList_node);
	
		this._toggleDisabledStatusOrOkButton();
		
	} // end of method addSettingsAttr
	,
	'deleteAttrSettings' : function (A_UUID) {

		this.attrStore.fetchItemByIdentity({
			'identity'	: A_UUID,
			'scope'		: this,
			'onItem'	: function (i) {
				this.attrStore.setValue(i, 'DOE_notChosen', true);
			} // end of method onItem
		});

		this.attrRows[A_UUID].destroyRecursive(false);
		delete this.attrRows[A_UUID];
	
		this._toggleDisabledStatusOrOkButton();
		
	} // end of method deleteAttrSettings
	,
	'execute' : function () {
		console.log('execute');
		
		// gather all necessary inputs
		var inputs = {};
		
		inputs.OT_UUID			= this.OT_UUID;
		
		inputs.nameAttribute	= {
			'A_UUID'		: this.widgets.nameAttrSelector.attr('value'),
			'valueTuple'	: this.widgets.nameAttrWidget.getChangedTupleSet()
		};
		
		inputs.attrsWithSettingsAsValueTuples = {};
		
		for (var A_UUID in this.attrRows) {
			var attrRow = this.attrRows[A_UUID];
		
			inputs.attrsWithSettingsAsValueTuples[A_UUID] = attrRow.getChangedTupleSet();
		
		} // end for .. in
		
		inputs.options = {
			'randomOrder'					: this.widgets.randomisedCheckBox.attr('checked'),
			'deleteExistingObjectsBefore'	: this.widgets.deleteBeforeCheckBox.attr('checked'),
		};
		
		console.log('inputs', inputs);


		
		// send the inputs to the server
		dojo.xhrPost({
			'url'		: '?'
			,
			'content'		: {
				'v'			: 'JSON_ObjectType',
				"task"		: 'dialogue_statisticData_set', 
				"UUID"		: this.OT_UUID,
				'postData'	: dojo.toJson(inputs),
			}
			,
			'error'		: 	application.AJAX_errorMessage, // function
			'handleAs'	: 'json',
			'scope'		: this,
			'load'		: function(response,request){ /* onSuccess */
			
				var scope = request.args.scope;
				
				console.log('response', response);
				
				/*
				scope.numberOfObjects 	= response.numberOfObjects;
				scope.attributes = response.attributes;
				
				var attrsAsArray = [];
				for (var A_UUID in scope.attributes) {
					var a 			= dojo.clone(scope.attributes[A_UUID]);
					a.DOE_notChosen = true;
					attrsAsArray.push(a);
				} // end for .. in
				
				scope.attrStore = new dojo.data.ItemFileWriteStore({
						'data'			: {
							'identifier'	: 'A_UUID',
							'label'			: 'name',
							'items'			: attrsAsArray
						}, 
						'clearOnClose' 	: true,
						// 'hierarchical'	: true
					});
				
				console.log('attrStore');
				console.log(scope.attrStore);
				*/
				
				// close the dialog
				this.callerObj.closeDialog();
				
			}, // end of onSuccess method
			//preventCache:true,
			//failOk	: true,
			'sync'		: true,
			'timeout'	: 	application.configuration.global.AJAX_default_timeout
		});
		
	} // end of method
	,
	'destroy' : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		
		for (var i in this.widgets) {
			if (this.widgets[i].destroyRecursive) this.widgets[i].destroyRecursive(false);
			delete this.widgets[i];
		} // end for .. in
		
		for (var i in this.attrRows) {
			if (this.attrRows[i].destroyRecursive) this.attrRows[i].destroyRecursive(false);
			delete this.attrRows[i];
		} // end for .. in
		
		//this.inherited(arguments);
	} // end of method destroy
	,

}); // end of dialog definition application.commonPlugins.designOfExperiments.dialog

dojo.declare('application.commonPlugins.designOfExperiments.dialog.attrSettings', [dijit._Widget, dijit._Templated], {
	// 'widgetsInTemplate'	: true
	// ,
	'templateString' : ''
		+'<tr>'
			+'<td style="width:30%;vertical-align:top;">'
				+'${name}'
			+'</td>'
			+'<td style="width:50%;vertical-align:top;">'
				+'<div dojoAttachPoint="settingsInputWidget_node"></div>'
			+'</td>'
			+'<td style="width:20%;vertical-align:top;text-align:right;">'
				+'<img width="12" src="third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/dialog-cancel-4.png"/ '
					+'dojoAttachEvent="onclick:_deleteThisRow_clicked" title="Delete the settings for this attribute" '
					+'style="cursor:pointer;vertical-align: middle;"> '
			+'</td>'
		+'</tr>'
	,
	'postMixInProperties' : function () {
		
		this.inherited(arguments);
		
		this.name = this.config.name;
		
		this.config.cardinality = 0;
		
	} // end of method postMixInProperties
	,
	'_deleteThisRow_clicked' : function (e) {
		dojo.stopEvent(e);
		console.log('_deleteThisRow_clicked', this.config.A_UUID);
		this.parentDialog.deleteAttrSettings(this.config.A_UUID);
	} // end of method deleteThisRow_clicked
	,
	'postCreate' : function () {
	
		this.inherited(arguments);
		
		this.settingsInputWidget = new application.widgets[this.config.kind]({
			'A_UUID'	: this.config.A_UUID,
			// 'O_UUID'	: '',
			'edit'		: true,
			'config'	: this.config,
			'valueTuples' : {},
		}).placeAt(this.settingsInputWidget_node);
		
	
	} // end of method postCreate
	,
	'getChangedTupleSet' : function () {
		return this.settingsInputWidget.getChangedTupleSet();
	} // end of method getChangedTupleSet
	,
	'isValid' : function () {
		return this.settingsInputWidget.isValid();
	} // end of method isValid
	,
	'destroy' : function () {
		this.settingsInputWidget.destroyRecursive();
		dojo.destroy(this.domNode);
		
		this.inherited(arguments);
	} // end of method destroy
});


// register the corersponding menu bar option
dojo.addOnLoad(function(){
	application.OT_menubar_itemKinds.register({name: "Design of Experiments [Experimental!]",
		'UUID'				:	"OT_menubar_itemKinds.commonPlugins.designOfExperiments",
		'addWhenCreating' 	: 	false,
		'openByDefault' 	: 	false,
		'JS_command'		:	function (OT_UUID, tabContainer) {
			// var t_C = dijit.byId(tabContainer)
		
			application.commonPlugins.designOfExperiments.showDialog(OT_UUID);
			
		} // end-of-method 
		,
		'description'		:	""
			+"<p>This menu item for object types is purely experimental! It is not fit for daily use.</p>"
			+"<p>This command opens a dialog that permits to create a set of objects with distinct properties.</p>"
	});
}); // end dojo.addOnLoad

})();