<?php if (!defined('APPLICATION_started')) {header('Location: .');exit;} 
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/


	class cScaledDifference extends cLocalDistanceFunction {
		
		
		# ==========================================================================================
		# Instance Properties                                                    Instance Properties
		# ==========================================================================================

		
		protected $_attrKinds = array('cNumberAttribute');
		
		protected $_baseValue = null; 
		protected $_candidateValue = null; 
		protected $_min = 0;
		protected $_max = 0;
		
		
		# ==========================================================================================
		# Static Properties                                                        Static Properties
		# ==========================================================================================

		
		public function __construct ( $baseAV, $candidateAV ) {
			$this->_setBaseAV ($baseAV);
			$this->_setCandidateAV ($candidateAV);
			if (func_num_args() == 3) {
				if (is_array($initParams = func_get_arg(2))) {
					if (isset($initParams['min'])) {
						$this->_min = $initParams['min'];
					}
					if (isset($initParams['max'])) {
						$this->_max = $initParams['max'];
					}
				}
			}
			$this->_calculateDistance();
		}
	
	
		# ==========================================================================================
		# Public Instance Methods                                            Public Instance Methods
		# ==========================================================================================

		
		# ==========================================================================================
		# Protected Instance Methods                                      Protected Instance Methods
		# ==========================================================================================

		
		protected function _setBaseAV ( $baseAV ) {
			if (count($baseAV)>0){
				foreach ($baseAV as $AVObject){
					$cAV = $this->_getRealAV($AVObject);
				}
				if ( is_object($cAV) and ( in_array(preg_replace ( '/Value\z/' , '' , get_class($cAV),1 ), $this->_attrKinds) ) )
					$this->_baseValue = $cAV->value_number();
			} 
		}
		
		
		protected function _setCandidateAV ( $candidateAV ) {
			if (count($candidateAV)>0){
				foreach ($candidateAV as $AVObject){
					$cAV = $this->_getRealAV($AVObject);
				}
				if ( is_object($cAV) and ( in_array(preg_replace ( '/Value\z/' , '' , get_class($cAV),1 ), $this->_attrKinds) ) )
					$this->_candidateValue = $cAV->value_number();
			} 
		}
		
		
		protected function _calculateDistance () {
			if ( $this->_baseValue and $this->_candidateValue)
				$this->_distance = self::scaledDifference($this->_baseValue, $this->_candidateValue, $this->_min, $this->_max);
		}
		
		
		# ==========================================================================================
		# Public Static Methods                                                Public Static Methods
		# ==========================================================================================
		
		
		public static function scaledDifference($baseValue, $candidateValue, $min, $max) {
			if (abs($max - $min) == 0) {
				return(1);
			}
			$distance = abs($baseValue - $candidateValue) / abs($max - $min);
			if ($distance < 0) {
				$distance = 0;
			}
			if ($distance > 1) {
				$distance = 1;
			}
			return($distance);
		} # end-of-method scaledDifference
		
		
	} # end-of-class cScaledDifference


?>