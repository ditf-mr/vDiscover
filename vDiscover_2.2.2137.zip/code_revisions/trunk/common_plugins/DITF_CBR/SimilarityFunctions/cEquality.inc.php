<?php if (!defined('APPLICATION_started')) {header('Location: .');exit;} 
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/


	class cEquality extends cLocalDistanceFunction {
	
	
		# ==========================================================================================
		# Instance Properties                                                    Instance Properties
		# ==========================================================================================

		protected $_attrKinds = array(
			'cNumberAttribute', 
			'cKeyValuePairAttribute', 
			'cSingleLineAttribute',
			'cRelationAttribute'
		);
		
		protected $_baseValue = null; 
		protected $_candidateValue = null; 
		
		# ==========================================================================================
		# Static Properties                                                        Static Properties
		# ==========================================================================================

		
		
		# ==========================================================================================
		# Protected Instance Methods                                      Protected Instance Methods
		# ==========================================================================================

		protected function _setBaseAV ( $baseAV ) {
			global $backend;
			if (count($baseAV)>0){
				foreach ($baseAV as $AVObject){
					$cAV = $this->_getRealAV($AVObject);
				}
				if ( is_object($cAV) and ( in_array(preg_replace ( '/Value\z/' , '' , get_class($cAV),1 ), $this->_attrKinds) ) )
					switch (preg_replace ( '/Value\z/' , '' , get_class($cAV),1 )) {
						case 'cKeyValuePairAttribute':
								$this->_baseValue = $cAV->value_listKey();
								break;
						case 'cNumberAttribute': 
								$this->_baseValue = $cAV->value_number();
								break;
						case 'cSingleLineAttribute': 
								$this->_baseValue = $cAV->value_text();
								break;
						case 'cRelationAttribute': {
								$relation = $backend->getRelation($cAV->value_UUID());
								$base = $backend->getObject($AVObject->OR_v_UUID());
								if ($base->O_UUID() == $relation->Start_O_UUID()) {
									$this->_baseValue = $relation->End_O_UUID();
								}
								else {
									$this->_baseValue = $relation->Start_O_UUID();
								}
								break;
						}
					}
			} 
		}
		
		protected function _setCandidateAV ( $candidateAV ) {
			global $backend;
			if (count($candidateAV)>0){
				foreach ($candidateAV as $AVObject){
					$cAV = $this->_getRealAV($AVObject);
				}
				if ( is_object($cAV) and ( in_array(preg_replace ( '/Value\z/' , '' , get_class($cAV),1 ), $this->_attrKinds) ) )
					switch (preg_replace ( '/Value\z/' , '' , get_class($cAV),1 )) {
						case 'cKeyValuePairAttribute': {
								$this->_candidateValue = $cAV->value_listKey();
								break;
						}
						case 'cNumberAttribute': {
								$this->_candidateValue = $cAV->value_number();
								break;
						}
						case 'cSingleLineAttribute': {
								$this->_candidateValue = $cAV->value_text();
								break;
						}
						case 'cRelationAttribute': {
								$relation = $backend->getRelation($cAV->value_UUID());
								$candidate = $backend->getObject($AVObject->OR_v_UUID());
								if ($candidate->O_UUID() == $relation->Start_O_UUID()) {
									$this->_candidateValue = $relation->End_O_UUID();
								}
								else {
									$this->_candidateValue = $relation->Start_O_UUID();
								}
								break;
						}
					}
			} 
		}
		
		protected function _calculateDistance () {
// $GLOBALS['logHandler']->debug(__METHOD__);
// $GLOBALS['logHandler']->debug('$this->_baseValue', $this->_baseValue);
// $GLOBALS['logHandler']->debug('$this->_candidateValue', $this->_candidateValue);
			if ( $this->_baseValue and $this->_candidateValue)
				$this->_distance = (($this->_baseValue == $this->_candidateValue)? 0:1);
// $GLOBALS['logHandler']->debug('$this->_distance', $this->_distance);
		}
		
		
		# ==========================================================================================
		# Public Instance Methods                                            Public Instance Methods
		# ==========================================================================================

		public function __construct ( $baseAV, $candidateAV) {
			$this->_setBaseAV ($baseAV);
			$this->_setCandidateAV ($candidateAV);
			$this->_calculateDistance();
		}
	}

	
?>