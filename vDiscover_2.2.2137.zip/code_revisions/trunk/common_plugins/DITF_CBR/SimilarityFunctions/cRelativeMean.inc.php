<?php if (!defined('APPLICATION_started')) {header('Location: .');exit;} 
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	class cRelativeMean extends cLocalDistanceFunction {
		
		
		# ==========================================================================================
		# Instance Properties                                                    Instance Properties
		# ==========================================================================================

		
		protected $_attrKinds = array('cNumberAttribute');
		
		protected $_baseValue = null; 
		protected $_candidateValue = null; 
		
		
		# ==========================================================================================
		# Static Properties                                                        Static Properties
		# ==========================================================================================

		
		# ==========================================================================================
		# Public Instance Methods                                            Public Instance Methods
		# ==========================================================================================

		// public function __construct ( $baseAV, $candidateAV) {
			// $this->_setBaseAV ($baseAV);
			// $this->_setCandidateAV ($candidateAV);
			// $this->_calculateDistance();
		// }


		# ==========================================================================================
		# Protected Instance Methods                                      Protected Instance Methods
		# ==========================================================================================

		
		// protected function _setBaseAV ( $baseAV ) {
			// if (count($baseAV)>0){
				// foreach ($baseAV as $AVObject){
					// $cAV = $this->_getRealAV($AVObject);
				// }
				// if ( is_object($cAV) and ( in_array(preg_replace ( '/Value\z/' , '' , get_class($cAV),1 ), $this->_attrKinds) ) )
					// $this->_baseValue = $cAV->value_number();
			// } 
		// }
		

		// protected function _setCandidateAV ( $candidateAV ) {
			// if (count($candidateAV)>0){
				// foreach ($candidateAV as $AVObject){
					// $cAV = $this->_getRealAV($AVObject);
				// }
				// if ( is_object($cAV) and ( in_array(preg_replace ( '/Value\z/' , '' , get_class($cAV),1 ), $this->_attrKinds) ) )
					// $this->_candidateValue = $cAV->value_number();
			// } 
		// }
		

		protected function _calculateDistance () {
			if ( $this->_baseValue and $this->_candidateValue)
				$this->_distance = self::relativeMean($this->_baseValue, $this->_candidateValue);
		}
		
		
		# ==========================================================================================
		# Public Static Methods                                                Public Static Methods
		# ==========================================================================================
		
		
		public static function relativeMean($baseValue, $candidateValue) {
			return(abs($baseValue - $candidateValue) / max($baseValue, $candidateValue));
		} # end-of-method relativeMean
		
		
	} # end-of-class cRelativeMean


?>