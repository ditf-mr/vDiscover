<?php if (!defined('APPLICATION_started')) {header('Location: .');exit;} 
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # load relevant functions
		require_once($repository_config['application_path'].DIRECTORY_SEPARATOR.'web_browser'.DIRECTORY_SEPARATOR.'json/Object.json/get_O_view2_functions.inc.php');
	}


	class CBRException extends Exception {
	
	
		# ==========================================================================================
		# Instance Properties                                                    Instance Properties
		# ==========================================================================================


		protected $_errorNo = 0;
		
		
		# ==========================================================================================
		# Public Instance Methods                                            Public Instance Methods
		# ==========================================================================================
		
		
		public function __construct ($errorNo=0) {
			$this->_errorNo = $errorNo;
		} # end-of-function __construct
		
		
		public function errorNo() {
			return($this->_errorNo);
		} # end-of-method errorNo
		
		
	} # end-of-class CBRException
	
	
	class cCBR {
		
		
		# ==========================================================================================
		# Instance Properties                                                    Instance Properties
		# ==========================================================================================

		
		/**
		 * Stores the error state (0 = no error). The possible errors are listed in the static
		 * property 'errors'.
		 */
		protected $_errorNo = 0;
		
		
		/**
		 * Stores the auxilary error message, if errorNo=999.
		 */
		protected $_errorAuxMsg = '';
		
		
		/**
		 * Keeps the object, that will be manipulated by the adaptation results.
		 */
		protected $_caseObject = null;
		
		
		/**
		 * The object that keeps the cbr configuration.
		 */
		protected $_CBRconfig = null;  
		

		/**
		 * The buffer for the adapted attribute values. Structure of this associative array is:
		 * A_UUID => values.
		 */
		protected $_adaptationBuffer = array();
		
		
		# ==========================================================================================
		# Static Properties                                                        Static Properties
		# ==========================================================================================
		
		
		/** 
		 * Type Enumeration:
		 * - 1: first similar case identified and then based on them the values estimated
		 * - 2: the values will be calculated directly from other values
		 * - 3: only the similar case will be identified.
		 */
		public static $pT_standard = 1;
		public static $pT_estimateDirectly = 2;
		public static $pT_similarCases = 3;
		
		
		/**
		 * List of Errors
		 */
		public static $errors = array(
			0 => 'No error.',
			1 => 'Case object not found.',
			2 => 'Case base object type not found.',
			3 => 'Syntax error in configuration. Error during decoding of json structure.',
			4 => 'Process type of influence set is invalid.',
			999 => 'Unknow CBR error'
		);
		
		
		# ==========================================================================================
		# Public Instance Methods                                            Public Instance Methods
		# ==========================================================================================
		
		
		public function __construct( $caseObject_O_v_UUID , $jsonConfig ) {
			/** 
			 * Starts a CBR process. 
			 * @param $caseObject_O_v_UUID. The incomplete case that will be completed.
			 * @param $jsonConfig string. The configuration of the CBR process. May contain 
			 * 		comments, as follows:
			 * 		- slash star ... star slash,  standard php or c mutliline comment
			 *		- slash slash single line comment
			 */
			{ # Start exception handling of the CBR routine
				try{
					{ # Checks if the given UUID refers to a object. If so, this object will be saved as 
					  # case object, else an error will arise.
						if (!$this->_setCaseObject($caseObject_O_v_UUID)) {
							throw new CBRException(1);
						}
					}
					{ # Save CBR configuration given in json format.
						$this->_setCBRconfig($jsonConfig);
					}
					{ # Walk through all influence sets and perform adaptation
						foreach ($this->CBRconfig()->influenceMatrix() as $k => $influenceSet) {
							set_time_limit(500);
							$influenceSet->process();
						} # end foreach influence set
					}
					{ # Mark this object as a CBR proposal
						if ($this->_CBRconfig->CBRProposalsEnabled()) {
							$this->_caseObject->setAttributeValue_noCheck($this->_CBRconfig->CBRProposals_A_UUID(), 'value_listKey', $this->_CBRconfig->CBRProposals_valueToMark());
						}
					}
				} catch (CBRException $e) {
					$this->_errorNo = $e->errorNo();
					return(false);
				} catch (Excpetion $e) {
					$this->_errorNo = 999;
					$this->_errorAuxMsg = $e->gerMessage();
					return(false);
				}
			}
		} # end-of-method __construct
		
		
		public function error() {
			/**
			 * Return the error state (0 = No error).
			 * @return integer.
			 */
			return($this->_errorNo);
		} # end-of-method error
		
		
		public function errorAuxMsg() {
			/**
			 * Return the auxilary error message. Only relevant for error=999.
			 * @return string.
			 */
			return($this->_errorAuxMsg);
		} # end-of-method errorAuxMsg
		
		
		public function caseObject() {
			/** 
			 * Return the case object, the object that was manipulated.
			 * @return object.
			 */
			return($this->_caseObject);
		} # end-of-method caseObject
		
		
		public function caseObject_O_v_UUID(){
			/**
			 * Return the O_v_UUID of the case object.
			 * @return \ref UUID-string.
			 */
			return($this->_caseObject->O_v_UUID());
		} # end-of-method caseObject_O_v_UUID

		
		public function CBRconfig() {
			/**
			 * Returns the CBRconfig object, that keeps the configuration information.
			 * @return object.
			 */
			return($this->_CBRconfig);
		} # end-of-method CBRconfig

		
		public function buildCandidateCaseCriteriumForCBRProposalStatus($caseCandidateRetrievalCriteria) {
			/**
			 * If CBR proposals should be considered in the CBR process, this function returns 
			 * null. If not it returns a candidate case retrieval criterium, that filters out all
			 * cases that are not yet proved CBR proposals.
			 * @param $caseCandidateRetrievalCriteria array.
			 * @return null. CBR proposals should be used.
			 * @return array. CBR proposals should not be used. A criterium.
			 */
			global $backend;
			if (!$this->CBRconfig()->CBRProposals_useCBRProposals()) {
				{ # Get information about the attribute
					if (!is_null($attribute = $backend->getAttribute($this->CBRconfig()->CBRProposals_A_UUID()))) {
						$caseCandidateRetrievalCriteria[$attribute->A_UUID()] = $attribute->buildRetrievalCriteriumForEquality($this->CBRconfig()->CBRProposals_valueToMark(), true);
					}
				}
			}
			return($caseCandidateRetrievalCriteria);
		} # end-of-method buildCandidateCaseCriteriumForCBRProposalStatus()
		
		
		public function getNumberOfInfluenceSets() {
			/**
			 * Returns the number of influence sets in the influence matrix.
			 * @return integer.
			 */
			return(count($this->_CBRconfig->influenceMatrix()));
		} # end-of-method getNumberOfInfluenceSets
		
		
		public function influenceSet($offset) {
			/**
			 * Returns the influence set at position $offset.
			 * @param $offset integer. 
			 * @return null. An influence set at position $offset does not exist.
			 * @return object. The influence set at the position $offset.
			 */
			return($this->_CBRconfig->influenceSet($offset));
		} # end-of-method influenceSet
		
		
		# ==========================================================================================
		# Public Static Methods                                                Public Static Methods
		# ==========================================================================================
		
		
		public static function getUUID($identifier) {
			/**
			 * Returns the UUID corresponding to the given identifier. Methods checks if the there
			 * is a global constant named $identifier. If so, ist value (a UUID) is returned.
			 * If not $identifer seems to be the UUID itself, so it is returned.
			 * @return string. A UUID.
			 */
			if (array_key_exists($identifier, $GLOBALS)) {
				return($GLOBALS[$identifier]);
			} else {
				return($identifier);
			}		
		} # end-of-function getUUID
		
		
		public static function removeCommentsInJson($jsonWithComments) {
			/**
			 * Removes comments in the given json string and returns the cleaned one. Allowed 
			 * comments are:
			 * 	- slash star ... star slash,  standard php or c mutliline comment
			 *	- slash slash single line comment
			 * @param $jsonWithComments string. Json string with comments.
			 * @return string. Json string without comments.
			 *
			 * Hint:
			 * Taken from http://stackoverflow.com/questions/643113/regex-to-strip-comments-
			 *	and-multi-line-comments-and-empty-lines
			 */
			{ # Build the regex rules for everything to be stripped
				$EOL = '([\n\r\f\v]+|$)';
				$multiLineCommentStart = '(/\*)';
				$multiLineCommentEnd = '(\*/)';
			}
			{ # Remove all comments
				$regexRules = array(
					# strips // ...
					'/\/\/.*'.$EOL.'/', 
					# strip multiline comments
					'!'.$multiLineCommentStart.'.*?'.$multiLineCommentEnd.'!s'
				);
				$jsonWithoutComments = preg_replace($regexRules, '', $jsonWithComments);
			}
			return($jsonWithoutComments);
		} # end-of-method removeCommentsInJson
		
		
		public static function processTypes() {
			return(
				array(
					$pT_standard, $pT_estimateDirectly, $pT_similarCases
				)
			);
		} # end-of-method processTypes
		
		
		# ==========================================================================================
		# Protected Instance Methods                                      Protected Instance Methods
		# ==========================================================================================
		
		
		protected function _setCBRconfig($jsonConfig) {
			/**
			 * Creates a new CBRconfig object and saves a reference to it.
			 * @param string. The configuration in json format.
			 */
			$this->_CBRconfig = new cCBRconfig($this, $jsonConfig);
		} # end-of-method _setCBRconfig
		
		
		protected function _setCaseObject($caseObject_O_v_UUID) {
			/**
			 * Retrieves the case object (the object that will be manipulated) by the given UUID.
			 * @param \ref UUID-string. The O_v_UUID of the case object.
			 * @return false. Failure, the case object was not found.
			 * @return true. Success. The case object was found.
			 */
			global $backend;
			return(!is_null($this->_caseObject = $backend->getObject($caseObject_O_v_UUID)));
		} # end-of-method _setCaseObject
		
		
	} # end-of-class cCBR
	
	
# ==================================================================================================


	class cCBRconfig {
				

		# ==========================================================================================
		# Instance Properties                                                    Instance Properties
		# ==========================================================================================

		
		/**
		 * Store the configuration, which was given in json format as php array. Analyses is then 
		 * performed on this array.
		 */
		protected $_configArray = '';
		
		
		/**
		 * Keeps the object type of the case base. The case object and all candidate cases are 
		 * objects of this object type.
		 */
		protected $_caseBaseOT = null;
		
		
		/**
		 * Keeps the information how to handle objects that habe been manipulated by the CBR module.
		 * This includes:
		 * - Mark them at the end of the CBR process.
		 * - Consider them during the CBR process.
		 */
		protected $_CBRProposals = null;
		
		
		/**
		 * Stores the number of instances that will be the limit the size of the overall set of  
		 * candidate cases (aspirants).
		 * @type integer.
		 */
		protected $_numberOfAspirantCases = 100;
		

		/**
		 * Specifies the strategy, which will be used to select the candidate case if the retrieval 
		 * for candidate cases delivers more than the parameter 
		 * "numberOfCandidateCasesForSimilarity" specifies. The following strategies are supported:
		 * - "newestFirst": cases that have been changed the latest will be prefered.
		 * - "random": candidate cases will be select randomly.
		 * This value may be overwritten in each influence set.
		 */
		protected $_candidateCasesSelectStrategy = '';
		
		
		/**
		 * Stores the default value for the number of cases that are used as candidates.
		 * This value may be overwritten in each influence set. 0 means no limit.
		 */
		protected $_numberOfCandidateCasesForSimilarity = 50;
		

		/**
		 * Stores the default value for the number of cases that are used for adaptation.
		 * This value may be overwritten in each influence set. 0 means no limit.
		 */
		protected $_numberOfSimilarCasesForAdaptation = 10;	
		

		/**
		 * Stores the default value for the treshold that is the maximum distance allowed for 
		 * similar cases.
		 */
		protected $_distanceThreshold = 1;
		
		
		/** 
		 * Keeps the influence matrix (all influence sets in an array).
		 */
		protected $_influenceMatrix = array();
		
		
		/**
		 * Keeps a reference to the CBR object.
		 */
		protected $_CBR = null;
				
		
		# ==========================================================================================
		# Public Instance Methods                                            Public Instance Methods
		# ==========================================================================================
		
		
		public function __construct($CBR, $jsonConfig) {
			/** 
			 * Calls several sub functions to do the analysing of the given configuration.
			 * @param $CBR object. The reference to the CBR object.
			 * @param $jsonConfig string. The configuration for the CBR process in json format. May
			 * 		contain comments (see cCBR::construct).
			 */
			{ # Rescue a reference to the CBR object. Must be done first!
				$this->_setCBR($CBR);
			}
			{ # Decode and store the given configuration in json format
				$this->_setConfigArray($jsonConfig);
			}
			{ # Analyse the configuration and save elements in corresponding properties.
				$this->_setCaseBaseOT();
				$this->_setCBRProposals();
				$this->_setNumberOfAspirantCases();
				$this->_setCandidateCasesSelectStrategy();
				$this->_setNumberOfCandidateCasesForSimilarity();
				$this->_setNumberOfSimilarCasesForAdaptation();
				$this->_setDistanceThreshold();
			}
			{ # Build influence matrix and save it
				$this->_setInfluenceMatrix();	
			}
		} # end-of-method __construct
		
		
		public function caseBaseOT() {
			/**
			 * Returns the case base object type.
			 * @return object. The object type.
			 */
			return($this->_caseBaseOT);
		} # end-of-method caseBaseOT
		
		
		public function CBRProposalsEnabled() {
			/**
			 * Returns if the CBR consideration module is enabled (cases can be marked and/or 
			 * identified as elaborated by the CBR module) or not.
			 * @return boolean. 
			 */
			return(isset($this->_CBRProposals) and !$this->_CBRProposals['disabled']);
		} # end-of-method CBRProposalsEnabled
		
		
		public function CBRProposals_A_UUID() {
			/**
			 * Returns the A_UUID of the attribute, that stores, if the object is one, which has 
			 * been elaborated from the CBR module.
			 * @return \ref UUID-string.
			 */
			if ($this->CBRProposalsEnabled()) {
				return($this->_CBRProposals['A_UUID']);
			}
			else {
				return(null);
			}
		} # end-of-method CBRProposals_A_UUID
		
		
		public function CBRProposals_valueToMark() {
			/**
			 * Returns the value, that will be used to mark a object as a case that has been 
			 * manipulated by the CBR module.
			 * @return mixed. 
			 */
			if ($this->CBRProposalsEnabled()) {
				return($this->_CBRProposals['valueToMark']);
			}
			else {
				return(null);
			}
		} # end-of-method CBRProposals_valueToMark
		
		
		public function CBRProposals_useCBRProposals() {
			/**
			 * Returns the flag that indicates if case that have been manipulated by the CBR
			 * module and have not been aproved sincde that moment, will be considered during
			 * the CBR process or not.
			 * @return true. Not yet approved CBR cases will be used in the CBR process.
			 * @return false. Not yet approved CBR cases will not be used in the CBR process.
			 */
			if ($this->CBRProposalsEnabled()) {
				return($this->_CBRProposals['useCBRProposals']);
			}
			else {
				return(true);
			}
		} # end-of-method CBRProposals_useCBRProposals
		
		
		public function numberOfAspirantCases() {
			/** 
			 * Returns the number of aspirant cases.
			 * @return integer.
			 */
			return($this->_numberOfAspirantCases);
		} # end-of-method numberOfAspirantCases

		
		public function candidateCasesSelectStrategy() {
			/**
			 * Returns the strategy that will be used if the retrieval for candidate cases delivers
			 * more cases than the property numberOfCandidateCasesForSimilarity allowes.
			 * @return string.
			 */
			return($this->_candidateCasesSelectStrategy);
		} # end-of-method candidateCasesSelectStrategy


		public function numberOfCandidateCasesForSimilarity() {
			/**
			 * Returns the default value for the number of cases that are used as candidates.
			 * @return integer.
			 */
			return($this->_numberOfCandidateCasesForSimilarity);
		} # end-of-method numberOfCandidateCasesForSimilarity


		public function numberOfSimilarCasesForAdaptation() {
			/**
			 * Returns the default value for the number of cases that are used for adaptation.
			 * @return integer;
			 */
			return($this->_numberOfSimilarCasesForAdaptation);
		} # end-of-method numberOfSimilarCasesForAdaptation


		public function distanceThreshold() {
			/**
			 * Returns the default value for the treshold of the maximum distance allowed.
			 * @return double.
			 */
			return($this->_distanceThreshold);
		} # end-of-method distanceThreshold

		
		public function influenceMatrix() {
			/** 
			 * Returns the structure that keeps the influence matrix.
			 * @return null. Influence matrix has not been created due to an error.
			 * @return array. The influence matrix.
			 */
			return($this->_influenceMatrix);
		} # end-of-method influenceMatrix

		
		public function influenceSet($offset) {
			/**
			 * Returns the influence set at position $offset.
			 * @param $offset integer. 
			 * @return null. An influence set at position $offset does not exist.
			 * @return object. The influence set at the position $offset.
			 */
			
			if (count($this->_influenceMatrix ) < $offset ) {
				return(null); # failure
			}
			$influenceMatrix = $this->_influenceMatrix;
			return($influenceMatrix[$offset]);
		} # end-of-method influenceSet
		
		
		public function CBR() {
			/**
			 * Returns the (reference to the) CBR object.
			 * @return object.
			 */
			return($this->_CBR);
		} # end-of-method CBR
		
		
		# ==========================================================================================
		# Protected Instance Methods                                      Protected Instance Methods
		# ==========================================================================================
		
		
		protected function _setCBR($CBR) {
			/**
			 * Rescues the given reference to the CBR object in the corresponding property.
			 * @param $CBR object. Reference to the CBR object.
			 */
			$this->_CBR = $CBR;
		} # end-of-method _setCBR
		
		
		protected function _setConfigArray($jsonConfig) {
			/**
			 * Saves the given configuration in json format in the corresponding property. 
			 * @param $jsonConfig. The configuration in json format. May contain comments, that
			 * 		will be filtered out before json_decode is applied.
			 */
			$this->_configArray = json_decode(cCBR::removeCommentsInJson($jsonConfig), true);
			if (json_last_error()) {
				throw new CBRException(3);
			}
		} # end-of-method _setConfigArray
		
		
		protected function _setCaseBaseOT() {
			/**
			 * Loads the case base object type. If the object type is not found an error arises.
			 */
			global $backend;			
			if (is_null($this->_caseBaseOT = $backend->getObjectType(cCBR::getUUID($this->_configArray['caseBaseOT'])))) {
				throw new CBRException(2);
			}
		} # end-of-method _setCaseBaseOT
		
		
		protected function _setCBRProposals() {
			/**
			 * Analyses the slot "CBRProposals", if it exists. If the slot not exists, this 
			 * functionality is disabled.
			 * 
			 */
			{ # set to default values
				$this->_CBRProposals = array(
					'disabled' => true,
					'A_UUID' => '',
					'valueToMark' => null,
					'useCBRProposals' => false
				);
			}
			if (isset($this->_configArray['CBRProposals'])) {
				$temp = $this->_configArray['CBRProposals'];
				$this->_CBRProposals['disabled'] = false;
				{ # check A_UUID
					if (isset($temp['A_UUID'])) {
						if (array_key_exists($temp['A_UUID'], $GLOBALS)) {
							$this->_CBRProposals['A_UUID'] = $GLOBALS[$temp['A_UUID']];
						} else {
							$this->_CBRProposals['A_UUID'] = $temp['A_UUID'];
						}		
					}
					else {
						$this->_CBRProposals['disabled'] = true;
					}
				}
				{ # check valueToMark
					if (isset($temp['valueToMark'])) {
						$this->_CBRProposals['valueToMark'] = $temp['valueToMark'];
					}
					else {
						$this->_CBRProposals['disabled'] = true;
					}
				}
				{ # check useCBRProposals
					if (isset($temp['useCBRProposals'])) {
						$this->_CBRProposals['useCBRProposals'] = !empty($temp['useCBRProposals']);
					}
				}
			}
		} # end-of-method _setCBRProposals
		
		
		protected function _setNumberOfAspirantCases() {
			/** 
			 * Saves the number of aspirant cases in the corressponding property.
			 */
			$this->_numberOfAspirantCases = $this->_configArray['numberOfAspirantCases'];
		} # end-of-method _setnumberOfAspirantCases
		
		
		protected function _setCandidateCasesSelectStrategy() {
			/**
			 * Saves the strategy that will be used to select the cases if the retrieval for 
			 * candidate cases delivers more cases than the property 
			 * numberOfCandidateCasesForSimilarity allows.
			 */
			if (isset($this->_configArray['candidateCasesSelectStrategy'])) {
				$this->_candidateCasesSelectStrategy = $this->_configArray['candidateCasesSelectStrategy'];
			}
		} # end-of-method _setCandidateCasesSelectStrategy


		protected function _setNumberOfCandidateCasesForSimilarity() {
			/** 
			 * Saves the number of candidate case for similarity in the corressponding property.
			 */
			$this->_numberOfCandidateCasesForSimilarity = $this->_configArray['numberOfCandidateCasesForSimilarity'];
		} # end-of-method _setNumberOfCandidateCasesForSimilarity


		protected function _setNumberOfSimilarCasesForAdaptation() {
			/** 
			 * Saves the number of similar case for adaptation in the corressponding property.
			 */
			$this->_numberOfSimilarCasesForAdaptation = $this->_configArray['numberOfSimilarCasesForAdaptation'];
		} # end-of-method _setNumberOfSimilarCasesForAdaptation


		protected function _setDistanceThreshold() {
			/** 
			 * Saves the distance threshold in the corressponding property.
			 */
			$this->_distanceThreshold = $this->_configArray['distanceThreshold'];
		} # end-of-method _setDistanceThreshold
		
		
		protected function _setInfluenceMatrix() {
			/** 
			 * Builds up the influence matrix, that means creates an influence set object for each
			 * elements in the influence matrix and adds it to the internal array.
			 */
			foreach ($this->_configArray['influenceMatrix'] as $influenceSet){
				$this->_influenceMatrix[] = new cInfluenceSet ($this->CBR(), $influenceSet);
			}
		} # end-of-method _setInfluenceMatrix
		
		
	} # end-of-class cCBRconfig

	
# ==================================================================================================


	class cInfluenceSet {
		
		
		/**
		 * Store the configuration, which was given as php array. Analyses is then performed on 
		 * this array.
		 */
		protected $_configArray = '';
		
		/**
		 * Indicates if the influence set is used (and processed) or ignored.
		 * true = influence set is ignored
		 * false = (default) influence set is processed.
		 */
		protected $_ignore = false;
		
		
		/** 
		 * Keeps the type of influence set.
		 * 1 = Adaptation of values is based on values in similar cases.
		 * 2 = Values will be calculated directly form other values.
		 */
		protected $_type = 0;
		
		
		/**
		 * Keeps the list of attributes of which the similarity of the candidate depends and on 
		 * which adaptation is done. This is relevant only for type=1 influence sets.
		 */
		protected $_dependencies = array();
		
		
		/**
		 * Keeps the list of attributes of this influence set. All attributes will be adaptated
		 * on basis of the same candidate cases.
		 */
		protected $_attrList = array();
		
		
		/**
		 * Specifies the strategy, which will be used to select the candidate case if the retrieval 
		 * for candidate cases delivers more than the parameter 
		 * "numberOfCandidateCasesForSimilarity" specifies. The following strategies are supported:
		 * - "newestFirst": cases that have been changed the latest will be prefered.
		 * - "random": candidate cases will be select randomly.
		 * If not specified or empty the global one is used.
		 */
		protected $_candidateCasesSelectStrategy = '';
		
		
		/**
		 * Stores the default value for the number of cases that are used as candidates.
		 * If -1 the global one is used. 0 means no limit.
		 */
		protected $_numberOfCandidateCasesForSimilarity = -1;
		

		/**
		 * Stores the default value for the number of cases that are used for adaptation.
		 * If -1 the global one is used. 0 means no limit.
		 */
		protected $_numberOfSimilarCasesForAdaptation = -1;	
		

		/**
		 * Stores the default value for the treshold that is the maximal distance allowed for 
		 * similar cases.
		 * If negativ the global one is used.
		 */
		protected $_distanceThreshold = -1;
		
		
		/**
		 * Keeps the list of candidate cases. The structure of this array is:
		 * O_v_UUID => distance.
		 * Hint: Default (initialisation) value for the distance is 1.
		 */
		protected $_candidateCasesUUID = array();
		
		
		/**
		 * Keeps the list of similar cases. Similar cases are the candidate cases with a distance
		 * less than the threshold. The structure of this array is:
		 * O_v_UUID => distance.
		 * Hint: Default (initialisation) value for the distance is 1.
		 */
		protected $_similarCasesUUID = array();
		
		
		/** 
		 * Keeps the estimated values of the attributes. These values are the results of the 
		 * adaptation. The structure of this array is:
		 * A_UUID => values
		 */
		protected $_adaptationBuffer = array(); 

		
		/** 
		 * Keeps a reference of the CBR object.
		 */
		protected $_CBR = '';
		
		
		/**
		 * ???
		 */
		protected $_prediction = array(); # array of attribute values
		
		
		# ==========================================================================================
		# Public Instance Methods                                            Public Instance Methods
		# ==========================================================================================
		
		
		public function __construct($CBR, $influenceSet) {
			/**
			 * @param $CBR object. The reference to the CBR object.
			 * @param $influenceSet array. The configuration of the influence set.
			 */
			$this->_setConfigArray($influenceSet);
			set_time_limit(100);
			$this->_setCBR($CBR);
			$this->_setIgnore();
			$this->_setType();
			$this->_setCandidateCasesSelectStrategy();
			$this->_setNumberOfCandidateCasesForSimilarity();
			$this->_setNumberOfSimilarCasesForAdaptation();
			$this->_setDistanceThreshold();
			switch($this->type()) {
				case cCBR::$pT_standard: {
					$this->_setDependencies();
					$this->_setAttrList();
					break;
				}
				case cCBR::$pT_estimateDirectly: {
					$this->_setAttrList();
					break;
				}
				case cCBR::$pT_similarCases: {
					$this->_setDependencies();
					$this->_setAttrList();
					break;
				}
				default: {
					throw new CBRException(4);
				}
			}
		} # end-of-method __construct
		
		
		public function ignore() {
			/** 
			 * Returns whether the influence set is processed or ignored.
			 * @return true. The influence set is ignored.
			 * @return false. The influence set is processed.
			 */
			return($this->_ignore);		
		} # end-of-method ignore
		
		
		public function type() {
			/** 
			 * Returns the type of the influence set.
			 * 1 = Adaptation of values is based on values in similar cases.
			 * 2 = Values will be calculated directly form other values.
			 * @return integer;
			 */
			return($this->_type);		
		} # end-of-method type
		
		
		public function candidateCasesSelectStrategy() {
			/**
			 * Returns the number of cases that are used as candidates for this influence set.
			 * If there is no individual value for this influence set, the global one is used.
			 * @return integer;
			 */
			if ($this->_candidateCasesSelectStrategy != '') {
				return($this->_candidateCasesSelectStrategy);
			}
			else {
				return($this->_CBR->CBRconfig()->candidateCasesSelectStrategy());
			}
		} # end-of-method candidateCasesSelectStrategy
		
		
		public function numberOfCandidateCasesForSimilarity() {
			/**
			 * Returns the number of cases that are used as candidates for this influence set.
			 * If there is no individual value for this influence set, the global one is used.
			 * @return integer;
			 */
			if ($this->_numberOfCandidateCasesForSimilarity >= 0) {
				return($this->_numberOfCandidateCasesForSimilarity);
			}
			else {
				return($this->_CBR->CBRconfig()->numberOfCandidateCasesForSimilarity());
			}
		} # end-of-method numberOfCandidateCasesForSimilarity
		
		
		public function numberOfSimilarCasesForAdaptation() {
			/**
			 * Returns the number of cases that are used for the adaptation for all attributes of
			 * this influence set.
			 * If there is no individual value for this influence set, the global one is used.
			 * @return integer;
			 */
			if ($this->_numberOfSimilarCasesForAdaptation >= 0) {
				return($this->_numberOfSimilarCasesForAdaptation);
			}
			else {
				return($this->_CBR->CBRconfig()->numberOfSimilarCasesForAdaptation());
			}
		} # end-of-method numberOfSimilarCasesForAdaptation
		
		
		public function distanceThreshold() {
			/**
			 * Returns the default value for the treshold of the maximal distance allowed.
			 * If there is no individual value for this influence set, the global one is used.
			 * @return double. (0..1)
			 */
			if ($this->_distanceThreshold >= 0) {
				return($this->_distanceThreshold);
			}
			else {
				return($this->_CBR->CBRconfig()->distanceThreshold());
			}
		} # end-of-method distanceThreshold
		
		
		public function dependencies() {
			return $this->_dependencies;		
		} # end-of-method dependencies
		
		
		public function attrList() {
			return $this->_attrList;	
		} # end-of-method attrList
		
		
		public function getInfluencingAttrList() {
			return array_keys($this->_dependencies);		
		} # end-of-method getInfluencingAttrList
		
		
		public function getAffectedAttrList() {
			return array_keys($this->_attrList);		
		} # end-of-method getAffectedAttrList
		
		
		public function getInfluencingWeightByAttr($attr) {
			return $this->_dependencies[$attr]['weight'];		
		} # end-of-method getInfluencingWeightByAttr
		
		
		public function getDistancefunctionByAttr($attr) {
			return $this->_dependencies[$attr]['function'];		
		} # end-of-method getDistancefunctionByAttr
		
		
		public function getAdaptationFunctionByAttr($attr) {
			return $this->_attrList[$attr]['function'];		
		} # end-of-method getAdaptationFunctionByAttr
		
		
		public function candidateCasesUUID() {
			return($this->_candidateCasesUUID);
		} # end-of-method candidateCasesUUID
				
		
		public function similarCasesUUID() {
			return($this->_similarCasesUUID);
		} # end-of-method similarCasesUUID
				
		
		public function CBR() {
			/**
			 * Returns the (reference to the) CBR object.
			 * @return object.
			 */
			return($this->_CBR);
		} # end-of-method CBR
		
		
		public function process() {
			
			/**
			 * Decides in consideration of the type which process routine must be called and
			 * then calls it.
			 */
			{ # Check whether the influence set should be ignored or not
				if ($this->_ignore) {
					return;
				}
			}
			switch($this->_type) {
				case cCBR::$pT_standard: {
					$this->_processType1();
					break;
				}
				case cCBR::$pT_estimateDirectly: {
					$this->_processType2();
					break;
				}
				case cCBR::$pT_similarCases: {
					$this->_processType3();
					break;
				}
				default: {
					throw new CBRException(4);
				}
			} # end-of-switch
		} # end-of-method process
		
		
		# ==========================================================================================
		# Protected Instance Methods                                      Protected Instance Methods
		# ==========================================================================================
		
		
		protected function _setConfigArray($configArray) {
			/**
			 * Resues the given influence set config array in the corresponding property.
			 * @param $configArray array.
			 */
			$this->_configArray = $configArray;
		} # end-of-method _setConfigArray
		
		
		protected function _setCBR($CBR) {
			/**
			 * Rescues the given reference to the CBR object in the corresponding property.
			 * @param $CBR object. Reference to the CBR object.
			 */
			$this->_CBR = $CBR;
		} # end-of-method _setCBR
		
		
		protected function _setIgnore() {
			/**
			 * Saves whether the influence set will be ignored or processed (default). 
			 */
			if (isset($this->_configArray['ignore'])) {
				$this->_ignore = !empty($this->_configArray['ignore']);
			}
		} # end-of-method _setIgnore
		
		
		protected function _setType() {
			/**
			 * Saves the type of the influence set in the corresponding property.
			 */
			if (isset($this->_configArray['type'])) {
				$this->_type = $this->_configArray['type'];
			}
		} # end-of-method _setType
		
		
		protected function _setCandidateCasesSelectStrategy() {
			/**
			 * Saves the strategy that will be used to select the cases if the retrieval for 
			 * candidate cases delivers more cases than the property 
			 * numberOfCandidateCasesForSimilarity allows.
			 */
			if (isset($this->_configArray['candidateCasesSelectStrategy'])) {
				$this->_candidateCasesSelectStrategy = $this->_configArray['candidateCasesSelectStrategy'];
			}
		} # end-of-method _setCandidateCasesSelectStrategy


		protected function _setNumberOfCandidateCasesForSimilarity() {
			/**
			 * Saves the number of candidate casees for similarity of the influence set in the  
			 * corresponding property.
			 */
			if (isset($this->_configArray['numberOfCandidateCasesForSimilarity'])) {
				$this->_numberOfCandidateCasesForSimilarity = $this->_configArray['numberOfCandidateCasesForSimilarity'];
			}
		} # end-of-method _setNumberOfCandidateCasesForSimilarity


		protected function _setNumberOfSimilarCasesForAdaptation() {
			/**
			 * Saves the number of candidate cases for adaptation of the influence set in the  
			 * corresponding property.
			 */
			if (isset($this->_configArray['numberOfSimilarCasesForAdaptation'])) {
				$this->_numberOfSimilarCasesForAdaptation = $this->_configArray['numberOfSimilarCasesForAdaptation'];
			}
		} # end-of-method _setNumberOfSimilarCasesForAdaptation


		protected function _setDistanceThreshold() {
			/**
			 * Saves the distance threshold of this influence set in the corresponding property.
			 */
			if (isset($this->_configArray['distanceThreshold'])) {
				$this->_distanceThreshold = $this->_configArray['distanceThreshold'];
			}
		} # end-of-method _setDistanceThreshold
		
		
		protected function _setDependencies() {
			/**
			 * Saves the list of dependencies of this influence set in the corresponding property.
			 */
			$this->_dependencies = array();
			if (isset($this->_configArray['dependencies'])) {
				foreach ($this->_configArray['dependencies'] as $attributeIdentifier => $A_config) {
					$A_UUID = cCBR::getUUID($attributeIdentifier);
					$this->_dependencies[$A_UUID] = $A_config;
				}
			}
		} # end-of-method _setDependencies
		
		
		protected function _setAttrList() {
			/**
			 * Saves the list of attrList elements of this influence set in the corresponding 
			 * property.
			 */
			$this->_attrList = array();
			if (isset($this->_configArray['attrList'])) {
				foreach ($this->_configArray['attrList'] as $attributeIdentifier => $A_config ) {
					$A_UUID = cCBR::getUUID($attributeIdentifier);
					$this->_attrList[$A_UUID] = $A_config;
				}
			}
		} # end-of-method _setAttrList

		
		protected function _processType1() {
			/**
			 * Processes this influence set, which is a type 1.
			 * "Adaptation of values from values in similar cases".
			 * Work to do for this type of influence set:
			 * - Retrieve candidate cases for the influence set (consider 
			 * 	"numberOfCandidateCasesForSimilarity").
			 * - Calculate distance of each candidate case
			 * - Order candidate cases by distance
			 * - Take best X candidate case for adaptation (consider 
			 * 	"numberOfSimilarCasesForAdaptation")
			 * - Adapt the attribute value.
			 */
			{ # Retrieve candidate cases
				$this->_setCandidateCasesUUID();
// $GLOBALS['logHandler']->debug('$this->_candidateCasesUUID', $this->_candidateCasesUUID);
			}
			{ # Calculate distances to each candidate cases
				$this->_calculateDistanceOfAllCandidateCases();
			}
			{ # Order candidate case by distance
				asort($this->_candidateCasesUUID, SORT_NUMERIC);
// $GLOBALS['logHandler']->debug('$this->_candidateCasesUUID', $this->_candidateCasesUUID);
			}
			{ # Remove all candidate cases below threshold
				$this->_getSimilarCasesFromCandidateCases();
// $GLOBALS['logHandler']->debug('$this->_similarCasesUUID', $this->_similarCasesUUID);
			}
			{ # Calculate prediction from best results
				$this->_calculatePrediction();
			}
			{ # Save adapted values
				foreach($this->_prediction as $A_UUID => $store) {
					$this->_CBR->caseObject()->setAttributeValue_noCheck($A_UUID, $store['slot'], $store['value']);
				}
			}
		} # end-of-method _processType1
		
		
		protected function _processType2() {
			/**
			 * Processes this influence set, which is a type 2.
			 * "Calculation of values directly from other values of the case".
			 * Work to do for this type of influence set:
			 * - Compute attribute values directly from other attribute values.
			 */
			foreach($this->_attrList as $A_UUID => $config) {
				$functionClass = $config['function'];
				$params = $config['paramList'];
				$paramList = array();
				foreach($params as $param) {
					$anA_UUID = cCBR::getUUID($param);
					$paramValue = $this->_CBR->caseObject()->getAttributeValueAsText($anA_UUID);
					$paramList[] = $paramValue;
				}
				$adaptationFunctionObject = new $functionClass($A_UUID, $paramList);
				$this->_CBR->caseObject()->setAttributeValue_noCheck($A_UUID, $adaptationFunctionObject->valueSlot(), $adaptationFunctionObject->value());
			}
		} # end-of-method _processType2
		
		
		protected function _processType3() {
			/**
			 * Processes this influence set, which is a type 3.
			 * "Identification of the similar cases only".
			 * Work to do for this type of influence set:
			 * - Retrieve candidate cases for the influence set (consider 
			 * 	"numberOfCandidateCasesForSimilarity").
			 * - Calculate distance of each candidate case
			 * - Order candidate cases by distance
			 * - Adapt the attribute value.
			 */
			{ # Retrieve candidate cases
				$this->_setCandidateCasesUUID();
// $GLOBALS['logHandler']->debug('$this->_candidateCasesUUID', $this->_candidateCasesUUID);
			}
			{ # Calculate distances to each candidate cases
				$this->_calculateDistanceOfAllCandidateCases();
			}
			{ # Order candidate case by distance
				asort($this->_candidateCasesUUID, SORT_NUMERIC);
			}
// $GLOBALS['logHandler']->debug('$this->_candidateCasesUUID', $this->_candidateCasesUUID);
			{ # Remove all candidate cases below threshold
				$this->_getSimilarCasesFromCandidateCases();
			}
// $GLOBALS['logHandler']->debug('$this->_similarCasesUUID', $this->_similarCasesUUID);
		} # end-of-method _processType3
		
		
		protected function _setCandidateCasesUUID() {	
			/** 
			 * Performs a retrieval to get the candiate cases of this influence set. The query is a 
			 * RS standard query. Its conditions are saved in the dependencies of this influence
			 * set in the slot "candidateCaseQueryCondition".
			 * The candidate case query conditions of all elementes of the dependecies are must 
			 * criteria that are combined by a logical and.
			 */
			global $backend;
			$criteria = array();
			{ # Walk through all dependencies and build query criterium
				foreach($this->_dependencies  as $A_UUID => $A_config) {
					if (is_null($attribute = $backend->getAttribute($A_UUID))) {
						continue; # skip
					}
					{ # Check if there is a query condition for this attribute. If not skip.
						if (!isset($A_config['candidateCaseQueryCondition'])) {
							continue; # skip
						}
						$criterium = array();
						foreach($A_config['candidateCaseQueryCondition'] as $key => $value) {
							if (preg_match('/(.*)(\$\{([^{}\n]*)\})(.*)/', $value, $matches)) {
								$prafix = $matches[1];
								$suffix = $matches[4];
								$slot = $matches[3];
								$attributeValue = $this->_getAttributeValue4RetrievalQuery($this->_CBR->caseObject(), $attribute, $slot);
								$criterium[$key] = $attributeValue;
							}
							else {
								$criterium[$key] = $value;
							}
						}
						$criteria[$A_UUID] = $criterium;
					}
				}
			}
			{ # Add criterium for CBRProposals if CBR proposals should not be used for the CBR 
			  # process (see "CBRProposals"/"useCBRProposals").
				$criteria = $this->_CBR->buildCandidateCaseCriteriumForCBRProposalStatus($criteria);
// $GLOBALS['logHandler']->debug('$criteria', $criteria);
			}
			{ # Perform the query and collect candidate cases
				$this->_candidateCasesUUID = array();
				$countCandidates = 0;
				if (count($criteria) > 0) {
					{ # Perform query, order by clause is set to 'changed at desc' to ensure
					  # that newer objects are prefered.
						$results = $this->_CBR->CBRconfig()->caseBaseOT()->retrieveBy_attributeValues(
							$criteria, 
							false, 
							'changedAt desc'
						);
					}
					{ # Consider selection strategy
						switch ($this->candidateCasesSelectStrategy()) {
							case 'random': {
								shuffle($results);
								break;
							}
							case 'newestfirst':
							default: {	
								# do nothing, result set is already order by changed at desc.
							}
						}
					}
					{ # Collect the candidate cases
						foreach($results as $O_UUID => $result) {
							$setting = current($result);
							if ($setting->O_v_UUID() != $this->_CBR->caseObject_O_v_UUID()) {
								$countCandidates++;
								$this->_candidateCasesUUID[$setting->O_v_UUID()] = 1;
								if (($this->numberOfCandidateCasesForSimilarity() != 0)
								and ($countCandidates >= $this->numberOfCandidateCasesForSimilarity())) {
									break;
								}
							}
						}
					}
				}
				else {
					$results = $this->_CBR->CBRconfig()->caseBaseOT()->getObjects(cObject::vtCurrent, 'changedAt desc', false);
					{ # Consider selection strategy
						switch ($this->candidateCasesSelectStrategy()) {
							case 'random': {
								shuffle($results);
								break;
							}
							case 'newestfirst':
							default: {	
								# do nothing, result set is already order by changed at desc.
							}
						}
					}
					{ # Collect the candidate cases
						foreach($results as $O_v_UUID) {
							if ($O_v_UUID != $this->_CBR->caseObject_O_v_UUID()) {
								$countCandidates++;
								$this->_candidateCasesUUID[$O_v_UUID] = 1;
								if (($this->numberOfCandidateCasesForSimilarity() != 0)
								and ($countCandidates >= $this->numberOfCandidateCasesForSimilarity())) {
									break;
								}
							}
						}
					}
				}
			}
		} # end-of-method _setCandidateCasesUUID
		
	
		protected function _getAttributeValue4RetrievalQuery($object, $attribute, $slot) {
			/**
			 * Returns the content of the slot $slot in the attribute value of the attribute 
			 * $attribute of the object $object. If retrievalSupportsMultipleValuesInOrCombination
			 * (a property of the attribute) is true, then a list with all values is returned.
			 */
			global $backend;
			if (!is_a($attribute, 'cRelationAttribute')) {
				$attributeValues = $object->getAttributeValues($attribute->A_UUID());
				if (count($attributeValues) == 0) {
					return(null); # not attribute values
				}
				else {
					if ($attribute->retrievalSupportsMultipleValuesInOrCombination()) {
						$list = array();
						foreach($attributeValues as $attributeValue) {
							$attributeValueAsArray = $attributeValue->toArray();
							$list[] = $attributeValueAsArray[$slot];
						}
						return($list);
					}
					else {
						$attributeValue = current($attributeValues);
						$attributeValueAsArray = $attributeValue->toArray();
						return($attributeValueAsArray[$slot]);
					}
				}
			}
			else {
				$resultSet = array();
				{ # Get information about relation type, its direction and retrieve end (or start) 
				  # objects.
					$relationType = $attribute->selected_RT();
					if (in_array($relationType->Start_OT_UUID(), $object->OT()->getObjectTypeHierarchy())) {
						$inverse = false;
						$relations = cRelation::getBy_Start_O_UUID_RT_UUID($object->O_UUID(), $attribute->selected_RT_UUID());
					}
					else if (in_array($relationType->End_OT_UUID(), $object->OT()->getObjectTypeHierarchy())) {
						$inverse = true;
						$relations = cRelation::getBy_End_O_UUID_RT_UUID($object->O_UUID(), $attribute->selected_RT_UUID());
					}
					else {
						return(null); # failure
					}
					{ # Walk through the list of relations, get end object an the attribute values there.
						foreach($relations as $relation) {
							if ($inverse) {
								$endObject = $relation->Start_O();
							}
							else {
								$endObject = $relation->End_O();
							}
							switch($attribute->showWhat()) {
								case 'V': {
									{ # Get end object O_v_UUID, but nothing else
										$resultSet[] = $endObject->O_v_UUID();
									}
									break;
								}
								case 'A': {
									{ # Collect information an go into recursion
										{ # Get relevant attribute. This may be inherited, so it depends 
										  # on the cObjectType.
											if (is_null($thisAttribute = $backend->getAttribute($attribute->show_UUID()))) {
												return (null); # failure
											}
											$origin_A_UUID = $thisAttribute->A_origin()->A_UUID();
											if (is_null($attributeAtEndObject = cAttribute::getBy_A_origin_UUID($origin_A_UUID, $endObject->OT_UUID()))) {
												return(null); # failure
											}
										}
										$subResultSet = $this->_getAttributeValue4RetrievalQuery($endObject, $attributeAtEndObject, $slot);
									}
									if (! is_null($subResultSet)) {
										if (is_array($subResultSet)) {
											$resultSet = array_merge($resultSet, $subResultSet);
										}
										else {
											$resultSet[] = $subResultSet;
										}
									}
									break;
								}
								default: {
									return(null); # failure
								}
							}
						} # end-foreach
					}
				}
				if (is_array($resultSet) and (count($resultSet) == 1)) {
					return(current($resultSet));
				}
				else {
					return($resultSet);
				}
			}
		} # end-of-method _getAttributeValue4RetrievalQuery
		

		protected function _calculateDistanceOfAllCandidateCases() {
			/**
			 * Walks through all candidate cases and calculates their distances.
			 */
			global $backend;
			foreach ($this->_candidateCasesUUID as $candidateCaseUUID => &$distance){
				{ # Ensure that the case object is not one of the candidates
					if ( $candidateCaseUUID != $this->CBR()->caseObject()->UUID() ){ 
						{ # Check for candidate object or skip
							if (is_null($candidateObject = $backend->getObject($candidateCaseUUID))) {
								continue; # skip the candidate if object does not exist
							}
						}
						{ # Compute local distances
							$dependencyDistanceSet = array();
							foreach($this->_dependencies as $A_UUID => $A_config) {
								if (!isset($A_config['function']) or !isset($A_config['weight']) or !class_exists($A_config['function'])) {
									continue; # skip
								}
								else {				
									$caseObjectAttributeValues = $this->_CBR->caseObject()->getAttributeValues($A_UUID);
									$candidateObjectAttributeValues = $candidateObject->getAttributeValues($A_UUID);
									if(isset($A_config['functionInitParams'])) {
										$distObj = new $A_config['function']( 	
											$caseObjectAttributeValues,
											$candidateObjectAttributeValues,
											$A_config['functionInitParams']
										);
									}
									else {
										$distObj = new $A_config['function']( 	
											$caseObjectAttributeValues,
											$candidateObjectAttributeValues
										);
									}
									$dependencyDistanceSet[$A_UUID] = array(
										'weight' => $A_config['weight'],
										'localDistance' => $distObj->distance()
									);
								}
							}
// $GLOBALS['logHandler']->debug('$dependencyDistanceSet', $dependencyDistanceSet);
						}
						{ # Compute distance from local distances
							$distanceSum = 0;
							$weightSum = 0;
							foreach($dependencyDistanceSet as $key => $res) {
								$distanceSum += $res['weight'] * pow($res['localDistance'], 2);
								$weightSum += $res['weight'];
							}
							$distance = sqrt($distanceSum/$weightSum);
						}
					}
				}
			}
		} # end-of-method _calculateDistanceOfAllCandidateCases
		
		
		protected function _calculatePrediction() {
			/**
			 * Performs the calculation of the adapted value. This consists of:
			 * - building up the adaption buffer, that means collecting all values, of which the
			 *		the adaption will be done
			 * - calculating the prediction out of this adaptation buffer.
			 */
			$this->_buildAdaptationBuffer();			
			$this->_calculateNewAttributeValues();
		} # end-of-method _calculatePrediction
		
		
		protected function _getSimilarCasesFromCandidateCases() {
			/**
			 * Remove all candidate case and generate the list of similar cases, where the 
			 * distance is less than the threshold.
			 */
			$this->_similarCasesUUID = array();
			foreach($this->_candidateCasesUUID as $candidateCaseUUID => $distance) {
				if ($distance <= $this->distanceThreshold()) {
					$this->_similarCasesUUID[$candidateCaseUUID] = $distance;
				}
			}
		} # end-of-method _getSimilarCasesFromCandidateCases
		
		
		protected function _buildAdaptationBuffer() {
			/**
			 * Builds up the adaptation buffer. This buffers collects all attribute values which
			 * are relevant for doing the prediction (adaptation) of the new values of all 
			 * similar case. This considers also the number of similar cases for adaptation.
			 */
			global $backend;
			$i = 0;
			foreach($this->_similarCasesUUID as $similarCaseUUID => $distance) {
				$i++;
				if ($i > $this->numberOfSimilarCasesForAdaptation()) {
					break; # leave foreach loop
				}
				{ # Get similar case object
					if (is_null($similarObject = $backend->getObject($similarCaseUUID))) {
						continue; # skip 
					}
				}
				{ # Get settings of candidate case
					foreach($this->_attrList as $attrUUID => $adaptationConfig){
						$attrValueArray = $similarObject->getAttributeValues($attrUUID);
						if (count($attrValueArray) > 0) {
							{ # Build result array structure
								if (!array_key_exists($attrUUID, $this->_adaptationBuffer)){
									$this->_adaptationBuffer[$attrUUID] = array();
								}						
							}
							$attrValueObject = current($attrValueArray);	
							$adaptationFunctionClass = $this->getAdaptationFunctionByAttr($attrValueObject->A_UUID());
							array_push(
								$this->_adaptationBuffer[$attrUUID], 
								$adaptationFunctionClass::getValueFromAV($attrValueObject)
							);
						}
					} # end-for-each
				}
			} # end-of-foreach
		} # end-of-method _buildAdaptationBuffer

		
		protected function _calculateNewAttributeValues () {
			/**
			 * Predictes the new values using the values stored in the adaptation buffer.
			 */
			global $backend;
			foreach ($this->_adaptationBuffer as $A_UUID => $attrValues) {
				{ # Get attribute
					$attribute = $backend->getAttribute($A_UUID);
				}				
				{ # Call adaption function (object) to do the prediction
					if (class_exists($this->getAdaptationFunctionByAttr($A_UUID))) {				
						$adaptationFunctionClass = $this->getAdaptationFunctionByAttr($A_UUID);
						$adaptationObject = new $adaptationFunctionClass($attribute, $attrValues);
						if ($adaptationObject->value() != null) {
							$this->_prediction[$A_UUID] = array(
								'slot' => $adaptationObject->valueSlot(),
								'value' => $adaptationObject->value()
							);
						}
					} else {
						continue; # continues with the next run in the loop
					}
				}
			} # end for each attribute 
		} # end-of-method _calculateNewAttributeValues
		

	} # end-of-class cInfluenceSet
	
		
# ==================================================================================================

	abstract class cLocalDistanceFunction {
	
	
		# ==========================================================================================
		# Instance Properties                                                    Instance Properties
		# ==========================================================================================

		
		protected $_attrKinds = array();
		
		
		protected $_distance = 1;
		
		
		# ==========================================================================================
		# Static Properties                                                        Static Properties
		# ==========================================================================================

		
		
		# ==========================================================================================
		# Protected Instance Methods                                      Protected Instance Methods
		# ==========================================================================================

		
		protected function _getRealAV ( $inputAV ) {
			global $backend;
			if ( is_a($inputAV, 'cRelationAttributeValue' ) ) {
				$relationAttribute = $inputAV->attribute();
				if ( $relationAttribute->showWhat() == 'A' ) {
					$atEndObject = __get_O_view2_getAttribute ( $inputAV->OR_v_UUID(), $inputAV->A_UUID(), 2 );

					# variables to manage the way to the interesting cAttributeValue Object
					$AV_UUID = $inputAV->AV_UUID();
	

					$helper = $atEndObject['attributesWithValueSets'][$inputAV->A_UUID()]['values']->$AV_UUID;
					$helper2 = current($helper['atEndObject']['attributesWithValueSets']);
					$helper3 = current($helper2['values']);
					
					if ($helper3['kind']== 'cRelationAttributeValue') {
						return $backend->getAttributeValue($helper3['AV_v_UUID']);
					} else {
						return $backend->getCurrentAttributeValue( $helper3['AV_UUID']);
					}
				} 
			}
			return $inputAV;
		} # end-of-method _getRealAV
		
		
		
		# ==========================================================================================
		# Public Instance Methods                                            Public Instance Methods
		# ==========================================================================================

		public function attrKinds() {
			return($this->_attrKinds);
		} # end-of-method attrKinds
		
		
		public function distance() {
			return($this->_distance);
		} # end-of-method distance
		
		
		# ==========================================================================================
		# Public Static Instance Methods									 Public Instance Methods
		# ==========================================================================================

		
		public static function getLocalDistanceFunctions(){
		    $result = array();
			foreach (get_declared_classes() as $class) {
				if (is_subclass_of($class, 'cLocalDistanceFunction')) {
					$result[] = $class;
				}
			}
			return($result);
		} # end-of-method getLocalDistanceFunctions
		
		
		public static function getLocalDistanceFunctionsByAttrKind($attrKind){
			$result = array();
			foreach (get_declared_classes() as $class) {
				if (is_subclass_of($class, 'cLocalDistanceFunction'))
					if (in_array( $attrKind, $class::attrKinds())){
						$result[] = $class::attrKinds();
					}
			}
			return $result;		
		} # end-of-method getLocalDistanceFunctionsByAttrKind
		
		
	} # end-of-class cLocalDistanceFunction


	abstract class cAdaptationFunction {
		# ==========================================================================================
		# Instance Properties                                                    Instance Properties
		# ==========================================================================================

		protected $_value = null; 
		protected $_valueSlot = null; 

		
		# ==========================================================================================
		# Static Properties                                                        Static Properties
		# ==========================================================================================

		static $attrKinds = array();

		
		# ==========================================================================================
		# Protected Instance Methods                                      Protected Instance Methods
		# ==========================================================================================

		protected function _getRealAV ( $inputAV ) {
			global $backend;
			if ( is_a($inputAV, 'cRelationAttributeValue' ) ) {
				$relationAttribute = $inputAV->attribute();
				if ( $relationAttribute->showWhat() == 'A' ) {
					$atEndObject = __get_O_view2_getAttribute ( $inputAV->OR_v_UUID(), $inputAV->A_UUID(), 2 );

					# variables to manage the way to the interesting cAttributeValue Object
					$AV_UUID = $inputAV->AV_UUID();
					$helper = $atEndObject['attributesWithValueSets'][$inputAV->A_UUID()]['values']->$AV_UUID;
					$helper2 = current($helper['atEndObject']['attributesWithValueSets']);
					$helper3 = current($helper2['values']);
					
					if ($helper3['kind']== 'cRelationAttributeValue') {
						return $backend->getAttributeValue($helper3['AV_v_UUID']);
					} else {
						return $backend->getCurrentAttributeValue( $helper3['AV_UUID']);
					}
				} /* else {
					return $inputAV;
				} */
			} /* else {
				return $inputAV;
			} */
			return $inputAV;
		}
		
		# ==========================================================================================
		# Public Instance Methods                                            Public Instance Methods
		# ==========================================================================================
		
		public function value() {
			return $this->_value;
		}

		public function valueSlot() {
			return $this->_valueSlot;
		}
			
		# ==========================================================================================
		# Public Static Instance Methods									 Public Instance Methods
		# ==========================================================================================

		public static function getLocalAdaptationFunctions (){
		
		    $result = array();
			foreach (get_declared_classes() as $class) {
				if (is_subclass_of($class, 'cAdaptationFunction'))
					$result[] = $class;
			}
			
			return $result;
		
		}
		
		public static function getLocalAdaptationFunctionsByAttrKind ( $attrKind ){
		    
			$result = array();
			foreach (get_declared_classes() as $class) {
				if (is_subclass_of($class, 'cAdaptationFunction'))
					if (in_array( $attrKind, $class::$attrKinds)){
						$result[] = $class::$attrKinds;
					}
			}
			
			return $result;		
		}
	
	}


?>