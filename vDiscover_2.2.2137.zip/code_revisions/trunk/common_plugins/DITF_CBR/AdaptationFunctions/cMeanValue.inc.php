<?php if (!defined('APPLICATION_started')) {header('Location: .');exit;} 
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	class cMeanValue extends cAdaptationFunction {
		# ==========================================================================================
		# Instance Properties                                                    Instance Properties
		# ==========================================================================================

		
		protected $_baseValue = null; 
		protected $_candidateValue = null; 
		protected $_valueSlot = 'value_number'; 

		
		# ==========================================================================================
		# Static Properties                                                        Static Properties
		# ==========================================================================================

		static $_attrKinds = array('cNumberAttribute');
		
		# ==========================================================================================
		# Protected Instance Methods                                      Protected Instance Methods
		# ==========================================================================================

		protected function _setBaseAV ( $baseAV ) {
			if (count($baseAV)>0){
				foreach ($baseAV as $AVObject){
					$cAV = $this->_getRealAV($AVObject);
				}
				if ( is_object($cAV) and ( in_array(preg_replace ( '/Value\z/' , '' , get_class($cAV),1 ), $this->_attrKinds) ) )
					$this->_baseValue = $cAV->value_number();
			} 
		}
		
		protected function _setCandidateAV ( $candidateAV ) {
			if (count($candidateAV)>0){
				foreach ($candidateAV as $AVObject){
					$cAV = $this->_getRealAV($AVObject);
				}
				
				if ( is_object($cAV) and ( in_array(preg_replace ( '/Value\z/' , '' , get_class($cAV),1 ), $this->_attrKinds) ) )
					$this->_candidateValue = $cAV->value_number();
			} 
		}
		
		protected function _calculateNewValue ($valueArray) {
			$this->_value = array_sum($valueArray)/count($valueArray);
		}		
		
		# ==========================================================================================
		# Public Instance Methods                                            Public Instance Methods
		# ==========================================================================================

		public function __construct ( $attribute, $valueArray ) {
			$this->_calculateNewValue($valueArray);
		}
		
		# ==========================================================================================
		# Public Static Instance Methods									 Public Instance Methods
		# ==========================================================================================

		public static function getValueFromAV ( $attrValueObject ) {
			if ( is_object($attrValueObject) and ( in_array(preg_replace ( '/Value\z/' , '' ,$attrValueObject->kind(),1 ), cMainValue::$attrKinds) ) ) {
				return $attrValueObject->value_number();
			}
			return null;
		}
	}


?>