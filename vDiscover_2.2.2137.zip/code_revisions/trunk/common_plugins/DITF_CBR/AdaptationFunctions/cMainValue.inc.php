<?php if (!defined('APPLICATION_started')) {header('Location: .');exit;} 
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	class cMainValue extends cAdaptationFunction {
		# ==========================================================================================
		# Instance Properties                                                    Instance Properties
		# ==========================================================================================
		
		# ==========================================================================================
		# Static Properties                                                        Static Properties
		# ==========================================================================================

		static $attrKinds = array('cNumberAttribute','cKeyValuePairAttribute');
		
		# ==========================================================================================
		# Protected Instance Methods                                      Protected Instance Methods
		# ==========================================================================================

		protected function _calculateNewValue ($valueArray) {
			$nV = array();
			foreach ($valueArray as $value) {
				if ( array_key_exists ((string)$value, $nV ) )
					$nV[(string)$value]++;
				else
					$nV[(string)$value] = 1;
			}
			
			//$nV = array_count_values($valueArray);
			arsort($nV, SORT_NUMERIC);
			$this->_value = key($nV).''; 
		}
		
		protected function _setValueSlot ($attribute) {
			switch ($attribute->kind()){
				case "cNumberAttribute": 
							$this->_valueSlot = 'value_number';
							break;				
				case "cKeyValuePairAttribute": 
							$this->_valueSlot = 'value_listKey';
							break;
			}
		}
		
		
		# ==========================================================================================
		# Public Instance Methods                                            Public Instance Methods
		# ==========================================================================================

		public function __construct ( $attribute, $valueArray ) {
			$this->_calculateNewValue($valueArray);
			$this->_setValueSlot($attribute);
		}
		
		# ==========================================================================================
		# Public Static Instance Methods									 Public Instance Methods
		# ==========================================================================================

		public static function getValueFromAV ( $attrValueObject ) {			
			if ( is_object($attrValueObject) and ( in_array(preg_replace ( '/Value\z/' , '' ,$attrValueObject->kind(),1 ), cMainValue::$attrKinds) ) ) {
				switch ( $attrValueObject->kind()) {								
					case "cNumberAttributeValue": 
						return $attrValueObject->value_number();
						break;
					case "cKeyValuePairAttributeValue": 
						return $attrValueObject->value_listKey();
						break;
				}
			}
			
			return null;
		}
	}


?>