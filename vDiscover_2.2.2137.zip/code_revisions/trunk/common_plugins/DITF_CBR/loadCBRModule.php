<?php if (!defined('APPLICATION_started')) {header('Location: .');exit;} 
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/


	/**
	 * This script loads all modules that belong to the common CBR module. Repository specific CBR 
	 * elements must be loaded by the correspondent plugin.
	 */

	{ # Load CBR class
		include_once(__DIR__ .DIRECTORY_SEPARATOR.'CBR.php');
	}
	{ # Load all Similarity Functions, that means all files in sub dir SimilarityFunctions, whose 
	  # name matches 'c*.inc.php'
		$subDir = __DIR__.DIRECTORY_SEPARATOR.'SimilarityFunctions';
		if (is_dir($subDir)) {
			if ($dirHandle = opendir($subDir)) {
				while (($file = readdir($dirHandle)) !== false) {
					if (preg_match('/c.*\.inc\.php/', $file)) {
						include_once($subDir.DIRECTORY_SEPARATOR.$file);
					}
				}
				closedir($dirHandle);
			}
        }
    }
	{ # Load all Adaption Functions, that means all files in sub dir AdaptionsFunctions, whose name
	  # matches 'c*.inc.php'
		$subDir = __DIR__.DIRECTORY_SEPARATOR.'AdaptationFunctions';
		if (is_dir($subDir)) {
			if ($dirHandle = opendir($subDir)) {
				while (($file = readdir($dirHandle)) !== false) {
					if (preg_match('/c.*\.inc\.php/', $file)) {
						include_once($subDir.DIRECTORY_SEPARATOR.$file);
					}
				}
				closedir($dirHandle);
			}
        }
    }
	

?>