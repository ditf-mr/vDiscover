<?php if (!defined('APPLICATION_started')) {header('Location: .');exit;} 
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// this file registers all common plugin components
cApplicationRegistry::registerModuleComponents(PLUGIN_REGISTRY_parseAllSubDirs, __DIR__ );

?>