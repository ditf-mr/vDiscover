<?php
  
	// Define the method as a PHP function
	function getAttributesWithValues($O_UUID) {
		try {
			// get access to the backend
			global $backend;
						
			$O = $backend->get($O_UUID);		
			
			if ($O) {
				$attributeValueSets = $O->getAttributeValueSets();
				
				$attributeWithValues = array();
				foreach($attributeValueSets as $attributeValueSet) {
					$attributeArray = $attributeValueSet['attribute'];
					$attributeValues = $attributeValueSet['values'];
					#$attributeValueAsArray = array();
					$attributeValueAsString = '';
					foreach($attributeValues as $attributeValue) {
						#$attributeValueAsArray[] = $attributeValue->valueAsText();
						$attributeValueAsString .= $attributeValue->valueAsText().' ';
					}
					$attributeWithValues[] = array(
						'name'		=> $attributeArray->name(), 
						#'values' 	=> $attributeValueAsArray
						'values' 	=> $attributeValueAsString
					);
				}
				return $attributeWithValues;		
			}
			else 
				return new nusoap_fault('SOAP-ENV:Server','','Invalid UUID','');
		} catch (Exception $e) {			
			return new nusoap_fault('SOAP-ENV:Server','',$e->getMessage(),$e->getFile() . '(' . $e->getLine() . '): ' . $e->getTraceAsString());
		}
	}
	// End of method definition
	
  	// Register the method to expose
	$this->register('getAttributesWithValues', array('O_UUID' => 'xsd:string'), array( 'return' => 'SOAP-ENC:Array'),
		'urn:RS2',
		'urn:RS2#getAttributesWithValues',
		'rpc', 'literal', 'With this webservice you get back all attributes with their values.');
?>
