<?php 
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/


if(!$repository_config) {header('Location: ../..');exit;}
define('APPLICATION_started', true);

set_include_path(realpath(__DIR__.DIRECTORY_SEPARATOR.'..'));

// add absolute paths to $repository_config
	require_once(__DIR__.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'information_structure'.DIRECTORY_SEPARATOR.'utilities.php');
	$repository_config = expandPathsIn_repository_config($repository_config);	
	

{ # load configuration
	require_once($repository_config['application_path'].DIRECTORY_SEPARATOR.'config.php');
}

{ # load and initialise global log files handler 
	require_once(realpath($repository_config['application_path'].'/../../utilities/cLogHandler.php'));
	global $logHandler;
	if ( is_null( $logHandler = new cLogHandler ( $repository_config['path_logs'] ) ) ) 
		die('Could not initialise global $logHandler object.');
}

{ # load exceptions
	require_once(realpath($repository_config['application_path'].'/../../utilities/exceptions.php'));
}

// load Backend module and create cBackend instance
require($repository_config['application_path'].'/backend/loadBackend.php');

// Melde alle PHP Fehler (siehe Changelog)
error_reporting(E_ALL);

// TODO: wherefore is this code???
ini_set('soap.wsdl_cache_enabled', '0'); 

// Making the registry available
require_once('../common/cPluginRegistry.php'); 

// Validate UserFunction

function validateUser($auth) {
	if(!empty($auth['username'])&& !empty($auth['password'])) {
		global $backend;						
		if ( $backend->login($auth['username'],$auth['password']) === true ) {
			return true;
		}
	}
	return false;
}


// Main

$r = new cWebserviceRegistry();

cWebserviceRegistry::registerModuleComponents(PLUGIN_REGISTRY_parseAllSubDirs, $repository_config['path_common_plugins'] );
cWebserviceRegistry::registerModuleComponents(PLUGIN_REGISTRY_parseAllSubDirs, $repository_config['path_plugins'] );

$ws = $r->getWebservices();

$keyFound = false;

if (is_array($ws)) {
	foreach ($ws as $key => $value ) {
		if ($key == $wsName) {
			$server = new SoapServer($value['wsdl']);		
			foreach ( $value['functions'] as $wsFunction ) {
				require_once($wsFunction['path']);
				$server->addFunction($wsFunction['name']);
			}
			foreach ( $value['globalCodeFiles'] as $globalCodeFile ) {
				require_once($globalCodeFile);
			}
			if ($_SERVER["REQUEST_METHOD"] == "POST") {
				$auth = array();
				if ( isset($_SERVER['PHP_AUTH_USER']) ) {
					$auth['username'] = $_SERVER['PHP_AUTH_USER'];
					$auth['password'] = $_SERVER['PHP_AUTH_PW'];
				}

				// function to validate the user	 		
				if ( !validateUser($auth) ) { 				
					// try again with values in configuration
					$auth['username'] = $value['username'];
					$auth['password'] = $value['password'];
					// function to validate the user
					if ( !validateUser($auth) ) { 						
						$server->fault('SOAP-ENV:Server','Authentication failed!','');		
					}
				}
				{ # handle the webservice
					try {
						$server->handle();			
					}
						catch ( userError $e ) { 	
						$logHandler->debug('User-Error');
						$logHandler->debug($e);
						global $server;
						$server->fault('User-Error',$e->getMessage(),'');	
					}
					catch ( Exception $e ) { 	
						$remark = "Webservice Internal error. (See log file for details.)";
						$logHandler->debug('ERROR: "' . $remark . '"');
						$logHandler->debug($e);
						global $server;
						$server->fault('SOAP-ENV:Server',$remark,'');	
					}
				}
			} else			
				die ('vDiscover 2.'. $repository_config['subversion_revision'] .' - ' . $repository_config['repository_name'] . '- Webserice: ' . $wsName);
			$keyFound = true;
		}	
	}
}

if (!$keyFound) {
	if ($wsName == "?wsdl")
		header("Location: index.php?wsdl");
	else
		header("Location: index.php");
}

?>


