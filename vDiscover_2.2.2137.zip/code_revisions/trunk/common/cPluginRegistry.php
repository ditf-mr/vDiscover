<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

if (!defined('APPLICATION_started')) {header('Location: .');exit;}

define ('PLUGIN_REGISTRY_loadFinally', 'PLUGIN_REGISTRY_loadFinally');
define ('PLUGIN_REGISTRY_parseAllSubDirs', 'PLUGIN_REGISTRY_parseAllSubDirs');

class cPluginRegistry {
	private $cssFiles 					= false; // array
	private $cssContent 				= false; // array
	private $widgetDeclarationHTMLFiles = false; // array
	private $dialogHTMLFiles 			= false; // array
	private $JSFiles 					= false; // array
	private $JSFiles_loadFinally		= false; // array
	private $JavaScript					= false; // array
	private $preloaderHTMLFile			= false; // path (string)
	private $mainHTMLFile				= false; // path (string)
	private $webserviceMethods			= false; // array
	private $webserviceComplexTypes		= false; // array
	private $webservice 				= false; // array
	public $repos_config				= false; // array

	
	
	function __construct() {
		$this->cssFiles 					= array();
		$this->widgetDeclarationHTMLFiles 	= array();
		$this->dialogHTMLFiles 				= array();
		$this->JSFiles 						= array();
		$this->JavaScript					= array();
		$this->repos_config 				= array();
	} // end constructor

	// --------------------------------------------------

	public function set_configOption($slot_name, $value) {
		// add passed path to registry
		$this->repos_config[$slot_name]=$value;
	} // end of public method register_cssFile
	
	public function get_configOption($slot_name, $defaultValue='') {
		// this method returns a configuration option, if set. If not, the default value is returned.
		return (isset($this->repos_config[$slot_name])?$this->repos_config[$slot_name]:$defaultValue);
	}
	
	public function register_cssFile ($path) {
		if (!file_exists($path)) throw new Exception ('Cannot find the CSS file "'.$path.'"'."\n".'(the current working directory is"'.getcwd().'").');
		// add passed path to registry
		$this->cssFiles[]=$path;
	} // end of public method register_cssFile

	public function register_cssContent ($string) {
		// add passed string to registry
		$this->cssContent[]=$string;
	} // end of public method register_cssContent
	
	public function register_widgetDeclaration ($path) {
		if (!file_exists($path)) throw new Exception ('Cannot find the widget declaration file "'.$path.'"'."\n".'(the current working directory is "'.getcwd().'").');
		// add passed path to registry
		$this->widgetDeclarationHTMLFiles[]=$path;
	} // end of public method  	widgetDeclaration
	
	public function register_dialogHTML ($path) {
		if (!file_exists($path)) throw new Exception ('Cannot find the dialog HTML file "'.$path.'"'."\n".'(the current working directory is "'.getcwd().'").');
		// add passed path to registry
		$this->dialogHTMLFiles[]=$path;
	} // end of public method register_dialogHTML
	
	public function register_JavaScriptFile ($path, $loadFinally=false) {
		if (!file_exists($path)) throw new Exception ('Cannot find the JavaScript file "'.$path.'"'."\n".'(the current working directory is "'.getcwd().'").');
		// add passed path to registry
		if ($loadFinally==PLUGIN_REGISTRY_loadFinally) {
			$this->JSFiles_loadFinally[]=$path;
		} else {
			$this->JSFiles[]=$path;
		} // end if
	} // end of public method register_JavaScript
	
	public function register_JavaScript($s) {
		$this->JavaScript[]=$s;
	} // end of public method register_JavaScript
	
	public function register_mainHTMLFile ($path) {
		if (!file_exists($path)) throw new Exception ('Cannot find the main HTML file "'.$path.'"'."\n".'(the current working directory is "'.getcwd().'").');
		// add passed path to registry
		$this->mainHTMLFile=$path;
	} // end of public method register_mainHTMLFile
	
	public function register_preloaderHTMLFile ($path) {
		if (!file_exists($path)) throw new Exception ('Cannot find the preloader HTML file "'.$path.'"'."\n".'(the current working directory is "'.getcwd().'").');
		// add passed path to registry
		$this->preloaderHTMLFile=$path;
	} // end of public method register_mainHTMLFile
		
	public function register_webServiceMethod ( $path, $name, $desc, $input, $output ) {
		// prepare checks
		global $repository_config;
				
		$pathCP = explode($repository_config['path_repository_root'],$repository_config['path_common_plugins']);
		$pathCP = explode(DIRECTORY_SEPARATOR,$pathCP[1]);
		$pathCP = $repository_config['application_path'] . DIRECTORY_SEPARATOR . $pathCP[1];

		if ( substr( $path, 0, strlen($pathCP) ) ==  $pathCP )  
			// Plugin in common_plugins folder
			$pathParts = explode( $pathCP, $path );			
			 
		if ( substr( $path, 0, strlen($repository_config['path_plugins'])) == $repository_config['path_plugins'] ) 
			// Plugin in repository plugins folder
			$pathParts = explode( $repository_config['path_plugins'], $path );
		
		$pathParts = explode(DIRECTORY_SEPARATOR,$pathParts[1]);

		// check if webservice_method has correct name
		$nameParts = explode( $pathParts[1], $name . "_" );
		if ( substr( $name, 0, strlen($pathParts[1])) != $pathParts[1] ) 
			throw new Exception('The web service method name has to begin with "'. $pathParts[1] . '_".');
		
		// check if webservice_methods directory exists in plugin directory
		if ( $pathParts[2] != 'webservice_methods'  )
			throw new Exception('The web service method function file has to be placed in and subfolder "webservice_methods".');
			
		// check if webservice_method file exists
		if ( ! file_exists($path) )
			throw new Exception('The web service method function file "'. $path . '" does not exist.');
				
		// check function if webservice_method function exists in included file
		$file = file_get_contents($path);		
		if (!preg_match('/function '.$name.'/', $file))
			throw new Exception('The web service method function "' . $name . '" does not exist in file "'. $path . '".');
	
		// if everything is ok store webServiceMethod
		$this->webserviceMethods[] = array( $path, $name, $desc, $input, $output );		
		
	}

	public function register_webServiceComplexType( $name, $structure ) {
		
		// check webservice Complex Type Name
		/*$check = false;
		foreach ( $this->webserviceMethods as $webServiceMethod ) {
		
		if ( substr( $name, 0, strlen($webServiceMethod[1]) + 1) == $webServiceMethod[1] . "_" ) 
				$check = true;
		}
		if (!$check)
			throw new Exception('The corresponding web service method doesn\'t exists. The Complex Type name has to begin with the name of the corresponding web servicde method followed by a "_".');
		
		// Todo: do some checks
		*/
		$this->webserviceComplexTypes[$name] = $structure;
	}
	
	public function register_webService( $name, $wsdl, $username = '', $password = '' ) {
		$this->webservice[$name]['wsdl'] = $wsdl;	
		$this->webservice[$name]['username'] = $username;
		$this->webservice[$name]['password'] = $password;
	}
	
	public function register_webserviceFunction( $name, $path, $wsName ) {
		if ( array_key_exists( $wsName, $this->webservice ) ) {			
			$this->webservice[$wsName]['functions'][] = array ( "name" => $name, "path" => $path );
		}
		else
			throw new Exception('The web service with the Name "' . $wsName . '" doesn\'t exist.');
	}
	
	public function register_webserviceGlobalCodeFiles( $path, $wsName ) {
		if ( array_key_exists( $wsName, $this->webservice ) ) {			
			if (!file_exists($path)) 
			{
				throw new Exception ('Cannot find the global code at file "'.$path.'"');
			}
			else 
			{
				$this->webservice[$wsName]['globalCodeFiles'][] = $path;	
			}	
		}
		else
			throw new Exception('The web service with the Name "' . $wsName . '" doesn\'t exist.');
	}
	
	// ---------------------------------------------------
	
	public function outputConfigOptions() {
		echo '<!-- BEGIN CONFIG OPTION output -->'."\n";
		echo '<script type="text/javascript">'."\n";
			echo '    if(typeof application ==\'undefined\') {application={};}'."\n";
			echo '    application.configuration={};'."\n";
			echo '    application.configuration.global='.json_encode($this->repos_config, JSON_FORCE_OBJECT).';'."\n";
		echo '</script>'."\n";
		echo '<!-- END CONFIG OPTION output -->'."\n"."\n";
	} // end of public method outputConfigOptions
	
	public function outputRegisteredCSSFiles() {
		// output CSS section begin
		echo '<!-- BEGIN CSS FILE PLUGIN output -->'."\n";
	
		// output the css files
		reset ($this->cssFiles);
		while (list($nr,$file)=each($this->cssFiles)) {
			echo '	<link rel="stylesheet" href="'.$file.'" />'."\n";
		} // end while there are CSS files
		
		// output CSS section end
		echo '<!-- END CSS PLUGIN output -->'."\n"."\n";
	} // end of public method outputRegisteredCSSFiles
	
	public function outputRegisteredCSSContent() {
		// output CSS section begin
		echo '<!-- BEGIN CSS CONTENT PLUGIN output -->'."\n";
	
		if ($this->cssContent) {// output the css content
		reset ($this->cssContent);
		while (list($nr,$content)=each($this->cssContent)) {
			echo "\n".'<!-- ############################################ -->'."\n";
			echo '<style type="text/css">'."\n";
			echo $content;
			echo '</style>'."\n";
			echo "\n".'<!-- ############################################ -->'."\n";
		}} // end while there is CSS content
		
		// output CSS section end
		echo '<!-- END CSS CONTENT PLUGIN output -->'."\n"."\n";
	} // end of public method outputRegisteredCSSFiles
	
	public function outputRegisteredWidgetDeclarations() {
		// output section begin
		echo '<!-- BEGIN WIDGET DECLARATION output -->'."\n";
	
		// output the css files
		reset ($this->widgetDeclarationHTMLFiles);
		while (list($nr,$file)=each($this->widgetDeclarationHTMLFiles)) {
			echo "\n".'<!-- BEGIN OF FILE: "'.$file.'" -->'."\n"."\n";

			global $repository_config;
			require ($file);

			echo "\n".'<!-- END OF FILE: "'.$file.'" -->'."\n";
		} // end while there are files
		
		// output section end
		echo "\n".'<!-- END WIDGET DECLARATION output -->'."\n"."\n";
	} // end of public method outputRegisteredCSSFiles
	
	public function outputRegisteredMainHTMLFile() {
		$file=$this->mainHTMLFile;
		// output section begin	
		echo "\n".'<!-- BEGIN OF FILE: "'.$file.'" -->'."\n"."\n";

		global $repository_config;
		require ($file);

		// output section end
		echo "\n".'<!-- END OF FILE: "'.$file.'" -->'."\n";
	} // end of public method outputRegisteredCSSFiles
	
	public function outputRegisteredPreloaderHTMLFile() {
		if(!$this->preloaderHTMLFile) throw new Exception('There is no preloader HTML file specified, but the output routine was called.');
		$file=$this->preloaderHTMLFile;
		// output section begin	
		echo "\n".'<!-- BEGIN OF FILE: "'.$file.'" -->'."\n"."\n";

		global $repository_config;
		require ($file);
		
		// output section end
		echo "\n".'<!-- END OF FILE: "'.$file.'" -->'."\n";
	} // end of public method outputRegisteredCSSFiles
	
	public function outputRegisteredDialogs() {
		// output section begin
		echo '<!-- BEGIN DIALOG definition output -->'."\n";
	
		// output the css files
		reset ($this->dialogHTMLFiles);
		while (list($nr,$file)=each($this->dialogHTMLFiles)) {
			echo "\n".'<!-- BEGIN OF FILE: "'.$file.'" -->'."\n"."\n";

			global $repository_config;
			require ($file);

			echo "\n".'<!-- END OF FILE: "'.$file.'" -->'."\n";
		} // end while there are files
		
		// output section end
		echo "\n".'<!-- END DIALOG definition output -->'."\n"."\n";
	} // end of public method outputRegisteredDialogs
		
	public function outputJavaScriptFiles() {
		// output JavaScript section begin
		echo '<!-- BEGIN JAVASCRIPT FILE INCLUSION -->'."\n";
	
		// output the JavaScript files
		reset ($this->JSFiles);
		while (list($nr,$file)=each($this->JSFiles)) {
			echo '	<script type="text/javascript" src="'.$file.'"></script>'."\n";
		} // end while
		
		// output the final JavaScript files
		if (is_array($this->JSFiles_loadFinally) AND count($this->JSFiles_loadFinally)) {
			echo '<!-- Begin final file inclusion -->'."\n";
		
			reset ($this->JSFiles_loadFinally);
			while (list($nr,$file)=each($this->JSFiles_loadFinally)) {
				echo '	<script type="text/javascript" src="'.$file.'"></script>'."\n";
			} // end while
		} // end if there are file JavaScript files
		
		// output JavaScript section end
		echo '<!-- END JAVASCRIPT FILE INCLUSION -->'."\n"."\n";
	} // end of public method outputRegisteredCSSFiles
	
	public function outputJavaScript() {
		if(count($this->JavaScript)) {
		
			echo "\n".'<script type="text/javascript">'."\n";
			echo implode('</script>'."\n\n".'<script type="text/javascript">'."\n",$this->JavaScript);
			echo "\n".'</script>'."\n";
		
		} // end if
	} // end of public method outputJavaScript
	
	public function getWebServiceMethods() {
		return $this->webserviceMethods;
	}
		
	public function getWebServiceComplexTypes(){
		return $this->webserviceComplexTypes;
	}
	
	public function getWebservices() {
		return $this->webservice;
	}
	
	// ---------------------------------------------------

	static function registerModuleComponents ($dirs, $start_path, $registerFileName='enter_here_the_registration_file_name.php', $verbose=false/*, $sorting=true*/) {
		
		// if no dir list is passed: build one that starts at $start_path
		if (!is_array($dirs) AND ($dirs==PLUGIN_REGISTRY_parseAllSubDirs)) {
			$d = dir($start_path);
			$dirs=array();
			$excludeSubDirs=array('.','..','.svn','_svn');
			while (false !== ($subDir=$d->read())) if(!in_array($subDir,$excludeSubDirs) AND is_dir($start_path.DIRECTORY_SEPARATOR.$subDir)) $dirs[]=$subDir;
			$d->close();
		}// end if include all subDirs
		
/* 		if ($sorting) {# case insensitive alphabetical sorting of $dirs
			sort ($dirs,SORT_STRING );
		}
		 */
		reset($dirs);
		while(list($k,$dir)=each($dirs)) {
			if (is_file($path=$start_path.DIRECTORY_SEPARATOR.$dir.DIRECTORY_SEPARATOR.$registerFileName)) {
				if ($verbose) echo '<!-- registering modules in "'.$path.'" -->'."\n";
				global $r, $repository_config;
				require($path);
			} else {
				if ($verbose) echo '<!-- NOTE - Cannot find modules at  "'.$start_path.DIRECTORY_SEPARATOR.$dir.DIRECTORY_SEPARATOR.'", because there is no file called "'.$registerFileName.'". -->'."\n";
			} // end if 
		} // end while there are dirs
		
	} // end of static function registerModuleComponents
	
} // end class definition cPluginRegistry

// special class for the retrieval system application
class cApplicationRegistry extends cPluginRegistry {

	static function registerModuleComponents ($dirs, $start_path, $registerFileName='overwrite_me.php', $verbose=false/*, $sorting=true*/) {
		parent::registerModuleComponents ($dirs, $start_path, 'register_application_components.php', true/* , $sorting */);
	} // end of method registerModuleComponents
	
} // end of class definition rs_application

// special class for the retrieval system login

class cLoginRegistry extends cPluginRegistry {

	static function registerModuleComponents ($dirs, $start_path, $registerFileName='overwrite_me.php', $verbose=false/*, $sorting=true*/) {
		parent::registerModuleComponents ($dirs, $start_path, 'register_login_components.php');
	} // end of method registerModuleComponents

}	

class cWebserviceMethodRegistry extends cPluginRegistry {
	static function registerModuleComponents ($dirs, $start_path, $registerFileName='overwrite_me.php', $verbose=false/*, $sorting=true*/) {
		parent::registerModuleComponents ($dirs, $start_path, 'register_webservice_methods.php');
	} // end of method registerModuleComponents
}

class cWebserviceRegistry extends cPluginRegistry {
	static function registerModuleComponents ($dirs, $start_path, $registerFileName='overwrite_me.php', $verbose=false/*, $sorting=true*/) {
		parent::registerModuleComponents ($dirs, $start_path, 'register_webservice.php');
	} // end of method registerModuleComponents
}


class cBackendApplicatonRegistry extends cPluginRegistry {
	protected $phpFile	= false; // path (string)	

	function __construct() {
		parent::__construct();
		$this->phpFile						= array();
	} // end constructor

	public function register_phpFile ($path) {
		if (!file_exists($path)) throw new Exception ('Cannot find the PHP file "'.$path.'"'."\n".'(the current working directory is "'.getcwd().'").');
		// add passed path to registry
		$this->phpFile[]=$path;
	} // end of public method register_JavaScript

	public function includeRegisteredPhpFiles() {
		if(count($this->phpFile)) {
	
			reset($this->phpFile);
			while(list($k, $path)=each($this->phpFile))  {
				require_once($path);
			} // end while
		} // end if
	} // end of public method outputJavaScript

	static function registerModuleComponents ($dirs, $start_path, $registerFileName='overwrite_me.php', $verbose=false/*, $sorting=true*/) {
		parent::registerModuleComponents ($dirs, $start_path, 'register_backend_components.php');
	} // end of method registerModuleComponents
}

// End of file --------------------------------
?>