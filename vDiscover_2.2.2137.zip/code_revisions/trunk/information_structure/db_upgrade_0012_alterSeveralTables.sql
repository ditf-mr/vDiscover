SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;


-- -----------------------------------------------------------
-- Add columns createdAt and createdByP_UUID to several tables
-- -----------------------------------------------------------

ALTER TABLE objecttype  
ADD createdAt DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00' AFTER isSystemObject,  
ADD createdByP_UUID VARCHAR(45) NOT NULL AFTER createdAt;


ALTER TABLE relationtype  
ADD createdAt DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00' AFTER isSystemObject,  
ADD createdByP_UUID VARCHAR(45) NOT NULL AFTER createdAt;


ALTER TABLE attribute  
ADD createdAt DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00' AFTER isSystemObject,  
ADD createdByP_UUID VARCHAR(45) NOT NULL AFTER createdAt;


ALTER TABLE viewtype
ADD createdAt DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00' AFTER isSystemObject,  
ADD createdByP_UUID VARCHAR(45) NOT NULL AFTER createdAt;


ALTER TABLE object  
ADD createdAt DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00' AFTER isSystemObject,  
ADD createdByP_UUID VARCHAR(45) NOT NULL AFTER createdAt;


ALTER TABLE relation
ADD createdAt DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00' AFTER isSystemObject,  
ADD createdByP_UUID VARCHAR(45) NOT NULL AFTER createdAt;


ALTER TABLE attributevalue  
ADD createdAt DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00' AFTER isSystemObject,  
ADD createdByP_UUID VARCHAR(45) NOT NULL AFTER createdAt;



-- ---------------------------------------------------------------------------
-- Set createdAt and createdByP_UUID to changedAt and changedByP_UUID if empty
-- ---------------------------------------------------------------------------

UPDATE objecttype
SET 
	createdAt = changedAt,
	createdByP_UUID = changedByP_UUID
WHERE (createdAt = '0000-00-00 00:00:00');


UPDATE relationtype
SET 
	createdAt = changedAt,
	createdByP_UUID = changedByP_UUID
WHERE (createdAt = '0000-00-00 00:00:00');


UPDATE attribute
SET 
	createdAt = changedAt,
	createdByP_UUID = changedByP_UUID
WHERE (createdAt = '0000-00-00 00:00:00');


UPDATE viewtype
SET 
	createdAt = changedAt,
	createdByP_UUID = changedByP_UUID
WHERE (createdAt = '0000-00-00 00:00:00');


UPDATE object
SET 
	createdAt = changedAt,
	createdByP_UUID = changedByP_UUID
WHERE (createdAt = '0000-00-00 00:00:00');


UPDATE relation
SET 
	createdAt = changedAt,
	createdByP_UUID = changedByP_UUID
WHERE (createdAt = '0000-00-00 00:00:00');


UPDATE attributevalue
SET 
	createdAt = changedAt,
	createdByP_UUID = changedByP_UUID
WHERE (createdAt = '0000-00-00 00:00:00');
