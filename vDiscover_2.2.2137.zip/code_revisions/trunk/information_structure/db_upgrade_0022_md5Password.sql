SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;


-- -----------------------------------------------------------
-- Add readModeHint and editModeHint to attribute
-- -----------------------------------------------------------

UPDATE attributevalue
SET value_tinytext_1 = md5(md5(value_tinytext_1))
WHERE kind = 'cPasswordAttributeValue'