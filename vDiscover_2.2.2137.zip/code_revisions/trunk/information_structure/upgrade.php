<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory. 
*/

// %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
// %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//
// Information Structure Upgrade Package 
//
// This file contains a class for automatically upgrading data structures
// it needs to be called when the database is already mounted

if ((!defined('REPOSITORY_MANAGER_started')) and (!defined('APPLICATION_started'))) {
	header('Location: ..');
	exit;
}

// Libraries ---------------------------------
if (defined('REPOSITORY_MANAGER_started')) {
	require_once(REPOSITORY_MANAGER_root.'/lib/handle_directories.php');
	require_once(REPOSITORY_MANAGER_root.'/lib/handle_databases.php');
} // end if

// %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

class informationStructureUpgrader { // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	// variable declarations // --------------------------------------------------------------------------------------------
	public static	$current_Version	= 45; 		// integer 	// set this number always to the latest version!
	protected 		$version 			= 0; 		// integer
	protected 		$configFile 		= ''; 		// string
	protected		$repositoryConfig	= array();
	protected		$template_configFile= 'template_config_file.index.php';
	protected 		$replace_me_in_tf	= '((PLACE_THE_CONFIGURATION_HERE))';
	
	
	// method declarations // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	
	public function __construct ($configFile, $initialConfiguration=array()) {

		// read the current configuration file and get the current information structure version
		$this->_readConfigFile($configFile);
		
		// detect if there is a need to carry out upgrades
		if ($initialConfiguration) $this->upgrade($initialConfiguration);
			
	} # end-of-function __construct 

	
	public function writeConfigFile () { 
		
		// remove unnecessary absolute paths
		$unnecessaryAbsolutePaths = array(
			'path_repository_root',
			'application_path',
			'backend_path',
			'path_fileStore',
			'path_sessions',
			'path_temp',
			'path_uploads',
			'path_database_backups',
			'path_logs',
			'path_plugins',
			'path_web_browser',
			'path_web_service',
			'path_common',
			'path_common_plugins',
			'path_tools',
			'path_third_party_libraries',
			'path_media',
			'path_application',
			'path_login',
			'root_path',
		);
		$repositoryConfigForFile = $this->repositoryConfig;
		while(list($k, $p) = each($unnecessaryAbsolutePaths)) {
			unset($repositoryConfigForFile[ $p ]);
		} // end while
		
		unset($unnecessaryAbsolutePaths);

					// read the template file
		$temp_file = file_get_contents(__DIR__.DIRECTORY_SEPARATOR.$this->template_configFile);
		
		// put the repository configuration in the configuration file
		$temp_file = str_replace( $this->replace_me_in_tf, "\t".'unserialize(\''.serialize($repositoryConfigForFile).'\')', $temp_file);
		
		// write the configuration file
		file_put_contents($this->configFile, $temp_file);

		unset($repositoryConfigForFile);
		
	} # end-of-function writeConfigFile 

	
	public function updateRepositoryConfig ($var, $value) {
		$this->repositoryConfig[$var]=$value;
	} # end-of-method updateRepositoryConfig
	
	
	public function getRepositoryConfig ( ) {
		$tempConf = $this->repositoryConfig;
		$tempConf['type']='repository';
		return $tempConf;
	} # end-of-function getRepositoryConfig
	
	
	protected function _createPaths() { // ---------------------------------------------------------------------------------
		
		{ # file store path
			$folder=$this->repositoryConfig['path_fileStore'];
			mkdir($folder);
			copy(REPOSITORY_htaccess_template, $folder.DIRECTORY_SEPARATOR.REPOSITORY_htaccess_fileName);
		}

		{ # session path
			$folder=$this->repositoryConfig['path_sessions'];
			mkdir($folder);
			copy(REPOSITORY_htaccess_template, $folder.DIRECTORY_SEPARATOR.REPOSITORY_htaccess_fileName);
		}

		{ # temp path
			$folder=$this->repositoryConfig['path_temp'];
			mkdir($folder);
			copy(REPOSITORY_htaccess_template, $folder.DIRECTORY_SEPARATOR.REPOSITORY_htaccess_fileName);
		}

		{ # uploads path
			$folder=$this->repositoryConfig['path_uploads'];
			mkdir($folder);
			copy(REPOSITORY_htaccess_template, $folder.DIRECTORY_SEPARATOR.REPOSITORY_htaccess_fileName);
		}

		{ # backup path
			$folder=$this->repositoryConfig['path_database_backups'];
			mkdir($folder);
			copy(REPOSITORY_htaccess_template, $folder.DIRECTORY_SEPARATOR.REPOSITORY_htaccess_fileName);
		}
		
		{ # plugin path
			$folder=$this->repositoryConfig['path_plugins'];
			mkdir($folder);
			copy(REPOSITORY_doNotDelete_template, $folder.DIRECTORY_SEPARATOR.REPOSITORY_doNotDelete_fileName);
		}
		
		{ # log files path
			$folder=$this->repositoryConfig['path_logs'];
			mkdir($folder);
			copy(REPOSITORY_doNotDelete_template, $folder.DIRECTORY_SEPARATOR.REPOSITORY_htaccess_fileName);
		}
		
		{ # web_browser files path
			$folder=$this->repositoryConfig['path_web_browser'];
			mkdir($folder);
		}
		
		{ # web_service files path
			$folder=$this->repositoryConfig['path_web_service'];
			mkdir($folder);
		}
		
	} // end of method _createPaths ---------------------------------------------------------------------------------		

	
	protected function _registerPaths ($repos_path) {
		
		{ # file store path
			$this->repositoryConfig['path_fileStore'] 
				= realpath($repos_path).DIRECTORY_SEPARATOR.'file_store';
		}
		
		{ # session path
			$this->repositoryConfig['path_sessions']
				= realpath($repos_path).DIRECTORY_SEPARATOR.'sessions';
		}
		
		{ # temp path
			$this->repositoryConfig['path_temp']
				= realpath($repos_path).DIRECTORY_SEPARATOR.'temp';
		}

		{ # uploads path
			$this->repositoryConfig['path_uploads']
				= realpath($repos_path).DIRECTORY_SEPARATOR.'uploads';
		}
		
		{ # backup path
			$this->repositoryConfig['path_database_backups']
				= realpath($repos_path).DIRECTORY_SEPARATOR.'database_backups';
		}
		
		{ # plugin path
			$this->repositoryConfig['path_plugins']
				= realpath($repos_path).DIRECTORY_SEPARATOR.'plugins';
		}

		{ # log files path
			$this->repositoryConfig['path_logs']
				= realpath($repos_path).DIRECTORY_SEPARATOR.'logs';
		}
		
		{ # web_browser files path
			$this->repositoryConfig['path_web_browser']
				= realpath($repos_path).DIRECTORY_SEPARATOR.'web_browser';
		}
		
		{ # web_services files path
			$this->repositoryConfig['path_web_service']
				= realpath($repos_path).DIRECTORY_SEPARATOR.'web_service';
		}
		
		{ # application path
			$this->repositoryConfig['application_path']	
				= realpath($repos_path.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'code_revisions'.DIRECTORY_SEPARATOR.$this->repositoryConfig['code_version'].DIRECTORY_SEPARATOR);
		}
		
		{ # backend path
			$this->repositoryConfig['backend_path']
				= realpath($repos_path.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'code_revisions'.DIRECTORY_SEPARATOR.$this->repositoryConfig['code_version'].DIRECTORY_SEPARATOR.'backend/'
			);
		}

		{ # root path
			$this->repositoryConfig['root_path'] 
				= realpath($this->repositoryConfig['application_path'].DIRECTORY_SEPARATOR."..".DIRECTORY_SEPARATOR."..");
		}
			
	} # end-of-function _updatePath
	
	
	public function upgrade ($initialConfiguration=array()) {

		if ( !$initialConfiguration AND ($this->version >= self::$current_Version) ) return;
	
		{ // some preliminary tests ------------------------------
	
			// test if configuration file can be written
			if(!$this->configFile OR !is_writable($this->configFile)) 
				throw new Exception( '\nInformation Structure Upgrade Package: Cannot write the configuration file. 
					The information structure was not modified. Aborting.\n' );
		
			// test if template configuration file can be read
			if(!$this->template_configFile OR !is_readable(__DIR__.DIRECTORY_SEPARATOR.$this->template_configFile)) 
				throw new Exception( '\nInformation Structure Upgrade Package: Cannot read the *template* configuration file. 
				The information structure was not modified. Aborting.\n' );
	
		} // end of the preliminary tests
	
		// repository path
		$repos_path=dirname($this->configFile);

		// if repository is imported from backup file
		if ( (isset($initialConfiguration['import']) ) && ($initialConfiguration['import']) ) {
			$this->repositoryConfig=$initialConfiguration;
			{ # recreate web_browser directory and files
				{ # web_browser files path
					$folder=$repos_path.DIRECTORY_SEPARATOR.'web_browser';
					$this->repositoryConfig['path_web_browser'] = $folder;
					mkdir($folder);
				}
				{ # create index.php in web_browser
					copy( __DIR__.DIRECTORY_SEPARATOR.'index_repository_web_browser.php', $this->repositoryConfig['path_web_browser'].DIRECTORY_SEPARATOR.'index.php');	
				}
			}
			
			{ # recreate web_service directory and files
				{ # web_service files path
					$folder=$repos_path.DIRECTORY_SEPARATOR.'web_service';
					$this->repositoryConfig['path_web_service'] = $folder;
					mkdir($folder);
				}
				{ # create index.php in web_service
					copy( __DIR__.DIRECTORY_SEPARATOR.'index_repository_web_service.php', $this->repositoryConfig['path_web_service'].DIRECTORY_SEPARATOR.'index.php');	
				}
				{ # create webservice.php in web_service
					copy( __DIR__.DIRECTORY_SEPARATOR.'web_service_template'.DIRECTORY_SEPARATOR.'webservice.php', $this->repositoryConfig['path_web_service'].DIRECTORY_SEPARATOR.'webservice.php');
				}
				{ # create htaccess in web_service
					copy( __DIR__.DIRECTORY_SEPARATOR.'web_service_template'.DIRECTORY_SEPARATOR.'.htaccess', $this->repositoryConfig['path_web_service'].DIRECTORY_SEPARATOR.'.htaccess');
				}
			}
			{ # recreate tools directory and files 
				{ # tools files path
					$folder=$repos_path.DIRECTORY_SEPARATOR.'tools';
					$this->repositoryConfig['path_tools'] = $folder;
					mkdir($folder);
				}
				{ # create index.php in tools
					copy( __DIR__.DIRECTORY_SEPARATOR.'index_repository_tools.php', $this->repositoryConfig['path_tools'].DIRECTORY_SEPARATOR.'index.php');	
				}
			}
			{ # recreate dynamic directories
				{ # in web_browser directory
					$this->_createDynamicPathsWebBrowser($repos_path);
					if (file_exists($repos_path.DIRECTORY_SEPARATOR.'common')) {
						removeDirectory($repos_path.DIRECTORY_SEPARATOR.'common');
					}
				}
				{ # else
					$dynamicPaths = array(
						'common',
						'common_plugins'
					);
					$this->repositoryConfig['path_repository_root'] = $repos_path;
					
					$this->_createDynamicPathsRoot($repos_path, $dynamicPaths);
				}
			}
			
			{ # log logging and archiving information to the logfile
				$reposLogHandler = new cLogHandler( $this->repositoryConfig['path_logs'] );
				
				if (!isset($this->repositoryConfig['logAccess']))
					$this->repositoryConfig['logAccess'] = true;
				if (!isset($this->repositoryConfig['archive']))
					$this->repositoryConfig['archive'] = true;
					
				if ($this->repositoryConfig['logAccess'] == true) {
					$reposLogHandler->log("Logging changes has been activated");
				}
				if ($this->repositoryConfig['logAccess'] == false) {
					$reposLogHandler->log("Logging changes has been deactivated");
				}	
				if ($this->repositoryConfig['archive'] == true) {
					$reposLogHandler->log("Archiving all changes in database has been activated");
				}
				if ($this->repositoryConfig['archive'] == false) {
					$reposLogHandler->log("Archiving all changes in database has been deactivated");
				}
			}
			
			unset($initialConfiguration['import']);
		}

		{ # load and initialise global log files handler 
			if ($this->version > 0) {
				require_once(realpath($this->repositoryConfig['application_path'].DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'utilities'.DIRECTORY_SEPARATOR.'cLogHandler.php'));
				global $logHandler;
				if ( is_null( $logHandler = new cLogHandler ( $this->repositoryConfig['path_logs'] ) ) ) 
					die('Could not initialise global $logHandler object.');
			}
		}
		
		global $logHandler;
		
		// perform update procedure
		switch ( $this->version ) {
			case 0: {			
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{ # here comes the initialisation code 
					$this->repositoryConfig=$initialConfiguration;
				}				
				
				{ # register some paths in the configuration
					$this->_registerPaths($repos_path);
				}
				{ # create paths
					$this->_createPaths();
				}
				{ # create linked paths for webbrowser
					$this->_createDynamicPathsWebBrowser($repos_path);
				}				
				
				{ # create index.php in web_browser
					copy( __DIR__.DIRECTORY_SEPARATOR.'index_repository_web_browser.php', $this->repositoryConfig['path_web_browser'].DIRECTORY_SEPARATOR.'index.php');
				}
				{ # create index.php in web_service
					copy( __DIR__.DIRECTORY_SEPARATOR.'index_repository_web_service.php', $this->repositoryConfig['path_web_service'].DIRECTORY_SEPARATOR.'index.php');
				}
				{ # create webservice.php in web_service
					copy( __DIR__.DIRECTORY_SEPARATOR.'web_service_template'.DIRECTORY_SEPARATOR.'webservice.php', $this->repositoryConfig['path_web_service'].DIRECTORY_SEPARATOR.'webservice.php');
				}
				{ # create htaccess in web_service
					copy( __DIR__.DIRECTORY_SEPARATOR.'web_service_template'.DIRECTORY_SEPARATOR.'.htaccess', $this->repositoryConfig['path_web_service'].DIRECTORY_SEPARATOR.'.htaccess');
				}
				{ # initialise database
					$db_dump_file = __DIR__.DIRECTORY_SEPARATOR.'db_upgrade_0000_initialDB.sql';
					importDatabase( $this->repositoryConfig['db_host'], $this->repositoryConfig['db_port'], $this->repositoryConfig['db_name'], $this->repositoryConfig['db_u_name'], $this->repositoryConfig['db_u_pwd'], $db_dump_file );
				}

				{ # log logging and archiving information to the logfile
					if (!isset($this->repositoryConfig['logAccess']))
						$this->repositoryConfig['logAccess'] = true;
					if (!isset($this->repositoryConfig['archive']))
						$this->repositoryConfig['archive'] = true;
						
					$reposLogHandler = new cLogHandler( $this->repositoryConfig['path_logs'] );
					
					if ($this->repositoryConfig['logAccess'] == true) {
						$reposLogHandler->log("Logging changes has been activated");
					}
					if ($this->repositoryConfig['logAccess'] == false) {
						$reposLogHandler->log("Logging changes has been deactivated");
					}	
					if ($this->repositoryConfig['archive'] == true) {
						$reposLogHandler->log("Archiving all changes in database has been activated");
					}
					if ($this->repositoryConfig['archive'] == false) {
						$reposLogHandler->log("Archiving all changes in database has been deactivated");
					}
				}				
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				} 
			}
			
			case 1: {
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{ # update database: add table 'watchlist'
					$db_dump_file = __DIR__.DIRECTORY_SEPARATOR.'db_upgrade_0001_addWatchlist.sql';
					importDatabase( $this->repositoryConfig['db_host'], $this->repositoryConfig['db_port'], $this->repositoryConfig['db_name'], $this->repositoryConfig['db_u_name'], $this->repositoryConfig['db_u_pwd'], $db_dump_file );
				}
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				} 
			}
			
			case 2: {
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{ # update database: add column 'dependencies' to table 'objecttype'
					$db_dump_file = __DIR__.DIRECTORY_SEPARATOR.'db_upgrade_0002_alterObjectType.sql';
					importDatabase( $this->repositoryConfig['db_host'], $this->repositoryConfig['db_port'], $this->repositoryConfig['db_name'], $this->repositoryConfig['db_u_name'], $this->repositoryConfig['db_u_pwd'], $db_dump_file );
				} 
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				} 
			}
			
			case 3: {
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{ # update database: rename column 'dependencies' to 'equationSolver' in table 'objecttype'
					$db_dump_file = __DIR__.DIRECTORY_SEPARATOR.'db_upgrade_0003_alterObjectType.sql';
					importDatabase( $this->repositoryConfig['db_host'], $this->repositoryConfig['db_port'], $this->repositoryConfig['db_name'], $this->repositoryConfig['db_u_name'], $this->repositoryConfig['db_u_pwd'], $db_dump_file );
				} 
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				} 
			}
			
			case 4: {
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{ # update database: create new columns in table 'attributevalues' and copy values
					$db_dump_file = __DIR__.DIRECTORY_SEPARATOR.'db_upgrade_0004_alterAttributeValue.sql';
					importDatabase( $this->repositoryConfig['db_host'], $this->repositoryConfig['db_port'], $this->repositoryConfig['db_name'], $this->repositoryConfig['db_u_name'], $this->repositoryConfig['db_u_pwd'], $db_dump_file );
				} 
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				} 
			}
			
			case 5: {
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{ # create sub directories in fileStore: "_archived", "_deleted" and "_modified"
					$path_dirArchived = $this->repositoryConfig['path_fileStore']. DIRECTORY_SEPARATOR . '_archived';
					if (! file_exists($path_dirArchived) and (! mkdir($path_dirArchived))) {
						throw new fatalError('Cannot create directory "' . path_dirArchived . '"');
					}
					$path_dirDeleted = $this->repositoryConfig['path_fileStore']. DIRECTORY_SEPARATOR . '_deleted';
					if (! file_exists($path_dirDeleted) and (! mkdir($path_dirDeleted))) {
						throw new fatalError('Cannot create directory "' . path_dirDeleted . '"');
					}
					$path_dirModified = $this->repositoryConfig['path_fileStore']. DIRECTORY_SEPARATOR . '_modified';
					if (! file_exists($path_dirModified) and (! mkdir($path_dirModified))) {
						throw new fatalError('Cannot create directory "' . path_dirModified . '"');
					}
				} 
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				} 
			}
			
			case 6: {
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{ # update database: create new columns in table 'attributevalues' and copy values
					$db_dump_file = __DIR__.DIRECTORY_SEPARATOR.'db_upgrade_0006_updateAttributeValue.sql';
					importDatabase( $this->repositoryConfig['db_host'], $this->repositoryConfig['db_port'], $this->repositoryConfig['db_name'], $this->repositoryConfig['db_u_name'], $this->repositoryConfig['db_u_pwd'], $db_dump_file );
				} 
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				} 
			}
			
			case 7: {
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{ # update database: create new columns in table 'attributevalues' and copy values
					$db_dump_file = __DIR__.DIRECTORY_SEPARATOR.'db_upgrade_0007_alterViewType.sql';
					importDatabase( $this->repositoryConfig['db_host'], $this->repositoryConfig['db_port'], $this->repositoryConfig['db_name'], $this->repositoryConfig['db_u_name'], $this->repositoryConfig['db_u_pwd'], $db_dump_file );
				}				
				{ # load exceptions and backend module and create cBackend instance
					global $repository_config;
					$repository_config = $this->repositoryConfig;
					require_once( realpath($this->repositoryConfig['application_path'].DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'utilities'.DIRECTORY_SEPARATOR.'exceptions.php') );				
					require_once( $this->repositoryConfig['backend_path'].DIRECTORY_SEPARATOR.'loadBackend.php' );
					
				}
				{ # login upgrade user
					global $backend;
					$backend->loginUpgrader();
				}
				{ # create inherited cViewType for each existing cViewType and adapt the relevant 
				  # cAttribute of these cViewType
				  # walk through all cObjectType, for each do:
				  # - collect sub cObjectType
				  # - bequeath all cViewType to each sub cObjectType
					$objectTypes = cObjectType::getObjectTypes();

					foreach($objectTypes as $objectType) {

						$subObjectTypes = $objectType->getSubObjectTypes();
						if (count($subObjectTypes) > 0) {

							$viewTypes = $objectType->getViewTypes();
							foreach($viewTypes as $viewType) {
								$viewTypeAsArray = $viewType->toArray();
								foreach($subObjectTypes as $subObjectType) {
									$newViewType = cViewType::newViewTypeFromArray(
										$subObjectType->OT_UUID(), 
										$subObjectType->kind(), 
										$viewTypeAsArray
									);
									$newViewType->setVT_origin_UUID($viewType->VT_UUID());
									$newViewType->reviseAttributes();
									$newViewType->create();
								}
							}
						}
					}
				}
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				} 
			}
			
			case 8: {
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{ # update database: create new column in table 'viewtypes'
					$db_dump_file = __DIR__.DIRECTORY_SEPARATOR.'db_upgrade_0008_alterViewType.sql';
					importDatabase( $this->repositoryConfig['db_host'], $this->repositoryConfig['db_port'], $this->repositoryConfig['db_name'], $this->repositoryConfig['db_u_name'], $this->repositoryConfig['db_u_pwd'], $db_dump_file );
				} 
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				} 
			}
			
			case 9: {
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{ # update database: create new column in table 'relationtype' 
					$db_dump_file = __DIR__.DIRECTORY_SEPARATOR.'db_upgrade_0009_alterRelationType.sql';
					importDatabase( $this->repositoryConfig['db_host'], $this->repositoryConfig['db_port'], $this->repositoryConfig['db_name'], $this->repositoryConfig['db_u_name'], $this->repositoryConfig['db_u_pwd'], $db_dump_file );
				} 
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				} 
			}
			
			case 10: {
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{ # update database: create new table 'queries' 
					$db_dump_file = __DIR__.DIRECTORY_SEPARATOR.'db_upgrade_0010_createQueries.sql';
					importDatabase( $this->repositoryConfig['db_host'], $this->repositoryConfig['db_port'], $this->repositoryConfig['db_name'], $this->repositoryConfig['db_u_name'], $this->repositoryConfig['db_u_pwd'], $db_dump_file );
				} 
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				} 
			}
			
			case 11: {
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{ 
					# Generates a folder web_service under repositories plugins path
					mkdir($this->repositoryConfig['path_plugins'].DIRECTORY_SEPARATOR.'web_service_methods');
				} 
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				} 
			}			
			
			case 12: {
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{ # update database: add 'createdAt' and 'createdByP_UUID' to several tables
					$db_dump_file = __DIR__.DIRECTORY_SEPARATOR.'db_upgrade_0012_alterSeveralTables.sql';
					importDatabase( $this->repositoryConfig['db_host'], $this->repositoryConfig['db_port'], $this->repositoryConfig['db_name'], $this->repositoryConfig['db_u_name'], $this->repositoryConfig['db_u_pwd'], $db_dump_file );
				} 
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				} 
			}
			
			case 13: {
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{ # connect to database
					$mysqli = new mysqli(
						$this->repositoryConfig['db_host'], 
						$this->repositoryConfig['db_u_name'], 
						$this->repositoryConfig['db_u_pwd'],
						$this->repositoryConfig['db_name'], 
						$this->repositoryConfig['db_port'] 
					);
					$mysqli->set_charset('utf8'); 
					$mysqli->query("SET 
						character_set_results 		= 'utf8', 
						character_set_client 		= 'utf8', 
						character_set_connection 	= 'utf8', 
						character_set_database 		= 'utf8', 
						character_set_server 		= 'utf8'
					");
				}
				{ # search for all attributes with
				  # - kind: cNumberAttribute or cValueRangeAttribute or cMeasurementAttribute
				  # - configuration like 's:4:"unit";'
					$sql = "
						SELECT 
							A_UUID,
							configuration
						FROM attribute
						WHERE ((kind= 'cNumberAttribute') OR (kind= 'cValueRangeAttribute') OR (kind= 'cMeasurementResultAttribute'))
						  AND (configuration like '%s:4:\"unit\";%')";
						$res = $mysqli->query($sql);				
				}
				{ # walk through all retrieved records and collect A_UUID and configuration
						$toDoList = array();
						while ( $row = $res->fetch_assoc() ) {
							$toDoList[$row['A_UUID']] = $row['configuration'];
						} 	
				} 
				{ # walk through toDoList and save corrected configuration
					foreach($toDoList as $A_UUID=>$configuration) {
						{ # transform configuration
							$configuration = str_replace('s:4:"unit";', 's:5:"units";', $configuration);
						}
						$sql = '
							UPDATE attribute
							SET configuration = "' . $mysqli->real_escape_string($configuration) . '"
							WHERE A_UUID = "' . $mysqli->real_escape_string($A_UUID) .'"';
						$mysqli->query($sql);
					} 
				}
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				} 
			}
			
			case 14: {
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{ # connect to database
					$mysqli = new mysqli(
						$this->repositoryConfig['db_host'], 
						$this->repositoryConfig['db_u_name'], 
						$this->repositoryConfig['db_u_pwd'],
						$this->repositoryConfig['db_name'], 
						$this->repositoryConfig['db_port'] 
					);
					$mysqli->set_charset('utf8'); 
					$mysqli->query("SET 
						character_set_results 		= 'utf8', 
						character_set_client 		= 'utf8', 
						character_set_connection 	= 'utf8', 
						character_set_database 		= 'utf8', 
						character_set_server 		= 'utf8'
					");
				}
				{ # search for all attributes with
				  # - kind: cNumberAttribute or cValueRangeAttribute or cMeasurementAttribute
				  # - configuration like 's:4:"unit";'
					$sql = "
						SELECT 
							A_UUID,
							configuration
						FROM attribute
						WHERE (kind= 'cNumberAttribute') 
						   OR (kind= 'cValueRangeAttribute') 
						   OR (kind= 'cMeasurementResultAttribute')";
						$res = $mysqli->query($sql);				
				}
				{ # walk through all retrieved records and collect A_UUID and configuration
					$toDoList = array();
					while ( $row = $res->fetch_assoc() ) {
						$toDoList[$row['A_UUID']] = $row['configuration'];
					} 
				}
				{ # walk through toDoList and save corrected configuration
					foreach($toDoList as $A_UUID=>$configuration) {
						{ # transform configuration
							$pattern = '/(.*)(s.5."units";s.\d+.")([^"]*)";(.*)/';
							if (preg_match_all($pattern, $configuration, $matches)) {
								if (trim($matches[3][0]) == '') {
									$asArray = array();
								}
								else {
									$asArray = explode('\n', $matches[3][0]); 
								}
								$configuration = $matches[1][0].'s:5:"units";' . serialize($asArray) . $matches[4][0];
							}
						}
						$sql = '
							UPDATE attribute
							SET configuration = "' . $mysqli->real_escape_string($configuration) . '"
							WHERE A_UUID = "' . $mysqli->real_escape_string($A_UUID) .'"';
						$mysqli->query($sql);
					} 
				}
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				} 
			}
			
			case 15: {
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{ # Removes folder web_service under repositories plugins path
					$directory = $this->repositoryConfig['path_plugins'].DIRECTORY_SEPARATOR.'web_service_methods';
					if (file_exists($directory)) {
						rmdir($this->repositoryConfig['path_plugins'].DIRECTORY_SEPARATOR.'web_service_methods');
					}
				} 
				{ # create linkadd paths in repositories root
					$this->repositoryConfig['path_repository_root'] = realpath($this->repositoryConfig['path_web_browser'].DIRECTORY_SEPARATOR.'..');
					$dynamicPaths = array(
						'common'
					);
					$this->_createDynamicPathsRoot($repos_path, $dynamicPaths);
				}
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				} 
			}	
			
			case 16: {
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{ # update database: rename and modified 'readOnly' of 'viewtype'
					$db_dump_file = __DIR__.DIRECTORY_SEPARATOR.'db_upgrade_0016_alterViewType.sql';
					importDatabase( $this->repositoryConfig['db_host'], $this->repositoryConfig['db_port'], $this->repositoryConfig['db_name'], $this->repositoryConfig['db_u_name'], $this->repositoryConfig['db_u_pwd'], $db_dump_file );
				} 
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				} 
			}			

			case 17: {
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{ # create linked paths for webbrowser
					$this->repositoryConfig['path_repository_root'] = realpath($this->repositoryConfig['path_web_browser'].DIRECTORY_SEPARATOR."..");
					// Remove old softlink to common_plugins folder in web_browser, but not the new one in root					
					if ( isset($this->repositoryConfig['path_common_plugins']) AND (substr($this->repositoryConfig['path_common_plugins'],0,strlen($this->repositoryConfig['path_web_browser'])) == $this->repositoryConfig['path_web_browser'] ) ) 
						if (file_exists($this->repositoryConfig['path_common_plugins'])) {
							removeDirectory($this->repositoryConfig['path_common_plugins']);
						}
					$dynamicPaths = array(
						'common_plugins'
					);
					$this->_createDynamicPathsRoot($repos_path, $dynamicPaths);
				}
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				}			
			}
			
			case 18: {
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{ # update database: add 'displayInFullWidth' to table 'attribute'
					$db_dump_file = __DIR__.DIRECTORY_SEPARATOR.'db_upgrade_0018_alterAttribute.sql';
					importDatabase( $this->repositoryConfig['db_host'], $this->repositoryConfig['db_port'], $this->repositoryConfig['db_name'], $this->repositoryConfig['db_u_name'], $this->repositoryConfig['db_u_pwd'], $db_dump_file );
				} 
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				} 
			}		
			
			case 19: {
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{ # update database: add 'readModeHint' and 'editModeHint' to table 'attribute'
					$db_dump_file = __DIR__.DIRECTORY_SEPARATOR.'db_upgrade_0019_alterAttribute.sql';
					importDatabase( $this->repositoryConfig['db_host'], $this->repositoryConfig['db_port'], $this->repositoryConfig['db_name'], $this->repositoryConfig['db_u_name'], $this->repositoryConfig['db_u_pwd'], $db_dump_file );
				} 
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				} 
			}		
			
			case 20: {
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{ # create sub directories in fileStore: "_temporary" and "_modified"
					$path_dirTemporary = $this->repositoryConfig['path_fileStore']. DIRECTORY_SEPARATOR . '_temporary';
					if (! file_exists($path_dirTemporary) and (! mkdir($path_dirTemporary))) {
						throw new fatalError('Cannot create directory "' . path_dirTemporary . '"');
					}
					$path_dirModified = $this->repositoryConfig['path_fileStore']. DIRECTORY_SEPARATOR . '_modified';
					if (! file_exists($path_dirModified) and (! mkdir($path_dirModified))) {
						throw new fatalError('Cannot create directory "' . path_dirModified . '"');
					}
				} 
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				} 
			}
			
			case 21: {
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{ # update database: add 'showEmptyAttributesInReadMode' to table 'viewtype'
					$db_dump_file = __DIR__.DIRECTORY_SEPARATOR.'db_upgrade_0021_alterViewType.sql';
					importDatabase( $this->repositoryConfig['db_host'], $this->repositoryConfig['db_port'], $this->repositoryConfig['db_name'], $this->repositoryConfig['db_u_name'], $this->repositoryConfig['db_u_pwd'], $db_dump_file );
				} 
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				} 
			}		
			
			case 22: {
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{ # update database: encrypt password in cPasswordAttributeValue
					$db_dump_file = __DIR__.DIRECTORY_SEPARATOR.'db_upgrade_0022_md5Password.sql';
					importDatabase( $this->repositoryConfig['db_host'], $this->repositoryConfig['db_port'], $this->repositoryConfig['db_name'], $this->repositoryConfig['db_u_name'], $this->repositoryConfig['db_u_pwd'], $db_dump_file );
				} 
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				} 
			}		
			
			case 23: {
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{ # update database: add and modify several objects concerning the user access permissions
					$db_dump_file = __DIR__.DIRECTORY_SEPARATOR.'db_upgrade_0023_initialAccessPermissions.sql';
					importDatabase( $this->repositoryConfig['db_host'], $this->repositoryConfig['db_port'], $this->repositoryConfig['db_name'], $this->repositoryConfig['db_u_name'], $this->repositoryConfig['db_u_pwd'], $db_dump_file );
				} 
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				} 
			}
			
			case 24: {
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{ # update database: unset isSystemObject for old RT 'assignedTo'
					$db_dump_file = __DIR__.DIRECTORY_SEPARATOR.'db_upgrade_0024_additionalAccessPermissions.sql';
					importDatabase( $this->repositoryConfig['db_host'], $this->repositoryConfig['db_port'], $this->repositoryConfig['db_name'], $this->repositoryConfig['db_u_name'], $this->repositoryConfig['db_u_pwd'], $db_dump_file );
				} 
				{ # load exceptions and backend module and create cBackend instance
					global $repository_config;
					$repository_config = $this->repositoryConfig;
					require_once( realpath($this->repositoryConfig['application_path'].DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'utilities'.DIRECTORY_SEPARATOR.'exceptions.php') );
				
					require_once( $this->repositoryConfig['backend_path'].DIRECTORY_SEPARATOR.'loadBackend.php' );
					
				}
				{ # login upgrade user
					global $backend;
					$backend->loginUpgrader();
				}
				{ # do modification in backend
					{ # delete old RT 'assigned to'
						$relationType = $backend->getRelationType('10000000-1000-1000-1000-00a000005e00');
						$relationType->delete();
					}
				}
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				} 
			}
			
			case 25: {
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{ # create webservice.php in web_service
					copy( __DIR__.DIRECTORY_SEPARATOR.'web_service_template'.DIRECTORY_SEPARATOR.'webservice.php', $this->repositoryConfig['path_web_service'].DIRECTORY_SEPARATOR.'webservice.php');
				}
				{ # create htaccess in web_service
					copy( __DIR__.DIRECTORY_SEPARATOR.'web_service_template'.DIRECTORY_SEPARATOR.'.htaccess', $this->repositoryConfig['path_web_service'].DIRECTORY_SEPARATOR.'.htaccess');
				}
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				} 
			}
			
			case 26: {
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{ # specify root path of retrieval system 2
					$this->repositoryConfig['root_path'] = realpath($this->repositoryConfig['application_path'].DIRECTORY_SEPARATOR."..".DIRECTORY_SEPARATOR."..");
				}
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				} 
			}
			
			case 27: {
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{ # check whether "repositoryConfig['path_tools']" exists or not.
				  # if it exists then this repository has been restored and not task has to be performed here.
					if (!isset($this->repositoryConfig['path_tools'])) {
						{ # add path to 'repository_config'
							$this->repositoryConfig['path_tools'] = realpath($repos_path).DIRECTORY_SEPARATOR.'tools';
						}
						{ # create 'tools' directory in the repository
							$folder = $this->repositoryConfig['path_tools'];
							mkdir($folder);
						}
						{ # create 'index.php' file in the directory 'tools' on the basis of the template
							copy( __DIR__.DIRECTORY_SEPARATOR.'index_repository_tools.php', $this->repositoryConfig['path_tools'].DIRECTORY_SEPARATOR.'index.php');
						}
					}
				}
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				} 
			}

			case 28: {
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{ # create sub directories in fileStore: "_archived", "_deleted", "_modified" and
				  # "_temporary"
				  #
				  # Attention: These task should have been done in step 5 and 20 (see there) but in 
				  # some circumstances, this has not happend.
				  # It is necessary to create a file named "do_not_delete" in each directory, 
				  # because if a directory is empty, it will not be included in a backup zip file.
					$directories = array('_archived', '_deleted', '_modified', '_temporary');
					foreach($directories as $directory) {
						$path_dir = $this->repositoryConfig['path_fileStore'].DIRECTORY_SEPARATOR.$directory;
						if (! file_exists($path_dir) and (! mkdir($path_dir))) {
							throw new fatalError('Cannot create directory "'.path_dir.'"');
						}
						$path_file = $path_dir.DIRECTORY_SEPARATOR.'do_not_delete';
						if (! file_exists($path_file)) {
							$fhandle = fopen($path_file, 'w');
							fwrite($fhandle, 'Do not delete this file.');
							fclose($fhandle);
						}
					}
				} 
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				} 
			}

			case 29: {
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{ # update database: create new table 'queries' 
					$db_dump_file = __DIR__.DIRECTORY_SEPARATOR.'db_upgrade_0029_createAccessHistory.sql';
					importDatabase( $this->repositoryConfig['db_host'], $this->repositoryConfig['db_port'], $this->repositoryConfig['db_name'], $this->repositoryConfig['db_u_name'], $this->repositoryConfig['db_u_pwd'], $db_dump_file );
				} 
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				} 
			}
			
			case 30: {
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{ # update database: add attributes "Language" and "Country" to ObjectType 'Persons"
				  # do this directly in the database, do not use backend functionality
					$db_dump_file = __DIR__.DIRECTORY_SEPARATOR.'db_upgrade_0030_addLanguageAndCountry.sql';
					importDatabase( $this->repositoryConfig['db_host'], $this->repositoryConfig['db_port'], $this->repositoryConfig['db_name'], $this->repositoryConfig['db_u_name'], $this->repositoryConfig['db_u_pwd'], $db_dump_file );
				} 
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				} 
			}
						
			case 31: {
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{ # update database: add 'eqSolverIsActive' and 'eqSolverJSONConfig' to table 'viewtype'
					$db_dump_file = __DIR__.DIRECTORY_SEPARATOR.'db_upgrade_0031_alterViewType.sql';
					importDatabase( $this->repositoryConfig['db_host'], $this->repositoryConfig['db_port'], $this->repositoryConfig['db_name'], $this->repositoryConfig['db_u_name'], $this->repositoryConfig['db_u_pwd'], $db_dump_file );
				} 
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				} 
			}		
			
			case 32: {
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{
					# recreate index.php in web_browser
					copy( __DIR__.DIRECTORY_SEPARATOR.'index_repository_web_browser.php', $this->repositoryConfig['path_web_browser'].DIRECTORY_SEPARATOR.'index.php');	
					# recreate index.php in web_service
					copy( __DIR__.DIRECTORY_SEPARATOR.'index_repository_web_service.php', $this->repositoryConfig['path_web_service'].DIRECTORY_SEPARATOR.'index.php');	
					# recreate webservice.php in web_service
					copy( __DIR__.DIRECTORY_SEPARATOR.'web_service_template'.DIRECTORY_SEPARATOR.'webservice.php', $this->repositoryConfig['path_web_service'].DIRECTORY_SEPARATOR.'webservice.php');
				
				}
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				} 
			
			}
			
			case 33: {
				
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{
					# recreate index.php in tools
					copy( __DIR__.DIRECTORY_SEPARATOR.'index_repository_tools.php', $this->repositoryConfig['path_tools'].DIRECTORY_SEPARATOR.'index.php');								
				}
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				} 
			}
			
			case 34: {
				
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{ # update database: add 'enableAnalyticalExpressions' and 'analyticalExpressionConfig_asJSON' to table 'attribute'
					$db_dump_file = __DIR__.DIRECTORY_SEPARATOR.'db_upgrade_0034_alterAttribute.sql';
					importDatabase( $this->repositoryConfig['db_host'], $this->repositoryConfig['db_port'], $this->repositoryConfig['db_name'], $this->repositoryConfig['db_u_name'], $this->repositoryConfig['db_u_pwd'], $db_dump_file );
				} 
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				} 
			}		
			
			case 35: {
				
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{ # update database: add 'CBRIsActive' and 'CBRJSONConfig' to table 'viewtype'
					$db_dump_file = __DIR__.DIRECTORY_SEPARATOR.'db_upgrade_0035_alterViewType.sql';
					importDatabase( $this->repositoryConfig['db_host'], $this->repositoryConfig['db_port'], $this->repositoryConfig['db_name'], $this->repositoryConfig['db_u_name'], $this->repositoryConfig['db_u_pwd'], $db_dump_file );
				} 
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				} 
			}		
			
			case 36: {
				
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{ # update database: add table 'findLists'
					$db_dump_file = __DIR__.DIRECTORY_SEPARATOR.'db_upgrade_0036_createFindLists.sql';
					importDatabase( $this->repositoryConfig['db_host'], $this->repositoryConfig['db_port'], $this->repositoryConfig['db_name'], $this->repositoryConfig['db_u_name'], $this->repositoryConfig['db_u_pwd'], $db_dump_file );
				} 
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				} 
			}		
			
			case 37: {
				
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{ # update database: add 'workflowConfiguration' to table 'objecttype'
					$db_dump_file = __DIR__.DIRECTORY_SEPARATOR.'db_upgrade_0037_alterObjectType.sql';
					importDatabase( $this->repositoryConfig['db_host'], $this->repositoryConfig['db_port'], $this->repositoryConfig['db_name'], $this->repositoryConfig['db_u_name'], $this->repositoryConfig['db_u_pwd'], $db_dump_file );
				} 
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				} 
			}		
			case 38: {
				
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{ # update database: add 'workflowConfigurationActivated' to table 'objecttype'
					$db_dump_file = __DIR__.DIRECTORY_SEPARATOR.'db_upgrade_0038_alterObjectType.sql';
					importDatabase( $this->repositoryConfig['db_host'], $this->repositoryConfig['db_port'], $this->repositoryConfig['db_name'], $this->repositoryConfig['db_u_name'], $this->repositoryConfig['db_u_pwd'], $db_dump_file );
				} 
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				}
				
			}				
			case 39: {
				
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{ # update database: add 'currentState', 'visibleInSearch', 'dueDate' to table 'objecttype'
					$db_dump_file = __DIR__.DIRECTORY_SEPARATOR.'db_upgrade_0039_alterObject.sql';
					importDatabase( $this->repositoryConfig['db_host'], $this->repositoryConfig['db_port'], $this->repositoryConfig['db_name'], $this->repositoryConfig['db_u_name'], $this->repositoryConfig['db_u_pwd'], $db_dump_file );
				} 
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				}
			}
			
			case 40: {
				
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{ # update database: add "User Status" to ObjectType 'Persons' 
				  # update database: add AttributeValuu of "User Status" to Object 'admin'
					$db_dump_file = __DIR__.DIRECTORY_SEPARATOR.'db_upgrade_0040_addUserStatus.sql';
					importDatabase( $this->repositoryConfig['db_host'], $this->repositoryConfig['db_port'], $this->repositoryConfig['db_name'], $this->repositoryConfig['db_u_name'], $this->repositoryConfig['db_u_pwd'], $db_dump_file );
				} 
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				} 
			}
			
			case 41: {
				
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{ # update database: add "User Status" to ObjectType 'Persons' 
				  # update database: add AttributeValuu of "User Status" to Object 'admin'
					$db_dump_file = __DIR__.DIRECTORY_SEPARATOR.'db_upgrade_0041_addObjStatus.sql';
					importDatabase( $this->repositoryConfig['db_host'], $this->repositoryConfig['db_port'], $this->repositoryConfig['db_name'], $this->repositoryConfig['db_u_name'], $this->repositoryConfig['db_u_pwd'], $db_dump_file );
				} 
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				} 
			}	
					
			case 42: {
				
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{ # update database: add "User Status" to ObjectType 'Persons' 
				  # update database: add AttributeValuu of "User Status" to Object 'admin'
					$db_dump_file = __DIR__.DIRECTORY_SEPARATOR.'db_upgrade_0042_alterTableStatusLog.sql';
					importDatabase( $this->repositoryConfig['db_host'], $this->repositoryConfig['db_port'], $this->repositoryConfig['db_name'], $this->repositoryConfig['db_u_name'], $this->repositoryConfig['db_u_pwd'], $db_dump_file );
				} 
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				} 
			}	
					
			case 43: {
				
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{ # update database: add "User Status" to ObjectType 'Persons' 
				  # update database: add AttributeValuu of "User Status" to Object 'admin'
					$db_dump_file = __DIR__.DIRECTORY_SEPARATOR.'db_upgrade_0043_addPermission.sql';
					importDatabase( $this->repositoryConfig['db_host'], $this->repositoryConfig['db_port'], $this->repositoryConfig['db_name'], $this->repositoryConfig['db_u_name'], $this->repositoryConfig['db_u_pwd'], $db_dump_file );
				} 
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				} 
			}	
			case 44: {
				
				set_time_limit ( 3 );
				$logHandler->debug('information structure upgrade step '.$this->version.'->'.($this->version+1).' ...');
				{ # update database: add "User Status" to ObjectType 'Persons' 
				  # update database: add AttributeValuu of "User Status" to Object 'admin'
					$db_dump_file = __DIR__.DIRECTORY_SEPARATOR.'db_upgrade_0044_addPermissionTemp.sql';
					importDatabase( $this->repositoryConfig['db_host'], $this->repositoryConfig['db_port'], $this->repositoryConfig['db_name'], $this->repositoryConfig['db_u_name'], $this->repositoryConfig['db_u_pwd'], $db_dump_file );
				} 
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				} 
			}	
			/* here comes a template for new information structure upgrades
			case 0815: {
				// here comes the upgrading code --------------------------------

				// All environment variables are available as key=>value pairs in $this->repositoryConfig . 
				// In case that you need to add/change/delete the environment variables, do this in $this->repositoryConfig .

				// only delete environment variables in the corresponding upgrading section here, do never remove environment 
				// variables from older upgrading sections.
				
				// For environment variables, the types string and int are permitted.
				
				// Please note that doing nothing but incrementing the version number does always 
				// cause that the repository configuration file is overwritten.
				
				// end of the upgrading code -------------------------------------------
				$logHandler->debug('information structure upgrade step '.$this->version.' done.');
				{ # update version number
					$this->version++;
				} 
			};
			// do not forget to update informationStructureUpgrader::$current_Version at the top the class definition 
			// with the current version !!!
			*/
		}; // end switch version
		$logHandler->debug('Upgrading the information structure has finished. Current information structure version: '.$this->version);				
		
		$this->repositoryConfig['information_structure_version']=$this->version;
		$this->writeConfigFile();
	} # end-of-function upgrade 
	
	
	protected function _readConfigFile ($configFile) { 

		// read the current configuration file
		$this->configFile = $configFile;
		if (!is_readable($this->configFile)) 
			throw new Exception('Information Structure Upgrade Package: Cannot read the configuration file. Aborting.\n' );
		
		// read the configuration, if there is already one
		$this->repositoryConfig=array();
		if (filesize($this->configFile)>0) {
			// get the repository configuration
			require($this->configFile); 
			// now, the variable $repository_config is available
			
			// add absolute paths to the repository configuration
			require_once(__DIR__.DIRECTORY_SEPARATOR.'utilities.php');
			$repository_config = expandPathsIn_repository_config($repository_config);
			
			// make the repository configuration local
			$this->repositoryConfig=$repository_config;
			
		} else {
			$this->repositoryConfig['information_structure_version']=0;
		} // end if there is already a configuration

		// get the current information structure version
		$this->version = $this->repositoryConfig['information_structure_version'];

	} # end-of-function _readConfigFile
	

	protected function _createDynamicPathsWebBrowser ($repos_path) {
		// this method iterates over all dynamic paths and calls the creation routine
	
		$base_path = $repos_path.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'code_revisions'.
						DIRECTORY_SEPARATOR.$this->repositoryConfig['code_version'].DIRECTORY_SEPARATOR.'web_browser'.
						DIRECTORY_SEPARATOR;
						
		$dynamicPaths = array(
			'third_party_libraries',
			'media',
			'application',
			'common',
			'login'
		);
		
		reset($dynamicPaths);
		while(list($k,$dp)=each($dynamicPaths)) $this->_createDynamicPath($dp, $base_path, $this->repositoryConfig['path_web_browser']);
	
		// configure paths				
		$this->_registerPaths($repos_path);
		
		// writing config file
		$this->writeConfigFile();
		
	} # end-of-function _createDynamicPathsWebBrowser

	
	protected function _createDynamicPathsRoot ($repos_path,$dynamicPaths) {
		// this method iterates over all dynamic paths and calls the creation routine
	
		$base_path = $repos_path.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'code_revisions'.
						DIRECTORY_SEPARATOR.$this->repositoryConfig['code_version'].DIRECTORY_SEPARATOR;
							
		while(list($k,$dp)=each($dynamicPaths)) $this->_createDynamicPath($dp, $base_path, $this->repositoryConfig['path_repository_root']);
	
		// configure paths				
		$this->_registerPaths($repos_path);
		
		// writing config file
		$this->writeConfigFile();
	
	
	} # end-of-function _createDynamicPathsRoot
	
	
	protected function _createDynamicPath ($dp, $base_path, $dest_path){
		$this->repositoryConfig['path_'.$dp]=$dest_path.DIRECTORY_SEPARATOR.$dp;
		// only perform if folder doesn't allready exists
		if (!file_exists($this->repositoryConfig['path_'.$dp])) {
			// create a softlink to the directory $dp or simply copy it
			$folder=realpath( $base_path.$dp );		
			softlinkOrCopyDirectory($folder, $this->repositoryConfig['path_'.$dp]);			
		}

	} # end of protected method _createDynamicPath
        
	
} # end-of-class informationStructureUpgrader


function __debug () {
	$fileName = 'c:\debug.log';
	{ # open log file 
		try {
			$fHandle = fopen($fileName, 'a+');
			fwrite($fHandle, date('Y.m.d H:i:s').' ');
			if (! func_num_args())
				fwrite($fHandle, "\n");
			else {
				$funcArgs = func_get_args();
				foreach($funcArgs as $funcArg) {
					switch(true) {
						case is_scalar($funcArg): # scalar type
							fwrite($fHandle, $funcArg."\n");
							break;
						default: # non scalar
							fwrite($fHandle, print_r($funcArg, true)."\n");
					} # end-of-switch
				} # end-of-foreach
			}
			fclose($fHandle);
		} catch (Exception $e) {
			if ($fHandle)
				die ('Can`t write log file: ' . $e->getMessage());
		}
	}
} # end-of-function __debug

?>
