SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;


-- --------------------------------------------------------
-- Structure of Table 'watchlist'
-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `watchlist` (
  `WL_UUID` varchar(45) NOT NULL,
  `ownerP_UUID` varchar(45) NOT NULL,
  `O_UUID` varchar(45) NOT NULL,
  `comment` mediumtext NOT NULL,
  `addedAt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `addedByP_UUID` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
