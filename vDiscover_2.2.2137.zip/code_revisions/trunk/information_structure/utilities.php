<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
// %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//
// Information Structure -- general utilities 
//
// This file contains utilities the refer to the information structure of a repository

if ((!defined('REPOSITORY_MANAGER_started')) and (!defined('APPLICATION_started'))) {
	header('Location: ..');
	exit;
}

// absolute path expansion in $repository_config
function dirUp($p, $times=1) {return $p.str_repeat(DIRECTORY_SEPARATOR.'..', $times);};

function expandPathsIn_repository_config( $repository_config ) {// set some absolute paths as needed

	/** \brief This function builds absolute paths for accessing various modules and integrates them into a passed repository configuration.
	* \par $repository_config The repository configuration as array.
	*/

	if ( !array_key_exists( 'db_name', 		$repository_config ) ) throw new Exception('expandPathsIn_repository_config: no array key called \'db_name\' passed. Aborting.\n');
	if ( !array_key_exists( 'code_version', $repository_config ) ) throw new Exception('expandPathsIn_repository_config: no array key called \'code_version\' passed. Aborting.\n');
	if ( !array_key_exists( 'db_name', 		$repository_config ) ) throw new Exception('expandPathsIn_repository_config: no array key called \'db_name\' passed. Aborting.\n');

	{// build and verify the absolute path for everything below it
		
		$root_path = 
			$repository_config['root_path'] = 
				realpath(dirUp(__DIR__, 3));
		
		// check whether everying is ok
		if($root_path === false) throw new Exception('expandPathsIn_repository_config: Cannot build the path \'root_path\', properly. Aborting.\n' );
		
	} // end repository root path
	
	{ // build some general absolute paths
	
		$repository_root = 
			$repository_config['path_repository_root'] = 
				$root_path.DIRECTORY_SEPARATOR.'repositories'.DIRECTORY_SEPARATOR.$repository_config['db_name'].'.rpy';
	
		$repository_config['application_path'] = 
			$root_path.DIRECTORY_SEPARATOR.'code_revisions'.DIRECTORY_SEPARATOR.$repository_config['code_version'];
		
		$repository_config['backend_path'] = 
			$repository_config['application_path'].DIRECTORY_SEPARATOR.'backend';
		
	} // end general absolute paths
	
	{// make all relative sub paths of the repository root path absolute ones
		$rootSubPaths = array(
			'path_fileStore'		=>	'file_store',
			'path_sessions'			=>	'sessions',
			'path_temp'				=>	'temp',
			'path_uploads'			=>	'uploads',
			'path_database_backups'	=>	'database_backups',
			'path_logs'				=>	'logs',
			'path_plugins'			=>	'plugins',
			'path_web_browser'		=>	'web_browser',
			'path_web_service'		=>	'web_service',
			'path_common'			=>	'common',
			'path_common_plugins'	=>	'common_plugins',
			'path_tools'			=>	'tools',
		);
		
		while(list($k, $subPath) = each($rootSubPaths)) {
			$repository_config[ $k ] = $repository_root.DIRECTORY_SEPARATOR.$subPath;
		} // end while
	
	} // end build absolute sub paths of the repository root path
	
	{ // set some web_browser-specific sub paths
		$web_browserSubPaths = array(
			'path_third_party_libraries'=>	'third_party_libraries',
			'path_media'				=>	'media',
			'path_application'			=>	'application',
			'path_login'				=>	'login',
		);
		
		while(list($k, $subPath) = each($web_browserSubPaths)) {
			$repository_config[ $k ] = $repository_config['path_web_browser'].DIRECTORY_SEPARATOR.$subPath;
		} // end while
	
	} // end set web_browser-specific sub paths

	 return $repository_config;
} // end of function expandPathsInrepository_config

?>