-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Erstellungszeit: 14. Juni 2010 um 15:02
-- Server Version: 5.1.41
-- PHP-Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;





-- Not yet checked -------------------------------------------------------------------





-- --------------------------------------------------------


DROP TABLE IF EXISTS `accessHistory`;
CREATE TABLE IF NOT EXISTS `accessHistory` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `OT_UUID` varchar(45) NOT NULL DEFAULT '' COMMENT 'this col is not necessary, but it speeds up querying for the correct type or object\n\nT for type UUID\nO for object UUID',
  `O_UUID` varchar(45) NOT NULL DEFAULT '' COMMENT 'a type or object GUID',
  `V_UUID` varchar(45) NOT NULL DEFAULT '',
  `accessedAt` datetime NOT NULL,
  `accessedBy_P_UUID` varchar(45) NOT NULL DEFAULT '' COMMENT 'UUID of the person, who accessed the concept.',
  PRIMARY KEY (`id`),
  KEY `fkTypeObject` (`OT_UUID`),
  KEY `fkObject` (`O_UUID`),
  KEY `fkView` (`V_UUID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;


DROP TABLE IF EXISTS `noteList`;
CREATE TABLE IF NOT EXISTS `noteList` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `owner_UUID` varchar(45) NOT NULL DEFAULT '',
  `O_UUID` varchar(45) NOT NULL DEFAULT '',
  `noteListName` tinytext NOT NULL DEFAULT '',
  `addedAt` datetime NOT NULL,
  `addedBy_P_UUID` varchar(45) NOT NULL DEFAULT '' COMMENT 'UUID of the person, who added the task to the note list, that means the person, who was logged in during the note was added.',
  PRIMARY KEY (`id`),
  KEY `fkObject` (`O_UUID`),
  KEY `fkOwner` (`owner_UUID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;


DROP TABLE IF EXISTS `todoList`;
CREATE TABLE IF NOT EXISTS `todoList` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `O_UUID` varchar(45) DEFAULT NULL DEFAULT '',
  `dedicatedTo_P_UUID` varchar(45) NOT NULL DEFAULT '' COMMENT 'The person (user) the task is deicated to.',
  `message` mediumtext NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT ' ' COMMENT 'possible values:\nP	pending\nD	done',
  `addedAt` datetime NOT NULL,
  `addedBy_P_UUID` varchar(45) NOT NULL DEFAULT '' COMMENT 'UUID of the person, who added the task to the todo list, that means the person, who was logged in during the task was added.',
  PRIMARY KEY (`id`),
  KEY `fkObject` (`O_UUID`),
  KEY `fkDedicated_to` (`dedicatedTo_P_UUID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;





-- --------------------------------------------------------



INSERT INTO `concept` 
	(`C_v_UUID`, `C_UUID`, 
	 `CT_UUID`, `kind`, 
	 `name`, `versionType`, 
	 `changedAt`, `changedBy_P_UUID`) 
	VALUES
	('80f75ead-51de-11df-a6c3-455bf6c0df1e', 'd11e025f-4dea-11df-ad02-5ec5c072fa91', 
	 'd273e0d3-374b-11df-b9e6-76b0145055bb', 'O', 
	 'Maschine A', 'c', 
	 '2010-04-22 10:40:55', 'me'),
	('80f784a4-51de-11df-a6c3-455bf6c0df1e', 'f690e444-4def-11df-ad02-5ec5c072fa91', 
	 '213a2ee5-3744-11df-b9e6-76b0145055bb', 'O', 
	 'Betriebsmittel A', 'c', 
	 '2010-04-22 11:17:58', 'me'),
	('80f7a354-51de-11df-a6c3-455bf6c0df1e', 'd11e025f-4dea-11df-ad02-5ec5c072fa91', 
	 'd273e0d3-374b-11df-b9e6-76b0145055bb', 'O', 
	 'Maschine A (modified)', 'm', 
	 '2010-04-21 10:40:55', 'me'),
	('690cb2be-52c7-11df-a6c3-455bf6c0df1e', '690cb2f0-52c7-11df-a6c3-455bf6c0df1e', 
	 '32e8465a-3751-11df-b9e6-76b0145055bb', 'R', 
	 'produziert', 'c', 
	 '2010-04-28 15:10:17', 'me'),
	('be5e6ed4-52c7-11df-a6c3-455bf6c0df1e', 'be5e6f04-52c7-11df-a6c3-455bf6c0df1e', 
	 'a6b0eb48-374b-11df-b9e6-76b0145055bb', 'O', 
	 'Produkt A', 'c', 
	 '2010-04-28 15:12:41', 'me');


INSERT INTO `object` 
	(`O_v_UUID`, `descriptionHtml`, `descriptionPlain`) 
	VALUES
	('80f75ead-51de-11df-a6c3-455bf6c0df1e', '<p>description</p>', 'destription'),
	('80f784a4-51de-11df-a6c3-455bf6c0df1e', '', ''),
	('80f7a354-51de-11df-a6c3-455bf6c0df1e', '<p>description</p>', 'destription'),
	('be5e6ed4-52c7-11df-a6c3-455bf6c0df1e', 'ein tolles Produkt A', '');




INSERT INTO `relation` 
	(`R_v_UUID`, `Start_O_v_UUID`, `End_O_v_UUID`) 
	VALUES
	('690cb2be-52c7-11df-a6c3-455bf6c0df1e', '80f75ead-51de-11df-a6c3-455bf6c0df1e', 'be5e6ed4-52c7-11df-a6c3-455bf6c0df1e');


INSERT INTO `viewType` 
	(`VT_UUID`, `CT_UUID`, `conceptTypeKind`, 
	 `name`, `templateContentHtml`, `description`, 
	 `positionOfView`, 
	 `specialContentFile`, `searchPoints`, `specialContentConfig`, 
	 `changedAt`, `changedBy_P_UUID`) 
	VALUES
	('c122c4ca-3bfa-11df-adc6-4522d9ddc647', 'd273e0d3-374b-11df-b9e6-76b0145055bb', 'O', 
	 'All attr in a table', '', '', 
	 1, 
	 '', '', 0x616161, 
	 '2010-03-30 14:49:52', 'me'),
	('ddee4292-3bfa-11df-adc6-4522d9ddc647', '32e8465a-3751-11df-b9e6-76b0145055bb', 'R', 
	 'Attribute View of the relation', '', '', 
	 1, 
	 '', '', 0x616161, 
	 '2010-03-30 14:50:41', 'me');



INSERT INTO `attribute` 
	(`A_UUID`, `CT_UUID`, `A_origin_UUID`, 
	 `conceptTypeKind`, `kind`, 
	 `name`, `description`, 
	 `positionOfAttribute`, `cardinality`, 
	 `readOnly`, `mustBeSet`, `nameOfVariable`, 
	 `configuration`, 
	 `changedAt`, `changedBy_P_UUID`) 
	VALUES 
	('e389893b-3017-11df-913b-f2f90c4f6719', 'd289893b-3017-11df-913b-f2f90c4f6719', '', 
	 'O', 'cBlobAttribute', 
	 'BlobAttribute', 'Description of BlobAttribute', 
	 0, 1, 
	 0, 0, '', 
	 'a:5:{s:17:"svFormatActivated";b:0;s:12:"svHtmlBefore";s:0:"";s:13:"svHtmlBetween";s:0:"";s:11:"svHtmlAfter";s:0:"";s:7:"maxSize";i:0;}', 
	 '2010-09-15 15:30:00', 'geg'),
	('f489893b-3017-11df-913b-f2f90c4f6719', 'd289893b-3017-11df-913b-f2f90c4f6719', '', 
	 'O', 'cClassificationNumberAttribute', 
	 'ClassificationNumberAttribute', 'Description of ClassificationNumberAttribute', 
	 0, 1, 
	 0, 0, '', 
	 'a:0:{}', 
	 '2010-09-15 15:30:00', 'geg'),
	('g589893b-3017-11df-913b-f2f90c4f6719', 'd289893b-3017-11df-913b-f2f90c4f6719', '', 
	 'O', 'cCounterAttribute', 
	 'CounterAttribute', 'Description of CounterAttribute', 
	 0, 1, 
	 0, 0, '', 
	 'a:2:{s:9:"nextValue";i:1;s:9:"increment";i:1;}', 
	 '2010-09-15 15:30:00', 'geg'),
	('h689893b-3017-11df-913b-f2f90c4f6719', 'd289893b-3017-11df-913b-f2f90c4f6719', '', 
	 'O', 'cDateTimeAttribute', 
	 'DateTimeAttribute', 'Description of DateTimeAttribute', 
	 0, 1, 
	 0, 0, '', 
	 'a:11:{s:17:"svFormatActivated";b:0;s:12:"svHtmlBefore";s:0:"";s:13:"svHtmlBetween";s:0:"";s:11:"svHtmlAfter";s:0:"";s:16:"currentAsDefault";b:0;s:19:"futureValuesAllowed";b:1;s:17:"pastValuesAllowed";b:1;s:8:"showDate";b:1;s:8:"showTime";b:1;s:10:"dateFormat";s:0:"";s:10:"timeFormat";s:0:"";}', 
	 '2010-09-15 15:30:00', 'geg'),
	('i789893b-3017-11df-913b-f2f90c4f6719', 'd289893b-3017-11df-913b-f2f90c4f6719', '', 
	 'O', 'cExternalLinkAttribute', 
	 'ExternalLinkAttribute', 'Description of ExternalLinkAttribute', 
	 0, 1, 
	 0, 0, '', 
	 'a:4:{s:17:"svFormatActivated";b:0;s:12:"svHtmlBefore";s:0:"";s:13:"svHtmlBetween";s:0:"";s:11:"svHtmlAfter";s:0:"";}', 
	 '2010-09-15 15:30:00', 'geg'),
	('j889893b-3017-11df-913b-f2f90c4f6719', 'd289893b-3017-11df-913b-f2f90c4f6719', '', 
	 'O', 'cFileAttribute', 
	 'FileAttribute', 'Description of FileAttribute', 
	 0, 1, 
	 0, 0, '', 
	 'a:4:{s:17:"svFormatActivated";b:0;s:12:"svHtmlBefore";s:0:"";s:13:"svHtmlBetween";s:0:"";s:11:"svHtmlAfter";s:0:"";}', 
	 '2010-09-15 15:30:00', 'geg'),
	('k989893b-3017-11df-913b-f2f90c4f6719', 'd289893b-3017-11df-913b-f2f90c4f6719', '', 
	 'O', 'cKeyValuePairAttribute', 
	 'KeyValuePairAttribute', 'Description of KeyValuePairAttribute', 
	 0, 1, 
	 0, 0, '', 
	 'a:6:{s:17:"svFormatActivated";b:0;s:12:"svHtmlBefore";s:0:"";s:13:"svHtmlBetween";s:0:"";s:11:"svHtmlAfter";s:0:"";s:17:"displayAsCheckbox";b:0;s:14:"showAllOptions";b:0;}', 
	 '2010-09-15 15:30:00', 'geg'),
	('l189893b-3017-11df-913b-f2f90c4f6719', 'd289893b-3017-11df-913b-f2f90c4f6719', '', 
	 'O', 'cLastChangeAttribute', 
	 'LastChangeAttribute', 'Description of LastChangeAttribute', 
	 0, 1, 
	 0, 0, '', 
	 'a:0:{}', 
	 '2010-09-15 15:30:00', 'geg'),
	('m289893b-3017-11df-913b-f2f90c4f6719', 'd289893b-3017-11df-913b-f2f90c4f6719', '', 
	 'O', 'cMultiLineAttribute', 
	 'MultiLineAttribute', 'Description of MultiLineAttribute', 
	 0, 1, 
	 0, 0, '', 
	 'a:1:{s:11:"htmlAllowed";b:0;}', 
	 '2010-09-15 15:30:00', 'geg'),
	('n389893b-3017-11df-913b-f2f90c4f6719', 'd289893b-3017-11df-913b-f2f90c4f6719', '', 
	 'O', 'cNumberAttribute', 
	 'NumberAttribute', 'Description of NumberAttribute', 
	 0, 1, 
	 0, 0, '', 
	 'a:8:{s:17:"svFormatActivated";b:0;s:12:"svHtmlBefore";s:0:"";s:13:"svHtmlBetween";s:0:"";s:11:"svHtmlAfter";s:0:"";s:6:"format";s:0:"";s:4:"unit";s:0:"";s:8:"minValue";N;s:8:"maxValue";N;}', 
	 '2010-09-15 15:30:00', 'geg'),
	('n489893b-3017-11df-913b-f2f90c4f6719', 'd289893b-3017-11df-913b-f2f90c4f6719', '', 
	 'O', 'cRelationAttribute', 
	 'RelationAttribute', 'Description of RelationAttribute', 
	 0, 1, 
	 0, 0, '', 
	 'a:4:{s:17:"svFormatActivated";b:0;s:12:"svHtmlBefore";s:0:"";s:13:"svHtmlBetween";s:0:"";s:11:"svHtmlAfter";s:0:"";}', 
	 '2010-09-15 15:30:00', 'geg'),
	('o389893b-3017-11df-913b-f2f90c4f6719', 'd289893b-3017-11df-913b-f2f90c4f6719', '', 
	 'O', 'cPersonAttribute', 
	 'PersonAttribute', 'Description of PersonAttribute', 
	 0, 1, 
	 0, 0, '', 
	 'a:4:{s:17:"svFormatActivated";b:0;s:12:"svHtmlBefore";s:0:"";s:13:"svHtmlBetween";s:0:"";s:11:"svHtmlAfter";s:0:"";}', 
	 '2010-09-15 15:30:00', 'geg'),
    ('o489893b-3017-11df-913b-f2f90c4f6719', 'd289893b-3017-11df-913b-f2f90c4f6719', '', 
	 'O', 'cPasswordAttribute', 
	 'PasswordAttribute', 'Description of PasswordAttribute', 
	 0, 1, 
	 0, 0, '', 
	 'a:1:{s:9:"minLength";i:1;}', 
	 '2010-09-15 15:30:00', 'geg'),
	('p589893b-3017-11df-913b-f2f90c4f6719', 'd289893b-3017-11df-913b-f2f90c4f6719', '', 
	 'O', 'cSingleLineAttribute', 
	 'SingleLineAttribute', 'Description of SingleLineAttribute', 
	 0, 1, 
	 0, 0, '', 
	 'a:6:{s:17:"svFormatActivated";b:0;s:12:"svHtmlBefore";s:0:"";s:13:"svHtmlBetween";s:0:"";s:11:"svHtmlAfter";s:0:"";s:6:"format";s:0:"";s:9:"maxLength";i:255;}', 
	 '2010-09-15 15:30:00', 'geg'),
	('q689893b-3017-11df-913b-f2f90c4f6719', 'd289893b-3017-11df-913b-f2f90c4f6719', '', 
	 'O', 'cStatusAttribute', 
	 'StatusAttribute', 'Description of StatusAttribute', 
	 0, 1, 
	 0, 0, '', 
	 'a:0:{}', 
	 '2010-09-15 15:30:00', 'geg'),
	('r789893b-3017-11df-913b-f2f90c4f6719', 'd289893b-3017-11df-913b-f2f90c4f6719', '', 
	 'O', 'cValueRangeAttribute', 
	 'ValueRangeAttribute', 'Description of ValueRangeAttribute', 
	 0, 1, 
	 0, 0, '', 
	 'a:8:{s:17:"svFormatActivated";b:0;s:12:"svHtmlBefore";s:0:"";s:13:"svHtmlBetween";s:0:"";s:11:"svHtmlAfter";s:0:"";s:6:"format";s:0:"";s:4:"unit";s:0:"";s:8:"minValue";N;s:8:"maxValue";N;}', 
	 '2010-09-15 15:30:00', 'geg');

	
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
