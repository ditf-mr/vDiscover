SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;


-- -----------------------------------------------------------
-- Add workflowConfigurationActivated as column
-- -----------------------------------------------------------

ALTER TABLE `object`
ADD currentState varchar(45)  NULL AFTER descriptionPlain,
ADD visibleInSearch boolean default true NULL AFTER currentState,
ADD dueDate datetime  NULL AFTER visibleInSearch
;

