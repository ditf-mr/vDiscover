SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;


-- -----------------------------------------------------------
-- Add workflowConfigurationActivated as column
-- -----------------------------------------------------------

ALTER TABLE objecttype
ADD workflowConfigurationActivated boolean NOT NULL  default false AFTER equationSystem;

