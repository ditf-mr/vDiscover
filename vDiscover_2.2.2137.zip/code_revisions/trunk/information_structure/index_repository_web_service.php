<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

define('INTERFACE', 'web_service');

require('../index.php');

require(realpath(__DIR__.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'code_revisions'.DIRECTORY_SEPARATOR.$repository_config['code_version'].DIRECTORY_SEPARATOR.'web_service'.DIRECTORY_SEPARATOR.'index.php'));


// end if file ---------------------------------------------------------------------------------
?>