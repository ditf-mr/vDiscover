SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;


-- --------------------------------------------------------
-- Add new columns
-- --------------------------------------------------------

ALTER TABLE attributevalue
	ADD value_tinytext_1 TINYTEXT NOT NULL AFTER value_linkUrl,  
	ADD value_tinytext_2 TINYTEXT NOT NULL AFTER value_tinytext_1,  
	ADD value_tinytext_3 TINYTEXT NOT NULL AFTER value_tinytext_2,  
	ADD value_tinytext_4 TINYTEXT NOT NULL AFTER value_tinytext_3,  
	ADD value_tinytext_5 TINYTEXT NOT NULL AFTER value_tinytext_4,  
	ADD value_mediumtext_1 MEDIUMTEXT NOT NULL AFTER value_tinytext_5,  
	ADD value_mediumtext_2 MEDIUMTEXT NOT NULL AFTER value_mediumtext_1,  
	ADD value_mediumtext_3 MEDIUMTEXT NOT NULL AFTER value_mediumtext_2,  
	ADD value_decimal_1 DECIMAL(65,15) NOT NULL DEFAULT '0' AFTER value_mediumtext_3,  
	ADD value_decimal_2 DECIMAL(65,15) NOT NULL DEFAULT '0' AFTER value_decimal_1,  
	ADD value_decimal_3 DECIMAL(65,15) NOT NULL DEFAULT '0' AFTER value_decimal_2,  
	ADD value_decimal_4 DECIMAL(65,15) NOT NULL DEFAULT '0' AFTER value_decimal_3,  
	ADD value_decimal_5 DECIMAL(65,15) NOT NULL DEFAULT '0' AFTER value_decimal_4,  
	ADD value_boolean_1 TINYINT(1) NOT NULL DEFAULT '0' AFTER value_decimal_5,  
	ADD value_boolean_2 TINYINT(1) NOT NULL DEFAULT '0' AFTER value_boolean_1,  
	ADD value_boolean_3 TINYINT(1) NOT NULL DEFAULT '0' AFTER value_boolean_2,  
	ADD value_datetime_1 DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00' AFTER value_boolean_3,
	ADD value_datetime_2 DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00' AFTER value_datetime_1,
	ADD value_datetime_3 DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00' AFTER value_datetime_2
;


-- --------------------------------------------------------
-- Copy values
-- --------------------------------------------------------

-- cDateTimeAttributeValue
UPDATE attributevalue 
	SET	value_datetime_1 = value_timepoint
	WHERE (kind = 'cDateTimeAttributeValue')
;

-- cFuzzyAttributeValue
UPDATE attributevalue 
	SET	value_decimal_1 = value_number, 
		value_mediumtext_1 = value_text
	WHERE (kind = 'cFuzzyAttributeValue')
;

-- cKeyValuePairAttributeValue
UPDATE attributevalue
	SET	value_tinytext_1 = value_listKey
	WHERE (kind = 'cKeyValuePairAttributeValue')
;

-- cMultiLineAttributeValue
UPDATE attributevalue
	SET	value_mediumtext_1 = value_text, 
		value_mediumtext_2 = value_textPlain
	WHERE (kind = 'cMultiLineAttributeValue')
;

-- cNumberAttributeValue
UPDATE attributevalue
	SET	value_decimal_1 = value_number
	WHERE (kind = 'cNumberAttributeValue')
;

-- cPasswordAttributeValue
UPDATE attributevalue
	SET	value_tinytext_1 = value_password
	WHERE (kind = 'cPasswordAttributeValue')
;

-- cRelationAttributeValue
UPDATE attributevalue
	SET	value_tinytext_1 = value_UUID
	WHERE (kind = 'cRelationAttributeValue')
;

-- cSingleLineAttributeValue
UPDATE attributevalue
	SET	value_tinytext_1 = value_text, 
		value_tinytext_2 = value_textPlain
	WHERE (kind = 'cSingleLineAttributeValue')
;

-- cValueRangeAttributeValue
UPDATE attributevalue
	SET	value_decimal_1 = value_rangeMin, 
		value_decimal_2 = value_rangeMax
	WHERE (kind = 'cValueRangeAttributeValue')
;


-- --------------------------------------------------------
-- Delete old columns
-- --------------------------------------------------------

ALTER TABLE `attributevalue`
  DROP `value_text`,
  DROP `value_textPlain`,
  DROP `value_UUID`,
  DROP `value_fileTitle`,
  DROP `value_fileName`,
  DROP `value_fileExtension`,
  DROP `value_fileStoreFileName`,
  DROP `value_fileSize`,
  DROP `value_number`,
  DROP `value_binaryData`,
  DROP `value_password`,
  DROP `value_personFirstName`,
  DROP `value_personLastName`,
  DROP `value_personGender`,
  DROP `value_personTitle`,
  DROP `value_rangeMin`,
  DROP `value_rangeMax`,
  DROP `value_listKey`,
  DROP `value_timepoint`,
  DROP `value_linkUrl`;













