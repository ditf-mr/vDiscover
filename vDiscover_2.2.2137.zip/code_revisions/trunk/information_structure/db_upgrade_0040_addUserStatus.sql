SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;


-- --------------------------------------------------------
-- Create new table queries
-- --------------------------------------------------------


-- Attributes "user status" of "Persons"
INSERT INTO `attribute` (`A_UUID`, `ORT_UUID`, `ORT_kind`, `A_origin_UUID`, `kind`, `name`, `description`, `descriptionPlain`, `readModeHint`, `editModeHint`, `positionOfAttribute`, `cardinality`, `readOnly`, `mustBeSet`, `mustBeUnique`, `displayInFullWidth`, `configuration`, `isSystemObject`, `createdAt`, `createdByP_UUID`, `changedAt`, `changedByP_UUID`/*, `CBRWeight`, `CBRResolution`, `CBRMustBeSet`*/) VALUES
('10000000-1000-1000-1007-00000000e000', '10000000-1000-1000-1000-00000000e000', 'O', '', 'cIsActiveAttribute', 'User Status', 'The access status of the user.', 'The access status of the user.', '', '', 7, 1, 0, 1, 0, 0, 'a:11:{s:4:"tags";a:0:{}s:17:"svFormatActivated";b:0;s:28:"svHtmlTagBeforeValueTupleSet";s:0:"";s:27:"svHtmlTagAfterValueTupleSet";s:0:"";s:25:"svHtmlTagBeforeValueTuple";s:0:"";s:24:"svHtmlTagAfterValueTuple";s:0:"";s:30:"valueTupleReordering_permitted";b:0;s:13:"keyValuePairs";a:3:{i:1;s:6:"active";i:0;s:11:"deactivated";i:2;s:22:"waiting for activation";}s:17:"displayAsCheckbox";b:1;s:14:"showAllOptions";b:0;s:12:"defaultValue";a:1:{i:0;s:1:"2";}}', 1, '0000-00-00 00:00:00', '', '2012-08-24 11:00:00', '10000000-1000-1001-1000-00000000e000'/*, 1, 5, 1*/);


-- Add Attribute Value for Admin-User
INSERT INTO `attributevalue` (`AV_v_UUID`, `versionType`, `AV_UUID`, `A_UUID`, `OR_v_UUID`, `OR_kind`, `kind`, `positionOfAttribute`, `positionOfValue`, `value_tinytext_1`, `value_tinytext_2`, `value_tinytext_3`, `value_tinytext_4`, `value_tinytext_5`, `value_mediumtext_1`, `value_mediumtext_2`, `value_mediumtext_3`, `value_decimal_1`, `value_decimal_2`, `value_decimal_3`, `value_decimal_4`, `value_decimal_5`, `value_boolean_1`, `value_boolean_2`, `value_boolean_3`, `value_datetime_1`, `value_datetime_2`, `value_datetime_3`, `isSystemObject`, `createdAt`, `createdByP_UUID`, `changedAt`, `changedByP_UUID`) VALUES
('3e810e7a-d18b-11e5-a5d5-00fff1f86e41', 'c', '3e811c06-d18b-11e5-a5d5-00fff1f86e41', '10000000-1000-1000-1007-00000000e000', '10000001-1000-1001-1000-00000000e000', 'O', 'cIsActiveAttributeValue', 7, 1, '1', '', '', '', '', '', '', '', '0.000000000000000', '0.000000000000000', '0.000000000000000', '0.000000000000000', '0.000000000000000', 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, '2012-02-09 08:50:55', '10000000-1000-1001-1000-00000000e000', '2012-02-09 08:50:55', '10000000-1000-1001-1000-00000000e000');








