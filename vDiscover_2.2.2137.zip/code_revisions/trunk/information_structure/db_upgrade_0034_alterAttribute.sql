SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;


-- ----------------------------------------------------------------------------------
-- Add enableAnalyticalExpressions and analyticalExpressionConfig_asJSON to attribute
-- ----------------------------------------------------------------------------------

ALTER TABLE attribute
ADD enableAnalyticalExpressions tinyint(1) NOT NULL DEFAULT '0' AFTER mustBeUnique,
ADD analyticalExpressionConfig_asJSON mediumtext NOT NULL AFTER enableAnalyticalExpressions;


UPDATE attribute
SET 
	analyticalExpressionConfig_asJSON = "{\"attrVars\":{},\"funcBody\":\"\"}"
WHERE (analyticalExpressionConfig_asJSON = "");
