SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;


-- Delete a column in 'viewtype'
ALTER TABLE viewtype
DROP showEmptyAttributesInReadMode;


-- Mark O "August Administrator" as a system object
UPDATE object
SET isSystemObject = 1
WHERE O_UUID = '10000000-1000-1001-1000-00000000e000';


-- Rename RT 'act as' to 'act as / assigned to'
UPDATE relationtype
SET nameOfInverse = 'assigned to'
WHERE RT_UUID = '10000000-1000-1000-1000-0000000ac0a0';


-- Add Objects of Object Type "Roles"
INSERT INTO `object` (`O_v_UUID`, `versionType`, `O_UUID`, `OT_UUID`, `name`, `description`, `descriptionPlain`, `isSystemObject`, `changedAt`, `changedByP_UUID`) VALUES
('27ba8523-5189-11e1-a62f-406186f2abca', 'c', '27ba94cd-5189-11e1-a62f-406186f2abca', '10000000-1000-1000-1000-00000000000e', 'Reader', '', '', 1, '2012-02-09 08:50:55', '10000000-1000-1001-1000-00000000e000'),
('28b1d53c-5189-11e1-a62f-406186f2abca', 'c', '28b1de64-5189-11e1-a62f-406186f2abca', '10000000-1000-1000-1000-00000000000e', 'Writer', '', '', 1, '2012-02-09 08:50:55', '10000000-1000-1001-1000-00000000e000');


-- Add Attribute Values for new Objects
INSERT INTO `attributevalue` (`AV_v_UUID`, `versionType`, `AV_UUID`, `A_UUID`, `OR_v_UUID`, `OR_kind`, `kind`, `positionOfAttribute`, `positionOfValue`, `value_tinytext_1`, `value_tinytext_2`, `value_tinytext_3`, `value_tinytext_4`, `value_tinytext_5`, `value_mediumtext_1`, `value_mediumtext_2`, `value_mediumtext_3`, `value_decimal_1`, `value_decimal_2`, `value_decimal_3`, `value_decimal_4`, `value_decimal_5`, `value_boolean_1`, `value_boolean_2`, `value_boolean_3`, `value_datetime_1`, `value_datetime_2`, `value_datetime_3`, `isSystemObject`, `createdAt`, `createdByP_UUID`, `changedAt`, `changedByP_UUID`) VALUES
('27ba8532-5189-11e1-a62f-406186f2abca', 'c', '27ba94dc-5189-11e1-a62f-406186f2abca', '10000000-1000-1000-1001-00000000000e', '27ba8523-5189-11e1-a62f-406186f2abca', 'O', 'cSingleLineAttributeValue', 1, 1, 'Reader', 'Reader', '', '', '', '', '', '', '0.000000000000000', '0.000000000000000', '0.000000000000000', '0.000000000000000', '0.000000000000000', 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, '2012-02-09 08:50:55', '10000000-1000-1001-1000-00000000e000', '2012-02-09 08:50:55', '10000000-1000-1001-1000-00000000e000'),
('28b1d5c3-5189-11e1-a62f-406186f2abca', 'c', '28b1de46-5189-11e1-a62f-406186f2abca', '10000000-1000-1000-1001-00000000000e', '28b1d53c-5189-11e1-a62f-406186f2abca', 'O', 'cSingleLineAttributeValue', 1, 1, 'Writer', 'Writer', '', '', '', '', '', '', '0.000000000000000', '0.000000000000000', '0.000000000000000', '0.000000000000000', '0.000000000000000', 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, '2012-02-09 08:50:55', '10000000-1000-1001-1000-00000000e000', '2012-02-09 08:50:55', '10000000-1000-1001-1000-00000000e000');


-- Add Objects of Object Type "Persons"
-- INSERT INTO `object` (`O_v_UUID`, `versionType`, `O_UUID`, `OT_UUID`, `name`, `description`, `descriptionPlain`, `isSystemObject`, `changedAt`, `changedByP_UUID`) VALUES
-- ('b3a734fb-52ea-11e1-81db-88b801d940b3', 'c', 'b3a7403f-52ea-11e1-81db-88b801d940b3', '10000000-1000-1000-1000-00000000e000', 'Randolf Reader', '', '', 0, '2012-02-09 08:50:55', '10000000-1000-1001-1000-00000000e000'),
-- ('bb1ec0ac-52ea-11e1-81db-88b801d940b3', 'c', 'bb1ecb94-52ea-11e1-81db-88b801d940b3', '10000000-1000-1000-1000-00000000e000', 'Wilma Writer', '', '', 0, '2012-02-09 08:50:55', '10000000-1000-1001-1000-00000000e000');


-- Add Attribute Values for new Objects
-- INSERT INTO `attributevalue` (`AV_v_UUID`, `versionType`, `AV_UUID`, `A_UUID`, `OR_v_UUID`, `OR_kind`, `kind`, `positionOfAttribute`, `positionOfValue`, `value_tinytext_1`, `value_tinytext_2`, `value_tinytext_3`, `value_tinytext_4`, `value_tinytext_5`, `value_mediumtext_1`, `value_mediumtext_2`, `value_mediumtext_3`, `value_decimal_1`, `value_decimal_2`, `value_decimal_3`, `value_decimal_4`, `value_decimal_5`, `value_boolean_1`, `value_boolean_2`, `value_boolean_3`, `value_datetime_1`, `value_datetime_2`, `value_datetime_3`, `isSystemObject`, `createdAt`, `createdByP_UUID`, `changedAt`, `changedByP_UUID`) VALUES
-- ('9e223aa6-7c7c-11e0-a3b1-406186f2abca', 'c', '9e224564-7c7c-11e0-a3b1-406186f2abca', '10000000-1000-1000-1001-00000000e000', 'b3a734fb-52ea-11e1-81db-88b801d940b3', 'O', 'cSingleLineAttributeValue', 1, 1, 'Reader', 'Reader', '', '', '', '', '', '', '0.000000000000000', '0.000000000000000', '0.000000000000000', '0.000000000000000', '0.000000000000000', 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, '2012-02-09 08:50:55', '10000000-1000-1001-1000-00000000e000', '2012-02-09 08:50:55', '10000000-1000-1001-1000-00000000e000'),
-- ('be718d47-7c7c-11e0-a3b1-406186f2abca', 'c', 'be71989a-7c7c-11e0-a3b1-406186f2abca', '10000000-1000-1000-1003-00000000e000', 'b3a734fb-52ea-11e1-81db-88b801d940b3', 'O', 'cSingleLineAttributeValue', 2, 1, 'Randolf Reader', 'Randolf Reader', '', '', '', '', '', '', '0.000000000000000', '0.000000000000000', '0.000000000000000', '0.000000000000000', '0.000000000000000', 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, '2012-02-09 08:50:55', '10000000-1000-1001-1000-00000000e000', '2012-02-09 08:50:55', '10000000-1000-1001-1000-00000000e000'),
-- ('c349f019-7c7c-11e0-a3b1-406186f2abca', 'c', 'c349fc21-7c7c-11e0-a3b1-406186f2abca', '10000000-1000-1000-1002-00000000e000', 'b3a734fb-52ea-11e1-81db-88b801d940b3', 'O', 'cPasswordAttributeValue', 3, 1, 'b1518456785038807d2639d1fc01a25e', '', '', '', '', '', '', '', '0.000000000000000', '0.000000000000000', '0.000000000000000', '0.000000000000000', '0.000000000000000', 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, '2012-02-09 08:50:55', '10000000-1000-1001-1000-00000000e000', '2012-02-09 08:50:55', '10000000-1000-1001-1000-00000000e000'),
-- ('8e223aa6-7c7c-11e0-a3b1-406186f2abca', 'c', '8e224564-7c7c-11e0-a3b1-406186f2abca', '10000000-1000-1000-1001-00000000e000', 'bb1ec0ac-52ea-11e1-81db-88b801d940b3', 'O', 'cSingleLineAttributeValue', 1, 1, 'Writer', 'Writer', '', '', '', '', '', '', '0.000000000000000', '0.000000000000000', '0.000000000000000', '0.000000000000000', '0.000000000000000', 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, '2012-02-09 08:50:55', '10000000-1000-1001-1000-00000000e000', '2012-02-09 08:50:55', '10000000-1000-1001-1000-00000000e000'),
-- ('ae718d47-7c7c-11e0-a3b1-406186f2abca', 'c', 'ae71989a-7c7c-11e0-a3b1-406186f2abca', '10000000-1000-1000-1003-00000000e000', 'bb1ec0ac-52ea-11e1-81db-88b801d940b3', 'O', 'cSingleLineAttributeValue', 2, 1, 'Wilma Writer', 'Wilma Writer', '', '', '', '', '', '', '0.000000000000000', '0.000000000000000', '0.000000000000000', '0.000000000000000', '0.000000000000000', 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, '2012-02-09 08:50:55', '10000000-1000-1001-1000-00000000e000', '2012-02-09 08:50:55', '10000000-1000-1001-1000-00000000e000'),
-- ('b349f019-7c7c-11e0-a3b1-406186f2abca', 'c', 'b349fc21-7c7c-11e0-a3b1-406186f2abca', '10000000-1000-1000-1002-00000000e000', 'bb1ec0ac-52ea-11e1-81db-88b801d940b3', 'O', 'cPasswordAttributeValue', 3, 1, 'b1518456785038807d2639d1fc01a25e', '', '', '', '', '', '', '', '0.000000000000000', '0.000000000000000', '0.000000000000000', '0.000000000000000', '0.000000000000000', 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, '2012-02-09 08:50:55', '10000000-1000-1001-1000-00000000e000', '2012-02-09 08:50:55', '10000000-1000-1001-1000-00000000e000');

-- Add Relations between Object "Persons" and "Roles"
-- INSERT INTO `relation` (`R_v_UUID`, `versionType`, `R_UUID`, `RT_UUID`, `Start_O_UUID`, `End_O_UUID`, `positionOfRelation`, `isSystemObject`, `changedAt`, `changedByP_UUID`) VALUES
-- ('2c0cec63-52eb-11e1-81db-88b801d940b3', 'c', '2b94a063-52eb-11e1-81db-88b801d940b3', '10000000-1000-1000-1000-0000000ac0a0', 'b3a7403f-52ea-11e1-81db-88b801d940b3', '27ba94cd-5189-11e1-a62f-406186f2abca', 1, 0, '2012-02-09 08:50:55', '10000000-1000-1001-1000-00000000e000'),
-- ('cc92e2f4-7c7c-11e0-a3b1-406186f2abca', 'c', '1c0cf7b5-52eb-11e1-81db-88b801d940b3', '10000000-1000-1000-1000-0000000ac0a0', 'bb1ecb94-52ea-11e1-81db-88b801d940b3', '28b1de64-5189-11e1-a62f-406186f2abca', 1, 0, '2012-02-09 08:50:55', '10000000-1000-1001-1000-00000000e000');
