SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;


-- -----------------------------------------------------------
-- Rename column readOnly and change type to int of viewType
-- -----------------------------------------------------------

ALTER TABLE viewtype 
CHANGE readOnly editingLevel INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '0=editiable, 1=readOnly, 2=invisible'
