SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;


-- --------------------------------------------------------
-- Create new table queries
-- --------------------------------------------------------


-- Attributes "Language" and "Country" of "Persons"
INSERT INTO `attribute` (`A_UUID`, `ORT_UUID`, `ORT_kind`, `A_origin_UUID`, `kind`, `name`, `description`, `descriptionPlain`, `readModeHint`, `editModeHint`, `positionOfAttribute`, `cardinality`, `readOnly`, `mustBeSet`, `mustBeUnique`, `displayInFullWidth`, `configuration`, `isSystemObject`, `createdAt`, `createdByP_UUID`, `changedAt`, `changedByP_UUID`/*, `CBRWeight`, `CBRResolution`, `CBRMustBeSet`*/) VALUES
('10000000-1000-1000-1005-00000000e000', '10000000-1000-1000-1000-00000000e000', 'O', '', 'cSingleLineAttribute', 'Language', 'The language code of the person, e.g. "en" (English) or "de" (German).', 'The language code of the person, e.g. "en" (English) or "de" (German).', '', '', 5, 1, 0, 0, 0, 0, 'a:10:{s:4:"tags";a:0:{}s:17:"svFormatActivated";b:0;s:28:"svHtmlTagBeforeValueTupleSet";s:0:"";s:27:"svHtmlTagAfterValueTupleSet";s:0:"";s:25:"svHtmlTagBeforeValueTuple";s:0:"";s:24:"svHtmlTagAfterValueTuple";s:0:"";s:30:"valueTupleReordering_permitted";b:0;s:6:"format";s:10:"[a-z][a-z]";s:9:"maxLength";i:2;s:12:"defaultValue";s:0:"";}', 1, '0000-00-00 00:00:00', '', '2012-08-24 11:00:00', '10000000-1000-1001-1000-00000000e000'/*, 1, 5, 1*/),
('10000000-1000-1000-1006-00000000e000', '10000000-1000-1000-1000-00000000e000', 'O', '', 'cSingleLineAttribute', 'Country', 'The country code of the person, e.g. "US" (United States), "GB" (United Kingdom) or "DE" (Germany).', 'The country code of the person, e.g. "US" (United States), "GB" (United Kingdom) or "DE" (Germany).', '', '', 6, 1, 0, 0, 0, 0, 'a:10:{s:4:"tags";a:0:{}s:17:"svFormatActivated";b:0;s:28:"svHtmlTagBeforeValueTupleSet";s:0:"";s:27:"svHtmlTagAfterValueTupleSet";s:0:"";s:25:"svHtmlTagBeforeValueTuple";s:0:"";s:24:"svHtmlTagAfterValueTuple";s:0:"";s:30:"valueTupleReordering_permitted";b:0;s:6:"format";s:10:"[A-Z][A-Z]";s:9:"maxLength";i:2;s:12:"defaultValue";s:0:"";}', 1, '0000-00-00 00:00:00', '', '2011-08-24 11:00:00', '10000000-1000-1001-1000-00000000e000'/*, 1, 5, 1*/);


INSERT INTO `viewtype` (`VT_UUID`, `ORT_UUID`, `ORT_kind`, `VT_origin_UUID`, `kind`, `name`, `description`, `descriptionPlain`, `positionOfView`, `configuration`, `editingLevel`, `searchPoints`, `isSystemObject`, `createdAt`, `createdByP_UUID`) VALUES
('92ec7b16-eddd-11e1-9fe6-406186f2abca', '10000000-1000-1000-1000-00000000e000', 'O', '', 'cAllAttributesViewType', 'All Attributes', '', '', 2, 'a:1:{s:29:"showEmptyAttributesInReadMode";b:1;}', 0, 5, 1, '2012-08-24 13:19:30', '10000000-1000-1001-1000-00000000e000');










