SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;


-- -----------------------------------------------------------
-- Add eqSolverIsActive and eqSolverJSONConfig to attributes
-- -----------------------------------------------------------

ALTER TABLE viewtype
ADD eqSolverIsActive tinyint(1) NOT NULL DEFAULT 0 AFTER searchPoints,
ADD eqSolverJSONConfig mediumtext NOT NULL AFTER eqSolverIsActive;

UPDATE viewtype
SET eqSolverJSONConfig = '{}'
WHERE (eqSolverJSONConfig = '')