SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;


-- --------------------------------------------------------
-- Create new table queries
-- --------------------------------------------------------


CREATE TABLE IF NOT EXISTS `accesshistory` (
  AH_UUID			varchar(45) NOT NULL,
  O_UUID			varchar(45) NOT NULL,
  O_v_UUID			varchar(45) NOT NULL,
  type				varchar(45) NOT NULL,
  details			mediumtext NOT NULL,
  session_id		tinytext NOT NULL,
  accessedAt		datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  accessedByP_UUID	varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;








