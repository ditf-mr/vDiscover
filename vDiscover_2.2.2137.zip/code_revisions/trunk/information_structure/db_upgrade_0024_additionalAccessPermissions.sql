SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;


-- Mark O "Administrator" as a system object
UPDATE object
SET isSystemObject = 1
WHERE O_UUID = 'a997b3ed-7c7c-11e0-a3b1-406186f2abca';



-- Mark old RT 'assigned to' to a non system relevant object (to delete it later on.)
UPDATE relationtype
SET isSystemObject = 0
WHERE RT_UUID = '10000000-1000-1000-1000-00a000005e00';

