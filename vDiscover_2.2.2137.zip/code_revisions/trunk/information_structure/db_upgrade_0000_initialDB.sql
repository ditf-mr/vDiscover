SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;


-- --------------------------------------------------------
-- Types
-- --------------------------------------------------------


DROP TABLE IF EXISTS objecttype;
CREATE TABLE IF NOT EXISTS objecttype (
  OT_UUID 						varchar(45)	NOT NULL DEFAULT '',
  super_OT_UUID 				varchar(45)	NOT NULL DEFAULT '',
  name 							tinytext	NOT NULL,
  description 					mediumtext	NOT NULL,
  descriptionPlain				mediumtext	NOT NULL,
  templateName_VT_UUID			varchar(45)	NOT NULL DEFAULT '',
  templateDescription_VT_UUID	varchar(45)	NOT NULL DEFAULT '',
  menuBarOT						mediumtext	NOT NULL COMMENT 'menu bar for object type level',
  menuBarO						mediumtext	NOT NULL COMMENT 'menu bar for object level',
  isSystemObject				tinyint(1)	NOT NULL DEFAULT '0' COMMENT 'indicates a system object',
  changedAt						datetime	NOT NULL DEFAULT '0000-00-00 00:00:00',
  changedByP_UUID				varchar(45)	NOT NULL DEFAULT '',
  PRIMARY KEY	( OT_UUID ),
  KEY			fkSuperConcept ( super_OT_UUID ),
  FULLTEXT		( name )
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS relationtype;
CREATE TABLE IF NOT EXISTS relationtype (

  RT_UUID						varchar(45)			NOT NULL DEFAULT '',
  name							tinytext			NOT NULL,
  description					mediumtext			NOT NULL,
  descriptionPlain				mediumtext			NOT NULL,
  Start_OT_UUID					varchar(45)			NOT NULL DEFAULT '',
  End_OT_UUID					varchar(45)			NOT NULL DEFAULT '',
  cardinality					int(10) unsigned	NOT NULL DEFAULT '1' COMMENT '0 indicates unlimited ',
  isSystemObject				tinyint(1)			NOT NULL DEFAULT '0' COMMENT 'indicates a system object',
  changedAt						datetime			NOT NULL DEFAULT '0000-00-00 00:00:00',
  changedByP_UUID				varchar(45)			NOT NULL DEFAULT '',
  
  PRIMARY KEY	( RT_UUID ),
  KEY			fkStartTypeObject ( Start_OT_UUID ),
  KEY			fkEndTypeObject ( End_OT_UUID ),
  FULLTEXT		( name )
  
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS attribute;
CREATE TABLE IF NOT EXISTS attribute (

  A_UUID				varchar(45)			NOT NULL DEFAULT '',
  ORT_UUID				varchar(45)			NOT NULL DEFAULT '' COMMENT 'either a relation or an object type UUID',
  ORT_kind				char(1)				NOT NULL DEFAULT ' ',
  A_origin_UUID			varchar(45)			NOT NULL DEFAULT '',
  kind					tinytext			NOT NULL,
  name					tinytext			NOT NULL,
  description			mediumtext			NOT NULL,
  descriptionPlain		mediumtext			NOT NULL,
  positionOfAttribute	int(10) unsigned	NOT NULL DEFAULT '1' COMMENT 'Position of the attribute within the set of attributes.',
  cardinality			int(10) unsigned	NOT NULL DEFAULT '0' COMMENT '0 indicates unlimited',
  readOnly				tinyint(1)			NOT NULL DEFAULT '0',
  mustBeSet				tinyint(1)			NOT NULL DEFAULT '0',
  mustBeUnique			tinyint(1)			NOT NULL DEFAULT '0',
  configuration			mediumtext			NOT NULL,
  isSystemObject		tinyint(1)			NOT NULL DEFAULT '0' COMMENT 'indicates a system object',
  changedAt				datetime			NOT NULL DEFAULT '0000-00-00 00:00:00',
  changedByP_UUID		varchar(45)			NOT NULL DEFAULT '' COMMENT 'UUID of the person, who did the last change.',
	
  PRIMARY KEY	( A_UUID ),
  FULLTEXT		( name )
  
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS viewtype;
CREATE TABLE IF NOT EXISTS viewtype (

  VT_UUID				varchar(45)				NOT NULL DEFAULT '' COMMENT 'Primary Key',
  ORT_UUID				varchar(45)				NOT NULL DEFAULT '' COMMENT 'object or relation type UUID',
  ORT_kind				char(1)					NOT NULL DEFAULT ' ',
  kind					tinytext				NOT NULL,
  name					tinytext				NOT NULL,
  description			mediumtext				NOT NULL,
  descriptionPlain		mediumtext				NOT NULL,
  positionOfView		int(10) unsigned		NOT NULL DEFAULT '1' COMMENT 'Position of the view (type) within the set of views (types).',
  configuration			mediumtext				NOT NULL,
  searchPoints			smallint(5) unsigned	NOT NULL DEFAULT '0',
  isSystemObject		tinyint(1)				NOT NULL DEFAULT '0' COMMENT 'indicates a system object',
  changedAt				datetime				NOT NULL DEFAULT '0000-00-00 00:00:00',
  changedByP_UUID		varchar(45)				NOT NULL DEFAULT '' COMMENT 'UUID of the person, who did the last change.',
  
  PRIMARY KEY	( VT_UUID ),
  FULLTEXT		( name )
  
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



-- --------------------------------------------------------
-- Objects, Relations etc.
-- --------------------------------------------------------


DROP TABLE IF EXISTS object;
CREATE TABLE IF NOT EXISTS object (

  O_v_UUID					varchar(45)	NOT NULL DEFAULT '',
  versionType				char(1)		NOT NULL  DEFAULT ' ' COMMENT 'c=current, o=out of use, m=modified (work flow), d=deleted',
  O_UUID					varchar(45)	NOT NULL DEFAULT '',
  OT_UUID					varchar(45)	NOT NULL DEFAULT '',
  name						tinytext	NOT NULL,
  description				mediumtext	NOT NULL,
  descriptionPlain			mediumtext	NOT NULL,
  isSystemObject			tinyint(1)	NOT NULL DEFAULT '0' COMMENT 'indicates a system object',
  changedAt					datetime	NOT NULL DEFAULT '0000-00-00 00:00:00',
  changedByP_UUID			varchar(45)	NOT NULL DEFAULT '',
  
  PRIMARY KEY	( O_v_UUID ),
  KEY			fkObjectToObjectType ( OT_UUID ),
  FULLTEXT		( name )
  
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS relation;
CREATE TABLE IF NOT EXISTS relation (

  R_v_UUID				varchar(45)			NOT NULL DEFAULT '',
  versionType			char(1)				NOT NULL DEFAULT ' ' COMMENT 'c=current, o=out of use, m=modified (work flow), d=deleted',
  R_UUID				varchar(45)			NOT NULL DEFAULT '',
  RT_UUID				varchar(45)			NOT NULL DEFAULT '',
  Start_O_UUID			varchar(45)			NOT NULL DEFAULT '',
  End_O_UUID			varchar(45)			NOT NULL DEFAULT '',
  positionOfRelation	int(10) unsigned	NOT NULL DEFAULT '1' COMMENT 'Position of the relation within the set of relations',
  isSystemObject		tinyint(1)			NOT NULL DEFAULT '0' COMMENT 'indicates a system object',
  changedAt				datetime			NOT NULL DEFAULT '0000-00-00 00:00:00',
  changedByP_UUID		varchar(45)			NOT NULL DEFAULT '',

  PRIMARY KEY	( R_v_UUID ),
  KEY			fkRelationToRelationType ( RT_UUID ),
  KEY			fkStartObject ( Start_O_UUID ),
  KEY			fkEndObject ( End_O_UUID )

  ) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS attributevalue;
CREATE TABLE IF NOT EXISTS attributevalue (

  AV_v_UUID					varchar(45)			NOT NULL DEFAULT '' COMMENT 'key of table',
  versionType				char(1)				NOT NULL DEFAULT ' ' COMMENT 'c=current, o=out of use, m=modified (work flow), d=deleted',
  AV_UUID					varchar(45)			NOT NULL DEFAULT '',
  A_UUID					varchar(45)			NOT NULL DEFAULT '' COMMENT 'FK to attribute.A_UUID',
  OR_v_UUID					varchar(45)			NOT NULL DEFAULT '' COMMENT 'object or relation UUID',
  OR_kind					char(1)				NOT NULL DEFAULT ' ',
  kind						tinytext			NOT NULL,
  positionOfAttribute		int(10) unsigned	NOT NULL DEFAULT '1' COMMENT 'Position of the attribute within the set of attributes. See attribute.positionOfAttribute',
  positionOfValue			int(10) unsigned	NOT NULL DEFAULT '1' COMMENT 'Position of the attribute values within the set of attribute values.',
  value_text				mediumtext			NOT NULL,
  value_textPlain			mediumtext			NOT NULL,
  value_UUID				varchar(45)			NOT NULL DEFAULT '',
  value_fileTitle			tinytext			NOT NULL,
  value_fileName			tinytext			NOT NULL,
  value_fileExtension		tinytext			NOT NULL,
  value_fileStoreFileName	tinytext			NOT NULL,
  value_fileSize			int(10) unsigned	NOT NULL DEFAULT '0',
  value_number				decimal(30,15)		DEFAULT NULL,
  value_binaryData			mediumblob			DEFAULT NULL,
  value_password			tinytext			NOT NULL COMMENT 'md5 encoded',
  value_personFirstName		tinytext			NOT NULL,
  value_personLastName		tinytext			NOT NULL,
  value_personGender		char(1)				NOT NULL DEFAULT ' ',
  value_personTitle			tinytext			NOT NULL COMMENT 'Academical grade or similar',
  value_rangeMin			decimal(30,15)		DEFAULT NULL,
  value_rangeMax			decimal(30,15)		DEFAULT NULL,
  value_listKey				varchar(10)			NOT NULL DEFAULT '',
  value_timepoint			datetime			NOT NULL DEFAULT '0000-00-00 00:00:00',
  value_linkUrl				mediumtext			NOT NULL,
  isSystemObject			tinyint(1)			NOT NULL DEFAULT '0' COMMENT 'indicates a system object',
  changedAt					datetime			NOT NULL DEFAULT '0000-00-00 00:00:00',
  changedByP_UUID			varchar(45)			NOT NULL DEFAULT '' COMMENT 'UUID of the person, who did the last change.',
  
  PRIMARY KEY (AV_v_UUID),
  KEY fkAttribute (A_UUID)
  
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- --------------------------------------------------------
-- Initial Data (System Objects)
-- --------------------------------------------------------

-- Object Types for "Persons" and "Roles"
INSERT INTO `objecttype` (`OT_UUID`, `super_OT_UUID`, `name`, `description`, `descriptionPlain`, `templateName_VT_UUID`, `templateDescription_VT_UUID`, `menuBarOT`, `menuBarO`, `isSystemObject`, `changedAt`, `changedByP_UUID`) VALUES
('10000000-1000-1000-1000-00000000e000', '', 'Persons', '', '', '2a027765-7c7c-11e0-a3b1-406186f2abca', '', 'a:2:{i:0;a:6:{s:4:"UUID";s:36:"6d3e30e4-5c37-11e0-9409-406186f2abca";s:16:"mB_itemKind_UUID";s:32:"OT_menubar_itemKinds.general.all";s:5:"label";s:16:"List all Persons";s:8:"position";i:10;s:4:"type";s:17:"dijit.MenuBarItem";s:13:"openByDefault";b:1;}i:1;a:6:{s:4:"UUID";s:36:"6d3e384c-5c37-11e0-9409-406186f2abca";s:16:"mB_itemKind_UUID";s:38:"OT_menubar_itemKinds.general.newObject";s:5:"label";s:10:"Add Person";s:8:"position";i:20;s:4:"type";s:17:"dijit.MenuBarItem";s:13:"openByDefault";b:0;}}', 'a:2:{i:0;a:5:{s:4:"UUID";s:36:"687b68ea-5c40-11e0-9409-406186f2abca";s:16:"mB_itemKind_UUID";s:34:"O_menubar_itemKinds.general.delete";s:5:"label";s:6:"Delete";s:8:"position";i:10;s:4:"type";s:17:"dijit.MenuBarItem";}i:1;a:6:{s:4:"UUID";s:36:"f760af9c-9b4c-11e0-a6b4-406186f2abca";s:16:"mB_itemKind_UUID";s:37:"O_menubar_itemKinds.general.duplicate";s:5:"label";s:9:"Duplicate";s:8:"position";i:20;s:4:"type";s:17:"dijit.MenuBarItem";s:13:"openByDefault";b:0;}}', 1, '2011-05-12 11:42:42', '10000000-1000-1001-1000-00000000e000'),
('10000000-1000-1000-1000-00000000000e', '', 'Roles', '', '', '5d742bc7-7c7c-11e0-a3b1-406186f2abca', '', 'a:2:{i:0;a:6:{s:4:"UUID";s:36:"745f362a-5c37-11e0-9409-406186f2abca";s:16:"mB_itemKind_UUID";s:32:"OT_menubar_itemKinds.general.all";s:5:"label";s:14:"List all Roles";s:8:"position";i:10;s:4:"type";s:17:"dijit.MenuBarItem";s:13:"openByDefault";b:1;}i:1;a:6:{s:4:"UUID";s:36:"745f3b72-5c37-11e0-9409-406186f2abca";s:16:"mB_itemKind_UUID";s:38:"OT_menubar_itemKinds.general.newObject";s:5:"label";s:8:"Add Role";s:8:"position";i:20;s:4:"type";s:17:"dijit.MenuBarItem";s:13:"openByDefault";b:0;}}', 'a:2:{i:0;a:5:{s:4:"UUID";s:36:"687b68ea-5c40-11e0-9409-406186f2abca";s:16:"mB_itemKind_UUID";s:34:"O_menubar_itemKinds.general.delete";s:5:"label";s:6:"Delete";s:8:"position";i:10;s:4:"type";s:17:"dijit.MenuBarItem";}i:1;a:6:{s:4:"UUID";s:36:"f760af9c-9b4c-11e0-a6b4-406186f2abca";s:16:"mB_itemKind_UUID";s:37:"O_menubar_itemKinds.general.duplicate";s:5:"label";s:9:"Duplicate";s:8:"position";i:20;s:4:"type";s:17:"dijit.MenuBarItem";s:13:"openByDefault";b:0;}}', 1, '2011-05-12 11:44:16', '10000000-1000-1001-1000-00000000e000');


-- Relation Types between "Persons" and "Roles"
INSERT INTO `relationtype` (`RT_UUID`, `name`, `description`, `descriptionPlain`, `Start_OT_UUID`, `End_OT_UUID`, `cardinality`, `isSystemObject`, `changedAt`, `changedByP_UUID`) VALUES
('10000000-1000-1000-1000-0000000ac0a0', 'act as', '', '', '10000000-1000-1000-1000-00000000e000', '10000000-1000-1000-1000-00000000000e', 0, 1, '2011-04-01 07:30:00', '10000000-1000-1001-1000-00000000e000'),
('10000000-1000-1000-1000-00a000005e00', 'assigned to', '', '', '10000000-1000-1000-1000-00000000000e', '10000000-1000-1000-1000-00000000e000', 0, 1, '2011-04-01 07:30:00', '10000000-1000-1001-1000-00000000e000');


-- Attributes of "Persons"
INSERT INTO `attribute` (`A_UUID`, `ORT_UUID`, `ORT_kind`, `A_origin_UUID`, `kind`, `name`, `description`, `descriptionPlain`, `positionOfAttribute`, `cardinality`, `readOnly`, `mustBeSet`, `configuration`, `isSystemObject`, `changedAt`, `changedByP_UUID`) VALUES
('10000000-1000-1000-1001-00000000e000', '10000000-1000-1000-1000-00000000e000', 'O', '', 'cSingleLineAttribute', 'User name', 'The user name of the person.', 'The user name of the person.', 2, 1, 0, 1, 'a:6:{s:17:"svFormatActivated";b:0;s:12:"svHtmlBefore";s:0:"";s:13:"svHtmlBetween";s:0:"";s:11:"svHtmlAfter";s:0:"";s:6:"format";s:0:"";s:9:"maxLength";i:255;}', 1, '2011-04-01 07:30:00', '10000000-1000-1001-1000-00000000e000'),
('10000000-1000-1000-1002-00000000e000', '10000000-1000-1000-1000-00000000e000', 'O', '', 'cPasswordAttribute', 'Password', 'The password of the person.', 'The password of the person.', 3, 1, 0, 1, 'a:1:{s:9:"minLength";i:5;}', 1, '2011-04-01 07:30:00', '10000000-1000-1001-1000-00000000e000'),
('10000000-1000-1000-1003-00000000e000', '10000000-1000-1000-1000-00000000e000', 'O', '', 'cSingleLineAttribute', 'Name', '', '', 1, 1, 0, 1, 'a:6:{s:17:"svFormatActivated";b:0;s:12:"svHtmlBefore";s:0:"";s:13:"svHtmlBetween";s:0:"";s:11:"svHtmlAfter";s:0:"";s:6:"format";s:0:"";s:9:"maxLength";i:255;}', 1, '2011-04-01 07:30:00', '10000000-1000-1001-1000-00000000e000'),
('10000000-1000-1000-1004-00000000e000', '10000000-1000-1000-1000-00000000e000', 'O', '', 'cRelationAttribute', 'Roles', 'The roles the person acts as.', 'The roles the person acts as.', 4, 1, 0, 1, 'a:7:{s:17:"svFormatActivated";b:0;s:12:"svHtmlBefore";s:0:"";s:13:"svHtmlBetween";s:0:"";s:11:"svHtmlAfter";s:0:"";s:16:"selected_RT_UUID";s:36:"10000000-1000-1000-1000-0000000ac0a0";s:8:"showWhat";s:1:"V";s:9:"show_UUID";s:36:"5d742bc7-7c7c-11e0-a3b1-406186f2abca";}', 0, '2011-04-01 07:30:00', '10000000-1000-1001-1000-00000000e000');


-- Attributes of "Roles"
INSERT INTO `attribute` (`A_UUID`, `ORT_UUID`, `ORT_kind`, `A_origin_UUID`, `kind`, `name`, `description`, `descriptionPlain`, `positionOfAttribute`, `cardinality`, `readOnly`, `mustBeSet`, `mustBeUnique`, `configuration`, `isSystemObject`, `changedAt`, `changedByP_UUID`) VALUES
('10000000-1000-1000-1001-00000000000e', '10000000-1000-1000-1000-00000000000e', 'O', '', 'cSingleLineAttribute', 'Name', '', '', 1, 1, 0, 1, 1, 'a:6:{s:17:"svFormatActivated";b:0;s:12:"svHtmlBefore";s:0:"";s:13:"svHtmlBetween";s:0:"";s:11:"svHtmlAfter";s:0:"";s:6:"format";s:0:"";s:9:"maxLength";i:255;}', 1, '2011-04-01 07:30:00', '10000000-1000-1001-1000-00000000e000');


-- View Types of "Persons"
INSERT INTO `viewtype` (`VT_UUID`, `ORT_UUID`, `ORT_kind`, `kind`, `name`, `description`, `descriptionPlain`, `positionOfView`, `configuration`, `searchPoints`, `isSystemObject`, `changedAt`, `changedByP_UUID`) VALUES
('918dbf78-7c7b-11e0-a3b1-406186f2abca', '10000000-1000-1000-1000-00000000e000', 'O', 'cAttributeListViewType', 'Attributes', 'List all system relevant attributes.', 'List all system relevant attributes.', 2, 'a:1:{s:13:"attributeList";a:4:{i:0;s:36:"10000000-1000-1000-1003-00000000e000";i:1;s:36:"10000000-1000-1000-1001-00000000e000";i:2;s:36:"10000000-1000-1000-1002-00000000e000";i:3;s:36:"10000000-1000-1000-1004-00000000e000";}}', 5, 0, '2011-05-12 11:42:32', '10000000-1000-1001-1000-00000000e0000'),
('2a027765-7c7c-11e0-a3b1-406186f2abca', '10000000-1000-1000-1000-00000000e000', 'O', 'cNameViewType', 'Name', 'Display the name of the Person (see attribute ''Name'')', 'Display the name of the Person (see attribute ''Name'')', 1, 'a:1:{s:7:"content";s:39:"${10000000-1000-1000-1003-00000000e000}";}', 5, 0, '2011-05-12 11:42:32', '10000000-1000-1001-1000-00000000e000');


-- View Types of "Roles"
INSERT INTO `viewtype` (`VT_UUID`, `ORT_UUID`, `ORT_kind`, `kind`, `name`, `description`, `descriptionPlain`, `positionOfView`, `configuration`, `searchPoints`, `isSystemObject`, `changedAt`, `changedByP_UUID`) VALUES
('5d742bc7-7c7c-11e0-a3b1-406186f2abca', '10000000-1000-1000-1000-00000000000e', 'O', 'cNameViewType', 'Name', 'Displays the name of the Role (see attribute ''Name'').', 'Displays the name of the Role (see attribute ''Name'').', 1, 'a:1:{s:7:"content";s:39:"${10000000-1000-1000-1001-00000000000e}";}', 5, 0, '2011-05-12 11:43:58', '10000000-1000-1001-1000-00000000e000');


-- Objects of Object Type "Persons"
INSERT INTO `object` (`O_v_UUID`, `versionType`, `O_UUID`, `OT_UUID`, `name`, `description`, `descriptionPlain`, `isSystemObject`, `changedAt`, `changedByP_UUID`) VALUES
('10000001-1000-1001-1000-00000000e000', 'c', '10000000-1000-1001-1000-00000000e000', '10000000-1000-1000-1000-00000000e000', 'Augustus Administrator', '', '', 0, '2011-05-12 11:46:38', '10000000-1000-1001-1000-00000000e000');


-- Objects of Object Type "Roles"
INSERT INTO `object` (`O_v_UUID`, `versionType`, `O_UUID`, `OT_UUID`, `name`, `description`, `descriptionPlain`, `isSystemObject`, `changedAt`, `changedByP_UUID`) VALUES
('a997a1f8-7c7c-11e0-a3b1-406186f2abca', 'c', 'a997b3ed-7c7c-11e0-a3b1-406186f2abca', '10000000-1000-1000-1000-00000000000e', 'Administrator', '', '', 0, '2011-05-12 11:46:18', '10000000-1000-1001-1000-00000000e000');


-- Relations between Object "Persons" and "Roles"
INSERT INTO `relation` (`R_v_UUID`, `versionType`, `R_UUID`, `RT_UUID`, `Start_O_UUID`, `End_O_UUID`, `positionOfRelation`, `isSystemObject`, `changedAt`, `changedByP_UUID`) VALUES
('bc92e2f4-7c7c-11e0-a3b1-406186f2abca', 'c', 'bc92ec87-7c7c-11e0-a3b1-406186f2abca', '10000000-1000-1000-1000-0000000ac0a0', '10000000-1000-1001-1000-00000000e000', 'a997b3ed-7c7c-11e0-a3b1-406186f2abca', 1, 0, '2011-05-12 11:46:38', '10000000-1000-1001-1000-00000000e000');


-- Attribute Values 
INSERT INTO `attributevalue` (`AV_v_UUID`, `versionType`, `AV_UUID`, `A_UUID`, `OR_v_UUID`, `OR_kind`, `kind`, `positionOfAttribute`, `positionOfValue`, `value_text`, `value_textPlain`, `value_UUID`, `value_fileTitle`, `value_fileName`, `value_fileExtension`, `value_fileStoreFileName`, `value_fileSize`, `value_number`, `value_binaryData`, `value_password`, `value_personFirstName`, `value_personLastName`, `value_personGender`, `value_personTitle`, `value_rangeMin`, `value_rangeMax`, `value_listKey`, `value_timepoint`, `value_linkUrl`, `isSystemObject`, `changedAt`, `changedByP_UUID`) VALUES
('7e223aa6-7c7c-11e0-a3b1-406186f2abca', 'c', '7e224564-7c7c-11e0-a3b1-406186f2abca', '10000000-1000-1000-1003-00000000e000', '10000001-1000-1001-1000-00000000e000', 'O', 'cSingleLineAttributeValue', 1, 1, 'Augustus Administrator', 'Augustus Administrator', '', '', '', '', '', 0, NULL, NULL, '', '', '', '', '', NULL, NULL, '', '0000-00-00 00:00:00', '', 0, '2011-05-12 11:45:32', '10000000-1000-1001-1000-00000000e000'),
('9e718d47-7c7c-11e0-a3b1-406186f2abca', 'c', '9e71989a-7c7c-11e0-a3b1-406186f2abca', '10000000-1000-1000-1001-00000000e000', '10000001-1000-1001-1000-00000000e000', 'O', 'cSingleLineAttributeValue', 2, 1, 'Admin', 'Admin', '', '', '', '', '', 0, NULL, NULL, '', '', '', '', '', NULL, NULL, '', '0000-00-00 00:00:00', '', 0, '2011-05-12 11:45:47', '10000000-1000-1001-1000-00000000e000'),
('a349f019-7c7c-11e0-a3b1-406186f2abca', 'c', 'a349fc21-7c7c-11e0-a3b1-406186f2abca', '10000000-1000-1000-1002-00000000e000', '10000001-1000-1001-1000-00000000e000', 'O', 'cPasswordAttributeValue', 3, 1, '', '', '', '', '', '', '', 0, NULL, NULL, '*****', '', '', '', '', NULL, NULL, '', '0000-00-00 00:00:00', '', 0, '2011-05-12 11:45:55', '10000000-1000-1001-1000-00000000e000'),
('b0bdf3d8-7c7c-11e0-a3b1-406186f2abca', 'c', 'b0be0126-7c7c-11e0-a3b1-406186f2abca', '10000000-1000-1000-1001-00000000000e', 'a997a1f8-7c7c-11e0-a3b1-406186f2abca', 'O', 'cSingleLineAttributeValue', 1, 1, 'Administrator', 'Administrator', '', '', '', '', '', 0, NULL, NULL, '', '', '', '', '', NULL, NULL, '', '0000-00-00 00:00:00', '', 0, '2011-05-12 11:46:18', '10000000-1000-1001-1000-00000000e000');


