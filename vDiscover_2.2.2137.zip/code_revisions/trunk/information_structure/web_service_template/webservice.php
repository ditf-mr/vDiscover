<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

define('INTERFACE', 'web_service');

require('../index.php');

$params = explode("/",substr($_SERVER["REQUEST_URI"],strlen(dirname($_SERVER["SCRIPT_NAME"]))));
array_shift($params);
if ( sizeof($params) == 1 ) {
	$wsName = $params[0];
	$params = explode("wsName=",$wsName);
	if ($params[0] != $wsName) 
		$wsName =  $_GET['wsName'];
}

if ( isset($wsName ) ) {
	require(realpath(__DIR__.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'code_revisions'.DIRECTORY_SEPARATOR.$repository_config['code_version'].DIRECTORY_SEPARATOR.'web_service'.DIRECTORY_SEPARATOR.'webservice.php'));
}
else {
	header("Location: ../../");
}


// end if file ---------------------------------------------------------------------------------
?>