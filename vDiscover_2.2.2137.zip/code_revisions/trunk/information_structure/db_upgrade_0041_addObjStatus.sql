SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+01:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `iobj_status_log`
--

CREATE TABLE IF NOT EXISTS `statuslog` (
  `SL_UUID` tinytext NOT NULL,
  `ORT_UUID` tinytext NOT NULL,
  `ORT_kind` varchar(1) NOT NULL,  
  `lastStatus` tinytext NOT NULL,
  `changedToCurrentAt` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `changedByP_UUID` tinytext NOT NULL,
  `comment` mediumtext NOT NULL,
   PRIMARY KEY (`SL_UUID`(36)),
   KEY `ORT_UUID` (`ORT_UUID`(36)),
   KEY `lastStatus` (`lastStatus`(36))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `iobj_status_log`
--

  
ALTER TABLE `object` CHANGE `currentState` `currentStatus` VARCHAR(45) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL