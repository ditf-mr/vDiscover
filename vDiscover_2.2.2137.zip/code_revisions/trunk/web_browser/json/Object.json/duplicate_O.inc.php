<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		if (is_null($object = _getCObjectFromParameter())) {
			throw new instanceNotFoundException(_object_);
		}
		$name = sanitize_string($_POST, 'name', $_GET);
	}
	{ # check access permissions
		if (! $backend->mayWrite_OT($object->OT_UUID())) {
			throw new writeViolationException($object);
		}
	}
	$newObject = $object->duplicate($name);
	{ # answer
		$output = array(
			'O_v_UUID'	=> $newObject->O_v_UUID(),
			'O_UUID'	=> $newObject->O_UUID(),
			'OT_UUID'	=> $newObject->OT_UUID()
		);
		echo json_encode($output);
	}


?>