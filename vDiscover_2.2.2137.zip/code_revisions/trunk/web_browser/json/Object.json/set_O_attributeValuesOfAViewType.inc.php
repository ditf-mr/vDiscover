<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		if (is_null($object = _getCObjectFromParameter())) {
			throw new instanceNotFoundException(_object_);
		}
		$VT_UUID = sanitize_string($_POST, 'VT_UUID', $_GET); 
		$attributeValues = json_decode(sanitize_string($_POST, 'attributeValues', $_GET), true);
		if (json_last_error() != JSON_ERROR_NONE) {
			throw new incorrectInputDataException('"attributeValues" caused json-syntax-error.');
		}
		if (is_null($viewType = $backend->getViewType($VT_UUID))) {
			throw new instanceNotFoundException(viewType, $VT_UUID);
		}
	}
	{ # check access permissions
		if (! $backend->mayWrite_OT($object->OT_UUID())) {
			throw new writeViolationException($object);
		}
	}
	{ # save current object name to check, if it will be modified by changing 
	  # some attribute values.
		$O_oldName = $object->name(); 
	}
	
	$done = $object->setAttributeValuesOfAViewType($viewType->VT_UUID(), $attributeValues);
	
	{ # check if the name has been changed
		$nameIsModified = ($O_oldName != $object->name());
	}
	{ # answer
		$output = array(
			'O_UUID'			=> $object->O_UUID(),
			'O_v_UUID'			=> $object->O_v_UUID(),
			'O_nameIsModified'	=> &$nameIsModified, 
			'name'				=> $object->name()
			 );
		echo json_encode($output);
	}


?>