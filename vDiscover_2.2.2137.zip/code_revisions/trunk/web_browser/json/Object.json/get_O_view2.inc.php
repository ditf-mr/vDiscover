<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		if (is_null($object = _getCObjectFromParameter())) {
			throw new instanceNotFoundException(_object_);
		} else $aryObject = $object->toArray();
		$VT_UUID = sanitize_string($_POST, 'VT_UUID', $_GET);
		if (is_null($viewType = $backend->getViewType($VT_UUID))) {
			throw new instanceNotFoundException(viewType, $VT_UUID);
		}
	}
	{ # check access permissions
		if (! $aryObject["readPermission"]) {
			throw new readViolationException($object);
		}
	}
	{ # save access history
		cAccessHistory::addView($object, $viewType);
	}
	{ # answer
		$output = __get_O_view2_generateView(
			$object->O_v_UUID(), 
			$viewType->VT_UUID(), 
			$maxNumberOfFunctionCalls
		);
		echo json_encode($output);
	}

?>