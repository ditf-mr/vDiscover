<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		if (is_null($object = _getCObjectFromParameter())) {
			throw new instanceNotFoundException(_object_);
		}
		$newStatus = sanitize_string($_POST, 'selectTargetStatus');
		$strComment =  sanitize_string($_POST, 'commentTargetStatus');
		
	}
	{ # check access permissions
		if (! $backend->mayWrite_OT($object->OT_UUID())) {
			throw new writeViolationException($object);
		}
	}
	// $object->archive();
	

	
	$object->setCurrentStatus($newStatus, $strComment);
	$return  = $object->update();
	
	{ # answer
		$output = $object->toArray();
		echo json_encode($output);
	}

?>