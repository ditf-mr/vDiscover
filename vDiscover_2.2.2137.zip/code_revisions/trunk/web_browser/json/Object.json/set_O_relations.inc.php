<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		if (is_null($object = _getCObjectFromParameter())) {
			throw new instanceNotFoundException(_object_);
		}
		$RT_UUID = sanitize_string($_POST, 'RT_UUID', $_GET);
		$relations = json_decode(sanitize_string($_POST, 'relations', $_GET), true);
		if (json_last_error() != JSON_ERROR_NONE) {
			throw new incorrectInputDataException('"relations" caused json-syntax-error.');
		}
		$relations = $relations['items'];	
	}
	{ # check access permissions
		if (! $backend->mayWrite_OT($object->OT_UUID())) {
			throw new writeViolationException($object);
		}
	}
	$previousName = $object->name(); # to check, if name will be changed
	$done = $object->setRelations_asStart($RT_UUID, $relations, false);
	{ # check if the name has been changed
		$nameIsModified = ($previousName != $object->name());
	}
	{ # answer
		$output = array(
			'O_nameIsModified'	=> $nameIsModified, 
			'name'				=> $object->name()
		);
		echo json_encode($output);
	}


?>