<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		if (is_null($object = _getCObjectFromParameter())) {
			throw new instanceNotFoundException(_object_);
		}
	}
	{ # check access permissions
		if (! $backend->mayRead_OT($object->OT_UUID())) {
			throw new readViolationException($object);
		}

		
	}
	{ # get attributes of object
		$attributes = $object->getAttributes();
		$objectAttributes = array();
		foreach($attributes as $attribute) {
			$objectAttributes[] = $attribute->toArray();
		}			
	}
	{ # get viewTypes of object
		$viewTypes = $object->getViewTypes();
		$objectViewTypes = array();
		foreach($viewTypes as $viewType) {
			$objectViewTypes[] = $viewType->toArray();
		}			
	}
	$objectType = $object->OT();
	{ # get attributes of objectType
		$attributes = $object->getAttributes();
		$objectTypeAttributes = array();
		foreach($attributes as $attribute) {
			$objectTypeAttributes[] = $attribute->toArray();
		}			
	}
	{ # get viewTypes of objectType
		$viewTypes = $object->getViewTypes();
		$objectTypeViewTypes = array();
		foreach($viewTypes as $viewType) {
			$objectTypeViewTypes[] = $viewType->toArray();
		}			
	}
	{ # answer
		$object2 = $object->toArray();
		$object2['attributes'] = $objectAttributes;
		$object2['viewTypes'] = $objectViewTypes;
		$object2['availablePermissions'] = $object->availablePermissions($object->O_UUID());
		$object2['currentStatusPossibleTransitions'] = $object->currentStatusPossibleTransitions();
		$objectType2 = $objectType->toArray();
		$objectType2['attributes'] = $objectTypeAttributes;
		$objectType2['viewTypes'] = $objectTypeViewTypes;
		$objectType2['availablePermissions'] = $objectType->availablePermissions($object->OT_UUID());

		$output = array(
				'object'     => $object2,
				'objectType' => $objectType2
		);
		echo json_encode($output);
	}

	
?>