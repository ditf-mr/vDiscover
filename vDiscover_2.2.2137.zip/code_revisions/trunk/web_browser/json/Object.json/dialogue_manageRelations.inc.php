<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		if (is_null($object = _getCObjectFromParameter())) {
			throw new instanceNotFoundException(_object_);
		}
		$RT_UUID = sanitize_string($_POST, 'RT_UUID', $_GET); 
		if (is_null($relationType = $backend->getRelationType($RT_UUID))) {
			throw new instanceNotFoundException(relationType, $RT_UUID);
		}
	}
	{ # check access permissions
		if (! $backend->mayRead_OT($object->OT_UUID())) {
			throw new readViolationException($object);
		}
	}
	{ # get name of end object type of relation type
		$endObjectType = $relationType->End_OT();
		$relationType2 = $relationType->toArray();
		$relationType2['End_OT_name'] = $endObjectType->name();
	}
	{ # get relations and name of end object of relation
		$relations = $object->getRelations_asStart($relationType->RT_UUID());
		$relations2 = array();
		foreach($relations as $relation) {
			$endObject = $relation->End_O();
			$relation2 = $relation->toArray();
			$relation2['End_O_name'] = $endObject->name();
			$relations2[] = $relation2;
		}
	}
	{ # answer	
		$output =  array ( 	
			'relationType'	=> $relationType2,
			'relations' 	=> array( 	
				'identifier'=> 'UUID',
				'label'		=> 'UUID',
				'items'		=> $relations2
			)
		);
		$output['O_name'] = $object->name();
		echo json_encode($output);
	}

?>