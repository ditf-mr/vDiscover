<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		$Q_UUID = sanitize_string($_POST, 'Q_UUID', $_GET);	
	}
	if (is_null($query = $backend->getQuery($Q_UUID))) {
		throw new instanceNotFoundException('query', $Q_UUID);
	}
	{ # answer
		$output = $query->toArray();
		echo json_encode($output);
	}

						
?>