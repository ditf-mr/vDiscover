<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		$OT_UUID = sanitize_string($_POST, 'OT_UUID', $_GET);	
		if ( empty($OT_UUID)) {
			$OT_UUID = sanitize_string($_POST, 'UUID', $_GET);
		}
	}
	if (is_null($objectType = $backend->getObjectType($OT_UUID))) {
		throw new instanceNotFoundException(objectType, $OT_UUID);
	}
	{ # check access permissions
		if (! $backend->mayRead_OT($objectType->OT_UUID())) {
			throw new readViolationException($objectType);
		}
	}
	$viewTypes = $objectType->getViewTypes();
	$viewTypes2 = array();
	foreach($viewTypes as $viewType) {
		$viewType2 = $viewType->toArray();
		{ # workaround due to the fact that the frontend in javascript needs (gets and sends) the 
		  # slot 'attributeList' seperatly json encoded. (see also 'set_OT_viewTypes.inc.php')
			$viewType2['attributeList'] = json_encode($viewType2['attributeList']);
		}
		{ # add the information whether this view is default template for name or description
			$viewType2['isTemplateName'] = ($viewType->VT_UUID() == $objectType->templateName_VT_UUID());
			$viewType2['templateNameInherited'] = false; # default, will be overwritten below in inherited part
			$viewType2['isTemplateDescription'] = ($viewType->VT_UUID() == $objectType->templateDescription_VT_UUID());
			$viewType2['templateDescriptionInherited'] = false; # default, will be overwritten below in inherited part
		}
		{ # add the information whether this view is allowed to be a template for name or 
		  # description.
			$viewType2['mayBeUsedAsNameTemplate'] = (($class = get_class($viewType)) and ($class::mayBeUsedAsNameTemplate));
			$viewType2['mayBeUsedAsDescriptionTemplate'] = (($class = get_class($viewType)) and ($class::mayBeUsedAsDescriptionTemplate));
		}
		{ # add some information if the view type is inherited
			if ($viewType->isInherited()) {
				{ # is view an inherited one
					$viewType2['isInherited'] = true;
				}
				{ # name/UUID of super object type, where the view type was defined originally
					$origin_VT = $viewType->VT_origin();
					$viewType2['viewDefinedAt'] = $origin_VT->ORT()->name();
				}
				{ # list of names/UUIDs of super object types that have the same view
					$OTList = array();
					$super_OT = $viewType->ORT()->super_OT();
					while(!is_null($super_OT)) {
						$OTList[] = $super_OT->name();
						$super_OT = $super_OT->super_OT();
					}
					$viewType2['inheritanceChain'] = json_encode(array_reverse($OTList));
				}
				{ # get view of parent
					$origin_VT = $viewType->VT_origin();
					$super_OT = $viewType->ORT()->super_OT();
					$super_VT = cViewType::getBy_VT_origin_UUID($origin_VT->VT_UUID(), $super_OT->OT_UUID());
				}
				{ # descriptionOfParentView
					$viewType2['descriptionOfParentView'] = $super_VT->description();
				}
				{ # add information whether this view is template name or description (if so) due
				  # to the fact, that the object type has inherited this from super object type
					$super_name_VT = $super_OT->templateName_VT();
					if (!is_null($super_name_VT)) {
						// $parentTemplateName = array(
							// 'VT_UUID' => cViewType::getBy_VT_origin_UUID($super_name_VT->VT_origin()->VT_UUID(), $objectType->OT_UUID(), false),
							// 'name' => $super_name_VT->name()
						// );
						$templateNameInherited = 
							((!is_null($current_VT = $objectType->templateName_VT()))
							and ($current_VT->VT_origin()->VT_UUID() == $super_name_VT->VT_origin()->VT_UUID()));
						$viewType2['templateNameInherited'] = $templateNameInherited;
					}
					$super_description_VT = $super_OT->templateDescription_VT();
					if (!is_null($super_description_VT)) {
						// $parentTemplateDescription = array(
							// 'VT_UUID' => cViewType::getBy_VT_origin_UUID($super_description_VT->VT_origin()->VT_UUID(), $objectType->OT_UUID(), false),
							// 'name' => $super_description_VT->name()
						// );
						$templateDescriptionInherited = 
							((!is_null($current_VT = $objectType->templateDescription_VT()))
							and ($current_VT->VT_origin()->VT_UUID() == $super_description_VT->VT_origin()->VT_UUID()));
						$viewType2['templateDescriptionInherited'] = $templateDescriptionInherited;
					}
				}
				{ # kind specific things
					switch ($viewType->kind()) {
						case 'cHTMLFormViewType': 
							{ # for cHTMLFormViewType add some information
								{ # similar to 'contentWithVariables' the same of the parent view type.
									$viewType2['parentContentWithVariables'] = $super_VT->contentWithVariables();
								}
								break;
							}
						case 'cAttributeListViewType':
							{ # for cAttributeListViewType add some information
								{ # similar to 'attributeList' the same of the parent view type.
								  # This list must contain all attributes of the list at the parent, but 
								  # with the corresponding UUIDs of the attributes here.
									$super_attributeList = $super_VT->attributeList();
									$referenceAttributeList = array();
									foreach($super_attributeList as $A_UUID) {
										{ # get relevant attribute. This may be inherited, so it depends on the cObjectType.
											{ # get origin of the attribute first
												$thisAttribute = $backend->getAttribute($A_UUID);
												$origin_A_UUID = $thisAttribute->A_origin()->A_UUID();
											}
											if (is_null($reference_A_UUID = cAttribute::getBy_A_origin_UUID($origin_A_UUID, $OT_UUID, false))) {
												throw new Exception('Inherited Attribute of UUID = "'.$origin_A_UUID.'" not found.');
											}
										}
										$referenceAttributeList[] = $reference_A_UUID;
									}
									$viewType2['parentAttributeList'] = json_encode($referenceAttributeList);
								}
								break;
							}
					} # end-of-switch
				}
			}
			else {
				$viewType2['isInherited'] = false;
			}
		}
		$viewTypes2[] = $viewType2;
	}
	{ # get template views of parent object type
		$parentTemplateName 		= '';
		$parentTemplateDescription 	= '';
		
		// is there a super/ parent type?
		if (!is_null($parentObjectType = $objectType->super_OT())) {
		
			// is there a template for the name at the parent?
			if (! is_null($parentTemplateName_OT = $parentObjectType->templateName_VT())){
				$parentTemplateName = array(
					'VT_UUID'	=> $parentTemplateName_OT->VT_UUID(),
					'name'		=> $parentTemplateName_OT->name()
				);
			} // end if
			
			// is there a template for the description at the parent?
			if (! is_null($parentTemplateDescription_OT = $parentObjectType->templateDescription_VT())){
				$parentTemplateDescription = array(
					'VT_UUID'	=> $parentTemplateDescription_OT->VT_UUID(),
					'name'		=> $parentTemplateDescription_OT->name()
				);
			} // end if
		} // end if
	}
	
	{ # answer
		/*$output = array(
			'viewTypes' => array( 
				'identifier'	=> 'UUID',
				'label'			=> 'UUID',
				'items'			=> $viewTypes2
			),
			'parentTemplateName' 		=> $parentTemplateName,
			'parentTemplateDescription'	=> $parentTemplateDescription,
			
			// 'attrListForStore'	=> array( 
				// 'identifier'	=> 'UUID',
				// 'label'			=> 'name',
				// 'items'			=> $viewTypes2
			// ),
		);*/
		echo '{'
			.'"viewTypes":{"identifier":"UUID","label":"UUID","items":'.json_encode($viewTypes2).'},'
			.'"parentTemplateName":'.json_encode($parentTemplateName).','
			.'"parentTemplateDescription":'.json_encode($parentTemplateDescription).','
			.'"attrListForStore":';
				include(/*ObjectType.json/*/'get_OT_attributes.inc.php');
		echo '}';
	}
	

?>