<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

$GLOBALS['logHandler']->clearDebug();
$GLOBALS['logHandler']->debug(__FILE__);
	{ # get parameter
		$FL_UUID = sanitize_string($_POST, 'FL_UUID', $_GET);	
	}
	if (is_null($findList = $backend->getFindList($FL_UUID))) {
		throw new instanceNotFoundException('findList', $FL_UUID);
	}
	$findList2['FL_UUID'] = $findList->FL_UUID();
	// $findList2['name'] = $findList->name();
	// $findList2['usage'] = ($findList->isPrivate()?'justMe':'everybody');
	$findList2['queryParameters'] = $findList->configuration();
	$findList2['changedAt'] = $findList->changedAt();
	{ # add name of person, that carried out the last changes
		if (! is_null($changedByP = $backend->getCurrentObject($findList->changedByP_UUID()))) {
			$av_name = $changedByP->getAttributeValues(cSystem::$sysObject_Persons_A_Name_UUID);			
			$findList2['changedByP_name'] = current($av_name)->value();
			$findList2['changedByP_O_v_UUID'] = $changedByP->O_v_UUID();
		}
		else {
			$findList2['changedByP_name'] = '???';
		}
	}
$GLOBALS['logHandler']->debug('$findList2', $findList2);
	{ # answer
		echo json_encode($findList2);
	}
?>