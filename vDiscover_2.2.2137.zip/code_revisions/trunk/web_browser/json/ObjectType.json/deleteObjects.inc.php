<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		$OT_UUID = sanitize_string($_POST, 'OT_UUID', $_GET);	
		if ( empty($OT_UUID)) {
			$OT_UUID = sanitize_string($_POST, 'UUID', $_GET);
		}
		$deleteAll = (sanitize_string($_POST, 'deleteWhat', $_GET) == 'allObjects');
		if (! $deleteAll) {
			$delete_O_v_UUIDs = json_decode(sanitize_string($_POST, 'delete_O_v_UUIDs', $_GET));
			if (json_last_error() != JSON_ERROR_NONE) {
				throw new incorrectInputDataException('"delete_O_v_UUIDs" caused json-syntax-error.');
			}
		}
	}
	if (is_null($objectType = $backend->getObjectType($OT_UUID))) {
		throw new instanceNotFoundException(objectType, $OT_UUID);
	}
	{ # check access permissions
		if (! $backend->mayWrite_OT($objectType->OT_UUID())) {
			throw new writeViolationException($objectType);
		}
	}

	$numberOfObjectsDeleted = 0;
	
	{ # perform deletion
		if ($deleteAll) {
			$numberOfObjectsDeleted = $objectType->mDeleteObjects(true);
		}
		else {
			foreach($delete_O_v_UUIDs as $O_v_UUID) {
				if (! is_null($object = $backend->getObject($O_v_UUID))) {
					$object->mDelete();
					$numberOfObjectsDeleted++;
				}
			}
		}
	}
	
	
	{ # answer
		$output = array(
			'done' 						=> true,
			'numberOfObjectsDeleted'	=> $numberOfObjectsDeleted
		);
		echo json_encode($output);
	}

						
?>