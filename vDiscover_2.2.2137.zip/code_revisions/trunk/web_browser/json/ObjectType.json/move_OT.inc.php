<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameters
	
		// the OT_UUID of the object type to be moved
		$OT_UUID = sanitize_string($_POST, 'move_OT_UUID', $_GET);	
		
		// the OT_UUID of the new parent object type
		$OT_UUID = sanitize_string($_POST, 'new_parent_OT_UUID', $_GET);	
	}
	
	{ ### GUIDO ###
	
	}

	{ # answer
		$output = array(
			'ok' => 'ok'
		);
		echo json_encode($output);
	}

						
?>