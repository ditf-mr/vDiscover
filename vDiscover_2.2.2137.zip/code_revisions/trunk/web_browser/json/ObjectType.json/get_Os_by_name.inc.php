<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		$OT_UUID = sanitize_string($_POST, 'OT_UUID', $_GET);	
		if ( empty($OT_UUID)) {
			$OT_UUID = sanitize_string($_POST, 'UUID', $_GET);
		}
		$pattern = sanitize_string($_POST, 'pattern', $_GET);	
		// $pattern = sanitize_string($_POST, 'namePattern', $_GET);	
		
		$recursionLevels = -1;
		$recursionLevels = sanitize_integer($_POST, 'recursionLevels', $_GET);	
		
	}
	if (is_null($objectType = $backend->getObjectType($OT_UUID))) {
		throw new instanceNotFoundException(objectType, $OT_UUID);
	}
	{ # check access permissions
		if (! $backend->mayRead_OT($objectType->OT_UUID())) {
			throw new readViolationException($objectType);
		}
	}
	$objects = $objectType->getObjectsBy_name($pattern, null, $recursionLevels);
	$objects2 = array();
	foreach($objects as $object) {
		$objects2[] = $object->toArray();
	}
	{ # answer
		$output = array( 
			'identifier'	=> 'UUID',
			'label'			=> 'UUID',
			'items'			=> $objects2
		);
		echo json_encode($output);
	}

						
?>