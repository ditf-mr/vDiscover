<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		$OT_UUID = sanitize_string($_POST, 'OT_UUID', $_GET);	
		if ( empty($OT_UUID))
			$OT_UUID = sanitize_string($_POST, 'UUID', $_GET);
	}
	if (is_null($objectType = $backend->getObjectType($OT_UUID))) {
		throw new instanceNotFoundException(objectType, $OT_UUID);
	}
	{ # check access permissions
		if (! $backend->mayRead_OT($objectType->OT_UUID())) {
			throw new readViolationException($objectType);
		}
	}
	$relationTypes2 = array();
	{ # collect those relation types, where the object type is start 
		$relationTypes = $objectType->getRelationTypes_asStart();
		foreach($relationTypes as $RT_UUID=>$relationType) {
			$relationType2 = $relationType->toArray();
			{ # get name of end object type and add label
				$endObjectType = $relationType->End_OT();
				$relationType2['label'] = $relationType->name() 
										  . ' (→ ' .$endObjectType->name() . ')'
										  . ($relationType->reflexive()?' [R>]':'');
			}
			$relationTypes2[$RT_UUID] = $relationType2;
		}
	}
	{ # collect those inverse relation type, where the object type is end
		$relationTypes = $objectType->getRelationTypes_asEnd();
		foreach($relationTypes as $RT_UUID=>$relationType) {
			if (! in_array($RT_UUID, $relationTypes2)) {
				$relationType2 = $relationType->toArray();
				if ($relationType->reflexive()) {
					$relationType2['UUID'] .= '*';
				}
				{ # get name of end (start of inverse)  object type and add label
					$endObjectType = $relationType->Start_OT();
					$relationType2['label'] = $relationType->nameOfInverse() . ' (→ ' .$endObjectType->name() . ')';
					$relationType2['label'] = $relationType->nameOfInverse() 
											  . ' (→ ' .$endObjectType->name() . ')'
											  . ($relationType->reflexive()?' [<R]':'');
				}
				$relationTypes2[$RT_UUID.'*'] = $relationType2;
			}
		}
	}
	{ # answer
		$output = array( 
			'identifier'	=> 'UUID',
			'label'			=> 'UUID',
			'items'			=> array_values($relationTypes2)
		);
		echo json_encode($output);
	}

						
?>