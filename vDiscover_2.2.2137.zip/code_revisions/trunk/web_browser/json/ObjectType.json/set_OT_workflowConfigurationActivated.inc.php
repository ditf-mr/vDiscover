<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		$OT_UUID = sanitize_string($_POST, 'OT_UUID', $_GET);	
		if ( empty($OT_UUID)) {
			$OT_UUID = sanitize_string($_POST, 'UUID', $_GET);
		}
		if (array_key_exists('workflowConfigurationActivated', $_REQUEST))
			$workflowConfigurationActivated = ($_REQUEST['workflowConfigurationActivated']);
		else $workflowConfigurationActivated = false;
	}
	if (is_null($objectType = $backend->getObjectType($OT_UUID))) {
		throw new instanceNotFoundException(objectType, $OT_UUID);
	}
	{ # check access permissions
		if (! $backend->isAdmin()) {
			throw new accessViolationException('You are not allowed to edit an object type.');
		}
	}
	
	if (is_string($workflowConfigurationActivated) && $workflowConfigurationActivated == 'true'){
		$workflowConfigurationActivated = true;
	} else $workflowConfigurationActivated = false;
		
	
	$objectType->setWorkflowConfigurationActivated($workflowConfigurationActivated, true);
	$objectType->update();
	{ # answer
		$output = array(
			'workflowConfigurationActivated' => $objectType->workflowConfigurationActivated()
		);
		echo json_encode($output);
	}
?>