<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	$paramName_name 			= 'name';
	$paramName_description 		= 'description';
	$paramName_lastChangeAtBy 	= 'lastChangeAtBy';

	
	{ # get parameter
		$OT_UUID = sanitize_string($_POST, 'OT_UUID', $_GET);	
		if ( empty($OT_UUID)) {
			$OT_UUID = sanitize_string($_POST, 'UUID', $_GET);
		}
		$colHeaders = json_decode(sanitize_string($_POST, 'colHeaders', $_GET));
		$searchTerm = sanitize_string($_POST, 'searchTerm', $_GET);
		if (empty($searchTerm)) {
			$searchTerm = '*';
		}
		$CSV_separatorChar = sanitize_string($_POST, 'CSV_separatorChar', $_GET);
		if (empty($CSV_separatorChar)) {
			$CSV_separatorChar = ';';
		}
		$CSV_decimalChar = sanitize_string($_POST, 'CSV_decimalChar', $_GET);
		if (empty($CSV_decimalChar)) {
			$CSV_decimalChar = '.';
		}
		$includeColHeadings = sanitize_boolean($_POST, 'includeColHeadings', $_GET);
		$exportAll = (sanitize_string($_POST, 'exportWhat', $_GET) == 'allObjects');
		if (! $exportAll) {
			$export_O_v_UUIDs = json_decode(sanitize_string($_POST, 'export_O_v_UUIDs', $_GET));
			if (json_last_error() != JSON_ERROR_NONE) {
				throw new incorrectInputDataException('"export_O_v_UUIDs" caused json-syntax-error.');
			}
		}
		$export_fileMIMEType = sanitize_string($_POST, 'export_fileMIMEType', $_GET);
	}
	if (is_null($objectType = $backend->getObjectType($OT_UUID))) {
		throw new instanceNotFoundException(objectType, $OT_UUID);
	}
	{ # check export format
		switch($export_fileMIMEType) {
			case 'application/csv':
				$exportFormat = 'csv';
				break;
			// case 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
				// $exportFormat = 'excel';
				// break;
			default:
				throw new incorrectInputDataException('Export file mimetype "'.$export_fileMIMEType.'" is not supported.');
		}
	}
	{ # check access permissions
		if (! $backend->mayRead_OT($objectType->OT_UUID())) {
			throw new readViolationException($objectType);
		}
	}
	{ # analyse colHeaders
		# general colHeaders
		$with_name 				= in_array($paramName_name, 			$colHeaders);
		$with_description 		= in_array($paramName_description, 		$colHeaders);
		$with_lastChangeAtBy 	= in_array($paramName_lastChangeAtBy, 	$colHeaders);
		
		# attributes as colHeaders
		$A_UUIDs = array();
		$attributes = $objectType->getAttributes();
		$k='';
		reset($colHeaders);
		while (list($k,$colHeader)=each($colHeaders)) {
			if (isset($attributes[$colHeader])) {
				$A_UUIDs[] = $colHeader;
			}
		}
	}	
	{ # get the desired objects
		$objects = array();
		if ($exportAll) {
			$searchResults = $objectType->retrieveObjectsBy_nameOrDescription($searchTerm, 'name asc');
			foreach($searchResults as $searchResult) {
				$objects[] = $searchResult['object']; 
			}
		}
		else {
			foreach($export_O_v_UUIDs as $O_v_UUID) {
				if (! is_null($object = $backend->getObject($O_v_UUID))) {
					$objects[] = $object;
				}
			}
		} # end-of-if
	}
	{ # open file
		switch($export_fileMIMEType) {
			case 'application/csv':
				$fileName = 'rs_export_'.date("Y-m-d_H-i-s").'.csv';
				$fileHandle = fopen($repository_config['path_temp'].DIRECTORY_SEPARATOR.$fileName, 'w');
				break;
			default:
				throw new incorrectInputDataException('Export file mime type "'.$export_fileMIMEType.'" is not supported.');
		}
	}
	{ # add column headers
		if ($includeColHeadings) {
			$colHeadings = array();
			# O_UUID
			$colHeadings[] = 'O_UUID';
			if ($with_name) {
				$colHeadings[] = 'Name';
			}
			if ($with_description) {
				$colHeadings[] = 'Description';
			}
			if ($with_lastChangeAtBy) {
				$colHeadings[] = 'Changed at';
				$colHeadings[] = 'Changed by';
			}
			foreach($A_UUIDs as $A_UUID) {
				$attribute = $backend->getAttribute($A_UUID);
				$colHeadings = array_merge($colHeadings, $attribute->columnHeadingsForExportInColumns());
			}
			{ # export the column headings
				switch($export_fileMIMEType) {
					case 'application/csv':
						fputcsv($fileHandle, $colHeadings, $CSV_separatorChar);
						break;
					default:
						throw new incorrectInputDataException('Export file mimetpye "'.$export_fileMIMEType.'" is not supported.');
				}
			}
		}
	}
	{ # 'objects' may contain objects of different object types. The list 'A_UUIDs' contain 
	  # the UUIDs of the attributes, how they are specified in OT specified by 'OT_UUID'. During
	  # the collection of attribute values (see below) the A_UUIDs of the corresponding attributes
	  # of the specific object types are needed. The will be collected in the list 
	  # 'referenceList_A_UUID', that will be build up during the retrieval process.
	  # The structure of the list is [ OT_UUID => listOf_A_UUIDs_ofThisObjectType, ... ]
		$referenceList_A_UUID = array(
			$OT_UUID => $A_UUIDs
		);
	}
	{ # add objects
		$numberOfObjectsExported = 0;	
		foreach($objects as $object) {
			set_time_limit(20);
			$numberOfObjectsExported++;
			$object2 = array();
			$object2['O_UUID'] = $object->O_UUID();
			if ($with_name) {
				$object2['name'] = $object->name();
			}
			if ($with_description) {
				$object2['description'] = $object->description();
				#$object2['descriptionPlain'] = $object->descriptionPlain();
			}
			if ($with_lastChangeAtBy) {
				{ # add name of person, that carried out the last changes
					$object2['changedAt'] = $object->changedAt();
					if (! is_null($changedByP = $backend->getCurrentObject($object->changedByP_UUID()))) {
						$av_name = $changedByP->getAttributeValues(cSystem::$sysObject_Persons_A_Name_UUID);			
						$object2['changedByP_name'] = current($av_name)->value();
					}
					else {
						$object2['changedByP_name'] = '???';
					}
				}
			}
			{ # collect all A_UUIDs of the attributes of this object if not available
				if (! isset($referenceList_A_UUID[$object->OT_UUID()])) {
					$A_UUIDs2 = array();
					foreach($A_UUIDs as $A_UUID) {
						$attribute = $backend->getAttribute($A_UUID);
						$thisAttribute = cAttribute::getBy_A_origin_UUID($attribute->A_origin()->A_UUID(), $object->OT_UUID());
						$A_UUIDs2[] = $thisAttribute->A_UUID();
					}
					$referenceList_A_UUID[$object->OT_UUID()] = $A_UUIDs2;
				}
			}
			{ # call getAttributeValues for each attribute of this object
				$oldDecimalSeparator = cSystem::decimalSeparator();
				$oldThousandsSeparator = cSystem::thousandsSeparator();
				cSystem::setDecimalSeparator($CSV_decimalChar);
				cSystem::setThousandsSeparator('');
				foreach($referenceList_A_UUID[$object->OT_UUID()] as $A_UUID) {
					$attribute = $backend->getAttribute($A_UUID);
					$attributeValues = $object->getAttributeValues($A_UUID);
					if (count($attributeValues) == 0) {
						$attributeValueForExportInColumns = $attribute->emptyValueForExportInColumns();
					}
					elseif  ($attribute->cardinality() == 1) {
						$attributeValue = current($attributeValues);
						$attributeValueForExportInColumns = $attributeValue->valueForExportInColumns(
							array(
								'decimalSeparator' => $CSV_decimalChar
							)
						);
					}
					else {
						$attributeValues2 = array();
						foreach($attributeValues as $attributeValue) {
							$attributeValues2[] = $attributeValue->valueAsText();
						}
						$attributeValueForExportInColumns = array('['. implode('|', $attributeValues2). ']');
					} # end-of-if
					foreach($attributeValueForExportInColumns as $key=>$item) {
						$object2[$A_UUID.'-'.$key] = $item;
					}
				}
				cSystem::setDecimalSeparator($oldDecimalSeparator);
				cSystem::setThousandsSeparator($oldThousandsSeparator);
			}
			{ # export the object
				switch($export_fileMIMEType) {
					case 'application/csv':
						fputcsv($fileHandle, $object2, $CSV_separatorChar, '"');
						break;
					default:
						throw new incorrectInputDataException('Export file mimetpye "'.$export_fileMIMEType.'" is not supported.');
				}
			}
		} # end-of-foreach
	}
	{ # close file
		switch($export_fileMIMEType) {
			case 'application/csv':
				fclose($fileHandle);
				$fileSize = filesize($repository_config['path_temp'].DIRECTORY_SEPARATOR.$fileName);
				break;
			default:
				throw new incorrectInputDataException('Export file mimetpye "'.$export_fileMIMEType.'" is not supported.');
		}
	}
	
	{ # answer
		$output = array(
			'done' 						=> true,
			'fileAccessCode'			=> $fileName,
			'numberOfObjectsExported'	=> $numberOfObjectsExported,
			'fileSize'					=> $fileSize
		);
		echo json_encode($output);
	}

						
?>