<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		$RT_UUID = sanitize_string($_POST, 'RT_UUID', $_GET);	
		if (empty($RT_UUID)) {
			$RT_UUID = sanitize_string($_POST, 'UUID', $_GET);
		}
		$RT_UUID = str_replace('*', '', $RT_UUID);
		$OT_UUID = sanitize_string($_POST, 'OT_UUID', $_GET);	
	}
	if (is_null($relationType = $backend->getRelationType($RT_UUID))) {
		throw new instanceNotFoundException(relationType, $RT_UUID);
	}
	if (is_null($objectType = $backend->getObjectType($OT_UUID))) {
		throw new instanceNotFoundException(objectType, $OT_UUID);
	}
	$viewTypes2 = array();
	if ($relationType->Start_OT()->getRootObjectType()->OT_UUID() == $objectType->getRootObjectType()->OT_UUID()) {
		$endObjectType = $relationType->End_OT();
	}
	else { # use inverse direction
		$endObjectType = $relationType->Start_OT();
	}

	{ # check access permissions
		if (! $backend->mayRead_OT($endObjectType->OT_UUID())) {
			throw new readViolationException($endObjectType);
		}
	}
	if ($endObjectType and ($viewTypes = $endObjectType->getViewTypes())) {
		foreach($viewTypes as $viewType) {
			$viewType2 = $viewType->toArray();
			$viewTypes2[] = $viewType2;
		}
	}
	{ # answer
		$output = array( 
			'identifier'	=> 'UUID',
			'label'			=> 'UUID',
			'items'			=> $viewTypes2
		);
		echo json_encode($output);
	}
	
	
?>