<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	// { # get parameter
		// $OT_UUID = sanitize_string($_POST, 'OT_UUID', $_GET);	
		// if ( empty($OT_UUID)) {
			// $OT_UUID = sanitize_string($_POST, 'UUID', $_GET);
		// }
	// }
	// if (is_null($objectType = $backend->getObjectType($OT_UUID))) {
		// throw new instanceNotFoundException(objectType, $OT_UUID);
	// }
	// { # check access permissions
		// if (! $backend->mayRead_OT($objectType->OT_UUID())) {
			// throw new readViolationException($objectType);
		// }
	// }
function getArrayPermissions($aryPermissionsForPR, $Element_name, $otRoles, $otPersons) {
	$oAP = array();
	$i = 0;
	foreach($aryPermissionsForPR as $aryPerm){		
		// name of objecttype role or person
		if ($aryPerm['PRT_UUID'] == cSystem::$sysObject_OT_Persons_UUID) 
			$oAP[$i]['prt_name'] = T('manageAccessPermissions.js/Person.txt', "Person"); // $otPersons->name();
		else $oAP[$i]['prt_name'] = T('manageAccessPermissions.js/Role.txt', "Role");//$otRoles->name(); 
		
		$oAP[$i] = array('P_UUID'=>$aryPerm['P_UUID'],
						'blnNew' => false, // already in DB saved
						'UUID'=>$aryPerm['Element_UUID'], // O_UUID or OT_UUID
						'kind'=>$aryPerm['Element_kind'], // O or OT
						'name' => $aryPerm['name'], // name of object
						'pr_name' => $aryPerm['pr_name'], // name of object of type role or person
						'pr_uuid' => $aryPerm['PR_UUID'], // O_UUID of role or person

						
						'prt_uuid' => $aryPerm['PRT_UUID'], // OT_UUID of role or person							
						'type_name'=> $Element_name,
						'readPermission'	=> 0,
						'writePermission'	=> 0,
						'createPermission'	=> 0,
						'deletePermission'	=> 0,
						'adminPermission'	=> 0
						);	// OT name
						
						
		// check if prt_uuid system uuid of role or person
		
 		switch ($oAP[$i]["prt_uuid"]){
				case cSystem::$sysObject_OT_Persons_UUID: $oAP[$i]["prt_name"] = T('manageAccessPermissions.js/Person.txt', "Person"); break;//$otPersons->name(); 
				case cSystem::$sysObject_OT_Roles_UUID: $oAP[$i]["prt_name"] = T('manageAccessPermissions.js/Role.txt', "Role"); break; // $otRoles->name();
				default:  $oAP[$i]["prt_name"] = ''; break;
		}// End switch(prt_uuid)  
		
		// if permission string is found, check read and write permission
		if ($aryPerm['Permissions']) {		
			$aryPermissions = json_decode($aryPerm['Permissions'], true);
			
			if (array_key_exists('W', $aryPermissions)){
				$oAP[$i]['writePermission']	= $aryPermissions["W"];	
			}
			if (array_key_exists('R', $aryPermissions))
				$oAP[$i]['readPermission']	= $aryPermissions["R"];
			
			if (array_key_exists('C', $aryPermissions))
				$oAP[$i]['createPermission']	= $aryPermissions["C"];
			
			if (array_key_exists('D', $aryPermissions))
				$oAP[$i]['deletePermission']	= $aryPermissions["D"];
				
			if (array_key_exists('A', $aryPermissions))
				$oAP[$i]['adminPermission']	= $aryPermissions["A"];						
		}
	$i++;	
	} // end foreach role	
	return $oAP;		
} // end function	
	
	$oAP = array();
	
	if (array_key_exists('blnOT', $_REQUEST))	
		$blnOT	= sanitize_string($_POST, 'blnOT', $_GET);
	else $blnOT = true;
	$Element_UUID = sanitize_string($_POST, 'Element_UUID', $_GET);
	$Element_kind = sanitize_string($_POST, 'Element_kind', $_GET);	
	$Element_name = sanitize_string($_POST, 'Element_name', $_GET);	
	
	// get Permissions of parameter UUID and kind
	$permissions = new cPermissions();


	
	$otPersons 	= cObjectType::newFromDB(cSystem::$sysObject_OT_Persons_UUID);
	$otRoles 	= cObjectType::newFromDB(cSystem::$sysObject_OT_Roles_UUID);
	
	// if Element_kind OT but not blnOT then fetch all Objects for Objecttype

	if (!$blnOT && $Element_kind =='OT') {
		$aryObjects = cObject::getBy_OT_UUID($Element_UUID);	
		$aryObjectsPermissionsForPR = Array();
		foreach($aryObjects as $singleObject){
			$aryPermissionsForPR = $permissions->getPRBy_Element($singleObject->UUID(), 'O');
			if ($aryPermissionsForPR) $oAP = array_merge($oAP, getArrayPermissions($aryPermissionsForPR, $Element_name, $otRoles, $otPersons));			
		}
	}
	
	// fetch all Permissions of Element_UUID and Element_kind

		$aryPermissionsForPR = $permissions->getPRBy_Element($Element_UUID, $Element_kind);			
		if ($aryPermissionsForPR) $oAP = getArrayPermissions($aryPermissionsForPR, $Element_name, $otRoles, $otPersons);

	
	
	
	// { # answer
		// $output = array(
			// 'identifier'	=> 'PERM_UUID',
			// 'label'			=> 'PERM_UUID',
			// 'items'			=> $rights
		// );
		// echo json_encode($output);
	// }

// print_r($oAP);
	
	{ # answer
		$output = array(
			'identifier'	=> 'P_UUID', 	// OT_UUID
			'label'			=> 'P_UUID', 	// 
			'items'			=> $oAP		// objects
		);
		echo json_encode($output);
	}

						
?>