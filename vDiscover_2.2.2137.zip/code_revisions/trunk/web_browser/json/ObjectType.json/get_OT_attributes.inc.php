<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameters
	
		$OT_UUID = sanitize_string($_POST, 'OT_UUID', $_GET);
		if ( empty($OT_UUID)) $OT_UUID = sanitize_string($_POST, 'UUID', $_GET);
		
		$relationConfig = sanitize_string($_POST, 'relationConfig', $_GET);
		
	}
	if (is_null($objectType = $backend->getObjectType($OT_UUID))) {
		throw new instanceNotFoundException(objectType, $OT_UUID);
	}
	{ # check access permissions
		if (! $backend->mayRead_OT($objectType->OT_UUID())) {
			throw new readViolationException($objectType);
		}
	}
	$attributes = $objectType->getAttributes();
	$attributes2 = array();
	$tagNames = array(); # see workaround for tags below
	foreach($attributes as $attribute) {
		$attribute2 = $attribute->toArray( true );
		# bugfix no longer needed
		{ # bugfix for cKeyValuePairAttribute, because this associative array will become
		  # a json object, which leads to an javascript resp. dojo error.
			// if ($attribute->kind() == 'cKeyValuePairAttribute') {
				// unset($attribute2['keyValuePairs']);
			// }
		}
		# bugfix no longer needed
		{ # bugfix for cOTInfoAttribute , because the slot 'configurationParameter' will lead to an 
		  # error. It must be json_encode once more.
			// if ($attribute->kind() == 'cOTInfoAttribute') {
				// $attribute2['configurationParameter'] = json_encode($attribute2['configurationParameter']);
			// }
		}
		{ # for cRelationAttributes: add name of end object type
			if (
						($attribute->kind() == 'cRelationAttribute') 
					AND ($relationConfig!='withoutEndObjAndAttributeInfo')
				) {
				$endObjectType = $backend->getObjectType($attribute->End_OT_UUID());
				$attribute2['End_OT_name'] = is_null($endObjectType)?'':$endObjectType->name();
				$relationAttributes = $attribute->selected_RT()->getAttributes();
				$relationAttributes2 = array();
				foreach($relationAttributes as $A_UUID => $relationAttribute) {
					$relationAttributes2[$A_UUID] = $relationAttribute->toArray();
				}
				$attribute2['relationAttributes'] = json_encode($relationAttributes2);
			}
		}
		{ # add some information if attribute is inherited
			if ($attribute->isInherited()) {
				{ # is view an inherited one
					$attribute2['isInherited'] = true;
				}
				{ # name/UUID of super object type, where the attribute was defined originally
					$origin_A = $attribute->A_origin();
					$attribute2['attributeDefinedAt'] = $origin_A->ORT()->name();
				}
				{ # list of names/UUIDs of super object types that have the same attribute
					$OTList = array();
					$super_OT = $attribute->ORT()->super_OT();
					while(!is_null($super_OT)) {
						$OTList[] = $super_OT->name();
						$super_OT = $super_OT->super_OT();
					}
					$attribute2['inheritanceChain'] = json_encode(array_reverse($OTList));
				}
				{ # get direct parent attribute
					$parentAttribute = cAttribute::getBy_A_origin_UUID ( $attribute->A_origin_UUID(), $attribute->ORT()->super_OT_UUID());
				}
				{ # kind specific things
					switch ($attribute->kind()) {
						case 'cNumberAttribute':
							$attribute2['parentDefaultValue'] = $parentAttribute->defaultValue();
							$attribute2['parentDefaultUnit'] = $parentAttribute->defaultUnit();
							break;
						case 'cFuzzyAttribute':
							$attribute2['parentDefaultValue'] = $parentAttribute->defaultValue();
							break;
						case 'cKeyValuePairAttribute':
							$attribute2['parentDefaultValue'] = $parentAttribute->defaultValue();
							$attribute2['parentDefaultValueAsString'] = $parentAttribute->defaultValueAsString();
							break;
						case 'cSingleLineAttribute':
							$attribute2['parentDefaultValue'] = $parentAttribute->defaultValue();
							break;
						case 'cValueRangeAttribute':
							$attribute2['parentDefaultValue_rangeMin'] = $parentAttribute->defaultValue_rangeMin();
							$attribute2['parentDefaultValue_rangeMax'] = $parentAttribute->defaultValue_rangeMax();
							$attribute2['parentDefaultUnit'] = $parentAttribute->defaultUnit();
							break;
						case 'cMeasurementResultAttribute':
							$attribute2['parentDefaultValue'] = $parentAttribute->defaultValue();
							$attribute2['parentDefaultUnit'] = $parentAttribute->defaultUnit();
							break;
					}
				}
			}
			else {
				$attribute2['isInherited'] = false;
			}
		}
		{ # workaround for tags
			$tags = $attribute->tags();
			$tags2 = array();
			foreach($tags as $tag) {
				if (!isset($tagNames[$tag])) {
					$tagNames[$tag] = cSystem::generateUUID();
				}
				$tags2[$tagNames[$tag]] = $tag;
			}
			$attribute2['tags'] = json_encode($tags2);
		}
		$attributes2[] = $attribute2;
	} # end-of-foreach
	{ # answer
		$output = array( 
			'identifier'	=> 'UUID',
			'label'			=> 'UUID',
			'items'			=> $attributes2
		);
		echo json_encode($output);
/*
		echo '{
				"identifier":"UUID",
				"label":"UUID",
				"items":[
							{
								"UUID":"aaf08111-656b-11e2-9610-00fff1f86e41",
								"isSystemObject":false,
								"changedAt":"2013-01-24 09:02:26",
								"changedByP_UUID":"10000000-1000-1001-1000-00000000e000",
								"A_UUID":"aaf08111-656b-11e2-9610-00fff1f86e41",
								"ORT_UUID":"8c396cc2-656b-11e2-9610-00fff1f86e41",
								"ORT_kind":"O","A_origin_UUID":"",
								"kind":"cKeyValuePairAttribute",
								"name":"Key value pair",
								"description":"",
								"workflowConfigurationActivated":false,
								"workflowConfiguration":"",
								"readModeHint":"",
								"editModeHint":"",
								"positionOfAttribute":1,
								"cardinality":1,
								"readOnly":false,
								"mustBeSet":true,
								"mustBeUnique":false,
								"enableAnalyticalExpressions":false,
								"analyticalExpressionConfig_asJSON":"{\"attrVars\":{},\"funcBody\":\"\"}",
								"displayInFullWidth":false,
								"tags":"[]",
								"svFormatActivated":false,
								"svHtmlTagBeforeValueTupleSet":"",
								"svHtmlTagAfterValueTupleSet":"",
								"svHtmlTagBeforeValueTuple":"",
								"svHtmlTagAfterValueTuple":"",
								"actualSvHtmlTagBeforeValueTupleSet":"<ul>",
								"actualSvHtmlTagAfterValueTupleSet":"<\/ul>",
								"actualSvHtmlTagBeforeValueTuple":"<li>",
								"actualSvHtmlTagAfterValueTuple":"<\/li>",
								"valueTupleReordering_permitted":false,
								"keyValuePairsAsString":"s|Sun \u263f\nMe|Mercury \u2640\nV|Venus \u2295\nE|Earth \u2641\nMa|Mars \u2642\nJ|Jupiter \u2643\nS|Saturn \u2644\nU|Uranus \u2645\nN|Neptune \u2646",
								"displayAsCheckbox":false,
								"showAllOptions":false,
								"defaultValueAsString":"",
								"isInherited":false
							},
							{
								"UUID":"aaf0b063-656b-11e2-9610-00fff1f86e41",
								"isSystemObject":false,
								"changedAt":"2013-01-23 15:46:28",
								"changedByP_UUID":"10000000-1000-1001-1000-00000000e000",
								"A_UUID":"aaf0b063-656b-11e2-9610-00fff1f86e41",
								"ORT_UUID":"8c396cc2-656b-11e2-9610-00fff1f86e41",
								"ORT_kind":"O",
								"A_origin_UUID":"",
								"kind":"cNumberAttribute",
								"name":"Number",
								"description":"",
								"workflowConfigurationActivated":false,
								"workflowConfiguration":"",
								"readModeHint":"",
								"editModeHint":"",
								"positionOfAttribute":2,
								"cardinality":1,
								"readOnly":false,
								"mustBeSet":true,
								"mustBeUnique":false,
								"enableAnalyticalExpressions":false,
								"analyticalExpressionConfig_asJSON":"{\"attrVars\":{},\"funcBody\":\"\"}",
								"displayInFullWidth":false,
								"tags":"[]",
								"svFormatActivated":false,
								"svHtmlTagBeforeValueTupleSet":"",
								"svHtmlTagAfterValueTupleSet":"",
								"svHtmlTagBeforeValueTuple":"",
								"svHtmlTagAfterValueTuple":"",
								"actualSvHtmlTagBeforeValueTupleSet":"<ul>",
								"actualSvHtmlTagAfterValueTupleSet":"<\/ul>",
								"actualSvHtmlTagBeforeValueTuple":"<li>",
								"actualSvHtmlTagAfterValueTuple":"<\/li>",
								"valueTupleReordering_permitted":false,
								"format":"###,###.##",
								"formatDisplay":"###,###.##",
								"units":[],
								"unitsAsString":"",
								"minValue":null,
								"maxValue":null,
								"defaultValue":null,
								"defaultUnit":"",
								"isInherited":false
							},
							{
								"UUID":"aaf0d7e8-656b-11e2-9610-00fff1f86e41",
								"isSystemObject":false,
								"changedAt":"2013-01-23 15:46:28",
								"changedByP_UUID":"10000000-1000-1001-1000-00000000e000",
								"A_UUID":"aaf0d7e8-656b-11e2-9610-00fff1f86e41",
								"ORT_UUID":"8c396cc2-656b-11e2-9610-00fff1f86e41",
								"ORT_kind":"O",
								"A_origin_UUID":"",
								"kind":"cNumberAttribute",
								"name":"Number 1",
								"description":"",
								"workflowConfigurationActivated":false,
								"workflowConfiguration":"",
								"readModeHint":"",
								"editModeHint":"",
								"positionOfAttribute":3,
								"cardinality":1,
								"readOnly":false,
								"mustBeSet":true,
								"mustBeUnique":false,
								"enableAnalyticalExpressions":false,
								"analyticalExpressionConfig_asJSON":"{\"attrVars\":{},\"funcBody\":\"\"}",
								"displayInFullWidth":false,
								"tags":"[]",
								"svFormatActivated":false,
								"svHtmlTagBeforeValueTupleSet":"",
								"svHtmlTagAfterValueTupleSet":"",
								"svHtmlTagBeforeValueTuple":"",
								"svHtmlTagAfterValueTuple":"",
								"actualSvHtmlTagBeforeValueTupleSet":"<ul>",
								"actualSvHtmlTagAfterValueTupleSet":"<\/ul>",
								"actualSvHtmlTagBeforeValueTuple":"<li>",
								"actualSvHtmlTagAfterValueTuple":"<\/li>",
								"valueTupleReordering_permitted":false,
								"format":"###,###.##",
								"formatDisplay":"###,###.##",
								"units":[],
								"unitsAsString":"",
								"minValue":null,
								"maxValue":null,
								"defaultValue":null,
								"defaultUnit":"",
								"isInherited":false
							},
							{
								"UUID":"053564dc-65fc-11e2-b269-00fff1f86e41",
								"isSystemObject":false,
								"changedAt":"2013-01-24 09:02:26",
								"changedByP_UUID":"10000000-1000-1001-1000-00000000e000",
								"A_UUID":"053564dc-65fc-11e2-b269-00fff1f86e41",
								"ORT_UUID":"8c396cc2-656b-11e2-9610-00fff1f86e41",
								"ORT_kind":"O",
								"A_origin_UUID":"",
								"kind":"cRelationAttribute",
								"name":"Relation to: Persons",
								"description":"Auto-generated corresponding to relation type \"is related with\" with UUID=\"05320d90-65fc-11e2-b269-00fff1f86e41\"",
								"workflowConfigurationActivated":false,
								"workflowConfiguration":"",
								"readModeHint":"",
								"editModeHint":"",
								"positionOfAttribute":4,
								"cardinality":1,
								"readOnly":false,
								"mustBeSet":false,
								"mustBeUnique":false,
								"enableAnalyticalExpressions":false,
								"analyticalExpressionConfig_asJSON":"{\"attrVars\":{},\"funcBody\":\"\"}",
								"displayInFullWidth":false,
								"tags":"[]",
								"svFormatActivated":false,
								"svHtmlTagBeforeValueTupleSet":"",
								"svHtmlTagAfterValueTupleSet":"",
								"svHtmlTagBeforeValueTuple":"",
								"svHtmlTagAfterValueTuple":"",
								"actualSvHtmlTagBeforeValueTupleSet":"<ul>",
								"actualSvHtmlTagAfterValueTupleSet":"<\/ul>",
								"actualSvHtmlTagBeforeValueTuple":"<li>",
								"actualSvHtmlTagAfterValueTuple":"<\/li>",
								"valueTupleReordering_permitted":false,
								"selected_RT_UUID":"05320d90-65fc-11e2-b269-00fff1f86e41",
								"inverse":false,
								"showWhat":"V",
								"show_UUID":"2a027765-7c7c-11e0-a3b1-406186f2abca",
								"editRelatedObject":false,
								"hideAttributes":false,
								"multipleRelationsToTheSameTarget_permitted":false,
								"multipleRelationsAtOnce":false,
								"duplicateTargetBeforeCreating":false,
								"creatingTargetObject_permitted":false,
								"End_OT_UUID":"10000000-1000-1000-1000-00000000e000",
								"End_OT_name":"Persons",
								"isInherited":false
							},
							{
								"UUID":"63fa1bf1-65fc-11e2-b269-00fff1f86e41",
								"isSystemObject":false,
								"changedAt":"2013-01-24 09:02:26",
								"changedByP_UUID":"10000000-1000-1001-1000-00000000e000",
								"A_UUID":"63fa1bf1-65fc-11e2-b269-00fff1f86e41",
								"ORT_UUID":"8c396cc2-656b-11e2-9610-00fff1f86e41",
								"ORT_kind":"O",
								"A_origin_UUID":"",
								"kind":"cRelationAttribute",
								"name":"Relation to: Persons->User name",
								"description":"Auto-generated corresponding to relation type \"is related with\" with UUID=\"05320d90-65fc-11e2-b269-00fff1f86e41\"",
								"workflowConfigurationActivated":false,
								"workflowConfiguration":"",
								"readModeHint":"",
								"editModeHint":"",
								"positionOfAttribute":5,
								"cardinality":1,
								"readOnly":true,
								"mustBeSet":false,
								"mustBeUnique":false,
								"enableAnalyticalExpressions":false,
								"analyticalExpressionConfig_asJSON":"{\"attrVars\":{},\"funcBody\":\"\"}",
								"displayInFullWidth":false,
								"tags":"[]",
								"svFormatActivated":false,
								"svHtmlTagBeforeValueTupleSet":"",
								"svHtmlTagAfterValueTupleSet":"",
								"svHtmlTagBeforeValueTuple":"",
								"svHtmlTagAfterValueTuple":"",
								"actualSvHtmlTagBeforeValueTupleSet":"<ul>",
								"actualSvHtmlTagAfterValueTupleSet":"<\/ul>",
								"actualSvHtmlTagBeforeValueTuple":"<li>",
								"actualSvHtmlTagAfterValueTuple":"<\/li>",
								"valueTupleReordering_permitted":false,
								"selected_RT_UUID":"05320d90-65fc-11e2-b269-00fff1f86e41",
								"inverse":false,
								"showWhat":"A",
								"show_UUID":"10000000-1000-1000-1001-00000000e000",
								"editRelatedObject":false,
								"hideAttributes":true,
								"multipleRelationsToTheSameTarget_permitted":false,
								"multipleRelationsAtOnce":false,
								"duplicateTargetBeforeCreating":false,
								"creatingTargetObject_permitted":false,
								"End_OT_UUID":"10000000-1000-1000-1000-00000000e000",
								"End_OT_name":"Persons",
								"isInherited":false,
								"children":[{"_reference":"292442b5-65fc-11e2-b269-00fff1f86e41"}]
							},
							{
								"UUID":"292442b5-65fc-11e2-b269-00fff1f86e41",
								"isSystemObject":false,
								"changedAt":"2013-01-24 09:00:47",
								"changedByP_UUID":"10000000-1000-1001-1000-00000000e000",
								"A_UUID":"292442b5-65fc-11e2-b269-00fff1f86e41",
								"ORT_UUID":"05320d90-65fc-11e2-b269-00fff1f86e41",
								"ORT_kind":"R",
								"A_origin_UUID":"",
								"kind":"cNumberAttribute",
								"name":"RA_Number",
								"description":"",
								"workflowConfigurationActivated":false,
								"workflowConfiguration":"",
								"readModeHint":"",
								"editModeHint":"",
								"positionOfAttribute":1,
								"cardinality":1,
								"readOnly":false,
								"mustBeSet":false,
								"mustBeUnique":false,
								"enableAnalyticalExpressions":false,
								"analyticalExpressionConfig_asJSON":"{\"attrVars\":{},\"funcBody\":\"\"}",
								"displayInFullWidth":false,
								"tags":"[]",
								"svFormatActivated":false,
								"svHtmlTagBeforeValueTupleSet":"",
								"svHtmlTagAfterValueTupleSet":"",
								"svHtmlTagBeforeValueTuple":"",
								"svHtmlTagAfterValueTuple":"",
								"actualSvHtmlTagBeforeValueTupleSet":"<ul>",
								"actualSvHtmlTagAfterValueTupleSet":"</ul>",
								"actualSvHtmlTagBeforeValueTuple":"<li>",
								"actualSvHtmlTagAfterValueTuple":"</li>",
								"valueTupleReordering_permitted":false,
								"format":"###,###.##",
								"formatDisplay":"###,###.##",
								"units":[],
								"unitsAsString":"",
								"minValue":null,
								"maxValue":null,
								"defaultValue":null,
								"defaultUnit":"",
								"isInherited":false
							}
						]
			}'; 
*/
	}

	
?>