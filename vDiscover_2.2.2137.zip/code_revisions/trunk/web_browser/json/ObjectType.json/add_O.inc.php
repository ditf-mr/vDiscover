<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		$OT_UUID = sanitize_string($_POST, 'OT_UUID', $_GET);	
		if ( empty($OT_UUID)) {
			$OT_UUID = sanitize_string($_POST, 'UUID', $_GET);
		}
		$name = sanitize_string($_POST, 'name', $_GET);
		$temporary = sanitize_boolean($_POST, 'temporary', $_GET);
	}
	if (is_null($objectType = $backend->getObjectType($OT_UUID))) {
		throw new instanceNotFoundException(objectType, $OT_UUID);
	}
	{ # check access permissions
		if (! $backend->mayWrite_OT($objectType->OT_UUID())) {
			throw new accessViolationException('You are not allowed to write.');
		}
	}
	if ($temporary) {
		$newObject = $objectType->addObject($name, cObject::vtTemporary);
	}
	else {
		$newObject = $objectType->addObject($name);
	}
	{ # answer
		$output = $newObject->toArray();
		echo json_encode($output);
	}

						
?>