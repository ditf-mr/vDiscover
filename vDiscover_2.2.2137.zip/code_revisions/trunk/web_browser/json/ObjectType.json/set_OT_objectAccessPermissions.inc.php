<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	// { # get parameter
		// $OT_UUID = sanitize_string($_POST, 'OT_UUID', $_GET);	
		// if ( empty($OT_UUID)) {
			// $OT_UUID = sanitize_string($_POST, 'UUID', $_GET);
		// }
	// }
	// if (is_null($objectType = $backend->getObjectType($OT_UUID))) {
		// throw new instanceNotFoundException(objectType, $OT_UUID);
	// }
	// { # check access permissions
		// if (! $backend->mayRead_OT($objectType->OT_UUID())) {
			// throw new readViolationException($objectType);
		// }
	// }
	
	
	$oAP = array();
	$strJsonPermission = '';
	$blnNew = sanitize_string($_POST, 'blnNew', $_GET);
	$Element_UUID = sanitize_string($_POST, 'Element_UUID', $_GET);	
	$result= false;
	
	if($blnNew < 2){
		$Element_kind = sanitize_string($_POST, 'Element_kind', $_GET);		
		$PR_UUID = sanitize_string($_POST, 'PR_UUID', $_GET);
		$PRT_UUID = sanitize_string($_POST, 'PRT_UUID', $_GET);	
		
		$readPermission = sanitize_integer($_POST, 'readPermission', $_GET);	
		$writePermission = sanitize_integer($_POST, 'writePermission', $_GET);	
		$createPermission = sanitize_integer($_POST, 'createPermission', $_GET);	
		$deletePermission = sanitize_integer($_POST, 'deletePermission', $_GET);
		$adminPermission = sanitize_integer($_POST, 'adminPermission', $_GET);				
		
		$strJsonPermission  = '"W":' . $writePermission;
		$strJsonPermission .= ',"R":' . $readPermission;	
		$strJsonPermission .= ',"C":' . $createPermission;
		$strJsonPermission .= ',"D":' . $deletePermission;
		$strJsonPermission .= ',"A":' . $adminPermission;		
		$strJsonPermission = '{' . $strJsonPermission . '}';
	}

	// set Permissions of parameter UUID and kind
	
	

	switch($blnNew){
		  
		case 0: // UPDATE
		case 1: // INSERT
			
			if (!$blnNew) $result = cPermissions::deletePermission ($PR_UUID, $Element_UUID);
			
			$result = cPermissions::addPermission ( $PR_UUID, $PRT_UUID, $strJsonPermission, $Element_UUID, $Element_kind);	
			if (is_object($result)) $result = 0;
		break;
		
		case 2: // DELETE
		
			$result = cPermissions::deletePermission ('', $Element_UUID);	
			if (is_object($result)) $result = 0;
		break;		
		
		
	}
			
	echo  $strJsonPermission; 
?>