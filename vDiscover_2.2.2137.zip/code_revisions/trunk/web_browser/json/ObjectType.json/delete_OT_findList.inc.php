<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		$FL_UUID = sanitize_string($_POST, 'FL_UUID', $_GET);	
	}
	if (is_null($findList = $backend->getFindList($FL_UUID))) {
		throw new instanceNotFoundException('findList', $FL_UUID);
	}
	if ($findList->isPrivate() and ($findList->changedByP_UUID() != $backend->currentUser('UUID'))) {
		throw new accessViolationException('You are not allowed to delete this findList object.');
	}
	$findList->delete();
	$output = array(
		'done' => 'ok'
	);
	{ # answer
		echo json_encode($output);
	}
?>