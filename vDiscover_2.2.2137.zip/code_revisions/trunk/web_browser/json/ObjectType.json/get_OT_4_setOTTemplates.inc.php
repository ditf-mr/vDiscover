<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		$OT_UUID = sanitize_string($_POST, 'OT_UUID', $_GET);	
		if ( empty($OT_UUID)) {
			$OT_UUID = sanitize_string($_POST, 'UUID', $_GET);
		}
	}
	if (is_null($objectType = $backend->getObjectType($OT_UUID))) {
		throw new instanceNotFoundException(objectType, $OT_UUID);
	}
	{ # check access permissions
		if (! $backend->mayRead_OT($objectType->OT_UUID())) {
			throw new readViolationException($objectType);
		}
	}
	{ # collect info about parent and inheritance
		$templateNameInherited = false;
		$templateDescriptionInherited = false;
		$parentTemplateName = array();
		$parentTemplateDescription = array();
		if (!$objectType->isARootObjectType()) {
			$super_OT = $objectType->super_OT();
			$super_name_VT = $super_OT->templateName_VT();
			if (!is_null($super_name_VT)) {
				$parentTemplateName = array(
					'VT_UUID' => cViewType::getBy_VT_origin_UUID($super_name_VT->VT_origin()->VT_UUID(), $objectType->OT_UUID(), false),
					'name' => $super_name_VT->name()
				);
				$templateNameInherited = 
					((!is_null($current_VT = $objectType->templateName_VT()))
					and ($current_VT->VT_origin()->VT_UUID() == $super_name_VT->VT_origin()->VT_UUID()));
			}
			$super_description_VT = $super_OT->templateDescription_VT();
			if (!is_null($super_description_VT)) {
				$parentTemplateDescription = array(
					'VT_UUID' => cViewType::getBy_VT_origin_UUID($super_description_VT->VT_origin()->VT_UUID(), $objectType->OT_UUID(), false),
					'name' => $super_description_VT->name()
				);
				$templateDescriptionInherited = 
					((!is_null($current_VT = $objectType->templateDescription_VT()))
					and ($current_VT->VT_origin()->VT_UUID() == $super_description_VT->VT_origin()->VT_UUID()));
			}
		}
	}
	{ # collect allowed view types for name 
		$viewTypes = $objectType->getViewTypesAllowed4NameTemplate();
		$viewTypes4Name = array();
		foreach($viewTypes as $viewType) {
			$viewTypes4Name[] = $viewType->toArray();
		}		
	}
	{ # collect allowed view types for description 
		$viewTypes = $objectType->getViewTypesAllowed4DescriptionTemplate();
		$viewTypes4Description = array();
		foreach($viewTypes as $viewType) {
			$viewTypes4Description[] = $viewType->toArray();
		}		
	}
	{ # answer
		$output = array( 
			'nameView' 						=> $objectType->templateName_VT_UUID(),
			'descriptionView' 				=> $objectType->templateDescription_VT_UUID(),
			'templateNameInherited'			=> $templateNameInherited,
			'templateDescriptionInherited'	=> $templateDescriptionInherited,
			'parentTemplateName'			=> $parentTemplateName,
			'parentTemplateDescription'		=> $parentTemplateDescription,
			'viewTypes4Name'				=> array( 
				'identifier'	=> 'UUID',
				'label'			=> 'UUID',
				'items'			=> $viewTypes4Name
			),
			'viewTypes4Description'			=> array( 
				'identifier'	=> 'UUID',
				'label'			=> 'UUID',
				'items'			=> $viewTypes4Description
			)
		);
		echo json_encode($output);
	}

						
?>