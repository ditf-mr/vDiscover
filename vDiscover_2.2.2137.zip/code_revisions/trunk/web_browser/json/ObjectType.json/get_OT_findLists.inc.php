<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// $GLOBALS['logHandler']->clearDebug();
// $GLOBALS['logHandler']->debug(__FILE__);
{ # get parameters
	$OT_UUID = sanitize_string($_POST, 'OT_UUID', $_GET);	
	if (is_null($objectType = $backend->getObjectType($OT_UUID))) {
		throw new instanceNotFoundException(objectType, $OT_UUID);
	}
}
{ # check access permissions
	if (! $backend->mayRead_OT($objectType->OT_UUID())) {
		throw new readViolationException($objectType);
	}
}

{ # bet and build the output
	$output = array();
	
	$findLists = cFindList::getBy_OT_UUID_changedByP_UUID ( $OT_UUID, $backend->currentUser('UUID') );
	reset($findLists);
	while ( list($FL_UUID, $findList) = each($findLists) ) {
	
		{ # locate name of person that carried out the last changes
			$lastChangesBy 			= '';
			$lastChangesBy_O_v_UUID = '';
		
			if (! is_null($changedBy_O = $backend->getCurrentObject($findList->changedByP_UUID()))) {
				$name_VTSet = $changedBy_O->getAttributeValues( cSystem::$sysObject_Persons_A_Name_UUID );			
				
				$lastChangesBy 			= current($name_VTSet)->value();
				$lastChangesBy_O_v_UUID = $changedBy_O->O_v_UUID();
				
				unset($changedBy_O);
				unset($name_VTSet);
			} else {
				$lastChangesBy 			= '?';
				$lastChangesBy_O_v_UUID = '';
			} // end if
		}
		
		{ # add the current find list to the output
			$output[] = array(
				'FL_UUID'				=> $findList->FL_UUID(),
				'name'					=> $findList->name(),
				'usage'					=> ($findList->isPrivate()?'justMe':'everybody'),
				'lastChanges_at'		=> $findList->changedAt(),
				'lastChanges_by' 		=> $lastChangesBy,
				'lastChanges_byO_v_UUID'=> $lastChangesBy_O_v_UUID,
			);
		}
	} // end while
}

{ # answer the query
	echo json_encode($output);
}
?>