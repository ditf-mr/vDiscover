<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		$OT_UUID = sanitize_string($_POST, 'OT_UUID', $_GET);	
		if ( empty($OT_UUID)) {
			$OT_UUID = sanitize_string($_POST, 'UUID', $_GET);
		}
	}
	if (is_null($objectType = $backend->getObjectType($OT_UUID))) {
		throw new instanceNotFoundException(objectType, $OT_UUID);
	}
	{ # check access permissions
		if (! $backend->mayRead_OT($objectType->OT_UUID())) {
			throw new readViolationException($objectType);
		}
	}
	$attributes = $objectType->getAttributes();
	$attributeList = array();
	
	reset($attributes);
	while(list(,$attribute)=each($attributes)) {
		// restrict the attributes to number, only
		switch ($attribute->kind()) {
			case 'cNumberAttribute': {
				$attributeList[]=array(
					'kind'			=> $attribute->kind(),
					'UUID'			=> $attribute->A_UUID(),
					'name'			=> $attribute->name(),
					'cardinality'	=> $attribute->cardinality(),
					'format'		=> $attribute->formatDisplay(),
					'unit'			=> $attribute->unitsAsString()
				);
				// name unit UUID
				} break;
			case 'cRelationAttribute': {
				// does the relation attribute refer to a number attribute?
				
				$showAttribute=null;
				
				if (		($attribute->showWhat()=='A')
						AND	($attribute->show_UUID())
						AND ($showAttribute = $attribute->show_Instance())
						AND ($showAttribute->kind()=='cNumberAttribute')
					) 				
						$attributeList[]=array(
							'kind'			=> $attribute->kind(),
							'UUID'			=> $attribute->A_UUID(),
							'name'			=> $attribute->name(),
							'cardinality'	=> $showAttribute->cardinality(),
							'format'		=> $showAttribute->formatDisplay(),
							'unit'			=> $showAttribute->unitsAsString()
						);
			
				} break;
				
			default: // do nothing
		} // end switch
		
	} // end for each attribute
	
	{ # prepare and send the answer
		$output = array(
			'equationSystem'		=> $objectType->equationSystem(),
			'attributesForStore'	=> array( 
				'identifier'	=> 'UUID',
				'label'			=> 'UUID',
				'items'			=> $attributeList
			)
		);
		echo json_encode($output);
	}

	
?>