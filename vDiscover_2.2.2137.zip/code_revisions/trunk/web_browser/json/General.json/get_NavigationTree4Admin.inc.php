<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameters
		$onlyOT = (sanitize_string($_POST, 'onlyOT', $_GET) == '1');
		$excludeSubTypesOf_OT_UUID = sanitize_string($_POST, 'excludeSubTypesOf_OT_UUID', $_GET);
	}
	{ # init empty items list
		$menuItems = array();
	}
	{ # retrieve object types and relation types
		if ($backend->isAdmin()) {
			$objectTypes = $backend->getAllObjectTypes(); 
			$relationTypes = $backend->getAllRelationTypes(); 
		}
		else {
			$objectTypes = array();
			$relationTypes = array();
		}
	}
	{ # walk through object types and collect information about object hierarchy
		$topLevelObjectTypes = array();
		$subObjectTypes = array();
		foreach($objectTypes as $OT_UUID=>$objectType) {
			if ( $objectType->isARootObjectType()) 
				$topLevelObjectTypes[] = array ( '_reference' => $OT_UUID );
			else
				$subObjectTypes[$objectType->super_OT_UUID()][] = $OT_UUID;
		}
	}
	{ # walk through object types, collect top level object types and create menu items	
		foreach($objectTypes as $OT_UUID=>$objectType) {
			{ # generate children list
				$children = array();
				$has_OTChildren=false; # boolean
				{ # add sub object types
					if (isset($subObjectTypes[$OT_UUID]) && ($excludeSubTypesOf_OT_UUID!=$OT_UUID)) {
						foreach($subObjectTypes[$OT_UUID] as $sub_OT_UUID) 
							$children[] = array( '_reference' => $sub_OT_UUID );
						$has_OTChildren=true;
					} // end if
				}
				{ # add relations
					if (! $onlyOT) {
						foreach($relationTypes as $RT_UUID=>$relationType) {
							if ($relationType->Start_OT_UUID() == $OT_UUID) {
								$children[] = array( '_reference' => 's_'.$RT_UUID );
							}
							if ($relationType->End_OT_UUID() == $OT_UUID) {
								$children[] = array( '_reference' => 's_'.$RT_UUID.'_I' );
							}
						}
					}
				}
			}
			
			$item = array(
				'uniqueMenu_UUID'	=> $OT_UUID,
				'UUID'				=> $OT_UUID,
				'label'				=> $objectType->name(),
				'name'				=> $objectType->name(),
				'type'				=> 'OT',
				'excludedSubTypes'	=> ((isset($subObjectTypes[$OT_UUID]) && ($excludeSubTypesOf_OT_UUID==$OT_UUID))?1:0),
				'has_OTChildren'	=> $has_OTChildren
			);
			if (count($children)>0) $item['children'] = $children;
			$menuItems[] = $item;
		}
	}
	{ # walk through relation types, collect top level relation types and create menu items
	  # each relation type should be created twice
		$topLevelRelationTypes = array();
		foreach($relationTypes as $RT_UUID=>$relationType) {
			{ # step 1: relation types
				$Start_OT = $relationType->Start_OT();
				$End_OT = $relationType->End_OT();
				$topLevelRelationTypes[] = array ( '_reference' => $RT_UUID );
				$menuItems[] = array(
					'uniqueMenu_UUID'	=> $RT_UUID,
					'UUID'				=> $RT_UUID,
					'label'				=> $relationType->name() . ' (' . $Start_OT->name() . '→' . $End_OT->name() . ')'
											. ($relationType->reflexive()?' [R]':''),
					'name'				=> $relationType->name(),
					'type'				=> 'RT'
				);
				if (! $onlyOT) {
					$menuItems[] = array(
						'uniqueMenu_UUID'	=> 's_'.$RT_UUID,
						'UUID'				=> $RT_UUID,
						'label'				=> $relationType->name() . ' (→' . $End_OT->name() . ')'
											. ($relationType->reflexive()?' [R]':''),
						'name'				=> $relationType->name(),
						'type'				=> 'RT'
					);
				}
			}
			{ # step 2: inverse relation types
				$Start_OT = $relationType->End_OT();
				$End_OT = $relationType->Start_OT();
				$topLevelRelationTypes[] = array ( '_reference' => $RT_UUID.'_I' );
				$menuItems[] = array(
					'uniqueMenu_UUID'	=> $RT_UUID.'_I',
					'UUID'				=> $RT_UUID,
					'label'				=> $relationType->nameOfInverse() . ' (' . $Start_OT->name() . '→' . $End_OT->name() . ') '
											. ($relationType->reflexive()?'[R,I]':'[I]'),
					'name'				=> $relationType->nameOfInverse(),
					'type'				=> 'RT'
				);
				if (! $onlyOT) {
					$menuItems[] = array(
						'uniqueMenu_UUID'	=> 's_'.$RT_UUID.'_I',
						'UUID'				=> $RT_UUID,
						'label'				=> $relationType->nameOfInverse() . ' (→' . $End_OT->name() . ') '
											. ($relationType->reflexive()?'[R,I]':'[I]'),
						'name'				=> $relationType->nameOfInverse(),
						'type'				=> 'RT'
					);
				}
			}
		}
	}
	{ # add top level elements for object and relation types
		$menuItems[] =  array( 
			'uniqueMenu_UUID'	=> 'Object Types', 
			'label'				=> 'Object Types', 
			'topLevelItem'		=> true,
			'type'				=> 'navigation_node',
			'children'			=> $topLevelObjectTypes 
		);
		if (! $onlyOT) {
			$menuItems[] =  array( 
				'uniqueMenu_UUID'	=> 'Relation Types', 
				'label'				=> 'Relation Types', 
				'topLevelItem'		=> true,
				'type'				=> 'navigation_node_withoutRightClickFunctionality',
				'children'			=> $topLevelRelationTypes 
			);
		}
	}
	{ # generate output element
		$output = array ( 
			'identifier'	=> 'uniqueMenu_UUID', 
			'label'			=> 'label', 
			'items'			=> $menuItems );
	}
	{ # encode
		echo json_encode( $output );
	}

?>