<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # Get parameters
		$username = sanitize_string($_POST, 'username', $_GET);	
	}
	{ # Perform a database query.
		$answer = false;
		$sql = 'SELECT
					OR_v_UUID 
				FROM attributevalue
				WHERE (OR_kind = \'O\')
				  AND (OR_v_UUID <> ' . $dbLayer->quoteSmart($backend->currentUser('v_UUID')) . ')
				  AND (versionType = \'c\')
				  AND (A_UUID = ' . $dbLayer->quoteSmart(cSystem::$sysObject_Persons_A_Username_UUID) . ')
				  AND (value_tinytext_1 = ' . $dbLayer->quoteSmart($username) . ')';
		$res = $dbLayer->readQuery($sql);
		if ($row = $res->fetchRow()) {
			$answer = true;
		}
	}
	{ # output the result
		echo json_encode(array('userNameExists'=>$answer));
	}

						
?>