<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameters
	}
	{ # generate output element
		$output = array ( 
			'hasReadPermission'	=> $backend->hasReadPermission()
		);
	}
	{ # encode
		echo json_encode( $output );
	}

?>