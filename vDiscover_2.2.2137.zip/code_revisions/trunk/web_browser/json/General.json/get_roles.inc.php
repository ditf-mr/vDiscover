<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/
	
	// check if ObjectType "Roles" is defined
	if (is_null($objectTypeRole = $backend->getObjectType(cSystem::$sysObject_OT_Roles_UUID))) {
		throw new Exception('Object type with UUID = "' .$sysObject_OT_Roles_UUID . '" not found.');
	}
	
	// check if ObjectType "Persons" is defined
	if (is_null($objectTypePersons = $backend->getObjectType(cSystem::$sysObject_OT_Persons_UUID))) {
		throw new Exception('Object type with UUID = "' .$sysObject_OT_Persons_UUID . '" not found.');
	}	
	
	// get Objects of 'Roles'
	$aryObjectsRoles = $objectTypeRole->getObjects();
	$objectsForStore = array();
	$strJsonForStore = '';
	foreach($aryObjectsRoles as $objectRole) {

		$assignedToRelations = $objectRole->getRelations_asEnd(cSystem::$sysObject_RT_actAs_UUID);
		$aryChildren = array();
/* 		foreach($assignedToRelations as $singleRelation){
			 
			$person_uuid = $singleRelation->Start_O()->O_UUID();
			$aryChildren[]['_reference'] =  $person_uuid;
			$person = cObject::getCurrent($person_uuid);	
					
			$objectPerson = $person->toArray();
			
			$objectsForStore[] = $objectPerson;
		} */
		
		$objectRoleAsArray = $objectRole->toArray();
		$objectRoleAsArray["children"] = $aryChildren;
		$objectsForStore[] = $objectRoleAsArray;
	}	


	{ # answer
		$output = array(
			'identifier'	=> 'O_UUID',
			'label'			=> 'name',
			'items'			=> $objectsForStore
		);
		echo json_encode($output);
	}

						
?>