<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		# no parameters
	}
	$watchLists = $backend->getWatchLists();
	$watchLists2 = array();
	{ # List to collect all used cObjectType
		$collectedObjectTypes = array();
	}
	foreach($watchLists as $watchList) {
		if (is_null($object = $watchList->O())) {
			$GLOBALS['logHandler']->debug('Object with O_UUID "' . $watchList->O_UUID() . '" on watch list does not exist. Watch list entry is deleted.');
			$watchList->delete();
		}
		else {
			$watchLists2[] = array(
				'UUID' 		=> $object->O_v_UUID(),
				'O_v_UUID'	=> $object->O_v_UUID(),
				'O_UUID'	=> $object->O_UUID(),
				'OT_UUID' 	=> $object->OT_UUID(),
				'name' 		=> $object->name(),
				'type'		=> 'O',
				'isTagged'	=> true
			);
			if (! isset($collectedObjectTypes[$object->OT_UUID()])) {
				{ # initialise a firstly appeared cObjectType element
					$objectType = $object->OT();
					$collectedObjectTypes[$objectType->OT_UUID()] = array(
						'UUID'		=> $objectType->OT_UUID(),
						'OT_UUID'	=> $objectType->OT_UUID(),
						'name'		=> $objectType->name(),
						'type'		=> 'OT',
						//'isTagged'	=> false,
						'OT_menuBar'	=> json_encode($objectType->menuBarOT())
					);
				}
			}
			{ # add the current $Object to its (now) existing cObjectType element
				$collectedObjectTypes[$object->OT_UUID()]['_objects'][] = 
					array('_reference' => $object->O_v_UUID());
			}
		}
	}
	{ # finally add all collected cObjectType elements to the output list
		foreach($collectedObjectTypes as $objectType) {
			$watchLists2[] = $objectType;
		}
	}
	{ # answer
		$output = array(
			'identifier'	=> 'UUID',
			'label'			=> 'name',
			'items' 		=> $watchLists2
		);
		echo ( json_encode($output) );
	}

						
?>