<?php 
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # check if application is started correctly
		if ( ! defined('APPLICATION_started') or ! $repository_config ) {
			header('Location: ../../../..');
			exit;
		}
	}

	{ # start http output 
		header('Content-type: application/json');
	}

	try { 

		# user permission are validated either in each task or in the backend functions 
	
		{ # identify the task 
			$task = sanitize_string($_POST, 'task', $_GET);
			switch ( $task ) { 
	
				case 'get_O_current': # ------------------------------------------------------------
					{ # return the UUID of the current object identified by the given parameter.
					  # Attention: The given UUID is the O_UUID of an object (group). The UUID in 
					  # the return value of this function is the O_v_UUID, which is unique.
						include('Object.json/get_O_current.inc.php');
						break;
					}
					
				case 'get_O_modified': #------------------------------------------------------------
					{ # return the UUID of the modified object identified by the given parameter. 
					  # Modified means the object, which is in a workflow process.
					  # Attention: The given UUID is the O_UUID of an object (group). The UUID in  
					  # the return value of this function is the O_v_UUID, which is unique.
						include('Object.json/get_O_modified.inc.php');
					break;
				}
					
				case 'activate_O': # --------------------------------------------------------------------
					{ # activates a temporary object
						include('Object.json/activate_O.inc.php');
						break;
					}
					
				case 'get_O': # --------------------------------------------------------------------
					{ # get (read) all items of an object
						include('Object.json/get_O.inc.php');
						break;
					}
					
				case 'get_O_name': # ---------------------------------------------------------------
					{ # return the name of the object
						include('Object.json/get_O_name.inc.php');
						break;
					}
					
				case 'set_O_name': # ---------------------------------------------------------------
					{ # set (save) the name of the object
						include('Object.json/set_O_name.inc.php');
						break;
					}
					
				case 'get_O_description': # --------------------------------------------------------
					{ # return the description of the object
						include('Object.json/get_O_description.inc.php');
						break;
					}
					
				case 'get_O_descriptionPlain': # ---------------------------------------------------
					{ # return the plain description of the object
						include('Object.json/get_O_descriptionPlain.inc.php');
						break;
					}
					
				case 'set_O_description': # --------------------------------------------------------
					{ # set (save) the description of the object. If description is based on a 
					  # template view, then nothing happens
						include('Object.json/set_O_description.inc.php');
						break;
					}
					
				case 'get_O_versionType': # --------------------------------------------------------
					{ # return the version type ('c', 'm', 't', 'a', or 'd') of the object
						include('Object.json/get_O_versionType.inc.php');
						break;
					}
					
				case 'get_O_UUID': # ---------------------------------------------------------------
					{ # return the O_UUID of the object
						include('Object.json/get_O_UUID.inc.php');
						break;
					}
					
				case 'get_O_v_UUID': # -------------------------------------------------------------
					{ # return the O_v_UUID of the object
						include('Object.json/get_O_v_UUID.inc.php');
						break;
					}
					
				case 'get_OT_UUID': # --------------------------------------------------------------
					{ # return the OT_UUID of the object
						include('Object.json/get_OT_UUID.inc.php');
						break;
					}
					
				case 'get_O_kind': # ---------------------------------------------------------------
					{ # return the kind ('O') of the object
						include('Object.json/get_O_kind.inc.php');
						break;
					}
					
				case 'get_O_attributeValueSets': # -------------------------------------------------
					{ # get (read) the attribute value sets (attributes and their values)
						include('Object.json/get_O_view2_functions.inc.php');
						include('Object.json/get_O_attributeValueSets.inc.php');
						break;
					}
					
				case 'get_O_CBREstimations': # -------------------------------------------------
					{ # get (read) the attribute value sets (attributes and their values)
						include('Object.json/get_O_CBREstimations.inc.php');
						break;
					}
					
				case 'get_O_attributeValues': # ----------------------------------------------------
					{ # get (read) the attribute values of the given object-attribute-combination.
						include('Object.json/get_O_attributeValues.inc.php');
						break;
					}
					
				case 'set_O_attributeValuesOfAnAttribute': # ---------------------------------------
					{ # set the attribute values for the given attribute.
						include('Object.json/set_O_attributeValuesOfAnAttribute.inc.php');
						break;
					}
				
				case 'set_O_attributeValuesOfAnAttributeSet': # ---------------------------------------
					{ # set the attribute values for the given attributes.
						include('Object.json/set_O_attributeValuesOfAnAttributeSet.inc.php');
						break;
					}
				
				case 'set_O_attributeValuesOfAViewType': # -----------------------------------------
					{ # set the attribute values for all attributes of the given view type
						include('Object.json/set_O_attributeValuesOfAViewType.inc.php');
						break;
					}
					
				case 'dialogue_manageRelations': # -------------------------------------------------
					{ # get all information needed to build the dialogue for creation and deletion
					  # ofrelations.
						include('Object.json/dialogue_manageRelations.inc.php');
						break;
					}
					
				case 'set_O_relations': # ----------------------------------------------------------
					{ # set the attribute values for the given object-attribute-combination.
					  # Hint: RT_UUID can be deleted, because is named again in each new relation
						include('Object.json/set_O_relations.inc.php');
						break;
					}
					
				case 'get_O_view2': # ---------------------------------------------------------------
					{ # Attention: this is currently used by Tobias for his work on the views.
					  # This method is similar to 'get_O_view', but for cRelationAttribute this 
					  # method loads (and returns) the relevant attribute or view of the object at
					  # the end of the relation. Attention: A sequence of relations is not allowed, 
					  # that means it is not possible to follow a relation to an attribute (or a
					  # view containing a attribute), that is a cRelationAttribute.
					  # get (read) one specific view of an object, this means return a json object
					  # consisting of the view type and the attributeValueSets needed.
						include('Object.json/get_O_view2_functions.inc.php');
						include('Object.json/get_O_view2.inc.php');
						break;
					}
					
				case 'get_O_view': # ---------------------------------------------------------------
					{ # get (read) one specific view of an object, this means return a json object
					  # consisting of the view type and the attributeValueSets needed.
						include('Object.json/get_O_view.inc.php');
						break;
					}
					
				case 'get_O_connectedAttributeValueSet': # -----------------------------------------
					{ # get all information needed to build the dialogue for creation and deletion 
					  # of relations.
						include('Object.json/get_O_connectedAttributeValueSet.inc.php');
						break;
					}
					
				case 'get_O_connectedView': # ------------------------------------------------------
					{ # get all information needed to build the dialogue for creation and deletion 
					  # of relations.
						include('Object.json/get_O_connectedView.inc.php');
						break;
					}	
					
				case 'mDelete_O': # ----------------------------------------------------------------
					{ # mDelete (mark as deleted) the object 
						include('Object.json/mDelete_O.inc.php');
						break;
					}
					
				case 'delete_O': # -----------------------------------------------------------------
					{ # delete the object 
						include('Object.json/delete_O.inc.php');
						break;
					}

				case 'duplicate_O': # --------------------------------------------------------------
					{ # duplicates an object 
						include('Object.json/duplicate_O.inc.php');
						break;
					}
				case 'set_O_currentStatus': # --------------------------------------------------------------
					{ # duplicates an object 
						include('Object.json/set_O_currentStatus.inc.php');
						break;
					}				
				case 'get_O_withOT': # -------------------------------------------------------------
					{ # get (read) all properties of an object plus its object type
						include('Object.json/get_O_withOT.inc.php');
						break;
					}
					
				case 'addToWatchList': # -----------------------------------------------------------
					{ # adds a cObject to or from user's watch list
						include('Object.json/addToWatchList.inc.php');
						break;
					}
					
				case 'deleteFromWatchList': # ------------------------------------------------------
					{ # deletes a cObject to or from user's watch list
						include('Object.json/deleteFromWatchList.inc.php');
					break;
					}
					
				case 'isOn_watchList': # -----------------------------------------------------------
					{ # checks if a cObject is on the user's watch list
						include('Object.json/isOn_watchList.inc.php');
						break;
					}
				
				case 'usesTemplateViewForName': # --------------------------------------------------
					{ # return true, if a template view for the name is specified, false, if not.
						include('Object.json/usesTemplateViewForName.inc.php');
						break;
					}
								
				default: # -------------------------------------------------------------------------
					throw new Exception('The passed task ' . $task . ' is not implemented.');
			} # end-of-switch
		}
	} 
	catch (Exception $e) {
		header('HTTP/1.1 500 Internal Server Error');
		$GLOBALS['logHandler']->log($e);
		echo json_encode(array(
			'type'		=> 'Exception',
			'message'	=> $e->getMessage(),
			'code'		=> $e->getCode(),
			'file'		=> $e->getFile(),
			'line'		=> $e->getLine(),
			'trace'		=> $e->getTraceAsString()
		));
	} # end-of-trycatch


	function _getCObjectFromParameter () {
		/** Loads a cObject regarding the given POST or GET parameters.
		 * (1) looks for 'O_v_UUID'. If found ok. If not (2), looks for 'UUID' (interpreted as 
		 * 'O_v_UUID'. If found ok. If not (3), looks for 'O_UUID' and gets O_v_UUID of current 
		 * version 
		 * @return cObject. On success.
		 * @return null. On failure.
		 */
		global $backend;
		if (! ( ($UUID = sanitize_string($_POST, 'O_v_UUID', $_GET))
			or ($UUID = sanitize_string($_POST, 'O_UUID', $_GET))
			or ($UUID = sanitize_string($_POST, 'UUID', $_GET)) ) ) {
			return ( null );
		}
		else {
			if ( (is_null($object = $backend->getObject($UUID)))
				and (is_null($object = $backend->getCurrentObject($UUID))) ) {
				return ( null );
			}
			else {
				return ( $object );
			}
		}
	} # end-of-fucntion _getCObjectFromParameter

?>