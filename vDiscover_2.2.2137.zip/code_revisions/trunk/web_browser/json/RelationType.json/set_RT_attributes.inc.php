<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		$RT_UUID = sanitize_string($_POST, 'RT_UUID', $_GET);	
		if ( empty($RT_UUID)) {
			$RT_UUID = sanitize_string($_POST, 'UUID', $_GET);
		}
		$attributesBlock = json_decode(sanitize_string($_POST, 'attributes', $_GET), true);
		if (json_last_error() != JSON_ERROR_NONE) {
			throw new incorrectInputDataException('"attributes" caused json-syntax-error.');
		}
		$attributes = $attributesBlock['items'];	
	}
	if (is_null($relationType = $backend->getRelationType($RT_UUID))) {
		throw new instanceNotFoundException(relationType, $RT_UUID);
	}
	{ # check access permissions
		if (! $backend->mayWrite_RT($relationType->RT_UUID())) {
			throw new writeViolationException($relationType);
		}
	}
	$relationType->setAttributes($attributes);
	{ # answer
		$output = array(
			'done' => true
		);
		echo json_encode($output);
	}

	
?>