<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # get parameter
		$A_UUID = sanitize_string($_POST, 'A_UUID', $_GET); 
		if ( empty($A_UUID)) {
			$A_UUID = sanitize_string($_POST, 'UUID', $_GET);
		}
	}
	if (is_null($attribute = $backend->getAttribute($A_UUID))) {
		throw new instanceNotFoundException(attribute, $A_UUID);
	}
	{ # check access permissions
		switch($attribute->ORT_kind()) {
			case 'O':
				if (! $backend->mayRead_OT($attribute->ORT_UUID())) {
					throw new readViolationException($attribute);
				}
				break;
			case 'R':
				if (! $backend->mayRead_RT($attribute->ORT_UUID())) {
					throw new readViolationException($attribute);
				}
				break;
			default:
				throw new developerException('Inconsistet data in attribute. Invalid ORT_kind.');
		}
	}
	{ # answer
		$output = $attribute->toArray();
		echo json_encode($output);
	}

						
?>