<?php if (!defined('APPLICATION_started')) {header('Location: .');exit;} 
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// this file registers all basic dojo componentsa

{// let's start with the DOJO & DIJIT javascript, css and themes
$p='third_party_libraries/'.DOJO_TOOLKIT_path;
$r->register_cssFile($p.'/dijit/themes/'.$repository_config['DOJO_theme'].'/'.$repository_config['DOJO_theme'].'.css');
$r->register_JavaScriptFile($p.'/dojo/dojo.js');

} // end register DOJO & DIJIT

?>