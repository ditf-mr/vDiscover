#############################################################
# 				 DIN 4844-2 Standard Symbols                #
#############################################################

Description: 
	This package include pictograms of the German DIN 4844-2 
standard as well as some French extentions. 


Includes:
	Prohibition, Manditory, and Hazard symbols 

Package source:	
	Open Icon Library
	http://openiconlibrary.sourceforge.net/

Date:		
	13 Jan 2009

License:	
	Public Domain
	http://en.wikipedia.org/wiki/Public_domain

Original Source:	
	Source: Technische Regeln für Arbeitsstätten
	Link: http://www.baua.de/nn_56926/de/Themen-von-A-Z/Arbeitsstaetten/ASR/pdf/ASR-A1-3.pdf
	Aquired: 27 Dec 2009
	Modifications: PDF converted to SVG and PNG by the 
		Open Icon Library

