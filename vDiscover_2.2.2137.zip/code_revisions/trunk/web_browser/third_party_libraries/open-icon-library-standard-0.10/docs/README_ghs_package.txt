#############################################################
#                      GHS Pictograms                       #
#############################################################

Description: 
	This package contains the pictograms used by the UN Economic Commission for Europe for the Global Harmonized System of Classification and Labeling of Chemicals.  This lables are commonly used by many other organizations for lableling chemicals.

Package source:	
	Open Icon Library
	http://openiconlibrary.sourceforge.net/

Date:		
	13 Jan 2009

License:	
	Public Domain
	http://en.wikipedia.org/wiki/Public_domain

Original Source:	
	Link: http://www.unece.org/trans/danger/publi/ghs/pictograms.html
	Aquired: 27 Dec 2009

