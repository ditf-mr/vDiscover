<?php
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

	{ # check if configuration is loaded
		if ( ! $repository_config ) {
			header('Location: ../..');
			exit;
		}
	}
	define('APPLICATION_started', true);
	
	// add absolute paths to $repository_config
	require_once(__DIR__.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'information_structure'.DIRECTORY_SEPARATOR.'utilities.php');
	$repository_config = expandPathsIn_repository_config($repository_config);	
	
	{ # specification of modules
	  # choose which application output shall be sent to the web browser.
	  # these output options are available only, if the user is logged in.
		$modules = array (
			# general application output
			'application_title'		=> 'application/corporate_identity_panes/application_title.php',
			'welcome_tab'			=> 'application/corporate_identity_panes/welcome_tab.php',
			# language strings
			'getLanguageStrings'	=> 'common/lang/getLanguageStrings.json.php',
			# information object type specific output 
			'OT_tab'				=> 'application/OT/OT_tab.php',
			'OT_Overview'			=> 'application/OT/OT_overview.php',
			'OT_last_changes'		=> 'application/OT/OT_last_changes.php',
			//'OT_show_all_io'		=> 'application/OT/OT_show_all_io.php',
			'OT_retrieval_query'	=> 'application/OT/OT_retrieval_query.php',
			# attribute-specific functionalities
			'cFileAttribute_uploadFile' => 'application/attributes/cFileAttribute/uploadFile.php',
			'cFileAttribute_downloadFile' => 'application/attributes/cFileAttribute/downloadFile.php',
			# JSON queries
			'JSON_General'			=> 'json/General.json.php',
			'JSON_ObjectType'		=> 'json/ObjectType.json.php',
			'JSON_RelationType'		=> 'json/RelationType.json.php',
			'JSON_Attribute'		=> 'json/Attribute.json.php',
			'JSON_Object'			=> 'json/Object.json.php',
			'ObjectType'			=> 'json/ObjectType.json.php',
			# information object specific output
			'O_tab'					=> 'application/O/O_tab.php',
			# hints
			'hint_attributeName'	=> 'application/admin/hints/attributeName.php',
			'hint_patternNumber'	=> 'application/admin/hints/pattern-number.php',
			'hint_regex'			=> 'application/admin/hints/pattern-regex.php',
			'hint_patternTime'		=> 'application/admin/hints/pattern-time.php',
			'hint_keyValuePair'		=> 'application/admin/hints/keyValuePair.php',
			'hint_fuzzyValue'		=> 'application/admin/hints/fuzzyValue.php',
			'hint_mimeTypes'		=> 'application/admin/hints/mimeTypes.php',
			# managing export files
			'downloadExportFile' => 'application/downloadExportFile.php',
			# manual
			'manual'				=> 'application/user_manual/default/manual.php', //default language
			
			# is this file here still necessary?
			'admin_pane'			=> 'application/admin/admin_pane.php'
		); 
	}
	{ # list here scripts, that may be accessed without login
		$modulesWithoutLogin = array ( 
			'application/corporate_identity_panes/application_title.php',
			'common/lang/getLanguageStrings.json.php',
		);
	}
	{ # send header to ensure that file will not be cached
		header('Cache-Control: no-cache, must-revalidate'); 
		header('Content-Type: text/html; charset=utf-8'); 
		header('Expires: Sat, 26 Jul 1997 05:00:00 GMT'); # date in the past
	}
	{ # load configuration
		require_once($repository_config['application_path'].DIRECTORY_SEPARATOR.'config.php');
	}
	{ # load some useful functions, classes, methods ...
		require_once($repository_config['application_path'].DIRECTORY_SEPARATOR.'utilities.php');
	}
	{ # load and initialise global log files handler 
		require_once( realpath($repository_config['root_path'].DIRECTORY_SEPARATOR.'utilities'.DIRECTORY_SEPARATOR.'cLogHandler.php') );
		global $logHandler;
		if ( is_null( $logHandler = new cLogHandler ( $repository_config['path_logs'] ) ) ) 
			die('Could not initialise global $logHandler object.');
	}
	{ # load exceptions
		require_once( realpath($repository_config['root_path'].DIRECTORY_SEPARATOR.'utilities'.DIRECTORY_SEPARATOR.'exceptions.php') );		
	}
	{ # load backend module and create cBackend instance
		require_once( $repository_config['backend_path'].DIRECTORY_SEPARATOR.'loadBackend.php' );
	}
	{ # start session
		session_start();
		session_cache_expire(cSystem::sessionTimeout());
	}
	{ # load translation module and create cTranslation instance
		require_once( $repository_config['application_path'].DIRECTORY_SEPARATOR.'translations'.DIRECTORY_SEPARATOR.'loadTranslations.php' );
	}
	{ # load the web browser configuration
		require(__DIR__.DIRECTORY_SEPARATOR.'config.php');
	}
	{ # load some general purpose functions, classes, methods ...
		require(__DIR__.DIRECTORY_SEPARATOR.'common'.DIRECTORY_SEPARATOR.'utilities.php');
	}
	{ # carry out actions 
		# Set Maintenance Error if Maintenance is running
		if ( ( ( $repository_config['maintenance_status'] == "announced" ) AND (  $repository_config['maintenance_nologinafter'] <= time() ) )
		OR ( $repository_config['maintenance_status'] == "running" ) ) {
			$errorMaintenance = 'The repository is currently under maintenance.<br />
				Message: ' . $repository_config['maintenance_message'] . '<br />
				Expected end of maintenance: ' . date('Y/m/d H:i',$repository_config['maintenance_end']) . '<br />
				Please try again later.';
		}
		# Set Maintenance Message if Maintenance is announced
		else if ( ( $repository_config['maintenance_status'] == "announced" ) AND (  $repository_config['maintenance_nologinafter'] > time() ) ) {
			$messageMaintenance = 'Next maintenance is excepted:<br /> ' . 
				date('Y/m/d H:i',$repository_config['maintenance_begin']) . ' - ' . date('Y/m/d H:i',$repository_config['maintenance_end']). '<br />
				Message: ' . $repository_config['maintenance_message'] . '<br />
				No logins will be possible after: ' . date('Y/m/d H:i',$repository_config['maintenance_nologinafter']);
		}		
		try {
			$action = sanitize_string($_POST, 'a', $_GET);
			switch ($action) {
				case 'login':
					{ # try login using username and password, given in corresponding post parameter.
						if (! isset($_POST['dialogue_login_u'])) {
							throw new incorrectInputDataException('Access denied. User name must not be empty.');
						}
						elseif (! isset($_POST['dialogue_login_p'])) {
							throw new incorrectInputDataException('Access denied. Password must not be empty.');
						}
						else {
							$loginResult = $backend->login($_POST['dialogue_login_u'], $_POST['dialogue_login_p']);
							if (is_string($loginResult)) {
								throw new incorrectInputDataException($loginResult);
							}
							elseif ($loginResult === true) {
								# login was already done in backend->login
								# if maintainance is on check if user is admin
								if ( (!$backend->currentUser('isAdmin')) AND (isset( $errorMaintenance)) )
									throw new incorrectInputDataException( $errorMaintenance );								
							}
							else {
								throw new developerException('Access denied: cause unknown.');
							}
						}
						
						// check if a jump-to request was passed
						$jumpTo		= sanitize_string($_GET, 'jumpTo',	$_POST);
						$O_v_UUID	= sanitize_string($_GET, 'O_v_UUID',$_POST);
						$V_UUID		= sanitize_string($_GET, 'V_UUID', 	$_POST);
						$OT_UUID	= sanitize_string($_GET, 'OT_UUID', $_POST);
						$FL_UUID	= sanitize_string($_GET, 'FL_UUID', $_POST);
												
						$URL='.';
						if ($jumpTo) {
							$URL='?'.http_build_query(array(
								'jumpTo'	=> $jumpTo,
								'O_v_UUID'	=> $O_v_UUID,
								'V_UUID'	=> $V_UUID,
								'OT_UUID'	=> $OT_UUID,
								'FL_UUID'	=> $FL_UUID
							));
						} // end if
						
						header('Location: '.$URL);
						exit;
					}
				case 'loginA':
				case 'loginAnonymous':
					{ # login as anonymous if enabled in configuration.
						if (!isset($repository_config['anonymousLogin']) or (!$repository_config['anonymousLogin'])) {
							throw new incorrectInputDataException('No anonymous login permitted.');
						}
						else {
							$loginResult = $backend->loginAnonymous();
							if (is_string($loginResult)) {
								throw new incorrectInputDataException($loginResult);
							}
							elseif ($loginResult === true) {
								# login was already done in backend->login
								# if maintainance is on return error message
								if (isset( $errorMaintenance))
									throw new incorrectInputDataException( $errorMaintenance );								
							}
							else {
								throw new developerException('Access denied: cause unknown.');
							}
						}
						
						// check if a jump-to request was passed
						$jumpTo		= sanitize_string($_GET, 'jumpTo',	$_POST);
						$O_v_UUID	= sanitize_string($_GET, 'O_v_UUID',$_POST);
						$V_UUID		= sanitize_string($_GET, 'V_UUID', 	$_POST);
						$OT_UUID	= sanitize_string($_GET, 'OT_UUID', $_POST);
						$FL_UUID	= sanitize_string($_GET, 'FL_UUID', $_POST);
												
						$URL='.';
						if ($jumpTo) {
							$URL='?'.http_build_query(array(
								'jumpTo'	=> $jumpTo,
								'O_v_UUID'	=> $O_v_UUID,
								'V_UUID'	=> $V_UUID,
								'OT_UUID'	=> $OT_UUID,
								'FL_UUID'	=> $FL_UUID
							));
						} // end if
						
						header('Location: '.$URL);
						exit;
					}
				case 'logout':
					{ # logs out from backend
						$backend->logout();
						// Reset Language for login-dialog
						if (isset ( $_SESSION['loginLangCode'] ) )
							$translations->selectLanguage($_SESSION['loginLangCode']);
						header('Location: .');						
						exit; 
						# no break required due to use of exit
					}
				case 'changeLocale':
					{ # set the locale, if required					
						$langCode = sanitize_string($_POST, 'locale', $_GET);
						if ( strlen($langCode)==5 OR $langCode== "default" ) {
							$_SESSION['loginLangCode'] = $langCode;
							$translations->selectLanguage($langCode);
						} // end if set locale
					}
				default:
					{ 					
					# check if there is a user logged in or parameter 'v' is set.
						{ # check if request for dojo part 
							if ( array_key_exists('PHP_dojoHTML_file', $_GET) AND ($_GET['PHP_dojoHTML_file']) ) {
								{ # call PHP file of DOJO HTML
									require($_GET['PHP_dojoHTML_file']);
									exit; # exit switch
								}
							}
						}
						
						// identify the mopdule that needs to be loaded
						$v = sanitize_string($_POST, 'v', $_GET);
						$module = (isset($modules[$v])?$modules[$v]:'');
						if ( $backend->isLoggedIn() or in_array($module, $modulesWithoutLogin) ) { 
						
							// the user is logged in
						
							if (! empty($module) ) { // call a module
								{ # login ok or module in exception list, so call desired module
									require(__DIR__.DIRECTORY_SEPARATOR.$module);
								}
							} else { // load the application
							
								{ # check if information structure version of the repository fits to the information structure version of the database
									$current_version_db = $repository_config['information_structure_version'];
									require_once(realpath($repository_config['application_path'].DIRECTORY_SEPARATOR.'information_structure'.DIRECTORY_SEPARATOR.'upgrade.php'));
									$current_version_cv = informationStructureUpgrader::$current_Version;
									if ($current_version_db != $current_version_cv) {
										# information_structure_version isn't valid for this code_version --> logout
										$backend->logout();
										header('Location: .');
										exit;						
									}
								}
												
								# load application
								include(__DIR__.DIRECTORY_SEPARATOR.'application.php');
							}
						} else { // not logged in --> output the login page
						
							{ # some preliminary checks
									if (isset( $errorMaintenance))											
										throw new incorrectInputDataException( $errorMaintenance );											
									else if (isset( $messageMaintenance))
										$loginMessage = $messageMaintenance;
									
							}
												
							# load login page
							include(__DIR__.DIRECTORY_SEPARATOR.'login.php');
							
						} // end if user is logged in
					} // end of switch-default
			} # end-of-switch
		} catch (Exception $exception) {
			# load login page
			include(__DIR__.DIRECTORY_SEPARATOR.'login.php');
		} // end try ... catch
	}

	exit();				

?>