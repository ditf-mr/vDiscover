/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// The preloader is active directly after loading.
// It needs to be deactivated after everything else is loaded and initialised. 
// This is done by the file deactivate_preloader.js .

var loader = {
	'nodeName' : 'preloader'
	,
	'hide' : function() {
		dojo.fadeOut({
			'node': this.nodeName,
			'onEnd': function() { dojo.style(loader.nodeName, "display", "none"); loader.isShown=false;}
		}).play();
	} // end of method hide
	,
	'show' : function(now /* boolean, default = false */) {
		if (this.isShown) return;
		dojo.style(this.nodeName, "opacity", "0");
		dojo.style(this.nodeName, "display", "block");
		if(now){
			dojo.style(this.nodeName, "opacity", "255");
		} else {dojo.fadeIn({
				'node': this.nodeName,
				'onEnd': function() {loader.isShown=false;}
			}).play();
		} // end if
	} // end of method show
	,
	'isShown' : true
}; // end of object declaration loader

// show the loader when unloading
dojo.addOnWindowUnload(function(){
	loader.show('now');
});