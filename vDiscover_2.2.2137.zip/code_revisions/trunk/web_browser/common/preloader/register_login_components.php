<?php if (!defined('APPLICATION_started')) {header('Location: .');exit;} 
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

// this file registers all preloader componentsa
$r->register_preloaderHTMLFile	('common/preloader/preloader.html.php');
$r->register_JavaScriptFile		('common/preloader/preloader.js');
$r->register_JavaScriptFile		('common/preloader/deactivate_preloader.js', PLUGIN_REGISTRY_loadFinally);
$r->register_cssContent			(require('common/preloader/preloader.css.php'));

?>