<?php if (!defined('APPLICATION_started')) {header('Location: .');exit;} 
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

return '

.loading {
	width:100%; height:100%; 
	margin:0; padding:0;
	text-align:center;
	background:#fff	
		url(./third_party_libraries/'.DOJO_TOOLKIT_path.'/dojox/widget/Standby/images/loading.gif)
		no-repeat center center;
	position:absolute;
	z-index:999;
}

#preloader {
	width:100%; height:100%; 
	margin:0; padding:0;
	text-align:center;
	background:#e1ebfb;
	position:absolute;
	z-index:999;
}

#preloaderBox { /* see http://stackoverflow.com/questions/5012111/how-to-position-a-div-in-the-middle-of-the-screen-when-the-page-is-bigger-than-t */
	/*z-index:1000;*/
	position:fixed;
    top: 33%;
    left: 50%;
    width:16em;
    height:9em;
    margin-top: -4.5em; /*set to a negative number 1/2 of your height*/
    margin-left: -8em; /*set to a negative number 1/2 of your width*/
    border: .1ex solid #b1badf;
    border-radius: .5em;
    box-shadow: 0.5cm 0.5cm 0.5cm gray;
	background:white
		url(./third_party_libraries/'.DOJO_TOOLKIT_path.'/dojox/widget/Standby/images/loading.gif)
		no-repeat center center;

';
?>
