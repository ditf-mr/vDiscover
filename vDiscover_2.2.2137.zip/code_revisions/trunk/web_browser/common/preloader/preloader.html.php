<?php if (!defined('APPLICATION_started')) {header('Location: .');exit;} 
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/
?>
<!-- Begin Preloader Inclusion ########################################################################### -->

<div id="preloader" ondblclick="loader.hide();">
	<p style="text-align: center;">&nbsp;</p>
	<div id="preloaderBox">
		<p style="text-align: center;padding-top: 1em;"><?php echo T('preloader.php/PleaseBePatient_TXT', 'Please be patient for a moment &hellip;'); ?></p>
	</div>
</div>


<!-- End Preloader Inclusion ########################################################################### -->