 /* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

/* 

This file defines the multilanguage component of vDiscover.

Usage

In each *.js file, define the name space, that shall be used. Examples:
<script type="text/javascript">
translationEngine.setNameSpace('application.admin'); // the current namespace is now 'application.admin'
translationEngine.setNameSpace(''); // the current namespace is now 'global'
</script>

To translate a JavaScript string, call the t() or the T() function. Both return a translation, although T does this always in the global name space.
Examples:
<script type="text/javascript">
t('ADMIN_PANE_TITLE', 'Administration Pane', null, 'application.admin') // returns e.g. 'Admin pane' or 'Administration Pane' (default in case that no language string for this key 'ADMIN_PANE_TITLE' is defined)
T('GOOD_MORNING', 'Good morning to you, $[1] $[0]!', ['Edwards', 'John']) // returns e.g. 'Good morning to you, John Edwards!'
T('GOOD_MORNING', 'Good morning to you, $[firstName] $[lastName]!', {'lastName':'Edwards', 'firstName':'John'}) // returns e.g. 'Good morning to you, John Edwards!'
</script>

*/


if(typeof generalClasses == 'undefined') {
	generalClasses = {};
} // end if

generalClasses.translationEngine = function () {
	
	// slots
	this.translationStores 		= null; // will be set to {}
	this.pendingForTranslation	= null; // will be set to {}
	
	// methods
	
	this.constructor = function() {

		this.translationStore 		= null;
		this.pendingForTranslation	= {};
		
		this.lifeCycleStatus = 'initialising';
		
	}; // end of method constructor
	
	this.postMixInProperties = function () {
		// this.inherited(arguments);
	
		this.lifeCycleStatus = 'ready for requests';
	};// end of method postMixInProperties
	
	this._webClientHasLocalStorage = function () { // see http://diveintohtml5.info/storage.html
		try {
			return 'localStorage' in window && window['localStorage'] !== null;
		} catch (e) {
			return false;
		} // end try .. catch
	}; // end of method _webClientHasLocalStorage
	
	this.loadLanguageStrings = function () {
		if(!this.translationStore) {
			dojo.require("dojo.data.ItemFileReadStore");
			
			// get the current lang code if present
			var currentLocale = ( 		('locale' in application.configuration.global)
									&& (application.configuration.global.locale.length>0)
								) 
									? 
										application.configuration.global.locale 
									: 	'default' 
								;
			if( this._webClientHasLocalStorage() ) {
				var r	= application.configuration.global.repository_name,
					storedLocale = localStorage.getItem( 'RS_locale::'+r );
				if (storedLocale) currentLocale = storedLocale;			
			};
			
			dojo.xhrPost({
				'url'		: '?'
				,
				'content'	: {
					'v'			: 'getLanguageStrings',
					'langCode'	: currentLocale,
				}
				,
				// 'error'		: 	application.AJAX_errorMessage, // function
				'handleAs'	: 'json',
				'scope'		: this,
				'load'		: function(r,a){ /* onSuccess */
					this.scope.translationStore = new dojo.data.ItemFileReadStore({
							'data' 				: r,
							'clearOnClose' 		: true,
							'urlPreventCache' 	: true,
					});
				}, // end of onSuccess method
				//preventCache:true,
				//failOk	: true,
				'sync'		: true,
				// 'timeout'	: 2000
			});

		} // end if
	}; // end of method loadLanguageStrings
	
	this.lookUpTranslation = function(key, defaultTranslation) {
	
		if(!this.translationStore) this.loadLanguageStrings();
		
		var translation = '';
		this.translationStore.fetchItemByIdentity({
			'identity' : key,
			'onItem' : function(item) {
				if(item) translation = this.translationStore.getValue(item,'translation');
			} // end of method onItem
			,
			'scope' : this
		});
		
		// return the translation or the default translation
		if(translation.length) {
			return translation;
		} else {
			if(!this.pendingForTranslation) this.pendingForTranslation={};
			if(!this.pendingForTranslation[key]) this.pendingForTranslation[key]=defaultTranslation;
			return this.pendingForTranslation[key];
		} // end if
	}; // end of method lookUpTranslation
	
	this.translate = function (key, defaultTranslation, data) {
		/* 
		This function returns a translation string for key.
		If no corresponding translation string was found, translateMe will be used as language string.
		The language string may contain variables. These need to be defined within data as array elements or object slots.

		*/
		if((typeof key!='string') || !key.length) throw new Error('Cannot translate "'+defaultTranslation+'" without key.');
		
		var t=this.lookUpTranslation(key, defaultTranslation);
		
		// are there specific arguments to be placed in the language string?
		if ((typeof data=='array') || (typeof data=='object')) {
			try{
				// place the arguments in the language string
				t=dojo.replace(t, data, /\$\[([^\]]+)\]/g);
				// $[0] - first slot in array data
				// $[first name] - slot 'first name' in object data
			} catch(e) {
				console.error(e);
				console.log(key, defaultTranslation, data);
				throw new Error('Language string with key"'+key+'": There is a problem with the $[...] variables in\n"'+t+'":\n'+e.toString());
			} // end try .. catch
		} // end if
		return t;
	}; // end of method translate
	
	this.getStringsThatArePendingForTranslation = function () {
		/* This method returns all language strings that need to be translated. */
		if ( (!typeof this.pendingForTranslation[nameSpace]=='object') ) return false;
		return this.pendingForTranslation;
	}; // end of method getStringsThatArePendingForTranslation
	
	this.constructor();
	this.postMixInProperties();
	
// }); // end of class declaration 'application.translationEngine'
};

//}); // end dojo.addOnLoad

function T(key, defaultTranslation, data) {
	/* 
	This function returns a translation string for a given key.
	If no corresponding translation string was found, defaultTranslation will be used as language string.
	The language string may contain variables. These need to be defined within data as array elements or object slots.

	*/
       
	try {
		return translationEngine.translate( key, defaultTranslation, data );
	} catch (exception) {
		var e = 'Translation engine error: translation operation failed.\n'
			+ 'Command   : translationEngine.translate( key, defaultTranslation, data );\n\n'
			+ 'Parameters: key                = \''+key+'\'\n'
			+ '            defaultTranslation = \''+defaultTranslation+'\'\n'
			+ '            data               = \''+dojo.toJson(data)+'\'\n';
		console.error(e);
		console.error('Exception:', exception);
	} // end try ... catch
} // end of function T

translationEngine = new generalClasses.translationEngine();
