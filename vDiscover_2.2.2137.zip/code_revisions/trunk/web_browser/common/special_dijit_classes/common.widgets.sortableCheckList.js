/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

dojo.declare('common.widgets.sortableCheckList',[dijit._Widget, dijit._Templated],{

	/* This widget provides a sortable check list looking like
	
	|---------------------------------------|
	|Check all ... | Uncheck all ...		|
	|---------------------------------------|
	|☑ Item 						       ↕|
	|☑ Item 						       ↕|
	|☑ Item 						       ↕|
	|---------------------------------------|
	|☐ Item								|
	|☐ Item								|
	|☐ Item								|
	|☐ Item								|
	|☐ Item								|
	|☐ Item								|
	|---------------------------------------|
	
	Clicking on one of the arrows in ↕ permits to move the check item up /down in the list.
	
	The list of checked items (an array) can be retrieved by calling the method getCheckedItems() .
	
	*/

	// When creating an instance of this class, the following slots are necessary:
	
	'itemList'			: null // type: { 'UUID' : 'Item label/ name', 'UUID' : 'Item label/ name', 'UUID' : 'Item label/ name', ...}
	,
	'checkedItems' 		: null // type: [ 'UUID', 'UUID', 'UUID', ...]
	,
	
	
	// these slots are mandantory ... set them to customise the texts in the widget
	'checkedItemsLabel'	: null, // 'Checked Items'
	'uncheckedItemsLabel': null, // 'Available Items'
	'uncheckAllLabel'	: null, // 'Uncheck all'
	'checkAllLabel' 	: null, // 'Check all'
	
	
	
	'widgetsInTemplate' : true
	,
	'templateString' : ''	// the template string will be built in this.postMixInProperties
	,
	'constructor' : function() {
		// Your constructor method will be called before the parameters are mixed into the widget, and can be used to initialize arrays, etc.
		this.inherited(arguments);
		
		// initialisations
		this.checkedItems = [];
		this.itemWidgets = {};
		
		this.checkedItemsLabel 	= T('commWidSortChkList.js/CheckedItems_LBL', 	'Checked Items'		);
		this.uncheckedItemsLabel= T('commWidSortChkList.js/AvailItems_LBL', 	'Available Items'	);
		this.uncheckAllLabel	= T('commWidSortChkList.js/UnchkAll_LBL',		'Uncheck all'		);
		this.checkAllLabel		= T('commWidSortChkList.js/ChkAll_LBL',			'Check all'			);

		
	} // end of method constructor
	,
	'postMixInProperties' : function () {
		this.inherited(arguments);
	
		// test if the necessary inputs are given
		if ( 		!dojo.isObject	(this.itemList) 
				|| 	 dojo.isArray	(this.itemList)
				||   dojo.isFunction(this.itemList)
		) throw this.declaredClass+'::postMixInProperties : when creating an instance of this class, you need to provide at least the slot \'itemList\' of the type {}. Aborting.';
		
		this.templateString = ''
			+'<div class="dijitMenuBar" style="display:inline-block;">'
			
				+'<table dojoAttachPoint="checkedItemsList_domNode" class="compact fullWidth dijitMenuBar" style="border-left:0;border-top:0;border-right:0;">'
					+'<thead class="dijitMenuBar"  style="border-top:0;border-left:0;border-right:0;margin-bottom:.5em;">'
						+'<tr>'
							+'<td style="width:1em;">'
								+'&nbsp;'
							+'</td>'
							+'<td dojoAttachPoint="checkedItemsTitle_domNode">'
								+this.checkedItemsLabel
							+'</td>'
							+'<td style="width:.5em;">'
							+'</td>'
						+'</tr>'
					+'</thead>'
					+'<tbody dojoAttachPoint="checkedItems_domNode">'
						
						+'<tr dojoAttachPoint="uncheckAll_domNode" dojoAttachEvent="onmouseenter:_onHover,onmouseleave:_onUnHover" class="dijitMenuItemDisabled">'
							+'<td style="width:1em;">'
								+'<div class="dijit dijitReset dijitInline dijitCheckBox" style="cursor:pointer;" title="'+this.uncheckAllLabel+'" dojoAttachEvent="onclick:uncheckAll" />'
							+'</td>'
							+'<td class="small"  dojoAttachEvent="onclick:uncheckAll" style="cursor:pointer;">'
								+this.uncheckAllLabel
							+'</td>'
							+'<td style="width:.5em;">'
							+'</td>'
						+'</tr>'
					+'</tbody>'	
				+'</table>'	
		
				+'<table dojoAttachPoint="uncheckedItemsList_domNode" class="compact fullWidth dijitMenuBar" style="border-left:0;border-right:0;border-bottom:0;border-top:0;">'
					+'<thead class="dijitMenuBar"  style="border-top:0;border-left:0;border-right:0;margin-bottom:.5em;">'
						+'<tr>'
							+'<td style="width:1em;">'
								+'&nbsp;'
							+'</td>'
							+'<td dojoAttachPoint="uncheckedItemsTitle_domNode">'
								+this.uncheckedItemsLabel
							+'</td>'
							+'<td style="width:.5em;">'
							+'</td>'
						+'</tr>'
					+'</thead>'
					+'<tbody dojoAttachPoint="unCheckedItems_domNode">'
						+'<tr dojoAttachPoint="checkAll_domNode" dojoAttachEvent="onmouseenter:_onHover,onmouseleave:_onUnHover" class="dijitMenuItemDisabled">'
							+'<td style="width:1em;">'
								+'<div class="dijit dijitReset dijitInline dijitCheckBox dijitCheckBoxChecked dijitChecked" style="cursor:pointer;" title="'+this.checkAllLabel+'" dojoAttachEvent="onclick:checkAll" />'
							+'</td>'
							+'<td class="small"  dojoAttachEvent="onclick:checkAll"  style="cursor:pointer;">'
								+this.checkAllLabel
							+'</td>'
							+'<td style="width:.5em;">'
							+'</td>'
						+'</tr>'
					+'</tbody>'	
				+'</table>'	
		
			+'</div>';		
	
	} // end of method postMixInProperties
	,
	'postCreate' : function() {
		// This is typically the workhorse of a custom widget. The widget has 
		// been rendered (but note that sub-widgets in the containerNode have not!). 
		// The widget though may not be attached to the DOM yet so you shouldn't 
		// do any sizing calculations in this method.
		this.inherited(arguments);
		
		// create widgets for all checked items
		dojo.forEach(this.checkedItems, function (UUID) {
		
			if (UUID in this.itemList) this.itemWidgets[UUID] = new common.widgets.sortableCheckList.checkableItem({
				'checked'		: true,
				'UUID'			: UUID,
				'label'			: this.itemList[UUID],
				'parentWidget'	: this,
			}).placeAt(this.checkedItems_domNode);
			this.connect( this.itemWidgets[UUID], 'item_repositioned', '_call_onChange');
			
		}, this);
		
		// create widgets for all unchecked items
		for (var UUID in this.itemList) {
		
			if ( dojo.indexOf(this.checkedItems, UUID)<0 ) this.itemWidgets[UUID] = new common.widgets.sortableCheckList.checkableItem({
				'checked'		: false,
				'UUID'			: UUID,
				'label'			: this.itemList[UUID],
				'parentWidget'	: this,
			}).placeAt(this.unCheckedItems_domNode);
			this.connect( this.itemWidgets[UUID], 'item_repositioned', '_call_onChange');
	
		} // end for ... in
		
		// place the labels
		this._showHideMessages();
		
	} // end of method postCreate
	,
	'startup' : function() {
		// If you need to be sure parsing and creation of any child widgets has 
		// completed, use startup. This is often used for layout widgets like 
		// BorderContainer. If the widget does JS sizing, then startup() should 
		// call resize(), which does the sizing.
		this.inherited(arguments);
		
		// this should take car of displaying all up/down arrows, properly
		for (var UUID in this.itemWidgets) this.itemWidgets[UUID].startup();
		
	} // end of method startup
	,
	'showHideUpDownArrows' : function () {
		for (var UUID in this.itemWidgets) this.itemWidgets[UUID]._showHideUpDownArrows();	
	} // end of method showHideUpDownArrows
	,
	'_call_onChange' : function () {
		this.onChange( this.getCheckedItems() );
	} // end of method _call_onChange
	,
	'widgetGotChecked' : function (w) {
	
		w.placeAt(this.checkedItems_domNode);
		this.showHideUpDownArrows();
	
		this._call_onChange();
	} // end of method widgetGotChecked
	,
	'widgetGotUnChecked' : function (w) {
	
		// The list of unchecked items is ordered as given by the initialisation.
		// Hence, the widget w should be placed after last unchecked one in this.itemList.

		var insertAfterDOMNode = null;
		for (var currentUUID in this.itemList) {
			var currentWidget = this.itemWidgets[currentUUID];
			if (currentUUID==w.UUID) break;
			if (!currentWidget.checked) insertAfterDOMNode = currentWidget.domNode;
		} // end for .. in
		
		// decide where to move w to

		if (insertAfterDOMNode) {
			w.placeAt(insertAfterDOMNode, 'after');
		} else {
			// the widget goes first into the list
			w.placeAt(this.checkAll_domNode, 'after');
		} // end if

		this.showHideUpDownArrows();
		this._call_onChange();	
	} // end of method widgetGotUnChecked
	,
	'onChange' : function (checkedItems) {
		this._showHideMessages();
		return checkedItems;
	} // end of method onChange
	,
	'check'		: function (UUID) {
		if( 		this.itemWidgets[UUID] 
				&& 	(!this.itemWidgets[UUID].checked) 
			) this.itemWidgets[UUID]._labelClicked();	
	} // end of method check
	,
	'_showHideMessages' : function () {
		var availableItems	= Object.keys(this.itemWidgets).length,
			checkedItems	= dijit.findWidgets(this.checkedItems_domNode).length;
		
		dojo.style( this.uncheckAll_domNode, 		'display', ((checkedItems>1)?'table-row':'none') );
		dojo.style( this.checkAll_domNode, 			'display', ((availableItems-checkedItems>1)?'table-row':'none') );
		
		dojo.style( this.checkedItemsList_domNode,	'display', ((checkedItems>0)?'table':'none') );
		dojo.style( this.uncheckedItemsList_domNode,'display', ((availableItems-checkedItems>0)?'table':'none') );
		
	} // end of method _showHideMessages
	,
	'_hoverclasses' : 'dijitReset dijitMenuItemSelected dijitMenuItemFocused dijitFocused'
	,
	'_onHover' : function(e) {
		dojo.addClass(e.currentTarget, this._hoverclasses);
		dojo.stopEvent(e);
	} // end of method _onHover
	,
	'_onUnHover' : function(e) {
		dojo.removeClass(e.currentTarget, this._hoverclasses);
		dojo.stopEvent(e);
	} // end of method _onUnHover
	,
	'getCheckedItems' : function () {
		
		var checkedItemWidgets = dijit.findWidgets(this.checkedItems_domNode),
			checkedItems = [];
		
		dojo.forEach( checkedItemWidgets, function (w) {
			checkedItems.push(w.UUID);
		},this);
		
		return checkedItems;
	} // end of method getCheckedItems
	,

	'checkAll' : function () {
		var wArr = dijit.findWidgets(this.unCheckedItems_domNode);
		
		dojo.forEach( wArr, function (w) {
			w._labelClicked(); // this toggles the checked status
		},this);
	} // end of method checkAll
	,

	'uncheckAll' : function () {
		var wArr = dijit.findWidgets(this.checkedItems_domNode);
		
		dojo.forEach( wArr, function (w) {
			w._labelClicked(); // this toggles the checked status
		},this);
	} // end of method uncheckAll
	,
	'destroy' : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
		
		for (var i in this.itemWidgets) {
			this.itemWidgets[i].destroy();
			delete this.itemWidgets[i];
		} // end for .. in
		
		this.inherited(arguments);
	} // end of method destroy
	,

});

dojo.declare('common.widgets.sortableCheckList.checkableItem',[dijit._Widget, dijit._Templated],{

	// these parameters need to be passed upon instantiation
	'checked'		: null // boolean
	,
	'UUID'			: null // string
	,
	'label'			: null // string
	,
	'parentWidget'	: null // instance of common.widgets.sortableCheckList
	,


	'widgetsInTemplate' : true
	,
	'constructor' : function() {
		// Your constructor method will be called before the parameters are mixed into the widget, and can be used to initialize arrays, etc.
		this.inherited(arguments);
		
	} // end of method constructor
	,
	'postMixInProperties' : function () {
		this.inherited(arguments);
		
		this.isChecked = this.checked ? 'true' : 'false';
	
	} // end of method postMixInProperties
	,
	'templateString' : ''
		+'<tr dojoAttachEvent="onmouseenter:_onHover,onmouseleave:_onUnHover" style="vertical-align:middle;">'
			+'<td style="width:1em;">'
				+'<div dojoType="dijit.form.CheckBox" dojoAttachPoint="checkBoxWidget" dojoAttachEvent="onClick:_checkBoxClicked" checked="${isChecked}" style="cursor:pointer;"/>'
			+'</td>'
			+'<td>'
				+'<span dojoAttachEvent="onclick:_labelClicked" style="cursor:pointer;">${label}</span>'
			+'</td>'
			+'<td style="margin-left:1em;width:.5em;vertical-align:middle;">'
				+'<div dojoAttachPoint="upDownArrowBox_domNode" style="display:inline-block;height:1em;position:relative;">'
					+'<img src="./third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/arrow-up-3.png" class="RS_sortableCheckListUpDownBox" style="position:absolute;top:0;right:0;" dojoAttachPoint="_upButton_domNode" dojoAttachEvent="onclick:_upButtonClicked" title="Move this list item up."/>'
					+'<img src="./third_party_libraries/open-icon-library-standard-0.10/icons/png/16x16/actions/arrow-down-3.png" class="RS_sortableCheckListUpDownBox" style="position:absolute;bottom:0;right:0;" dojoAttachPoint="_downButton_domNode" dojoAttachEvent="onclick:_downButtonClicked" title="Move this list item down."/>'
				+'</div>'
			+'</td>'
		+'</tr>'
	,
	'postCreate' : function() {
		// This is typically the workhorse of a custom widget. The widget has 
		// been rendered (but note that sub-widgets in the containerNode have not!). 
		// The widget though may not be attached to the DOM yet so you shouldn't 
		// do any sizing calculations in this method.
		this.inherited(arguments);
				
	} // end of method postCreate
	,
	'startup' : function (){
		this.inherited(arguments);
		
		this._showHideUpDownArrows();
	} // end of method startup
	,
	'_checkBoxClicked' : function(e) {
		if (e) dojo.stopEvent(e);
		
		// store the current status
		this.checked = this.checkBoxWidget.attr('checked');
		
		// tell the parent widget that this widget got checked or unchecked
		if (this.checked) {
			this.parentWidget.widgetGotChecked(this);
		} else {
			this.parentWidget.widgetGotUnChecked(this);
		} // end if
		
		this._onUnHover();
		this._showHideUpDownArrows();
		
	} // end of method _checkBoxClicked
	,
	'_labelClicked' : function(e) {
		if(e) dojo.stopEvent(e);

		// invert the checkboxes checked status
		var isChecked = (this.checkBoxWidget.attr('checked') ? true : false);
		this.checkBoxWidget.attr('checked', !isChecked);
		
		this._checkBoxClicked();
	} // end of method _labelClicked
	,
	'_upButtonClicked' : function(e) {
		this._onUnHover();

		var previousNode	= this.domNode.previousSibling,
			previousWidget	= dijit.byNode(previousNode);
		
		if( previousNode && dijit.byNode(previousNode) ) {
			this.placeAt(previousNode, 'before');
			this._showHideUpDownArrows();
			previousWidget._showHideUpDownArrows();
		} // end if 
		
		dojo.stopEvent(e);
		this.item_repositioned();
	} // end of method _upButtonClicked
	,
	'_downButtonClicked' : function(e) {
			this._onUnHover();
	
		var nextNode		= this.domNode.nextSibling,
			nextWidget		= dijit.byNode(nextNode);
		
		if( nextNode && dijit.byNode(nextNode) ) {
			this.placeAt(nextNode, 'after');
			this._showHideUpDownArrows();
			nextWidget._showHideUpDownArrows();
		} // end if
		
		dojo.stopEvent(e);
		this.item_repositioned();
	} // end of method _downButtonClicked
	,
	'_hoverclasses' : 'dijitReset dijitMenuItemSelected dijitMenuItemFocused dijitFocused'
	,
	'_onHover' : function() {
		dojo.addClass(this.domNode, this._hoverclasses);
	} // end of method _onHover
	,
	'_onUnHover' : function() {
		dojo.removeClass(this.domNode, this._hoverclasses);
	} // end of method _onUnHover
	,
	'_showHideUpDownArrows' : function () {
		dojo.style( this.upDownArrowBox_domNode, 'display', (this.checked?'block':'none') );
		
		var previousNode	= this.domNode.previousSibling,
			nextNode 		= this.domNode.nextSibling;
		
		dojo.style( this._upButton_domNode, 	'display', (previousNode 	&& dijit.byNode(previousNode)	?'inline-block':'none') );
		dojo.style( this._downButton_domNode, 	'display', (nextNode 		&& dijit.byNode(nextNode)		?'inline-block':'none') );
		
	} // end of method _showHideUpDownArrows
	,
	
	// Events
	'item_repositioned' : function () {},
});

