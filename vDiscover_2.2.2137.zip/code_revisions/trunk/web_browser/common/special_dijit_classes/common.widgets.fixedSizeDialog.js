/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

if(!dojo._hasResource["common.widgets.fixedSizeDialog"]){

dojo._hasResource["common.widgets.fixedSizeDialog"]=true;
dojo.provide("common.widgets.fixedSizeDialog");


dojo.require('dijit.Declaration');
dojo.require('dijit.Dialog');

dojo.declare('common.widgets.fixedSizeDialog',[dijit.Dialog],{
	'innerHeight'	: 800 // overwrite this value as necessary
	,
	'innerWidth'	: 1000 // overwrite this value as necessary
	,
	/*'constructor' : function() {
		// Your constructor method will be called before the parameters are mixed into the widget, and can be used to initialize arrays, etc.
		this.inherited(arguments);
		
	} // end of method constructor
	,*/
	'postMixInProperties' : function() {
		// If you provide a postMixInProperties method for your widget, 
		// it will be invoked before rendering occurs, and before 
		// any dom nodes are created. If you need to add or change the 
		// instance's properties before the widget is rendered 
		// - this is the place to do it.
		this.inherited(arguments);
		
	} // end of method postMixInProperties
	,
	/*buildRendering : function() {
		// dijit._Templated provides an implementation of buildRendering 
		// that most times will do what you need. The template is fetched/read, 
		// nodes created and events hooked up during buildRendering. The end 
		// result is assigned to this.domNode. If you don't mixin dijit._Templated 
		// (and most OOTB dijits do) and want to handle rendering yourself 
		// (e.g. to really streamline a simple widget, or even use a different 
		// templating system) this is where you'd do it.
		this.inherited(arguments);
	} // end of method buildRendering
	,*/
	'postCreate' : function() {
		// This is typically the workhorse of a custom widget. The widget has 
		// been rendered (but note that sub-widgets in the containerNode have not!). 
		// The widget though may not be attached to the DOM yet so you shouldn't 
		// do any sizing calculations in this method.
		this.inherited(arguments);
			
	} // end of method postCreate
	,
	'startup' : function() {
		// If you need to be sure parsing and creation of any child widgets has 
		// completed, use startup. This is often used for layout widgets like 
		// BorderContainer. If the widget does JS sizing, then startup() should 
		// call resize(), which does the sizing.
		this.inherited(arguments);
	
		this.connect(window, "onresize", 'resize');

		this.resize();
	
	} // end of method startup
	,
    'resize' : function() {
		// All widgets that do JS sizing should have a method called resize(), that lays 
		// out the widget. Resize() should be called from startup() and will also be 
		// called by parent widgets like dijit.layout.ContentPane.
		
		this.inherited(arguments);
		
		this.viewPortHeight = dojo.doc.body.clientHeight;
		this.viewPortWidth 	= dojo.doc.body.clientWidth;
		
		this.contentBoxHeight= Math.min( this.viewPortHeight-50, Math.floor(this.viewPortHeight * .9), this.innerHeight );
		this.contentBoxWidth = Math.min( this.viewPortWidth	-50, Math.floor(this.viewPortWidth 	* .9), this.innerWidth  );
		
		// resize the inner part of this dialog
		dojo.style( this.containerNode, 'height',	''+this.contentBoxHeight+'px' );
		dojo.style( this.containerNode, 'width',	''+this.contentBoxWidth+'px' );
		
		// tell all children to resize
		var subWidgets = dijit.findWidgets(this.containerNode);
		dojo.forEach(subWidgets,function(w){
			if(w.resize) w.resize();
		},this);
		
		this._position();
		
	} // end of method resize
	,
	/*destroy : function() {
		// Implement destroy if you have special tear-down work to do 
		// (the superclasses will take care of most of it for you).
				
		this.inherited(arguments);
		
		
	} // end of method destroy
	,*/
	/*'onCancel' : function(){
		return false;
	} // end of method
	,*/
});

} // end if provide module