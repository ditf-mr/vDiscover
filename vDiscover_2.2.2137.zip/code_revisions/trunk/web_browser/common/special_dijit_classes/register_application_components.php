<?php if (!defined('APPLICATION_started')) {header('Location: .');exit;} 
/* 
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
*/

$r->register_JavaScriptFile('common/special_dijit_classes/common.widgets.Tooltip.js');
$r->register_JavaScriptFile('common/special_dijit_classes/common.widgets.fixedSizeDialog.js');
$r->register_JavaScriptFile('common/special_dijit_classes/common.widgets.sortableCheckList.js');
$r->register_JavaScriptFile('common/special_dijit_classes/common.widgets.printableContent.js');

?>