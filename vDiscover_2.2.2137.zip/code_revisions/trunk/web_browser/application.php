<?php if (!defined('APPLICATION_started')) {header('Location: .');exit;} ?><!DOCTYPE HTML><html>
<head>
<!--
	vDiscover (Retrieval System for Structured Information)
	-------------------------------------------------------
	
	For documentation, license conditions and warranty
	see Read.Me in root directory.
-->

<?php
require_once ('../common/cPluginRegistry.php');
// the plugin registry can be accessed via the variable $r from now on
$r = new cApplicationRegistry();

$r->set_configOption( 'repository_name', 		$repository_config['repository_name']);
$r->set_configOption( 'DOJO_TOOLKIT_path', 		DOJO_TOOLKIT_path);

// register the application components
try {
	
	// register all main components
	cApplicationRegistry::registerModuleComponents(array(
			// components in these modules will be included in the given order
			'third_party_libraries',
			'common'.DIRECTORY_SEPARATOR.'lang',
			'common'.DIRECTORY_SEPARATOR.'special_dijit_classes',
			'media',
			'application',
			'..'.DIRECTORY_SEPARATOR.'common_plugins'
		)
		, __DIR__);// , '' /*$registerFileName*/,false /*$verbose*/, false);
	
	// make the DOJO toolkit path available in JavaScript, as well
	$r->set_configOption('AJAX_default_timeout', 	AJAX_default_timeout);
	
	// register all plugins
	cApplicationRegistry::registerModuleComponents(PLUGIN_REGISTRY_parseAllSubDirs, $repository_config['path_plugins'] );

	// test if a jumpTo request was passed
	$jumpTo=''; $O_v_UUID=''; $V_UUID=''; $OT_UUID=''; $FL_UUID='';
	if(isset($_GET['jumpTo'])) 		$jumpTo		= sanitize_string($_GET, 'jumpTo');
	if(isset($_GET['O_v_UUID'])) 	$O_v_UUID	= sanitize_string($_GET, 'O_v_UUID');
	if(isset($_GET['V_UUID'])) 		$V_UUID		= sanitize_string($_GET, 'V_UUID');
	if(isset($_GET['OT_UUID'])) 	$OT_UUID	= sanitize_string($_GET, 'OT_UUID');
	if(isset($_GET['FL_UUID'])) 	$FL_UUID	= sanitize_string($_GET, 'FL_UUID');
	
	// identify the jumpTo request and translate it to JavaScript
	switch ( true) {
		// show an object -------------------------------------------------------
		case (($jumpTo=='O') AND $O_v_UUID): {
				$r->register_JavaScript ('
					dojo.addOnLoad(function(){
						application.O.show("'.$O_v_UUID.'", "'.$V_UUID.'");
					});
				');
			} break;
		// show an object type --------------------------------------------------
		case (($jumpTo=='OT') AND $OT_UUID): {
				$r->register_JavaScript ('
					dojo.addOnLoad(function(){
						// Using a timeout here is someway silly, I know.
						// the object type store isn\'t initialised properly, if not so.
						setTimeout(function(){application.OT.show("'.$OT_UUID.'");},2000);
					});
				');
			} break;
		// show a find list of an object type ------------------------------------
		case (($jumpTo=='OTfindList') AND $OT_UUID AND $FL_UUID): {
				$r->register_JavaScript ('
					dojo.addOnLoad(function(){
						// Using a timeout here is someway silly, I know.
						// the object type store isn\'t initialised properly, if not so.
						setTimeout(function(){
							application.OT.show("'.$OT_UUID.'", "OT_menubar_itemKinds.general.all", {"loadFindQuery": "'.$FL_UUID.'"});
						},2000);
					});
				');
			} break;
		default: // do nothing
	} // end switch jumpTo request identification
	
		
	// last: register the preloader
	cApplicationRegistry::registerModuleComponents(array(
			'common'.DIRECTORY_SEPARATOR.'preloader' // this module is registered last because the preloader deactivation should happen after everything else is instantiated
		)
		, __DIR__ );
		
		
} catch (Exception $e) {
	echo '</head>';
	echo '
			<body>
				<h1>Failed to register all application components :-(</h1>
				<h2>Details:</h2>
				<p>The most important aspect is the message, the other aspects tell you where the error/ exception occurred.</p>
				<table>
					<tbody>
						<tr><th style="vertical-align:baseline;">Message:</th><td><pre>'.$e->getMessage().'</pre></td></tr>
						<tr><th style="vertical-align:baseline;">Code:</th><td><pre>'.$e->getCode().'</pre></td></tr>
						<tr><th style="vertical-align:baseline;">File:</th><td><pre>'.$e->getFile().'</pre></td></tr>
						<tr><th style="vertical-align:baseline;">getLine:</th><td><pre>'.$e->getLine().'</pre></td></tr>
						<tr><th style="vertical-align:baseline;">getTraceAsString:</th><td><pre>'.$e->getTraceAsString().'</pre></td></tr>
					</tbody>
				</table>
			</body>
		</html>';
	exit();
} // end try ... catch
{// output the application ###############################################################
?>
 	<meta http-equiv="content-type" content="text/html;charset=utf-8" />
	<!--<meta http-equiv="X-UA-Compatible" content="IE=8" />-->
	<link rel="shortcut icon" href="<?php echo $r->get_configOption('appTitle_favIcon', './media/favicon/vdiscover.ico'); ?>"  type="image/x-icon"/>
	<link rel="icon" href="<?php echo $r->get_configOption('appTitle_favIcon', './media/favicon/vdiscover.ico'); ?>"  type="image/x-icon"/>

	<title><?php echo $repository_config['application_title_HTML'] ?></title>
<?php
$r->outputRegisteredCSSFiles();
$r->outputRegisteredCSSContent();


// get the list of all available languages and create a JavaScript variable
$langs = $translations->getAvailableLanguages();
$langs['default'] = 'Default (English)';

// build the JavaScript object structure
$langStoreData = Array (
	'identifier'=> 'locale',
	'label'		=> 'localeName_display',
	'items'		=> Array(),

);
reset($langs);
while (list($locale, $localeName_display) = each($langs)) {
	$langStoreData['items'][]=array(
		'locale'			=> $locale,
		'localeName_display'=> $localeName_display,
	);
} // end while $langs

// output the language list to JavaScript
echo "\t".'<script type="text/javascript">'."\n".
	"\t\t// List of available locales\n".
	"\t\t".'var langStoreData = '.json_encode($langStoreData, true).';'.
	"\n\t".'</script>'."\n";

$r->outputConfigOptions();
$r->outputJavaScriptFiles();
$r->outputJavaScript();
} // end application output

?>
</head>

<body class="<?php echo $repository_config['DOJO_theme']; ?>">

<!-- Begin Preloader -->
<?php $r->outputRegisteredPreloaderHTMLFile(); ?>
<!-- End Preloader -->

<div>
<?php $r->outputRegisteredDialogs(); ?>
</div>
	
<!-- Main Application -->
<?php
$r->outputRegisteredMainHTMLFile();
?>
<!-- End Main Application -->

</body></html>