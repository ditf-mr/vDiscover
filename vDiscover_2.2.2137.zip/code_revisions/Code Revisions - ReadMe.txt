﻿Here is a brief overview of the code versions that are available by default:

	stable		A tested, reliable code version that gets bug fixes, only. Updates are announced and come with
				a feature list and upgrade instructions.
	
	trunk		The development code version. Do not expect that everything will work fine. But expect new features.


To use another code revision than trunk, do the following:-

1) 	Create a folder, prefereably with tailing ".cr" (these subfolders will be ignored by Subversion, here).

2) 	Right-click on the folder and check out the corresponding code revision of the DITF Retrieval System.
	The project archive URL is e.g. https://koersch.ditf-denkendorf.de/svn/retrieval_system2/code_revisions/trunk .
	Check out the revision number of your choice.

3)	Reload the Repository Manager. The new code version will be available, then.